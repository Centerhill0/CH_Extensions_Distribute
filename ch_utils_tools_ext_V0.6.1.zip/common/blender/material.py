"""
材质共享算法模块

提供以下功能:
- MATERIAL_SLOT_TYPES: 可拥有材质槽的物体类型集合
- assign_material: 把材质赋给一组物体的活动材质槽(无槽时追加新槽)

供 ch_utils_tools(材质拾取器 ASSIGN)与 ch_scene_helper(材质面板 Assign to Selected)共用;
纯函数与常量, 不含 bpy 类型声明, 故不参与 class_loader 的注册(见 common/blender/list_snapshot.py 先例).
"""

from bpy.types import Material

# 可拥有材质槽的物体类型(网格/曲线/文本/曲面/融球)
MATERIAL_SLOT_TYPES = {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}


def assign_material(mat: Material, objects: list) -> tuple:
    """把材质赋给一组物体的活动材质槽(无槽时追加新槽), 返回 (赋值物体数, 错误信息)

    仅处理可拥有材质槽的物体类型(MATERIAL_SLOT_TYPES), 其它类型静默跳过.

    Args:
        mat: 待赋值材质
        objects: 目标物体列表

    Returns:
        (成功赋值的物体数, 错误信息或 None)
    """
    if mat is None:
        return 0, "material is None"
    count = 0
    for obj in objects:
        if obj.type not in MATERIAL_SLOT_TYPES:
            continue
        if not obj.material_slots:
            obj.data.materials.append(mat)
        else:
            obj.material_slots[obj.active_material_index].material = mat
        count += 1
    return count, None
