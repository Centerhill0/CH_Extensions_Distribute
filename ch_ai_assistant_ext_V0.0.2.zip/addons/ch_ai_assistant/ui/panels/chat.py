"""
AI 对话面板模块

提供以下功能:
- 纯文本问答: 消息历史列表(点击行按偏好转出到文本编辑器阅读长回复), 输入框与发送按钮
- "自动打开对话"开关(存于偏好设置): 新回复与点击的消息自动转出到文本编辑器
- 清空对话按钮与请求等待进度(仅显示对话流程)
"""

import bpy
from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...operators.chat import ChatClear, ChatSend, ChatViewMessage
from ...preference import get_prefs
from ..lists.chat import CH_AI_UL_chat


@reg_order(2)
class AiChatPanel(Panel):
    """AI 纯文本对话面板"""

    bl_label = "AI Chat"
    bl_idname = "VIEW3D_PT_ch_ai_chat"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 与 AI 脚本面板共用的 "AI Assistant" 选项卡
    bl_category = "AI Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    # 消息列表显示行数
    _CHAT_ROWS = 6

    def draw(self, context: Context):
        state = context.window_manager.ch_ai_state
        layout = self.layout

        # 消息历史标题行; 右侧开关: 自动在文本编辑器打开所选消息与新回复
        row = layout.row()
        row.label(text="Messages", icon='COMMUNITY')
        row.prop(get_prefs(), "use_auto_open_chat", text="", icon='TEXT', toggle=True)

        # 消息历史(发送/回复即入列, 点击行按偏好转出到文本编辑器阅读)
        if len(state.chat_messages):
            layout.template_list(CH_AI_UL_chat.__name__, "ch_ai_chat", state, "chat_messages",
                                 state, "chat_active_index", rows=self._CHAT_ROWS)
            row = layout.row(align=True)
            row.operator(ChatViewMessage.bl_idname, icon='TEXT')
            row.operator(ChatClear.bl_idname, icon='X')
        else:
            layout.label(text="No messages yet", icon='INFO')

        # 输入框与发送
        col = layout.column(align=True)
        col.prop(state, "chat_input", text="Message")
        col.operator(ChatSend.bl_idname, icon='FORWARD')

        # 等待进度: 面板最下方, 只显示本面板的对话流程, 完成后自动消失
        if state.status and state.status_scope == 'chat':
            box = layout.box()
            row = box.row()
            row.label(text=state.status, icon='TIME')
            if state.wait_seconds > 0:
                row.label(text=f"{state.wait_seconds}s")
