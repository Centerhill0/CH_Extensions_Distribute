"""
AI 脚本生成器面板模块

提供以下功能:
- 需求输入与生成按钮
- 文本编辑器已有脚本列表(点击行按偏好聚焦编辑器, 运行/一键调试/删除)
- "自动打开脚本"开关(存于偏好设置): 生成/调试/修改产物与点击的脚本自动聚焦编辑器
- 最近一次运行错误摘要与清除按钮
"""

import bpy
from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import EditPrompt, GenerateScript
from ...operators.script_actions import (
    ClearError,
    DebugScript,
    DeleteScript,
    ReviseScript,
    RunScript,
)
from ...preference import get_prefs
from ...utils import AI_PROMPT_TEXT_NAME
from ..lists.scripts import CH_AI_UL_scripts


@reg_order(1)
class AiScriptPanel(Panel):
    """AI 脚本生成器面板"""

    bl_label = "AI Script Generator"
    bl_idname = "VIEW3D_PT_ch_ai_script"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 与 AI 对话面板共用的 "AI Assistant" 选项卡
    bl_category = "AI Assistant"

    # 错误摘要最多显示的 traceback 行数(取末尾异常段)
    _ERROR_LINES = 4

    def draw(self, context: Context):
        state = context.window_manager.ch_ai_state
        layout = self.layout

        # 描述输入: 单行快捷输入; 长文在文本编辑器编辑(单行为空时采用长文)
        col = layout.column(align=True)
        col.prop(state, "prompt", text="Prompt")
        prompt_text = bpy.data.texts.get(AI_PROMPT_TEXT_NAME)
        if not state.prompt.strip() and prompt_text is not None and prompt_text.as_string().strip():
            col.label(text="Using the long description from the text editor", icon='INFO')
        # 编辑描述与生成脚本同行
        row = col.row(align=True)
        row.operator(EditPrompt.bl_idname, icon='TEXT')
        row.operator(GenerateScript.bl_idname, icon='CONSOLE')

        # 脚本列表(快照由 handlers 实时刷新); 右侧开关: 自动在文本编辑器打开
        layout.separator()
        row = layout.row()
        row.label(text="Scripts", icon='TEXT')
        row.prop(get_prefs(), "use_auto_open_scripts", text="", icon='TEXT', toggle=True)
        if len(state.scripts):
            layout.template_list(CH_AI_UL_scripts.__name__, "ch_ai_scripts", state, "scripts",
                                 state, "scripts_active_index", rows=5)
            item = state.scripts[state.scripts_active_index]
            # 点击行即聚焦文本编辑器(scripts_active_index 的 update 回调), 无需打开按钮
            row = layout.row(align=True)
            op = row.operator(RunScript.bl_idname, text="Run", icon='PLAY')
            op.script_name = item.name
            op = row.operator(DebugScript.bl_idname, text="Debug", icon='ERROR')
            op.script_name = item.name
            op = row.operator(DeleteScript.bl_idname, text="", icon='X')
            op.script_name = item.name
            # 对话修改: 修改要求作用于当前高亮脚本, 写回原稿, 可迭代
            col = layout.column(align=True)
            col.prop(state, "revision", text="Change")
            op = col.operator(ReviseScript.bl_idname)
            op.script_name = item.name
        else:
            layout.label(text="No scripts yet", icon='INFO')

        # 最近错误摘要(末尾异常段), 右侧清除按钮; 拼接式标签经 iface() 自查翻译
        if state.last_error_traceback:
            box = layout.box()
            header = box.row()
            header.label(text=iface("Last error: {}").format(state.last_error_script), icon='ERROR')
            header.operator(ClearError.bl_idname, text="", icon='X')
            error_lines = state.last_error_traceback.strip().splitlines()
            for line in error_lines[-self._ERROR_LINES:]:
                box.label(text=line)

        # 等待进度: 面板最下方, 只显示本面板的流程(生成/调试/修改), 完成后自动消失
        if state.status and state.status_scope == 'script':
            box = layout.box()
            row = box.row()
            row.label(text=state.status, icon='TIME')
            if state.wait_seconds > 0:
                row.label(text=f"{state.wait_seconds}s")
