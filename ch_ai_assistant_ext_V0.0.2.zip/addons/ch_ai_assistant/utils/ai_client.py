"""
AI 服务客户端工具模块

OpenAI 兼容 chat 接口的单次请求, 生成/调试/修改消息组装与响应清洗.

主要功能:
- build_context_info: 场景上下文摘要(Blender 版本/场景/选中与活动物体)
- build_system_prompt: 按注释语言组装脚本周的系统提示词
- build_generation_messages: 脚本生成请求的消息组装
- build_debug_messages: 脚本调试请求的消息组装(原脚本 + 报错)
- build_revise_messages: 对话修改请求的消息组装(原脚本 + 修改要求, 变更行头附修改说明)
- build_chat_messages: 纯文本对话请求的消息组装(带最近历史)
- build_thinking_extras: 按服务商把思考级别映射为请求附加参数
- request_chat: urllib 单次 POST 请求(默认 60s 超时, 不自动重试)
- strip_code_fences: 剥掉响应中的 markdown 代码围栏
- validate_script: compile 语法校验
"""

import json
import re
import urllib.error
import urllib.request

import bpy
from bpy.types import Context

# 系统提示词: 要求模型先输出 script-name 命名行, 再输出完整可直接运行的 bpy 脚本;
# 注释语言由 build_system_prompt 按偏好拼接
_SYSTEM_PROMPT = (
    "You are a Blender scripting assistant for Blender 5.0. "
    "Write a complete, self-contained Python script using the bpy API. "
    "Your response must start with a single comment line in the exact form "
    "'# script-name: <short_name>.py', where <short_name> is a short snake_case name "
    "describing what the script does. After that line, output the complete script only: "
    "no explanations, no markdown code fences. "
    "The script must import bpy by itself and run directly in Blender's text editor. "
    "Prefer simple and robust code, with short comments for key steps."
)

# 注释语言指令: 按偏好键取用, 未知值回落英文
_COMMENT_LANGUAGE_DIRECTIVES = {
    'CHINESE': "Write all code comments in Chinese.",
    'ENGLISH': "Write all code comments in English.",
}

# 纯文本对话系统提示词: 不生成脚本文件, 按提问语言作答
_CHAT_SYSTEM_PROMPT = (
    "You are a helpful Blender assistant. "
    "Answer in plain text, concise and accurate. "
    "Reply in the same language as the user's message. "
    "Only include short code snippets when they are explicitly asked for."
)

# markdown 代码围栏(允许语言标注), 取围栏内部内容
_FENCE_RE = re.compile(r"```[a-zA-Z0-9_+-]*[ \t]*\r?\n(.*?)```", re.DOTALL)

# 响应首行命名行 '# script-name: xxx.py'
_NAME_LINE_RE = re.compile(r"^#\s*script-name:\s*(\S.*?)\s*$", re.IGNORECASE)

# 纯文本对话最多回带的历史消息条数(旧消息截断, 控制请求体大小)
_CHAT_HISTORY_LIMIT = 20

# 思考级别 -> 请求参数的映射: GLM 是 thinking.type 开关(无档位),
# OpenAI 兼容服务商是 reasoning_effort 档位; DeepSeek 由模型名决定, 不下发参数
_GLM_THINKING_TYPES = {'OFF': "disabled", 'LOW': "enabled", 'MEDIUM': "enabled", 'HIGH': "enabled"}
_OPENAI_REASONING_EFFORTS = {'LOW': "low", 'MEDIUM': "medium", 'HIGH': "high"}


def build_system_prompt(comment_language: str) -> str:
    """按注释语言组装脚本周系统提示词, 未知语言值回落英文"""
    directive = _COMMENT_LANGUAGE_DIRECTIVES.get(comment_language, _COMMENT_LANGUAGE_DIRECTIVES['ENGLISH'])
    return f"{_SYSTEM_PROMPT} {directive}"


def build_thinking_extras(provider: str, thinking: str) -> dict:
    """按服务商把思考级别转换为请求附加参数, 不支持或 DEFAULT 时返回空 dict"""
    if thinking == 'DEFAULT':
        return {}
    if provider == 'GLM':
        thinking_type = _GLM_THINKING_TYPES.get(thinking)
        return {"thinking": {"type": thinking_type}} if thinking_type else {}
    effort = _OPENAI_REASONING_EFFORTS.get(thinking)
    return {"reasoning_effort": effort} if effort else {}


def _sanitize_script_name(raw: str) -> str | None:
    """清洗模型给出的脚本名: 非法字符转下划线, 限长, 保证 .py 后缀; 无效返回 None"""
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", raw.removesuffix(".py").strip())
    stem = stem.strip("_")
    if not stem:
        return None
    return f"{stem[:32]}.py"


def extract_script_name(text: str) -> tuple:
    """剥离并解析首行 '# script-name: xxx' 命名行, 返回 (清洗后的脚本名或 None, 其余文本)"""
    lines = text.split("\n", 1)
    match = _NAME_LINE_RE.match(lines[0].strip()) if lines else None
    if not match:
        return None, text
    name = _sanitize_script_name(match.group(1))
    rest = lines[1] if len(lines) > 1 else ""
    return name, rest.lstrip("\r\n")


def build_context_info(context: Context) -> tuple:
    """汇总场景上下文摘要, 返回 (摘要文本, 错误信息)"""
    sel_names = ", ".join(obj.name for obj in context.selected_objects)
    act_obj = context.active_object
    lines = [
        f"Blender version: {bpy.app.version_string}",
        f"Scene: {context.scene.name}",
        f"Objects in scene: {len(context.scene.objects)}",
        f"Selected objects ({len(context.selected_objects)}): {sel_names or 'None'}",
        f"Active object: {act_obj.name if act_obj else 'None'}",
    ]
    return "\n".join(lines), None


def build_generation_messages(prompt: str, context_info: str | None, comment_language: str = 'ENGLISH') -> tuple:
    """组装脚本生成请求的消息列表, 返回 (messages, 错误信息)"""
    content = prompt if context_info is None else f"{prompt}\n\n--- Scene context ---\n{context_info}"
    messages = [
        {"role": "system", "content": build_system_prompt(comment_language)},
        {"role": "user", "content": content},
    ]
    return messages, None


def build_debug_messages(script: str, error_text: str, context_info: str | None,
                         comment_language: str = 'ENGLISH') -> tuple:
    """组装脚本调试请求的消息列表(原脚本 + 报错 + 可选上下文), 返回 (messages, 错误信息)"""
    content = (
        "The Blender Python script below failed. "
        "Find the bug and output ONLY the corrected complete script: "
        "no explanations, no markdown code fences.\n\n"
        f"--- Script ---\n{script}\n\n"
        f"--- Error ---\n{error_text}"
    )
    if context_info:
        content += f"\n\n--- Scene context ---\n{context_info}"
    messages = [
        {"role": "system", "content": build_system_prompt(comment_language)},
        {"role": "user", "content": content},
    ]
    return messages, None


def build_revise_messages(script: str, request: str, context_info: str | None,
                          comment_language: str = 'ENGLISH') -> tuple:
    """组装对话修改请求的消息列表(当前脚本 + 修改要求 + 可选上下文), 返回 (messages, 错误信息)

    要求模型在每个修改/新增的行或块头部写一条简短 '# Changed: ...' 说明,
    便于一眼看出改了哪里; 说明语言跟随系统提示词的注释语言指令.
    """
    content = (
        "Modify the Blender Python script below according to the modification request. "
        "For every modified or added line or block, put a brief comment at its head "
        "in the form '# Changed: what was modified', so the changes can be spotted at a glance. "
        "Output ONLY the name line and the complete modified script: "
        "no explanations, no markdown code fences.\n\n"
        f"--- Script ---\n{script}\n\n"
        f"--- Modification request ---\n{request}"
    )
    if context_info:
        content += f"\n\n--- Scene context ---\n{context_info}"
    messages = [
        {"role": "system", "content": build_system_prompt(comment_language)},
        {"role": "user", "content": content},
    ]
    return messages, None


def build_chat_messages(history: list, message: str) -> tuple:
    """组装纯文本对话请求的消息列表, 返回 (messages, 错误信息)

    history 为 (role, content) 元组列表, role 取 'user'/'assistant';
    超出条数上限的旧消息截断, 新消息始终保留.
    """
    messages = [{"role": "system", "content": _CHAT_SYSTEM_PROMPT}]
    for role, content in history[-_CHAT_HISTORY_LIMIT:]:
        messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": message})
    return messages, None


def request_chat(base_url: str, api_key: str, model: str, temperature: float, timeout: int, messages: list,
                 provider: str = 'CUSTOM', thinking: str = 'DEFAULT') -> tuple:
    """单次请求 OpenAI 兼容 chat 接口, 不自动重试; 返回 (回复文本, 错误信息)

    provider 与 thinking 用于按服务商拼接思考级别附加参数, 见 build_thinking_extras.
    """
    url = base_url.rstrip('/') + "/chat/completions"
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
    }
    payload.update(build_thinking_extras(provider, thinking))
    body = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return None, f"HTTP {e.code} {e.reason}"
    except urllib.error.URLError as e:
        return None, f"Request failed: {e.reason}"
    except json.JSONDecodeError:
        return None, "API returned invalid JSON"

    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        return None, "Unexpected API response format"
    if not isinstance(content, str) or not content.strip():
        return None, "API returned empty content"
    return content, None


def strip_code_fences(text: str) -> str:
    """剥掉 markdown 代码围栏; 有围栏取围栏内容(多块拼接), 无围栏取原文收尾去白"""
    blocks = [block.strip() for block in _FENCE_RE.findall(text) if block.strip()]
    if blocks:
        return "\n\n".join(blocks)
    return text.strip()


def validate_script(code: str) -> tuple:
    """语法校验脚本文本, 返回 (compile 产物或 None, 语法错误信息或 None)"""
    try:
        return compile(code, "<ai_script>", 'exec'), None
    except SyntaxError as e:
        return None, f"SyntaxError: line {e.lineno}: {e.msg}"
