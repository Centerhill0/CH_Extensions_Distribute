"""
utils 公共 API 汇聚

各子模块的公共函数在此显式具名再导出, 作为公共/内部边界的唯一声明点;
子模块不再声明模块级 __all__, 未列出的模块级名称视为内部协作 API.
"""

from .ai_client import (
    build_chat_messages,
    build_context_info,
    build_debug_messages,
    build_generation_messages,
    build_revise_messages,
    build_system_prompt,
    build_thinking_extras,
    extract_script_name,
    request_chat,
    strip_code_fences,
    validate_script,
)
from .script_io import (
    AI_CHAT_TEXT_NAME,
    AI_PROMPT_TEXT_NAME,
    ensure_unique_name,
    focus_text_editors,
    next_script_name,
    run_text_block,
    write_text_block,
)
