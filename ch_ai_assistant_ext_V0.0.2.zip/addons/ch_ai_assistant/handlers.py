"""
实时同步处理器模块

提供以下功能:
- sync_scripts_now: 脚本列表快照立即刷新(供脚本写入后调用)
- activate_script: 生成/调试写回后同步快照, 按偏好把列表高亮与文本编辑器指向该脚本
- 脚本/对话列表活跃索引 update 回调: 用户点击列表行时按偏好把该条目送入文本编辑器
- open_chat_message: 按偏好把当前高亮对话消息转出到 AI_Chat.txt 并聚焦文本编辑器
- load_post 处理器: 快照存于 WM 跨文件保留, 载入后立即对齐
- 周期计时器: 兜底刷新(文本块增删改不触发 depsgraph)
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接
- 快照重建与重入护栏机制见 common.ui.list_snapshot
"""

import bpy
from bpy.types import Context

from ...common.ui.list_snapshot import is_syncing, rebuild_if_changed
from .preference import get_prefs
from .utils import AI_CHAT_TEXT_NAME, AI_PROMPT_TEXT_NAME, focus_text_editors, write_text_block

# 脚本列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0


def _script_names() -> list:
    """全部文本块名(排除 AI 长文描述块与对话查看块, 它们不是脚本)"""
    return [t.name for t in bpy.data.texts
            if t.name not in (AI_PROMPT_TEXT_NAME, AI_CHAT_TEXT_NAME)]


def sync_scripts_now():
    """立即重建脚本列表快照(生成/调试写入文本块后调用, 不等计时器节拍)"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())


def activate_script(context: Context, name: str):
    """生成/调试写回后: 同步快照, 按偏好把列表高亮与文本编辑器活动文本指向该脚本

    高亮经活跃索引 update 回调联动聚焦, 与手动点击行为一致.
    """
    state = context.window_manager.ch_ai_state
    sync_scripts_now()
    if get_prefs().use_auto_open_scripts:
        text = bpy.data.texts.get(name)
        if text is not None:
            focus_text_editors(context, text)
    for idx, item in enumerate(state.scripts):
        if item.name == name:
            setattr(state, "scripts_active_index", idx)
            return


def on_scripts_index_update(self, context: Context):
    """脚本列表活跃索引回调: 开关开启时, 用户点击行把文本编辑器聚焦到该脚本"""
    if not get_prefs().use_auto_open_scripts:
        return
    if is_syncing() or self.scripts_active_index >= len(self.scripts):
        return
    text = bpy.data.texts.get(self.scripts[self.scripts_active_index].name)
    if text is not None:
        focus_text_editors(context, text)


def open_chat_message(context: Context, state):
    """按偏好把当前高亮对话消息写入 AI_Chat.txt 并聚焦文本编辑器

    供对话活跃索引 update 回调(点击列表行)与回复写入后的联动调用;
    转出后完整内容在文本编辑器阅读, 列表行内仅显示首行.
    """
    if not get_prefs().use_auto_open_chat:
        return
    idx = state.chat_active_index
    if idx >= len(state.chat_messages):
        return
    text, _ = write_text_block(AI_CHAT_TEXT_NAME, state.chat_messages[idx].content)
    focus_text_editors(context, text)


def on_chat_index_update(self, context: Context):
    """对话消息活跃索引回调: 开关开启时, 用户点击行把该消息转出到文本编辑器"""
    open_chat_message(context, self)


# ------------------------------------------------------------
# 文件 -> 列表同步
# ------------------------------------------------------------


def _sync_scripts():
    """全量同步: 有变化才重建脚本列表快照"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())


def _on_load_post(*_args):
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐"""
    try:
        _sync_scripts()
    except (ReferenceError, AttributeError):
        pass


def _sync_timer():
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_scripts()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register():
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister():
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
