"""
状态属性模块

提供以下功能:
- WM 级状态属性组: 脚本列表快照, AI 输入/最近错误记录与纯文本对话消息
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.ui.list_snapshot
"""

from bpy.props import CollectionProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import PropertyGroup

from ...common.ui.list_snapshot import ListItem
from .handlers import on_chat_index_update, on_scripts_index_update

# 对话消息角色条目("User"为 Blender 系统词条, 不入插件词典)
_CHAT_ROLE_ITEMS = [
    ('USER', "User", ""),
    ('ASSISTANT', "AI", ""),
]


class ChatMessage(PropertyGroup):
    """单条对话消息: 角色与纯文本内容"""
    role: EnumProperty(name="Role", items=_CHAT_ROLE_ITEMS, default='USER')  # type: ignore
    content: StringProperty(name="Content")  # type: ignore


class AiAssistantState(PropertyGroup):
    """AI 助手状态: 脚本列表快照与活跃索引, 描述输入, 等待进度与最近一次运行错误记录, 纯文本对话"""
    scripts: CollectionProperty(type=ListItem)  # type: ignore
    scripts_active_index: IntProperty(default=0, update=on_scripts_index_update)  # type: ignore
    prompt: StringProperty(
        name="Prompt",
        description="Describe the script you need",
    )  # type: ignore
    # 请求等待期间的面板进度文案(完成后清空)
    status: StringProperty()  # type: ignore
    # 运行中请求所属面板('script'/'chat'), 各面板只显示自己的进度(完成后清空)
    status_scope: StringProperty()  # type: ignore
    # 已等待秒数
    wait_seconds: IntProperty()  # type: ignore
    # 对话修改要求(作用于脚本列表当前高亮脚本)
    revision: StringProperty(
        name="Revision",
        description="Describe what to change in the active script",
    )  # type: ignore
    last_error_script: StringProperty()  # type: ignore
    last_error_traceback: StringProperty()  # type: ignore
    # 纯文本对话: 消息历史, 当前高亮消息(点击行按偏好转出文本编辑器)与输入框(存于 WM, 不随 .blend 保存)
    chat_messages: CollectionProperty(type=ChatMessage)  # type: ignore
    chat_active_index: IntProperty(default=0, update=on_chat_index_update)  # type: ignore
    chat_input: StringProperty(
        name="Message",
        description="What to ask the AI in plain text",
    )  # type: ignore
