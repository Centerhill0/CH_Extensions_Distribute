from ....common.i18n.dictionary import preprocess_dictionary

# 翻译条目按对应 Operator 的分块注释归类:
# Operator 标签用 ("Operator", "English text"), 通用文本与 report 消息用 ("*", "English text")
dictionary = {
    "zh_HANS": {
        # AiAssistantPreferences
        ("*", "AI Service"): "AI 服务",
        ("*", "Provider"): "服务商",
        ("*", "API Base URL"): "API 地址",
        ("*", "API Key"): "API 密钥",
        ("*", "Model"): "模型",
        ("*", "Timeout"): "超时",
        ("*", "Sampling Temperature"): "采样温度",
        ("*", "Sampling randomness: 0 is the most deterministic, higher is more creative. 0-0.3 recommended for scripts"): "采样随机度: 0 最确定, 越高越有创造性. 脚本生成建议 0-0.3",
        ("*", "Include Scene Context"): "附带场景上下文",
        ("*", "Send Blender version and selection info with AI requests"): "AI 请求附带 Blender 版本与选中物体信息",
        ("*", "Request timeout in seconds"): "单次请求超时秒数",
        ("*", "OpenAI-compatible API endpoint, e.g. https://api.deepseek.com"): "OpenAI 兼容接口地址, 如 https://api.deepseek.com",
        ("*", "Secret key of the AI service, stored locally in Blender preferences"): "AI 服务密钥, 仅保存在本机 Blender 偏好设置中",
        ("*", "Chat model name, e.g. deepseek-chat"): "对话模型名称, 如 deepseek-chat",
        ("*", "DeepSeek OpenAI-compatible API"): "DeepSeek 的 OpenAI 兼容接口",
        ("*", "Zhipu AI OpenAI-compatible API"): "智谱 AI 的 OpenAI 兼容接口",
        ("*", "Official OpenAI API"): "OpenAI 官方接口",
        ("*", "Manually fill in base URL and model"): "手动填写接口地址与模型",
        # 侧栏选项卡与 AI 对话面板标题("AI Script Generator" 在下方 AiScriptPanel 块)
        ("*", "AI Assistant"): "AI助手",
        ("*", "AI Chat"): "AI 对话",
        # 思考级别与注释语言("Default/Low/Medium/High/Off"为系统词条, 不入典)
        ("*", "Thinking Level"): "思考级别",
        ("*", "Model thinking level: sent as the provider's thinking parameter when supported, ignored otherwise"): "模型思考级别: 服务商支持时按其参数下发, 否则忽略",
        ("*", "Use the service default, no thinking parameter is sent"): "使用服务商默认行为, 不发送思考参数",
        ("*", "Explicitly disable thinking, supported by Zhipu GLM"): "明确关闭思考, 智谱 GLM 支持",
        ("*", "Low reasoning effort, supported by OpenAI-compatible reasoning models"): "低推理强度, OpenAI 兼容推理模型支持",
        ("*", "Medium reasoning effort, supported by OpenAI-compatible reasoning models"): "中推理强度, OpenAI 兼容推理模型支持",
        ("*", "High reasoning effort, supported by OpenAI-compatible reasoning models"): "高推理强度, OpenAI 兼容推理模型支持",
        ("*", "Comment Language"): "注释语言",
        ("*", "Language of the comments written in generated and modified scripts"): "生成与修改脚本中的注释语言",
        ("*", "Chinese"): "中文",
        ("*", "English"): "英文",
        ("*", "Write script comments in Chinese"): "脚本注释使用中文",
        ("*", "Write script comments in English"): "脚本注释使用英文",
        # 编辑器联动开关("Editor"为系统词条, 不入典)
        ("*", "Auto Open Scripts"): "自动打开脚本",
        ("*", "Show generated, debugged and revised scripts, and the script clicked in the list, in the text editor automatically"): "生成/调试/修改的脚本与列表中点击的脚本自动在文本编辑器中打开",
        ("*", "Auto Open Chat"): "自动打开对话",
        ("*", "Show the chat message clicked in the list and new replies in the text editor automatically"): "列表中点击的对话消息与新的回复自动在文本编辑器中打开",
        ("*", "Messages"): "消息",
        # AiScriptPanel
        ("*", "AI Script Generator"): "AI 脚本生成器",
        ("*", "Scripts"): "脚本",
        ("*", "Revision"): "修改要求",
        ("*", "Describe what to change in the active script"): "描述要对当前脚本做的修改",
        ("*", "Edit Description"): "编辑描述",
        ("Operator", "Edit Description"): "编辑描述",
        ("*", "Edit a multi-line description in the text editor, used when the inline prompt is empty"): "在文本编辑器中编辑多行长描述, 单行描述为空时生成请求将采用它",
        ("*", "Using the long description from the text editor"): "将采用文本编辑器中的长文描述",
        ("*", "No text editor area open, switch an area to the text editor first"): "没有打开的文本编辑器区域, 请先把一个区域切换为文本编辑器",
        ("*", "No scripts yet"): "暂无脚本",
        ("*", "Run"): "运行",
        # UILayout.operator(text=) 走 Operator 语境(rna_ui_api.cc), 与上一条 "*" 并存
        ("Operator", "Run"): "运行",
        # 状态属性
        ("*", "Describe the script you need"): "描述你需要的脚本",
        # 等待进度
        ("*", "Waiting for AI response... (Esc to cancel)"): "等待 AI 响应... (Esc 取消)",
        ("*", "Generating script... (Esc to cancel)"): "正在生成脚本... (Esc 取消)",
        ("*", "Debugging script with AI... (Esc to cancel)"): "正在 AI 调试脚本... (Esc 取消)",
        ("*", "Revising script with AI... (Esc to cancel)"): "正在 AI 修改脚本... (Esc 取消)",
        ("*", "Chatting with AI... (Esc to cancel)"): "正在 AI 对话... (Esc 取消)",
        ("*", "Type what to change in the revision field first"): "请先在修改要求中输入要改动的内容",
        # 对话模块
        ("*", "No messages yet"): "暂无消息",
        ("*", "What to ask the AI in plain text"): "以纯文本向 AI 提问的内容",
        ("Operator", "Send Message"): "发送消息",
        ("*", "Send the message to the AI service and append the reply to the conversation"): "把消息发给 AI 服务, 回复追加到对话",
        ("Operator", "View Message"): "查看消息",
        ("*", "Open the selected message in the text editor to read long replies"): "在文本编辑器中打开所选消息, 便于阅读长回复",
        ("Operator", "Clear Chat"): "清空对话",
        ("*", "Delete the whole chat history"): "清空全部对话消息历史",
        ("*", "Type a message first"): "请先输入消息内容",
        ("*", "No message selected"): "未选择消息",
        ("*", "An AI request is already running, wait for it to finish first"): "已有 AI 请求在进行中, 请等待其完成",
        # 算子悬停描述(bl_description)
        ("*", "Ask the AI service to write a script and put it in the text editor"): "让 AI 服务编写脚本并放入文本编辑器",
        ("*", "Run the selected script and capture its error"): "运行所选脚本并捕获其错误",
        ("*", "Send the script and its error to the AI service and fix it in place"): "把脚本与报错发给 AI 服务, 修复稿写回原脚本",
        ("*", "Send the script and your change request to the AI service and update it in place"): "把脚本与修改要求发给 AI 服务, 修改稿写回原脚本",
        ("*", "Delete the selected script from the blend file"): "从 blend 文件中删除所选脚本",
        ("*", "Clear the last captured error"): "清除最近一次捕获的错误",
        # AiScriptPanel(f-string 标签经 iface() 拆模板)
        ("*", "Last error: {}"): "最近错误: {}",
        # GenerateScript
        ("Operator", "Generate Script"): "生成脚本",
        ("*", "Type what script you need in the prompt field or the long description text first"): "请先在描述框输入需求, 或在文本编辑器的长文描述中编写",
        ("*", "Set API base URL and key in addon preferences first"): "请先在插件偏好设置中填写 API 地址与密钥",
        ("*", "Online access is disabled, allow it in Blender system preferences"): "Blender 未开启联网权限, 请在系统偏好设置中允许联网",
        ("*", "AI request cancelled, the background request is abandoned"): "已取消等待, 后台请求已放弃",
        ("*", "Script saved but has syntax errors: {}"): "脚本已保存但存在语法错误: {}",
        ("*", "Script '{}' created in the text editor"): "脚本 '{}' 已创建到文本编辑器",
        # RunScript
        ("*", "Script ran without errors"): "脚本运行成功, 无错误",
        ("*", "Script no longer exists"): "脚本已不存在",
        ("*", "Script failed: {}"): "脚本运行失败: {}",
        # DebugScript
        ("Operator", "Debug Script"): "调试脚本",
        ("*", "Script runs without errors, nothing to debug"): "脚本运行正常, 无需调试",
        ("*", "Fix has syntax errors, written back to '{}'"): "修复稿存在语法错误, 已写回 '{}'",
        ("*", "Fix written back to '{}', review and run it"): "修复稿已写回 '{}', 请检查后运行",
        # ReviseScript
        ("Operator", "Revise Script"): "修改脚本",
        ("*", "Revision has syntax errors, written back to '{}'"): "修改稿存在语法错误, 已写回 '{}'",
        ("*", "Revision written back to '{}', review and run it"): "修改稿已写回 '{}', 请检查后运行",
        # DeleteScript
        ("Operator", "Delete Script"): "删除脚本",
        ("*", "Script '{}' deleted"): "脚本 '{}' 已删除",
        # ClearError
        ("Operator", "Clear Error"): "清除错误",
    }
}

dictionary = preprocess_dictionary(dictionary)
