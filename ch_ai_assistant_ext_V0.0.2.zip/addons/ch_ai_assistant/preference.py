"""
偏好设置模块

提供以下功能:
- AI 服务接入配置: 服务商预设(DeepSeek/智谱/OpenAI/自定义), API 地址, 密钥, 模型, 温度, 超时
- 生成参数: 模型思考级别(按服务商映射为对应请求参数), 脚本注释语言
- AI 请求附带场景上下文的开关
- 编辑器联动: 自动在文本编辑器打开脚本产物/对话消息的开关(面板内亦有快捷开关)
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Context

from .config import __addon_name__

# 服务商预设: 条目标识 -> (base_url, 默认模型); CUSTOM 不回填, 由用户手动填写
_PRESETS = {
    'DEEPSEEK': ("https://api.deepseek.com", "deepseek-chat"),
    'GLM': ("https://open.bigmodel.cn/api/paas/v4", "glm-4.6"),
    'OPENAI': ("https://api.openai.com/v1", "gpt-4o"),
}

provider_items = [
    ('DEEPSEEK', "DeepSeek", "DeepSeek OpenAI-compatible API"),
    ('GLM', "Zhipu GLM", "Zhipu AI OpenAI-compatible API"),
    ('OPENAI', "OpenAI", "Official OpenAI API"),
    ('CUSTOM', "Custom", "Manually fill in base URL and model"),
]

# 思考级别条目: OFF/GLM 是开关式, LOW/MEDIUM/HIGH 是 OpenAI reasoning_effort 档位, 映射见 utils.ai_client
thinking_items = [
    ('DEFAULT', "Default", "Use the service default, no thinking parameter is sent"),
    ('OFF', "Off", "Explicitly disable thinking, supported by Zhipu GLM"),
    ('LOW', "Low", "Low reasoning effort, supported by OpenAI-compatible reasoning models"),
    ('MEDIUM', "Medium", "Medium reasoning effort, supported by OpenAI-compatible reasoning models"),
    ('HIGH', "High", "High reasoning effort, supported by OpenAI-compatible reasoning models"),
]

comment_language_items = [
    ('CHINESE', "Chinese", "Write script comments in Chinese"),
    ('ENGLISH', "English", "Write script comments in English"),
]


def _apply_preset(self, _context):
    """切换服务商预设时回填 API 地址与模型"""
    preset = _PRESETS.get(self.provider)
    if preset is not None:
        self.base_url, self.model = preset


class AiAssistantPreferences(AddonPreferences):
    """AI 助手偏好设置"""

    # 必须与 __addon_name__ 一致, Blender 据此定位偏好面板
    bl_idname = __addon_name__

    provider: EnumProperty(name="Provider", items=provider_items, default='DEEPSEEK', update=_apply_preset)  # type: ignore
    # OpenAI 兼容接口基地址, 请求时拼接 /chat/completions
    base_url: StringProperty(
        name="API Base URL",
        description="OpenAI-compatible API endpoint, e.g. https://api.deepseek.com",
        default="https://api.deepseek.com",
    )  # type: ignore
    api_key: StringProperty(
        name="API Key",
        description="Secret key of the AI service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    model: StringProperty(
        name="Model",
        description="Chat model name, e.g. deepseek-chat",
        default="deepseek-chat",
    )  # type: ignore
    temperature: FloatProperty(
        # 用 "Sampling Temperature" 而非常见词 "Temperature": 避开 Blender 自带翻译对常见词的遮蔽
        name="Sampling Temperature",
        description="Sampling randomness: 0 is the most deterministic, higher is more creative. 0-0.3 recommended for scripts",
        default=0.0,
        min=0.0,
        max=2.0,
        precision=1,
    )  # type: ignore
    thinking: EnumProperty(
        name="Thinking Level",
        description="Model thinking level: sent as the provider's thinking parameter when supported, ignored otherwise",
        items=thinking_items,
        default='DEFAULT',
    )  # type: ignore
    comment_language: EnumProperty(
        name="Comment Language",
        description="Language of the comments written in generated and modified scripts",
        items=comment_language_items,
        default='CHINESE',
    )  # type: ignore
    # 单次请求超时秒数, 请求失败不自动重试
    timeout: IntProperty(name="Timeout", description="Request timeout in seconds", default=60, min=5, max=600)  # type: ignore
    use_context: BoolProperty(
        name="Include Scene Context",
        description="Send Blender version and selection info with AI requests",
        default=True,
    )  # type: ignore
    # 编辑器联动开关(侧栏面板内亦有快捷开关): 是否自动把产物/所选条目送入文本编辑器
    use_auto_open_scripts: BoolProperty(
        name="Auto Open Scripts",
        description="Show generated, debugged and revised scripts, and the script clicked in the list, in the text editor automatically",
        default=True,
    )  # type: ignore
    use_auto_open_chat: BoolProperty(
        name="Auto Open Chat",
        description="Show the chat message clicked in the list and new replies in the text editor automatically",
        default=True,
    )  # type: ignore

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.alignment = 'CENTER'

        # 左右两列: 左侧 AI 服务接入, 右侧 生成参数与编辑器联动
        split = layout.split()
        col_left = split.column()
        col_right = split.column()

        box = col_left.box()
        box.label(text="AI Service", icon="PREFERENCES")
        box.prop(self, "provider")
        box.prop(self, "base_url")
        box.prop(self, "api_key")
        box.prop(self, "model")

        box = col_right.box()
        box.label(text="Generation", icon="SETTINGS")
        box.prop(self, "temperature")
        box.prop(self, "thinking")
        box.prop(self, "comment_language")
        box.prop(self, "timeout")
        box.prop(self, "use_context")

        box = col_right.box()
        box.label(text="Editor", icon="TEXT")
        box.prop(self, "use_auto_open_scripts")
        box.prop(self, "use_auto_open_chat")


def get_prefs() -> AiAssistantPreferences:
    """获取插件偏好设置实例"""
    return bpy.context.preferences.addons[__addon_name__].preferences
