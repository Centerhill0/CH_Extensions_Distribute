"""
纯文本对话操作模块

与 AI 服务进行纯文本问答, 不生成/修改脚本, 不附带场景上下文.

操作流程:
1. 发送消息: 输入框内容入列消息历史, 连同最近历史(上限截断)送 AI, 回复追加到消息历史;
   请求启动失败时回退刚入列的用户消息
2. 查看消息: 把当前高亮消息转出到文本编辑器专用文本块, 便于阅读长回复
3. 清空对话: 清空全部消息历史
"""

import bpy
from bpy.types import Context, Event, Operator

from ..utils import (
    AI_CHAT_TEXT_NAME,
    build_chat_messages,
    focus_text_editors,
    write_text_block,
)
from .ai_generate import AiRequestMixin


class ChatSend(Operator, AiRequestMixin):
    """
    发送对话消息操作器

    功能: 把输入框消息与最近对话历史发给 AI 服务,
    回复追加到消息历史, 输入框随即清空.
    """

    bl_idname = "ch_ai.chat_send"
    bl_label = "Send Message"
    bl_description = "Send the message to the AI service and append the reply to the conversation"
    bl_options = {'REGISTER'}

    status_text = "Chatting with AI... (Esc to cancel)"
    # 进度显示在对话面板
    status_scope = 'chat'

    def invoke(self, context: Context, event: Event):
        message = context.window_manager.ch_ai_state.chat_input.strip()
        if not message:
            self.report({'WARNING'}, "Type a message first")
            return {'CANCELLED'}

        state = context.window_manager.ch_ai_state
        item = state.chat_messages.add()
        item.role = 'USER'
        item.content = message
        state.chat_active_index = len(state.chat_messages) - 1
        history = [("user" if m.role == 'USER' else "assistant", m.content)
                   for m in state.chat_messages[:-1]]
        messages, _ = build_chat_messages(history, message)
        if not self._start_request(context, messages):
            # 请求未启动: 回退刚才入列的用户消息
            state.chat_messages.remove(len(state.chat_messages) - 1)
            state.chat_active_index = max(0, len(state.chat_messages) - 1)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        state = context.window_manager.ch_ai_state
        item = state.chat_messages.add()
        item.role = 'ASSISTANT'
        item.content = content
        state.chat_active_index = len(state.chat_messages) - 1
        state.chat_input = ""
        return {'FINISHED'}


class ChatViewMessage(Operator):
    """
    查看对话消息操作器

    功能: 把当前高亮消息写入对话专用文本块并聚焦文本编辑器,
    便于阅读被列表截断的长回复.
    """

    bl_idname = "ch_ai.chat_view_message"
    bl_label = "View Message"
    bl_description = "Open the selected message in the text editor to read long replies"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        if state.chat_active_index >= len(state.chat_messages):
            self.report({'WARNING'}, "No message selected")
            return {'CANCELLED'}
        content = state.chat_messages[state.chat_active_index].content
        text, _ = write_text_block(AI_CHAT_TEXT_NAME, content)
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        return {'FINISHED'}


class ChatClear(Operator):
    """
    清空对话操作器

    功能: 清空全部对话消息历史(不可撤销).
    """

    bl_idname = "ch_ai.chat_clear"
    bl_label = "Clear Chat"
    bl_description = "Delete the whole chat history"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        state.chat_messages.clear()
        state.chat_active_index = 0
        return {'FINISHED'}
