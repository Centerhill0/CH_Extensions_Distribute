"""
AI 生成脚本操作模块

需求文本送 AI 服务生成 Blender 脚本, 产物写入文本编辑器并聚焦.

操作流程:
1. 描述来源: 单行输入框优先, 为空时取文本编辑器中的长文描述块
2. invoke: 校验描述与偏好配置, 组装消息(注释语言取偏好)后启动后台请求线程进入模态等待
3. modal: 计时器轮询线程结果并刷新面板等待进度, Esc 放弃等待(底层请求不中断, 结果丢弃)
4. 响应处理: 剥围栏 -> 解析 script-name 命名行(清洗/重名加序号, 缺失回落递增名)
   -> 语法校验 -> 写入文本编辑器 -> 高亮列表并聚焦
"""

import threading
import time

import bpy
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ..handlers import activate_script
from ..preference import get_prefs
from ..utils import (
    AI_PROMPT_TEXT_NAME,
    build_context_info,
    build_generation_messages,
    ensure_unique_name,
    extract_script_name,
    focus_text_editors,
    next_script_name,
    request_chat,
    strip_code_fences,
    validate_script,
    write_text_block,
)


def _resolve_prompt(context: Context) -> str:
    """生成用描述: 单行输入框优先, 为空时取长文描述块内容, 返回清洗后的文本"""
    prompt = context.window_manager.ch_ai_state.prompt.strip()
    if prompt:
        return prompt
    text = bpy.data.texts.get(AI_PROMPT_TEXT_NAME)
    if text is not None:
        return text.as_string().strip()
    return ""


def _request_worker(op, prefs, messages):
    """后台线程入口(op 模拟 self): 单次请求并把结果写入 op._result, 线程内兜底一切异常"""
    try:
        content, err = request_chat(
            prefs.base_url, prefs.api_key, prefs.model,
            prefs.temperature, prefs.timeout, messages,
            provider=prefs.provider, thinking=prefs.thinking,
        )
        op._result = (content, err)
    except Exception as e:
        op._result = (None, f"Request thread crashed: {e}")


class AiRequestMixin:
    """
    AI 请求模态等待 Mixin

    后台单次请求 + 计时器轮询模态等待: 状态栏提示等待中, Esc 放弃等待.
    子类在 invoke 中校验输入后调用 _start_request, 并实现 _on_response 处理响应.
    """

    # 等待期间的状态栏文案与进度作用域, 子类按场景覆盖
    status_text = "Waiting for AI response... (Esc to cancel)"
    # 进度所属面板作用域('script'/'chat'): 面板据此只显示自己的等待进度
    status_scope = 'script'

    _thread = None
    _timer = None
    _result = None

    def _start_request(self, context: Context, messages: list) -> bool:
        """校验配置并启动后台请求线程, 进入模态等待; 配置缺失或已有请求进行中时上报并返回 False"""
        ai_state = context.window_manager.ch_ai_state
        prefs = get_prefs()
        if not prefs.base_url or not prefs.api_key:
            self.report({'WARNING'}, "Set API base URL and key in addon preferences first")
            return False
        if not bpy.app.online_access:
            self.report({'WARNING'}, "Online access is disabled, allow it in Blender system preferences")
            return False
        if ai_state.status:
            self.report({'WARNING'}, "An AI request is already running, wait for it to finish first")
            return False

        self._thread = threading.Thread(
            target=_request_worker, args=(self, prefs, messages), daemon=True)
        self._result = None
        self._timer = None
        self._thread.start()

        ai_state.status = self.status_text
        ai_state.status_scope = self.status_scope
        ai_state.wait_seconds = 0
        self._start_monotonic = time.monotonic()
        context.workspace.status_text_set(self.status_text)
        self._timer = context.window_manager.event_timer_add(0.25, window=context.window)
        context.window_manager.modal_handler_add(self)
        if context.area is not None:
            context.area.tag_redraw()
        return True

    def modal(self, context: Context, event: Event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._finish_wait(context)
            self.report({'INFO'}, "AI request cancelled, the background request is abandoned")
            return {'CANCELLED'}
        if event.type == 'TIMER' and self._thread is not None and not self._thread.is_alive():
            content, err = self._result
            self._finish_wait(context)
            return self._on_response(context, content, err)
        if event.type == 'TIMER':
            # 等待中刷新已等待秒数与面板
            ai_state = context.window_manager.ch_ai_state
            ai_state.wait_seconds = int(time.monotonic() - self._start_monotonic)
            if context.area is not None:
                context.area.tag_redraw()
        return {'PASS_THROUGH'}

    def _finish_wait(self, context: Context):
        """结束等待: 移除计时器, 清空状态栏与面板进度"""
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.workspace.status_text_set(None)
        ai_state = context.window_manager.ch_ai_state
        ai_state.status = ""
        ai_state.status_scope = ""
        ai_state.wait_seconds = 0
        if context.area is not None:
            context.area.tag_redraw()

    def _on_response(self, context: Context, content, err):
        """响应处理钩子, 子类必须实现并返回结果集"""
        raise NotImplementedError


class GenerateScript(Operator, AiRequestMixin):
    """
    生成脚本操作器

    功能: 把需求文本与可选场景上下文发给 AI 服务,
    产物清洗校验后写入文本编辑器新建脚本块并聚焦, 不自动执行.
    """

    bl_idname = "ch_ai.generate_script"
    bl_label = "Generate Script"
    bl_description = "Ask the AI service to write a script and put it in the text editor"
    bl_options = {'REGISTER'}

    status_text = "Generating script... (Esc to cancel)"

    def invoke(self, context: Context, event: Event):
        prompt = _resolve_prompt(context)
        if not prompt:
            self.report({'WARNING'}, "Type what script you need in the prompt field or the long description text first")
            return {'CANCELLED'}
        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_generation_messages(prompt, context_info, get_prefs().comment_language)
        if not self._start_request(context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        # 命名行可能在围栏外或围栏内首行, 两段各解析一次(幂等)
        name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        name_in_code, code = extract_script_name(code)
        if name_in_code is not None:
            name = name_in_code
        if name is None:
            name, _ = next_script_name()
        else:
            name = ensure_unique_name(name)
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(name, code)
        activate_script(context, name)
        if syntax_err is not None:
            self.report({'WARNING'}, report("Script saved but has syntax errors: {}").format(syntax_err))
        else:
            self.report({'INFO'}, report("Script '{}' created in the text editor").format(name))
        return {'FINISHED'}


class EditPrompt(Operator):
    """
    编辑描述操作器

    功能: 在文本编辑器中打开长文描述块(多行, 可自动换行),
    单行描述框为空时生成请求自动采用其内容.
    """

    bl_idname = "ch_ai.edit_prompt"
    bl_label = "Edit Description"
    bl_description = "Edit a multi-line description in the text editor, used when the inline prompt is empty"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        text = bpy.data.texts.get(AI_PROMPT_TEXT_NAME)
        if text is None:
            text = bpy.data.texts.new(AI_PROMPT_TEXT_NAME)
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        return {'FINISHED'}
