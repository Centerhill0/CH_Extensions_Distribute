"""
脚本操作模块

文本编辑器脚本的运行捕获, 一键 AI 调试, 对话修改, 删除与错误记录清理.

操作流程:
1. 运行脚本: 独立命名空间执行所选文本块, traceback 写入面板状态
2. 一键调试: 无该脚本已捕获错误时先代跑捕获, 脚本 + 报错送 AI, 修复稿写回原脚本并清错误记录
3. 对话修改: 脚本 + 修改要求送 AI, 修改稿写回原脚本, 修改/新增行头带简短修改说明;
   不满意可继续追加要求迭代(每次都以当前脚本为基准, 无需历史对话)
4. 删除脚本: 确认后删除文本块并同步列表快照
5. 清除错误: 清空面板的错误摘要
"""

import bpy
from bpy.props import StringProperty
from bpy.types import Context, Event, Operator, Text

from ....common.i18n.i18n import report
from ..handlers import activate_script, sync_scripts_now
from ..preference import get_prefs
from ..utils import (
    build_context_info,
    build_debug_messages,
    build_revise_messages,
    extract_script_name,
    run_text_block,
    strip_code_fences,
    validate_script,
    write_text_block,
)
from .ai_generate import AiRequestMixin


class RunScript(Operator):
    """
    运行脚本操作器

    功能: 在独立命名空间中执行所选文本块,
    traceback 写入面板状态, 供一键调试与错误摘要显示使用.
    """

    bl_idname = "ch_ai.run_script"
    bl_label = "Run Script"
    bl_description = "Run the selected script and capture its error"
    bl_options = {'REGISTER'}

    script_name: StringProperty()  # type: ignore

    def execute(self, context: Context):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        ok, error_text = run_text_block(text.as_string(), text.name)
        ai_state = context.window_manager.ch_ai_state
        ai_state.last_error_script = text.name
        ai_state.last_error_traceback = error_text or ""
        if ok:
            self.report({'INFO'}, "Script ran without errors")
        else:
            last_line = error_text.strip().splitlines()[-1]
            self.report({'ERROR'}, report("Script failed: {}").format(last_line))
        return {'FINISHED'}


class DebugScript(Operator, AiRequestMixin):
    """
    一键调试操作器

    功能: 该脚本无已捕获错误时先代跑捕获报错,
    再把脚本全文与报错发给 AI 服务, 修复稿直接写回原脚本并清错误记录.
    """

    bl_idname = "ch_ai.debug_script"
    bl_label = "Debug Script"
    bl_description = "Send the script and its error to the AI service and fix it in place"
    bl_options = {'REGISTER'}

    status_text = "Debugging script with AI... (Esc to cancel)"

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}

        ai_state = context.window_manager.ch_ai_state
        error_text = self._capture_error(text, ai_state)
        if error_text is None:
            self.report({'INFO'}, "Script runs without errors, nothing to debug")
            return {'CANCELLED'}

        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_debug_messages(
            text.as_string(), error_text, context_info, get_prefs().comment_language)
        if not self._start_request(context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _capture_error(self, text: Text, ai_state) -> str | None:
        """取该脚本的报错文本

        Args:
            text: 目标文本块
            ai_state: WM 级 AiState, 记录/复用已捕获的错误
        Returns:
            报错 traceback 文本; 脚本运行正常时返回 None
        """
        if ai_state.last_error_script == text.name and ai_state.last_error_traceback:
            return ai_state.last_error_traceback
        ok, captured = run_text_block(text.as_string(), text.name)
        ai_state.last_error_script = text.name
        ai_state.last_error_traceback = captured or ""
        if ok:
            return None
        return captured

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        # 修复稿写回原脚本, 不采用命名行(有则剥掉)
        _name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(self.script_name, code)
        activate_script(context, self.script_name)
        # 修复稿已写回, 旧报错不再成立
        ai_state = context.window_manager.ch_ai_state
        ai_state.last_error_script = ""
        ai_state.last_error_traceback = ""
        if syntax_err is not None:
            self.report({'WARNING'}, report("Fix has syntax errors, written back to '{}'").format(self.script_name))
        else:
            self.report({'INFO'}, report("Fix written back to '{}', review and run it").format(self.script_name))
        return {'FINISHED'}


class ReviseScript(Operator, AiRequestMixin):
    """
    对话修改脚本操作器

    功能: 把所选脚本全文与修改要求发给 AI 服务, 修改稿直接写回原脚本并清错误记录;
    效果不满意可继续追加修改要求迭代(每次都以当前脚本为基准).
    """

    bl_idname = "ch_ai.revise_script"
    bl_label = "Revise Script"
    bl_description = "Send the script and your change request to the AI service and update it in place"
    bl_options = {'REGISTER'}

    status_text = "Revising script with AI... (Esc to cancel)"

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        request = context.window_manager.ch_ai_state.revision.strip()
        if not request:
            self.report({'WARNING'}, "Type what to change in the revision field first")
            return {'CANCELLED'}

        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_revise_messages(
            text.as_string(), request, context_info, get_prefs().comment_language)
        if not self._start_request(context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        # 修改稿写回原脚本, 不采用命名行(有则剥掉)
        _name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(self.script_name, code)
        activate_script(context, self.script_name)
        # 写回后旧报错不再成立
        ai_state = context.window_manager.ch_ai_state
        ai_state.last_error_script = ""
        ai_state.last_error_traceback = ""
        if syntax_err is not None:
            self.report({'WARNING'}, report("Revision has syntax errors, written back to '{}'").format(self.script_name))
        else:
            self.report({'INFO'}, report("Revision written back to '{}', review and run it").format(self.script_name))
        return {'FINISHED'}


class DeleteScript(Operator):
    """
    删除脚本操作器

    功能: 确认后删除所选文本块并同步列表快照,
    错误记录指向它时一并清除(删除文本块不可撤销).
    """

    bl_idname = "ch_ai.delete_script"
    bl_label = "Delete Script"
    bl_description = "Delete the selected script from the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: Context):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        bpy.data.texts.remove(text)
        ai_state = context.window_manager.ch_ai_state
        if ai_state.last_error_script == self.script_name:
            ai_state.last_error_script = ""
            ai_state.last_error_traceback = ""
        sync_scripts_now()
        self.report({'INFO'}, report("Script '{}' deleted").format(self.script_name))
        return {'FINISHED'}


class ClearError(Operator):
    """
    清除错误记录操作器

    功能: 清空面板错误摘要(最近一次运行捕获的 traceback).
    """

    bl_idname = "ch_ai.clear_error"
    bl_label = "Clear Error"
    bl_description = "Clear the last captured error"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        ai_state = context.window_manager.ch_ai_state
        ai_state.last_error_script = ""
        ai_state.last_error_traceback = ""
        return {'FINISHED'}
