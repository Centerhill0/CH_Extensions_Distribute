import sys

# Purge stale submodules left over from the previous version when overwriting installation within the same session:
# after bl_pkg replaces files, the cleanup of sys.modules is incomplete, and residual submodules mix with new imports,
# causing "No module named ... / is not a package" errors when enabling. Only purge submodules under __name__,
# do not delete __name__ itself (deleting the wrapper currently being executed would cause recursive re-execution when inner relative
# imports look up the parent module); fresh start has no residue, this is an empty operation.
for _mod_name in [n for n in list(sys.modules) if n.startswith(__name__ + ".")]:
    del sys.modules[_mod_name]

from .addons.ch_ai_assistant import register as addon_register, unregister as addon_unregister

bl_info = {
    "name": 'CH AI Assistant',
    "author": 'Centerhill',
    "version": (0, 0, 2),
    "blender": (5, 1, 0),
    "description": 'AI script generator for the text editor',
    "category": '3D View'
}

def register():
    addon_register()

def unregister():
    addon_unregister()

    