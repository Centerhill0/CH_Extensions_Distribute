"""
脚本安全预检模块

对即将运行的脚本做运行前的危险调用扫描(纯函数, 不导入 bpy).
RunScript 在运行前调用 scan_dangerous: 命中高风险调用时弹确认框, 由用户决定是否继续,
避免 AI 生成/修改的脚本在误点时毁坏场景或数据.

扫描是"看调用名是否出现"的字面匹配, 不做 AST 分析: 误报(如在注释/字符串里提到)由用户在
确认框自行判断, 成本远低于漏报; 只有真正执行才会造成损害, 故只需在"运行前"这一处收口.
"""

import re

# 高风险调用: (匹配模式, 说明键) —— 说明为英文键, 由调用方经 iface()/词典翻译
_DANGEROUS = (
    (re.compile(r"\bquit_blender\b"), "quits Blender"),
    (re.compile(r"\bsave(?:_as)?_mainfile\b"), "overwrites the .blend file"),
    (re.compile(r"\bshutil\.rmtree\b"), "deletes a directory tree"),
    (re.compile(r"\bos\.(?:remove|unlink)\b"), "deletes a file"),
)


def scan_dangerous(code: str) -> list:
    """扫描脚本源码里的高风险调用, 按声明顺序返回命中的说明键列表(去重); 无命中返回空列表

    只做字面匹配(见模块说明); 空入参按无命中处理.
    """
    if not code:
        return []
    hits = []
    for pattern, label in _DANGEROUS:
        if label not in hits and pattern.search(code):
            hits.append(label)
    return hits
