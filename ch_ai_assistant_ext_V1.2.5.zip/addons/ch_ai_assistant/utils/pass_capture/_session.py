"""通道捕获会话: 按批驱动渲染, 逐批收集, 结束时回收临时环境"""

import bpy


from ..errors import api_error
from ..cryptomatte import decode_segmentation


from ._cache import group_render_key, lookup_group_cache, needed_groups, store_group_cache


from ._constants import (
    CRYPTO_SLOT_COUNT,
    CRYPTO_SLOT_KEYS,
    CRYPTO_SOURCE_ASSET,
    CRYPTO_SOURCE_DEFAULT,
    CRYPTO_SOURCE_MATERIAL,
    EDGE_PRESET_DEFAULT,
    GROUP_LINEART,
    PASS_ORDER,
    _EEVEE_SAMPLES,
    _SEG_UNMATCHED_WARN,
    _crypto_slots_used,
    _group_entries,
    drop_silently,
    set_attr_safe,
)


from ._lineart import _add_edge_gp, _remove_gp


from ._pixels import _collect_frame, _decode_raw, _encode_png, _read_crypto_slot


from ._scene import _build_capture_group, _copy_color_management, _copy_render_common, _drop_node_group, _eevee_engine_id, _enable_passes, _ensure_view_layers, _link_user_scene, _move_to_lineart_collection, _render_frame


from ._size import _render_size, _sane_clamp


from ._tmpdir import _drop_path, _new_tmp_dir, _sweep_tmp_root


class PassCaptureSession:
    """相机通道捕获会话(可按批驱动): open 建临时场景 -> render_next_frame 逐批渲染收集 -> close 回收

    供 CaptureViewRefs 的模态算子按批驱动(批与批之间让出主线程更新等待进度);
    capture_camera_passes 是一次性薄封装(open + 逐批 + close 一口气跑完, 供脚本与测试直调).
    批序列: 主组(合并结果/深度/法向/漫射颜色/AO, 用户世界; 勾选分割时附加 cryptomatte 各层)
    -> 线稿组(场景线条画); 未命中增量缓存的组才进批, 故常见情形只有一批, 甚至一批都不渲.
    单次渲染仍是同步阻塞的, 会话只把批与批之间交还给调用方.
    wanted 为通道键 -> 是否捕获; 其余参数与 capture_camera_passes 同名同义.
    """

    def __init__(
        self,
        scene,
        wanted: dict,
        *,
        ao_distance: float = 1.0,
        depth_near: float = 1.0,
        depth_far: float = 20.0,
        depth_curve: str = 'LINEAR',
        normal_convention: str = 'OPENGL',
        edge_width_scale: float = 1.0,
        material_borders: bool = False,
        edge_preset: str = EDGE_PRESET_DEFAULT,
        clamp_long_edge: int = 0,
        reuse_cache: bool = True,
        render_samples: int = _EEVEE_SAMPLES,
        crypto_source: str = CRYPTO_SOURCE_DEFAULT,
        crypto_slots: int = CRYPTO_SLOT_COUNT,
        smooth_seg_edges: bool = False,
    ):
        self._scene = scene
        self._reuse_cache = reuse_cache
        self._wanted = dict(wanted)
        self._ao_distance = ao_distance
        self._depth_near, self._depth_far = depth_near, depth_far
        self._depth_curve = depth_curve
        self._normal_convention = normal_convention
        self._edge_width_scale = edge_width_scale
        self._material_borders = material_borders
        self._edge_preset = edge_preset
        self._clamp_long_edge = _sane_clamp(clamp_long_edge)
        try:
            self._render_samples = max(1, int(render_samples))
        except (TypeError, ValueError):
            self._render_samples = _EEVEE_SAMPLES
        self._crypto_source = crypto_source
        self._crypto_slots = _crypto_slots_used(crypto_slots)
        # 解码参数(不进渲染键): 切换它只重解码, 不触发任何渲染
        self._smooth_seg_edges = bool(smooth_seg_edges)
        # 生命周期状态: 渲染批次定义(每批为该批要渲的组列表)与待渲染批次下标
        self._batches = []
        self._pending = []
        self._layers = {}
        # 增量缓存: 各组渲染键,命中缓存的组,本次真正渲过的组
        self._keys = {}
        self.reused_groups = []
        self._rendered_groups = []
        self.passes: dict = {}
        self.passes_raw: dict = {}
        self.notices: list = []
        self.size = None
        self._tmp = None
        self._ng = None
        self._gp = None
        self._lineart_col = None
        self._tmp_dir = None
        self._decode_kwargs = None
        self._opened = False
        self._closed = False

    def open(self):
        """建立临时场景与公共渲染设置, 返回错误信息(None 成功; 失败时已自行回收)"""
        if self._opened or self._closed:
            return api_error("The capture session has already been started")
        scene = self._scene
        if scene.camera is None:
            return api_error("The scene has no active camera")
        engine_id = _eevee_engine_id()
        if engine_id is None:
            return api_error("The EEVEE engine is not available in this build")
        try:
            # 两个阶段都在同一个 try 内: 任一步的意外异常都统一转成错误信息并自行回收
            self._prepare_environment(scene, engine_id)
            self._plan_batches(scene)
            self._opened = True
        except Exception as e:  # noqa: BLE001 - 建场任一步的意外异常统一转成错误信息
            self.close()
            return api_error("Failed to prepare the pass capture", e)
        return None

    def _prepare_environment(self, scene, engine_id: str) -> None:
        """建临时场景并备齐渲染公共项与解码参数(阶段一; 失败由 open 统一收回)

        顺序敏感: 临时目录 -> 临时场景 -> 关联用户集合/世界/相机 -> 渲染公共项与色彩管理
        -> 引擎与采样 -> 输出格式与分辨率 -> 深度背景(供深度通道映射).
        """
        _sweep_tmp_root()
        self._tmp_dir = _new_tmp_dir()
        tmp = bpy.data.scenes.new("CH_AI_PassCapture")
        self._tmp = tmp
        _link_user_scene(tmp, scene)
        tmp.world = scene.world
        tmp.camera = scene.camera
        _copy_render_common(tmp, scene, self._clamp_long_edge)
        _copy_color_management(tmp, scene)
        tmp.render.engine = engine_id
        # 引擎注册表无该属性时用默认采样(通道缺失/参数缺失一律不阻断捕获)
        set_attr_safe(tmp.eevee, "taa_render_samples", self._render_samples)
        tmp.render.image_settings.file_format = 'PNG'
        self.size = _render_size(tmp.render)
        depth_background = None
        cam_data = getattr(scene.camera, "data", None)
        if cam_data is not None and hasattr(cam_data, "clip_end"):
            depth_background = float(cam_data.clip_end)
        # 解码参数: 只有深度用区间/曲线, 只有法向用约定, 线稿只按 alpha 映射(其余通道直接取字节)
        self._decode_kwargs = dict(depth_near=self._depth_near, depth_far=self._depth_far, depth_curve=self._depth_curve, normal_convention=self._normal_convention, depth_background=depth_background)

    def _plan_batches(self, scene) -> None:
        """算渲染键, 复用命中的组, 把未命中的排进批次(阶段二)

        渲染批次: 每批一次渲染调用, 批内各视图层在同一次调用里各自落盘
        - 主组 + 线稿组: 两者的场景态互不干扰(蜡笔只进线稿组的集合), 故可同批
        - 线稿组: 需蜡笔对象与集合排除, 单独一批且该批只渲这一个视图层
        增量缓存: 先按组算渲染键, 命中的组直接复用原始字节(免渲染), 只把未命中的排进批次.
        """
        groups = needed_groups(self._wanted)
        self._keys = {
            group: group_render_key(
                group,
                scene,
                ao_distance=self._ao_distance,
                edge_width_scale=self._edge_width_scale,
                material_borders=self._material_borders,
                edge_preset=self._edge_preset,
                clamp_long_edge=self._clamp_long_edge,
                render_samples=self._render_samples,
                crypto_source=self._crypto_source,
                crypto_slots=self._crypto_slots,
            )
            for group in groups
        }
        reused = lookup_group_cache(self._keys, self._wanted, self._crypto_source, self._crypto_slots) if self._reuse_cache else {}
        for group, raw in reused.items():
            self.passes_raw.update(raw)
            self.notices.extend(_decode_collected(raw, _group_entries(group, self._wanted, self._crypto_source, self._crypto_slots), self.passes, self._decode_kwargs))
        self.reused_groups = sorted(reused)
        stale = [group for group in groups if group not in reused]
        # 未失效的组不进批次; 都失效时合成一批(多个视图层在同一次渲染调用里各自落盘)
        self._batches = [stale] if stale else []
        self._pending = list(range(len(self._batches)))

    def _prepare_batch(self, index: int) -> tuple:
        """准备第 index 批: 建所需视图层,按组开通道,装配该批特有的场景态

        返回 (视图层表, 是否跳过渲染). 视图层**按批按需创建** —— 场景里存在但本批不需要的
        视图层也会被 blend 一并渲染, 故跑主组那批时线稿视图层尚未建出来,
        从而不会被顺带渲染(线稿组只在它自己那一批创建).
        """
        tmp = self._tmp
        groups = self._batches[index]
        layers, self._lineart_col = _ensure_view_layers(tmp, groups, self._lineart_col)
        self._layers.update(layers)
        skip = False
        for group in groups:
            _enable_passes(layers[group], group, self._wanted, self._ao_distance, self._crypto_source)
            if group == GROUP_LINEART:
                self._gp, gp_notice = _add_edge_gp(tmp, self._edge_width_scale, self._material_borders, self._edge_preset)
                if gp_notice is not None:
                    # 蜡笔建不出来(编辑模式等)时跳过本批渲染, 只留提示
                    self.notices.append(gp_notice)
                    skip = True
                else:
                    _move_to_lineart_collection(self._lineart_col, self._gp)
        return layers, skip

    def render_next_frame(self) -> tuple:
        """渲染下一批并收集其通道, 返回 (本批新增提示, 错误信息, 是否全部完成)

        单次渲染内部同步阻塞; 错误时调用方应 close 放弃(已完成的批次不 commit).
        """
        if not self._opened or self._closed:
            return [], api_error("The capture session is not open"), True
        if not self._pending:
            return [], None, True
        index = self._pending.pop(0)
        tmp, tmp_dir = self._tmp, self._tmp_dir
        try:
            layers, skip = self._prepare_batch(index)
            groups = self._batches[index]
            if not skip:
                entries = tuple((layers[group], _group_entries(group, self._wanted, self._crypto_source, self._crypto_slots)) for group in groups)
                # 单组批用 layer= 精确限定视图层; 多组批此时场景里恰好只有这些视图层
                layer_name = layers[groups[0]].name if len(groups) == 1 else None
                self._ng, missing = _build_capture_group(tmp, tmp_dir, entries)
                self.notices.extend(msg for _, msg in missing)
                err = _render_frame(tmp, layers[groups[0]], tmp_dir, layer=layer_name)
                if err is not None:
                    return [], err, False
                for group in groups:
                    self.notices.extend(_collect_frame(tmp_dir, _group_entries(group, self._wanted, self._crypto_source, self._crypto_slots), missing, self.passes, self._decode_kwargs, self.passes_raw))
                self._rendered_groups.extend(groups)
                _drop_node_group(self._ng)
                self._ng = None
        except Exception as e:  # noqa: BLE001 - 渲染/收集任一步的意外异常统一转成错误信息
            return [], api_error("Failed to capture the camera passes", e), False
        return [], None, not self._pending

    def has_pending(self) -> bool:
        """是否还有未渲染的批次(全部命中增量缓存时为 False, 调用方可直接提交)"""
        return bool(self._pending)

    def commit_cache(self) -> None:
        """把本次真正渲染过的组写入增量缓存(未重渲的组保留原有条目)

        只在渲染成功后调用; 失败路径不写, 免得把半份结果当有效缓存.
        """
        raw_by_group = {}
        for group in self._rendered_groups:
            raw = {channel: self.passes_raw[channel] for channel, _socket in _group_entries(group, self._wanted, self._crypto_source, self._crypto_slots) if channel in self.passes_raw}
            if raw:
                raw_by_group[group] = raw
        if raw_by_group:
            store_group_cache(self._keys, raw_by_group, self.size, self.notices)

    def collect(self) -> tuple:
        """收集最终通道字典(按参考优先序排列), 返回 (通道字典, 参考图尺寸)"""
        self._decode_segmentation()
        ordered = {key: self.passes[key] for key in PASS_ORDER if key in self.passes}
        return ordered, self.size

    def _decode_segmentation(self) -> None:
        """把 Cryptomatte 各层原始字节合成为 segmentation 通道的 PNG 字节

        名字取用户场景的全部物体: cryptomatte 只哈希被渲染到的物体, 多给的候选名不会命中,
        无副作用. 逐层读回像素后交给 utils.cryptomatte 做哈希反查(同像素按覆盖率择优).
        这一整段是**解码期**工作, 不触发任何渲染.
        """
        if not self._wanted.get('segmentation'):
            return
        raw_layers = [self.passes_raw.get(key) for key in CRYPTO_SLOT_KEYS]
        if not any(raw_layers):
            self.notices.append(api_error("The pass is not available from this engine, it was skipped", 'segmentation'))
            return
        arrays = []
        for raw in raw_layers:
            if raw is None:
                continue
            arr, err = _read_crypto_slot(raw)
            if err is not None:
                self.notices.append(api_error("The captured pass could not be read, it was skipped", 'segmentation'))
                return
            arrays.append(arr)
        names = _segmentation_names(self._scene, self._crypto_source)
        # 边缘是否抗锯齿由解码参数决定(出厂关闭=台阶, 打开=按覆盖率加权平均成平滑过渡)
        image, unmatched, err = decode_segmentation(arrays, names, antialias=self._smooth_seg_edges)
        if err is not None or image is None:
            self.notices.append(api_error("The captured pass could not be read, it was skipped", 'segmentation'))
            return
        if unmatched > _SEG_UNMATCHED_WARN:
            # 口径**按像素**: 该像素有覆盖却一个给出的名字都没匹配上(不是"某个槽位没匹配上").
            # 常见成因是该依据下确实没有对应名字(如按材质分割而物体没有材质), 那些像素保持黑.
            # 注意: 像素只要**任一**槽位匹配到名字就不计未解析 —— 故本提示反映的是"整片未解析
            # 的面积", 不反映重叠边缘的小面积归属错误(边缘按覆盖率择优, 见 cryptomatte 模块).
            self.notices.append(api_error("Part of the segmentation map did not match any name in the chosen source, " "those pixels stay black", f"{unmatched * 100:.1f}%"))
        self.passes['segmentation'] = _encode_png(image)

    def close(self):
        """回收临时场景/蜡笔/临时目录(幂等, 用户场景零残留)

        只回收**渲染环境**, 不动收集结果: passes / passes_raw / _keys / notices / size
        在 close() 之后仍可读(调用方按 collect -> commit_cache -> close 的顺序使用).
        若将来要在此清空它们, 必须同步调整 ai_render.CaptureViewRefs._finish 的调用序.
        """
        if self._closed:
            return
        self._closed = True
        _drop_node_group(self._ng)
        self._ng = None
        tmp = self._tmp
        if tmp is not None:
            try:
                bpy.data.scenes.remove(tmp)
            except Exception:  # noqa: BLE001 - 已回收时忽略
                pass
        self._tmp = None
        self._layers = {}
        _remove_gp(self._gp)
        self._gp = None
        # 线稿集合是我们自己建的, 必须**显式回收**: 只删临时场景只会把它变成 0 用户孤儿
        # 留在 bpy.data.collections 里, 下次捕获新建时被改名成 .001(2026-10-15 实测缺陷).
        if self._lineart_col is not None:
            drop_silently(bpy.data.collections.remove, self._lineart_col)
            self._lineart_col = None
        _drop_path(self._tmp_dir)
        self._tmp_dir = None


def _segmentation_names(scene, crypto_source: str) -> list:
    """该分割依据下参与解码的名字表

    与 Blender 侧的哈希口径严格对应(`cryptomatte.cc:564` 的 `add_ID` 取 `&id.name[2]`,
    即**去掉两字符类型前缀的裸名**):
    - OBJECT: 场景物体名;
    - MATERIAL: 数据块里的全部材质名(于是同材质的物体同色);
    - ASSET: 资产根物体名 —— 沿父级链走到顶(`cryptomatte.cc:255` 同款算法).
    多给的候选名不会命中, 无副作用(解码只对像素里实际出现过的哈希做反查).
    """
    if crypto_source == CRYPTO_SOURCE_MATERIAL:
        return [material.name for material in bpy.data.materials if material.name]
    if crypto_source == CRYPTO_SOURCE_ASSET:
        roots = []
        for obj in scene.objects:
            root = obj
            while root.parent is not None:
                root = root.parent
            if root.name:
                roots.append(root.name)
        return roots
    return [obj.name for obj in scene.objects if obj.name]


def _decode_collected(raw_map: dict, entries: tuple, passes: dict, decode_kwargs: dict) -> list:
    """把**已有的**原始字节解码为最终字节(免渲染路径复用缓存时用), 返回提示列表

    与 _collect_frame 的分工: 那条路从落盘文件读原始字节, 这条路直接拿缓存里的字节,
    解码逻辑共用 _decode_raw.
    """
    notices = []
    for channel, _socket in entries:
        raw = raw_map.get(channel)
        if raw is None:
            notices.append(api_error("The pass is not available from this engine, it was skipped", channel))
            continue
        final, err = _decode_raw(channel, raw, **decode_kwargs)
        if err is not None:
            notices.append(api_error("The captured pass could not be read, it was skipped", channel))
            continue
        passes[channel] = final
    return notices
