"""
物体移动到地面操作器模块

提供以下功能:
- ObjectToGround: 将物体移动到世界平面或指定物体表面
"""

__all__ = ["ObjectToGround"]

from bpy.types import Operator, Context
from bpy.props import EnumProperty, StringProperty, FloatProperty

from ...items import processing_mode_items
from ...utils import MeasureObject, get_evaluated_object, get_world_location, measure_objects_evaluated, set_world_location
from .....common.i18n.i18n import report


# ============================================================
# 物体移动到地面操作器
# ============================================================
class ObjectToGround(Operator):
    """
    将物体移动到地面
    功能:将选中的物体移动到世界平面或指定物体的表面
    - 支持两种目标模式:世界平面/指定物体
    - 支持两种移动模式:独立移动/整体移动
    - 支持自定义世界原点高度
    要求:至少选中 1 个物体
    """

    bl_idname = "ch.object_to_ground"
    bl_label = "Objects to Ground"
    bl_description = "Move selected objects to world plane or designated object"
    bl_options = {'REGISTER', 'UNDO'}

    target_mode: EnumProperty(
        name="Target Mode",
        description="The mode to move objects to",
        items=[
            ('WORLD_PLANE', "World Plane", "Move to world Z plane"),
            ('DESIGNATED_OBJECT', "Designated Object", "Move to top of designated object"),
        ],
        default='WORLD_PLANE',
    )  # type: ignore

    move_mode: EnumProperty(
        name="Move Mode",
        description="The mode to move objects to ground",
        items=processing_mode_items,
        default='INDIVIDUAL',
    )  # type: ignore

    designated_object_name: StringProperty(
        name="Designated Object",
        description="The target object to move objects onto",
    )  # type: ignore

    custom_origin: FloatProperty(
        name="Custom Origin",
        description="The custom world Z origin height",
        default=0.0,
    )  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return len(context.selected_objects) > 0

    def execute(self, context: Context):
        # 一步式构建世界坐标测量, 并回取可安全写回的原始物体
        measure_objs, objs = measure_objects_evaluated(context, context.selected_objects)
        # 计算整体底部 Z 坐标和地面 Z 坐标
        group_bottom_z = measure_objs.min_pos.z
        ground_z = self._get_ground_z(context)
        if ground_z is None:
            return {'CANCELLED'}
        # 遍历每个物体执行移动操作
        for obj, m_obj in zip(objs, measure_objs):
            # 测量值是世界坐标: 必须经世界位置写入, 父级物体的 location 是父空间局部值
            world_pos = get_world_location(obj)
            match self.move_mode:
                case 'INDIVIDUAL':
                    # 独立模式:每个物体独立移动到地面
                    world_pos.z -= m_obj.min_pos.z - ground_z
                case 'GROUP':
                    # 整体模式:所有物体作为整体移动到地面
                    world_pos.z -= group_bottom_z - ground_z
            set_world_location(obj, world_pos)

        context.view_layer.update()
        return {'FINISHED'}

    def _get_ground_z(self, context: Context) -> float:
        """
        计算地面 Z 坐标
        根据目标模式返回不同的地面高度:
        - WORLD_PLANE: 返回自定义世界原点高度
        - DESIGNATED_OBJECT: 返回指定物体的顶部 Z 坐标
        Returns:
            float: 地面 Z 坐标
        """
        match self.target_mode:
            case 'WORLD_PLANE':
                # 使用自定义世界平面高度
                return self.custom_origin
            case 'DESIGNATED_OBJECT':
                # 获取指定物体
                if not (obj := context.scene.objects.get(self.designated_object_name)):
                    # prop_search 存名字, 物体重命名/删除后按名查不到: 报错中止而非静默落到世界平面
                    # (浮空选区会被瞬间"砸"到 z=0)
                    self.report({'ERROR'}, report("Ground object '{}' not found").format(self.designated_object_name))
                    return None
                # 返回指定物体的顶部 Z 坐标
                designated_obj_dep = get_evaluated_object(context, obj)
                return MeasureObject(designated_obj_dep, designated_obj_dep.matrix_world).max_pos.z

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        col = layout.column()

        col.prop(self, "move_mode", expand=True)
        col.prop(self, "target_mode", expand=True)

        # 根据目标模式显示不同选项
        if self.target_mode == 'DESIGNATED_OBJECT':
            col.prop_search(self, "designated_object_name", context.scene, "objects")
        if self.target_mode == 'WORLD_PLANE':
            col.prop(self, "custom_origin")
