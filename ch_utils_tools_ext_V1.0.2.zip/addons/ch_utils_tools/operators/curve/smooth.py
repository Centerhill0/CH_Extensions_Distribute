"""
曲线平滑操作模块

提供以下功能:
- CurveSmooth: 平滑曲线的倾斜, 半径和权重属性

操作流程:
1. 选择要平滑的曲线点
2. 选择要平滑的属性(倾斜/半径/权重)
3. 执行平滑操作

支持的曲线类型:
- POLY: 多边形曲线
- NURBS: NURBS曲线
"""

__all__ = ["CurveSmooth"]

import bpy
from bpy.props import BoolProperty
from bpy.types import Operator, Context


class CurveSmooth(Operator):
    """
    曲线平滑操作器

    功能: 平滑曲线的倾斜, 半径和权重属性
    - 支持平滑倾斜(Tilt)
    - 支持平滑半径(Radius)
    - 支持平滑权重(Weight)

    要求: 曲线编辑模式下有活动的POLY或NURBS样条,且至少有一个属性存在变化
    """

    bl_idname = "ch.curve_smooth"
    bl_label = "Curve Smooth"
    bl_description = "Smooth the curve"
    bl_options = {'REGISTER', 'UNDO'}

    tilt: BoolProperty(name="Smooth Curve Tilt", default=True)  # type: ignore
    radius: BoolProperty(name="Smooth Curve Radius", default=True)  # type: ignore
    weight: BoolProperty(name="Smooth Curve Weight", default=False)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'EDIT_CURVE':
            act_obj = context.active_object
            act_spline = act_obj.data.splines.active

            if act_spline and act_spline.type in ['POLY', 'NURBS']:
                # poll 是重绘期高频路径: 任一属性存在相异值即可平滑——与首点比较发现相异
                # 即真, 不建三个全量 set; 原实现对空样条会因 len(set())-1 = -1 恒真, 顺带修正
                points = act_spline.points
                if len(points) < 2:
                    return False
                first = points[0]
                return any(point.tilt != first.tilt or point.radius != first.radius or point.weight != first.weight for point in points)

    def execute(self, context: Context):
        if self.tilt:
            bpy.ops.curve.smooth_tilt()

        if self.radius:
            bpy.ops.curve.smooth_radius()

        if self.weight:
            bpy.ops.curve.smooth_weight()

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "tilt")
        layout.prop(self, "radius")
        layout.prop(self, "weight")
