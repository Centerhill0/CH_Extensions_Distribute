"""
实时同步处理器模块

提供以下功能:
- depsgraph_update_post / load_post 处理器: 场景资源列表实时刷新与"选区同步"高亮
- refresh_lists: 公开的"立即重建快照"入口(供不触发 depsgraph 的算子主动调用)
- on_sync_toggle / on_zero_user_update: 面板状态开关的 update 回调
- on_images_index_update: 图像列表行点击时把图像编辑器切换到该图
- 周期计时器: 兜底刷新
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接

注:
- 列表活跃索引没有 update 回调 —— 点击名称只切换高亮, 选中物体由列表首按钮算子负责;
- "选区同步"只在**活动物体(或其活动材质)变化时**回写高亮, 用户手动点其它行不会被
  定时器顶回;
- 五种列表的集合/索引/开关统一取自 scene_state.LIST_SPECS.
"""

import bpy

from ...common.blender.list_snapshot import is_syncing, rebuild_if_changed
from .scene_state import LIST_SPECS, get_state, highlight_item
from .utils import collect_cameras, collect_images, collect_lights, collect_scene_material_blocks, collect_scene_materials, collect_worlds, first_image_of_material, focus_image_editors

# 列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0

# 上一次已跟进的活动状态 (物体名, 活动材质名); 变化时才回写各列表高亮
_LAST_ACTIVE: tuple = ("", "")


def reset_sync_cache() -> None:
    """清空"已同步的活动状态"缓存(选区同步开关切换/载入文件后重新开始同步)"""
    global _LAST_ACTIVE
    _LAST_ACTIVE = ("", "")


def on_sync_toggle(self, context) -> None:
    """选区同步开关的 update 回调: 重置缓存, 让下一轮同步重新对齐"""
    reset_sync_cache()


def on_zero_user_update(self, context) -> None:
    """ "显示0用户"开关的 update 回调: 立即重建快照(开关只改收集范围)"""
    refresh_lists()


def on_images_index_update(self, context) -> None:
    """图像列表活跃索引回调: 点击行时把图像编辑器切换到该图

    程序化写入(快照重建/高亮回写/移动条目)均在 common.list_snapshot 的护栏内,
    见 is_syncing 即跳过, 避免同步过程抢走用户的图像编辑器.
    """
    if is_syncing():
        return
    idx = self.images_active_index
    if not 0 <= idx < len(self.images):
        return
    image = bpy.data.images.get(self.images[idx].src_name)
    if image is not None:
        focus_image_editors(context, image)


def _collect_lists(state) -> dict:
    """收集五种列表的目标名称序列

    场景材质槽每轮只扫描一次: 材质列表直接复用该结果.
    """
    scene = bpy.context.scene
    used_materials = collect_scene_material_blocks(scene)
    return {
        "cameras": (collect_cameras(scene), None),
        "lights": (collect_lights(scene), None),
        "materials": (collect_scene_materials(scene, state.show_zero_user_materials, used_materials), None),
        "worlds": (collect_worlds(), None),
        "images": (collect_images(state.show_zero_user_images), None),
    }


def _sync_selection(context, state) -> None:
    """活动物体(或其活动材质)变化时, 按选区同步开关回写高亮

    只在"活动状态"变化时执行: 用户点其它行只改高亮, 不会被下一轮重建顶回.
    """
    global _LAST_ACTIVE
    act_obj = context.view_layer.objects.active
    if act_obj is None:
        _LAST_ACTIVE = ("", "")
        return
    act_mat = act_obj.active_material
    active = (act_obj.name, act_mat.name if act_mat is not None else "")
    if active == _LAST_ACTIVE:
        return
    _LAST_ACTIVE = active
    if not state.sync_selection:
        return
    highlight_item(context, "cameras", act_obj.name)
    _follow_light(context, act_obj)
    if act_mat is not None:
        highlight_item(context, "materials", act_mat.name)
        image = first_image_of_material(act_mat)
        if image is not None:
            highlight_item(context, "images", image.name)


def _follow_light(context, act_obj) -> None:
    """灯光列表跟进: 活动物体是灯光时高亮该灯光"""
    if act_obj.type == 'LIGHT':
        highlight_item(context, "lights", act_obj.name, 'OBJECT')


def _sync_all() -> None:
    """全量同步: 有变化才重建各列表快照, 然后按选区同步开关回写高亮"""
    context = bpy.context
    state = get_state(context)
    collected = _collect_lists(state)
    for kind, spec in LIST_SPECS.items():
        names, kinds = collected[kind]
        rebuild_if_changed(state, spec.collection, spec.index, spec.item_kind, names, kinds)
    _sync_selection(context, state)


def _sync_all_safe() -> None:
    """全量同步, 吞掉"插件注销窗口期 WM 属性已摘除"类异常(各入口共用)"""
    try:
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _on_depsgraph_update(*_args) -> None:
    """depsgraph 更新回调: 场景/选中变化时实时刷新"""
    _sync_all_safe()


def _on_load_post(*_args) -> None:
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐新场景并重置跟进缓存"""
    reset_sync_cache()
    _sync_all_safe()


def refresh_lists() -> None:
    """立即重建列表快照并回写高亮

    供"写自定义属性(不触发 depsgraph, 5.1.2 实测)"的算子主动调用, 如列表排序值写入.
    """
    _sync_all_safe()


def _sync_timer() -> float:
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register() -> None:
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister() -> None:
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
