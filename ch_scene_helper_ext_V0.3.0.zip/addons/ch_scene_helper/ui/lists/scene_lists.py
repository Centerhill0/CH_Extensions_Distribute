"""
场景助手资源列表模块

五个 UIList(类名含 _UL_ 标记, 类名即 template_list 查找 id):
相机 / 灯光 / 材质 / 世界环境 / 图像. 数据源是 WM 级快照(SceneHelperState),
顺序由快照序决定(按 ch_scene_order 排序).

主要功能:
- 行内只有名称与状态/参数控件, 详情统一由列表面板下方的可折叠子面板显示
- 名称经快照条目的 name 属性编辑并写穿到真实数据块, 双击才进入编辑
- 名称过滤 / 字母排序 / 反序由 common.blender.list_snapshot.StandardFilterMixin 提供
  (字母排序关闭时保持快照序, 反序最后统一应用)
- 首个图标统一为"选中关联物体": 点击会选中关联物体并高亮该列表项
- 伪用户按钮统一为算子切换(图标按当前状态绘制, 点击即时刷新)
"""

import bpy
from bpy.types import Context, UIList, UILayout

from .....common.blender.list_snapshot import StandardFilterMixin
from ...operators.utils.datablock_ops import WorldAssign
from ...operators.utils.image_ops import ImagePack, ImageUnpack
from ...operators.utils.material_ops import MaterialRowAssign
from ...operators.utils.row_ops import CameraSetView
from ...scene_state import block_for_item, get_state
from ._rows import (
    NAME_FACTOR,
    camera_icon,
    can_split_columns,
    draw_fake_user_count,
    draw_image_select,
    draw_isolate_button,
    draw_material_select,
    draw_missing_item,
    draw_name_cell,
    draw_object_toggles,
    draw_select_button,
    draw_split_columns,
    light_icon,
    material_preview_icon,
)

# 图像来源 -> 行图标
_IMAGE_SOURCE_ICONS = {
    'MOVIE': 'FILE_MOVIE',
    'SEQUENCE': 'RENDERLAYERS',
    'VIEWER': 'RESTRICT_RENDER_ON',
    'GENERATED': 'SELECT_SET',
}


def _draw_material_row(context: Context, layout: UILayout, item, mat) -> None:
    """材质行: 选择使用者 / 赋予 / 名称(预览图) / 通道索引 / 节点数 / 伪用户 / 使用者数"""
    state = get_state(context)
    row = layout.row(align=True)
    draw_material_select(row, context, mat)
    op = row.operator(MaterialRowAssign.bl_idname, text="", icon='IMPORT', emboss=False)
    op.mat_name = mat.name
    show_pass_index = state.materials_show_pass_index
    show_node_count = state.materials_show_node_count
    split_columns = (show_pass_index or show_node_count) and can_split_columns(context)
    sub = draw_name_cell(row, item, icon_value=material_preview_icon(mat), name_factor=0.4 if split_columns else NAME_FACTOR)
    if split_columns:
        columns, right = draw_split_columns(sub, 0.6)
        if show_pass_index:
            columns.prop(mat, "pass_index", text="")
        if show_node_count:
            count = len(mat.node_tree.nodes) if mat.use_nodes and mat.node_tree else 0
            columns.label(text="{:02d}".format(count), icon='NODE')
    else:
        right = sub
    draw_fake_user_count(right, mat, 'MATERIAL')


class CH_UL_scene_cameras(StandardFilterMixin, UIList):
    """相机列表(场景快照), 行内: 选择 / 相机视角 / 名称 / 焦距 / 类型 / 三状态开关"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        obj = block_for_item(context, "cameras", item)
        if obj is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        draw_select_button(row, context, obj, "cameras")
        op = row.operator(CameraSetView.bl_idname, text="", icon=camera_icon(context, obj), emboss=False)
        op.obj_name = obj.name
        show_columns = state.cameras_show_lens or state.cameras_show_type
        split_columns = show_columns and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else NAME_FACTOR)
        cam = obj.data
        if split_columns:
            columns, right = draw_split_columns(sub, 0.55)
            if state.cameras_show_lens:
                if cam.lens_unit == 'FOV':
                    columns.prop(cam, "angle", text="", emboss=False)
                else:
                    columns.prop(cam, "lens", text="", emboss=False)
            if state.cameras_show_type:
                columns.prop(cam, "type", text="", emboss=False)
        else:
            right = sub
        draw_object_toggles(right, obj)


class CH_UL_scene_materials(StandardFilterMixin, UIList):
    """材质列表(场景快照), 行内: 选择使用者 / 赋予 / 名称(预览图) / 通道索引 / 节点数 / 假用户"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        mat = bpy.data.materials.get(item.src_name)
        if mat is None:
            draw_missing_item(layout, item)
            return
        _draw_material_row(context, layout, item, mat)


class CH_UL_scene_lights(StandardFilterMixin, UIList):
    """灯光列表(场景快照), 行内: 选择 / 类型 / 名称 / 颜色 / 阴影 / 隔离 / 三状态开关"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        obj = block_for_item(context, "lights", item)
        if obj is None:
            draw_missing_item(layout, item)
            return
        light = obj.data
        row = layout.row(align=True)
        draw_select_button(row, context, obj, "lights")
        row.prop(light, "type", text="", icon=light_icon(obj), icon_only=True, emboss=False)
        show_columns = state.lights_show_color or state.lights_show_shadow
        split_columns = show_columns and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else NAME_FACTOR)
        if split_columns:
            columns, right = draw_split_columns(sub, 0.5)
            if state.lights_show_color:
                columns.prop(light, "color", text="")
            if state.lights_show_shadow:
                columns.prop(light, "use_shadow", text="", icon='GHOST_ENABLED' if light.use_shadow else 'GHOST_DISABLED', emboss=False)
        else:
            right = sub
        draw_isolate_button(right, context, obj)
        draw_object_toggles(right, obj)


class CH_UL_scene_images(StandardFilterMixin, UIList):
    """图像列表(图像数据块快照), 行内: 选择使用者 / 来源图标 / 名称 / 路径 / 尺寸 / 伪用户 / 打包解包"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        img = bpy.data.images.get(item.src_name)
        if img is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        draw_image_select(row, context, img)
        row.label(text="", icon=_IMAGE_SOURCE_ICONS.get(img.source, 'IMAGE_DATA'))
        # 列区只在**本行确实有内容**时占用宽度: Render Result / Viewer Node 这类无像素、
        # 无文件路径的内置图像若仍按 0.3 分列, 空列区会挤掉名称并把右侧按钮压到角落.
        show_size = bool(state.images_show_size and img.has_data)
        show_path = bool(state.images_show_filepath and img.filepath)
        split_columns = (show_size or show_path) and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else NAME_FACTOR)
        if split_columns:
            # 文件路径需要更多显示宽度: 图像列区占比高于其他列表, 右侧按钮仍保留足够空间
            columns, right = draw_split_columns(sub, 0.65)
            if show_size:
                columns.label(text="{} x {}".format(img.size[0], img.size[1]))
            if show_path:
                columns.prop(img, "filepath", text="", emboss=False)
        else:
            right = sub
        draw_fake_user_count(right, img, 'IMAGE')
        if img.packed_file is not None:
            op = right.operator(ImageUnpack.bl_idname, text="", icon='PACKAGE', emboss=False)
        else:
            op = right.operator(ImagePack.bl_idname, text="", icon='UGLYPACKAGE', emboss=False)
        op.image_name = img.name
        if img.has_data:
            right.label(text="", icon='BLANK1')
        elif img.filepath:
            right.label(text="", icon='MARKER')
        else:
            right.label(text="", icon='ERROR')


class CH_UL_scene_worlds(StandardFilterMixin, UIList):
    """世界环境列表(世界数据块快照), 行内: 指派 / 名称 / 颜色 / 伪用户 / 使用者数"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        world = bpy.data.worlds.get(item.src_name)
        if world is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        active = context.scene.world is world
        op = row.operator(WorldAssign.bl_idname, text="", icon='RESTRICT_SELECT_OFF' if active else 'RESTRICT_SELECT_ON', emboss=False)
        op.world_name = world.name
        split_columns = state.worlds_show_color and can_split_columns(context)
        sub = draw_name_cell(row, item, icon='WORLD', name_factor=0.3 if split_columns else NAME_FACTOR)
        if split_columns:
            columns, right = draw_split_columns(sub, 0.5)
            columns.prop(world, "color", text="")
        else:
            right = sub
        draw_fake_user_count(right, world, 'WORLD')
