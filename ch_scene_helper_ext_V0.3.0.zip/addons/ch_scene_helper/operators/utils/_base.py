"""
算子公共 mixin

- TranslatedDescriptionMixin: 动态 tooltip 回调统一经 tip() 翻译
- PanelMaterialMixin: "物体模式 + 材质面板有活动材质"的 poll 与取材质/警告
"""

from bpy.types import Context

from .....common.i18n.i18n import report, tip
from ...scene_state import panel_material


class TranslatedDescriptionMixin:
    """动态 tooltip 回调 mixin

    Blender 要求 description 是 classmethod/staticmethod, 且回调返回值不走静态
    bl_description 的翻译链, 必须经 tip() 自查.
    """

    @classmethod
    def description(cls, context: Context, properties):
        return tip(cls.bl_description)


class PanelMaterialMixin:
    """材质面板算子 mixin: poll 与取面板活动材质

    子类可按需关闭物体模式要求(如删除算子只要求有活动材质).
    """

    require_object_mode = True

    @classmethod
    def poll(cls, context: Context):
        if cls.require_object_mode and context.mode != 'OBJECT':
            return False
        return panel_material(context) is not None

    def require_panel_material(self, context: Context):
        """取面板活动材质; 无有效条目时报告警告并返回 None"""
        mat = panel_material(context)
        if mat is None:
            self.report({'WARNING'}, report("No material selected"))
        return mat
