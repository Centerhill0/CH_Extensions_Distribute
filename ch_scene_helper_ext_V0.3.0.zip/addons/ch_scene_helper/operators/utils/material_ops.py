"""
材质面板算子模块

提供以下功能:
- MaterialAssign: 把面板活动材质赋给选中物体(+Ctrl 追加 / +Alt 替换指定槽)
- MaterialSelectUsers: 选中面板活动材质(或行内指定材质)的全部使用者
- MaterialDuplicate: 复制面板活动材质并赋给选中物体(列表高亮切到副本)
- MaterialDelete: 解除面板活动材质的关联(默认), Shift 点击删除材质数据块
- MaterialRowAssign: 列表行内"赋予材质"按钮(+Shift 复制后赋予)
- MaterialNew: 新建材质并赋给活动物体
- PassIndexBatch: 场景材质 pass index 批量设置

注: "面板活动材质"指材质列表活跃索引对应的数据块(按 src_name 真实名检索),
即材质赋值的目标, 与"活动物体自身的活动材质槽"无关.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ... import handlers
from ...scene_state import highlight_item
from ...utils import MATERIAL_SLOT_TYPES, assign_material, collect_scene_material_blocks, delete_material, duplicate_material, find_instance_group, select_material_users, unlink_material, unsync_instance_group
from ._base import PanelMaterialMixin, TranslatedDescriptionMixin

# 提示之间在状态栏的合并分隔符(多条 report 会互相覆盖, 故合并成一条)
_NOTE_SEP = " | "


class MaterialAssign(PanelMaterialMixin, TranslatedDescriptionMixin, Operator):
    """把面板活动材质赋给选中物体(直接点击替换活动槽 / +Ctrl 追加 / +Alt 替换指定槽)

    要求: 物体模式; 有选中物体; 面板材质列表有活跃项; +Alt 时恰好选中一个物体
    """

    bl_idname = "ch.material_assign"
    bl_label = "Apply Material"
    bl_description = "Assign the active material of the Materials panel to all selected objects\n+Ctrl: Append the material to the object material slots instead of replacing the active one\n+Alt: Replace the material slot of the given index (single selected object only, out of range replaces the last slot)"
    bl_options = {'REGISTER', 'UNDO'}

    slot_index: IntProperty(name="Slot Index", description="Material slot index to replace (0-based, out of range replaces the last slot)", default=0, min=0)  # type: ignore
    append: BoolProperty(name="Append", description="Append the material to the object material slots instead of replacing the active one", default=False)  # type: ignore
    # invoke 中按 Alt 置位; 存 RNA 供 Redo 沿用同一分支(F9 面板不显示)
    replace_slot: BoolProperty(name="Replace Slot", default=False, options={'HIDDEN'})  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.append = bool(event is not None and event.ctrl)
        self.replace_slot = bool(event is not None and event.alt)
        if self.replace_slot:
            return self._invoke_slot_dialog(context)
        return self.execute(context)

    def draw(self, context: Context):
        self.layout.use_property_split = True
        self.layout.prop(self, "slot_index")

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        sel_objs = context.selected_objects
        if self.append:
            count, _err = assign_material(mat, sel_objs, append=True)
            if count == 0:
                self.report({'WARNING'}, report("No objects can hold the material"))
                return {'CANCELLED'}
            self.report({'INFO'}, report("Material appended: {} objects").format(count))
            return {'FINISHED'}
        if self._is_slot_assign():
            return self._execute_slot_assign(context, mat, sel_objs)
        count, _err = assign_material(mat, sel_objs)
        if count == 0:
            self.report({'WARNING'}, report("No objects can hold the material"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Material assigned: {} objects").format(count))
        return {'FINISHED'}

    def _is_slot_assign(self) -> bool:
        """是否走"替换指定槽"分支: invoke 按过 Alt, 或用户在 F9 面板把编号改成非 0"""
        return self.replace_slot or self.slot_index > 0

    def _invoke_slot_dialog(self, context: Context):
        """+Alt 入口: 校验单物体后弹出 F9 面板, 确认才执行"""
        sel_objs = context.selected_objects
        if len(sel_objs) != 1:
            self.report({'WARNING'}, report("Slot assign requires exactly one selected object"))
            return {'CANCELLED'}
        act_obj = sel_objs[0]
        if act_obj.type not in MATERIAL_SLOT_TYPES:
            self.report({'WARNING'}, report("Object has no material slots"))
            return {'CANCELLED'}
        self.slot_index = act_obj.active_material_index
        return context.window_manager.invoke_props_dialog(self, width=320)

    def _execute_slot_assign(self, context: Context, mat, sel_objs: list):
        """替换单物体的指定槽(编号越界由 utils.assign_material 落到末尾槽)"""
        if not sel_objs:
            self.report({'WARNING'}, report("Slot assign requires exactly one selected object"))
            return {'CANCELLED'}
        obj = sel_objs[0]
        count, _err = assign_material(mat, [obj], slot_index=self.slot_index)
        if count == 0:
            self.report({'WARNING'}, report("Object has no material slots"))
            return {'CANCELLED'}
        slot_count = len(obj.material_slots)
        idx = min(self.slot_index, slot_count - 1)
        if self.slot_index >= slot_count:
            self.report({'INFO'}, report("Slot index out of range, replaced the last slot: {}").format(idx))
        else:
            self.report({'INFO'}, report("Material replaced at slot: {}").format(idx))
        return {'FINISHED'}


class MaterialSelectUsers(PanelMaterialMixin, Operator):
    """选中材质的全部使用者物体

    mat_name 由行内按钮传入; 为空时取材质面板活动材质(面板动作行使用).
    """

    bl_idname = "ch.material_select_users"
    bl_label = "Select Users"
    bl_description = "Select all objects that use this material"
    bl_options = {'REGISTER', 'UNDO'}

    mat_name: StringProperty(name="Material", options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        # 行内按钮传 mat_name, 面板动作行走活动材质; poll 看不到算子属性,
        # 故只限物体模式, 具体材质是否存在交给 execute 报告.
        return context.mode == 'OBJECT'

    def execute(self, context: Context):
        mat = bpy.data.materials.get(self.mat_name) if self.mat_name else self.require_panel_material(context)
        if mat is None:
            if self.mat_name:
                self.report({'WARNING'}, report("Material not found"))
            return {'CANCELLED'}
        highlight_item(context, "materials", mat.name)
        if not select_material_users(context, mat):
            self.report({'WARNING'}, report("No objects use this material"))
        return {'FINISHED'}


class MaterialDuplicate(PanelMaterialMixin, TranslatedDescriptionMixin, Operator):
    """复制面板活动材质并赋给选中物体, 列表高亮切到新副本

    +Alt: 先把选中的实例物体独立化, 再复制材质; 没有实例时只提示,
    行为与直接点击一致.
    """

    bl_idname = "ch.material_duplicate"
    bl_label = "Duplicate Material"
    bl_description = "Duplicate the active material of the Materials panel and assign it to all selected objects\n+Alt: Make the selected instanced objects independent (selected objects sharing a mesh become one unified instance) and then duplicate the material; without instances it only shows a notice"
    bl_options = {'REGISTER', 'UNDO'}

    # invoke 中按 Alt 置位; 存 RNA 供 Redo 沿用同一分支(F9 面板不显示)
    unsync_instances: BoolProperty(name="Unsync Instances", default=False, options={'HIDDEN'})  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.unsync_instances = bool(event is not None and event.alt)
        return self.execute(context)

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        notes = []
        if self.unsync_instances:
            notes.extend(self._unsync_selected(context))
        new_mat = duplicate_material(mat)
        if new_mat is None:
            self.report({'ERROR'}, report("Material not found"))
            return {'CANCELLED'}
        count, _err = assign_material(new_mat, context.selected_objects)
        # 写自定义属性与新建数据块均不触发 depsgraph, 主动重建快照后才有副本条目可高亮
        handlers.refresh_lists()
        highlight_item(context, "materials", new_mat.name)
        notes.append(report("Material duplicated and assigned: {}").format(new_mat.name))
        if count == 0:
            notes.append(report("No objects selected, the copy has no users"))
        self.report({'INFO'}, _NOTE_SEP.join(notes))
        return {'FINISHED'}

    def _unsync_selected(self, context: Context) -> list:
        """+Alt 的第一步: 把选中的实例组独立化, 返回需要汇报的提示行(不直接 report)"""
        groups = find_instance_group(context.selected_objects)
        if not groups:
            return [report("No instanced objects to make independent")]
        notes = []
        done = 0
        for data_name, group_objs in groups.items():
            result = unsync_instance_group(group_objs)
            if not result["ok"]:
                notes.append(report("Failed to make instance independent: {}").format(data_name))
                continue
            done += result["count"]
        if done > 0:
            notes.append(report("Instances made independent: {} objects").format(done))
        return notes


class MaterialDelete(PanelMaterialMixin, Operator):
    """解除材质关联或删除材质数据块

    默认解除面板活动材质与全部物体的材质槽关联(保留数据块, Ctrl+Z 可撤销);
    Shift 点击才真正删除材质数据块(在用材质由 Blender 自动清空其材质槽).
    """

    bl_idname = "ch.material_delete"
    bl_label = "Unlink Material"
    bl_description = "Unlink the active material from all objects\n+Shift: Delete the material data-block directly"
    bl_options = {'REGISTER', 'UNDO'}

    require_object_mode = False

    delete: BoolProperty(name="Delete", description="Delete the material data-block instead of only unlinking it", default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        # Shift 点击 = 删除数据块; invoke 直调(event 为 None)时保持默认的解除关联
        self.delete = bool(event is not None and event.shift)
        return self.execute(context)

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        if self.delete:
            ok, _err = delete_material(mat)
            if not ok:
                self.report({'ERROR'}, report("Material not found"))
                return {'CANCELLED'}
            return {'FINISHED'}
        count, _err = unlink_material(context.scene, mat)
        if count == 0:
            self.report({'INFO'}, report("Material not linked to any object"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Material unlinked from {} slots").format(count))
        return {'FINISHED'}


class MaterialRowAssign(TranslatedDescriptionMixin, Operator):
    """把行内材质赋给选中物体(+Shift 复制材质后赋予)"""

    bl_idname = "ch.material_row_assign"
    bl_label = "Apply Material"
    bl_description = "Assign this material to all selected objects\n+Shift: Duplicate the material and assign the copy"
    bl_options = {'REGISTER', 'UNDO'}

    mat_name: StringProperty(name="Material")  # type: ignore
    duplicate: BoolProperty(name="Duplicate", default=False, description="Duplicate the material before assigning")  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.duplicate = bool(event is not None and event.shift)
        return self.execute(context)

    def execute(self, context: Context):
        mat = bpy.data.materials.get(self.mat_name)
        if mat is None:
            self.report({'WARNING'}, report("Material not found"))
            return {'CANCELLED'}
        if self.duplicate:
            mat = duplicate_material(mat)
        targets = [obj for obj in context.selected_objects if obj.type in MATERIAL_SLOT_TYPES]
        if not targets:
            self.report({'WARNING'}, report("No objects can hold the material"))
            return {'CANCELLED'}
        count, _err = assign_material(mat, targets)
        if count == 0:
            self.report({'WARNING'}, report("No objects can hold the material"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Material assigned: {} objects").format(count))
        return {'FINISHED'}


class MaterialNew(Operator):
    """新建材质并赋给活动物体(无可持有材质的活动物体时保留为 0 用户材质)"""

    bl_idname = "ch.material_new"
    bl_label = "New Material"
    bl_description = "Create a new material and assign it to the active object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        mat = bpy.data.materials.new("Material")
        mat.use_nodes = True
        obj = context.view_layer.objects.active
        assigned = obj is not None and obj.type in MATERIAL_SLOT_TYPES
        if assigned:
            obj.data.materials.append(mat)
            obj.active_material_index = len(obj.material_slots) - 1
        # 新材质挂到活动物体上后应立刻出现在快照里(材质列表只列场景在用材质)
        handlers.refresh_lists()
        highlight_item(context, "materials", mat.name)
        if not assigned:
            self.report({'INFO'}, report("Material created without users"))
        return {'FINISHED'}


class PassIndexBatch(Operator):
    """场景材质的 pass index 批量设置"""

    bl_idname = "ch.pass_index_batch"
    bl_label = "Batch Pass Index"
    bl_description = "Set the pass index of all materials used in the scene in one go"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        name="Mode",
        items=(
            ("SEQUENTIAL", "Sequential", "Assign increasing values"),
            ("FIXED", "Fixed", "Assign the same value to every material"),
        ),
        default=0,
    )  # type: ignore
    start: IntProperty(name="Start", default=1, min=0, description="Value assigned to the first material")  # type: ignore
    fixed_value: IntProperty(name="Value", default=0, min=0, description="Value assigned to every material")  # type: ignore
    skip_assigned: BoolProperty(name="Skip Assigned", default=True, description="Leave materials with a non-zero pass index untouched")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "mode", expand=True)
        if self.mode == 'FIXED':
            layout.prop(self, "fixed_value")
        else:
            layout.prop(self, "start")
            layout.prop(self, "skip_assigned")

    def execute(self, context: Context):
        materials = collect_scene_material_blocks(context.scene)
        if self.mode == 'FIXED':
            for mat in materials:
                mat.pass_index = self.fixed_value
            self.report({'INFO'}, report("Pass index set: {} materials").format(len(materials)))
            return {'FINISHED'}
        count = 0
        for mat in materials:
            if self.skip_assigned and mat.pass_index:
                continue
            mat.pass_index = self.start + count
            count += 1
        self.report({'INFO'}, report("Pass index set: {} materials").format(count))
        return {'FINISHED'}
