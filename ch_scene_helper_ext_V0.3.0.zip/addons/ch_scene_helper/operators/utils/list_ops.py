"""
列表动作算子模块

提供以下功能:
- ListMove: 上移/下移列表活跃项(顺序值写数据块自定义属性, 随 blend 持久; 高亮跟随被移动项)
- ListSort: 一键按名称排序(顺序值写数据块自定义属性)
- ObjectDelete: 删除列表活跃项对应的物体(相机/灯光列表)

列表顺序值算法见 common.blender.list_order: 挂数据块自定义属性 ch_scene_order,
collect 按 order_key 排序; 移动/排序只改写顺序值, 由 refresh_lists 立即重建快照.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Context, Operator

from .....common.blender.list_order import materialize_orders, swap_orders
from .....common.blender.list_snapshot import set_index
from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import LIST_SPECS, blocks_for, get_state

# 列表种类枚举(显示名由种类标识标题化, 与面板标题一致)
_LIST_KIND_ITEMS = tuple((kind, kind.title(), "") for kind in LIST_SPECS)
_OBJECT_LIST_ITEMS = (("lights", "Lights", ""), ("cameras", "Cameras", ""))


def _cancel_stale(op: Operator) -> set:
    """列表条目已失效: 报告后返回取消结果"""
    op.report({'WARNING'}, report("List item is no longer in the scene"))
    return {'CANCELLED'}


class ListMove(Operator):
    """上移/下移列表活跃项(交换相邻项的顺序值, 顺序随 blend 文件持久)"""

    bl_idname = "ch.list_move"
    bl_label = "Move List Item"
    bl_description = "Move the active list item up or down (order saved in the blend file)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_LIST_KIND_ITEMS, default="lights")  # type: ignore
    move_down: BoolProperty(name="Move Down", default=False)  # type: ignore

    def execute(self, context: Context):
        spec = LIST_SPECS[self.list_kind]
        state = get_state(context)
        coll = getattr(state, spec.collection)
        idx = getattr(state, spec.index)
        target = idx + 1 if self.move_down else idx - 1
        if not coll or not 0 <= idx < len(coll) or not 0 <= target < len(coll):
            return {'CANCELLED'}
        blocks = blocks_for(context, self.list_kind)
        if blocks[idx] is None or blocks[target] is None:
            return _cancel_stale(self)
        # 先物质化当前快照序(补齐缺失顺序值), 再交换相邻两个
        materialize_orders(blocks)
        swap_orders(blocks[idx], blocks[target])
        # 活跃索引跟随被移动的条目; 须在重建快照前写入, 否则重建会把原行号上的另一个条目当活跃项
        set_index(state, spec.index, target)
        refresh_lists()
        return {'FINISHED'}


class ListSort(Operator):
    """一键按名称排序列表(顺序值写数据块自定义属性, 随 blend 文件持久)"""

    bl_idname = "ch.list_sort"
    bl_label = "Sort by Name"
    bl_description = "Sort the list by name (order saved in the blend file)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_LIST_KIND_ITEMS, default="lights")  # type: ignore

    def execute(self, context: Context):
        spec = LIST_SPECS[self.list_kind]
        coll = getattr(get_state(context), spec.collection)
        if not coll:
            return {'CANCELLED'}
        blocks = blocks_for(context, self.list_kind)
        if any(block is None for block in blocks):
            return _cancel_stale(self)
        materialize_orders(sorted(blocks, key=lambda block: block.name))
        refresh_lists()
        return {'FINISHED'}


class ObjectDelete(Operator):
    """删除列表活跃项对应的物体(灯光/相机列表; 子物体保留, Ctrl+Z 可撤销)"""

    bl_idname = "ch.object_delete"
    bl_label = "Delete Object"
    bl_description = "Delete the active object of the list"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_OBJECT_LIST_ITEMS, default="lights")  # type: ignore

    def execute(self, context: Context):
        spec = LIST_SPECS[self.list_kind]
        state = get_state(context)
        coll = getattr(state, spec.collection)
        idx = getattr(state, spec.index)
        if not coll or not 0 <= idx < len(coll):
            return {'CANCELLED'}
        obj = blocks_for(context, self.list_kind)[idx]
        if obj is None:
            return _cancel_stale(self)
        bpy.data.objects.remove(obj)
        # 物体移除虽触发 depsgraph, 仍主动重建保证快照立即可见(后台通道尤甚)
        refresh_lists()
        return {'FINISHED'}
