"""
Blender API 封装子包

公共 API 经由本 __init__ 再导出至 utils 顶层命名空间;
未在此列出的模块成员为子包内部协作 API, 仅供 utils 内部使用.
"""

from .image import find_image_users, first_image_of_material, focus_image_editors, merge_duplicate_images, reload_external_images, rename_image_from_file, replace_image_reference
from .light import scale_lights_energy
from .material import (
    MATERIAL_SLOT_TYPES,
    assign_material,
    delete_material,
    detect_pbr_texture_graph,
    duplicate_material,
    find_instance_group,
    find_material_slot,
    get_material_output,
    get_pbr_texcoord_pair,
    get_surface_bsdf,
    get_texcoord_output,
    is_texcoord_update_suppressed,
    material_users,
    resolve_bsdf_slots,
    select_material_users,
    set_texcoord_output,
    suppress_texcoord_updates,
    trace_upstream,
    unlink_material,
    unsync_instance_group,
)
from .scene_data import collect_cameras, collect_images, collect_lights, collect_scene_material_blocks, collect_scene_materials, collect_worlds
from .selection import select_object, select_only

__all__ = [
    "scale_lights_energy",
    "find_image_users",
    "first_image_of_material",
    "focus_image_editors",
    "rename_image_from_file",
    "reload_external_images",
    "replace_image_reference",
    "merge_duplicate_images",
    "MATERIAL_SLOT_TYPES",
    "assign_material",
    "find_material_slot",
    "find_instance_group",
    "unsync_instance_group",
    "duplicate_material",
    "delete_material",
    "unlink_material",
    "material_users",
    "select_material_users",
    "get_material_output",
    "get_surface_bsdf",
    "resolve_bsdf_slots",
    "trace_upstream",
    "detect_pbr_texture_graph",
    "get_pbr_texcoord_pair",
    "get_texcoord_output",
    "set_texcoord_output",
    "is_texcoord_update_suppressed",
    "suppress_texcoord_updates",
    "select_only",
    "select_object",
    "collect_cameras",
    "collect_lights",
    "collect_scene_material_blocks",
    "collect_scene_materials",
    "collect_images",
    "collect_worlds",
]
