"""
物体选中工具模块

行内"选中关联物体"、材质/图像使用者批量选中与相机切换共用的选中算法.
"""

from bpy.types import Context, Object


def select_only(context: Context, objects: list, active: Object | None = None) -> None:
    """只选中给定物体(按名称集合写选中态), 并把 active 设为活动物体

    先设活动物体再遍历选中: 后台实测 active 为 None 时 select_set(True) 静默失效;
    迭代 view_layer.objects 的副本, 避免边选中边改动活集合令迭代器失效.
    """
    objects = [obj for obj in objects if obj is not None]
    if not objects:
        return
    first_obj = active if active is not None else objects[0]
    context.view_layer.objects.active = first_obj
    selected_names = {obj.name for obj in objects}
    for obj in list(context.view_layer.objects):
        if obj is not None:
            obj.select_set(obj.name in selected_names)


def select_object(context: Context, obj: Object, extend: bool = False, deselect: bool = False) -> None:
    """选中单个物体(extend 加选, deselect 减选, 否则独占选中并设为活动物体)"""
    if not extend and not deselect:
        for other in context.selected_objects:
            other.select_set(False)
    obj.select_set(not deselect)
    if not deselect:
        context.view_layer.objects.active = obj
