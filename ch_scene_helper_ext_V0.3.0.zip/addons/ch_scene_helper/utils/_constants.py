"""
材质面板参数子面板的共享常量

语义表驱动材质面板"设置"子面板的基础参数区:
- BSDF_SLOT_ALIASES: 固定语义序 -> 候选插槽名(逐个试取, 取到即用)
- BSDF_NODE_TYPES: 允许进入基础参数区的节点类型白名单
- PBR_CHANNELS: PBR 检测的五个通道(前四项为 Principled 插槽名, 末项为 Material Output 插槽)
- TEXCOORD_OPTIONS: 材质面板坐标输出下拉的镜像枚举(真值在连接关系里, 面板只存镜像)

版本兼容结论与警告见各常量旁注释; 完整依据见
.agents/log/archive/archive-ch_scene_helper-material-params-panel-design.md (v3 定案版, 已归档).
"""

# 允许进入基础参数区的节点类型(node.type 白名单)
# - 含 EMISSION: 自发光材质纳入(作者决议 3); 它只显示自己的 Color/Strength(见语义表序 7/8)
# - 含体积/毛发/SSS/高光/光线传送等(2026-10-19 作者扩充): 各按其拥有的插槽命中语义表
# - 不用 startswith('BSDF_') 前缀判断: EMISSION/体积类不满足前缀, 白名单才是唯一口径
BSDF_NODE_TYPES = {
    'BSDF_PRINCIPLED',
    'BSDF_DIFFUSE',
    'BSDF_GLOSSY',
    'BSDF_METALLIC',
    'BSDF_GLASS',
    'BSDF_REFRACTION',
    'BSDF_TRANSLUCENT',
    'BSDF_TRANSPARENT',
    'BSDF_SHEEN',
    'BSDF_TOON',
    'BSDF_HAIR',
    'BSDF_HAIR_PRINCIPLED',
    'EEVEE_SPECULAR',
    'SUBSURFACE_SCATTERING',
    'PRINCIPLED_VOLUME',
    'VOLUME_ABSORPTION',
    'VOLUME_SCATTER',
    'BSDF_RAY_PORTAL',
    'EMISSION',
}

# 毛发节点类型(作者口径: 只显示颜色/糙度, 其 IOR/Offset 等毛发专属参数留给节点面板)
HAIR_NODE_TYPES = frozenset({'BSDF_HAIR', 'BSDF_HAIR_PRINCIPLED'})
# 体积节点类型(作者口径: 只显示颜色; 原理化体积的 Emission Color/Strength、Density 等留给节点面板)
VOLUME_NODE_TYPES = frozenset({'PRINCIPLED_VOLUME', 'VOLUME_ABSORPTION', 'VOLUME_SCATTER'})

# 固定语义序 -> 候选插槽名(作者决议 7: 不按各节点自己的插槽顺序; 2026-10-19 作者扩充)
# - 绘制时逐项试取 node.inputs.get(name), 取到即画, 取不到跳过(静默, 不报错)
# - "IOR" 行还要求 socket.type == 'VALUE': Metallic BSDF 的 IOR 是 VECTOR(复折射率), 须排除
# - "自发光节点颜色/强度"两行要求节点 type == 'EMISSION': 与 Principled 的 Emission Color 行互斥
# - "高光颜色"行仅 EEVEE_SPECULAR 命中(其自发光插槽叫 "Emissive Color", 不是 "Emission Color")
# - "发光强度"仅 EMISSION(插槽 "Strength")与 EEVEE_SPECULAR(无强度插槽, 不命中)差异见上
# 版本兼容: 全部名字在 Blender 5.1.2(运行时探针)与 5.4.0-alpha(源码)上一致, 5.4 在
# Alpha 与 Normal 之间新增 "Thin Wall" 插槽不影响按名取值(对照记录见归档设计文档 §2.1b)
# ⚠️ 不要往本表加 "Weight" —— 5.4 起所有 BSDF/Emission 的 Weight 改为
# .available(is_gpu_internal), 用户材质里永远不可用(node_shader_bsdf_principled.cc:89);
# 5.1.2 里它存在且默认 0, 加进来会得到一个能拖但无效果的滑条
BSDF_SLOT_ALIASES = {
    "color": ("Base Color", "Color"),
    "metallic": ("Metallic",),
    "roughness": ("Roughness",),
    "ior": ("IOR",),
    "emission_color": ("Emission Color", "Emissive Color"),
    "emission_strength": ("Emission Strength",),
    "emission_node_color": ("Color",),
    "emission_node_strength": ("Strength",),
}

# "自发光节点专属"两行的语义键(仅 EMISSION 节点可命中, 与 Principled 的 Emission Color 行互斥)
EMISSION_NODE_SEMANTICS = frozenset({"emission_node_color", "emission_node_strength"})

# 滑条拖动失控的插槽名(作者实测: 自发光强度一拖数值变化幅度巨大):
# 这些插槽的 RNA hard 范围是 ±3.4e38(soft ±10000), slider 模式下整个范围被压进控件宽度,
# 每像素数千的步进完全不可用; 故一律**不用滑条**(普通数值框, 走 soft 范围)
# - Emission Strength(Principled/原理化体积): hard ±3.4e38
# - IOR: hard ±3.4e38(与 5.4 的 .min(1.0) 不同, 5.1.2 无下限)
NO_SLIDER_SOCKETS = frozenset({"Emission Strength", "IOR"})

# PBR 检测的五个通道(作者口径: 基础色/金属度/粗糙度/法向/置换, 至少两个通道上游有图像纹理)
# - 前四项是 Principled 的插槽名, 末项是 Material Output 的插槽名
# - 顺序即"第一个命中"的判定顺序(作者决议 2: 坐标下拉只编辑第一个命中的通道)
PBR_CHANNELS = ("Base Color", "Metallic", "Roughness", "Normal", "Displacement")
# 前四项挂在 BSDF 上, 末项挂在 Material Output 上; 检测时按下标区分
PBR_CHANNEL_BSDF_COUNT = 4

# 材质面板坐标输出下拉的候选项(镜像枚举, 见 props.SceneHelperState.pbr_texcoord)
# - 三元组 (标识, 名称, 描述): EnumProperty items 的最小合法形态; 描述给英文(运行期不翻译)
# - 标识/名称一律 ASCII(pitfalls §9): 三项均为 Blender 节点原词, 系统词典已含
#   (Generated->生成 / UV->UV / Object->物体), 插件词典不得再收录
# - default 必须是整数下标(房规 15)
TEXCOORD_OPTIONS = (
    ("GENERATED", "Generated", "Use the Generated texture coordinate output"),
    ("UV", "UV", "Use the UV texture coordinate output"),
    ("OBJECT", "Object", "Use the Object texture coordinate output"),
)

# 枚举标识 -> Texture Coordinate 节点真实输出口名(注意 Object 的口名首字母大写,
# 与枚举标识 OBJECT 不同; 口名以 node_shader_tex_coord.cc 声明为准, 5.1/5.4 一致)
TEXCOORD_SOCKET_NAMES = {
    "GENERATED": "Generated",
    "UV": "UV",
    "OBJECT": "Object",
}

# 投影统一控制的候选项(作者要求: 所有 PBR 贴图统一控制, 见 props.SceneHelperState.pbr_projection)
# - 四项与 Image Texture.projection 的原生枚举一致(FLAT/BOX/SPHERE/TUBE, 探针实证)
# - 标识/名称一律 ASCII(pitfalls §9)
# - 不设 Mixed 哨兵项(作者 2026-10-19 定): 各图投影不一致时下拉**保持镜像原值不变**,
#   不再声称任何一张图的当前状态; 选定任一项即统一写全部命中纹理
PROJECTION_OPTIONS = (
    ("FLAT", "Flat", "Project the image flat along the axes"),
    ("BOX", "Box", "Project the image as a box, with blend between sides"),
    ("SPHERE", "Sphere", "Project the image spherically around the object"),
    ("TUBE", "Tube", "Project the image from the tube using the Z axis as central"),
)

# 上游追溯的最大深度(防节点组内部回接组输入造成环; 正常 PBR 链深度 <= 4)
TREE_TRACE_MAX_DEPTH = 8
