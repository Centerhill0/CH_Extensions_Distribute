import bpy

from .dictionary import common_dictionary

__dictionary__ = common_dictionary


def _get_language_code():
    return bpy.context.preferences.view.language


__language_code__ = _get_language_code()


def refresh_language():
    global __language_code__
    __language_code__ = _get_language_code()


# Dictionary for translation: https://docs.blender.org/api/current/bpy.app.translations.html
# {
#     "en_US": {
#         ("*", code1): "translation1",
#         ("Operator", code2): "translation2",
#     },
#     "zh_CN": {
#         ("*", key): "翻译",
#         ("*, key2): "翻译2"
#     }
# }

# NOTE: __dictionary__ 与 common_dictionary 是同一个对象(别名引用).
# load_dictionary/set_dictionary 必须原地 update, 不能用 " __dictionary__ = 新字典 " 重新赋值:
# bpy.app.translations.register 注册的是 common_dictionary 这个对象, 重新赋值后
# 新增条目不会出现在已注册的字典里, 翻译会静默失效.
# 插件侧也应保证先调用 load_dictionary 合并词条, 再调用 translations.register.

# Set a new dictionary for translation
def set_dictionary(new_dictionary: dict[str, dict[tuple, str]]):
    global __dictionary__
    __dictionary__ = new_dictionary


# Load additional dictionary for translation
def load_dictionary(additional_dictionary: dict[str, dict[tuple, str]]):
    global __dictionary__
    for key in additional_dictionary:
        if key in __dictionary__:
            __dictionary__[key].update(additional_dictionary[key])
        else:
            __dictionary__[key] = {}
            __dictionary__[key].update(additional_dictionary[key])


# 在需要拼接字符串的地方使用i18n函数
def i18n(content: str) -> str:
    global __language_code__, __dictionary__
    current_lang = _get_language_code()
    if current_lang != __language_code__:
        __language_code__ = current_lang
    if __language_code__ not in __dictionary__:
        return content
    tuple_contents = [("*", content), ("Operator", content)]
    for tuple_content in tuple_contents:
        if tuple_content in __dictionary__[__language_code__]:
            return __dictionary__[__language_code__][tuple_content]
    for key in __dictionary__[__language_code__]:
        if key[1] == content:
            return __dictionary__[__language_code__][key]
    return content
