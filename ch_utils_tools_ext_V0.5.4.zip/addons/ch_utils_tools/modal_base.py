"""
模态算子基类模块

收编原 utils 中的算子实例型辅助函数, 作为模态算子的 Mixin 基类.
算法层(utils)不再包含任何依赖算子实例的交互代码.

主要功能:
- ModalOperatorMixin: 模态算子 Mixin
  - 绘制属性初始化 (draw_init)
  - 鼠标与HUD坐标 (init_mouse_position / wrap_mouse_position / get_flick_dir)
  - 模态处理器生命周期 (init_modal_handlers / finish_modal_handlers)
  - 状态栏 (init_status / finish_status)
  - 计时器 (init_timer_modal / update_countdown / get_timer_progress)
  - 修饰键状态 (update_mod_keys)
  - HUD文本尺寸 (get_text_dimensions)

用法: 模态算子继承 Operator 与本 Mixin,
    class MyOperator(Operator, ModalOperatorMixin):
        ...
并以 self.xxx() 形式调用各辅助方法.
"""

import time

import bpy
import blf
from mathutils import Vector
from bpy.types import Context, Event
from bl_ui.space_statusbar import STATUSBAR_HT_header as statusbar
from bpy_extras.view3d_utils import location_3d_to_region_2d

from .preference import get_prefs
from .utils._constants import HUD_BASE_FONT_SIZE, HUD_DEFAULT_FONT_ID
from .utils.blender.scene import get_ui_scale
from .utils.drawing.gpu import set_hud_opacity


class ModalOperatorMixin:
    """
    模态算子 Mixin

    为模态 Operator 提供鼠标/HUD/状态栏/模态处理器/计时器/修饰键等交互辅助方法.
    约定: 算子在 invoke 中调用 self.draw_init() 与 self.init_mouse_position(event, hud=True)
    初始化绘制属性与鼠标坐标, 在 finish 流程中调用 self.finish_status() 与
    self.finish_modal_handlers() 清理.
    """

    @property
    def hud_scale(self) -> float:
        """HUD 缩放系数 = Blender UI缩放 * 插件偏好中的模态HUD缩放"""
        return get_ui_scale() * get_prefs().modal_hud_scale

    def draw_init(self) -> None:
        """初始化绘制属性, 供 draw_label(init_obj=self) 兜底读取"""
        self.offset = 0
        self.font_id = HUD_DEFAULT_FONT_ID
        self.size = HUD_BASE_FONT_SIZE
        self.color = (1.0, 1.0, 1.0)
        self.alpha = 1.0
        self.center = True

    def get_text_dimensions(self, text: str = "", font_id: int = HUD_DEFAULT_FONT_ID, size: int = HUD_BASE_FONT_SIZE) -> Vector:
        """
        获取指定文本在当前HUD缩放下的像素尺寸

        Args:
            text: 文本内容
            font_id: 字体ID
            size: 字号
        Returns:
            Vector: 文本像素宽高(width, height)
        """
        fontsize = int(size * self.hud_scale)
        blf.size(font_id, fontsize)
        return Vector(blf.dimensions(font_id, text))

    def init_mouse_position(self, event: Event, hud=False, hud_offset: tuple | None = None):
        """
        获取当前鼠标在区域中的像素坐标,并计算HUD显示位置

        Args:
            event: 事件对象,包含鼠标位置
            hud: 是否计算 HUD 坐标
            hud_offset: HUD 相对鼠标的像素偏移, None 时读取插件偏好中的偏移设置
        """
        self.mouse_window_pos = Vector((event.mouse_x, event.mouse_y))
        self.mouse_region_pos = Vector((event.mouse_region_x, event.mouse_region_y))
        self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y
        self.region_offset_x, self.region_offset_y = event.mouse_x - event.mouse_region_x, event.mouse_y - event.mouse_region_y
        if hud:
            if hud_offset is None:
                prefs = get_prefs()
                hud_offset = (prefs.modal_hud_offset_x, prefs.modal_hud_offset_y)
            ui_scale = self.hud_scale
            self.HUD_x = self.mouse_region_pos.x + hud_offset[0] * ui_scale
            self.HUD_y = self.mouse_region_pos.y + hud_offset[1] * ui_scale

    def wrap_mouse_position(self, context: Context, event: Event) -> bool:
        """
        当光标进入区域边缘的包裹带时,将光标包裹到对侧
        (是否包裹与包裹带宽度由偏好设置中的模态光标选项控制)

        边距定义包裹带宽度: 光标距任一边缘不足边距像素时,立即被包裹到对侧,
        落点在对侧包裹带外沿(防抖), 模态期间光标可在两缘间连续乒乓.
        窗口/区域偏移在本方法内现算, 因此不依赖调用方每帧执行 init_mouse_position.
        发生包裹时返回 True 并将位移基线重置到落点: 调用方应跳过本帧的数值更新,
        下一帧增量从落点重新起算, 避免光标跳变导致数值突变.

        Args:
            context: Blender 上下文
            event: 鼠标事件
        Returns:
            bool: 本帧是否发生了包裹
        """
        prefs = get_prefs()
        if not prefs.modal_cursor_wrap:
            return False
        mouse_x, mouse_y = event.mouse_region_x, event.mouse_region_y
        region_width, region_height = context.region.width, context.region.height
        margin = prefs.modal_cursor_wrap_margin
        # 窗口/区域偏移每帧现算: 模态期间改变布局(按 N 展侧栏,拖分隔条,缩放窗口)会改变该偏移,
        # 沿用 invoke 时的旧值会让包裹落点算错甚至落到区域外再次触发包裹.
        self.region_offset_x = event.mouse_x - event.mouse_region_x
        self.region_offset_y = event.mouse_y - event.mouse_region_y
        # 两缘包裹带重叠(区域过窄)时禁用该轴, 避免无限乒乓
        wrap_x = margin * 2 < region_width
        wrap_y = margin * 2 < region_height
        new_mouse_x, new_mouse_y = None, None
        if wrap_x:
            if mouse_x < margin:
                new_mouse_x = region_width + self.region_offset_x - margin
            elif mouse_x > region_width - margin:
                new_mouse_x = self.region_offset_x + margin
        if wrap_y:
            if mouse_y < margin:
                new_mouse_y = region_height + self.region_offset_y - margin
            elif mouse_y > region_height - margin:
                new_mouse_y = self.region_offset_y + margin

        if new_mouse_x is None and new_mouse_y is None:
            return False
        if new_mouse_x is None:
            new_mouse_x = event.mouse_x
        if new_mouse_y is None:
            new_mouse_y = event.mouse_y
        context.window.cursor_warp(new_mouse_x, new_mouse_y)
        self.last_mouse_x, self.last_mouse_y = new_mouse_x, new_mouse_y
        return True

    def get_flick_dir(self, context: Context, locked_axes: list[str] | None = None) -> str | None:
        """
        根据鼠标滑动方向计算最对齐的轴方向

        通过将3D轴投影到2D屏幕空间,计算鼠标滑动向量与各轴的对齐程度,
        返回最对齐的轴方向字符串.
        要求实例具有 init_mouse_3d, axes, flick_vector 属性.

        Args:
            context: Blender上下文
            locked_axes: 锁定的轴列表,如 ['X', 'Y', 'Z'],为None时返回None

        Returns:
            最对齐的轴方向字符串,如 'POSITIVE_X' 或 'NEGATIVE_Y',无锁定轴时返回None
        """

        def get_influence(axis_data: dict) -> float:
            """计算轴的影响力分数"""
            emphasis = 2
            return axis_data['dot'] * emphasis + axis_data['weight']

        if not locked_axes:
            return None

        origin_2d = location_3d_to_region_2d(context.region, context.region_data, self.init_mouse_3d, default=Vector((context.region.width / 2, context.region.height / 2)))

        axes_2d = {}

        for direction, axis in self.axes.items():
            _, axis_name = direction.split('_')

            if axis_name not in locked_axes:
                continue

            axis_2d = location_3d_to_region_2d(context.region, context.region_data, self.init_mouse_3d + axis, default=origin_2d)

            if (dir_vec := (axis_2d - origin_2d)).length:
                axes_2d[direction] = {'axis': dir_vec.normalized(), 'dot': 0, 'length': dir_vec.length, 'weight': 1}

        if not axes_2d:
            return None

        max_length = max(data['length'] for data in axes_2d.values())

        for data in axes_2d.values():
            data['weight'] = data['length'] / max_length
            data['dot'] = data['axis'].dot(self.flick_vector.xy.normalized())

        most_aligned = max(axes_2d.items(), key=lambda x: get_influence(x[1]))

        return most_aligned[0]

    def init_timer_modal(self):
        """
        为模态操作初始化计时器,设置 self.countdown 倒计时属性与 self.start 开始时间属性.
        要求实例具有 time 属性.
        """
        self.start = time.time()
        self.countdown = self.time * get_prefs().modal_hud_timeout

    def update_countdown(self):
        """更新计时器倒计时, 要求实例具有 start/time/countdown 属性"""
        self.countdown = self.time * get_prefs().modal_hud_timeout - (time.time() - self.start)

    def get_timer_progress(self):
        """获取计时进度(0~1), 要求实例具有 countdown/time 属性"""
        progress = self.countdown / (self.time * get_prefs().modal_hud_timeout)
        return progress

    def init_modal_handlers(self, context: Context, area=True, hud=False, view3d=False, timer=False, time_step=0.05, modal=True):
        """
        初始化模态操作相关的事件处理器和绘制回调

        Args:
            context: Blender 上下文
            area: 是否记录当前区域
            hud: 是否注册HUD像素绘制回调(要求实例具有 draw_HUD 方法)
            view3d: 是否注册3D视图绘制回调(要求实例具有 draw_VIEW3D 方法)
            timer: 是否添加定时器事件
            time_step: 定时器步长(秒)
            modal: 是否注册为模态处理器
        """
        if area:
            self.area = context.area
        if hud:
            self.HUD = _add_guarded_draw_handler(self.draw_HUD, context, 'POST_PIXEL')
        if view3d:
            self.VIEW3D = _add_guarded_draw_handler(self.draw_VIEW3D, context, 'POST_VIEW')
        if timer:
            if getattr(self, 'time', None):
                self.init_timer_modal()
            self.TIMER = context.window_manager.event_timer_add(time_step, window=context.window)
        if modal:
            context.window_manager.modal_handler_add(self)

    def finish_modal_handlers(self):
        """清理模态操作中注册的所有处理程序, 包括HUD绘制, VIEW3D绘制, 定时器事件"""
        if getattr(self, 'HUD', None):
            bpy.types.SpaceView3D.draw_handler_remove(self.HUD, 'WINDOW')
            self.HUD = None

        if getattr(self, 'VIEW3D', None):
            bpy.types.SpaceView3D.draw_handler_remove(self.VIEW3D, 'WINDOW')
            self.VIEW3D = None

        if getattr(self, 'TIMER', None):
            bpy.context.window_manager.event_timer_remove(self.TIMER)
            self.TIMER = None

    def init_status(self, context: Context, title='', func=None):
        """
        初始化状态栏显示函数, 附带异常退出后的自动还原保护

        Args:
            context: Blender 上下文
            title: 状态栏标题
            func: 自定义状态栏绘制函数(可选)
        """
        self.bar_orig = statusbar.draw
        statusbar.draw = _self_restoring_status(func if func else _draw_basic_status(title), self.bar_orig)

    def finish_status(self):
        """恢复原始状态栏绘制函数"""
        if hasattr(self, 'bar_orig'):
            statusbar.draw = self.bar_orig

    def update_mod_keys(self, event: Event | None = None, shift=True, ctrl=True, alt=True):
        """
        更新修饰键(Shift,Ctrl,Alt)的状态, 写入 is_shift/is_ctrl/is_alt 属性

        Args:
            event: Blender 事件对象,为None时重置为False
            shift: 是否检测 shift 键
            ctrl: 是否检测 ctrl 键
            alt: 是否检测 alt 键
        """
        if event is None:
            if shift:
                self.is_shift = False
            if ctrl:
                self.is_ctrl = False
            if alt:
                self.is_alt = False
            return

        if shift:
            self.is_shift = bool(getattr(event, "shift", False))
        if ctrl:
            self.is_ctrl = bool(getattr(event, "ctrl", False))
        if alt:
            self.is_alt = bool(getattr(event, "alt", False))


def _add_guarded_draw_handler(draw_method, context: Context, post_type: str):
    """
    注册带自清理保护的视图绘制回调

    模态算子中途异常退出时, Blender会释放算子实例但已注册的绘制回调仍在,
    之后每次重绘访问已释放实例都会抛出ReferenceError.
    此包装在捕获该错误时自动移除残留处理器, 避免持续报错.
    每次回调执行前将偏好中的HUD全局透明度同步到绘制层(gpu.set_hud_opacity),
    使绘制透明度实时跟随设置.

    Args:
        draw_method: 算子的绘制方法(已绑定实例)
        context: Blender上下文
        post_type: 绘制阶段('POST_PIXEL'或'POST_VIEW')
    Returns:
        object: 绘制处理器句柄
    """
    holder = []

    def draw(context: Context):
        set_hud_opacity(get_prefs().modal_hud_opacity)
        try:
            draw_method(context)
        except ReferenceError:
            if holder:
                try:
                    bpy.types.SpaceView3D.draw_handler_remove(holder[0], 'WINDOW')
                except ValueError:
                    pass
                holder.clear()

    holder.append(bpy.types.SpaceView3D.draw_handler_add(draw, (context,), 'WINDOW', post_type))
    return holder[0]


def _self_restoring_status(draw_func, bar_orig):
    """
    返回带自动还原保护的状态栏绘制回调

    模态算子异常退出后, 状态栏绘制回调中访问已释放实例会抛出ReferenceError,
    此时自动恢复原始状态栏绘制函数, 避免状态栏被残留回调永久占据.

    Args:
        draw_func: 状态栏绘制函数
        bar_orig: 原始状态栏绘制函数
    Returns:
        function: 带还原保护的状态栏绘制回调
    """

    def draw(self, context: Context):
        try:
            draw_func(self, context)
        except ReferenceError:
            statusbar.draw = bar_orig

    return draw


def _draw_basic_status(title: str):
    """
    基础状态栏绘制函数

    Args:
        title: 状态栏标题
    Returns:
        状态栏绘制回调函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)
        row.label(text=title)

        row.label(text="", icon='MOUSE_LMB')
        row.label(text="Finish")

        if context.window_manager.keyconfigs.active.name.startswith('blender'):
            row.label(text="", icon='MOUSE_MMB')
            row.label(text="Viewport")

        row.label(text="", icon='MOUSE_RMB')
        row.label(text="Cancel")

    return draw
