axis_items = [
    ('X', "X", ""),
    ('Y', "Y", ""),
    ('Z', "Z", ""),
]

sorted_axis_items = [
    ('0', "X", ""),
    ('1', "Y", ""),
    ('2', "Z", ""),
]

space_items = [
    ('LOCAL', "Local", ""),
    ('WORLD', "World", ""),
    ('CURSOR', "Cursor", ""),
]

processing_mode_items = [
    ('INDIVIDUAL', "Individual", ""),
    ('GROUP', "Group", ""),
]

interpolation_type_items = [
    ('KEY_LINEAR', "Linear", ""),
    ('KEY_CARDINAL', "Cardinal", ""),
    ('KEY_CATMULL_ROM', "Catmull-Rom", ""),
    ('KEY_BSPLINE', "BSpline", ""),
]

mod_apply_mode_items = [
    ('APPLY', "Apply Modifier", ""),
    ('REMOVE', "Remove Modifier", ""),
]

lattice_apply_mode_items = mod_apply_mode_items + [('TO_SHAPE_KEY', "Convert To Shape Key", "Convert Deformation into shape keys")]

align_direction_items = [
    ('Align_Right', "Align Right", ""),
    ('Align_Left', "Align Left", ""),
    ('Align_Up', "Align Up", ""),
    ('Align_Down', "Align Down", ""),
    ('Align_Center_H', "Align Center H", ""),
    ('Align_Center_V', "Align Center V", ""),
    ('Align_Center', "Align Center", ""),
]

align_type_items = [
    ('AVERAGE', "Average", ""),
    ('ZERO', "Zero", ""),
    ('CURSOR', "Cursor", ""),
]

face_snap_mode_items = [
    ('ALIGN', "Align Only", ""),
    ('PROXIMITY', "Snap to Nearest", ""),
    ('CENTER', "Snap to Face Center", ""),
]

edge_snap_mode_items = [
    ('ALIGN', "Align Only", ""),
    ('PROXIMITY', "Snap to Nearest", ""),
    ('CENTER', "Snap to Edge Midpoint", ""),
]

extrude_mode_items = [
    ('AVERAGE', 'Average', 'Extrude along Average Face Normals'),
    ('EDGE', 'Edge', 'Extrude along any chosen Edge of any Object'),
    ('NORMAL', 'Normal', 'Extrude along Individual Vertex Normals'),
    ('CURSOR', 'Cursor', 'Extrude along Cursor Axis'),
]

fuse_method_items = [
    ('FUSE', "Fuse", ""),
    ('BRIDGE', "Bridge", ""),
]

handle_method_items = [
    ('FACE', "Face", ""),
    ('LOOP', "Loop", ""),
]

tension_preset_items = [
    ('CUSTOM', "Custom", ""),
    ('0.55', "0.55", ""),
    ('0.7', "0.7", ""),
    ('1', "1", ""),
    ('1.33', "1.33", ""),
]

flatten_mode_items = [
    ('EDGE', "Along Edge", ""),
    ('NORMAL', "Along Normal", ""),
]

turn_items = [
    ('1', "1", ""),
    ('2', "2", ""),
    ('3', "3", ""),
]

edge_type_items = [
    ('SHARP', "Sharp", "Select sharp edges"),
    ('BEVEL_WEIGHT', "Bevel Weight", "Select edges with bevel weight"),
    ('SEAM', "Seam", "Select UV seam edges"),
    ('CREASE', "Crease", "Select edges with crease weight"),
    ('FREESTYLE', "Freestyle", "Select Freestyle marked edges"),
]

boolean_method_items = [
    ('INTERSECT', "Intersect", ""),
    ('UNION', "Union", ""),
    ('DIFFERENCE', "Difference", ""),
    ('SPLIT', "Split", ""),
]

boolean_solver_items = [
    ('FLOAT', "Float", ""),
    ('EXACT', "Exact", ""),
    ('MANIFOLD', "Manifold", ""),
]

cleanup_select_items = [
    ("NONE", "None", ""),
    ("NON-MANIFOLD", "Non-Manifold", ""),
    ("NON-PLANAR", "Non-Planar", ""),
    ("TRIS", "Tris", ""),
    ("NGONS", "Ngons", ""),
]
