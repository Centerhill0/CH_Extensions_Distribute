from typing import Callable

import bpy
import os
from bpy.types import AddonPreferences, Context, KeyConfig, UILayout
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty

from .config import __addon_name__
from .keymaps import addon_keymaps
from rna_keymap_ui import draw_kmi

# 菜单功能扩展(ExpandableUi 挂接原生菜单,无需注册快捷键)
_MENU_EXTENSIONS = [
    ("ShadingExpandPie (Z)", "Append Shade Smooth / Flat to shading pie"),
    ("ExtrudeMenuExpand (Alt + E)", "Append Hole Extrude / Wedge Extrude to edit mesh extrude menu"),
]


def _draw_menu_extensions(col: UILayout) -> None:
    """绘制菜单功能扩展简要说明"""
    col.separator(factor=0.5)
    col.label(text="Menu Extensions", icon="MENU_PANEL")
    for name, desc in _MENU_EXTENSIONS:
        col.label(text=name)
        row = col.row()
        row.separator()
        row.label(text=desc)


def _draw_hotkey_column(layout: UILayout, title: str, groups: list, kc: KeyConfig, footer: Callable | None = None) -> None:
    """绘制单列快捷键分组列表"""
    col = layout.box()
    col.label(text=title)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
            # draw_kmi(["ADDON", "USER", "DEFAULT"], kc, km, kmi, split, 0)
        row.separator(factor=1, type='LINE')
    if footer:
        footer(col)


class CHAddonPreferences(AddonPreferences):
    bl_idname = __addon_name__

    # ----------CameraPie属性----------
    # 切换相机时,是否将视图对齐到相机
    is_align: BoolProperty(name="Is Align", description="Align the selected camera", default=True)  # type: ignore
    # 设置为活动相机时,是否将视图对齐到相机
    is_align_view: BoolProperty(name="Is Align View", description="Align the view to the selected camera", default=False)  # type: ignore

    # ----------孔洞挤出属性----------
    non_manifold_extrude: BoolProperty(name="Non-manifold Extrude", description="Support non-manifold meshes", default=True)  # type: ignore

    # ----------对称工具属性----------
    # 模态滑动判定半径(像素): 鼠标离锚点超过该距离即确认轴向; 同时是滑动HUD圆圈的半径
    symmetrize_flick_distance: IntProperty(name="Flick Distance", description="Pixel distance from the anchor at which a flick is confirmed; also the radius of the flick HUD circle", default=100, min=10, max=1000)  # type: ignore

    # ----------模态HUD属性----------
    modal_hud_scale: FloatProperty(name="HUD Scale", description="Multiscale of HUD elements", default=1, min=0.1, max=10.0)  # type: ignore
    # HUD绘制全局透明度系数: 与各绘制调用自身的透明度相乘, 0 时HUD完全不可见
    modal_hud_opacity: FloatProperty(name="HUD Opacity", description="Global opacity multiplier applied to all modal HUD drawing (0 hides the HUD)", default=1.0, min=0.0, max=1.0, subtype='FACTOR')  # type: ignore
    modal_hud_timeout: FloatProperty(name="HUD Timeout", description="Modulate duration of fading HUD elements", default=1, min=0.1, max=10.0)  # type: ignore
    modal_hud_offset_x: IntProperty(name="HUD Offset X", description="HUD offset relative to the mouse (pixels, scaled by HUD Scale)", default=20, min=-500, max=500)  # type: ignore
    modal_hud_offset_y: IntProperty(name="HUD Offset Y", description="HUD offset relative to the mouse (pixels, scaled by HUD Scale)", default=20, min=-500, max=500)  # type: ignore

    # ----------模态光标属性----------
    # 模态操作中鼠标到达视图边缘时,是否将光标包裹到对面
    modal_cursor_wrap: BoolProperty(name="Cursor Wrap", description="Wrap the cursor to the opposite edge when it reaches the region boundary during modal operations", default=True)  # type: ignore
    # 光标包裹带宽度: 光标距任一边缘不足该距离(像素)时立即被包裹到对侧, 落点在对侧带外沿
    modal_cursor_wrap_margin: IntProperty(name="Cursor Wrap Margin", description="Wraps the cursor to the opposite edge as soon as it comes within this distance of any region edge (pixels); the cursor re-enters just outside the opposite band", default=10, min=1, max=200)  # type: ignore

    # --------------属性--------------
    # 面板模块切换: 设置 / 快捷键
    settings_tab: EnumProperty(
        name="Settings",
        items=[
            ('PREFERENCES', "Settings", "Camera and hole extrude settings", 'PREFERENCES', 0),
            ('HOTKEYS', "Hotkeys", "Registered hotkey list and menu extensions", 'KEYINGSET', 1),
        ],
        default='PREFERENCES',
    )  # type: ignore

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 模块切换按钮(从左到右: 设置 / 快捷键)
        row = layout.row()
        row.prop(self, "settings_tab", expand=True)

        if self.settings_tab == 'PREFERENCES':
            split = layout.split(factor=0.5)
            left = split.column()
            right = split.column()

            # 相机设置
            box = left.box()
            box.label(text="Camera Settings", icon="CAMERA_DATA")
            box.prop(self, "is_align")
            box.prop(self, "is_align_view")

            # 孔洞挤出设置(单一操作独有, 放左侧)
            box = left.box()
            box.label(text="Hole Extrude Settings", icon="MOD_BOOLEAN")
            box.prop(self, "non_manifold_extrude")

            # 对称工具设置(单一操作独有, 放左侧)
            box = left.box()
            box.label(text="Symmetrize Settings", icon="MOD_MIRROR")
            box.prop(self, "symmetrize_flick_distance")

            # 模态HUD设置(多个模态算子共用, 放右侧)
            box = right.box()
            box.label(text="Modal HUD Settings", icon="OVERLAY")
            box.prop(self, "modal_hud_scale")
            box.prop(self, "modal_hud_opacity")
            box.prop(self, "modal_hud_timeout")
            row = box.row(align=True)
            row.prop(self, "modal_hud_offset_x", text="Offset X")
            row.prop(self, "modal_hud_offset_y", text="Offset Y")

            # 模态光标设置(多个模态算子共用, 放右侧)
            box = right.box()
            box.label(text="Modal Cursor Settings", icon="CURSOR")
            box.prop(self, "modal_cursor_wrap")
            box.prop(self, "modal_cursor_wrap_margin")

        else:
            # 快捷键列表(独立 Ops 在左,饼菜单在右)
            box = layout.box()
            independent_groups = []
            pie_groups = []
            for name, items in addon_keymaps.items():
                if name.lower().endswith('pie'):
                    pie_groups.append((name, items))
                else:
                    independent_groups.append((name, items))

            columns = box.split(factor=0.5)
            _draw_hotkey_column(columns.column(), "Operators", independent_groups, kc, footer=_draw_menu_extensions)
            _draw_hotkey_column(columns.column(), "Pie Menus", pie_groups, kc)


def get_prefs() -> CHAddonPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences


def get_path() -> str:
    return os.path.dirname(os.path.dirname(os.path.realpath(__file__)))


def get_name() -> str:
    return os.path.basename(get_path())
