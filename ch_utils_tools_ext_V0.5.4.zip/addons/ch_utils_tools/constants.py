"""
插件级共享常量模块

物体类型/模式集合与绘制用颜色元组的统一定义点.
"""

# 列出所有物体类型----------------------------------------------------------------------------------------------------------------------
# print("物体类型:", [item.identifier for item in bpy.types.Object.bl_rna.properties['type'].enum_items])
ALL_OBJ_TYPES = {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'CURVES', 'POINTCLOUD', 'VOLUME', 'GREASEPENCIL', 'ARMATURE', 'LATTICE', 'EMPTY', 'LIGHT', 'LIGHT_PROBE', 'CAMERA', 'SPEAKER'}

# 列出context.object.mode所有模式:https://docs.blender.org/api/current/bpy_types_enum_items/object_mode_items.html#rna-enum-object-mode-items
# print("模式(context.object.mode):", [item.identifier for item in bpy.types.Object.bl_rna.properties['mode'].enum_items])

# 列出context.mode所有模式:https://docs.blender.org/api/current/bpy_types_enum_items/context_mode_items.html#rna-enum-context-mode-items
# print("模式(context.mode):", [item.identifier for item in bpy.types.Context.bl_rna.properties['mode'].enum_items])


# 有两种以上模式的物体,按tab键弹出饼菜单切换
OBJ_TYPES_WITH_PIE = {'MESH', 'CURVES', 'ARMATURE', 'GREASEPENCIL'}

## 对应的编辑模式
MESH_OBJ_ALL_MODES = {'OBJECT', 'EDIT_MESH', 'PAINT_TEXTURE', 'PAINT_WEIGHT', 'PAINT_VERTEX', 'SCULPT', 'PARTICLE'}  # 网格物体有七种模式(context.mode)
## {'OBJECT', 'EDIT', 'TEXTURE_PAINT', 'WEIGHT_PAINT', 'VERTEX_PAINT', 'SCULPT', 'PARTICLE_EDIT'} # (context.object.mode)
CURVES_OBJ_ALL_MODES = {'OBJECT', 'EDIT_CURVES', 'SCULPT_CURVES'}  # 毛发曲线对象有三种模式(context.mode)
## {'OBJECT', 'EDIT', 'SCULPT_CURVES'}  # (context.object.mode)
ARMATURE_OBJ_ALL_MODES = {'OBJECT', 'EDIT_ARMATURE', 'POSE'}  # 骨架有三种模式(context.mode)
## {'OBJECT', 'EDIT', 'POSE'}  # (context.object.mode)
GP_OBJ_ALL_MODES = {'OBJECT', 'EDIT_GREASE_PENCIL', 'PAINT_GREASE_PENCIL', 'WEIGHT_GREASE_PENCIL', 'VERTEX_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'}  # GP蜡笔有六种模式(context.mode)
## {'OBJECT', 'EDIT', 'PAINT_GREASE_PENCIL', 'WEIGHT_GREASE_PENCIL', 'VERTEX_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'}  (context.object.mode) # Blender 4.3+

# 只有物体&编辑模式两种物体模式的物体,按tab键直接切换
OBJ_TYPES_TAB_DIR = {'CURVE', 'SURFACE', 'FONT', 'META', 'LATTICE', 'POINTCLOUD'}
## OBJ_TYPES_TAB_DIR_MODES = {'EDIT_CURVE', 'EDIT_SURFACE', 'EDIT_TEXT', 'EDIT_METABALL', 'EDIT_LATTICE', 'EDIT_POINT_CLOUD'}(对应的编辑模式context.mode)

# 只有物体模式的物体,按Tab键无动作
OTHER_OBJ_TYPES = {'VOLUME', 'EMPTY', 'LIGHT', 'LIGHT_PROBE', 'CAMERA', 'SPEAKER'}

# 支持改变物体原点的物体类型:
ORIGIN_EDIT_SUPPORT_TYPES = ALL_OBJ_TYPES - OTHER_OBJ_TYPES

# ---- 颜色 (GPU绘制用基础色) ----
normal = (0.5, 0.5, 1)  # 正常颜色
red = (1, 0.25, 0.25)  # 红色
green = (0.25, 1, 0.25)  # 绿色
blue = (0.25, 0.25, 1)  # 蓝色
cyan = (0, 1, 1)  # 青色
magenta = (1, 0, 1)  # 品红色
yellow = (1, 0.9, 0.2)  # 黄色
black = (0, 0, 0)  # 黑色
white = (1, 1, 1)  # 白色
grey = (0.5, 0.5, 0.5)  # 灰色
deep_grey = (0.35, 0.35, 0.35)  # 深灰色
orange = (1, 0.6, 0.2)  # 橙色
light_red = (1, 0.65, 0.65)  # 浅红色
light_green = (0.75, 1, 0.75)  # 浅绿色
light_blue = (0.7, 0.9, 1)  # 浅蓝色
deep_green = (0.35, 0.8, 0.35)  # 深绿色
violet = (0.5, 0.25, 1)  # 紫色
