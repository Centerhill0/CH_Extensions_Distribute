"""
快捷键管理模块

提供以下功能:
- 定义插件的快捷键配置
- 注册和注销快捷键映射

快捷键分组:

独立Ops
- CODE_EXECUTE: 代码执行操作 (Ctrl + F3)
- SWITCH_LANGUAGE: 语言切换 (Button 5)

- SYMMETRIZE: 对称操作 (Alt + X)
- MATERIAL_PICKER: 材质拾取和分配操作 (网格编辑模式Alt + Shift + E)

饼菜单
- MODES_PIE: 模式切换饼菜单 (Tab)
- EDIT_PIE: 物体编辑模式饼菜单 (Shift + Q)
- SELECT_PIE: 选择饼菜单 (Ctrl + W)
- OVERLAYS_PIE: 叠加层显示饼菜单 (Ctrl + Alt + Z)
- DELETE_PIE: 删除饼菜单 (X)
- CLEAN_UP_PIE: 清理饼菜单 (Shift + X)
- ALIGN_PIE: 对齐饼菜单 (Ctrl + Alt + A)
- CAMERA_PIE: 相机饼菜单 (Alt + C)
- LIGHT_PIE: 灯光饼菜单 (Alt + L)
- ADD_MODIFIER_PIE: 修改器饼菜单 (Alt + K)
- CURSOR_AND_ORIGIN_PIE: 游标和原点饼菜单 (Shift + S)
- TEMP_EDITOR_PIE: 临时编辑器饼菜单 (\\)


其它功能扩展:(无需注册)
- ShadingExpandPie (Z)
- ExtrudeMenuExpand (网格编辑模式Alt + E)
    - Hole Extrude
    - Wedge Extrude
"""

import bpy
from typing import Dict, List, Tuple, Any

from bpy.types import KeyMap, KeyMapItem


# ============================================================
# 快捷键配置数据
# ============================================================
keymap_items: Dict[str, List[Dict[str, Any]]] = {
    # 代码执行 (Ctrl + F3)
    'CODE_EXECUTE': [
        {'label': 'Window', 'keymaps_name': 'Window', 'id_name': "ch.code_execute", 'type': 'F3', 'value': 'PRESS', 'ctrl': True},
    ],
    # 语言切换 (鼠标侧键5)
    'SWITCH_LANGUAGE': [
        {'label': 'Window', 'keymaps_name': 'Window', 'id_name': "ch.switch_language", 'type': 'BUTTON5MOUSE', 'value': 'PRESS'},
    ],
    # 对称操作 (Alt + X)
    'SYMMETRIZE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'ch.object_symmetrize', 'type': 'X', 'value': 'PRESS', 'alt': True},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'ch.editmesh_symmetrize', 'type': 'X', 'value': 'PRESS', 'alt': True},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'ch.editcurve_symmetrize', 'type': 'X', 'value': 'PRESS', 'alt': True},
    ],
    # 材质拾取和分配操作 (Alt + Shift + E)
    'MATERIAL_PICKER': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'ch.material_picker', 'type': 'E', 'value': 'PRESS', 'alt': True, 'shift': True},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'ch.material_picker', 'type': 'E', 'value': 'PRESS', 'alt': True, 'shift': True},
    ],
    # 模式切换饼菜单 (Tab)
    'MODES_PIE': [
        {'label': '3D View', 'keymaps_name': 'Object Non-modal', 'id_name': 'ch.modes_toggle', 'type': 'TAB', 'value': 'PRESS'},
        {'label': 'Image & UV Editor', 'keymaps_name': 'Image', 'space_type': 'IMAGE_EDITOR', 'id_name': 'wm.call_menu_pie', 'type': 'TAB', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_imageuv_modes_switch_pie"}},
    ],
    # 编辑模式饼菜单 (Shift + Q)
    'EDIT_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_object_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editcurve_pie"}},
        {'label': 'Edit_Armature', 'keymaps_name': 'Armature', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editarmature_pie"}},
        {'label': 'Pose', 'keymaps_name': 'Pose', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_pose_pie"}},
    ],
    # 选择饼菜单 (Ctrl + W)
    'SELECT_PIE': [
        {'label': 'Select Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_object_select_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_select_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_editcurve_select_pie"}},
        {'label': 'Edit_Armature', 'keymaps_name': 'Armature', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_editarmature_select_pie"}},
        {'label': 'Pose', 'keymaps_name': 'Pose', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_pose_select_pie"}},
    ],
    # 覆盖显示饼菜单 (Ctrl + Alt + Z)
    'OVERLAYS_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_object_overlays_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_overlays_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_editcurve_overlays_pie"}},
        {'label': 'Edit_Armature', 'keymaps_name': 'Armature', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_armature_overlays_pie"}},
        {'label': 'Pose', 'keymaps_name': 'Pose', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_armature_overlays_pie"}},
    ],
    # 删除饼菜单 (X)
    'DELETE_PIE': [
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_editmesh_delete_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_editcurve_delete_pie"}},
    ],
    # 清理饼菜单 (Shift + X)
    'CLEAN_UP_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_object_cleanup_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_cleanup_pie"}},
    ],
    # 对齐饼菜单 (Ctrl + Alt + A)
    'ALIGN_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'A', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_object_align_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'A', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_align_pie"}},
        {'label': 'Node', 'keymaps_name': 'Node Editor', 'space_type': 'NODE_EDITOR', 'id_name': 'wm.call_menu_pie', 'type': 'A', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "NODE_MT_ch_node_align_pie"}},
    ],
    # 相机辅助饼菜单 (Alt + C)
    'CAMERA_PIE': [
        {'label': 'Object', 'keymaps_name': '3D View', 'space_type': 'VIEW_3D', 'id_name': 'wm.call_menu_pie', 'type': 'C', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_camera_pie"}},
    ],
    # 灯光饼菜单 (Alt + L)
    'LIGHT_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'L', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_light_pie"}},
    ],
    # 添加修改器饼菜单 (Alt + K)
    'ADD_MODIFIER_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'K', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_add_modifier_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'K', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_add_modifier_pie"}},
    ],
    # 游标和原点饼菜单 (Shift + S)
    'CURSOR_AND_ORIGIN_PIE': [
        {'label': '3D View', 'keymaps_name': '3D View', 'space_type': 'VIEW_3D', 'id_name': 'wm.call_menu_pie', 'type': 'S', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_cursor_and_origin_pie"}},
        {'label': 'Edit_Grease_Pencil', 'keymaps_name': 'Grease Pencil Edit Mode', 'id_name': 'wm.call_menu_pie', 'type': 'S', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_cursor_and_origin_pie"}},
    ],
    # 临时编辑器饼菜单 (Back Slash)
    'TEMP_EDITOR_PIE': [
        {'label': 'Window', 'keymaps_name': 'Window', 'space_type': 'EMPTY', 'id_name': 'wm.call_menu_pie', 'type': 'BACK_SLASH', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_open_temp_editor_pie"}},
    ],
}

# 已注册的快捷键存储字典
# 格式: {分组名: [(显示标签, KeyMap, KeyMapItem), ...]}
addon_keymaps: Dict[str, List[Tuple[str, KeyMap, KeyMapItem]]] = {}


# ============================================================
# 快捷键注册/注销函数
# ============================================================


def register_keymaps() -> None:
    """
    注册插件的快捷键

    遍历 keymap_items 配置,为每个条目创建键映射和键映射项,
    并存储到 addon_keymaps 字典中以便后续注销.

    幂等: 入口先清掉上一代条目. addon_keymaps 按分组名覆盖写入,
    若不清上一代, 旧 KeyMapItem 会失去句柄但仍在 keyconfigs.addon 中继续生效,
    造成同一快捷键触发多次且再也无法注销.
    """
    unregister_keymaps()

    kc = bpy.context.window_manager.keyconfigs.addon
    if not kc:
        return

    for km_name, km_entries in keymap_items.items():
        entries: List[Tuple[str, KeyMap, KeyMapItem]] = []

        for entry in km_entries:
            # 创建键映射
            km = kc.keymaps.new(name=entry['keymaps_name'], space_type=entry.get('space_type', 'EMPTY'))

            # 创建键映射项
            kmi = km.keymap_items.new(
                idname=entry['id_name'],
                type=entry['type'],
                value=entry['value'],
                shift=entry.get('shift', False),
                ctrl=entry.get('ctrl', False),
                alt=entry.get('alt', False),
            )

            # 设置操作属性(如菜单名称)
            if 'properties' in entry:
                for prop, value in entry['properties'].items():
                    setattr(kmi.properties, prop, value)

            # 格式化显示标签(添加缩进用于 UI 显示)
            display_label = ' ' * 6 + entry['label']
            entries.append((display_label, km, kmi))

        # 格式化分组名称并存储
        formatted_name = km_name.capitalize().replace('_', ' ')
        addon_keymaps[formatted_name] = entries


def unregister_keymaps() -> None:
    """
    注销插件的快捷键

    遍历 addon_keymaps 字典,移除所有已注册的键映射项,
    并清空存储字典.

    注意: KeyMapItem/KeyMap 被移除后再访问会抛 ReferenceError(而非 RuntimeError/KeyError),
    用户在偏好"快捷键"页删掉任一条目后即产生这种失效句柄; 必须一并吞掉该异常,
    且 addon_keymaps.clear() 放在 finally 中 —— 否则字典残留失效句柄,
    之后每次禁用都在同一条目再次抛错, 插件再也无法干净禁用.
    """
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        if not kc:
            return

        for km_name, entries in addon_keymaps.items():
            for _, km, kmi in entries:
                try:
                    km.keymap_items.remove(kmi)
                except (RuntimeError, KeyError, ReferenceError):
                    pass
    finally:
        # 清空存储字典(无论移除是否成功, 都不能留下失效句柄)
        addon_keymaps.clear()


def get_keymap_items() -> Dict[str, List[Dict[str, Any]]]:
    """
    获取快捷键配置数据

    Returns:
        Dict: 快捷键配置字典
    """
    return keymap_items


def get_registered_keymaps() -> Dict[str, List[Tuple[str, KeyMap, KeyMapItem]]]:
    """
    获取已注册的快捷键

    Returns:
        Dict: 已注册的快捷键字典
    """
    return addon_keymaps.copy()
