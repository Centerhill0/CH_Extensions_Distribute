"""
叠加层饼菜单模块

提供以下功能:
- ObjectOverlaysPie:物体模式
- EditMeshOverlaysPie:网格编辑模式
- EditCurveOverlaysPie:曲线编辑模式
- ArmatureOverlaysPie:骨架编辑/姿态
"""

from bpy.types import Menu, Context, UILayout


# ============================================================
# 物体模式叠加层
# ============================================================
class ObjectOverlaysPie(Menu):
    """
    物体模式叠加层饼菜单

    在物体模式下提供叠加层设置:
    - 变换选项(原点,仅位置,父子变换)
    - 查看器属性和面朝向
    - 线框显示
    - 视口控制器

    要求: 物体模式
    """

    bl_idname = "VIEW3D_MT_ch_object_overlays_pie"
    bl_label = "CH Object Overlays Pie"
    bl_description = "Overlays Pie Menu in Object Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()
        pie.scale_x = 1.3
        pie.scale_y = 1.5

        # 左:变换选项
        col = pie.column(align=False)
        col.ui_units_x = 4
        col.prop(context.scene.tool_settings, "use_transform_data_origin", text="Transform Origins", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.scene.tool_settings, "use_transform_pivot_point_align", text="Only Locations", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.scene.tool_settings, "use_transform_skip_children", text="Transform Parents", icon='NONE')

        # 右:查看器和面朝向
        col = pie.column(align=False)
        col.ui_units_x = 4
        col.prop(context.space_data.overlay, "show_viewer_attribute", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_face_orientation", text="Face Orientation", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_viewer_text", text="Attribute Text", icon='NONE')

        # 下:视口控制器
        ObjectOverlaysPie.tool_setting_draw(context, pie)

        # 上:线框显示
        col = pie.column(align=False)
        col.ui_units_x = 8
        row = col.row(align=True)
        row.prop(context.space_data.shading, "show_backface_culling", icon='NONE')
        row.prop(context.space_data.shading, "show_cavity", icon='NONE')
        row = col.row(align=True)
        row.prop(context.space_data.overlay, "show_wireframes", text="Wireframe", icon='NONE')
        row.prop(context.space_data.overlay, "wireframe_threshold")

    @staticmethod
    def _orientation_draw(context: Context, col: UILayout):
        """绘制变换坐标系切换按钮(Global/Local/Normal)"""
        # GLOBAL按钮
        op_global = col.operator("wm.context_set_string", text="Global", depress=(context.scene.transform_orientation_slots[0].type == 'GLOBAL'), icon='ORIENTATION_GLOBAL')
        op_global.data_path = "scene.transform_orientation_slots[0].type"
        op_global.value = "GLOBAL"
        col.separator(factor=2.0)
        # LOCAL按钮
        op_local = col.operator("wm.context_set_string", text="Local", depress=(context.scene.transform_orientation_slots[0].type == 'LOCAL'), icon='ORIENTATION_LOCAL')
        op_local.data_path = "scene.transform_orientation_slots[0].type"
        op_local.value = "LOCAL"
        col.separator(factor=2.0)
        # NORMAL按钮
        op_normal = col.operator("wm.context_set_string", text="Normal", depress=(context.scene.transform_orientation_slots[0].type == 'NORMAL'), icon='ORIENTATION_NORMAL')
        op_normal.data_path = "scene.transform_orientation_slots[0].type"
        op_normal.value = "NORMAL"

    @staticmethod
    def tool_setting_draw(context: Context, pie: UILayout):
        """绘制视口控制器设置"""
        col = pie.column(align=True)
        row = col.split(factor=0.28)
        row.separator()
        row.label(text="Viewport Gizmos")

        box = col.box()
        box.scale_x = 1.2
        split = box.split(factor=0.3)
        split.prop(context.space_data, "show_gizmo_context", text="", icon='GIZMO')
        split.prop(context.space_data, "show_gizmo_object_translate", text="", icon='EMPTY_ARROWS')
        split.prop(context.space_data, "show_gizmo_object_rotate", text="", icon='DRIVER_ROTATIONAL_DIFFERENCE')
        split.prop(context.space_data, "show_gizmo_object_scale", text="", icon='FULLSCREEN_ENTER')


# ============================================================
# 网格编辑模式叠加层
# ============================================================
class EditMeshOverlaysPie(Menu):
    """
    网格编辑模式叠加层饼菜单

    在网格编辑模式下提供叠加层设置:
    - 索引,边长,权重显示
    - 查看器属性和面朝向
    - 法线显示
    - 视口控制器

    要求: 网格编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editmesh_overlays_pie"
    bl_label = "CH Edit Mesh Overlays Pie"
    bl_description = "Overlays Pie Menu in MeshEdit Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()
        pie.scale_x = 1.3
        pie.scale_y = 1.5

        # 左:测量和权重
        col = pie.column(align=False)
        col.ui_units_x = 4
        if hasattr(context.space_data.overlay, "show_extra_indices"):
            col.prop(context.space_data.overlay, "show_extra_indices", text="Indices")
            col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_extra_edge_length", text="Edge Length", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_weight", text="Weight")

        # 右:查看器和面朝向
        col = pie.column(align=False)
        col.ui_units_x = 4
        col.prop(context.space_data.overlay, "show_viewer_attribute", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_face_orientation", text="Face Orientation", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_viewer_text", text="Attribute Text", icon='NONE')

        # 下:视口控制器
        ObjectOverlaysPie.tool_setting_draw(context, pie)

        # 上:法线显示
        col = pie.column(align=False)
        col.ui_units_x = 8
        row = col.row(align=True)
        row.prop(context.space_data.shading, "show_backface_culling", icon='NONE')
        row.prop(context.space_data.shading, "show_cavity", icon='NONE')

        row = col.row(align=True)
        row.prop(context.space_data.overlay, "show_vertex_normals", text="", icon='NORMALS_VERTEX')
        row.prop(context.space_data.overlay, "show_split_normals", text="", icon='NORMALS_VERTEX_FACE')
        row.prop(context.space_data.overlay, "show_face_normals", text="", icon='NORMALS_FACE')
        row.prop(context.space_data.overlay, "normals_length", text="Size")


# ============================================================
# 曲线编辑模式叠加层
# ============================================================
class EditCurveOverlaysPie(Menu):
    """
    曲线编辑模式叠加层饼菜单

    在曲线编辑模式下提供叠加层设置:
    - 变换坐标系切换
    - 查看器属性和面朝向
    - 手柄显示和法线
    - 视口控制器

    要求: 曲线编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editcurve_overlays_pie"
    bl_label = "CH Edit Curve Overlays Pie"
    bl_description = "Overlays Pie Menu in CurveEdit Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_CURVE'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()
        pie.scale_x = 1.3
        pie.scale_y = 1.5

        # 左:变换坐标系
        col = pie.column(align=False)
        col.ui_units_x = 4
        ObjectOverlaysPie._orientation_draw(context, col)

        # 右:查看器和面朝向
        col = pie.column(align=False)
        col.ui_units_x = 4
        col.prop(context.space_data.overlay, "show_viewer_attribute", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_face_orientation", text="Face Orientation", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_viewer_text", text="Attribute Text", icon='NONE')

        # 下:视口控制器
        ObjectOverlaysPie.tool_setting_draw(context, pie)

        # 上:手柄和法线
        col = pie.column(align=False)
        col.ui_units_x = 8

        row = col.row(align=True)
        row.scale_y = 0.8
        row.label(text="Handles:")
        row.prop(context.space_data.overlay, "display_handle", expand=True)

        row = col.row(align=True)
        row.prop(context.space_data.overlay, "show_curve_normals", text="")
        row.prop(context.space_data.overlay, "normals_length")


# ============================================================
# 骨架编辑/姿态模式叠加层
# ============================================================
class ArmatureOverlaysPie(Menu):
    """
    骨架叠加层饼菜单

    在骨架编辑/姿态模式下提供叠加层设置:
    - 变换坐标系切换
    - 查看器属性和面朝向
    - X光骨骼显示(姿态模式)
    - 视口控制器

    要求: 骨架编辑模式或姿态模式
    """

    bl_idname = "VIEW3D_MT_ch_armature_overlays_pie"
    bl_label = "CH Armature Overlays Pie"
    bl_description = "Overlays Pie Menu in Armature Object"

    @classmethod
    def poll(cls, context: Context):
        return context.mode in {'EDIT_ARMATURE', 'POSE'}

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()
        pie.scale_x = 1.3
        pie.scale_y = 1.5

        # 左:变换坐标系
        col = pie.column(align=False)
        col.ui_units_x = 4
        ObjectOverlaysPie._orientation_draw(context, col)

        # 右:查看器和面朝向
        col = pie.column(align=False)
        col.ui_units_x = 4
        col.prop(context.space_data.overlay, "show_viewer_attribute", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_face_orientation", text="Face Orientation", icon='NONE')
        col.separator(factor=2.0)
        col.prop(context.space_data.overlay, "show_viewer_text", text="Attribute Text", icon='NONE')

        # 下:视口控制器
        ObjectOverlaysPie.tool_setting_draw(context, pie)

        # 上:X光骨骼(姿态模式)
        if context.mode == 'POSE':
            col = pie.column(align=False)
            col.ui_units_x = 6
            row = col.row(align=True)
            row.prop(context.space_data.overlay, "show_xray_bone", text="")
            row.prop(context.space_data.overlay, "xray_alpha_bone")
