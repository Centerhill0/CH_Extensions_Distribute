"""
清理功能饼菜单模块

提供以下功能:
- ObjectCleanUpPie:物体模式
- EditMeshCleanUpPie:网格编辑模式
"""

from bpy.types import Menu, Context

from ...operators.mesh.cleanup import MeshCleanUp


# ============================================================
# 物体模式清理饼菜单
# ============================================================
class ObjectCleanUpPie(Menu):
    """
    物体模式清理饼菜单

    在物体模式下提供清理操作:
    - 删除物体(全局删除)
    - 从集合移除物体
    - 清理未使用的数据
    - 移除未使用的材质槽
    - 清理顶点组权重
    """

    bl_idname = "VIEW3D_MT_ch_object_cleanup_pie"
    bl_label = "CH Object CleanUp Pie"
    bl_description = "CleanUp Pie Menu in Object Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 左,右,下,上
        pie.operator("object.delete", text="Delete Global").use_global = True
        pie.operator("collection.objects_remove")
        pie.operator("outliner.orphans_purge", text="Purge Unused Data...")
        pie.operator("object.material_slot_remove_unused", text="Remove Unused Material Slots")

        # 左上,右上
        pie.operator("object.material_slot_remove_all")
        pie.separator()

        # 左下:文件相关操作
        col = pie.column()
        col.operator("file.report_missing_files")
        col.operator("file.find_missing_files")

        # 右下:顶点组清理操作
        col = pie.column()
        col.operator("object.vertex_group_clean", text="Clean Vertex Group Weights").group_select_mode = 'ALL'
        col.operator("object.vertex_group_limit_total", text="Limit Total Vertex Groups").group_select_mode = 'ALL'


# ============================================================
# 网格编辑模式清理饼菜单
# ============================================================
class EditMeshCleanUpPie(Menu):
    """
    网格编辑模式清理饼菜单

    在网格编辑模式下提供清理操作:
    - 有限溶解
    - 平面化
    - 填充孔洞
    - 删除松散元素
    - 简化网格
    - 溶解退化面
    """

    bl_idname = "VIEW3D_MT_ch_editmesh_cleanup_pie"
    bl_label = "CH Edit Mesh CleanUp Pie"
    bl_description = "CleanUp Pie Menu in MeshEdit Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 左
        col = pie.column()
        col.scale_x = 1.2
        col.scale_y = 1.5
        col.operator('mesh.dissolve_degenerate')
        col.operator('mesh.dissolve_limited')

        # 右
        col = pie.column()
        col.scale_x = 1.2
        col.scale_y = 1.5
        col.operator('mesh.vert_connect_concave')
        col.operator('mesh.fill_holes')

        # 下
        pie.operator('mesh.delete_loose')

        # 上
        pie.operator(MeshCleanUp.bl_idname)

        # 左上
        pie.operator('mesh.decimate')

        # 右上
        pie.operator('mesh.remove_doubles')

        # 左下
        pie.operator('mesh.face_make_planar')

        # 右下
        pie.operator('mesh.vert_connect_nonplanar')
