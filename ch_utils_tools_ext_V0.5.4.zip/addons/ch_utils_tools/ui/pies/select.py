"""
选择饼菜单模块

提供以下功能:
- ObjectSelectPie:物体选择
- EditMeshSelectPie:网格编辑选择
- EditCurveSelectPie:曲线编辑选择
- EditArmatureSelectPie:骨架编辑选择
- PoseSelectPie:姿态模式选择
"""

import bpy
from bpy.types import Menu, Context
from ...operators.mesh.smart_select import VSelect, SSelect, LSelect


# ============================================================
# 物体模式选择饼菜单
# ============================================================
class ObjectSelectPie(Menu):
    """
    物体选择饼菜单

    提供各种选择操作的快捷选项.
    支持物体选择,网格编辑选择,曲线编辑选择等.
    """

    bl_idname = "VIEW3D_MT_ch_object_select_pie"
    bl_label = "CH Object Select Pie"
    bl_description = "Object Select Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and context.active_object is not None

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:按类型选择
        pie.operator("object.select_by_type", text="Select All by Type")

        # 右:选择相连元素
        col = pie.column()
        col.label(text="Select Linked")
        box = col.box()
        col = box.column()
        col.operator("object.select_linked", text="Object Data").type = 'OBDATA'
        col.operator("object.select_linked", text="Material").type = 'MATERIAL'
        col.operator("object.select_linked", text="Instanced Collection").type = 'DUPGROUP'
        col.operator("object.select_linked", text="Particle System").type = 'PARTICLE'
        col.operator("object.select_linked", text="Library").type = 'LIBRARY'
        col.operator("object.select_linked", text="Library (Object Data)").type = 'LIBRARY_OBDATA'

        # 下:Misc
        col = pie.column()
        col.separator()
        row = col.row(align=False)
        row.operator("object.select_grouped", text="Collection").type = 'COLLECTION'
        row.operator("object.select_grouped", text="Children").type = 'CHILDREN_RECURSIVE'
        row.operator("object.select_grouped", text="Parent").type = 'PARENT'

        # 上:按名称
        pie.operator("object.select_pattern", text="Select Pattern...")

        # 左上:随机,镜像
        col = pie.column()
        row = col.row(align=True)
        row.operator("object.select_mirror", text="Select Mirror")
        row.separator(factor=0.3)
        row.operator("object.select_random", text="Select Random")

        # 右上
        pie.separator()

        # 左下:按组
        pie.operator("object.select_grouped", text="Select Grouped")


# ============================================================
# 网格编辑选择饼菜单
# ============================================================
class EditMeshSelectPie(Menu):
    """
    网格编辑选择饼菜单

    提供网格编辑模式下的选择操作快捷选项.
    """

    bl_idname = "VIEW3D_MT_ch_editmesh_select_pie"
    bl_label = "CH Edit Mesh Select Pie"
    bl_description = "Edit Mesh Select Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH' and context.active_object is not None

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:按特征
        pie.operator("wm.call_menu", text="Select All by Trait").name = "VIEW3D_MT_edit_mesh_select_by_trait"

        # 右:选择相连元素
        col = pie.column()
        col.label(text="Select Linked")
        box = col.box()
        col = box.column()
        col.operator("mesh.select_linked", text="Linked")
        col.operator("mesh.shortest_path_select", text="Shortest Path")
        col.operator("mesh.faces_select_linked_flat", text="Linked Flat Faces")

        # 下:Misc
        col = pie.column()
        col.ui_units_x = 9
        row = col.row(align=True)
        row.operator("mesh.edges_select_sharp")
        row.separator(factor=0.3)
        row.operator("mesh.select_axis", text="Side of Active")
        row = col.row(align=True)
        row.operator("mesh.loop_to_region")
        row.separator(factor=0.3)
        if bpy.app.version < (5, 1, 0):
            row.operator("mesh.loop_multi_select", text="Edge Loops").ring = False
        else:
            row.operator("mesh.select_edge_loop_multi", text="Edge Loops")
        row = col.row(align=True)
        row.operator("mesh.region_to_loop")
        row.separator(factor=0.3)
        if bpy.app.version < (5, 1, 0):
            row.operator("mesh.loop_multi_select", text="Edge Rings").ring = True
        else:
            row.operator("mesh.select_edge_ring_multi", text="Edge Rings")
        row = col.row(align=True)
        row.operator("mesh.select_by_attribute")

        # 上:间隔式弃选
        pie.operator("mesh.select_nth")

        # 左上:随机,镜像
        col = pie.column()
        row = col.row(align=True)
        row.operator("mesh.select_mirror", text="Select Mirror")
        row.separator(factor=0.3)
        row.operator("mesh.select_random", text="Select Random")

        # 右上
        row = pie.row(align=True)
        row.operator(VSelect.bl_idname)

        # 左下:选择相似
        pie.operator("wm.call_menu", text="Select Similar").name = "VIEW3D_MT_edit_mesh_select_similar"

        # 右下
        row = pie.row(align=True)
        row.operator(LSelect.bl_idname)
        row.separator(factor=0.3)
        row.operator(SSelect.bl_idname)


# ============================================================
# 曲线编辑选择饼菜单
# ============================================================
class EditCurveSelectPie(Menu):
    """
    曲线编辑选择饼菜单

    提供曲线编辑模式下的选择操作快捷选项.
    """

    bl_idname = "VIEW3D_MT_ch_editcurve_select_pie"
    bl_label = "CH Edit Curve Select Pie"
    bl_description = "Edit Curve Select Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_CURVE' and context.active_object is not None

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:选择相似
        pie.operator("curve.select_similar", text="Select Similar")

        # 右:选择相连元素
        pie.operator("curve.select_linked", text="Select Linked")

        # 下:Misc
        col = pie.column()
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator("curve.select_previous")
        row.separator(factor=0.3)
        row.operator("curve.select_next")
        col.operator("curve.de_select_first")
        col.operator("curve.de_select_last")

        # 上:间隔式弃选
        pie.operator("curve.select_nth")

        # 左上:随机
        pie.operator("curve.select_random", text="Select Random")


# ============================================================
# 骨架编辑模式选择饼菜单
# ============================================================
class EditArmatureSelectPie(Menu):
    """
    骨架编辑模式选择饼菜单

    提供骨架编辑模式下的选择操作快捷选项.
    """

    bl_idname = "VIEW3D_MT_ch_editarmature_select_pie"
    bl_label = "CH Edit Armature Select Pie"
    bl_description = "Edit Armature Select Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_ARMATURE' and context.active_object is not None

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:选择相似
        pie.operator("armature.select_similar", text="Select Similar")

        # 右:选择相连元素
        pie.operator("armature.select_linked", text="Select Linked")

        # 下:Misc
        col = pie.column()
        col.ui_units_x = 6
        row = col.row(align=True)
        row.operator("armature.select_hierarchy", text="Parent").direction = 'PARENT'
        row.separator(factor=0.3)
        row.operator("armature.select_hierarchy", text="Child").direction = 'CHILD'
        row = col.row(align=True)
        op = row.operator("armature.select_hierarchy", text="Extend Parent")
        op.direction = 'PARENT'
        op.extend = True
        row.separator(factor=0.3)
        op = row.operator("armature.select_hierarchy", text="Extend Child")
        op.direction = 'CHILD'
        op.extend = True

        # 上: 按名称
        pie.operator("object.select_pattern", text="Select Pattern")

        # 左上:镜像
        pie.operator("armature.select_mirror", text="Select Mirror")


# ============================================================
# 姿态模式选择饼菜单
# ============================================================
class PoseSelectPie(Menu):
    """
    姿态模式选择饼菜单

    提供姿态模式下的选择操作快捷选项.
    """

    bl_idname = "VIEW3D_MT_ch_pose_select_pie"
    bl_label = "CH Pose Select Pie"
    bl_description = "Pose Select Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'POSE' and context.active_object is not None

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:按组选择
        pie.operator("pose.select_grouped", text="Select Grouped")

        # 右:选择相连元素
        pie.operator("pose.select_linked", text="Select Linked")

        # 下:Misc
        col = pie.column()
        col.ui_units_x = 6
        row = col.row(align=True)
        row.operator("pose.select_hierarchy", text="Parent").direction = 'PARENT'
        row.separator(factor=0.3)
        row.operator("pose.select_hierarchy", text="Child").direction = 'CHILD'
        row = col.row(align=True)
        op = row.operator("pose.select_hierarchy", text="Extend Parent")
        op.direction = 'PARENT'
        op.extend = True
        row.separator(factor=0.3)
        op = row.operator("pose.select_hierarchy", text="Extend Child")
        op.direction = 'CHILD'
        op.extend = True

        # 上: 按名称
        pie.operator("object.select_pattern", text="Select Pattern")

        # 左上:镜像
        pie.operator("pose.select_mirror", text="Select Mirror")

        # 右上: 约束目标
        pie.operator("pose.select_constraint_target", text="Constraint Target")
