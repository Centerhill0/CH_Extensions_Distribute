"""
对齐饼菜单模块

提供以下功能:
- ObjectAlignPie: 物体模式对齐饼菜单
- EditMeshAlignPie: 网格编辑模式对齐饼菜单
- NodeAlignPie: 节点编辑器对齐饼菜单
"""

from bpy.types import Menu, Context

from ...icon_manager.icon_load import get_icon_id
from ...operators.align.align_object import ObjectAlignByView
from ...operators.align.align_edit_mesh import AlignEditMesh, AlignObjectToVert, AlignObjectToEdge, AlignObjectToFace
from ...operators.align.align_node import AlignNode, DistributeNode, SnapToGrid
from ...operators.align.distribute_by_view import ObjectDistributeByView
from ...operators.align.drop_to_surface import DropToSurface
from ...operators.align.flatten import Flatten
from ...operators.align.to_ground import ObjectToGround
from ...operators.mesh.edge_flow import SetVertexCurve, SetEdgeFlow, SetEdgeLinear, SetEdgeCurve


# ============================================================
# 物体模式对齐饼菜单
# ============================================================
class ObjectAlignPie(Menu):
    """
    物体模式对齐饼菜单

    功能:提供物体对齐和分布操作
    - 左/右/上/下对齐
    - 水平/垂直居中对齐
    - 水平/垂直分布
    - 下落到表面/移动到地面

    要求:物体模式下有选中物体
    """

    bl_idname = "VIEW3D_MT_ch_object_align_pie"
    bl_label = "CH Object Align Pie"
    bl_description = "Align Pie Menu in Object Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 方向键:左,右,下,上
        pie.operator(ObjectAlignByView.bl_idname, text="Align Left", icon_value=get_icon_id('Align_Left')).align_direction = 'Align_Left'
        pie.operator(ObjectAlignByView.bl_idname, text="Align Right", icon_value=get_icon_id('Align_Right')).align_direction = 'Align_Right'
        pie.operator(ObjectAlignByView.bl_idname, text="Align Down", icon_value=get_icon_id('Align_Down')).align_direction = 'Align_Down'
        pie.operator(ObjectAlignByView.bl_idname, text="Align Up", icon_value=get_icon_id('Align_Up')).align_direction = 'Align_Up'

        # 左上:水平/垂直居中对齐
        col = pie.column()
        col.scale_y = 1.5
        col.operator(ObjectAlignByView.bl_idname, text="Align Center H", icon_value=get_icon_id('Align_Center_H')).align_direction = 'Align_Center_H'
        col.operator(ObjectAlignByView.bl_idname, text="Align Center V", icon_value=get_icon_id('Align_Center_V')).align_direction = 'Align_Center_V'

        # 右上:水平/垂直分布
        col = pie.column()
        col.scale_y = 1.5
        col.operator(ObjectDistributeByView.bl_idname, text="Distribute H", icon_value=get_icon_id('Distribute_H')).is_horizontal = True
        col.operator(ObjectDistributeByView.bl_idname, text="Distribute V", icon_value=get_icon_id('Distribute_V')).is_horizontal = False

        # 左下:全部居中对齐
        col = pie.column()
        col.scale_y = 1.5
        col.operator(ObjectAlignByView.bl_idname, text="Align Center", icon_value=get_icon_id('Align_Center')).align_direction = 'Align_Center'

        # 右下:下落到表面/移动到地面
        col = pie.column()
        col.scale_y = 1.5
        col.operator(DropToSurface.bl_idname, text="Drop to Surface", icon='AXIS_TOP')
        col.operator(ObjectToGround.bl_idname, text="Move to Ground", icon='IMPORT')


# ============================================================
# 网格编辑模式对齐饼菜单
# ============================================================
class EditMeshAlignPie(Menu):
    """
    网格编辑模式对齐饼菜单

    功能:提供网格顶点对齐和物体对齐操作
    - 左/右/上/下对齐顶点
    - 水平/垂直居中对齐
    - 将物体对齐到顶点/边/面

    要求:网格编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editmesh_align_pie"
    bl_label = "CH Edit Mesh Align Pie"
    bl_description = "Align Pie Menu in Mesh Edit Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 方向键:左,右,下,上
        pie.operator(AlignEditMesh.bl_idname, text="Align Left", icon_value=get_icon_id('Align_Left')).align_direction = 'Align_Left'
        pie.operator(AlignEditMesh.bl_idname, text="Align Right", icon_value=get_icon_id('Align_Right')).align_direction = 'Align_Right'
        pie.operator(AlignEditMesh.bl_idname, text="Align Down", icon_value=get_icon_id('Align_Down')).align_direction = 'Align_Down'
        pie.operator(AlignEditMesh.bl_idname, text="Align Up", icon_value=get_icon_id('Align_Up')).align_direction = 'Align_Up'

        # 左上:水平/垂直居中对齐
        col = pie.column()
        col.scale_y = 1.5
        op = col.operator(AlignEditMesh.bl_idname, text="Align Center H", icon_value=get_icon_id('Align_Center_H'))
        op.align_direction = 'Align_Center_H'
        op.align_type = 'AVERAGE'
        op = col.operator(AlignEditMesh.bl_idname, text="Align Center V", icon_value=get_icon_id('Align_Center_V'))
        op.align_direction = 'Align_Center_V'
        op.align_type = 'AVERAGE'

        # 右上:留空
        pie.operator(Flatten.bl_idname, text="Flatten", icon='OUTLINER_OB_VOLUME')

        # 左下:将物体对齐到顶点/边/面
        col = pie.column()
        col.scale_y = 1.5
        col.operator(AlignObjectToVert.bl_idname, text="Align to Vert", icon='VERTEXSEL')
        col.operator(AlignObjectToEdge.bl_idname, text="Align to Edge", icon='EDGESEL')
        col.operator(AlignObjectToFace.bl_idname, text="Align to Face", icon='FACESEL')

        # 右下:留空
        col = pie.column()
        col.scale_y = 1.5
        row = col.row(align=True)
        row.operator(SetVertexCurve.bl_idname)
        row.separator(factor=0.3)
        row.operator(SetEdgeFlow.bl_idname)
        row = col.row(align=True)
        row.operator(SetEdgeLinear.bl_idname)
        row.separator(factor=0.3)
        row.operator(SetEdgeCurve.bl_idname)


# ============================================================
# 节点编辑器对齐饼菜单
# ============================================================
class NodeAlignPie(Menu):
    """
    节点编辑器对齐饼菜单

    功能:提供节点对齐操作
    - 左/右/上/下对齐节点(对齐到边界)
    - 左上: 对齐到活动节点的左边界,对齐到活动节点的上边界
    - 右上: 节点栅格吸附
    - 左下: 水平分布
    - 右下: 垂直分布

    要求:节点编辑器模式,至少选中2个非Frame节点
    """

    bl_idname = "NODE_MT_ch_node_align_pie"
    bl_label = "CH Node Align Pie"
    bl_description = "Align Pie Menu in Node Editor"

    @classmethod
    def poll(cls, context: Context):
        return context.area is not None and context.area.type == 'NODE_EDITOR'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        pie.operator(AlignNode.bl_idname, text="Align Left", icon_value=get_icon_id('Align_Left')).align_type = 'Align_Left'
        pie.operator(AlignNode.bl_idname, text="Align Right", icon_value=get_icon_id('Align_Right')).align_type = 'Align_Right'
        pie.operator(AlignNode.bl_idname, text="Align Down", icon_value=get_icon_id('Align_Down')).align_type = 'Align_Down'
        pie.operator(AlignNode.bl_idname, text="Align Up", icon_value=get_icon_id('Align_Up')).align_type = 'Align_Up'

        col = pie.column()
        col.scale_y = 1.2
        op = col.operator(AlignNode.bl_idname, text="Align to Active H", icon_value=get_icon_id('Align to Active (Up)'))
        op.align_type = 'Align_Up'
        op.use_align_to_active = True

        op = col.operator(AlignNode.bl_idname, text="Align to Active V", icon_value=get_icon_id('Align to Active (Left)'))
        op.align_type = 'Align_Left'
        op.use_align_to_active = True

        pie.operator(SnapToGrid.bl_idname, text="Snap to Grid", icon='SNAP_GRID')

        pie.operator(DistributeNode.bl_idname, text="Distribute H", icon_value=get_icon_id('Distribute_H')).is_horizontal = True
        pie.operator(DistributeNode.bl_idname, text="Distribute V", icon_value=get_icon_id('Distribute_V')).is_horizontal = False
