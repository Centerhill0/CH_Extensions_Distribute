"""
删除饼菜单模块

提供以下功能:
- EditMeshDeletePie:网格编辑模式
- EditCurveDeletePie:曲线编辑模式
"""

from bpy.types import Menu, Context


# ============================================================
# 网格编辑删除饼菜单
# ============================================================
class EditMeshDeletePie(Menu):
    """
    网格编辑模式删除饼菜单

    在网格编辑模式下提供删除操作:
    - 删除顶点/边/面
    - 溶解顶点/边/面
    - 删除边环
    - 移除重叠点

    要求: 网格编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editmesh_delete_pie"
    bl_label = "CH Edit Mesh Delete Pie"
    bl_description = "Delete Pie Menu in MeshEdit Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 左:溶解和塌陷
        col = pie.column()
        col.scale_y = 1.2
        col.operator("mesh.dissolve_limited")
        col.operator("mesh.edge_collapse")
        col.operator("mesh.delete_edgeloop")

        # 右:删除和清理
        col = pie.column()
        col.scale_y = 1.2
        col.operator("mesh.delete", text="Only Edges & Faces").type = 'EDGE_FACE'
        col.operator("mesh.delete", text="Only Faces").type = 'ONLY_FACE'
        col.operator("mesh.remove_doubles")

        # 下:溶解顶点
        pie.operator("mesh.dissolve_verts", icon='SNAP_VERTEX')

        # 上:删除顶点
        pie.operator("mesh.delete", text="Delete Vertices", icon='VERTEXSEL').type = 'VERT'

        # 左上:删除边
        pie.operator("mesh.delete", text="Delete Edges", icon='EDGESEL').type = 'EDGE'

        # 右上:删除面
        pie.operator("mesh.delete", text="Delete Faces", icon='FACESEL').type = 'FACE'

        # 左下:溶解边
        pie.operator("mesh.dissolve_edges", icon='SNAP_EDGE')

        # 右下:溶解面
        pie.operator("mesh.dissolve_faces", icon='SNAP_FACE')


# ============================================================
# 曲线编辑删除饼菜单
# ============================================================
class EditCurveDeletePie(Menu):
    """
    曲线编辑模式删除饼菜单

    在曲线编辑模式下提供删除操作:
    - 删除顶点/线段
    - 简化曲线
    - 溶解顶点

    要求: 曲线编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editcurve_delete_pie"
    bl_label = "CH Edit Curve Delete Pie"
    bl_description = "Delete Pie Menu in CurveEdit Mode"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_CURVE'

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 左:简化曲线
        pie.operator("curve.decimate")

        # 右:溶解顶点
        pie.operator("curve.dissolve_verts")

        # 上:删除线段
        pie.operator("curve.delete", text="Delete Segments").type = 'SEGMENT'

        # 下:删除顶点
        pie.operator("curve.delete", text="Delete Vertices").type = 'VERT'
