"""
菜单扩展模块

提供原生菜单的扩展功能:
- ShadingExpandPie: 着色器饼菜单扩展
- ExtrudeMenuExpand: 挤出菜单扩展
"""

from bpy.types import Context

from .....common.types.framework import ExpandableUi
from ...operators.mesh.hole_extrude import HoleExtrude
from ...operators.mesh.wedge import WedgeExtrude


class ShadingExpandPie(ExpandableUi):
    """着色器饼菜单扩展(物体模式)"""

    target_id = "VIEW3D_MT_shading_pie"
    expand_mode = "APPEND"

    def draw(self, context: Context):
        if context.mode == "OBJECT":
            layout = self.layout
            pie = layout.menu_pie()

            # 左上:自动平滑着色
            pie.operator("object.shade_auto_smooth", text="Shade Auto Smooth")

            # 右上:灯光类型选择器
            col = pie.column()
            col.ui_units_x = 9
            col.scale_y = 1.3
            box = col.box()
            row = box.row(align=False)
            row.prop(context.space_data.shading, "light", expand=True)

            # 左下:平滑着色
            pie.operator("object.shade_smooth", text="Shade Smooth")

            # 右下:平直着色
            pie.operator("object.shade_flat", text="Shade Flat")


class ExtrudeMenuExpand(ExpandableUi):
    """挤出菜单扩展"""

    target_id = "VIEW3D_MT_edit_mesh_extrude"
    expand_mode = "APPEND"

    def draw(self, context: Context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.operator(HoleExtrude.bl_idname)
        layout.operator(WedgeExtrude.bl_idname)
