"""
打开临时编辑器饼菜单模块

提供快速打开临时编辑器窗口的功能.
包含着色器编辑器,几何节点,资产浏览器,图像编辑器等.
"""

import bpy
from bpy.props import StringProperty
from bpy.types import Menu, Operator, Context


class OpenTempEditorPie(Menu):
    """
    打开临时编辑器饼菜单

    提供快速打开临时编辑器窗口:
    - 着色器编辑器
    - 几何节点编辑器
    - 纹理节点编辑器
    - 合成器
    - 图像编辑器
    - UV编辑器
    - 资产浏览器
    - 系统控制台
    """

    bl_idname = "VIEW3D_MT_ch_open_temp_editor_pie"
    bl_label = "CH Open Temp Editor Pie"
    bl_description = "Open Temp Editor Pie Menu"

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()

        # 左:着色器编辑器
        pie.operator(DuplicateEditor.bl_idname, text="Shader Editor", icon='NODE_MATERIAL').editor_type = 'ShaderNodeTree'

        # 右:几何节点编辑器
        pie.operator(DuplicateEditor.bl_idname, text="Geometry Node Editor", icon='GEOMETRY_NODES').editor_type = 'GeometryNodeTree'

        # 下:系统控制台
        pie.operator("wm.console_toggle", text="Toggle System Console", icon='CONSOLE')

        # 上:资产浏览器
        pie.operator(DuplicateEditor.bl_idname, text="Asset Browser", icon='ASSET_MANAGER').editor_type = 'ASSETS'

        # 左上:纹理节点编辑器
        pie.operator(DuplicateEditor.bl_idname, text="Texture Node Editor", icon='NODE_TEXTURE').editor_type = 'TextureNodeTree'

        # 右上:合成器
        pie.operator(DuplicateEditor.bl_idname, text="Compositor", icon='NODE_COMPOSITING').editor_type = 'CompositorNodeTree'

        # 左下:图像编辑器
        pie.operator(DuplicateEditor.bl_idname, text="Image Editor", icon='IMAGE').editor_type = 'IMAGE_EDITOR'

        # 右下:UV编辑器
        pie.operator(DuplicateEditor.bl_idname, text="UV Editor", icon='UV').editor_type = 'UV'


class DuplicateEditor(Operator):
    """
    复制当前编辑器

    复制当前编辑器窗口并切换到指定编辑器类型.
    新窗口将作为临时窗口打开.
    """

    bl_idname = "ch.duplicate_editor"
    bl_label = "Duplicate Editor"
    bl_description = "Duplicate the current editor"

    editor_type: StringProperty(name="Editor Type", default="", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        bpy.ops.screen.area_dupli('INVOKE_DEFAULT')
        context.area.ui_type = self.editor_type

        # 资产浏览器默认定位到当前文件的资产库(LOCAL), 而非上一次使用的库.
        # params 为惰性创建, 空间首次激活前取不到, 直接赋值会被静默跳过或被初始化覆盖,
        # 故经一次性 timer 延迟设置, params 未就绪时短暂重试(窗口被关闭则终止)
        if self.editor_type == 'ASSETS':
            win = context.window
            bpy.app.timers.register(
                lambda: _set_asset_library_to_local(win), first_interval=0.0
            )

        # 不调用 user_clear: 临时屏幕(SRtemp)的生命周期由新窗口持有,
        # 提前清零用户数会在窗口关闭释放时触发 "ID user decrement error: SRtemp 0 <= 0";
        # temp 屏幕本就不写入 .blend, 随窗口关闭自动释放
        return {'FINISHED'}


def _set_asset_library_to_local(window, attempts: int = 0) -> None:
    """将临时窗口中的资产浏览器定位到当前文件的资产库(LOCAL)

    Args:
        window: 临时窗口
        attempts: 已重试次数, params 长时间未就绪时封顶防止无限 timer
    """
    try:
        screen = window.screen
    except ReferenceError:
        return
    if screen is None:
        return

    pending = False
    for area in screen.areas:
        if area.type != 'FILE_BROWSER':
            continue
        params = getattr(area.spaces.active, "params", None)
        if params is None:
            pending = True
            continue
        params.asset_library_reference = 'LOCAL'

    if pending and attempts < 20:
        bpy.app.timers.register(
            lambda: _set_asset_library_to_local(window, attempts + 1),
            first_interval=0.05,
        )
