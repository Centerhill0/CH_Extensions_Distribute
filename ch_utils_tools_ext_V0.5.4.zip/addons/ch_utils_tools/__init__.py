import bpy

from .config import __addon_name__
from .i18n.dictionary import dictionary
from ...common.class_loader import auto_load
from ...common.class_loader.auto_load import add_properties, remove_properties
from ...common.i18n.dictionary import common_dictionary
from ...common.i18n.i18n import load_dictionary
from .icon_manager.icon_load import load_icon, clear_icon
from .keymaps import register_keymaps, unregister_keymaps

_addon_properties = {
    bpy.types.Object: {
        "dup_hash": bpy.props.StringProperty(description="Hash to find associated objects for Surface Slide"),
    },
}


def register():
    """
    注册插件
    """
    # 检查Blender版本
    # if not _check_blender_version():
    #     print(f"{__addon_name__} 插件注册失败: 版本不兼容")
    #     return

    # Register classes
    auto_load.init()
    auto_load.register()

    load_icon()
    register_keymaps()

    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(__addon_name__))


def unregister():
    """
    注销插件
    """
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)
    # unRegister classes
    auto_load.unregister()

    clear_icon()
    unregister_keymaps()

    remove_properties(_addon_properties)
    print("{} addon is uninstalled.".format(__addon_name__))


# You may declare properties like following, framework will automatically add and remove them.
# Do not define your own property group class in the __init__.py file. Define it in a separate file and import it here.
# 注意不要在__init__.py文件中自定义PropertyGroup类.请在单独的文件中定义它们并在此处导入.
# _addon_properties = {
#     bpy.types.Scene: {
#         "property_name": bpy.props.StringProperty(name="property_name"),
#     },
# }
