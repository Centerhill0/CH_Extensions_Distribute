"""
输入/轴映射模块

轴向量引用 utils/_constants.py 的同源常量, 避免重复定义.
"""

from .constants import red, green, blue
from .utils._constants import AXIS_X, AXIS_Y, AXIS_Z

axis_vector_mappings = {'X': AXIS_X, 'Y': AXIS_Y, 'Z': AXIS_Z}
axis_color_mappings = {'X': red, 'Y': green, 'Z': blue}

ctrl = ['LEFT_CTRL', 'RIGHT_CTRL']
alt = ['LEFT_ALT', 'RIGHT_ALT']
shift = ['LEFT_SHIFT', 'RIGHT_SHIFT']

input_mappings = {
    'ONE': "1",
    'TWO': "2",
    'THREE': "3",
    'FOUR': "4",
    'FIVE': "5",
    'SIX': "6",
    'SEVEN': "7",
    'EIGHT': "8",
    'NINE': "9",
    'ZERO': "0",
    'NUMPAD_1': "1",
    'NUMPAD_2': "2",
    'NUMPAD_3': "3",
    'NUMPAD_4': "4",
    'NUMPAD_5': "5",
    'NUMPAD_6': "6",
    'NUMPAD_7': "7",
    'NUMPAD_8': "8",
    'NUMPAD_9': "9",
    'NUMPAD_0': "0",
    'BACK_SPACE': "",
    'DELETE': "",
    'PERIOD': ".",
    'COMMA': ".",
    'MINUS': "-",
    'NUMPAD_PERIOD': ".",
    'NUMPAD_COMMA': ".",
    'NUMPAD_MINUS': "-",
}

# 数字键事件类型列表(含小键盘), 与 input_mappings 的键集合及顺序一致, 派生避免双处维护
numbers = list(input_mappings)
