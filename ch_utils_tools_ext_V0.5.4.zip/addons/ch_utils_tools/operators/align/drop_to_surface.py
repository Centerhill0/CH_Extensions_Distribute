"""
物体下落到表面操作器模块

提供以下功能:
- DropToSurface: 将物体垂直下落到下方表面
"""

__all__ = ["DropToSurface"]

from bpy.types import Operator, Context
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from mathutils import Matrix, Quaternion, Vector

from ...utils import measure_objects_evaluated, raycast_scene


# ============================================================
# 物体下落到表面操作器
# ============================================================
class DropToSurface(Operator):
    """
    将物体垂直下落到表面
    功能: 将选中的物体沿 Z 轴方向下落到下方表面
    - 支持两种对齐位置: 底部中心/物体原点
    - 支持旋转对齐到表面法线
    - 支持设置 Z 轴偏移
    - 支持翻转法线方向
    要求: 至少选中 1 个物体
    """

    bl_idname = "ch.drop_to_surface"
    bl_label = "Drop Objects"
    bl_description = "Vertical Drop to Surface"
    bl_options = {'REGISTER', 'UNDO'}

    align_position: EnumProperty(
        name="Align Position",
        description="Align position to surface",
        items=[
            ('BOTTOM_CENTER', "Center Bottom", "Use the bottom center of the object's bounding box"),
            ('OBJECT_ORIGIN', "Object Origin", "Use the object's origin point"),
        ],
        default='BOTTOM_CENTER',
    )  # type: ignore

    is_rotate_to_align: BoolProperty(
        name="Rotate to Align",
        description="Rotate to align with the surface normal",
        default=False,
    )  # type: ignore

    offset_z: FloatProperty(
        name="Offset",
        description="Offset Z distance from surface",
        default=0.0,
    )  # type: ignore

    flip_normal: BoolProperty(
        name="Flip Normal",
        description="Flip the surface normal direction",
        default=False,
    )  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return len(context.selected_objects) > 0

    def execute(self, context: Context):
        # 一步式构建世界坐标测量, 并回取可安全写回的原始物体
        measures, objs = measure_objects_evaluated(context, context.selected_objects)
        depsgraph = context.evaluated_depsgraph_get()
        # 预计算所有物体的底部中心位置
        bottom_center_list = [m.bottom_center_pos for m in measures]
        # 遍历每个物体执行下落操作
        for obj, bottom_center in zip(objs, bottom_center_list):
            # 根据对齐位置确定射线检测起点
            match self.align_position:
                case 'OBJECT_ORIGIN':
                    # 使用物体原点, 但 Z 坐标使用底部中心
                    ori = obj.location
                    origin = Vector((ori.x, ori.y, bottom_center.z - 0.01))
                case 'BOTTOM_CENTER':
                    # 使用底部中心位置
                    ori = bottom_center
                    origin = ori + Vector((0, 0, -0.01))

            # 执行射线检测 (从物体底部向下发射)
            is_hit, hit_pos, hit_normal, *_ = raycast_scene(
                depsgraph,
                origin,
                direction=Vector((0, 0, -1)),
                distance=1000.0,
            )

            # 如果没有检测到表面, 跳过当前物体
            if not is_hit:
                continue

            # 接触点是物体被对齐到表面的点(ori)经位移后的世界位置, 同时作为旋转支点
            delta = hit_pos - ori + Vector((0, 0, self.offset_z))
            pivot = ori + delta

            # 处理法线翻转
            if self.flip_normal:
                hit_normal = -hit_normal

            # 处理旋转对齐
            if self.is_rotate_to_align:
                # 获取物体局部 Z 轴方向 (世界空间)
                obj_local_z = (obj.matrix_world.to_3x3() @ Vector((0, 0, 1))).normalized()

                # 计算旋转轴和角度
                rotation_axis = obj_local_z.cross(hit_normal)
                angle = obj_local_z.angle(hit_normal)

                if rotation_axis.length > 0.000001:
                    rotation_quat = Quaternion(rotation_axis, angle)
                elif angle:
                    # 反向平行时旋转轴为零向量, 任选垂直轴旋转180度
                    rotation_quat = Quaternion(Vector((1, 0, 0)), angle)
                else:
                    rotation_quat = Quaternion()

                # 以接触点为支点旋转, 使接触点保持在表面命中处;
                # 世界矩阵需在位移写回前读取, 否则读到的是未刷新的缓存值, 位移会被覆盖丢失
                loc, rot, sca = obj.matrix_world.decompose()
                obj.matrix_world = Matrix.LocRotScale(rotation_quat @ (loc + delta - pivot) + pivot, rotation_quat @ rot, sca)

            else:
                # 计算偏移向量并移动物体到表面
                obj.location += delta

        context.view_layer.update()
        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        col = layout.column()

        col.prop(self, "align_position", expand=True)
        col.prop(self, "offset_z")
        col.prop(self, "is_rotate_to_align")
        col.prop(self, "flip_normal")
