"""
物体分布操作器模块

提供以下功能:
- ObjectDistributeByView: 按视图方向分布选中物体
"""

__all__ = ["ObjectDistributeByView"]

import bpy
from bpy.types import Operator, Context, Event
from bpy.props import EnumProperty, BoolProperty
from mathutils import Vector, Matrix

from ...items import axis_items, sorted_axis_items
from ...utils import MeasureObject, MeasureObjects, get_view_aligned_axes, measure_objects_evaluated


# ============================================================
# 按视图分布物体操作器
# ============================================================
class ObjectDistributeByView(Operator):
    """
    按视图方向分布物体
    功能: 将选中的物体按指定轴向均匀分布
    - 支持两种分布模式: 固定边界/调整间距
    - 支持两种距离计算: 边界净距/原点间距
    - 支持选择分布轴向
    要求: 至少选中 2 个物体
    """

    bl_idname = "ch.object_distribution_by_view"
    bl_label = "Distribution Objects"
    bl_description = "Distribute selected objects to the view"
    bl_options = {'REGISTER', 'UNDO'}

    distribute_sort_axis: EnumProperty(
        name="Sort Axis",
        description="Axis to sort objects by",
        items=sorted_axis_items,
        default="0",
    )  # type: ignore

    distribute_mode: EnumProperty(
        name="Distribution Mode",
        description="Mode to distribute objects",
        items=[
            ("FIXED", "Fixed", "Fixed the nearest and farthest objects"),
            ("ADJUSTMENT", "Adjustment", "Adjust the distance between each object"),
        ],
        default='FIXED',
    )  # type: ignore

    distribute_direction: EnumProperty(
        name="Distribute Direction",
        description="Direction to distribute objects",
        items=axis_items,
        default={'X'},
        options={'ENUM_FLAG', 'SKIP_SAVE'},
    )  # type: ignore

    distribute_distance: bpy.props.FloatProperty(
        name="Distance",
        description="Clearance between objects",
        subtype="DISTANCE",
        default=1.0,
    )  # type: ignore

    calculate_mode: EnumProperty(
        name="Distance Mode",
        description="Mode to calculate distance",
        items=[
            ("CLEARANCE", "Clearance", "distance between objects' bound"),
            ("ORIGIN_SPACE", "Origin Spacing", "distance between objects' center"),
        ],
        default='CLEARANCE',
    )  # type: ignore

    is_horizontal: BoolProperty(default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return len(context.selected_objects) >= 2

    def invoke(self, context: Context, event: Event):
        # 获取视图对齐的坐标轴
        axis_right_idx, axis_up_idx, *_ = get_view_aligned_axes(context)
        # 根据水平/垂直模式设置分布方向
        direction = axis_right_idx if self.is_horizontal else axis_up_idx
        self.distribute_direction = {"XYZ"[direction]}
        self.distribute_sort_axis = str(direction)

        return self.execute(context)

    def execute(self, context: Context):
        # 一步式构建世界坐标测量, 并回取可安全写回的原始物体
        measure_objs, _original_objs = measure_objects_evaluated(context, context.selected_objects)

        # 按指定轴向排序
        axis = int(self.distribute_sort_axis)
        sorted_m_objs = measure_objs.sorted_by_axis(axis)

        # 根据距离计算模式执行分布
        match self.calculate_mode:
            case "CLEARANCE":
                # 边界净距模式
                self._distribute_with_clearance(context, sorted_m_objs, measure_objs)
            case "ORIGIN_SPACE":
                # 原点间距模式
                origin_offset = measure_objs.get_offset_by_origin(is_sorted=True)
                self._distribute_with_origin(context, sorted_m_objs, origin_offset)

        context.view_layer.update()
        return {'FINISHED'}

    def _distribute_with_clearance(self, context: Context, sorted_m_objs: list[MeasureObject], measure_objs: MeasureObjects) -> None:
        """
        边界净距分布模式
        根据物体边界盒之间的净距进行分布,
        确保物体之间的间隙相等
        Args:
            context: Blender上下文
            sorted_m_objs: 按轴向排序后的测量对象列表
            measure_objs: 所有测量对象
        """
        current_offset = measure_objs.min_pos.copy()

        # 确定间隙大小
        match self.distribute_mode:
            case "FIXED":
                # 固定模式: 保持首尾物体位置, 中间物体均匀分布
                clearance = measure_objs.offset_by_clearance
            case "ADJUSTMENT":
                # 调整模式: 使用用户指定的间距
                clearance = Vector((self.distribute_distance, self.distribute_distance, self.distribute_distance))

        for m_obj in sorted_m_objs:
            # 计算目标位置
            target_loc = self._blend_coordinates(current_offset - m_obj.min_pos + m_obj.location, m_obj.location)
            # 应用变换
            self._apply_transform(context, m_obj, target_loc)
            # 更新偏移基准
            current_offset += clearance + m_obj.dims

    def _distribute_with_origin(self, context: Context, sorted_m_objs: list[MeasureObject], origin_offset: Vector) -> None:
        """
        原点偏移分布模式
        根据物体原点之间的距离进行分布,
        确保原点间距相等
        Args:
            context: Blender上下文
            sorted_m_objs: 按轴向排序后的测量对象列表
            origin_offset: 原点偏移量
        """
        base_loc = sorted_m_objs[0].location.copy()

        # 确定步进大小
        match self.distribute_mode:
            case "FIXED":
                # 固定模式: 保持首尾物体位置
                step_size = origin_offset
            case "ADJUSTMENT":
                # 调整模式: 使用用户指定的间距
                step_size = Vector((self.distribute_distance, self.distribute_distance, self.distribute_distance))

        for idx, m_obj in enumerate(sorted_m_objs):
            # 计算目标位置
            target_loc = self._blend_coordinates(base_loc + step_size * idx, m_obj.location)
            # 应用变换
            self._apply_transform(context, m_obj, target_loc)

    def _apply_transform(self, context: Context, m_obj: MeasureObject, new_location: Vector) -> None:
        """
        应用变换矩阵
        保持物体的旋转和缩放, 仅更新位置
        Args:
            context: Blender上下文
            m_obj: 测量对象
            new_location: 新的位置坐标
        """
        obj = context.scene.objects[m_obj.name]
        _, obj_rot, obj_sca = m_obj._object.matrix_world.decompose()
        obj.matrix_world = Matrix.LocRotScale(new_location, obj_rot, obj_sca)

    def _blend_coordinates(self, base_vec: Vector, ori_loc: Vector) -> Vector:
        """
        混合坐标分量
        根据分布方向设置, 选择性地使用 base_vec 或 ori_loc 的坐标分量
        Args:
            base_vec: 基准坐标向量
            ori_loc: 原始位置坐标向量
        Returns:
            Vector: 混合后的坐标向量
        """
        x = "X" in self.distribute_direction
        y = "Y" in self.distribute_direction
        z = "Z" in self.distribute_direction
        return Vector((base_vec.x if x else ori_loc.x, base_vec.y if y else ori_loc.y, base_vec.z if z else ori_loc.z))

    def draw(self, context: Context) -> None:
        layout = self.layout
        layout.use_property_split = True
        col = layout.column()

        col.prop(self, "distribute_sort_axis", expand=True)
        col.prop(self, "distribute_direction", expand=True)
        col.prop(self, "calculate_mode", expand=True)
        col.prop(self, "distribute_mode", expand=True)

        # 仅在调整模式下显示间距设置
        if self.distribute_mode == "ADJUSTMENT":
            col.prop(self, "distribute_distance")
