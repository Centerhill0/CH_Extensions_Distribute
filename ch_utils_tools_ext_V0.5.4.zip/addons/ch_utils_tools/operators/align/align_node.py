"""
节点对齐与分布操作器模块

提供节点编辑器中的节点对齐和分布功能.
支持四个方向的对齐,可选择对齐到活动节点或边界节点.
支持水平和垂直分布.
"""

__all__ = [
    "AlignNode",
    "DistributeNode",
    "SnapToGrid",
]

import bpy
from bpy.types import Context, Operator
from bpy.props import EnumProperty, BoolProperty

from ...items import align_direction_items
from ...utils import MeasureNode, MeasureNodes

FRAME_BORDER_OFFSETS = {90: 40, 108: 29}
FRAME_BORDER_DEFAULT_OFFSET = 40
GRID_SIZE = 20
SNAP_H_GAP = 40.0
MIN_GAP = 20.0


def calc_absolute_location(node, is_x: bool) -> float:
    """计算节点的绝对位置(累积所有父级Frame偏移)"""
    if node is None:
        return 0.0
    value = node.location.x if is_x else node.location.y
    parent = node.parent
    while parent is not None:
        value += parent.location.x if is_x else parent.location.y
        parent = parent.parent
    return value


def set_position_from_absolute(node: MeasureNode, abs_value: float, is_x: bool):
    """根据绝对位置设置节点位置,自动计算相对位置"""
    parent_offset = calc_absolute_location(node.parent, is_x) if node.parent else 0.0
    target_value = abs_value - parent_offset
    if is_x:
        node.location.x = target_value
    else:
        node.location.y = target_value


def snap_to_grid(value: float) -> float:
    """将值吸附到最近的网格(20的整数倍)"""
    return round(value / GRID_SIZE) * GRID_SIZE


def node_poll(context: Context, min_count: int) -> bool:
    """
    节点操作器的公共poll

    要求处于节点编辑器且有足够数量的非Frame选中节点.
    context.selected_nodes 仅在节点编辑器上下文中存在(其他区域求值poll时会缺失),
    故先校验空间类型再取用.

    Args:
        context: Blender上下文
        min_count: 所需的最少非Frame选中节点数

    Returns:
        是否满足操作条件
    """
    space = getattr(context, "space_data", None)
    if space is None or space.type != 'NODE_EDITOR' or space.edit_tree is None:
        return False

    selected_nodes = getattr(context, "selected_nodes", None)
    if not selected_nodes:
        return False

    non_frame_count = sum(node.bl_idname != "NodeFrame" for node in selected_nodes)
    return non_frame_count >= min_count


class AlignNode(Operator):
    """
    节点对齐操作器

    功能:将选中节点按方向对齐到边界节点或活动节点
    - 支持上下左右四个方向
    - 支持跨Frame统一对齐到活动节点
    """

    bl_idname = "ch.align_node"
    bl_label = "Align Node"
    bl_description = "Align selected nodes"
    bl_options = {'REGISTER', 'UNDO'}

    align_type: EnumProperty(name="Align Type", items=align_direction_items[:4], description="Align type", default="Align_Up")  # type: ignore
    use_align_to_active: BoolProperty(name="Align to Active", description="Align to active node instead of boundary", default=False, options={'SKIP_SAVE'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return node_poll(context, 2)

    def execute(self, context: Context):
        nodes = MeasureNodes(context.selected_nodes)
        use_snap = context.scene.tool_settings.use_snap_node

        if self.use_align_to_active:
            self._align_all_to_active(nodes, context.active_node, use_snap)
        else:
            for frame_key, node_list in nodes.grouped_by_frame.items():
                self._align_nodes_in_frame(node_list, nodes, frame_key, use_snap)

        return {"FINISHED"}

    def _align_all_to_active(self, nodes: MeasureNodes, active_node, use_snap: bool):
        """将所有节点对齐到活动节点(跨Frame统一对齐)"""
        if active_node is None:
            self.report({'INFO'}, "No Active Node")
            return

        is_x = self.align_type in ("Align_Left", "Align_Right")
        target_value = calc_absolute_location(active_node, is_x)

        if active_node.type == "FRAME":
            dpi = bpy.context.preferences.system.dpi
            offset = FRAME_BORDER_OFFSETS.get(dpi, FRAME_BORDER_DEFAULT_OFFSET)
            target_value += offset if is_x else -offset

        if use_snap:
            target_value = snap_to_grid(target_value)

        for node in nodes.measure_nodes:
            if not node.is_frame and node.name != active_node.name:
                set_position_from_absolute(node, target_value, is_x)

    def _align_nodes_in_frame(self, node_list: list[MeasureNode], nodes: MeasureNodes, frame_key: str, use_snap: bool):
        """对齐同一Frame内的节点到边界节点"""
        is_x = self.align_type in ("Align_Left", "Align_Right")
        target_value = nodes.get_align_position(frame_key, self.align_type)

        if use_snap:
            first_node = node_list[0]
            parent_offset = calc_absolute_location(first_node.parent, is_x) if first_node.parent else 0.0
            target_value = snap_to_grid(target_value + parent_offset)
            for node in node_list:
                set_position_from_absolute(node, target_value, is_x)
        else:
            for node in node_list:
                if is_x:
                    node.location.x = target_value
                else:
                    node.location.y = target_value


class DistributeNode(Operator):
    """
    节点分布操作器

    功能:按水平或垂直方向均匀分布选中节点,保持首尾节点位置
    """

    bl_idname = "ch.distribute_node"
    bl_label = "Distribute Node"
    bl_description = "Distribute selected nodes"
    bl_options = {'REGISTER', 'UNDO'}

    is_horizontal: BoolProperty(name="Horizontal", description="Distribute horizontally", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return node_poll(context, 2)

    def execute(self, context: Context):
        nodes = MeasureNodes(context.selected_nodes)
        use_snap = context.scene.tool_settings.use_snap_node

        for frame_key, node_list in nodes.grouped_by_frame.items():
            if len(node_list) < 2:
                continue
            if self.is_horizontal:
                self._distribute_horizontal(node_list, nodes, frame_key, use_snap)
            else:
                self._distribute_vertical(node_list, nodes, frame_key, use_snap)

        return {"FINISHED"}

    def _distribute_horizontal(self, node_list: list[MeasureNode], nodes: MeasureNodes, frame_key: str, use_snap: bool):
        """水平分布节点"""
        sorted_nodes = nodes.sorted_by_x[frame_key]
        first = sorted_nodes[0]
        last = sorted_nodes[-1]

        if use_snap:
            current_x = snap_to_grid(calc_absolute_location(first._node, True))
            for node in sorted_nodes:
                current_x = snap_to_grid(current_x)
                set_position_from_absolute(node, current_x, True)
                current_x += node.width + SNAP_H_GAP
        else:
            total_width = sum(n.width for n in sorted_nodes)
            total_range = last.location.x + last.width - first.location.x
            gap = max((total_range - total_width) / (len(sorted_nodes) - 1), MIN_GAP)

            current_x = first.location.x
            for node in sorted_nodes:
                node.location.x = current_x
                current_x += node.width + gap

    def _distribute_vertical(self, node_list: list[MeasureNode], nodes: MeasureNodes, frame_key: str, use_snap: bool):
        """垂直分布节点,保持最顶部节点位置不变"""
        sorted_nodes = nodes.sorted_by_y[frame_key]
        top_node = sorted_nodes[-1]

        if use_snap:
            current_y = snap_to_grid(calc_absolute_location(top_node._node, False))
            for node in reversed(sorted_nodes):
                current_y = snap_to_grid(current_y)
                set_position_from_absolute(node, current_y, False)
                current_y -= node.height + MIN_GAP
        else:
            total_height = sum(n.height for n in sorted_nodes)
            bottom_node = sorted_nodes[0]
            total_range = top_node.location.y - bottom_node.location.y - bottom_node.height
            gap = max((total_range - total_height + top_node.height) / (len(sorted_nodes) - 1), MIN_GAP)

            current_y = top_node.location.y
            for node in reversed(sorted_nodes):
                node.location.y = current_y
                current_y -= node.height + gap


class SnapToGrid(Operator):
    """
    节点网格吸附操作器

    功能:将选中节点位置吸附到最近的20单位网格
    """

    bl_idname = "ch.snap_node_to_grid"
    bl_label = "Snap to Grid"
    bl_description = "Snap selected nodes to nearest grid (20 units)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return node_poll(context, 1)

    def execute(self, context: Context):
        nodes = MeasureNodes(context.selected_nodes)

        for node in nodes.measure_nodes:
            if node.is_frame:
                continue
            snapped_x = snap_to_grid(calc_absolute_location(node._node, True))
            snapped_y = snap_to_grid(calc_absolute_location(node._node, False))
            set_position_from_absolute(node, snapped_x, True)
            set_position_from_absolute(node, snapped_y, False)

        return {"FINISHED"}
