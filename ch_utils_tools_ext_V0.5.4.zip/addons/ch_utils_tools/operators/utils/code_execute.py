"""
代码执行工具模块

在不同 context 中执行代码表达式查看数据, 用于调试上下文环境.

提供以下功能:
- CH_OT_code_execute: 执行输入的代码表达式并报告结果
"""

import bpy
from bpy.types import Context, Event


class CH_OT_code_execute(bpy.types.Operator):
    """
    代码执行操作器

    功能:在当前context中执行代码,查看数据
    - 输入:代码字符串
    - 输出:代码执行结果
    """

    bl_idname = "ch.code_execute"
    bl_label = "Code Execute"
    bl_description = "Execute Python Code in Current Context"

    code: bpy.props.StringProperty(name="Code String", default="context.area.type")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context: Context):
        try:
            result = eval(self.code)
        except Exception as e:
            self.report({'ERROR'}, f"{type(e).__name__}: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, str(result))

        return {'FINISHED'}

