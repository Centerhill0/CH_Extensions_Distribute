"""
材质拾取器操作模块

提供从3D视图拾取和分配材质的功能.

操作流程:
1. 启动操作符,检测环境和选择状态
2. 鼠标移动时实时检测鼠标下的材质
3. 按键切换操作模式或执行操作
4. 完成材质拾取或分配

支持的操作模式:
- PICK: 材质拾取模式(默认),将鼠标下的材质设置为活动材质, 并报告拾取到的材质名称
- ASSIGN: 材质分配模式(按住ALT激活),将鼠标下的材质分配给选中对象
- SWAP: 材质交换模式(按住CTRL激活),交换连续拾取到的两个材质;
  物体与网格编辑模式下均可用, 编辑模式下适用于调整自身物体的材质槽顺序

快捷键:
- LMB/SPACE: 确认操作
- ALT: 切换到ASSIGN模式(按住)
- CTRL: 切换到SWAP模式(按住),连续拾取两个材质后交换
- X: 清除材质
  - OBJECT模式: 清除鼠标下拾取到的材质槽(设置为None)
  - EDIT_MESH模式: 清除选中面的材质(无需鼠标命中)
- MMB: 视图导航
- ESC/RMB: 取消操作
"""

__all__ = ["MaterialPicker"]

import bpy
import bmesh
from bpy.types import Context, Event, Operator
from bpy.props import BoolProperty
from mathutils import Vector

from ...constants import white, yellow, blue, red, cyan
from ...mappings import alt, ctrl
from ...preference import get_prefs
from ...utils import (
    draw_label,
    draw_line,
    draw_mesh_wire,
    draw_status_item,
    force_ui_update,
    get_evaluated_object,
    get_last_node,
    get_ui_scale,
    get_vertex_coords,
    ignore_events,
    linear_to_srgb,
    raycast_from_mouse,
)
from ...modal_base import ModalOperatorMixin


class MaterialPicker(Operator, ModalOperatorMixin):
    """
    材质拾取和分配操作器

    功能: 从3D视图拾取材质并设置为活动材质,或将材质分配给选中对象
    - 默认为PICK模式(拾取材质), 确认后报告拾取到的材质名称
    - 按住ALT切换到ASSIGN模式(分配材质)
    - 按住CTRL切换到SWAP模式(交换材质), 物体与编辑模式均可用
    - 按X键清除材质
      - OBJECT模式: 清除鼠标下拾取到的材质槽(设置为None)
      - EDIT_MESH模式: 清除选中面的材质(无需鼠标命中)
    - 支持OBJECT和EDIT_MESH模式
    - 编辑模式下可拾取自身物体的材质并分配给选中面
    - 编辑模式下拾取其它物体的材质: 切换到该物体并回到物体模式(不进入其编辑模式)
    - 支持MESH,CURVE,FONT,SURFACE,META类型对象
    - 实时显示材质信息和颜色预览

    要求: 处于MATERIAL或RENDERED着色模式
    """

    bl_idname = "ch.material_picker"
    bl_label = "Material Picker"
    bl_description = "Pick Material from the 3D View\n+Alt: Assign Material to Selected Objects\n+Ctrl: Swap Two Materials\nX: Clear Material (Slot in Object Mode, Selected Faces in Edit Mode)"
    bl_options = {'REGISTER', 'UNDO'}

    is_keymap: BoolProperty(name="is Keymap Invocation", default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode in {'OBJECT', 'EDIT_MESH'}:
            return context.area and context.area.type == 'VIEW_3D'

    def invoke(self, context: Context, event: Event):
        if not self._validate_context(context):
            return {'PASS_THROUGH'}

        self._initialize_state(context)

        if not self._initialize_mode(context):
            return {'PASS_THROUGH'}

        self._initialize_ui(context, event)

        return {'RUNNING_MODAL'}

    def _validate_context(self, context: Context) -> bool:
        """验证上下文是否有效"""
        shading = context.space_data.shading
        shading_types = {'MATERIAL', 'RENDERED'}

        if shading.type == 'SOLID' and shading.color_type == 'MATERIAL':
            shading_types.add('SOLID')

        if shading.type not in shading_types:
            return False

        if not context.visible_objects:
            return False

        return True

    def _initialize_state(self, context: Context):
        """初始化操作状态"""
        self.dg = context.evaluated_depsgraph_get()
        self.sel = [obj for obj in context.selected_objects if obj.type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}]

        self.areas = self._get_areas(context)

        self.has_object_selection = bool(context.mode == 'OBJECT' and self.sel)
        self.has_face_selection = False

        if context.mode == 'EDIT_MESH':
            bm = bmesh.from_edit_mesh(context.active_object.data)
            self.has_face_selection = bool([f for f in bm.faces if f.select])
            del bm

        self.batches = {}
        self.hittable_cache = {}

        self.modes = []
        self.assign = False
        self.swap_mode = False

        self.first_material = None
        self.first_obj = None
        self.first_matindex = None

        self.hit_material_name = None
        self.hit_object_name = None
        self.hit_material_color = None

    def _initialize_mode(self, context: Context) -> bool:
        """初始化操作模式"""
        if not self._set_mode(context, init=True):
            return False

        if self.assign:
            self._populate_batches(self.sel)

        return True

    def _initialize_ui(self, context: Context, event: Event):
        """初始化UI"""
        self.init_mouse_position(event, hud=False)
        context.window.cursor_set("EYEDROPPER" if 'PICK' in self.modes else 'PAINT_CROSS')

        hitobj, matindex = self._get_material_hit(context)
        mat, self.hit_material_name, self.hit_object_name = self._get_material_from_hit(hitobj, matindex)
        self.hit_material_color = self._get_material_color_from_material(mat, srgb=True)

        self.init_status(context, func=_draw_material_pick_status(self))
        force_ui_update(context)
        self.init_modal_handlers(context, hud=True, view3d=True)
        self._tag_redraw_areas()

    def draw_HUD(self, context: Context):
        """绘制HUD信息"""
        if 'VIEW_3D' not in self.areas:
            return

        if context.area not in [area['area'] for area in self.areas['VIEW_3D']]:
            return

        HUD_x, HUD_y = self._get_per_area_HUD_coords(context, context.area)

        if not (HUD_x and HUD_y):
            return

        self.draw_init()

        if self.swap_mode:
            title, color = "Swap", cyan
        elif self.assign:
            title, color = "Assign", yellow
        else:
            title, color = "Pick", white

        dims = draw_label(context, scale=self.hud_scale, title=title, coords=Vector((HUD_x, HUD_y)), color=color, center=False)

        self.offset += 18

        color = white if self.hit_material_name else red

        dims = draw_label(context, scale=self.hud_scale, title='Material: ', coords=Vector((HUD_x, HUD_y)), offset=self.offset, center=False, alpha=0.5)
        start_dims = dims.copy()

        dims += draw_label(context, scale=self.hud_scale, title=str(self.hit_material_name), coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, color=color)
        end_dims = dims.copy()

        if self.swap_mode and self.first_material:
            dims += draw_label(context, scale=self.hud_scale, title=' (1st)', coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, color=cyan, alpha=0.5)

        if self.assign and self.hit_material_name and self.hit_object_name:
            dims += draw_label(context, scale=self.hud_scale, title=' from: ', coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, alpha=0.25)
            draw_label(context, scale=self.hud_scale, title=self.hit_object_name, coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, alpha=0.5)

        if self.hit_material_color and self.hit_material_name:
            scale = self._get_scale(context)

            draw_line([Vector((HUD_x + start_dims.x - 1, HUD_y - start_dims.y * 3, 0)), Vector((HUD_x + end_dims.x + 1, HUD_y - start_dims.y * 3, 0))], width=12 * scale, alpha=0.1)
            draw_line([Vector((HUD_x + start_dims.x, HUD_y - start_dims.y * 3, 0)), Vector((HUD_x + end_dims.x, HUD_y - start_dims.y * 3, 0))], color=self.hit_material_color, width=10 * scale)

            self.offset += 18

        if self.swap_mode and self.first_material:
            self.offset += 18

            dims = draw_label(context, scale=self.hud_scale, title="1st: ", coords=Vector((HUD_x, HUD_y)), offset=self.offset, center=False, alpha=0.25)
            draw_label(context, scale=self.hud_scale, title=self.first_material.name, coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, color=cyan, alpha=0.75)

        elif self.assign and self.hit_material_name:
            self.offset += 18

            dims = draw_label(context, scale=self.hud_scale, title="to: ", coords=Vector((HUD_x, HUD_y)), offset=self.offset, center=False, alpha=0.25)

            if context.mode == 'OBJECT':
                for idx, obj in enumerate(self.sel):
                    if idx > 0:
                        self.offset += 18

                    draw_label(context, scale=self.hud_scale, title=obj.name, coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, alpha=0.5)

            elif context.mode == 'EDIT_MESH':
                draw_label(context, scale=self.hud_scale, title="Face Selection", coords=Vector((HUD_x + dims.x, HUD_y)), offset=self.offset, center=False, color=blue)

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图线框高亮"""
        if 'VIEW_3D' not in self.areas:
            return

        if context.area not in [area['area'] for area in self.areas['VIEW_3D']]:
            return

        if context.mode != 'OBJECT':
            return

        if not (self.assign and self.hit_material_name):
            return

        alpha = 0.2

        for obj in self.sel:
            if obj.name == self.hit_object_name:
                continue

            batch = self.batches.get(obj.name)
            if batch:
                draw_mesh_wire(batch, color=blue, alpha=alpha)

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        self._tag_redraw_areas()

        if event.type == 'MOUSEMOVE':
            self.init_mouse_position(event, hud=False)

        area_under_mouse = self._get_area_type_under_mouse(self.mouse_window_pos)

        if area_under_mouse == 'VIEW_3D':
            result = self._handle_modal_events(context, event)
            if result:
                return result

        return {'RUNNING_MODAL'}

    def _handle_modal_events(self, context: Context, event: Event):
        """处理模态事件"""
        if event.type in ctrl and event.value == 'PRESS':
            self.swap_mode = True
            self.first_material = None
            self.first_obj = None
            self.first_matindex = None
            context.window.cursor_set("PAINT_CROSS")
            force_ui_update(context)

        elif event.type in ctrl and event.value == 'RELEASE':
            self.swap_mode = False
            self.first_material = None
            self.first_obj = None
            self.first_matindex = None

            if self.assign:
                context.window.cursor_set("PAINT_CROSS")
            else:
                context.window.cursor_set("EYEDROPPER")

            force_ui_update(context)

        if 'ASSIGN' in self.modes and not self.assign and not self.swap_mode and event.type in alt and event.value == 'PRESS':
            self._set_mode(context, mode='ASSIGN')

            if self.assign:
                self._populate_batches(self.sel)

        elif event.value == 'RELEASE' and event.type in alt:
            self._set_mode(context, mode=self.modes[0])

        if event.type in alt:
            force_ui_update(context)

        if 'PICK' in self.modes and event.type in alt and not self.swap_mode:
            if event.value == 'PRESS' and self.assign:
                context.window.cursor_set("PAINT_CROSS")

            elif not self.assign:
                context.window.cursor_set("EYEDROPPER")

        if event.type == 'MOUSEMOVE':
            self._handle_mouse_move(context)
            return None

        elif event.type == 'X' and event.value == 'PRESS':
            self._handle_clear_materials(context)
            return {'FINISHED'}

        elif (self.is_keymap and event.type in ['RIGHTMOUSE'] and event.value == 'RELEASE') or event.type in ['LEFTMOUSE', 'SPACE'] and event.value == 'PRESS':
            return self._handle_confirm(context)

        elif event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type in ['RIGHTMOUSE', 'ESC']:
            self.finish(context)
            return {'CANCELLED'}

        return None

    def _handle_mouse_move(self, context: Context):
        """处理鼠标移动事件"""
        hitobj, matindex = self._get_material_hit(context)

        if hitobj and hitobj.name not in self.batches:
            self._populate_batches([hitobj])

        mat, self.hit_material_name, self.hit_object_name = self._get_material_from_hit(hitobj, matindex)
        self.hit_material_color = self._get_material_color_from_material(mat, srgb=True)

        force_ui_update(context)

    def _handle_clear_materials(self, context: Context):
        """处理清除材质操作"""
        if context.mode == 'OBJECT':
            hitobj, matindex = self._get_material_hit(context)

            if hitobj and matindex is not None and matindex < len(hitobj.material_slots):
                hitobj.material_slots[matindex].material = None

        elif context.mode == 'EDIT_MESH':
            self._clear_material_in_editmode(context)

        self.finish(context)

    def _handle_confirm(self, context: Context):
        """处理确认操作"""
        if self.swap_mode:
            hitobj, matindex = self._get_material_hit(context)

            if not hitobj or matindex is None:
                return None

            if self.first_material is None:
                self.first_material = hitobj.material_slots[matindex].material if hitobj.material_slots and matindex < len(hitobj.material_slots) else None
                self.first_obj = hitobj
                self.first_matindex = matindex

                if self.first_material:
                    self.report({'INFO'}, f"First material selected: {self.first_material.name} from {hitobj.name}")

                return None

            else:
                second_material = hitobj.material_slots[matindex].material if hitobj.material_slots and matindex < len(hitobj.material_slots) else None

                if not second_material:
                    self.report({'WARNING'}, "No material in the second slot")
                    self.finish(context)
                    return {'CANCELLED'}

                if self.first_obj == hitobj and self.first_matindex == matindex:
                    self.report({'WARNING'}, "Cannot swap material with itself")
                    self.finish(context)
                    return {'CANCELLED'}

                self._swap_materials(self.first_obj, self.first_matindex, self.first_material, hitobj, matindex, second_material)

                self.finish(context)
                return {'FINISHED'}

        if self.assign:
            hitobj, matindex = self._get_material_hit(context)

            if hitobj:
                mat, _, _ = self._get_material_from_hit(hitobj, matindex)

                if mat:
                    if context.mode == 'OBJECT':
                        sel = [obj for obj in self.sel if obj != hitobj]

                        for obj in sel:
                            if not obj.material_slots:
                                obj.data.materials.append(mat)

                            else:
                                obj.material_slots[obj.active_material_index].material = mat

                    elif context.mode == 'EDIT_MESH':
                        self._assign_material_in_editmode(context, mat)

            self.finish(context)
            return {'FINISHED'}

        else:
            hitobj, matindex = self._get_material_hit(context)

            if hitobj and matindex is not None:
                iseditmode = context.mode == 'EDIT_MESH'
                mat, _, _ = self._get_material_from_hit(hitobj, matindex)

                if (active := context.active_object) != hitobj:
                    if iseditmode:
                        bpy.ops.object.mode_set(mode='OBJECT')

                    if active:
                        active.select_set(False)

                    context.view_layer.objects.active = hitobj

                hitobj.active_material_index = matindex

                if mat:
                    self.report({'INFO'}, f"Picked Material: {mat.name}")

            self.finish(context)
            return {'FINISHED'}

    def _set_mode(self, context: Context, mode: str = 'PICK', init: bool = False) -> bool:
        """设置操作模式"""
        if init:
            self.modes = ['PICK']

            if self.has_object_selection or self.has_face_selection:
                self.modes.append('ASSIGN')

            mode = self.modes[0]

        if mode == 'PICK':
            self.assign = False

        elif mode == 'ASSIGN':
            self.assign = True

        return True

    def _populate_batches(self, objects: list):
        """填充绘制批次"""
        for obj in objects:
            if obj.name not in self.batches and obj.type == 'MESH':
                mesh_eval = obj.evaluated_get(self.dg).data
                self.batches[obj.name] = get_vertex_coords(mesh_eval, mx=obj.matrix_world, return_edge_indices=True)

    def _get_areas(self, context: Context) -> dict:
        """获取窗口区域信息"""
        areas = {}

        for area in context.screen.areas:
            area_type = area.type

            data = {'area': area, 'x': (area.x, area.x + area.width), 'y': (area.y, area.y + area.height)}

            if area_type in areas:
                areas[area_type].append(data)

            else:
                areas[area_type] = [data]

        if 'VIEW_3D' in areas:
            for data in areas['VIEW_3D']:
                data['is_active'] = data['area'] == context.area

        return areas

    def _get_area_type_under_mouse(self, mouse_pos: Vector) -> str | None:
        """获取鼠标下的区域类型"""
        for area_type, areas in self.areas.items():
            for area in areas:
                if area['x'][0] <= mouse_pos.x <= area['x'][1]:

                    if area['y'][0] <= mouse_pos.y <= area['y'][1]:

                        if area_type == 'VIEW_3D' and not area['is_active']:
                            for a in areas:
                                a['is_active'] = a['area'] == area['area']

                        return area_type

        return None

    def _get_per_area_HUD_coords(self, context: Context, area, hud_offset: tuple | None = None) -> tuple[float, float] | tuple[None, None]:
        """获取HUD坐标, hud_offset 为 None 时读取插件偏好中的偏移设置"""
        if hud_offset is None:
            prefs = get_prefs()
            hud_offset = (prefs.modal_hud_offset_x, prefs.modal_hud_offset_y)

        region = self._get_window_region_from_area(area)

        if region:
            scale = self._get_scale(context)

            x, y = self._get_region_space_co2d(context, self.mouse_window_pos, region=region)

            HUD_x = x + hud_offset[0] * scale
            HUD_y = y + hud_offset[1] * scale

            return HUD_x, HUD_y
        return None, None

    def _get_window_region_from_area(self, area):
        """获取区域的WINDOW区域"""
        for region in area.regions:
            if region.type == 'WINDOW':
                return region
        return None

    def _get_region_space_co2d(self, context: Context, mouse_pos: Vector, region) -> tuple[float, float]:
        """将鼠标位置转换为区域坐标"""
        x = mouse_pos.x - region.x
        y = mouse_pos.y - region.y

        return x, y

    def _get_scale(self, context: Context) -> float:
        """获取UI缩放"""
        return get_ui_scale() * get_prefs().modal_hud_scale

    def _tag_redraw_areas(self):
        """刷新区域"""
        if 'VIEW_3D' in self.areas:
            for area in self.areas['VIEW_3D']:
                area['area'].tag_redraw()

    def _get_material_hit(self, context: Context) -> tuple:
        """获取鼠标下的材质命中"""
        if 'VIEW_3D' not in self.areas:
            return None, None

        for area in self.areas['VIEW_3D']:
            if area['is_active']:
                region = self._get_window_region_from_area(area['area'])
                mouse_pos = self._get_region_space_co2d(context, self.mouse_window_pos, region=region)

                _, hitobj, hitindex, _, _, _ = raycast_from_mouse(mouse_pos, depsgraph=self.dg, exclude_wire=True, cache=self.hittable_cache, region=region)

                if not hitobj:
                    return None, None

                hitobj_eval = get_evaluated_object(context, hitobj)

                if not hitobj_eval:
                    return hitobj, None

                if hitobj.type == 'MESH':
                    matindex = self._get_hit_material_index(hitobj, hitindex, hitobj_eval)

                    if matindex is None:
                        return hitobj, None
                else:
                    matindex = 0

                matindex = min(matindex, len(hitobj.material_slots) - 1)

                if matindex < 0:
                    return hitobj, None
                return hitobj, matindex

        return None, None

    def _get_hit_material_index(self, obj, index: int | None, obj_eval) -> int | None:
        """
        获取命中多边形的材质索引

        编辑模式下的对象其评估网格多边形为空(0), 须改读编辑网格, 否则自身材质永远拾取不到;
        非编辑对象读取评估网格, 以匹配射线命中的修改器结果几何
        """
        if index is None:
            return None

        if obj.mode == 'EDIT':
            bm = bmesh.from_edit_mesh(obj.data)

            if index >= len(bm.faces):
                return None

            bm.faces.ensure_lookup_table()
            return bm.faces[index].material_index

        mesh = obj_eval.data

        if not mesh or index >= len(mesh.polygons):
            return None

        return mesh.polygons[index].material_index

    def _get_material_from_hit(self, obj, idx: int | None) -> tuple:
        """从命中对象获取材质"""
        if obj:
            if idx is not None:
                if obj.material_slots and obj.material_slots[idx].material:
                    mat = obj.material_slots[idx].material
                    return mat, mat.name, obj.name
            return None, None, obj.name
        return None, None, None

    def _get_material_color_from_material(self, mat, srgb: bool = False) -> tuple | None:
        """从材质获取颜色"""
        if not mat:
            return None

        last_node = get_last_node(mat)

        if not last_node:
            return None

        matcolor = last_node.inputs.get('Base Color')

        if not matcolor:
            for i in last_node.inputs:
                if i.type == 'RGBA':
                    matcolor = i
                    break

        if not matcolor:
            return None

        if srgb:
            return linear_to_srgb(matcolor.default_value[:3])
        return matcolor.default_value

    def _assign_material_in_editmode(self, context: Context, mat):
        """在编辑模式下分配材质"""
        active = context.active_object

        if not active.material_slots:
            active.data.materials.append(mat)
            return

        bm = bmesh.from_edit_mesh(active.data)
        bm.normal_update()

        faces = [f for f in bm.faces if f.select]

        if not faces:
            return

        max_index = len(active.material_slots) - 1

        for f in faces:
            if f.material_index > max_index:
                f.material_index = max_index

        mat_indices = set(f.material_index for f in faces)

        if len(mat_indices) == 1:
            index = mat_indices.pop()
            mat_at_index = active.material_slots[index].material

            if mat_at_index == mat:
                active.active_material_index = index
                return

        if mat.name in active.data.materials:
            index = list(active.data.materials).index(mat)

        else:
            index = len(active.material_slots)

        for f in faces:
            f.material_index = index

        bmesh.update_edit_mesh(active.data)

        active.update_from_editmode()

        if mat.name not in active.data.materials:
            active.data.materials.append(mat)

        active.active_material_index = index

    def _swap_materials(self, obj1, matindex1: int, mat1, obj2, matindex2: int, mat2):
        """交换两个材质"""
        obj1.material_slots[matindex1].material = mat2
        obj2.material_slots[matindex2].material = mat1

        self.report({'INFO'}, f"Swapped materials: {mat1.name} <-> {mat2.name}")

    def _clear_material_in_editmode(self, context: Context):
        """在编辑模式下清除材质"""
        active = context.active_object

        if not active.material_slots:
            return

        bm = bmesh.from_edit_mesh(active.data)
        bm.normal_update()

        faces = [f for f in bm.faces if f.select]

        if not faces:
            return

        if len(faces) == len(bm.faces):
            active.data.materials.clear()
            active.active_material_index = 0

        else:
            empty_index = None

            for idx, slot in enumerate(active.material_slots):
                if slot.material is None:
                    empty_index = idx
                    break

            if empty_index is None:
                active.data.materials.append(None)
                empty_index = len(active.data.materials) - 1

            for f in faces:
                f.material_index = empty_index

            active.active_material_index = empty_index

        bmesh.update_edit_mesh(active.data)

        active.update_from_editmode()

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 光标复位 -> 刷新)"""
        self.finish_status()
        self.finish_modal_handlers()

        context.window.cursor_set("DEFAULT")

        force_ui_update(context)


def _draw_material_pick_status(op: MaterialPicker):
    """
    MaterialPicker状态栏绘制函数

    Args:
        op: MaterialPicker 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        swap_mode = getattr(op, 'swap_mode', False)
        first_material = getattr(op, 'first_material', None)
        assign = getattr(op, 'assign', False)

        if swap_mode:
            draw_status_item(row, text="Material Swap")
            if first_material:
                draw_status_item(row, text=f"1st: {first_material.name}", gap=1)
            else:
                draw_status_item(row, text="Select 1st Material", gap=1)
        else:
            draw_status_item(row, key='LMB', text='Finish')
            draw_status_item(row, key='MMB', text="Viewport")
            draw_status_item(row, key='RMB', text='Cancel')

            draw_status_item(row, active=assign, key='ALT', text="Assign", gap=1)
            draw_status_item(row, active=swap_mode, key='CTRL', text="Swap", gap=1)
            draw_status_item(row, key='X', text="Clear", gap=1)

    return draw
