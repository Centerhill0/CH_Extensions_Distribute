"""
网格清理操作模块

提供网格清理功能,包括合并重复顶点, 溶解退化几何体, 删除松散元素,
溶解冗余几何体, 重新计算法线等操作.

操作流程:
1. 在编辑模式下选择网格对象
2. 执行清理操作
3. 调整参数实现所需效果

支持的清理选项:
- Merge by Distance: 按距离合并重复顶点
- Degenerate Dissolve: 溶解退化边(零长度)和面(零面积)
- Delete Loose: 删除松散的顶点, 边或面
- Redundant Dissolve: 溶解冗余的顶点或边
- Recalculate Normals: 重新计算面法线

支持的选择类型:
- NON-MANIFOLD: 选择非流形边
- NON-PLANAR: 选择非平面面
- TRIS: 选择三角形面
- NGONS: 选择多边形面(边数>4)
"""

__all__ = ["MeshCleanUp"]


import math

import bmesh
from bpy.types import Operator, Context, Object
from bmesh.types import BMesh
from bpy.props import BoolProperty, FloatProperty, EnumProperty
from mathutils.geometry import distance_point_to_plane

from ...items import cleanup_select_items



class MeshCleanUp(Operator):
    """
    网格清理操作器

    功能: 清理网格中的冗余几何体
    - 支持合并重复顶点
    - 支持溶解退化几何体
    - 支持删除松散元素
    - 支持溶解冗余几何体
    - 支持重新计算法线
    - 支持仅处理选中元素

    要求: 网格编辑模式下有活动网格对象
    """

    bl_idname = "ch.mesh_clean_up"
    bl_label = "Mesh Clean Up"
    bl_description = "Clean up the selected mesh by removing unused vertices, edges, and faces"
    bl_options = {'REGISTER', 'UNDO'}

    only_selected: BoolProperty(name="Only Selected", description="Only clean up the selected elements", default=False)  # type: ignore

    remove_doubles: BoolProperty(name="Remove Doubles", description="Merge vertices by distance", default=True)  # type: ignore
    merge_distance: FloatProperty(name="Merge Distance", default=0.0001, min=0, step=0.01, precision=4)  # type: ignore
    use_connected: BoolProperty(name="Use Connected", description="Limit the search for doubles by connected geometry", default=True)  # type: ignore

    dissolve_degenerate: BoolProperty(name="Degenerate Dissolve", description="Merge degenerate edges(0-length) and faces(0-area)", default=True)  # type: ignore
    dissolve_distance: FloatProperty(name="Dissolve Distance", default=0.0001, min=0, step=0.01, precision=4)  # type: ignore

    delete_loose: BoolProperty(name="Delete Loose", description="Delete loose vertices, edges or faces", default=True)  # type: ignore
    delete_loose_verts: BoolProperty(name="Delete Loose Vertices", default=True)  # type: ignore
    delete_loose_edges: BoolProperty(name="Delete Loose Edges", default=True)  # type: ignore
    delete_loose_faces: BoolProperty(name="Delete Loose Faces", default=False)  # type: ignore

    dissolve_redundant: BoolProperty(name="Redundant Dissolve", description="Dissolve redundant vertices, edges or faces", default=True)  # type: ignore
    dissolve_redundant_verts: BoolProperty(name="Dissolve Redundant Verts", default=True)  # type: ignore
    dissolve_redundant_edges: BoolProperty(name="Dissolve Redundant Edges", default=False)  # type: ignore
    dissolve_redundant_angle: FloatProperty(name="Dissolve Redundant Angle", default=179.999, min=0, max=180, step=0.1, precision=6)  # type: ignore

    recalc_normals: BoolProperty(name="Recalculate Normals", default=True)  # type: ignore
    flip_normals: BoolProperty(name="Flip Normals", default=False)  # type: ignore

    select_type: EnumProperty(name="Select Element", items=cleanup_select_items, default='NONE')  # type: ignore
    planar_threshold: FloatProperty(name="Non-Planar Face Threshold", default=0.001, min=0, step=0.0001, precision=6)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def invoke(self, context: Context, event):
        bm = bmesh.from_edit_mesh(context.active_object.data)
        self.only_selected = any(v.select for v in bm.verts)
        return self.execute(context)

    def execute(self, context: Context):
        sel_objs = {obj for obj in context.selected_objects if obj.type == 'MESH' and obj.mode == 'EDIT'} | {context.active_object}
        removed = {}
        is_any_non_manifold = False

        for obj in sel_objs:
            bm, element_counts, is_non_manifold = self._clean_up(obj)

            if is_non_manifold:
                is_any_non_manifold = True

            if self.select_type != 'NONE':
                self._select_geometry(bm)

            cleaned_counts = self._get_element_counts(bm)
            bmesh.update_edit_mesh(obj.data)

            if element_counts != cleaned_counts:
                removed[obj] = (element_counts[0] - cleaned_counts[0], element_counts[1] - cleaned_counts[1], element_counts[2] - cleaned_counts[2])

        if removed:
            verts, edges, faces = 0, 0, 0
            for counts in removed.values():
                verts += counts[0]
                edges += counts[1]
                faces += counts[2]
            self.text_1 = f"Removed:{' Verts: ' + str(verts) if verts else ''}{' Edges: ' + str(edges) if edges else ''}{' Faces: ' + str(faces) if faces else ''}"
        else:
            self.text_1 = "Nothing to Remove"

        self.text_2 = "Non-Manifold Edges Found!" if is_any_non_manifold else "Manifold Mesh!"

        return {'FINISHED'}

    def _clean_up(self, act_obj: Object) -> tuple:
        """
        执行网格清理操作

        Args:
            act_obj: 活动网格对象

        Returns:
            包含BMesh对象, 元素计数和非流形标志的元组
        """
        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.verts.ensure_lookup_table()

        self.sel_verts = [v for v in bm.verts if v.select] if self.only_selected else bm.verts
        self.sel_edges = [e for e in bm.edges if e.select] if self.only_selected else bm.edges
        self.sel_faces = [f for f in bm.faces if f.select] if self.only_selected else bm.faces

        element_counts = self._get_element_counts(bm)

        if self.remove_doubles:
            valid_verts = [v for v in self.sel_verts if v.is_valid]
            if valid_verts:
                bmesh.ops.remove_doubles(bm, verts=valid_verts, use_connected=self.use_connected, dist=self.merge_distance)

        if self.dissolve_degenerate:
            valid_edges = [e for e in self.sel_edges if e.is_valid]
            if valid_edges:
                bmesh.ops.dissolve_degenerate(bm, dist=self.dissolve_distance, edges=valid_edges)

        if self.delete_loose:
            self._delete_loose_geometry(bm)

        if self.dissolve_redundant:
            self._dissolve_redundant_geometry(bm)

        if self.recalc_normals:
            valid_faces = [f for f in self.sel_faces if f.is_valid]
            if valid_faces:
                bmesh.ops.recalc_face_normals(bm, faces=valid_faces)
                if self.flip_normals:
                    for f in valid_faces:
                        f.normal_flip()

        is_non_manifold = any(not e.is_manifold for e in bm.edges)

        return bm, element_counts, is_non_manifold

    def _get_element_counts(self, bm: BMesh) -> tuple:
        """获取BMesh元素计数"""
        return (len(bm.verts), len(bm.edges), len(bm.faces))

    def _delete_loose_geometry(self, bm: BMesh):
        """删除松散几何体"""
        if self.delete_loose_verts:
            loose_verts = [v for v in self.sel_verts if v.is_valid and not v.link_edges]
            if loose_verts:
                bmesh.ops.delete(bm, geom=loose_verts, context="VERTS")

        if self.delete_loose_edges:
            loose_edges = [e for e in self.sel_edges if e.is_valid and not e.link_faces]
            if loose_edges:
                bmesh.ops.delete(bm, geom=loose_edges, context="EDGES")

        if self.delete_loose_faces:
            loose_faces = [f for f in self.sel_faces if f.is_valid and all([not e.is_manifold for e in f.edges])]
            if loose_faces:
                bmesh.ops.delete(bm, geom=loose_faces, context="FACES")

    def _dissolve_redundant_geometry(self, bm: BMesh):
        """溶解冗余几何体"""
        if self.dissolve_redundant_edges:
            manifold_edges = [e for e in self.sel_edges if e.is_valid and e.is_manifold]

            redundant_edges = []

            for e in manifold_edges:
                faces = e.link_faces
                if len(faces) == 2 and faces[0].material_index != faces[1].material_index:
                    continue

                angle = math.degrees(e.calc_face_angle(0))

                if angle < 180 - self.dissolve_redundant_angle:
                    redundant_edges.append(e)

            if redundant_edges:
                bmesh.ops.dissolve_edges(bm, edges=redundant_edges, use_verts=False)
                two_edged_verts = {v for e in redundant_edges if e.is_valid for v in e.verts if v.is_valid and len(v.link_edges) == 2}
                if two_edged_verts:
                    bmesh.ops.dissolve_verts(bm, verts=list(two_edged_verts))

        if self.dissolve_redundant_verts:
            two_edged_verts = [v for v in self.sel_verts if v.is_valid and len(v.link_edges) == 2]

            redundant_verts = []

            for v in two_edged_verts:
                e1 = v.link_edges[0]
                e2 = v.link_edges[1]

                if e1.calc_length() and e2.calc_length():
                    vector1 = e1.other_vert(v).co - v.co
                    vector2 = e2.other_vert(v).co - v.co

                    angle = min(math.degrees(vector1.angle(vector2)), 180)

                    if self.dissolve_redundant_angle < angle:
                        redundant_verts.append(v)

                else:
                    redundant_verts.append(v)

            if redundant_verts:
                bmesh.ops.dissolve_verts(bm, verts=redundant_verts)

    def _select_geometry(self, bm: BMesh):
        """选择特定类型的几何体"""
        for f in bm.faces:
            f.select = False

        bm.select_flush(False)

        match self.select_type:
            case 'NON-MANIFOLD':
                edges = [e for e in bm.edges if not e.is_manifold]
                for e in edges:
                    e.select = True

            case 'NON-PLANAR':
                faces = [f for f in bm.faces if len(f.verts) > 3]
                for f in faces:
                    distances = [distance_point_to_plane(v.co, f.calc_center_median(), f.normal) for v in f.verts]

                    if any(abs(d) > self.planar_threshold for d in distances):
                        f.select = True

            case 'TRIS':
                faces = [f for f in bm.faces if len(f.verts) == 3]
                for f in faces:
                    f.select = True

            case 'NGONS':
                faces = [f for f in bm.faces if len(f.verts) > 4]
                for f in faces:
                    f.select = True

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "only_selected")
        col = layout.column()

        row = col.row(heading="Merge by Distance")
        row.prop(self, "remove_doubles", text="")
        sub_row = row.row(align=True)
        sub_row.active = self.remove_doubles
        split = sub_row.split(factor=0.8)
        split.prop(self, "merge_distance", text="")
        split.prop(self, "use_connected", text="C", toggle=True)

        row = col.row(heading="Degenerate Dissolve")
        row.prop(self, "dissolve_degenerate", text="")
        sub_row = row.row(align=True)
        sub_row.active = self.dissolve_degenerate
        sub_row.prop(self, "dissolve_distance", text="")

        row = col.row(heading="Delete Loose")
        row.prop(self, "delete_loose", text="")
        sub_row = row.row(align=True)
        sub_row.active = self.delete_loose
        sub_row.prop(self, "delete_loose_verts", text="Vertices", toggle=True)
        sub_row.prop(self, "delete_loose_edges", text="Edges", toggle=True)
        sub_row.prop(self, "delete_loose_faces", text="Faces", toggle=True)

        row = col.row(heading="Redundant Dissolve")
        row.prop(self, "dissolve_redundant", text="")
        sub_row = row.row(align=True)
        sub_row.active = self.dissolve_redundant
        sub_row.prop(self, "dissolve_redundant_verts", text="Vertices", toggle=True)
        sub_row.prop(self, "dissolve_redundant_edges", text="Edges", toggle=True)
        sub_row.prop(self, "dissolve_redundant_angle", text="Angle")

        row = col.row(heading="Recalculate Normals")
        row.prop(self, "recalc_normals", text="")
        sub_row = row.row(align=True)
        sub_row.active = self.recalc_normals
        sub_row.prop(self, "flip_normals", toggle=True)

        sub_col = col.column()
        sub_col.prop(self, "select_type", expand=True)

        sub_col2 = col.column()
        sub_col2.active = self.select_type == 'NON-PLANAR'
        sub_col2.prop(self, "planar_threshold", text="Planar Threshold")

        col.label(text=self.text_1)
        col.label(text=self.text_2)
