"""
边环变形操作模块

提供边环(Edge Loop)的变形操作功能.
支持曲线化, 线性化, 流动变形等操作.

操作流程:
1. 在编辑模式下选择边或顶点
2. 执行对应的变形操作
3. 调整参数实现所需效果

操作类型:
- SetVertexCurve: 顶点曲线对齐
- SetEdgeFlow: 边流动变形
- SetEdgeLinear: 边线性变形
- SetEdgeCurve: 边曲线变形

支持的选项:
- Mix: 初始位置与计算位置的混合比例
- Tension: 曲线张力,用于收紧曲率
- Iterations: 迭代次数(流动变形)
- Use Rail: 使用轨道控制曲线

快捷键:
- ALT: 复用上次设置
"""

__all__ = ["SetVertexCurve", "SetEdgeFlow", "SetEdgeLinear", "SetEdgeCurve"]

import math
import bmesh
from bpy.types import Operator, Context, Event, Object
from bpy.props import BoolProperty, FloatProperty, IntProperty, EnumProperty
from mathutils import Vector

from ...utils import (
    collect_vert_path,
    circle_2_points,
    circle_3_points,
    curve_hermite,
    get_edge_loops,
    EdgeLoopDeformer,
)


class _SetEdgeLoopBase:
    """边环操作基类,提供通用功能"""

    mix: FloatProperty(name="Mix", default=1.0, min=0.0, max=1.0, subtype="FACTOR", description="Interpolate between initial position and calculated end position")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        obj = context.active_object
        if not obj or obj.type != "MESH" or obj.mode != "EDIT":
            return
        if context.space_data.type != "VIEW_3D":
            return
        # mesh_select_mode 是 bpy_prop_array, 直接与元组比较恒为 False, 必须先转 tuple
        return tuple(context.scene.tool_settings.mesh_select_mode) == (False, True, False)

    def _get_bm_from_object(self, obj: Object) -> bmesh.types.BMesh:
        """从物体获取编辑态BMesh"""
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        return bm

    def _revert_to_initial_positions(self) -> None:
        """恢复到初始位置"""
        for obj in self.objects:
            for idx, pos in self.initial_vert_positions[obj].items():
                self.bm[obj].verts[idx].co = pos

    def _store_final_positions(self) -> None:
        """存储最终位置"""
        self.final_vert_positions = {obj: {idx: self.bm[obj].verts[idx].co.copy() for idx in indices} for obj, indices in self.initial_vert_positions.items()}

    def _should_recompute(self) -> bool:
        """是否需要重算目标位置

        尚未算出 final_vert_positions(首次执行)时必须重算, 否则 _apply_mix 会索引空 dict 抛 KeyError;
        mix 与上次记录相同说明本次不是"只拖动 Mix 滑块"的复用场景, 同样重算;
        仅当 mix 变化且已有目标位置时才复用上次结果, 只重新混合.
        """
        return not self.final_vert_positions or self.mix == self.last_mix

    def _apply_mix(self) -> None:
        """应用混合比例"""
        if self.mix < 1.0 or (self.mix == 1.0 and self.last_mix < 1.0):
            for obj in self.objects:
                for edge_loop in self.edge_loops[obj]:
                    for vert in edge_loop.verts:
                        a = self.initial_vert_positions[obj][vert.index]
                        b = self.final_vert_positions[obj][vert.index]
                        vert.co = a.lerp(b, self.mix)

    def _update_mesh(self) -> None:
        """更新网格"""
        for obj in self.objects:
            self.bm[obj].normal_update()
            bmesh.update_edit_mesh(obj.data)

    def _init_base(self, context: Context) -> None:
        """初始化基类数据"""
        self.is_invoked = True
        self.last_mix = self.mix
        self.initial_vert_positions: dict[Object, dict[int, Vector]] = {}
        self.final_vert_positions: dict[Object, dict[int, Vector]] = {}

        self.objects = set(context.selected_editable_objects) if context.selected_editable_objects else {context.object}
        self.bm: dict[Object, bmesh.types.BMesh] = {}
        self.edge_loops: dict[Object, list[EdgeLoopDeformer]] = {}

        ignore = set()

        for obj in self.objects:
            if obj.mode != "EDIT":
                ignore.add(obj)
                continue

            bm = self._get_bm_from_object(obj)
            edges = [e for e in bm.edges if e.select]
            if not edges:
                ignore.add(obj)
                continue

            self.bm[obj] = bm
            self.edge_loops[obj] = get_edge_loops(bm, edges)
            self.initial_vert_positions[obj] = {v.index: v.co.copy() for e in edges for v in e.verts}

        self.objects -= ignore


class SetVertexCurve(Operator):
    """
    顶点曲线对齐操作器

    功能: 将选中顶点之间的顶点放置到曲线上
    - 支持2顶点半圆弧
    - 支持3顶点圆弧段
    - 支持4+顶点Hermite样条曲线

    要求: 在编辑模式下选择2个或更多顶点,要注意按顺序选择顶点
    """

    bl_idname = "ch.set_vertex_curve"
    bl_label = "Set Vertex Curve"
    bl_description = "Curve vertices between selected vertices in picking order"
    bl_options = {'REGISTER', 'UNDO'}

    mix: FloatProperty(name="Mix", default=1.0, min=0.0, max=1.0, subtype="FACTOR", description="Interpolate between initial position and calculated end position")  # type: ignore
    tension: IntProperty(name="Tension", default=0, min=-500, max=500, description="Tension can be used to tighten up the curvature")  # type: ignore
    use_topology_distance: BoolProperty(name="Use Topology Distance", default=False, description="Use edge count instead of edge lengths for distance measure")  # type: ignore
    flip: BoolProperty(name="Flip Half Circle", default=False, description="Flip the half circle into other direction")  # type: ignore
    rotate: BoolProperty(name="Rotate Half Circle", default=False, description="Rotate the half circle by 90 degrees")  # type: ignore
    space_evenly: BoolProperty(name="Space Evenly", default=False, description="Spread the vertices in even distances")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        obj = context.active_object
        if not obj or obj.type != "MESH" or obj.mode != "EDIT":
            return
        if context.space_data.type != "VIEW_3D":
            return
        # 同上: 需 tuple 转换后再比较
        return tuple(context.scene.tool_settings.mesh_select_mode) == (True, False, False)

    def invoke(self, context: Context, event: Event):
        self.initial_vert_positions: list[Vector] = []
        self.vert_count = 0

        if event and not event.alt:
            self.mix = 1.0
            self.tension = 0
            self.use_topology_distance = False
            self.space_evenly = False
            self.flip = False
            self.rotate = False

        return self.execute(context)

    def execute(self, context: Context):
        # execute 可能被直接调用(脚本调用 / F9 重做)而未经 invoke, 该守卫本身必须容忍状态缺席
        if not hasattr(self, "initial_vert_positions"):
            return self.invoke(context, None)

        obj = context.active_object
        bm = self._get_bm_from_mesh(obj.data)
        selected = self._get_selected_indices(bm)

        self.vert_count = len(selected)

        if self.vert_count < 2:
            self.report({"WARNING"}, "Please select 2, 3 or more vertices")
            return {"CANCELLED"}

        vert_path = collect_vert_path(bm, selected, self.use_topology_distance)

        if not self.initial_vert_positions:
            self.initial_vert_positions = [v.co.copy() for v in vert_path]

        tension = self.tension / 100.0

        curve_funcs = {
            2: lambda: circle_2_points(bm, selected, vert_path, tension, self.flip, self.rotate),
            3: lambda: circle_3_points(bm, selected, vert_path, tension, self.space_evenly),
        }
        result, msg = curve_funcs.get(self.vert_count, lambda: curve_hermite(bm, selected, vert_path, tension, self.space_evenly))()

        if result > 0:
            self.report({"INFO"}, msg)

        for i, vert in enumerate(vert_path):
            vert.co = self.initial_vert_positions[i].lerp(vert.co, self.mix)

        bmesh.update_edit_mesh(obj.data, loop_triangles=True)
        return {"FINISHED"}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        col = layout.column()
        col.prop(self, "mix")

        col = layout.column(align=True)
        col.prop(self, "tension")
        col.prop(self, "use_topology_distance")

        if self.vert_count == 2:
            col.prop(self, "flip")
            col.prop(self, "rotate")
        elif self.vert_count >= 3:
            col.prop(self, "space_evenly")

    def _get_bm_from_mesh(self, mesh) -> bmesh.types.BMesh:
        """从网格数据获取编辑态BMesh"""
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        return bm

    def _get_selected_indices(self, bm: bmesh.types.BMesh) -> list[int]:
        """获取选中顶点的索引列表(按选择顺序)"""
        maybe_selected = [elem.index for elem in bm.select_history if isinstance(elem, bmesh.types.BMVert)]
        return [idx for idx in maybe_selected if bm.verts[idx].select]


class SetEdgeFlow(Operator, _SetEdgeLoopBase):
    """
    边流动变形操作器

    功能: 根据交叉边的曲面调整曲率
    - 支持多次迭代
    - 支持起点/终点混合
    - 支持最小角度限制

    要求: 在编辑模式下选择边
    """

    bl_idname = "ch.set_edge_flow"
    bl_label = "Set Edge Flow"
    bl_description = "Adjust curvature to match surface defined by edges crossing the edgeloop\nALT: reuse last settings"
    bl_options = {'REGISTER', 'UNDO'}

    tension: IntProperty(name="Tension", default=180, min=-500, max=500, description="Tension can be used to tighten up the curvature")  # type: ignore
    iterations: IntProperty(name="Iterations", default=16, min=1, soft_max=32, description="How often the curvature operation is repeated")  # type: ignore
    blend_mode: EnumProperty(name="Blend Mode", items=[("ABSOLUTE", "Absolute", ""), ("FACTOR", "Factor", "")], description="Switch blend mode between absolute vertex counts and a factor of the whole edgeloop")  # type: ignore
    blend_start_int: IntProperty(name="Blend Start", default=0, min=0, description="The number of vertices from the start used to blend")  # type: ignore
    blend_end_int: IntProperty(name="Blend End", default=0, min=0, description="The number of vertices from the end used to blend")  # type: ignore
    blend_start_float: FloatProperty(name="Blend Start", default=0.0, min=0.0, max=1.0, subtype="FACTOR", description="Loop fraction from the start used to blend")  # type: ignore
    blend_end_float: FloatProperty(name="Blend End", default=0.0, min=0.0, max=1.0, subtype="FACTOR", description="Loop fraction from the end used to blend")  # type: ignore
    blend_type: EnumProperty(name="Blend Curve", items=[("LINEAR", "Linear", ""), ("SMOOTH", "Smooth", "")], description="The interpolation used to blend")  # type: ignore
    min_angle: IntProperty(name="Min Angle", default=0, min=0, max=180, description="After which angle the edgeloop curvature is ignored")  # type: ignore

    def invoke(self, context: Context, event: Event):
        # 归一化必须早于 _init_base: 后者会把当下的 mix 快照为 last_mix,
        # 快照之后再改 mix 会使首次执行被误判为"仅调整 mix"而跳过目标位置计算
        if event and not event.alt:
            self.mix = 1.0
            self.tension = 180
            self.iterations = 16
            self.min_angle = 0
            self.blend_start_int = 0
            self.blend_end_int = 0
            self.blend_start_float = 0.0
            self.blend_end_float = 0.0

        self._init_base(context)
        return self.execute(context)

    def execute(self, context: Context):
        # execute 可能被直接调用(脚本调用 / F9 重做)而未经 invoke, 该守卫本身必须容忍状态缺席
        if not getattr(self, "is_invoked", False):
            return self.invoke(context, None)

        self._revert_to_initial_positions()

        if self._should_recompute():
            for obj in self.objects:
                for _ in range(self.iterations):
                    for edge_loop in self.edge_loops[obj]:
                        edge_loop.apply_flow(self.tension / 100.0, math.radians(self.min_angle))

                for edge_loop in self.edge_loops[obj]:
                    if self.blend_mode == "ABSOLUTE":
                        start, end = self.blend_start_int, self.blend_end_int
                    else:
                        count = len(edge_loop.verts)
                        start, end = round(count * self.blend_start_float), round(count * self.blend_end_float)
                    edge_loop.blend_ends(start, end, self.blend_type)

            self._store_final_positions()

        self._apply_mix()
        self._update_mesh()

        self.last_mix = self.mix
        self.is_invoked = False
        return {"FINISHED"}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        col = layout.column(align=True)

        col.prop(self, "mix")
        col.prop(self, "tension")
        col.prop(self, "iterations")
        col.prop(self, "min_angle")
        col.separator()

        col.row().prop(self, "blend_mode", expand=True)

        if self.blend_mode == "ABSOLUTE":
            col.prop(self, "blend_start_int")
            col.prop(self, "blend_end_int")
        else:
            col.prop(self, "blend_start_float")
            col.prop(self, "blend_end_float")

        col.row().prop(self, "blend_type", expand=True)


class SetEdgeLinear(Operator, _SetEdgeLoopBase):
    """
    边线性变形操作器

    功能: 将边环顶点线性排列
    - 支持均匀分布

    要求: 在编辑模式下选择边
    """

    bl_idname = "ch.set_edge_linear"
    bl_label = "Set Edge Linear"
    bl_description = "Makes edge loops linear between start and end vertices"
    bl_options = {'REGISTER', 'UNDO'}

    space_evenly: BoolProperty(name="Space Evenly", default=False, description="Spread the vertices in even distances")  # type: ignore

    def invoke(self, context: Context, event: Event):
        # 归一化必须早于 _init_base: 后者会把当下的 mix 快照为 last_mix,
        # 快照之后再改 mix 会使首次执行被误判为"仅调整 mix"而跳过目标位置计算
        if event and not event.alt:
            self.mix = 1.0

        self._init_base(context)
        return self.execute(context)

    def execute(self, context: Context):
        # execute 可能被直接调用(脚本调用 / F9 重做)而未经 invoke, 该守卫本身必须容忍状态缺席
        if not getattr(self, "is_invoked", False):
            return self.invoke(context, None)

        self._revert_to_initial_positions()

        if self._should_recompute():
            for obj in self.objects:
                for edge_loop in self.edge_loops[obj]:
                    edge_loop.apply_linear(self.space_evenly)
            self._store_final_positions()

        self._apply_mix()
        self._update_mesh()

        self.last_mix = self.mix
        self.is_invoked = False
        return {"FINISHED"}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        col = layout.column(align=True)

        col.prop(self, "mix")
        col.prop(self, "space_evenly")


class SetEdgeCurve(Operator, _SetEdgeLoopBase):
    """
    边曲线变形操作器

    功能: 沿边环方向调整曲率
    - 支持轨道模式控制曲线
    - 支持绝对/因子模式

    要求: 在编辑模式下选择边
    """

    bl_idname = "ch.set_edge_curve"
    bl_label = "Set Edge Curve"
    bl_description = "Adjust curvature along the direction of the edgeloop\nALT: reuse last settings"
    bl_options = {'REGISTER', 'UNDO'}

    tension: IntProperty(name="Tension", default=100, soft_min=-500, soft_max=500, description="Tension can be used to tighten up the curvature")  # type: ignore
    use_rail: BoolProperty(name="Use Rail", default=False, description="Customize the interpolation by using the first and last edge to control the curvature")  # type: ignore
    rail_mode: EnumProperty(name="Rail Mode", items=[("ABSOLUTE", "Absolute", ""), ("FACTOR", "Factor", "")], default="FACTOR", description="Switch rail mode between absolute units or a factor")  # type: ignore
    rail_start_width: FloatProperty(name="Rail Start", default=1.0, subtype="DISTANCE", description="Choose how long the rail is at the start")  # type: ignore
    rail_end_width: FloatProperty(name="Rail End", default=1.0, subtype="DISTANCE", description="Choose how long the rail is at the end")  # type: ignore
    rail_start_factor: FloatProperty(name="Rail Start", default=1.0, soft_min=0.0, soft_max=1.5, subtype="FACTOR", description="Choose how long the rail is at the start")  # type: ignore
    rail_end_factor: FloatProperty(name="Rail End", default=1.0, soft_min=0.0, soft_max=1.5, subtype="FACTOR", description="Choose how long the rail is at the end")  # type: ignore

    def invoke(self, context: Context, event: Event):
        # 归一化必须早于 _init_base: 后者会把当下的 mix 快照为 last_mix,
        # 快照之后再改 mix 会使首次执行被误判为"仅调整 mix"而跳过目标位置计算
        if event and not event.alt:
            self.tension = 100
            self.mix = 1.0

        self._init_base(context)
        return self.execute(context)

    def execute(self, context: Context):
        # execute 可能被直接调用(脚本调用 / F9 重做)而未经 invoke, 该守卫本身必须容忍状态缺席
        if not getattr(self, "is_invoked", False):
            return self.invoke(context, None)

        self._revert_to_initial_positions()

        if self._should_recompute():
            for obj in self.objects:
                for edge_loop in self.edge_loops[obj]:
                    if self.rail_mode == "ABSOLUTE":
                        rail_start, rail_end = self.rail_start_width, self.rail_end_width
                    else:
                        rail_start, rail_end = self.rail_start_factor, self.rail_end_factor

                    edge_loop.apply_curve_flow(self.tension / 100.0, self.use_rail, self.rail_mode, rail_start, rail_end)

            self._store_final_positions()

        self._apply_mix()
        self._update_mesh()

        self.last_mix = self.mix
        self.is_invoked = False
        return {"FINISHED"}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        col = layout.column(align=True)

        col.prop(self, "mix")
        col.prop(self, "tension")
        col.separator()

        col.prop(self, "use_rail")

        sub_col = col.column(align=True)
        sub_col.row().prop(self, "rail_mode", expand=True)

        if self.rail_mode == "ABSOLUTE":
            sub_col.prop(self, "rail_start_width", slider=False)
            sub_col.prop(self, "rail_end_width", slider=False)
        else:
            sub_col.prop(self, "rail_start_factor")
            sub_col.prop(self, "rail_end_factor")

        sub_col.enabled = self.use_rail
