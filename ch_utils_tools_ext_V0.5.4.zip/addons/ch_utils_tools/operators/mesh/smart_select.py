"""
选择工具操作模块

提供顶点组选择,智能边选择,循环选择等功能.

操作流程:
1. VSelect: 通过可视化界面按顶点组选择网格元素
2. SSelect: 选择所有与当前选中边相连的特定类型边(锐边,折痕边,倒角权重边,缝合边,Freestyle边)
3. LSelect: 将孤立的边选择转换为循环选择

快捷键:
- VSelect:
  - 滚轮 UP/DOWN: 切换顶点组
  - S: 切换当前顶点组的选择状态
  - A: 切换所有顶点组的选择状态
  - 左键/空格: 确认选择
  - 右键/ESC: 取消
"""

__all__ = [
    "VSelect",
    "SSelect",
    "LSelect",
]

import bpy
import bmesh
from math import degrees, pi
from bpy.props import IntProperty, BoolProperty, FloatProperty, EnumProperty
from bpy.types import Context, Event, Operator, Object

from ...constants import deep_green, white
from ...items import edge_type_items
from ...utils import draw_points, force_ui_update, scroll, scroll_up, navigation_passthrough, draw_status_item, get_isolated_edges, select_loop_edges_by_angle, select_adjacent_quad_loop, is_freestyle_edge
from ...modal_base import ModalOperatorMixin


# ============================================================
# 顶点组选择操作器
# ============================================================
class VSelect(Operator, ModalOperatorMixin):
    """
    顶点组选择操作器

    功能: 通过可视化界面按顶点组选择网格元素
    - 支持滚轮切换顶点组
    - 支持预览当前顶点组
    - 支持3D视图中实时预览

    要求: 编辑模式下,活动物体有顶点组,且没有点选择或只有一个点选择
    """

    bl_idname = "ch.vselect"
    bl_label = "Vertex Group Select"
    bl_description = "Visually select mesh elements by Vertex Group"
    bl_options = {'REGISTER', 'UNDO'}

    current_idx: IntProperty(name="Current Index", default=0)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'EDIT_MESH':
            return

        sel_mode = tuple(context.scene.tool_settings.mesh_select_mode)
        if not sel_mode[0]:
            return

        act_obj = context.active_object
        if not act_obj or not act_obj.vertex_groups:
            return

        bm = bmesh.from_edit_mesh(act_obj.data)
        selected_verts = [v for v in bm.verts if v.select]
        return len(selected_verts) <= 1

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图中的顶点"""
        if context.area == self.area and self.current_vgroup_verts:
            draw_points(self.all_coords, indices=self.current_vgroup_verts, color=deep_green, size=7)
            draw_points(self.all_coords, indices=self.current_vgroup_verts, color=white, size=5, alpha=0.8)

    def modal(self, context: Context, event: Event):
        context.area.tag_redraw()
        # force_statusbar_redraw(context)

        if scroll(event):
            self._switch_vgroup(context, 1 if scroll_up(event) else -1)
        elif event.type in {'S', 'A'} and event.value == "PRESS":
            self._toggle_selection(context, all_groups=event.type == 'A')
        elif navigation_passthrough(event):
            return {'PASS_THROUGH'}
        elif event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _switch_vgroup(self, context: Context, direction: int):
        """切换顶点组"""
        self.current_idx = (self.current_idx + direction) % len(self.vgroup_list)
        vg_idx = self.vgroup_list[self.current_idx]
        self.current_vgroup_name = self.act_obj.vertex_groups[vg_idx].name
        self.current_vgroup_verts = self.vgroup_verts.get(vg_idx, [])
        context.area.header_text_set(f"Vertex Group: {self.current_vgroup_name} ({self.current_idx + 1}/{len(self.vgroup_list)})")
        force_ui_update(context)

    def _toggle_selection(self, context: Context, all_groups: bool = False):
        """切换选择状态"""
        if all_groups:
            all_selected = all(self.selected_groups.get(vg_idx, False) for vg_idx in self.vgroup_list)
            for vg_idx in self.vgroup_list:
                self.selected_groups[vg_idx] = not all_selected
        else:
            vg_idx = self.vgroup_list[self.current_idx]
            self.selected_groups[vg_idx] = not self.selected_groups.get(vg_idx, False)

        bpy.ops.mesh.select_all(action='DESELECT')
        for vg_idx, selected in self.selected_groups.items():
            if selected:
                for v_idx in self.vgroup_verts.get(vg_idx, []):
                    self.bm.verts[v_idx].select = True
        self.bm.select_flush(True)
        bmesh.update_edit_mesh(self.act_obj.data)

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 头部文本 -> 刷新)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        force_ui_update(context)

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.area = context.area
        self.mx = self.act_obj.matrix_world

        self.bm = bmesh.from_edit_mesh(self.act_obj.data)
        self.bm.verts.ensure_lookup_table()

        deform_layer = self.bm.verts.layers.deform.verify()
        selected_verts = [v for v in self.bm.verts if v.select]

        self.vgroup_verts = {}
        for v in self.bm.verts:
            for vg_idx in v[deform_layer].keys():
                self.vgroup_verts.setdefault(vg_idx, []).append(v.index)

        self.vgroup_list = sorted(self.vgroup_verts.keys())

        if not self.vgroup_list:
            self.report({'INFO'}, "No vertex groups with vertices found")
            return {'CANCELLED'}

        self.selected_groups = {}
        self.current_idx = 0

        if selected_verts:
            vgroups_in_vert = list(selected_verts[0][deform_layer].keys())
            for i, vg_idx in enumerate(self.vgroup_list):
                if vg_idx in vgroups_in_vert:
                    self.current_idx = i
                    break

        self.all_coords = [self.mx @ v.co for v in self.bm.verts]
        self._switch_vgroup(context, 0)

        self.init_status(context, func=_draw_vselect_status(self))
        self.init_modal_handlers(context, view3d=True)
        return {'RUNNING_MODAL'}


def _draw_vselect_status(op: VSelect):
    """
    VSelect状态栏绘制函数

    Args:
        op: VSelect 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='MMB_SCROLL', text="Switch", gap=1)
        draw_status_item(row, key='S', text="Toggle Selected")
        draw_status_item(row, key='A', text="Toggle All")
    return draw


# ============================================================
# 智能边选择操作器
# ============================================================
class SSelect(Operator):
    """
    边选择操作器

    功能: 选择所有与当前选中边相连的特定类型边
    - 锐边(Sharp): 标记为锐利的边
    - 倒角权重边(Bevel Weight): 带有倒角权重的边
    - 缝合边(Seam): UV缝合边
    - 折痕边(Crease): 带有折痕权重的边
    - Freestyle边: Freestyle标记边

    要求: 编辑模式下,当前选中的边中至少有一条符合选中类型的边
    """

    bl_idname = "ch.sselect"
    bl_label = "Edge Select"
    bl_description = "Select all edges of the same type connected to the existing selection"
    bl_options = {'REGISTER', 'UNDO'}

    TYPE_PRIORITY = ['SHARP', 'BEVEL_WEIGHT', 'SEAM', 'CREASE', 'FREESTYLE']

    edge_type: EnumProperty(name="Edge Type", items=edge_type_items, default='SHARP')  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'EDIT_MESH':
            if context.scene.tool_settings.mesh_select_mode[1]:
                return any(e.select for e in bmesh.from_edit_mesh(context.active_object.data).edges)

    def execute(self, context: Context):
        act_obj = context.active_object
        act_obj.update_from_editmode()

        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.verts.ensure_lookup_table()

        bw_layer = bm.edges.layers.float.get('bevel_weight_edge')
        crease_layer = bm.edges.layers.float.get('crease_edge')
        mesh_data = act_obj.data

        type_checkers = {
            'SHARP': lambda e: not e.smooth,
            'BEVEL_WEIGHT': lambda e: bw_layer and e[bw_layer] > 0,
            'SEAM': lambda e: e.seam,
            'CREASE': lambda e: crease_layer and e[crease_layer] > 0,
            'FREESTYLE': lambda e: is_freestyle_edge(mesh_data, e.index),
        }

        available_types = set()
        for e in bm.edges:
            if e.select:
                for type_key, checker in type_checkers.items():
                    if checker(e):
                        available_types.add(type_key)

        self._available_types = available_types

        if not available_types:
            self.report({'INFO'}, "Selected edges have no special edge types")
            return {'CANCELLED'}

        sorted_available = [t for t in self.TYPE_PRIORITY if t in available_types]
        if self.edge_type not in available_types:
            self.edge_type = sorted_available[0]

        checker = type_checkers[self.edge_type]
        start_edges = [e for e in bm.edges if e.select and checker(e)]
        select = set(start_edges)
        pending = list(start_edges)

        while pending:
            current = pending.pop()
            for v in current.verts:
                for e in v.link_edges:
                    if e not in select and checker(e):
                        select.add(e)
                        pending.append(e)

        for e in select:
            e.select = True

        bmesh.update_edit_mesh(act_obj.data)
        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True, heading="Edge Type")
        for type_key in self.TYPE_PRIORITY:
            if type_key in getattr(self, '_available_types', set(self.TYPE_PRIORITY)):
                row.prop_enum(self, 'edge_type', type_key)


# ============================================================
# 循环边选择操作器
# ============================================================
class LSelect(Operator):
    """
    循环选择操作器

    功能: 将孤立的边选择转换为循环选择
    - 支持角度控制
    - 支持边数限制
    - 支持面模式循环选择

    要求:
    - 边模式: 至少有一条选中的边
    - 面模式: 选中两个相邻的面
    """

    bl_idname = "ch.lselect"
    bl_label = "Loop Select"
    bl_description = "Turn isolated edge preselections into loop selections with control over the loop-angle and edge limit"
    bl_options = {'REGISTER', 'UNDO'}

    angle_threshold: FloatProperty(name="Angle Threshold", default=pi / 3, min=0, max=pi, subtype='ANGLE')  # type: ignore
    use_edge_limit: BoolProperty(name="Use Edge Limit", description="Limit how far the Loop Selection should reach", default=False)  # type: ignore
    edge_limit: IntProperty(name="Edge Limit", default=3, min=1)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'EDIT_MESH':
            bm = bmesh.from_edit_mesh(context.active_object.data)
            sel_mode = tuple(context.scene.tool_settings.mesh_select_mode)

            if sel_mode[1]:
                return any(e.select for e in bm.edges)

            elif sel_mode[2]:
                selected_faces = [f for f in bm.faces if f.select]
                return len(selected_faces) == 2

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "angle_threshold")

        row = layout.row(align=True, heading="Use Edge Limit")
        row.prop(self, "use_edge_limit", text="")
        sub_row = row.row(align=True)
        sub_row.active = self.use_edge_limit
        sub_row.prop(self, "edge_limit", text="")

    def execute(self, context: Context):
        act_obj = context.active_object

        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.verts.ensure_lookup_table()

        sel_mode = tuple(context.scene.tool_settings.mesh_select_mode)

        if sel_mode[1]:
            edges = [e for e in bm.edges if e.select]
            isolated = get_isolated_edges(edges)
            self._loop_select_edges(act_obj, isolated, limit=self.edge_limit if self.use_edge_limit else 0)

        elif sel_mode[2]:
            faces = [f for f in bm.faces if f.select]
            self._loop_select_faces(act_obj, faces)

        return {'FINISHED'}

    def _loop_select_edges(self, act_obj: Object, edges: list, limit=0):
        """边模式循环选择"""
        # 属性为 ANGLE 子类型(弧度), 工具函数按角度计算, 需转换后传入
        min_angle = 180 - degrees(self.angle_threshold)

        for edge in edges:
            vert = edge.verts[0]
            select_loop_edges_by_angle(min_angle, edge, vert, limit=limit, select=True)

            vert = edge.other_vert(vert)
            select_loop_edges_by_angle(min_angle, edge, vert, limit=limit, select=True)

            bmesh.update_edit_mesh(act_obj.data)

    def _loop_select_faces(self, act_obj: Object, faces: list):
        """面模式循环选择"""
        common = set(faces[0].edges) & set(faces[1].edges)

        if common:
            center_edge = common.pop()
            selected = select_adjacent_quad_loop(faces, center_edge)

            if selected:
                select_adjacent_quad_loop(faces, center_edge, reverse=True)
                bmesh.update_edit_mesh(act_obj.data)
            else:
                self.report({'WARNING'}, "Couldn't find 2 quads on either side of the selection!")
        else:
            self.report({'WARNING'}, "Selected 2 faces are not next to each other!")
