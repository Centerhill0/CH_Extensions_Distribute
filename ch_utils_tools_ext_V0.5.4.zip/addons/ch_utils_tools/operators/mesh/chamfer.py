"""
倒角/圆角转换操作模块

提供倒角(Chamfer)与圆角(Fillet)之间的相互转换工具:
- ChamferToFillet: 倒角转圆角
- FilletToChamfer: 圆角转倒角
- Unchamfer: 倒角转硬边
- Unfillet: 圆角转硬边(先融合为倒角面再收拢)

通用模态快捷键:
- H: 切换手柄方法(FACE/LOOP)
- S: 切换锐度标记(Sharp)
- B: 切换倒角权重标记(Bevel), ALT+滚轮调整数值
- W: 切换滑动/宽度调整模式, ALT+W 重置
- R: 反转轨道(仅单面模式)
- 滚轮: 调整分段数
- T: 张力调整模式, Z/X/C/V 张力预设, A 平均张力
- P: 投射循环, E: Freestyle切换, F: 封孔切换
"""

__all__ = ["ChamferToFillet", "FilletToChamfer", "Unchamfer", "Unfillet"]

import logging

import bpy
import bmesh
from bmesh.types import (
    BMesh,
)
from bpy.types import Operator, Context, Object, Event, VertexGroup
from bpy.props import IntProperty, FloatProperty, BoolProperty, EnumProperty
from ...items import fuse_method_items, handle_method_items, tension_preset_items

from ...utils import get_zoom_factor, get_average_position, ensure_default_data_layers, get_custom_data_layers, build_mesh_graph, init_sweeps, get_loops, change_width, create_face_intersection_handles, create_loop_intersection_handles, create_splines, fuse_surface, set_sweep_sharps_and_bweights, clear_rail_sharps_and_bweights, scroll, scroll_up, step_enum, navigation_passthrough, ignore_events, draw_status_item, format_adaptive_precision, force_ui_update, get_2_rails_from_chamfer, get_sweeps_from_fillet, fillet_to_chamfer, set_rail_sharps_and_bweights, unchamfer_loop_intersection, unchamfer_face_intersection, set_sharps_and_bweights
from ...modal_base import ModalOperatorMixin

_logger = logging.getLogger(__name__)


# ============================================================
# ChamferToFillet 倒角转圆角
# ============================================================

def _new_snapshot_bm(obj: Object) -> BMesh:
    """构建用于撤销/恢复初始状态的网格快照"""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.normal_update()
    return bm


def _apply_init_bm(init_bm: BMesh, obj: Object) -> None:
    """物体模式下把初始快照写回物体网格(带模式切换)"""
    bpy.ops.object.mode_set(mode='OBJECT')
    init_bm.to_mesh(obj.data)
    bpy.ops.object.mode_set(mode='EDIT')


def _new_work_bm(obj: Object) -> BMesh:
    """物体模式下构建工作BMesh(独立所有权, 成功后 to_mesh 回写并 free)"""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.normal_update()
    bm.select_mode = {'FACE'}
    bm.verts.ensure_lookup_table()
    return bm


def _prepare_edge_layers(bm: BMesh) -> tuple:
    """确保默认数据层, 返回 (顶点组, 倒角权重层, 全部边层列表)"""
    vg, bw, _ = ensure_default_data_layers(bm)
    return vg, bw, [bw] + get_custom_data_layers(bm)


class ChamferToFillet(Operator, ModalOperatorMixin):
    """
    切角转圆角操作器

    功能: 将选中的切角面转换为圆角
    - 支持FUSE和BRIDGE两种转换方法
    - 支持实时预览和参数调整
    - 支持张力,宽度,分段数等参数调整

    要求: 网格编辑模式下有选中的四边形面
    """

    bl_idname = "ch.chamfer_to_fillet"
    bl_label = "Chamfer to Fillet"
    bl_description = "Convert chamfer to fillet"
    bl_options = {'REGISTER', 'UNDO'}

    method: EnumProperty(name="Method", items=fuse_method_items, default="FUSE")  # type: ignore
    handle_method: EnumProperty(name="Handle Method", items=handle_method_items, default="FACE")  # type: ignore
    segments: IntProperty(name="Segments", default=6, min=0, max=30)  # type: ignore
    tension: FloatProperty(name="Tension", default=0.7, min=0.01, max=4, step=0.1)  # type: ignore
    tension_preset: EnumProperty(name="Tension Presets", items=tension_preset_items, default="CUSTOM")  # type: ignore
    average: BoolProperty(name="Average Tension", default=False)  # type: ignore
    force_projected_loop: BoolProperty(name="Projected Loops", default=False)  # type: ignore
    width: FloatProperty(name="Adjust Width", default=0.0, step=0.1)  # type: ignore
    cap_holes: BoolProperty(name="Cap Holes", default=True)  # type: ignore
    cap_dissolve_angle: IntProperty(name="Dissolve Angle", min=0, max=180, default=10)  # type: ignore
    smooth: BoolProperty(name="Shade Smooth", default=False)  # type: ignore
    reverse: BoolProperty(name="Reverse", default=False)  # type: ignore
    use_freestyle: BoolProperty(name="Use Freestyle", default=True)  # type: ignore

    # --- 模态状态 ---
    cyclic: BoolProperty(name="Cyclic", description="Is loop faces", default=False)  # type: ignore
    single: BoolProperty(name="Single", description="Is single face", default=False)  # type: ignore
    pass_through: BoolProperty(default=False)  # type: ignore
    allow_modal_width: BoolProperty(default=False)  # type: ignore
    allow_modal_tension: BoolProperty(default=False)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return len([f for f in bm.faces if f.select]) >= 1

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_obj.update_from_editmode()

        self.width = 0
        self.reverse = False
        self.force_projected_loop = False
        self.allow_modal_width = False
        self.allow_modal_tension = False

        self.init = True
        self.mat_index = 0
        self.single = False

        self.init_bm = _new_snapshot_bm(self.act_obj)

        depth_location = self.act_obj.matrix_world @ get_average_position([v.co for v in self.init_bm.verts if v.select])
        self.factor = get_zoom_factor(context, depth_location)

        self.init_mouse_position(event)

        ret = self._fuse_modal(self.act_obj)
        if not ret:
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        # 初始化状态栏
        self.init_status(context, func=_draw_chamfer_to_fillet_status(self))
        # 设置初始header文本
        self.update_header_text(context)
        # 初始化模态处理器
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        events = ['R', 'S', 'F', 'Z', 'X', 'C', 'V', 'W', 'T', 'A', 'P', 'E', 'M', 'H']
        if any([self.allow_modal_width, self.allow_modal_tension]):
            events.append('MOUSEMOVE')

        if event.type in events or scroll(event):
            if event.type == 'MOUSEMOVE':
                wrapped = self.wrap_mouse_position(context, event)
                if self.pass_through:
                    self.pass_through = False
                elif not wrapped and (self.allow_modal_width or self.allow_modal_tension):
                    if getattr(self, '_first_mouse_move', True):
                        self._first_mouse_move = False
                        self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y
                    else:
                        if self.allow_modal_width:
                            divisor = 100 if event.shift else 1 if event.ctrl else 10
                            delta_x = event.mouse_x - self.last_mouse_x
                            delta_width = delta_x / divisor * self.factor
                            self.width += delta_width
                            self.last_mouse_x = event.mouse_x

                        if self.allow_modal_tension:
                            divisor = 1000 if event.shift else 10 if event.ctrl else 100
                            delta_y = event.mouse_y - self.last_mouse_y
                            delta_tension = delta_y / divisor
                            self.tension_preset = "CUSTOM"
                            self.tension += delta_tension
                            self.last_mouse_y = event.mouse_y

            elif scroll(event):
                self._handle_scroll(event)
            else:
                self._handle_key_press(context, event)

            try:
                self.update_header_text(context)
                ret = self._fuse_modal(self.act_obj)

                if not ret:
                    self.finish(context)
                    return {'FINISHED'}
            except Exception:
                # 不得静默吞成 FINISHED: 否则用户看到"操作无声结束, 网格停在半成品",
                # 且控制台无任何线索. 记录并上报, 由 report 通道呈现给用户.
                _logger.exception("Chamfer modal failed")
                self.report({'ERROR'}, "Chamfer failed, see the system console for details")
                self.finish(context)
                return {'CANCELLED'}

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if any([self.allow_modal_width, self.allow_modal_tension]):
                self.allow_modal_width = False
                self.allow_modal_tension = False
            else:
                self.finish(context)
                return {'FINISHED'}

        elif event.type in {'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _handle_scroll(self, event: Event):
        """处理滚轮事件"""
        direction = 1 if scroll_up(event) else -1

        if self.method == "FUSE" and event.alt:
            self.cap_dissolve_angle += 5 * direction
        else:
            self.segments += direction

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.value != "PRESS":
            return

        if event.type == 'M':
            self.method = step_enum(self.method, fuse_method_items, 1)
            return

        if event.type == 'R':
            self.reverse = not self.reverse
            return

        fuse_only_keys = {
            'H': lambda: setattr(self, 'handle_method', step_enum(self.handle_method, handle_method_items, 1)),
            'S': lambda: setattr(self, 'smooth', not self.smooth),
            'F': lambda: setattr(self, 'cap_holes', not self.cap_holes),
            'P': lambda: setattr(self, 'force_projected_loop', not self.force_projected_loop),
            'E': lambda: setattr(self, 'use_freestyle', not self.use_freestyle),
        }

        if self.method == "FUSE":
            if event.type == 'W':
                if event.alt:
                    self.allow_modal_width = False
                    self.width = 0
                else:
                    self.allow_modal_width = not self.allow_modal_width
                    if self.allow_modal_width:
                        self._first_mouse_move = True
            elif event.type == 'A' and self.handle_method == "FACE":
                self.average = not self.average
            elif event.type in fuse_only_keys:
                fuse_only_keys[event.type]()

        common_keys = {
            'T': lambda: (setattr(self, 'allow_modal_tension', not self.allow_modal_tension), setattr(self, '_first_mouse_move', True) if self.allow_modal_tension else None),
            'X': lambda: setattr(self, 'tension_preset', "0.7"),
            'C': lambda: setattr(self, 'tension_preset', "1"),
            'V': lambda: setattr(self, 'tension_preset', "1.33"),
            'Z': lambda: setattr(self, 'tension_preset', "0.55"),
        }

        if event.type in common_keys:
            common_keys[event.type]()

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; 轨道提取与融合依赖的编辑模式面选择由 invoke 建立
        # (act_obj.update_from_editmode 同步后经 _fuse_modal 记录), 无交互状态时下面重建的快照
        # 取自未同步的 obj.data, 写回后会清空面选择, 使 _fuse_execute 的 max() 收到空序列抛 ValueError,
        # 故干净取消而非崩溃.
        # 不可复入 invoke 重建: invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # F9 重做走持久实例, init 与 init_bm 均存在, 不受此守卫影响
        if not hasattr(self, 'init'):
            self.report({'WARNING'}, "Chamfer to Fillet requires interactive viewport input and cannot be executed directly")
            return {'CANCELLED'}

        act_obj = context.active_object

        if not hasattr(self, 'init_bm') or self.init_bm is None:
            self.init_bm = _new_snapshot_bm(act_obj)

        if self.init_bm:
            _apply_init_bm(self.init_bm, act_obj)

        self._fuse_execute(act_obj)
        return {'FINISHED'}

    def finish(self, context: Context, cancel=False):
        """完成操作,清理资源

        Args:
            context: Blender上下文
            cancel: 是否为取消操作,取消时恢复初始状态
        """
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        if cancel:
            _apply_init_bm(self.init_bm, self.act_obj)
            self.init_bm.free()
            self.init_bm = None
        # 确认路径保留快照, 供F9 redo的execute恢复初始状态重算

        self.act_obj.update_from_editmode()

        force_ui_update(context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        row = layout.row(align=True)
        row.prop(self, "method")

        layout.prop(self, "segments")

        if self.method == "FUSE":
            row = layout.row(align=True)
            row.prop(self, "handle_method", expand=True)

            layout.prop(self, "force_projected_loop")
            row = layout.row()
            row.enabled = not self.force_projected_loop
            row.prop(self, "use_freestyle")
            layout.prop(self, "smooth")
            row = layout.row()
            row.enabled = not self.cyclic
            row.prop(self, "cap_holes")
            row = layout.row()
            row.enabled = not self.cyclic
            row.prop(self, "cap_dissolve_angle")
            layout.prop(self, "width")
        layout.prop(self, "tension")

        if self.method == "FUSE":
            if self.handle_method == "FACE":
                layout.prop(self, "average")

        if self.single:
            layout.prop(self, "reverse")

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        tension_text = format_adaptive_precision(self.tension, 2)

        text = f"Segments: {self.segments + 1} | Tension: {tension_text}"

        if self.method == "FUSE":
            width_text = format_adaptive_precision(self.width, 3)
            text += f" | Width: {width_text}"

            if not self.cyclic:
                text += f" | Dissolve: {self.cap_dissolve_angle}°"

        context.area.header_text_set(text)

    def _clean_up(self, bm: BMesh, faces: list):
        """清理原始切角面"""
        bmesh.ops.delete(bm, geom=faces, context='FACES')

    def _fuse_core(self, bm: BMesh, act_obj: Object, faces: list, rails: list, cyclic: bool, edge_layers: list, vg: VertexGroup):
        """
        执行切角转圆角的核心几何操作

        Args:
            bm: BMesh对象
            act_obj: 活动对象
            faces: 选中的面列表
            rails: 轨道顶点对列表
            cyclic: 是否为循环选择
            edge_layers: 边数据层列表
            vg: 顶点组
        """
        if self.method == "FUSE":
            self._fuse_method(bm, act_obj, rails, edge_layers, faces, vg)
        elif self.method == "BRIDGE":
            self._bridge_method(bm, act_obj, rails, edge_layers, faces)

    def _fuse_modal(self, act_obj: Object) -> bool:
        """
        模态模式下的切角转圆角操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        if self.tension_preset != "CUSTOM":
            self.tension = float(self.tension_preset)

        if self.segments == 0:
            return True

        bpy.ops.object.mode_set(mode='OBJECT')

        if self.init_bm:
            self.init_bm.to_mesh(act_obj.data)

        bm = _new_work_bm(act_obj)

        vg, _, edge_layers = _prepare_edge_layers(bm)

        faces = [f for f in bm.faces if f.select]

        if getattr(self, 'init', False):
            self.init = False
            self.single = len(faces) == 1
            self.smooth = any(f.smooth for f in faces)

            matindices = [f.material_index for f in faces]
            self.mat_index = max(set(matindices), key=matindices.count)

        if not self._rails_and_fuse(bm, act_obj, faces, edge_layers, vg):
            bm.free()
            bpy.ops.object.mode_set(mode='EDIT')
            return False

        bm.to_mesh(act_obj.data)
        bm.free()
        bpy.ops.object.mode_set(mode='EDIT')

        if self.method == "BRIDGE":
            bpy.ops.mesh.bridge_edge_loops(number_cuts=self.segments, smoothness=self.tension, interpolation='SURFACE')

        return True

    def _fuse_execute(self, act_obj: Object) -> bool:
        """
        直接执行模式下的切角转圆角操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        if self.segments <= 0:
            return False

        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.select_mode = {'FACE'}
        bm.verts.ensure_lookup_table()

        vg, _, edge_layers = _prepare_edge_layers(bm)

        faces = [f for f in bm.faces if f.select]

        self.single = len(faces) == 1

        matindices = [f.material_index for f in faces]
        self.mat_index = max(set(matindices), key=matindices.count)

        if not self._rails_and_fuse(bm, act_obj, faces, edge_layers, vg):
            return False

        bmesh.update_edit_mesh(act_obj.data)

        if self.method == "BRIDGE":
            bpy.ops.mesh.bridge_edge_loops(number_cuts=self.segments, smoothness=self.tension, interpolation='SURFACE')

        return True

    def _rails_and_fuse(self, bm: BMesh, act_obj: Object, faces: list, edge_layers: list, vg) -> bool:
        """
        提取轨道并执行FUSE融合(公共流程, 供模态与直接执行两种模式复用)

        Args:
            bm: BMesh对象
            act_obj: 活动对象
            faces: 选中的面列表
            edge_layers: 边数据层列表
            vg: 顶点组

        Returns:
            bool: 是否成功
        """
        mg = build_mesh_graph(bm)

        ret, err = get_2_rails_from_chamfer(bm, mg, faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        self._fuse_core(bm, act_obj, faces, rails, cyclic, edge_layers, vg)
        return True

    def _fuse_method(self, bm: BMesh, act_obj: Object, rails: list, edge_layers: list, faces: list, vg: VertexGroup):
        """FUSE方法: 使用贝塞尔曲线生成圆角"""
        sweeps = init_sweeps(bm, act_obj, rails, freestyle=self.use_freestyle)
        get_loops(edge_layers, sweeps, force_projected=self.force_projected_loop)

        if self.width != 0:
            change_width(sweeps, self.width)

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=self.tension, average=self.average)
        elif self.handle_method == "LOOP":
            create_loop_intersection_handles(sweeps, self.tension)

        spline_sweeps = create_splines(bm, sweeps, self.segments)
        self._clean_up(bm, faces)
        fuse_surface(bm, spline_sweeps, self.smooth, self.mat_index, self.cap_holes, self.cap_dissolve_angle, self.cyclic)

        set_sweep_sharps_and_bweights(bm, edge_layers, sweeps, spline_sweeps, vg=vg)
        clear_rail_sharps_and_bweights(bm, edge_layers, rails, self.cyclic)

    def _bridge_method(self, bm: BMesh, act_obj: Object, rails: list, edge_layers: list, faces: list):
        """BRIDGE方法: 使用Blender内置桥接功能"""
        for f in bm.faces:
            f.select = False

        bmesh.ops.delete(bm, geom=faces, context='FACES')
        clear_rail_sharps_and_bweights(bm, edge_layers, rails, self.cyclic, select=True)


def _draw_chamfer_to_fillet_status(op: ChamferToFillet):
    """
    返回 ChamferToFillet 操作的状态栏绘制回调函数

    Args:
        op: ChamferToFillet 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='M', text=f"{op.method.capitalize()}", gap=1)
        draw_status_item(row, key='MMB_SCROLL', text="Segments")

        if op.single:
            draw_status_item(row, active=op.reverse, key='R', text="Reverse")

        if op.method == "FUSE":
            draw_status_item(row, key='H', text=f"Handle({op.handle_method.capitalize()})")

            draw_status_item(row, active=op.force_projected_loop, key='P', text="Projected Loops", gap=3)
            draw_status_item(row, active=op.use_freestyle and not op.force_projected_loop, key='E', text="Freestyle")
            draw_status_item(row, active=op.smooth, key='S', text="Smooth")

            if not op.cyclic:
                draw_status_item(row, active=op.cap_holes, key='F', text="Cap Holes", gap=3)
                if op.cap_holes:
                    draw_status_item(row, key=['ALT', 'MMB_SCROLL'], text="Dissolve Angle")

            draw_status_item(row, active=op.allow_modal_width, key=['W', 'MOVE'], text="Adjust Width", gap=3)
            if op.allow_modal_width:
                draw_status_item(row, key=['ALT', 'W'], text="Reset")

        draw_status_item(row, active=op.allow_modal_tension, key=['T', 'MOVE'], text="Tension", gap=3)
        draw_status_item(row, key='Z', text="0.55")
        draw_status_item(row, key='X', text="0.7")
        draw_status_item(row, key='C', text="1.0")
        draw_status_item(row, key='V', text="1.33")

        if op.method == "FUSE":
            if op.handle_method == "FACE":
                draw_status_item(row, active=op.average, key='A', text="Average Tension")

    return draw


# ============================================================
# FilletToChamfer 圆角转倒角
# ============================================================
class FilletToChamfer(Operator):
    """
    圆角转倒角操作器

    功能: 将选中的圆角面转换为倒角面
    - 支持标记锐度和倒角权重
    - 自动提取轨道边

    要求: 网格编辑模式下有选中的圆角面
    """

    bl_idname = "ch.fillet_to_chamfer"
    bl_label = "Fillet to Chamfer"
    bl_description = "Convert fillet to chamfer"
    bl_options = {'REGISTER', 'UNDO'}

    mark_sharp: BoolProperty(name="Mark Sharp", default=False)  # type: ignore
    mark_bevel_weight: BoolProperty(name="Mark Bevel Weight", default=False)  # type: ignore
    bevel_weight: FloatProperty(name="Bevel Weight", default=1.0, min=0.0, max=1.0)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return len([f for f in bm.faces if f.select]) >= 1

    def execute(self, context: Context):
        obj = context.active_object
        me_data = obj.data

        bm = bmesh.from_edit_mesh(me_data)
        bm.normal_update()
        bm.select_mode = {'FACE'}

        bm.verts.ensure_lookup_table()
        bw = ensure_default_data_layers(bm)[1]
        mg = build_mesh_graph(bm)
        faces = [f for f in bm.faces if f.select]

        sweeps, err = get_sweeps_from_fillet(bm, mg, faces)

        if not err:
            chamfer_faces, err = fillet_to_chamfer(bm, sweeps)

        if not err:
            chamfer_mg = build_mesh_graph(bm)
            ret, err = get_2_rails_from_chamfer(bm, chamfer_mg, chamfer_faces, False)

        if not err:
            chamfer_rails, cyclic = ret
            set_rail_sharps_and_bweights(bm, bw, chamfer_rails, cyclic, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)
            bmesh.update_edit_mesh(me_data)
        else:
            self.report({'WARNING'}, err)

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "mark_sharp")

        row = layout.row(align=True, heading="Mark Bevel Weight")
        row.prop(self, "mark_bevel_weight", text="")
        sub_row = row.row(align=True)
        sub_row.enabled = self.mark_bevel_weight
        sub_row.prop(self, "bevel_weight", text="")


# ============================================================
# 倒角/圆角转硬边 公共基类
# ============================================================
class _UnchamferBase(ModalOperatorMixin):
    """
    倒角转硬边公共基类

    提供交互流程(模态/直接执行), 属性与清理逻辑;
    核心转换算法由子类通过 _core_modal/_core_execute 实现.
    """

    handle_method: EnumProperty(name="Handle Method", items=handle_method_items, default="FACE")  # type: ignore
    slide: FloatProperty(name="Slide", default=0, min=-1, max=1)  # type: ignore
    reverse: BoolProperty(name="Reverse", default=False)  # type: ignore
    mark_sharp: BoolProperty(name="Mark Sharp", default=True)  # type: ignore
    mark_bevel_weight: BoolProperty(name="Mark Bevel Weight", default=False)  # type: ignore
    bevel_weight: FloatProperty(name="Bevel Weight", default=1, min=0, max=1)  # type: ignore

    # --- 模态状态 ---
    cyclic: BoolProperty(name="Cyclic", description="Is loop faces", default=False)  # type: ignore
    single: BoolProperty(name="Single", description="Is single face", default=False)  # type: ignore
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    allow_modal_slide: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return len([f for f in bm.faces if f.select]) >= 1

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_obj.update_from_editmode()

        self.slide = 0
        self.reverse = False
        self.allow_modal_slide = False
        self.init = True

        self.init_bm = _new_snapshot_bm(self.act_obj)

        depth_location = self.act_obj.matrix_world @ get_average_position([v.co for v in self.init_bm.verts if v.select])
        self.factor = get_zoom_factor(context, depth_location)

        self.init_mouse_position(event)

        ret = self._core_modal(self.act_obj)
        if not ret:
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        self.init_status(context, func=_draw_unchamfer_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        context.area.tag_redraw()

        events = ['H', 'S', 'B', 'W', 'R']
        if self.allow_modal_slide:
            events.append('MOUSEMOVE')

        if event.type in events or scroll(event):
            if event.type == 'MOUSEMOVE':
                wrapped = self.wrap_mouse_position(context, event)
                if self.pass_through:
                    self.pass_through = False
                elif self.allow_modal_slide and not wrapped:
                    divisor = 1000 if event.shift else 10 if event.ctrl else 100
                    delta_x = event.mouse_x - self.last_mouse_x
                    self.slide += delta_x / divisor

                if not wrapped:
                    self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y

            elif scroll(event):
                self._handle_scroll(event)
            else:
                self._handle_key_press(context, event)

            try:
                self.update_header_text(context)
                ret = self._core_modal(self.act_obj)

                if not ret:
                    self.finish(context)
                    return {'FINISHED'}
            except Exception:
                # 不得静默吞成 FINISHED: 否则用户看到"操作无声结束, 网格停在半成品",
                # 且控制台无任何线索. 记录并上报, 由 report 通道呈现给用户.
                _logger.exception("Chamfer modal failed")
                self.report({'ERROR'}, "Chamfer failed, see the system console for details")
                self.finish(context)
                return {'CANCELLED'}

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if self.allow_modal_slide:
                self.allow_modal_slide = False
            else:
                self.finish(context)
                return {'FINISHED'}

        elif event.type in {'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _handle_scroll(self, event: Event):
        """处理滚轮事件"""
        if event.alt:
            direction = 1 if scroll_up(event) else -1
            self.bevel_weight = max(0, min(1, self.bevel_weight + 0.1 * direction))

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.value != "PRESS":
            return

        key_actions = {
            'H': lambda: setattr(self, 'handle_method', step_enum(self.handle_method, handle_method_items, 1)),
            'S': lambda: setattr(self, 'mark_sharp', not self.mark_sharp),
            'B': lambda: setattr(self, 'mark_bevel_weight', not self.mark_bevel_weight),
            'R': lambda: setattr(self, 'reverse', not self.reverse),
        }

        if event.type in key_actions:
            key_actions[event.type]()
        elif event.type == 'W':
            if event.alt:
                self.allow_modal_slide = False
                self.slide = 0
            else:
                self.allow_modal_slide = not self.allow_modal_slide

    def execute(self, context: Context):
        act_obj = context.active_object

        if not hasattr(self, 'init_bm') or self.init_bm is None:
            self.init_bm = _new_snapshot_bm(act_obj)

        if self.init_bm:
            _apply_init_bm(self.init_bm, act_obj)

        self._core_execute(act_obj)
        return {'FINISHED'}

    def finish(self, context: Context, cancel: bool = False):
        """
        完成操作,清理资源

        Args:
            context: Blender上下文
            cancel: 是否为取消操作,取消时恢复初始状态
        """
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        if cancel:
            _apply_init_bm(self.init_bm, self.act_obj)
            self.init_bm.free()
            self.init_bm = None
        # 确认路径保留快照, 供F9 redo的execute恢复初始状态重算

        self.act_obj.update_from_editmode()
        force_ui_update(context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        row = layout.row(align=True)
        row.prop(self, "handle_method", expand=True)

        if self.handle_method == "FACE":
            layout.prop(self, "slide")

        row = layout.row(align=True, heading="Mark Bevel Weight")
        row.prop(self, "mark_bevel_weight", text="")
        sub_row = row.row(align=True)
        sub_row.enabled = self.mark_bevel_weight
        sub_row.prop(self, "bevel_weight", text="")

        layout.prop(self, "mark_sharp")
        if self.single:
            layout.prop(self, "reverse")

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        parts = []

        if self.handle_method == "FACE":
            parts.append(f"Slide: {format_adaptive_precision(self.slide, 2)}")

        if self.mark_bevel_weight:
            parts.append(f"Bevel Weight: {self.bevel_weight:.1f}")

        context.area.header_text_set(" | ".join(parts) if parts else None)

    def _clean_up(self, bm: BMesh, faces: list, double_verts: list | None = None):
        """
        清理原始倒角面

        Args:
            bm: BMesh对象
            faces: 要删除的面列表
            double_verts: 需要合并的重叠顶点列表
        """
        bmesh.ops.delete(bm, geom=faces, context='FACES')

        if double_verts:
            bmesh.ops.remove_doubles(bm, verts=double_verts, dist=0.00001)

            two_edged_verts = [v for v in double_verts if v.is_valid and len(v.link_edges) == 2]
            if two_edged_verts:
                bmesh.ops.dissolve_verts(bm, verts=two_edged_verts)

    def _report_intersection_error(self):
        """报告交点计算错误"""
        if self.single:
            self.report({'WARNING'}, "Loop edges don't intersect. You can't unchamfer in this direction! Try toggling Reverse.")
        else:
            self.report({'WARNING'}, "Loop edges don't intersect.")

    def _core_modal(self, act_obj: Object) -> bool:
        """子类实现: 模态模式下的核心转换, 返回是否成功"""
        raise NotImplementedError

    def _core_execute(self, act_obj: Object) -> bool:
        """子类实现: 直接执行模式下的核心转换, 返回是否成功"""
        raise NotImplementedError


# ============================================================
# Unchamfer 倒角转硬边
# ============================================================
class Unchamfer(Operator, _UnchamferBase):
    """
    倒角转硬边操作器

    功能: 将选中的倒角面转换为硬边
    - 支持FACE和LOOP两种手柄方法
    - 支持实时预览和参数调整
    - 支持滑动,锐度,倒角权重等参数调整

    要求: 网格编辑模式下有选中的倒角面
    """

    bl_idname = "ch.unchamfer"
    bl_label = "Unchamfer"
    bl_description = "Reconstruct hard edge from Chamfer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return len([f for f in bm.faces if f.select]) >= 1 or len([e for e in bm.edges if e.select]) > 0

    def _core_modal(self, act_obj: Object) -> bool:
        """
        模态模式下的倒角转硬边操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        bpy.ops.object.mode_set(mode='OBJECT')

        if self.init_bm:
            self.init_bm.to_mesh(act_obj.data)

        bm = _new_work_bm(act_obj)

        _, bw, edge_layers = _prepare_edge_layers(bm)

        mg = build_mesh_graph(bm)
        faces = [f for f in bm.faces if f.select]

        self.single = len(faces) == 1

        if getattr(self, 'init', False):
            self.init = False
            self.mark_sharp = any(f.smooth for f in faces)

        ret, err = get_2_rails_from_chamfer(bm, mg, faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            bm.free()
            bpy.ops.object.mode_set(mode='EDIT')
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        sweeps = init_sweeps(bm, act_obj, rails)

        get_loops(edge_layers, sweeps)

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_face_intersection(bm, sweeps, slide=self.slide)
        else:
            create_loop_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_loop_intersection(bm, sweeps)

        self._clean_up(bm, faces, double_verts)

        if double_verts:
            set_sharps_and_bweights([e for e in bm.edges if e.select], bw, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)

            bm.to_mesh(act_obj.data)
            bm.free()
            bpy.ops.object.mode_set(mode='EDIT')
            return True

        bm.free()
        self._report_intersection_error()
        bpy.ops.object.mode_set(mode='EDIT')
        return False

    def _core_execute(self, act_obj: Object) -> bool:
        """
        直接执行模式下的倒角转硬边操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.select_mode = {'FACE'}
        bm.verts.ensure_lookup_table()

        _, bw, edge_layers = _prepare_edge_layers(bm)

        mg = build_mesh_graph(bm)
        faces = [f for f in bm.faces if f.select]

        self.single = len(faces) == 1

        ret, err = get_2_rails_from_chamfer(bm, mg, faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        sweeps = init_sweeps(bm, act_obj, rails)

        get_loops(edge_layers, sweeps)

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_face_intersection(bm, sweeps, slide=self.slide)
        else:
            create_loop_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_loop_intersection(bm, sweeps)

        self._clean_up(bm, faces, double_verts)

        if double_verts:
            set_sharps_and_bweights([e for e in bm.edges if e.select], bw, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)

            bmesh.update_edit_mesh(act_obj.data)
            return True

        self._report_intersection_error()
        return False


def _draw_unchamfer_status(op):
    """
    返回 Unchamfer/Unfillet 共用的状态栏绘制回调函数

    Args:
        op: 操作器实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='H', text=f"Handle({op.handle_method.capitalize()})", gap=1)

        draw_status_item(row, active=op.mark_sharp, key='S', text="Sharp", gap=3)
        draw_status_item(row, active=op.mark_bevel_weight, key='B', text="Bevel Weight")
        if op.mark_bevel_weight:
            draw_status_item(row, key=['ALT', 'MMB_SCROLL'], text=f"({op.bevel_weight:.1f})")

        if op.handle_method == "FACE":
            draw_status_item(row, active=op.allow_modal_slide, key=['W', 'MOVE'], text="Slide", gap=3)
            draw_status_item(row, active=op.allow_modal_slide, key=['ALT', 'W'], text="Reset")

        if op.single:
            draw_status_item(row, active=op.reverse, key='R', text="Reverse")
    return draw


# ============================================================
# Unfillet 圆角转硬边
# ============================================================
class Unfillet(Operator, _UnchamferBase):
    """
    圆角转硬边操作器

    功能: 将选中的圆角面转换为硬边
    - 支持FACE和LOOP两种手柄方法
    - 支持实时预览和参数调整
    - 支持滑动,锐度,倒角权重等参数调整

    要求: 网格编辑模式下有选中的圆角面
    """

    bl_idname = "ch.unfillet"
    bl_label = "Unfillet"
    bl_description = "Reconstruct hard edge from Fillet by using Unfuse + Unchamfer in sequence"
    bl_options = {'REGISTER', 'UNDO'}

    def _get_chamfer_faces(self, bm: BMesh, act_obj: Object) -> tuple[list, bool]:
        """
        将圆角面先转换为倒角面(Unfuse前置步骤)

        Args:
            bm: BMesh对象
            act_obj: 活动对象

        Returns:
            (倒角面列表, 是否成功)
        """
        mg = build_mesh_graph(bm)
        initial_faces = [f for f in bm.faces if f.select]

        initial_sweeps, err = get_sweeps_from_fillet(bm, mg, initial_faces)

        if err:
            self.report({'WARNING'}, err)
            return [], False

        chamfer_faces, err = fillet_to_chamfer(bm, initial_sweeps)

        if err:
            self.report({'WARNING'}, err)
            return [], False

        return chamfer_faces, True

    def _core_modal(self, act_obj: Object) -> bool:
        """
        模态模式下的圆角转硬边操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        bpy.ops.object.mode_set(mode='OBJECT')

        if self.init_bm:
            self.init_bm.to_mesh(act_obj.data)

        bm = _new_work_bm(act_obj)

        _, bw, edge_layers = _prepare_edge_layers(bm)

        chamfer_faces, ok = self._get_chamfer_faces(bm, act_obj)

        if not ok:
            bm.free()
            bpy.ops.object.mode_set(mode='EDIT')
            return False

        self.single = len(chamfer_faces) == 1

        if getattr(self, 'init', False):
            self.init = False
            self.mark_sharp = any(f.smooth for f in chamfer_faces)

        chamfer_mg = build_mesh_graph(bm)

        ret, err = get_2_rails_from_chamfer(bm, chamfer_mg, chamfer_faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            bm.free()
            bpy.ops.object.mode_set(mode='EDIT')
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        sweeps = init_sweeps(bm, act_obj, rails)

        get_loops(edge_layers, sweeps)

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_face_intersection(bm, sweeps, slide=self.slide)
        else:
            create_loop_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_loop_intersection(bm, sweeps)

        self._clean_up(bm, chamfer_faces, double_verts)

        if double_verts:
            set_sharps_and_bweights([e for e in bm.edges if e.select], bw, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)

            bm.to_mesh(act_obj.data)
            bm.free()
            bpy.ops.object.mode_set(mode='EDIT')
            return True

        bm.free()
        self._report_intersection_error()
        bpy.ops.object.mode_set(mode='EDIT')
        return False

    def _core_execute(self, act_obj: Object) -> bool:
        """
        直接执行模式下的圆角转硬边操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.select_mode = {'FACE'}
        bm.verts.ensure_lookup_table()

        _, bw, edge_layers = _prepare_edge_layers(bm)

        chamfer_faces, ok = self._get_chamfer_faces(bm, act_obj)

        if not ok:
            return False

        self.single = len(chamfer_faces) == 1

        chamfer_mg = build_mesh_graph(bm)

        ret, err = get_2_rails_from_chamfer(bm, chamfer_mg, chamfer_faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        sweeps = init_sweeps(bm, act_obj, rails)

        get_loops(edge_layers, sweeps)

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_face_intersection(bm, sweeps, slide=self.slide)
        else:
            create_loop_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_loop_intersection(bm, sweeps)

        self._clean_up(bm, chamfer_faces, double_verts)

        if double_verts:
            set_sharps_and_bweights([e for e in bm.edges if e.select], bw, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)

            bmesh.update_edit_mesh(act_obj.data)
            return True

        self._report_intersection_error()
        return False
