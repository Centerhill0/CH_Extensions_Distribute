"""
孔洞挤出操作器模块

提供以下功能:
- HoleExtrude: 将选中的面向内挤出形成孔洞

操作流程:
1. 选择要挤出的面(或闭合的顶点/边环)
2. 拖动鼠标设置挤出深度
3. 调整推拉参数优化结果
4. 确认完成

支持的挤出方向:
- AVERAGE: 平均法线方向
- NORMAL: 各顶点法线方向
- EDGE: 自定义边方向
- CURSOR: 游标轴向

快捷键:
挤出阶段:
- A: 切换到平均法线方向
- N: 切换到各顶点法线方向
- E: 拾取边方向
- C: 切换到游标轴向
- X/Y/Z: 切换游标轴向(仅CURSOR模式)
- R: 重置挤出起点
- 左键/空格: 确认挤出
- 右键/ESC: 取消操作

推拉调整阶段:
- W: 同时调整推和拉
- E: 调整推值
- Q: 调整拉值
- R: 重置推拉值
- S: 切换自相交选项
- A: 切换自动清理
- X: 切换移除冗余边
- Shift: 反向调整
- Ctrl: 加速调整(x100)
- 左键/空格/回车: 完成操作
- 右键/ESC: 返回挤出阶段
"""

__all__ = ["HoleExtrude"]

import math
from copy import copy
from dataclasses import dataclass

import bpy
import bmesh
from bmesh.types import BMesh
from bpy.types import Operator, Context, Event
from mathutils import Vector
from mathutils.geometry import intersect_line_line, intersect_point_line
from bpy.props import FloatProperty, BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d

from ...preference import get_prefs
from ...constants import red, green, blue, white, cyan, yellow, orange, normal, magenta
from ...mappings import ctrl, numbers, input_mappings, axis_vector_mappings, axis_color_mappings
from ...items import axis_items, extrude_mode_items
from ...utils import (
    get_bmesh,
    get_vert_sequences,
    get_mesh_element_islands,
    get_loop_triangles,
    get_boundary_edges,
    ensure_face_cut_layer,
    rotate_list,
    get_average_position,
    get_average_normals,
    raycast_from_point,
    RaycastCache,
    draw_status_item,
    force_ui_update,
    format_adaptive_precision,
    draw_label,
    draw_line,
    draw_lines,
    draw_point,
    draw_tris,
    draw_vector,
    ignore_events,
    get_face_angle,
    navigation_passthrough,
    get_lerp_position,
    Snap,
)
from ...modal_base import ModalOperatorMixin


@dataclass
class HoleVertData:
    """挤洞顶点载荷(原始/挤出顶点共用, 存于 original_verts/extruded_verts 容器)"""

    co: Vector  # 当前坐标
    init_co: Vector  # 初始坐标
    exit_co: Vector | None  # 射线出口坐标
    vert_dir: Vector  # 顶点法线方向(取反)
    push_dir: Vector | None  # 边界推挤方向
    bound_idx: int  # 边界序列索引, 内部顶点为-1



# ============================================================
# 孔洞挤出操作器
# ============================================================
class HoleExtrude(Operator, ModalOperatorMixin):
    """
    孔洞挤出

    功能:将选中的面向内挤出形成孔洞
    - 支持多种挤出方向模式
    - 支持推拉调整优化结果
    - 支持自动网格清理
    - 支持数值输入精确控制

    要求:网格编辑模式下有选中的面或闭合边环
    """

    bl_idname = "ch.hole_extrude"
    bl_label = "Hole Extrude"
    bl_description = "Extrude selected faces into hole"
    bl_options = {'REGISTER', 'UNDO'}

    is_use_self: BoolProperty(name="Is Use Self Intersection", description="Use Self Intersection. Slower but may produce better results.\nIf disabled, you'll often need bigger Push and Pull values.", default=True)  # type: ignore
    mode: EnumProperty(name="Mode", description="Extrude mode", items=extrude_mode_items, default='AVERAGE')  # type: ignore
    cursor_axis: EnumProperty(name="Cursor Axis", description="Cursor Axis", items=axis_items, default='X')  # type: ignore

    depth: FloatProperty(name="Depth", description="Extrude Depth", default=0.5, min=0, precision=4, step=0.1)  # type: ignore
    pushed: IntProperty(name="Push", description="Push Side Faces Out", default=1)  # type: ignore
    pulled: IntProperty(name="Pull", description="Pull Side Faces Back", default=1)  # type: ignore

    is_numeric_input: BoolProperty(default=False)  # type: ignore
    numeric_input_amount: StringProperty(name="Numeric Amount to Move Face", description="Amount to Move the Face Selection by", default='0')  # type: ignore

    auto_cleanup: BoolProperty(name="Auto Mesh Cleanup", description="Run an automatic mesh cleanup at the end", default=True)  # type: ignore
    remove_redundant: BoolProperty(name="Remove Redundant Edges", description="Remove Redundant Edges", default=True)  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_obj.update_from_editmode()

        # 缓存矩阵数据
        self.act_mx = self.act_obj.matrix_world
        self.cursor_mx = context.scene.cursor.matrix

        # 创建初始bmesh对象
        self.init_bm = bmesh.new()
        self.init_bm.from_mesh(self.act_obj.data)
        self.init_bm.normal_update()

        # 创建bmesh对象
        self.bm = get_bmesh(self.act_obj.data)

        # 确保face_cut层存在
        ensure_face_cut_layer(self.bm, "hole_extrude")

        self.cache = RaycastCache()  # BVH射线检测缓存, 避免重复构建
        self.is_mesh_non_manifold = False

        selection = self.get_selection(context, self.bm)

        if selection:
            self.data: dict = self.get_data(*selection)
            self.get_exit_coords()
            self.get_extruded_data()
            self.get_side_data()

            # 如果没有区域数据,直接执行
            if not context.region_data:
                return self.execute(context)

            self.init_mouse_position(event, hud=True)

            # 获取鼠标位置
            self.depth = 0
            self.set_extrusion_direction(context, 'AVERAGE')

            if not getattr(self, 'init_loc', None):
                # 鼠标视线与挤出方向平行时无交点, 清理资源并中止
                self.cache.clear()
                self.init_bm.free()
                self.report({'WARNING'}, "Mouse ray is parallel to the extrusion direction!")
                return {'CANCELLED'}

            # 初始化其他属性
            self.finalizing = False
            self.cleaned_up_general = 0
            self.cleaned_up_redundant = 0

            self.is_edge_picking = False
            self.edge_coords = None

            self.prev_mode = 'AVERAGE'

            self.is_numeric_input = False
            self.numeric_input_amount = '0'

            # 更新修饰键状态
            self.update_mod_keys()
            # 初始化Snap
            self.S = Snap(context)
            # 初始化状态栏
            self.init_status(context, func=_draw_hole_extrude_status(self))
            # 设置初始header文本
            self.update_header_text(context)
            # 强制UI更新
            force_ui_update(context)
            # 初始化模态处理器
            self.init_modal_handlers(context, hud=True, view3d=True)

            return {'RUNNING_MODAL'}

        return {'CANCELLED'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        if ret := self._numeric_input(context, event):
            return ret

        return self._interactive_input(context, event)

    def _numeric_input(self, context, event):
        if not self.finalizing:
            numeric_start_events = [*numbers, 'PERIOD', 'COMMA', 'NUMPAD_PERIOD', 'NUMPAD_COMMA']

            if not self.is_numeric_input and event.type in numeric_start_events and event.value == 'PRESS':
                self.is_numeric_input = True
                self.numeric_input_amount = input_mappings.get(event.type, '.')
                self.update_header_text(context)
                force_ui_update(context)
                return {'RUNNING_MODAL'}

            if self.is_numeric_input:
                if event.type in ctrl:
                    return {'RUNNING_MODAL'}

                events = [*numbers, 'BACK_SPACE', 'PERIOD', 'COMMA', 'NUMPAD_PERIOD', 'NUMPAD_COMMA']

                if event.type in events and event.value == 'PRESS':
                    if event.type in numbers:
                        self.numeric_input_amount += input_mappings[event.type]

                    elif event.type == 'BACK_SPACE':
                        if len(self.numeric_input_amount) > 1:
                            self.numeric_input_amount = self.numeric_input_amount[:-1]
                        else:
                            self.is_numeric_input = False
                            self.update_header_text(context)
                            force_ui_update(context)
                            return {'RUNNING_MODAL'}

                    elif event.type in ['COMMA', 'PERIOD', 'NUMPAD_COMMA', 'NUMPAD_PERIOD'] and '.' not in self.numeric_input_amount:
                        self.numeric_input_amount += '.'

                    try:
                        self.depth = float(self.numeric_input_amount)
                        self.update_header_text(context)
                        force_ui_update(context)

                    except ValueError:
                        return {'RUNNING_MODAL'}

                    self.set_extrusion_amount(context, interactive=False)

                elif navigation_passthrough(event, alt=True, wheel=True):
                    return {'PASS_THROUGH'}

                elif event.type in {'RET', 'NUMPAD_ENTER', 'LEFTMOUSE'} and event.value == 'PRESS':
                    self.set_push_and_pull_amount(context)

                    self.create_extruded_geo(self.act_obj, self.bm)

                    bpy.ops.mesh.intersect_boolean(operation='DIFFERENCE', use_self=self.is_use_self, solver='EXACT')
                    bpy.ops.mesh.select_all(action='DESELECT')

                    self.cleanup(generic=self.auto_cleanup, redundant=self.remove_redundant)

                    self.act_obj.update_from_editmode()

                    self.finalizing = True
                    return {'RUNNING_MODAL'}

                elif event.type == 'ESC' and event.value == 'PRESS':
                    self.is_numeric_input = False
                    self.update_header_text(context)
                    force_ui_update(context)
                    return {'RUNNING_MODAL'}

                elif event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
                    self.finish(context)
                    return {'CANCELLED'}

                return {'RUNNING_MODAL'}

    def _interactive_input(self, context: Context, event: Event):
        """
        处理模态操作期间的交互输入事件

        Args:
            context: Blender上下文对象
            event: 输入事件对象
        """
        # 处理鼠标移动事件
        if event.type == 'MOUSEMOVE':
            self.init_mouse_position(event)

            # 如果之前处于穿透模式,重置初始位置
            if self.pass_through:
                self.pass_through = False
                intersection = self.get_mouse_intersection(context)
                self.init_loc = intersection - self.amount_dir * self.depth

        # 非最终化阶段(挤出阶段)
        if not self.finalizing:
            # 边拾取模式切换
            if event.type in ['E', *ctrl]:
                if event.value == 'PRESS':
                    self.is_edge_picking = True
                    self.get_edge_direction(context)
                elif event.value == 'RELEASE':
                    self.is_edge_picking = False

                self.update_header_text(context)
                force_ui_update(context)
                return {'RUNNING_MODAL'}

            # 定义可处理的事件类型
            events = ['MOUSEMOVE', 'A', 'N', 'R', 'C']

            # 光标模式下添加坐标轴切换事件
            if self.mode == 'CURSOR':
                events.extend(['X', 'Y', 'Z'])

            # 处理主要事件
            if event.type in events:
                # 鼠标移动事件
                if event.type == 'MOUSEMOVE':
                    if self.is_edge_picking:
                        self.get_edge_direction(context)
                    else:
                        self.loc = self.get_mouse_intersection(context)
                        self.set_extrusion_amount(context)

                # 重置初始位置
                elif event.type == 'R' and event.value == 'PRESS':
                    self.init_loc = self.get_mouse_intersection(context)
                    self.set_extrusion_amount(context)

                # 切换挤出方向模式
                elif event.type == 'A' and event.value == 'PRESS':
                    self.set_extrusion_direction(context, direction='AVERAGE')
                    self.set_extrusion_amount(context)

                elif event.type == 'N' and event.value == 'PRESS':
                    self.set_extrusion_direction(context, direction='NORMAL')
                    self.set_extrusion_amount(context)

                elif event.type == 'C' and event.value == 'PRESS':
                    self.set_extrusion_direction(context, direction='CURSOR', init_cursor=True)
                    self.set_extrusion_amount(context)

                # 光标模式下切换坐标轴
                elif event.type in ['X', 'Y', 'Z']:
                    self.cursor_axis = event.type
                    self.set_extrusion_direction(context, direction='CURSOR', init_cursor=False)
                    self.set_extrusion_amount(context)

                self.update_header_text(context)
                force_ui_update(context)

            # 导航穿透事件(视图操作)
            elif navigation_passthrough(event, alt=True, wheel=True):
                self.pass_through = True
                return {'PASS_THROUGH'}

            # 确认挤出操作
            if self.depth and event.type in {'LEFTMOUSE', 'SPACE'} and event.value == 'PRESS':
                self.set_push_and_pull_amount(context)
                self.create_extruded_geo(self.act_obj, self.bm)

                # 执行布尔差集运算
                bpy.ops.mesh.intersect_boolean(operation='DIFFERENCE', use_self=self.is_use_self, solver='EXACT')
                bpy.ops.mesh.select_all(action='DESELECT')

                # 清理网格
                self.cleanup(generic=self.auto_cleanup, redundant=self.remove_redundant)
                self.act_obj.update_from_editmode()

                # 进入最终化阶段
                self.finalizing = True
                self.update_header_text(context)
                return {'RUNNING_MODAL'}

            # 取消操作
            elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
                self.finish(context)
                return {'CANCELLED'}

        # 最终化阶段(推拉调整阶段)
        else:
            # 更新修饰键状态
            self.update_mod_keys(event)

            # 定义可处理的事件类型
            events = ['Q', 'W', 'E', 'R', 'S', 'A']

            # 如果启用了自动清理,添加冗余清理切换事件
            if self.auto_cleanup:
                events.append('X')

            # 处理推拉调整事件
            if event.type in events and event.value == 'PRESS':
                # 重置网格到初始状态
                bm = self.reset_mesh(self.init_bm, return_bmesh=True)

                # 计算调整因子(Ctrl键加速)
                factor = 100 if self.is_ctrl else 1
                delta = -factor if self.is_shift else factor

                # 使用字典映射处理按键事件
                key_actions = {
                    'W': lambda: (setattr(self, 'pushed', self.pushed + delta), setattr(self, 'pulled', self.pulled + delta)),
                    'E': lambda: setattr(self, 'pushed', self.pushed + delta),
                    'Q': lambda: setattr(self, 'pulled', self.pulled + delta),
                    'R': lambda: (setattr(self, 'pushed', 1), setattr(self, 'pulled', 1)),
                    'S': lambda: setattr(self, 'is_use_self', not self.is_use_self),
                    'A': lambda: setattr(self, 'auto_cleanup', not self.auto_cleanup),
                    'C': lambda: setattr(self, 'auto_cleanup', not self.auto_cleanup),
                    'X': lambda: setattr(self, 'remove_redundant', not self.remove_redundant),
                }

                if event.type in key_actions:
                    key_actions[event.type]()

                # 应用推拉调整
                self.set_push_and_pull_amount(context)
                self.create_extruded_geo(self.act_obj, bm)

                # 执行布尔差集运算
                bpy.ops.mesh.intersect_boolean(operation='DIFFERENCE', use_self=self.is_use_self, solver='EXACT')
                bpy.ops.mesh.select_all(action='DESELECT')

                # 清理网格
                self.cleanup(generic=self.auto_cleanup, redundant=self.remove_redundant)
                self.act_obj.update_from_editmode()

                self.update_header_text(context)
                return {'RUNNING_MODAL'}

            # 导航穿透事件
            elif navigation_passthrough(event, alt=True, wheel=True):
                return {'PASS_THROUGH'}

            # 完成操作
            elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                self.finish(context)
                return {'FINISHED'}

            # 返回挤出阶段
            elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
                self.bm = self.reset_mesh(self.init_bm, return_bmesh=True)
                self.finalizing = False
                self.pass_through = True
                self.update_header_text(context)
                return {'RUNNING_MODAL'}

        # 默认返回运行状态
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; data 完全由 invoke 的选区解析派生,
        # 且 depth 是 RNA 属性(默认 0.5, 非零), 直调会先进入挤出分支才暴露 data 缺失, 故须在顶部守卫.
        # 不可复入 invoke 重建: invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # invoke 的"无区域数据直接执行"分支(自身调用 execute)已在此前设好 data, 不受此守卫影响;
        # F9 重做走持久实例, data 已存在, 同样不受影响
        if not hasattr(self, "data"):
            self.report({'WARNING'}, "Hole Extrude requires interactive viewport input and cannot be executed directly")
            return {'CANCELLED'}

        self.cleaned_up_general = 0
        self.cleaned_up_redundant = 0

        if self.depth:
            self.act_obj = context.active_object

            if self.mode == 'EDGE' and not self.data['edge_dir']:
                self.mode = 'AVERAGE'  # avoid EDGE mode when an edge dir was never set

            self.bm = bmesh.from_edit_mesh(self.act_obj.data)
            self.bm.normal_update()

            ensure_face_cut_layer(self.bm, "hole_extrude")

            self.set_extrusion_amount(context, interactive=False)

            self.set_push_and_pull_amount(context)

            self.create_extruded_geo(self.act_obj, self.bm)

            bpy.ops.mesh.intersect_boolean(operation='DIFFERENCE', use_self=self.is_use_self, solver='EXACT')
            bpy.ops.mesh.select_all(action='DESELECT')

            self.cleanup(generic=self.auto_cleanup, redundant=self.remove_redundant)

            self.act_obj.update_from_editmode()

        return {'FINISHED'}

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 头部文本 -> 释放资源)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        self.S.finish()
        self.cache.clear()
        self.init_bm.free()
        self.act_obj.update_from_editmode()

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "mode", expand=True)

        # column = layout.column(align=True)
        if self.mode == 'CURSOR':
            row = layout.row(align=True)
            row.prop(self, "cursor_axis", expand=True)

        layout.prop(self, "depth")
        layout.prop(self, "pushed")
        layout.prop(self, "pulled")

        layout.prop(self, "is_use_self")
        layout.prop(self, "auto_cleanup")
        if self.auto_cleanup:
            layout.prop(self, "remove_redundant")
            # 显示清理结果
            column = layout.column(align=True)
            if self.cleaned_up_general:
                info_row = column.row(align=True)
                info_row.alignment = 'RIGHT'
                info_row.label(text=f"{self.cleaned_up_general} verts removed", icon="INFO")
                info_row.label(text='', icon='CHECKMARK')

            if self.cleaned_up_redundant:
                info_row = column.row(align=True)
                info_row.alignment = 'RIGHT'
                info_row.label(text=f"{self.cleaned_up_redundant} edges removed", icon="INFO")
                info_row.label(text='', icon='CHECKMARK')

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        unit_settings = context.scene.unit_settings
        length_unit = unit_settings.length_unit

        unit_symbols = {'METERS': 'm', 'CENTIMETERS': 'cm', 'MILLIMETERS': 'mm', 'MICROMETERS': 'µm', 'FEET': 'ft', 'INCHES': 'in', 'ADAPTIVE': 'm' if unit_settings.system == 'METRIC' else 'ft'}
        unit_symbol = unit_symbols.get(length_unit, 'm')

        if not self.finalizing:
            if self.is_numeric_input:
                text = f"Depth: {self.numeric_input_amount} {unit_symbol}"
            else:
                depth_text = format_adaptive_precision(self.depth, 1)
                text = f"Depth: {depth_text} {unit_symbol}"
        else:
            depth_text = format_adaptive_precision(self.depth, 1)
            text = f"Depth: {depth_text} {unit_symbol} | Push: {self.pushed} | Pull: {self.pulled}"

        context.area.header_text_set(text)

    def draw_HUD(self, context: Context):
        if self.pass_through:
            return

        elif context.area == self.area:
            # 初始化参数
            self.draw_init()
            # 主标题
            dims = draw_label(context, scale=self.hud_scale, title="Hole Extrude", coords=Vector((self.HUD_x, self.HUD_y)), offset=0, center=False, alpha=0.5, init_obj=self)

            if not self.finalizing:

                if self.is_edge_picking:
                    draw_label(context, scale=self.hud_scale, title="Pick Direction", coords=Vector((self.HUD_x + dims.x + 15, self.HUD_y)), offset=0, center=False, init_obj=self)

                    self.offset += 18
                    dims = draw_label(context, scale=self.hud_scale, title="Edge:", coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, alpha=0.5)
                    title, color, alpha = ("Valid", yellow, 1) if self.edge_coords and self.data['edge_dir'] else ("Invalid", red, 1) if self.edge_coords else ("None", white, 0.5)

                    draw_label(context, scale=self.hud_scale, title=title, coords=Vector((self.HUD_x + dims.x, self.HUD_y)), offset=self.offset, center=False, color=color, alpha=alpha, init_obj=self)

                else:
                    draw_label(context, scale=self.hud_scale, title="Extrude", coords=Vector((self.HUD_x + dims.x + 15, self.HUD_y)), offset=0, center=False, init_obj=self)

                    self.offset += 18
                    dims = draw_label(context, scale=self.hud_scale, title="Along:", coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, alpha=0.5, init_obj=self)
                    if self.mode == 'CURSOR':
                        dims += draw_label(context, scale=self.hud_scale, title=f"{self.mode.title()} ", coords=Vector((self.HUD_x + dims.x + 12, self.HUD_y)), offset=self.offset, center=False, color=magenta, init_obj=self)
                        draw_label(context, scale=self.hud_scale, title=self.cursor_axis, coords=Vector((self.HUD_x + dims.x + 20, self.HUD_y)), offset=self.offset, center=False, color=axis_color_mappings[self.cursor_axis], init_obj=self)

                    else:
                        mode_colors = {
                            'EDGE': yellow,
                            'AVERAGE': green,
                            'NORMAL': cyan,
                        }
                        color = mode_colors.get(self.mode, white)
                        draw_label(context, scale=self.hud_scale, title=self.mode.title(), coords=Vector((self.HUD_x + dims.x + 12, self.HUD_y)), offset=self.offset, center=False, color=color, init_obj=self)

            else:
                draw_label(context, scale=self.hud_scale, title="Finish", coords=Vector((self.HUD_x + dims.x + 15, self.HUD_y)), offset=0, center=False, init_obj=self)

                self.offset += 18
                draw_label(context, scale=self.hud_scale, title="Use Self Intersection:" + (" True" if self.is_use_self else " False"), coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=cyan, init_obj=self)

                if self.auto_cleanup:
                    self.offset += 18
                    dims = draw_label(context, scale=self.hud_scale, title="Auto Cleanup:", coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=orange, init_obj=self)

                    if self.cleaned_up_general:
                        draw_label(context, scale=self.hud_scale, title=f"{self.cleaned_up_general} Verts Removed ✔️", coords=Vector((self.HUD_x + dims.x + 5, self.HUD_y)), offset=self.offset, center=False, size=self.size - 2, color=white, init_obj=self)
                    else:
                        draw_label(context, scale=self.hud_scale, title="None", coords=Vector((self.HUD_x + dims.x, self.HUD_y)), offset=self.offset, center=False, size=self.size - 2, color=white, alpha=0.5, init_obj=self)

                    self.offset += 18

                    color, alpha = (orange, 1) if self.remove_redundant else (white, 0.5)
                    draw_label(context, scale=self.hud_scale, title="Redundant:", coords=Vector((self.HUD_x + dims.x - self.get_text_dimensions("Redundant:", self.font_id, self.size).x, self.HUD_y)), offset=self.offset, center=False, color=color, alpha=alpha, init_obj=self)

                    if self.cleaned_up_redundant:
                        draw_label(context, scale=self.hud_scale, title=f"{self.cleaned_up_redundant} Edges Removed ✔️", coords=Vector((self.HUD_x + dims.x + 5, self.HUD_y)), offset=self.offset, center=False, size=self.size - 1, color=white, init_obj=self)
                    else:
                        draw_label(context, scale=self.hud_scale, title="None", coords=Vector((self.HUD_x + dims.x + 5, self.HUD_y)), offset=self.offset, center=False, size=self.size - 1, color=white, alpha=0.5, init_obj=self)

                if self.is_mesh_non_manifold:
                    self.offset += 24
                    draw_label(context, scale=self.hud_scale, title="Non-manifold meshes tend to require higher Push/Pull values", coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=orange, init_obj=self)

                    self.offset += 18
                    draw_label(context, scale=self.hud_scale, title="and may still produce undesired results", coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=orange, init_obj=self)

    def draw_VIEW3D(self, context: Context):
        """在3D视图中绘制孔洞挤出的可视化辅助信息"""
        if context.area == self.area:
            data = self.data
            orig_verts = data['original_verts']
            extr_verts = data['extruded_verts']

            if self.finalizing:
                # 挤出完成后显示最终三角面,侧面和边界
                tri_coords = [orig_verts[idx].co for idx in data['original_tri_indices']]
                draw_tris(tri_coords, mx=self.act_mx, color=green, alpha=0.05, xray=False)

                tri_coords = [(orig_verts | extr_verts)[idx].co for idx in data['side_tri_indices']]
                draw_tris(tri_coords, mx=self.act_mx, color=blue, alpha=0.05, xray=False)

                boundary_coords = [orig_verts[vidx].co for vidx in data['sorted_boundary']]
                draw_line(boundary_coords, indices=data['sorted_boundary_indices'], mx=self.act_mx, color=white, alpha=0.05)

                extr_boundary_coords = [extr_verts[data['vert_map'][vidx]].co for vidx in data['sorted_boundary']]
                draw_line(extr_boundary_coords, indices=data['sorted_boundary_indices'], mx=self.act_mx, color=white, alpha=0.05)

                side_line_coords = [(orig_verts | extr_verts)[idx].co for vidx in data['sorted_boundary'] for idx in [vidx, data['vert_map'][vidx]]]
                draw_lines(side_line_coords, mx=self.act_mx, color=white, alpha=0.05)

            else:
                # 挤出预览与动态辅助
                avg_co = self.act_mx @ data['avg_co']
                edge_dir = data['edge_dir']

                # 平均中心点
                draw_point(avg_co, color=red if self.depth == 0 else white)

                if self.depth:
                    # 挤出方向向量
                    extr_dir = self.loc - self.init_loc
                    draw_vector(extr_dir, origin=avg_co, fade=True, alpha=0.5)
                    draw_point(avg_co + extr_dir, size=4, alpha=0.5)

                    # 所有三角面预览
                    tri_coords = [(orig_verts | extr_verts)[idx].co for idx in data['original_tri_indices'] + data['extruded_tri_indices'] + data['side_tri_indices']]
                    draw_tris(tri_coords, mx=self.act_mx, color=green, alpha=0.1)

                    # 挤出后边界线
                    extr_boundary_coords = [extr_verts[data['vert_map'][vidx]].co for vidx in data['sorted_boundary']]
                    draw_line(extr_boundary_coords, indices=data['sorted_boundary_indices'], mx=self.act_mx, color=green, alpha=0.2)

                    # 侧边连线(根据模式变色)
                    mode_colors = {
                        'EDGE': (yellow, 0.5),
                        'AVERAGE': (blue, 1),
                        'CURSOR': (axis_color_mappings[self.cursor_axis], 1),
                        'NORMAL': (normal, 1),
                    }
                    color, alpha_val = mode_colors.get(self.mode, (normal, 1))
                    side_line_coords = [(orig_verts | extr_verts)[idx].co for vidx in data['sorted_boundary'] for idx in [vidx, data['vert_map'][vidx]]]
                    draw_lines(side_line_coords, mx=self.act_mx, color=color, alpha=alpha_val)

                # 边选取高亮
                if self.is_edge_picking and self.edge_coords:
                    color = yellow if self.edge_coords and edge_dir else red
                    draw_line(self.edge_coords, color=color, width=2, alpha=0.99)

                # 出口点连线
                exit_coords = [orig_verts[vidx].exit_co for vidx in data['sorted_boundary'] if orig_verts[vidx].exit_co]
                if exit_coords:
                    exit_coords.append(exit_coords[0])
                    draw_line(exit_coords, mx=self.act_mx, alpha=0.1)

    def get_selection(self, context: Context, bm: BMesh):
        """
        基于用户选择模式获取相应的面选择

        Args:
            context: Blender上下文
            bm: BMesh对象

        Returns:
            tuple: (faces, loop_triangles, sorted_boundary_verts, inner_verts) 或 None
        """
        # 检查网格是否为非流行
        self.is_mesh_non_manifold = not all(e.is_manifold for e in bm.edges)
        # 如果网格是非流形的,且偏好设置中未启用非流形网格支持,则显示警告信息
        if self.is_mesh_non_manifold and not get_prefs().non_manifold_extrude:
            self.report({'WARNING'}, "Mesh is Non-manifold, try enabling non-manifold mesh support in the addon preferences")
            return

        faces = {f for f in bm.faces if f.select}
        if not faces:
            verts = {v for v in bm.verts if v.select}
            if verts:
                sequences = get_vert_sequences(verts, ensure_seq_len=True)
                if len(sequences):
                    vert_seq_list = [s for s, c in sequences if c]
                    if len(vert_seq_list) == 0:
                        self.report({'WARNING'}, "You need to select at least one face or a closed verts/edge loop")
                        return
                    elif len(vert_seq_list) == 1:
                        vert_seq = vert_seq_list[0]
                    else:
                        vert_seq = max(vert_seq_list, key=lambda x: len(x))

                    for s, _ in sequences:
                        if s != vert_seq:
                            for v in s:
                                v.select_set(False)
                    bm.select_flush_mode()

                    bpy.ops.mesh.loop_to_region()
                    faces = {f for f in bm.faces if f.select}
                else:
                    self.report({'WARNING'}, "You need to select at least one face or a closed verts/edge loop")
                    return
            else:
                self.report({'WARNING'}, "You need to select at least one face or a closed verts/edge loop")
                return

        islands = get_mesh_element_islands(faces)
        faces = max(islands, key=lambda x: len(x[2]))[2]

        if set(faces) == {f for f in bm.faces}:
            self.report({'WARNING'}, "The whole mesh is selected")
            return

        loop_triangles = get_loop_triangles(bm, faces)
        verts = {v for f in faces for v in f.verts}
        boundary_edges = get_boundary_edges(faces)
        boundary_verts = list(set(v for e in boundary_edges for v in e.verts))
        inner_verts = [v for v in verts if v not in boundary_verts]

        has_non_manifold_verts = any(any(not e.is_manifold for e in v.link_edges) for v in boundary_verts)
        if has_non_manifold_verts:
            self.report({'WARNING'}, "Selection is next to non-manifold edges!")
            return

        sequences = get_vert_sequences(boundary_verts, boundary_edges)
        if len(sequences) > 1:
            self.report({'WARNING'}, "Selection contains multiple edge loops, try selecting a single loop")
            return

        sorted_boundary_verts = sequences[0][0]
        first_edge = bm.edges.get(sorted_boundary_verts[:2])

        for loop in first_edge.link_loops:
            if loop.face in faces:
                if loop.vert != sorted_boundary_verts[0]:
                    sorted_boundary_verts.reverse()

        smallest = min(sorted_boundary_verts, key=lambda x: x.index)

        if smallest != sorted_boundary_verts[0]:
            rotate_list(sorted_boundary_verts, sorted_boundary_verts.index(smallest))

        return faces, loop_triangles, sorted_boundary_verts, inner_verts

    def get_data(self, faces, loop_triangles, sorted_boundary_verts, inner_verts):
        """
        收集并组织挤洞操作所需的所有几何与拓扑数据

        Args:
            faces: 选中的面集合
            loop_triangles: 选中面片的三角形循环列表
            sorted_boundary_verts: 有序边界顶点列表
            inner_verts: 内部顶点列表

        Returns:
            dict: 包含所有关键数据的字典
        """
        # 初始化数据字典
        data = {
            'original_verts': {},
            'extruded_verts': {},
            'original_faces': {},
            'extruded_faces': {},
            'side_faces': {},
            'original_tri_indices': [],
            'extruded_tri_indices': [],
            'side_tri_indices': [],
            'sorted_boundary': [],
            'sorted_boundary_indices': [],
            'vert_map': {},
            'avg_co': get_average_position([f.calc_center_median() for f in faces]),
            'avg_dir': -get_average_normals([f.normal for f in faces]),
            'edge_co': None,
            'edge_dir': None,
            'cursor_dir_x': self.act_mx.inverted_safe().to_3x3() @ (self.cursor_mx.to_quaternion() @ axis_vector_mappings['X']),
            'cursor_dir_y': self.act_mx.inverted_safe().to_3x3() @ (self.cursor_mx.to_quaternion() @ axis_vector_mappings['Y']),
            'cursor_dir_z': self.act_mx.inverted_safe().to_3x3() @ (self.cursor_mx.to_quaternion() @ axis_vector_mappings['Z']),
            'area': 0,
        }

        # 保证坐标轴方向与平均法线方向一致,若相反则取反
        for axis, *_ in axis_items:
            cursor_dir = data[f"cursor_dir_{axis.lower()}"]
            if cursor_dir.dot(data['avg_dir']) < 0:
                cursor_dir.negate()

        seen = {}  # 记录顶点对象到索引的映射,避免重复
        orig_verts = data['original_verts']
        orig_faces = data['original_faces']
        vidx = 0  # 顶点索引计数器

        # 遍历所有面,收集顶点和面信息
        for fidx, f in enumerate(faces):
            face_vidx_list = []  # 当前面的顶点索引列表
            for v in f.verts:
                if v not in seen:
                    seen[v] = vidx
                    # 计算该顶点的法线方向(取反)
                    vert_dir = -get_average_normals([f.normal for f in v.link_faces if f in faces])
                    # 判断是否为内顶点,边界顶点需记录其在边界序列中的索引
                    bound_idx = -1 if v in inner_verts else sorted_boundary_verts.index(v)
                    orig_verts[vidx] = HoleVertData(
                        co=v.co.copy(),
                        init_co=v.co.copy(),
                        exit_co=None,
                        vert_dir=vert_dir,
                        push_dir=None,
                        bound_idx=bound_idx,
                    )
                    face_vidx_list.append(vidx)
                    vidx += 1
                else:
                    face_vidx_list.append(seen[v])
            orig_faces[fidx] = face_vidx_list
            data['area'] += f.calc_area()

        # 记录所有三角面顶点索引
        data['original_tri_indices'] = [seen[l.vert] for lt in loop_triangles for l in lt]

        # 生成有序边界顶点索引及其成对索引
        sorted_boundary = [seen[v] for v in sorted_boundary_verts]
        data['sorted_boundary'] = sorted_boundary
        data['sorted_boundary_indices'] = [(idx, (idx + 1) % len(sorted_boundary)) for idx in range(len(sorted_boundary))]

        # 计算每个边界顶点的推挤方向(push_dir)
        for idx, vidx in enumerate(sorted_boundary):
            v_co = orig_verts[vidx].co
            vert_dir = orig_verts[vidx].vert_dir
            next_vidx = sorted_boundary[(idx + 1) % len(sorted_boundary)]
            prev_vidx = sorted_boundary[(idx - 1) % len(sorted_boundary)]
            # 前后相邻顶点方向
            fwd_vec = (orig_verts[next_vidx].co - v_co).normalized()
            bwd_vec = (orig_verts[prev_vidx].co - v_co).normalized()
            # 前后方向的合成
            fwd_dir = (v_co + fwd_vec - (v_co + bwd_vec)).normalized()
            # 推挤方向为法线与前后方向的叉积
            push_dir = vert_dir.cross(fwd_dir)
            orig_verts[vidx].push_dir = push_dir

        return data

    def get_exit_coords(self, direction='AVERAGE'):
        """
        计算边界顶点在指定方向上的射线投射出口坐标

        Args:
            direction: 投射方向类型
                - 'AVERAGE': 使用平均方向
                - 'EDGE': 使用边方向
                - 'CURSOR': 使用游标方向
                - 其他: 使用每个顶点的垂直方向
        """
        # 重置BVH缓存(网格数据已变化, 旧缓存失效)
        self.cache.clear()

        # 计算偏移量:基于面积平方根的小量,避免自相交
        offset = math.sqrt(self.data['area']) * 0.00001

        # 使用字典映射获取射线方向
        direction_map = {
            'AVERAGE': lambda: self.data['avg_dir'],
            'EDGE': lambda: self.data['edge_dir'],
            'CURSOR': lambda: self.data[f"cursor_dir_{self.cursor_axis.lower()}"],
        }

        get_direction = direction_map.get(direction)
        ray_direction = get_direction() if get_direction else None

        # 遍历排序后的边界顶点索引
        for idx in self.data['sorted_boundary']:
            # 获取顶点数据
            vdata = self.data['original_verts'][idx]
            # 确定当前顶点的射线方向
            # 如果指定了全局方向,使用全局方向;否则使用顶点的垂直方向
            current_ray_dir = ray_direction if ray_direction else vdata.vert_dir
            # 计算射线起点:初始坐标 - 推挤方向偏移 + 射线方向偏移
            # 双重偏移确保射线从网格外部开始,避免自相交
            ray_origin = vdata.init_co - vdata.push_dir * offset + current_ray_dir * offset
            # 执行BVH射线投射
            _, hitloc, *_ = raycast_from_point(ray_origin, direction=current_ray_dir, cache=self.cache, candidates=[self.act_obj])

            # 如果命中,记录出口坐标
            if hitloc:
                vdata.exit_co = hitloc

    def get_extruded_data(self):
        """
        基于原始顶点和面数据,生成挤出后的顶点,面,三角面索引及映射关系

        结果写入 self.data 的 extruded_verts, extruded_faces, extruded_tri_indices, vert_map 等字段
        """
        data = self.data

        vert_count = len(data['original_verts'])
        face_count = len(data['original_faces'])

        for orig_vidx, orig_vdata in data['original_verts'].items():
            extr_vdata = copy(orig_vdata)
            extr_vidx = orig_vidx + vert_count
            data['extruded_verts'][extr_vidx] = extr_vdata
            data['vert_map'][orig_vidx] = extr_vidx
            data['vert_map'][extr_vidx] = orig_vidx

        for orig_fidx, orig_fdata in data['original_faces'].items():
            extr_fidx = orig_fidx + face_count
            extr_fdata = [data['vert_map'][vidx] for vidx in orig_fdata]
            data['extruded_faces'][extr_fidx] = extr_fdata

        data['extruded_tri_indices'] = [data['vert_map'][idx] for idx in data['original_tri_indices']]

    def get_side_data(self):
        """
        生成侧面数据

        为每一对相邻边界顶点构建四边形侧面,并生成三角面索引.
        结果写入 self.data 的 side_faces 和 side_tri_indices 字段.
        """
        data = self.data
        sorted_boundary = data['sorted_boundary']
        # 侧面索引起始值:原始面数+挤出面数
        side_face_idx = len(data['original_faces']) + len(data['extruded_faces'])

        for idx, orig_vidx in enumerate(sorted_boundary):
            extr_vidx = data['vert_map'][orig_vidx]  # 挤出后顶点索引
            next_orig_vidx = sorted_boundary[(idx + 1) % len(sorted_boundary)]
            next_extr_vidx = data['vert_map'][next_orig_vidx]
            # 构建四边形侧面(顺序:原,挤出,下一个挤出,下一个原)
            data['side_faces'][side_face_idx] = [orig_vidx, extr_vidx, next_extr_vidx, next_orig_vidx]
            side_face_idx += 1
            # 拆分为两个三角面索引(顺序保证法线朝外)
            data['side_tri_indices'].extend([orig_vidx, extr_vidx, next_extr_vidx, orig_vidx, next_extr_vidx, next_orig_vidx])

    def set_extrusion_direction(self, context: Context, direction='AVERAGE', init_cursor=False):
        """
        设置挤出方向并初始化相关参数

        Args:
            context: Blender上下文对象
            direction: 挤出方向模式,可选值: 'AVERAGE', 'NORMAL', 'EDGE', 'CURSOR'
            init_cursor: 是否初始化游标方向(仅 CURSOR 模式有效)
        """
        # 设置当前模式
        self.mode = direction

        # 计算挤出起点和方向
        if direction in ['AVERAGE', 'NORMAL']:
            # 使用平均法线方向
            self.amount_origin = self.act_mx @ self.data['avg_co']
            self.amount_dir = self.act_mx.to_3x3() @ self.data['avg_dir']

        elif direction == 'EDGE':
            # 使用边界方向
            self.amount_origin = self.act_mx @ self.data['edge_co']
            self.amount_dir = self.act_mx.to_3x3() @ self.data['edge_dir']

        elif direction == 'CURSOR':
            # 使用光标方向
            self.amount_origin = self.act_mx @ self.data['avg_co']

            if init_cursor:
                # 初始化光标方向:选择与平均法线最对齐的坐标轴
                cursor_dirs = [(axis, self.data[f"cursor_dir_{axis.lower()}"].dot(self.data['avg_dir']), self.data[f"cursor_dir_{axis.lower()}"]) for axis, _, _ in axis_items]

                # 选择点积最大的轴(最对齐的轴)
                aligned = max(cursor_dirs, key=lambda x: x[1])

                self.amount_dir = self.act_mx.to_3x3() @ aligned[2]
                self.cursor_axis = aligned[0]
            else:
                # 使用已选择的光标轴
                self.amount_dir = self.act_mx.to_3x3() @ self.data[f"cursor_dir_{self.cursor_axis.lower()}"]

        # 获取鼠标交点并设置初始位置
        intersection = self.get_mouse_intersection(context)

        if intersection:
            # 计算挤出起点(考虑当前挤出量)
            self.init_loc = intersection - self.amount_dir * self.depth
            self.loc = intersection

        # 计算出口坐标
        self.get_exit_coords(direction=direction)

    def set_extrusion_amount(self, context: Context, interactive=True):
        """
        设置挤出量并更新挤出顶点坐标

        Args:
            context: Blender上下文
            interactive: 是否为交互模式(如鼠标拖动)
        """
        if interactive:
            # 交互模式下,根据鼠标移动方向和距离计算挤出量
            amount_vector = self.loc - self.init_loc
            # 只有当移动方向与挤出方向一致时才允许挤出,否则为0
            self.depth = amount_vector.length if amount_vector.dot(self.amount_dir) > 0 else 0

        if self.depth > 0:
            # 使用字典映射获取挤出方向
            direction_map = {
                'AVERAGE': lambda: self.data['avg_dir'],
                'EDGE': lambda: self.data['edge_dir'],
                'NORMAL': lambda vdata: vdata.vert_dir,
                'CURSOR': lambda: self.data[f"cursor_dir_{self.cursor_axis.lower()}"],
            }

            get_direction = direction_map.get(self.mode)
            if get_direction:
                for vdata in self.data['extruded_verts'].values():
                    direction = get_direction(vdata) if self.mode == 'NORMAL' else get_direction()
                    vdata.co = vdata.init_co + direction * self.depth
        else:
            # 挤出量为0,重置初始位置
            self.init_loc = self.get_mouse_intersection(context)
            self.loc = self.init_loc

    def set_push_and_pull_amount(self, context: Context):
        """
        根据推拉参数调整顶点坐标,实现侧面推挤和拉回效果

        Args:
            context: Blender上下文
        """
        data = self.data
        mode = self.mode

        orig_verts = data['original_verts']
        extr_verts = data['extruded_verts']

        # 推拉缩放因子,基于选区面积
        push_pull_scale = math.sqrt(data['area']) * 0.00001

        # 使用字典映射获取挤出方向
        direction_map = {
            'AVERAGE': lambda: data['avg_dir'],
            'EDGE': lambda: data['edge_dir'],
            'CURSOR': lambda: data[f"cursor_dir_{self.cursor_axis.lower()}"],
        }

        for vidx, vdata in (orig_verts | extr_verts).items():
            # 坐标初始值
            co = vdata.init_co.copy()

            # 获取挤出方向
            get_direction = direction_map.get(mode)
            extr_dir = self.depth * (get_direction() if get_direction else vdata.vert_dir)

            # 挤出顶点:加上挤出方向
            if vidx in extr_verts:
                co += extr_dir

            # 推:沿 push_dir 方向移动
            if vdata.push_dir and self.pushed:
                co += vdata.push_dir * push_pull_scale * self.pushed

            # 拉:原始顶点沿挤出方向反向移动
            if vidx in orig_verts and self.pulled:
                # 防止 extr_dir 为零导致归一化异常
                norm_dir = extr_dir.normalized() if extr_dir.length > 0 else extr_dir
                co -= norm_dir * push_pull_scale * self.pulled

            # 更新顶点坐标
            vdata.co = co

    def create_extruded_geo(self, active, bm: BMesh):
        """
        根据挤出数据生成新几何体(顶点,面),并标记切割面

        Args:
            active: 当前活动对象
            bm: BMesh对象
        """
        data = self.data

        vert_map = {}
        faces = []

        face_layer = bm.faces.layers.int.get('HoleExtrude', None)

        for vidx, vdata in (data['original_verts'] | data['extruded_verts']).items():
            v = bm.verts.new(vdata.co)
            vert_map[vidx] = v

        for fidx, indices in (data['original_faces'] | data['extruded_faces'] | data['side_faces']).items():
            verts = [vert_map[vidx] for vidx in indices]
            f = bm.faces.new(verts)
            faces.append(f)

        bmesh.ops.recalc_face_normals(bm, faces=faces)

        bpy.ops.mesh.select_all(action='DESELECT')

        for f in faces:
            f.select_set(True)
            if face_layer:
                f[face_layer] = 1

        bmesh.update_edit_mesh(active.data)

    def cleanup(self, generic=True, redundant=True):
        """
        网格清理操作,包括常规清理和冗余边处理

        Args:
            generic: 是否执行常规清理(去重,溶解退化,删除孤立元素)
            redundant: 是否处理冗余边(角度为0的边)
        """
        bm = bmesh.from_edit_mesh(self.act_obj.data)
        bm.normal_update()
        face_layer = bm.faces.layers.int.get('HoleExtrude', None)

        init_vert_count = len([v for v in bm.verts])

        # 常规清理:去重,溶解退化,删除孤立元素
        if generic:
            bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0001)
            bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=0.0001)

            # 删除孤立顶点
            loose_verts = [v for v in bm.verts if not v.link_edges]
            if loose_verts:
                bmesh.ops.delete(bm, geom=loose_verts, context="VERTS")

            # 删除孤立边
            loose_edges = [e for e in bm.edges if not e.link_faces]
            if loose_edges:
                bmesh.ops.delete(bm, geom=loose_edges, context="EDGES")

            # 删除完全非流形的面
            loose_faces = [f for f in bm.faces if all([not e.is_manifold for e in f.edges])]
            if loose_faces:
                bmesh.ops.delete(bm, geom=loose_faces, context="FACES")

        # 冗余边处理:溶解切割面中角度为0的边
        redundant_edges = []
        cut_faces = set()
        if redundant and face_layer:
            cut_faces = set([f for f in bm.faces if f[face_layer] == 1])
            if cut_faces:
                edges = set([e for f in cut_faces for e in f.edges])
                for e in edges:
                    angle = get_face_angle(e, signed=False)
                    if round(angle, 2) == 0:
                        redundant_edges.append(e)
                if redundant_edges:
                    bmesh.ops.dissolve_edges(bm, edges=redundant_edges, use_verts=False)

        # 移除切割面标记层
        if face_layer:
            bm.faces.layers.int.remove(face_layer)

        # 同步到编辑网格
        bmesh.update_edit_mesh(self.act_obj.data)

        # 统计清理数量
        vert_count = len([v for v in bm.verts])
        self.cleaned_up_general = init_vert_count - vert_count
        self.cleaned_up_redundant = len(redundant_edges) if redundant and face_layer and cut_faces else 0

    def get_mouse_intersection(self, context: Context):
        """
        获取鼠标位置与挤出方向线的交点

        Args:
            context: Blender上下文对象

        Returns:
            Vector: 交点的3D坐标,如果没有找到交点则返回 None
        """
        try:
            # 获取视图原点和视图方向向量
            view_origin = region_2d_to_origin_3d(context.region, context.region_data, self.mouse_region_pos)
            view_dir = region_2d_to_vector_3d(context.region, context.region_data, self.mouse_region_pos)

            # 计算交点, 视线与方向线平行时返回 None
            intersection = intersect_line_line(self.amount_origin, self.amount_origin + self.amount_dir, view_origin, view_origin + view_dir)
            return intersection[0] if intersection else None

        except Exception:
            return None

    def get_edge_direction(self, context: Context):
        """
        获取鼠标点击的边方向,用于 EDGE 模式下的挤出方向

        Args:
            context: Blender上下文对象
        """
        # 获取鼠标点击信息
        self.S.update_hit(self.mouse_region_pos)

        # 如果不是EDGE模式,保存当前模式以便回退
        if self.mode != 'EDGE':
            self.prev_mode = self.mode

        # 如果点击有效
        if self.S.hit:
            hitmx = self.S.hit_mx
            hit_co = hitmx.inverted_safe() @ self.S.hit_location
            hitface = self.S.hit_face

            # 找到点击的边:计算每条边到点击点的距离,选择最近的边
            edge = min([(e, (hit_co - intersect_point_line(hit_co, e.verts[0].co, e.verts[1].co)[0]).length, (hit_co - get_lerp_position(*e.verts)).length) for e in hitface.edges if e.calc_length()], key=lambda x: (x[1] * x[2]) / x[0].calc_length())

            # 计算边方向
            edge_dir = (edge[0].verts[1].co - edge[0].verts[0].co).normalized()

            # 保存边坐标(世界空间)
            self.edge_coords = [hitmx @ v.co for v in edge[0].verts]

            # 计算点击点在边上的最近点
            closest_point_on_edge = intersect_point_line(hit_co, edge[0].verts[0].co, edge[0].verts[1].co)[0]

            # 如果点击的不是活动对象,需要转换坐标系
            if self.S.hit_obj != self.act_obj:
                edge_dir = self.act_mx.inverted_safe().to_3x3() @ hitmx.to_3x3() @ edge_dir
                closest_point_on_edge = self.act_mx.inverted_safe() @ hitmx @ closest_point_on_edge

            # 计算边方向与平均法线的点积
            dot = edge_dir.dot(self.data['avg_dir'])

            # 确保边方向与平均法线方向一致
            if dot < 0:
                edge_dir.negate()

            # 检查边方向是否与平均法线垂直(无效方向)
            if round(dot, 4) == 0:
                self.data['edge_dir'] = None
            else:
                # 设置有效的边方向
                self.data['edge_co'] = closest_point_on_edge
                self.data['edge_dir'] = edge_dir

                # 切换到EDGE模式并设置挤出量
                self.set_extrusion_direction(context, direction='EDGE')
                self.set_extrusion_amount(context)
                return

        else:
            # 没有点击到有效对象,清除边数据
            self.edge_coords = None
            self.data['edge_dir'] = None

        # 回退到之前的模式
        self.mode = self.prev_mode

        # 重新设置挤出方向和挤出量
        self.set_extrusion_direction(context, direction=self.mode)
        self.set_extrusion_amount(context)

    def reset_mesh(self, init_bm, return_bmesh=False):
        """
        重置网格到初始状态

        Args:
            init_bm: 初始的 BMesh 对象,包含原始网格数据
            return_bmesh: 是否返回新的 BMesh 对象

        Returns:
            BMesh: 如果 return_bmesh 为 True,返回新的 BMesh 对象
        """
        # 切换到对象模式以更新网格数据
        bpy.ops.object.mode_set(mode='OBJECT')
        # 将初始BMesh数据写回活动对象的网格
        init_bm.to_mesh(self.act_obj.data)
        # 切换回编辑模式
        bpy.ops.object.mode_set(mode='EDIT')
        # 如果需要返回BMesh对象
        if return_bmesh:
            # 从编辑网格创建新的BMesh对象
            bm = bmesh.from_edit_mesh(self.act_obj.data)
            # 更新法线
            bm.normal_update()
            # 确保切割面层存在
            ensure_face_cut_layer(bm, "hole_extrude")
            # 返回新的BMesh对象
            return bm


def _draw_hole_extrude_status(op: HoleExtrude):
    """
    HoleExtrude状态栏绘制函数

    Args:
        op: HoleExtrude 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        if not op.finalizing:
            if op.is_numeric_input:
                draw_status_item(row, key='LMB', text="Confirm")
                draw_status_item(row, key='MMB', text="Viewport")
                draw_status_item(row, key='RMB', text="Cancel")
            else:
                if op.is_edge_picking:
                    prop = "Valid" if op.edge_coords and op.data['edge_dir'] else "invalid" if op.edge_coords else "None"
                    draw_status_item(row, active=prop == "Valid", key='MOVE', text="Pick Direction", prop=prop, gap=3)
                else:
                    draw_status_item(row, key='LMB', text="Confirm")
                    draw_status_item(row, key='MMB', text="Viewport")
                    draw_status_item(row, key='RMB', text="Cancel")

                    if op.depth:
                        draw_status_item(row, key='R', text="Reset", gap=1)

                    draw_status_item(row, text="Extrusion Direction", gap=3)
                    draw_status_item(row, active=op.mode == 'AVERAGE', key='A', text="Average")
                    draw_status_item(row, active=op.mode == 'EDGE', key='E', text="Edge")
                    draw_status_item(row, active=op.mode == 'NORMAL', key='N', text="Normal")
                    draw_status_item(row, active=op.mode == 'CURSOR', key='C', text="Cursor")

                    if op.mode == 'CURSOR':
                        draw_status_item(row, active=op.cursor_axis == 'X', key='X', gap=1)
                        draw_status_item(row, active=op.cursor_axis == 'Y', key='Y')
                        draw_status_item(row, active=op.cursor_axis == 'Z', key='Z')
                        draw_status_item(row, text='Axis')
        else:
            draw_status_item(row, key='LMB', text="Finish")
            draw_status_item(row, key='MMB', text="Viewport")
            draw_status_item(row, key='RMB', text="Go Back")

            draw_status_item(row, active=op.is_use_self, key='S', text="Use Self", gap=3)
            draw_status_item(row, active=op.auto_cleanup, key='A', text="Auto Mesh Cleanup")
            if op.auto_cleanup:
                draw_status_item(row, active=op.remove_redundant, key='X', text="Remove Redundant Edges")

            draw_status_item(row, text="Push and Pull", gap=3)
            draw_status_item(row, active=op.is_shift, key='SHIFT', text="Invert")
            draw_status_item(row, active=op.is_ctrl, key='CTRL', text="x 100")
            draw_status_item(row, key='W', text="Both")
            draw_status_item(row, key='Q', text="Pull")
            draw_status_item(row, key='E', text="Push")
            draw_status_item(row, key='R', text="Reset", gap=1)

    return draw
