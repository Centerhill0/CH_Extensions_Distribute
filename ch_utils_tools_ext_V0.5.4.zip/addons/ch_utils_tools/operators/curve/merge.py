"""
曲线合并操作器模块

提供以下功能:
- CurveMergeToLast: 将选中点合并到最后选择的点
- CurveMergeToCenter: 将选中点合并到中心位置

操作流程:
1. 选择曲线上的点
2. 执行合并操作
3. 点被合并到目标位置

支持的合并类型:
- 同一样条内的点合并
- 跨样条的端点合并
"""

__all__ = ["CurveMergeToLast", "CurveMergeToCenter"]

from bpy.types import Operator, Context
from mathutils import Vector

from copy import copy

from ...utils import (
    CurveData,
    SplineData,
    get_curve_data,
    get_curve_selection_indices,
    create_spline_from_data,
    update_selection_history,
    get_average_position,
)


class CurveMergeToLast(Operator):
    """
    合并到最后选择的点

    功能:将选中的曲线点合并到最后选择的点位置
    - 支持同一样条内的连续点合并
    - 支持跨样条的端点合并

    要求:曲线编辑模式下有多个选中点
    """

    bl_idname = "ch.curve_merge_to_last"
    bl_label = "Merge to Last"
    bl_description = "Merge Spline Point(s) to Last Selected Point"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'EDIT_CURVE':
            return

        act_obj = context.active_object
        if not act_obj or act_obj.type != 'CURVE':
            return

        data = get_curve_data(act_obj.data)
        history = update_selection_history(data)
        selection = get_curve_selection_indices(data)

        return len(selection) >= 2 and (not history or history[-1] in selection)

    def execute(self, context: Context):
        act_obj = context.active_object
        act_curve = act_obj.data

        data = get_curve_data(act_curve)
        history = update_selection_history(data)
        selection = get_curve_selection_indices(data)

        if history and history[-1] in selection:
            last = history[-1]
        else:
            last = sorted(selection)[-1]

        selection.discard(last)

        same_spline_merge, other_spline_merge, couldnt_merge = self._verify_point_selection(data, selection, last)

        if same_spline_merge:
            new_points, spline_data = self._get_same_spline_merge_new_points(data, last, same_spline_merge)
            act_curve.splines.remove(act_curve.splines[last[0]])

        elif other_spline_merge:
            new_points, spline_data = self._get_other_spline_merge_new_points(data, last, other_spline_merge)

            other_spline = act_curve.splines[other_spline_merge[0][0]]
            last_point_spline = act_curve.splines[last[0]]

            act_curve.splines.remove(last_point_spline)
            act_curve.splines.remove(other_spline)

        if same_spline_merge or other_spline_merge:
            create_spline_from_data(act_curve, spline_data, custom_points=new_points)

            if couldnt_merge:
                self.report({'WARNING'}, "Illegal Selection: Some, but not all of the selected points could be merged")

            return {'FINISHED'}

        self.report({'WARNING'}, "Illegal Selection: Nothing could be merged! Make a selection that doesn't create a self-intersecting spline or cyclic loop")
        return {'CANCELLED'}

    def _verify_point_selection(self, data: CurveData, selection: set, last: tuple[int, int]) -> tuple[list, list, list]:
        """
        验证点选择是否有效

        Args:
            data: 曲线数据对象
            selection: 选中点索引集合
            last: 最后选择的点索引

        Returns:
            (同一样条合并列表, 跨样条合并列表, 无法合并列表)
        """
        same_spline_merge = []
        other_spline_merge = []
        couldnt_merge = []

        for sidx, pidx in selection:
            if sidx == last[0]:
                if last[1] > pidx:
                    if all((sidx, idx) in selection for idx in range(pidx + 1, last[1])):
                        same_spline_merge.append((sidx, pidx))
                    else:
                        couldnt_merge.append((sidx, pidx))
                else:
                    if all((sidx, idx) in selection for idx in range(last[1] + 1, pidx)):
                        same_spline_merge.append((sidx, pidx))
                    else:
                        couldnt_merge.append((sidx, pidx))
            else:
                if not data.splines[last[0]].is_cyclic and not data.splines[sidx].is_cyclic:
                    if last[1] == 0 or last[1] == len(data.splines[last[0]].points) - 1:
                        spline_data = data.splines[sidx]

                        if pidx == 0 or pidx == len(spline_data.points) - 1:
                            other_spline_merge.append((sidx, pidx))
                        else:
                            if all((sidx, idx) in selection for idx in range(pidx + 1, len(spline_data.points))):
                                other_spline_merge.append((sidx, pidx))
                            elif all((sidx, idx) in selection for idx in range(pidx)):
                                other_spline_merge.append((sidx, pidx))
                            else:
                                couldnt_merge.append((sidx, pidx))
                    else:
                        couldnt_merge.append((sidx, pidx))
                else:
                    couldnt_merge.append((sidx, pidx))

        return same_spline_merge, other_spline_merge, couldnt_merge

    def _get_same_spline_merge_new_points(self, data: CurveData, last: tuple[int, int], same_spline_merge: list) -> tuple[list, SplineData]:
        """
        获取同一样条合并后的新点列表

        Args:
            data: 曲线数据对象
            last: 最后选择的点索引
            same_spline_merge: 同一样条合并列表

        Returns:
            (新点列表, 样条数据)
        """
        sidx = last[0]
        spline_data = data.splines[sidx]

        new_points = []

        for point in spline_data.points:
            pidx = point.index

            if (sidx, pidx) not in same_spline_merge:
                new_points.append(point)

        return new_points, spline_data

    def _get_other_spline_merge_new_points(self, data: CurveData, last: tuple[int, int], other_spline_merge: list) -> tuple[list, SplineData]:
        """
        获取跨样条合并后的新点列表

        Args:
            data: 曲线数据对象
            last: 最后选择的点索引
            other_spline_merge: 跨样条合并列表

        Returns:
            (新点列表, 样条数据)
        """
        other_spline_merge.sort()

        sidx = other_spline_merge[0][0]
        other_spline_data = data.splines[sidx]

        merge_points = [point[1] for point in other_spline_merge if point[0] == sidx]

        if merge_points[0] == 0:
            trimmed_merge_points = []

            for point in other_spline_data.points:
                if point.index in merge_points:
                    trimmed_merge_points.append(point.index)
                else:
                    break
        else:
            trimmed_merge_points = []

            for point in reversed(other_spline_data.points):
                if point.index in merge_points:
                    trimmed_merge_points.append(point.index)
                else:
                    break

        spline_data = data.splines[last[0]]

        new_points = []

        if last[1] == 0:
            if trimmed_merge_points[0] == 0:
                for point in reversed(other_spline_data.points):
                    if point.index not in trimmed_merge_points:
                        new_points.append(point)
            else:
                for point in other_spline_data.points:
                    if point.index not in trimmed_merge_points:
                        new_points.append(point)

            new_points.extend(spline_data.points)

        else:
            new_points.extend(spline_data.points)

            if trimmed_merge_points[0] == 0:
                for point in other_spline_data.points:
                    if point.index not in trimmed_merge_points:
                        new_points.append(point)
            else:
                for point in reversed(other_spline_data.points):
                    if point.index not in trimmed_merge_points:
                        new_points.append(point)

        return new_points, spline_data


class CurveMergeToCenter(Operator):
    """
    合并到中心位置

    功能:将选中的曲线点合并到平均位置
    - 支持同一样条内的连续点合并
    - 支持跨两个样条的端点合并

    要求:曲线编辑模式下有多个选中点
    """

    bl_idname = "ch.curve_merge_to_center"
    bl_label = "Merge to Center"
    bl_description = "Merge Selected Points to Averaged Location, optionally across 2 Splines"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'EDIT_CURVE':
            return

        act_obj = context.active_object
        if not act_obj or act_obj.type != 'CURVE':
            return

        data = get_curve_data(act_obj.data)
        selection = get_curve_selection_indices(data)

        return len(selection) > 1

    def execute(self, context: Context):
        act_obj = context.active_object
        act_curve = act_obj.data

        data = get_curve_data(act_curve)
        selection = get_curve_selection_indices(data)

        separated = self._verify_point_selection(selection)

        if separated:
            if len(separated) > 1:
                new_points, spline_data, sidx1, sidx2 = self._get_other_spline_merge_new_points(data, separated)

                if new_points:
                    spline1 = act_curve.splines[sidx1]
                    spline2 = act_curve.splines[sidx2]

                    act_curve.splines.remove(spline1)
                    act_curve.splines.remove(spline2)

                    create_spline_from_data(act_curve, spline_data, custom_points=new_points)
                else:
                    self.report({'WARNING'}, "Illegal Selection: To Center Merge points across two splines, you need to have a continuous selection at either end of the two splines")
                    return {'CANCELLED'}
            else:
                new_points, spline_data = self._get_same_spline_merge_new_points(data, separated)

                act_curve.splines.remove(act_curve.splines[list(separated)[0]])

                create_spline_from_data(act_curve, spline_data, custom_points=new_points)

            return {'FINISHED'}

        self.report({'WARNING'}, "Illegal Selection: Nothing could be merged! Make a selection that doesn't create a self-intersecting spline or cyclic loop")
        return {'CANCELLED'}

    def _verify_point_selection(self, selection: set) -> dict:
        """
        验证点选择是否有效

        Args:
            selection: 选中点索引集合

        Returns:
            按样条分组的连续选择字典
        """
        sorted_selection = sorted(selection)

        separated = {}

        for sidx, pidx in sorted_selection:
            if sidx in separated:
                separated[sidx].append(pidx)
            else:
                separated[sidx] = [pidx]

        delete_splines = []

        for sidx, sel in separated.items():
            if not all(pidx == sel[idx] + 1 for idx, pidx in enumerate(sel[1:])):
                delete_splines.append(sidx)

        for sidx in delete_splines:
            del separated[sidx]

        return separated

    def _get_same_spline_merge_new_points(self, data: CurveData, separated: dict) -> tuple[list, SplineData]:
        """
        获取同一样条合并后的新点列表

        Args:
            data: 曲线数据对象
            separated: 按样条分组的连续选择字典

        Returns:
            (新点列表, 样条数据)
        """
        sidx = list(separated)[0]
        spline_data = data.splines[sidx]

        merge_co = get_average_position([spline_data.points[pidx].co.xyz for pidx in separated[sidx]])

        new_points = []
        first_merged = None

        for point in spline_data.points:
            if point.index in separated[sidx]:
                if not first_merged:
                    merged_point = copy(point)
                    merged_point.co = Vector((*merge_co, 1))
                    merged_point.index = -1
                    new_points.append(merged_point)
                    first_merged = True
            else:
                new_points.append(point)

        return new_points, spline_data

    def _get_other_spline_merge_new_points(self, data: CurveData, separated: dict) -> tuple[list, SplineData | None, int | None, int | None]:
        """
        获取跨样条合并后的新点列表

        Args:
            data: 曲线数据对象
            separated: 按样条分组的连续选择字典

        Returns:
            (新点列表, 样条数据, 样条索引1, 样条索引2)
        """
        new_points = []
        sidx1 = None
        sidx2 = None
        spline_data1 = None

        if len(separated) != 2:
            return new_points, spline_data1, sidx1, sidx2

        sidx1, sidx2 = list(separated)

        sel1 = separated[sidx1]
        spline_data1 = data.splines[sidx1]

        sel2 = separated[sidx2]
        spline_data2 = data.splines[sidx2]

        if sel1[0] != 0 and sel1[-1] != len(spline_data1.points) - 1:
            return [], spline_data1, sidx1, sidx2

        if sel2[0] != 0 and sel2[-1] != len(spline_data2.points) - 1:
            return [], spline_data1, sidx1, sidx2

        merge_co = get_average_position([spline_data1.points[pidx].co.xyz for pidx in sel1] + [spline_data2.points[pidx].co.xyz for pidx in sel2])

        if sel1[0] == 0:
            if sel2[0] == 0:
                second_spline_points = reversed(spline_data2.points)
            else:
                second_spline_points = spline_data2.points

            first_merged = None

            for point in second_spline_points:
                if point.index in sel2:
                    if not first_merged:
                        merged_point = copy(point)
                        merged_point.co = Vector((*merge_co, 1))
                        merged_point.index = -1
                        new_points.append(merged_point)
                        first_merged = True
                else:
                    new_points.append(point)

            for point in spline_data1.points:
                if point.index not in sel1:
                    new_points.append(point)

        else:
            first_merged = None

            for point in spline_data1.points:
                if point.index in sel1:
                    if not first_merged:
                        merged_point = copy(point)
                        merged_point.co = Vector((*merge_co, 1))
                        merged_point.index = -1
                        new_points.append(merged_point)
                        first_merged = True
                else:
                    new_points.append(point)

            if sel2[0] == 0:
                second_spline_points = spline_data2.points
            else:
                second_spline_points = reversed(spline_data2.points)

            for point in second_spline_points:
                if point.index not in sel2:
                    new_points.append(point)

        return new_points, spline_data1, sidx1, sidx2
