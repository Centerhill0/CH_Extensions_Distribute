"""
曲线切割操作器模块

提供以下功能:
- CurveKnife: 在曲线上切割新点并可选分割样条

操作流程:
1. 在曲线编辑模式下执行操作
2. 点击设置切割起点
3. 移动鼠标调整切割线
4. 按住Alt切换分割模式
5. 点击完成切割

支持的曲线类型:
- POLY: 多边形曲线
- NURBS: NURBS曲线

快捷键:
- LMB: 设置起点/完成切割
- Alt: 切换分割模式
- RMB/ESC: 取消操作
"""

__all__ = ["CurveKnife"]

from bpy.types import Operator, Context, Event
from bpy.props import BoolProperty
from mathutils import Vector
from mathutils.geometry import intersect_line_line_2d, intersect_line_plane

from copy import copy

from ...constants import red, violet, black, green
from ...utils import (
    CurveData,
    SplinePoint,
    get_curve_data,
    create_spline_from_data,
    ignore_events,
    force_ui_update,
    get_location_2d,
    get_view_origin_and_dir,
    is_on_screen,
    rotate_list,
    draw_status_item,
    draw_point,
    draw_line,
    draw_points,
)
from ...modal_base import ModalOperatorMixin


class CurveKnife(Operator, ModalOperatorMixin):
    """
    曲线切割

    功能:在曲线上切割新点并可选分割样条
    - 支持POLY和NURBS曲线类型
    - 支持分割样条

    要求:曲线编辑模式下有POLY或NURBS样条
    """

    bl_idname = "ch.curve_knife"
    bl_label = "Curve Knife"
    bl_description = "Cut new Curve Points and optionally Split Splines"
    bl_options = {'REGISTER', 'UNDO'}

    is_split_cut: BoolProperty(name="Split Splines at Knife Intersections", default=False)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'EDIT_CURVE':
            return

        act_obj = context.active_object
        if not act_obj or act_obj.type != 'CURVE':
            return

        return any(spline.type in ['POLY', 'NURBS'] for spline in act_obj.data.splines)

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_curve = self.act_obj.data
        self.mx = self.act_obj.matrix_world

        self.data: CurveData = get_curve_data(self.act_curve)

        self._populate_2d_point_coords(context)

        self.segments = self._get_knifeable_segments(context)

        self.cuts = []
        self.is_split_cut = False
        self.is_alt = False
        self.coords = []

        self.init_mouse_position(event, hud=True)
        context.window.cursor_set('KNIFE')

        self.start_loc = None
        self.end_loc = None

        self.init_status(context, func=draw_curve_knife_status(self))
        self.init_modal_handlers(context, hud=True)

        force_ui_update(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        self.is_alt = event.alt
        self.is_split_cut = bool(self.start_loc and self.is_alt)

        if event.type == 'MOUSEMOVE':
            self.init_mouse_position(event)

            if self.start_loc:
                self.end_loc = self.mouse_region_pos if self.mouse_region_pos != self.start_loc else None

        if not self.start_loc and event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.start_loc = self.mouse_region_pos

            force_ui_update(context)

        if self.start_loc and self.end_loc and self.segments:
            self.cuts = self._get_cuts_2d()

            force_ui_update(context)

        if self.start_loc and self.end_loc and event.type in ['LEFTMOUSE', 'SPACE'] and event.value == 'PRESS':
            self.finish(context)

            if self.cuts:
                self._get_cuts_3d(context)
                self._rebuild_cut_splines()

            return {'FINISHED'}

        elif event.type in ['RIGHTMOUSE', 'ESC'] and event.value == 'PRESS':
            self.finish(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def draw_HUD(self, context: Context):
        """绘制屏幕空间预览"""
        if context.area != self.area:
            return

        if self.start_loc:
            draw_point(self.start_loc.resized(3), size=4, alpha=0.5)

        if self.end_loc:
            draw_point(self.end_loc.resized(3), size=8, color=black, alpha=0.5)

        if self.start_loc and self.end_loc:
            draw_line([self.start_loc.resized(3), self.end_loc.resized(3)], color=violet, alpha=0.5)

        if self.coords:
            draw_points(self.coords, color=red if self.is_split_cut else green)

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 光标复位)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.window.cursor_set('DEFAULT')

    def _populate_2d_point_coords(self, context: Context):
        """为所有点计算2D屏幕坐标(按样条/点索引平行的二维列表)"""
        self.point_2d = [[get_location_2d(context, self.mx @ point.co.xyz) for point in spline.points] for spline in self.data.splines]

    def _get_knifeable_segments(self, context: Context) -> list:
        """获取可切割的线段列表"""

        def get_next_point(idx: int, is_cyclic: bool, points: list) -> tuple[int, object] | None:
            """返回(下一索引, 下一点), 无下一元素时返回None"""
            if is_cyclic:
                next_idx = (idx + 1) % len(points)
                return next_idx, points[next_idx]
            if idx < len(points) - 1:
                return idx + 1, points[idx + 1]
            return None

        segments = []

        for sidx, spline_data in enumerate(self.data.splines):
            is_cyclic = spline_data.is_cyclic
            points = spline_data.points
            point_2d = self.point_2d[sidx]

            segments.append([])

            for idx, point in enumerate(points):
                next_point = get_next_point(idx, is_cyclic, points)

                if next_point:
                    next_idx, next_point = next_point

                    if not is_on_screen(context, point_2d[idx]) and not is_on_screen(context, point_2d[next_idx]):
                        continue

                    segments[-1].append((point.index, next_idx))

        return segments

    def _get_cuts_2d(self) -> dict:
        """计算2D切割交点"""
        self.coords.clear()
        cuts = {'splines': {}, 'count': 0}

        cut_line = (self.start_loc, self.end_loc)

        for sidx, segment in enumerate(self.segments):
            for idx, next_idx in segment:
                segment_line = (self.point_2d[sidx][idx], self.point_2d[sidx][next_idx])

                i = intersect_line_line_2d(*segment_line, *cut_line)

                if i:
                    self.coords.append(i.resized(3))

                    if sidx not in cuts['splines']:
                        cuts['splines'][sidx] = []

                    cuts['splines'][sidx].append({'segment': (idx, next_idx), 'intersect2d': i, 'intersect': None})

                    cuts['count'] += 1

        return cuts

    def _get_cuts_3d(self, context: Context):
        """计算3D切割交点"""
        is_ortho = context.space_data.region_3d.view_perspective == 'ORTHO'

        if is_ortho:
            cut_origin, view_dir = get_view_origin_and_dir(context, self.start_loc)
            cut_origin_end, _ = get_view_origin_and_dir(context, self.end_loc)

            cut_normal = (cut_origin_end - cut_origin).normalized().cross(view_dir.normalized())
        else:
            cut_origin, view_dir_start = get_view_origin_and_dir(context, self.start_loc)
            _, view_dir_end = get_view_origin_and_dir(context, self.end_loc)

            cut_normal = view_dir_start.normalized().cross(view_dir_end.normalized())

        for sidx, cuts in self.cuts['splines'].items():
            for cut in cuts:
                idx, next_idx = cut['segment']

                point = self.data.splines[sidx].points[idx]
                next_point = self.data.splines[sidx].points[next_idx]

                co = self.mx @ point.co.xyz
                next_co = self.mx @ next_point.co.xyz

                i = intersect_line_plane(co, next_co, cut_origin, cut_normal)

                if i:
                    cut['intersect'] = self.mx.inverted_safe() @ i

    def _rebuild_cut_splines(self):
        """重建切割后的样条"""
        new_splines = []
        remove_splines = []

        for sidx, spline_data in enumerate(self.data.splines):
            if sidx in self.cuts['splines']:
                spline = self.act_curve.splines[sidx]

                remove_splines.append(spline)

                cut_data = self.cuts['splines'][sidx]
                new_data = copy(spline_data)
                new_data.points = []

                idx = 0

                for point in spline_data.points:
                    dup = copy(point)
                    dup.index = idx
                    dup.select = False
                    dup.is_split = False
                    new_data.points.append(dup)

                    idx += 1

                    for cut in cut_data:
                        if cut['segment'][0] == point.index:
                            idx += 1

                            next_point = spline_data.points[cut['segment'][1]]
                            is_after = True

                            if spline_data.is_cyclic and next_point.index == 0:
                                first_distance = (next_point.co.xyz - cut['intersect']).length
                                last_distance = (point.co.xyz - cut['intersect']).length

                                is_after = last_distance < first_distance

                            radius = (point.radius + next_point.radius) / 2
                            tilt = (point.tilt + next_point.tilt) / 2

                            c_point = SplinePoint(index=idx if is_after else -1, co=Vector((*cut['intersect'], 1.0)), radius=radius, tilt=tilt, hide=False, select=True, is_split=self.is_split_cut)

                            if is_after:
                                new_data.points.append(c_point)

                                if self.is_split_cut:
                                    new_data.points.append(c_point)
                            else:
                                new_data.points.insert(0, c_point)

                                if self.is_split_cut:
                                    new_data.points.insert(0, c_point)

                new_splines.append(new_data)

        if self.is_split_cut:
            split_splines = []

            for spline_data in new_splines:
                new_spline = copy(spline_data)
                new_spline.is_cyclic = False
                new_spline.points = []

                split_splines.append(new_spline)

                points = spline_data.points.copy()

                split_indices = [idx for idx, point in enumerate(points) if point.is_split]

                if spline_data.is_cyclic:
                    points = rotate_list(points, amount=split_indices[1])

                pidx = 0

                for idx, point in enumerate(points):
                    dup = copy(point)
                    dup.select = False
                    dup.index = pidx

                    new_spline.points.append(dup)

                    if pidx > 0:
                        if point.is_split and not idx == len(points) - 1:
                            new_spline = copy(spline_data)
                            new_spline.is_cyclic = False
                            new_spline.points = []

                            split_splines.append(new_spline)

                            pidx = 0
                            continue

                    pidx += 1

            new_splines = split_splines

        for spline in remove_splines:
            self.act_curve.splines.remove(spline)

        active = None

        for spline_data in new_splines:
            spline = create_spline_from_data(self.act_curve, spline_data)

            if spline_data.active:
                active = spline

        if active:
            self.act_curve.splines.active = active


def draw_curve_knife_status(op: CurveKnife):
    """
    返回 CurveKnife 操作的状态栏绘制回调函数

    Args:
        op: CurveKnife 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Start" if not op.start_loc else "Finish")
        draw_status_item(row, key='RMB', text="Cancel")

        if op.start_loc:
            draw_status_item(row, key='MOVE', text="Adjust", gap=1)
            draw_status_item(row, active=op.is_split_cut, key='ALT', text="Split")

    return draw
