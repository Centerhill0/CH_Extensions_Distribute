"""
曲线倒角操作器模块

提供以下功能:
- CurvePointsBlend: 将选中的曲线点进行倒角处理

操作流程:
1. 选择要倒角的曲线点(连续选择,非端点)
2. 拖动鼠标设置倒角宽度
3. 调整参数优化结果
4. 确认完成

支持的曲线类型:
- POLY: 多边形曲线
- NURBS: NURBS曲线

快捷键:
- 鼠标左右移动: 调整倒角宽度(默认模式)
- T: 切换张力调整模式,上下移动调整张力值
- M: 切换合并/倒角模式
- A: 切换自动张力
- 鼠标滚轮: 调整分段数
- W: 切换线框显示(当曲线有倒角时)
- Shift: 精细调整
- Ctrl: 粗糙调整
- 左键/空格: 确认操作
- 右键/ESC: 取消操作
"""

__all__ = ["CurvePointsBlend"]

from math import degrees

import numpy as np

from bpy.props import FloatProperty, IntProperty, BoolProperty, EnumProperty
from bpy.types import Operator, Context, Event
from mathutils import Vector
from mathutils.geometry import interpolate_bezier, intersect_line_line

from ...utils import (
    CurveData,
    SplinePoint,
    SplineData,
    get_curve_data,
    has_active_spline,
    has_active_selection,
    is_active_end_selected,
    is_active_selection_continuous,
    get_average_position,
    lerp,
    format_adaptive_precision,
    get_zoom_factor,
    ignore_events,
    navigation_passthrough,
    scroll_up,
    scroll_down,
    draw_status_item,
)
from ...modal_base import ModalOperatorMixin


class CurvePointsBlend(Operator, ModalOperatorMixin):
    """
    曲线倒角

    功能:将选中的曲线点进行倒角处理
    - 支持POLY和NURBS曲线类型
    - 支持自动张力计算以近似圆弧
    - 支持合并到单点

    要求:曲线编辑模式下有连续选中的点(非端点)
    """

    bl_idname = "ch.curve_blend"
    bl_label = "Curve Points Blend"
    bl_description = "Blend the curve points"
    bl_options = {'REGISTER', 'UNDO'}

    def update_tension(self, context: Context):
        """当手动调整张力时,禁用自动张力"""
        if self.auto_tension:
            self.auto_tension = False

    segments: IntProperty(name="Segments", default=6, min=1)  # type: ignore
    tension: FloatProperty(name="Tension", default=0.7, min=0.01, update=update_tension)  # type: ignore
    auto_tension: BoolProperty(name="Auto Tension", description="Use automatically calculated tension to approximate a Circular Arc", default=True)  # type: ignore
    width: FloatProperty(name="Width", description="Distance by withthe two outer Points are moved", default=0)  # type: ignore
    mode: EnumProperty(  # type: ignore
        name="Mode",
        items=[
            ('BLEND', "Blend", "Blend the curve with bezier interpolation"),
            ('MERGE', "Merge", "Merge selected points to a single point"),
        ],
        default='BLEND',
    )
    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    allow_modal_width: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    allow_modal_tension: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'EDIT_CURVE':
            act_obj = context.active_object
            if act_obj.type == 'CURVE':
                curve = act_obj.data
                return curve.splines.active and curve.splines.active.type in {'POLY', 'NURBS'}

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_curve = self.act_obj.data
        self.mx = self.act_obj.matrix_world

        self.data: CurveData = get_curve_data(self.act_curve)

        spline = has_active_spline(self.data)
        if not spline:
            self.report({'WARNING'}, "Invalid Curve/Spline, Ensure there is an Active Spline")
            return {'CANCELLED'}

        if spline.spline_type not in ['POLY', 'NURBS'] or len(spline.points) < 3:
            self.report({'WARNING'}, "Illegal Selection, Ensure the Active Spline is of type POLY or NURBS with at least 3 Points")
            return {'CANCELLED'}

        selection = has_active_selection(self.data)
        if not selection:
            self.report({'WARNING'}, "Illegal Selection, Select at least one Point in the Active Spline")
            return {'CANCELLED'}

        if is_active_end_selected(self.data):
            self.report({'WARNING'}, "Illegal Selection, Avoid selecting the Spline Ends")
            return {'CANCELLED'}

        if not is_active_selection_continuous(self.data):
            self.report({'WARNING'}, "Illegal Selection, Make a continuous Selection of Points, without unselected gaps")
            return {'CANCELLED'}

        self.bezier_data = self._get_bezier_data(spline.points, selection)

        if len(selection) > 2:
            self._create_bezier_coords(0, len(selection) - 2)
            new_spline_data = self._create_new_spline_data()
            self._create_new_active_spline(new_spline_data)

        self.width = 0
        self.mode = 'BLEND'
        self.allow_modal_width = True
        self.allow_modal_tension = False

        if self.act_curve.bevel_depth or self.act_curve.extrude:
            self.act_obj.show_wire = True

        self.segments = 7 if len(selection) == 1 else len(selection) - 1
        self.factor = get_zoom_factor(context, self.mx @ self.data.active_selection_mid_point, scale=5)

        self.init_mouse_position(event)

        self.init_status(context, func=draw_curve_blend_status(self))
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        events = ['A', 'M', 'W', 'T']
        if any([self.allow_modal_width, self.allow_modal_tension]):
            events.append('MOUSEMOVE')

        if event.type in events or scroll_up(event) or scroll_down(event):
            if event.type == 'MOUSEMOVE':
                wrapped = self.wrap_mouse_position(context, event)
                if self.pass_through:
                    self.pass_through = False
                elif not wrapped and (self.allow_modal_width or self.allow_modal_tension):
                    if getattr(self, '_first_mouse_move', True):
                        self._first_mouse_move = False
                        self.last_mouse_x = event.mouse_x
                        self.last_mouse_y = event.mouse_y
                    else:
                        if self.allow_modal_width:
                            divisor = 100 if event.shift else 1 if event.ctrl else 10
                            delta_x = event.mouse_x - self.last_mouse_x
                            delta_width = delta_x / divisor * self.factor
                            self.width += delta_width
                            self.last_mouse_x = event.mouse_x

                        if self.allow_modal_tension:
                            divisor = 1000 if event.shift else 10 if event.ctrl else 100
                            delta_y = event.mouse_y - self.last_mouse_y
                            delta_tension = delta_y / divisor
                            self.tension += delta_tension
                            self.last_mouse_y = event.mouse_y

            elif scroll_up(event) or scroll_down(event):
                self.segments += 1 if scroll_up(event) else -1
            elif event.value == 'PRESS':
                self._handle_key_press(context, event)

            self._update_spline()
            self.update_header_text(context)

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if self.allow_modal_tension:
                self.allow_modal_tension = False
                self.allow_modal_width = True
            else:
                self.finish(context)
                return {'FINISHED'}

        elif event.type in {'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context)

            for spline_data in self.data.splines:
                if spline_data.active:
                    self._create_new_active_spline(spline_data)
                    break

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.type == 'T':
            self.allow_modal_tension = not self.allow_modal_tension
            if self.allow_modal_tension:
                self._first_mouse_move = True
                self.allow_modal_width = False
                if self.auto_tension:
                    self.auto_tension = False
                    self.tension = self.bezier_data['circular_approximate_tension']
            else:
                self.allow_modal_width = True
            return

        if event.type == 'W' and (self.act_curve.bevel_depth or self.act_curve.extrude):
            self.act_obj.show_wire = not self.act_obj.show_wire
            return

        if event.type == 'A':
            self.auto_tension = not self.auto_tension
        elif event.type == 'M':
            self.mode = 'MERGE' if self.mode == 'BLEND' else 'BLEND'

    def finish(self, context: Context):
        """
        清理模态操作资源

        恢复光标, 状态栏,并在需要时隐藏线框显示.

        Args:
            context: Blender上下文
        """
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        if (self.act_curve.bevel_depth or self.act_curve.extrude) and self.act_obj.show_wire:
            self.act_obj.show_wire = False

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        width_text = format_adaptive_precision(self.width, 2)
        tension_text = format_adaptive_precision(self.tension, 2)
        text = f"Segments: {self.segments} | Width: {width_text} | Tension: {tension_text}"
        context.area.header_text_set(text)

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; 倒角所需的样条解析结果(bezier_data/act_curve/data)
        # 完全由 invoke 的选区校验与样条解析派生, 无交互状态时无法重建, 干净取消而非崩溃.
        # 不可复入 invoke 重建: invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # F9 重做走持久实例, bezier_data 已存在, 不受此守卫影响
        if not hasattr(self, "bezier_data"):
            self.report({'WARNING'}, "Curve Points Blend requires interactive viewport input and cannot be executed directly")
            return {'CANCELLED'}

        self._create_bezier_coords(self.width, self.segments)
        new_spline_data = self._create_new_spline_data()
        self._create_new_active_spline(new_spline_data)

        return {'FINISHED'}

    def _get_bezier_data(self, points: list[SplinePoint], selected_points: list[SplinePoint]) -> dict:
        """
        计算贝塞尔曲线倒角所需的数据

        根据选中的点计算倒角方向, 角度, 手柄交点等参数.

        Args:
            points: 样条上所有点的数据列表
            selected_points: 选中的点数据列表

        Returns:
            包含倒角参数的字典:
            - is_single: 是否只选中单个点
            - first_co/last_co: 首尾选中点坐标
            - previous_co/next_co: 相邻点坐标
            - first_move_dir/last_move_dir: 移动方向
            - angle: 倒角角度
            - circular_approximate_tension: 自动计算的张力值
            - avg_handle_intersect_co: 手柄交点平均位置
            - first_handle_intersect_co/last_handle_intersect_co: 手柄交点
            - WARNING: 警告信息(如有)
        """
        is_single = len(selected_points) == 1
        first_idx = selected_points[0].index
        last_idx = selected_points[-1].index

        first_point = points[first_idx]
        last_point = points[last_idx]
        previous_point = points[first_idx - 1]
        next_point = points[last_idx + 1]

        first_co = first_point.co.xyz
        last_co = last_point.co.xyz
        previous_co = previous_point.co.xyz
        next_co = next_point.co.xyz

        first_move_dir = (previous_co - first_co).normalized()
        last_move_dir = (next_co - last_co).normalized()
        angle = 180 - degrees(first_move_dir.angle(last_move_dir))

        bdata = {
            'WARNING': None,
            'is_single': is_single,
            'first_co': first_co,
            'last_co': last_co,
            'previous_co': previous_co,
            'next_co': next_co,
            'previous_radius': previous_point.radius,
            'next_radius': next_point.radius,
            'previous_tilt': previous_point.tilt,
            'next_tilt': next_point.tilt,
            'first_move_dir': first_move_dir,
            'last_move_dir': last_move_dir,
            'angle': angle,
            'circular_approximate_tension': self._calculate_tension(angle, first_co, last_co),
        }

        if is_single:
            bdata['avg_handle_intersect_co'] = first_co
            bdata['first_handle_intersect_co'] = first_co
            bdata['last_handle_intersect_co'] = first_co
            return bdata

        handle_intersects = intersect_line_line(previous_co, first_co, next_co, last_co)

        if handle_intersects and angle != 180:
            bdata['avg_handle_intersect_co'] = get_average_position(handle_intersects)
            bdata['first_handle_intersect_co'] = handle_intersects[0]
            bdata['last_handle_intersect_co'] = handle_intersects[1]
        else:
            bdata['avg_handle_intersect_co'] = get_average_position([first_co, last_co])
            bdata['first_handle_intersect_co'] = first_co - first_move_dir
            bdata['last_handle_intersect_co'] = last_co - last_move_dir
            bdata['WARNING'] = '180° Blend!'

        return bdata

    def _calculate_tension(self, angle: float, first_co, last_co) -> float:
        """
        根据角度计算贝塞尔曲线张力值

        使用预计算的多项式拟合曲线,根据倒角角度计算
        近似圆弧所需的张力系数.

        Args:
            angle: 倒角角度(度)
            first_co: 首点坐标
            last_co: 尾点坐标

        Returns:
            张力系数值
        """
        tension_angle = [5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 175]
        tension_values = [0.665, 0.661, 0.658, 0.645, 0.636, 0.625, 0.605, 0.59, 0.57, 0.55, 0.52, 0.482, 0.445, 0.395, 0.34, 0.273, 0.196, 0.1065, 0.0557]
        tension_poly = np.poly1d(np.polyfit(tension_angle, tension_values, deg=4))
        if angle == 180:
            return 0.7 * (first_co - last_co).length

        return float(tension_poly(angle))

    def _create_bezier_coords(self, amount: float, segments: int):
        """
        创建贝塞尔曲线坐标并计算插值因子

        根据倒角参数生成贝塞尔曲线点坐标,并计算半径和倾斜的插值因子.

        Args:
            amount: 倒角距离,控制首尾点移动的距离
            segments: 贝塞尔曲线分段数(实际段数)
        """
        bdata = self.bezier_data

        new_first_co = bdata['first_co'] + bdata['first_move_dir'] * amount
        new_last_co = bdata['last_co'] + bdata['last_move_dir'] * amount

        if bdata['is_single'] and amount < 0:
            new_first_co = bdata['first_co']
            new_last_co = bdata['last_co']
        else:
            first_handle_dir = bdata['first_handle_intersect_co'] - new_first_co
            first_dot = first_handle_dir.dot(bdata['first_move_dir'])

            if first_dot >= 0:
                new_first_co = bdata['first_handle_intersect_co']

            last_handle_dir = bdata['last_handle_intersect_co'] - new_last_co
            last_dot = last_handle_dir.dot(bdata['last_move_dir'])

            if last_dot >= 0:
                new_last_co = bdata['last_handle_intersect_co']

        if self.mode == 'MERGE':
            bdata['bezier_coords'] = [bdata['avg_handle_intersect_co']]
        else:
            first_dir = bdata['first_handle_intersect_co'] - new_first_co
            last_dir = bdata['last_handle_intersect_co'] - new_last_co
            tension = bdata['circular_approximate_tension'] if self.auto_tension else self.tension
            resolution = segments + 1

            bdata['bezier_coords'] = interpolate_bezier(new_first_co, new_first_co + first_dir * tension, new_last_co + last_dir * tension, new_last_co, resolution)

        bdata['interpolation_factors'] = self._calculate_interpolation_factors(bdata)

    def _calculate_interpolation_factors(self, bdata: dict) -> list[float]:
        """
        计算贝塞尔曲线上各点的插值因子

        根据各点之间的距离计算累积插值因子,用于半径和倾斜的线性插值.

        Args:
            bdata: 贝塞尔数据字典

        Returns:
            插值因子列表(不包含首尾点)
        """
        coords = [bdata['previous_co']] + bdata['bezier_coords'] + [bdata['next_co']]
        distances = [0.0] + [(coords[i] - coords[i - 1]).length for i in range(1, len(coords))]
        total_distance = sum(distances)

        cumulative = 0.0
        factors = []
        for dist in distances:
            cumulative += dist
            factors.append(cumulative / total_distance)

        return factors[1:-1]

    def _create_new_spline_data(self) -> SplineData | None:
        """
        创建新样条数据
        将贝塞尔曲线点插入到活动样条中,替换选中的点.

        Returns:
            新SplineData对象,如果没有活动样条则返回None
        """
        bdata = self.bezier_data

        for spline in self.data.splines:
            if not spline.active:
                continue

            new_spline_data = SplineData(
                spline_type=spline.spline_type,
                active=True,
                smooth=spline.smooth,
                is_cyclic=spline.is_cyclic,
                endpoint=spline.endpoint,
                order=spline.order,
                resolution=spline.resolution,
                points=[],
            )

            point_idx = 0
            has_inserted_bezier = False

            for point in spline.points:
                if point.select:
                    if has_inserted_bezier:
                        continue

                    for idx, co in enumerate(bdata['bezier_coords']):
                        point_data = SplinePoint(
                            index=point_idx,
                            co=Vector((*co, 1)),
                            radius=lerp(bdata['previous_radius'], bdata['next_radius'], bdata['interpolation_factors'][idx]),
                            tilt=lerp(bdata['previous_tilt'], bdata['next_tilt'], bdata['interpolation_factors'][idx]),
                            select=True,
                            hide=False,
                        )
                        new_spline_data.points.append(point_data)
                        point_idx += 1

                    has_inserted_bezier = True
                else:
                    point_data = SplinePoint(index=point_idx, co=point.co, radius=point.radius, tilt=point.tilt, select=False, hide=point.hide)
                    new_spline_data.points.append(point_data)
                    point_idx += 1

            return new_spline_data

        return None

    def _create_new_active_spline(self, data: SplineData):
        """
        创建新的活动样条

        删除当前活动样条,并根据SplineData创建新样条.

        Args:
            data: 样条数据,包含类型, 属性和点数据
        """
        active_spline = self.act_curve.splines.active
        if active_spline:
            self.act_curve.splines.remove(active_spline)

        new_spline = self.act_curve.splines.new(data.spline_type)
        self.act_curve.splines.active = new_spline

        new_spline.points.add(len(data.points) - 1)

        for point, point_data in zip(new_spline.points, data.points):
            point.co = point_data.co
            point.radius = point_data.radius
            point.tilt = point_data.tilt
            point.select = point_data.select
            point.hide = point_data.hide

        new_spline.use_cyclic_u = data.is_cyclic
        new_spline.use_smooth = data.smooth

        if data.spline_type == 'NURBS':
            new_spline.use_endpoint_u = data.endpoint
            new_spline.order_u = data.order
            new_spline.resolution_u = data.resolution

    def _update_spline(self):
        """更新样条曲线"""
        self._create_bezier_coords(self.width, self.segments)
        new_spline_data = self._create_new_spline_data()
        self._create_new_active_spline(new_spline_data)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "mode")
        if self.mode == 'BLEND':
            layout.prop(self, "width")
            layout.prop(self, "segments")

            if self.segments > 1:
                row = layout.row(align=True, heading="Auto Tension")
                row.prop(self, "auto_tension", text="")
                sub_row = row.row(align=True)
                sub_row.prop(self, "tension", text="")
                sub_row.active = not self.auto_tension


def draw_curve_blend_status(op: CurvePointsBlend):
    """
    返回 CurvePointsBlend 操作的状态栏绘制回调函数

    Args:
        op: CurvePointsBlend 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport")
        draw_status_item(row, key='RMB', text="Cancel")

        is_merge = op.mode == 'MERGE'
        draw_status_item(row, active=is_merge, key='M', text=f"{'Merge' if is_merge else 'Blend'}", gap=1)

        if not is_merge:
            draw_status_item(row, active=not op.allow_modal_tension, key='MOVE', text="Width", gap=1)
            draw_status_item(row, key='MMB_SCROLL', text="Segments")

            if op.segments > 1:
                draw_status_item(row, active=op.allow_modal_tension, key=['T', 'MOVE'], text="Tension")
                draw_status_item(row, active=op.auto_tension, key='A', text="Auto")

            if op.act_curve.bevel_depth or op.act_curve.extrude:
                draw_status_item(row, active=op.act_obj.show_wire, key='W', text="Wireframe")

    return draw
