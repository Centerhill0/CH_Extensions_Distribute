"""
曲线间隙重排操作器模块

提供以下功能:
- CurveGapShuffle: 重排曲线的间隙位置

操作流程:
1. 选择曲线样条
2. 滚动鼠标滚轮重排间隙位置
3. 确认完成

支持的曲线类型:
- POLY: 多边形曲线
- NURBS: NURBS曲线

快捷键:
- 鼠标滚轮: 重排间隙位置
- Q: 切换仅重排异常段
- C: 切换曲线循环
- 左键/空格: 确认操作
- 右键/ESC: 取消操作
"""

__all__ = ["CurveGapShuffle"]

from bpy.types import Operator, Context, Event

from ...constants import orange, black, white, yellow, red, normal
from ...utils import (
    CurveData,
    get_curve_data,
    create_spline_from_data,
    rotate_list,
    step_list,
    find_outliers,
    ignore_events,
    navigation_passthrough,
    scroll_up,
    scroll_down,
    draw_status_item,
    draw_line,
    draw_points,
    draw_lines,
)
from ...modal_base import ModalOperatorMixin


class CurveGapShuffle(Operator, ModalOperatorMixin):
    """
    曲线间隙重排

    功能:重排曲线的间隙位置
    - 支持POLY和NURBS曲线类型
    - 自动检测异常间隙段
    - 支持仅重排异常段
    - 循环状态遵循曲线初始状态, 可按C切换

    要求:曲线编辑模式下有活动样条
    """

    bl_idname = "ch.curve_gap_shuffle"
    bl_label = "Gap Shuffle"
    bl_description = "Shuffle the gap in the active spline"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'EDIT_CURVE':
            return

        act_obj = context.active_object
        if act_obj.type == 'CURVE':
            act_spline = act_obj.data.splines.active
            if act_spline:
                return len(act_spline.points) > 2

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_curve = self.act_obj.data
        self.mx = self.act_obj.matrix_world

        self.data: CurveData = get_curve_data(self.act_curve)
        self.act_spline = self.act_curve.splines.active

        for point in self.act_spline.points:
            point.hide = True

        # 不强制样条闭合: 结果沿用曲线初始的循环状态, 需要闭合可按 C 切换
        self.is_initially_cyclic = self.act_spline.use_cyclic_u

        self.outliers = []
        self.coords = []
        self.orig_gap_coords = []
        self.outlier_coords = []

        self.step = 1
        self.is_shuffle_outliers = True

        self.new_points = self._get_new_points(gap=None)

        self.init_status(context, func=draw_gap_shuffle_status(self))
        self.init_modal_handlers(context, view3d=True)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        try:
            return self._modal_impl(context, event)
        except Exception as e:
            self._abort_modal(context)
            self.report({'WARNING'}, f"Gap Shuffle error: {str(e)}")
            return {'CANCELLED'}

    def _modal_impl(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        events = ['MOUSEMOVE', 'Q', 'C']

        if event.type in events or scroll_up(event) or scroll_down(event):
            if scroll_up(event) or scroll_down(event):
                if len(self.outliers) > 1 and self.is_shuffle_outliers:
                    self.step = step_list(self.step - 1, self.outliers, step=1 if scroll_up(event) else -1, loop=True) + 1
                else:
                    if scroll_up(event):
                        self.step += 1
                        if self.step > len(self.new_points) - 1:
                            self.step = 1
                    else:
                        self.step -= 1
                        if self.step < 1:
                            self.step = len(self.new_points) - 1

                self.new_points = self._get_new_points(gap=self.step)

            elif self.outliers and event.type == 'Q' and event.value == 'PRESS':
                self.is_shuffle_outliers = not self.is_shuffle_outliers

                if self.is_shuffle_outliers:
                    opposite_outlier_idx = int(len(self.outliers) / 2)
                    self.step = self.outliers[opposite_outlier_idx] + 1

                self.new_points = self._get_new_points(gap=self.step)
                self.act_spline.points[0].hide = True

            elif event.type == 'C' and event.value == 'PRESS':
                self.act_spline.use_cyclic_u = not self.act_spline.use_cyclic_u
                self.act_spline.points[0].hide = True

        elif navigation_passthrough(event, alt=True, wheel=False):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS' and not event.alt:
            self.finish(context)

            if self.step:
                spline_data = self.data.active
                sidx = next(i for i, s in enumerate(self.data.splines) if s is spline_data)

                spline_data.is_cyclic = self.act_spline.use_cyclic_u

                self.act_curve.splines.remove(self.act_curve.splines[sidx])
                create_spline_from_data(self.act_curve, spline_data, custom_points=self.new_points)
            else:
                for point in self.act_spline.points:
                    point.hide = False

            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self._abort_modal(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _abort_modal(self, context: Context):
        """取消或异常中止: 恢复样条可见性与循环状态并清理资源"""
        self.finish(context)

        for point in self.act_spline.points:
            point.hide = False

        self.act_spline.use_cyclic_u = self.is_initially_cyclic

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图预览"""
        if context.area != self.area:
            return

        if self.coords:
            draw_line(self.coords, color=orange, alpha=0.99)

            draw_points(self.coords[1:-1], size=4, color=black, alpha=1)

            color = white if self.act_spline.use_cyclic_u else red
            draw_points([self.coords[0], self.coords[-1]], size=4, color=color, alpha=1)

        if self.orig_gap_coords:
            draw_line(self.orig_gap_coords, color=yellow, alpha=0.75)

        if self.outlier_coords:
            draw_lines(self.outlier_coords, color=normal, width=2, alpha=0.99)

        if self.act_spline.use_cyclic_u and self.act_spline.type == 'NURBS':
            draw_line([self.coords[0], self.coords[-1]], color=black, alpha=1)

    def finish(self, context: Context):
        """
        清理模态操作资源

        Args:
            context: Blender上下文
        """
        self.finish_status()
        self.finish_modal_handlers()

    def _get_new_points(self, gap: int | None) -> list:
        """
        获取重排后的点列表

        Args:
            gap: 间隙位置索引,None表示自动检测

        Returns:
            重排后的点数据列表
        """
        spline_data = self.data.active
        points = spline_data.points.copy()

        if gap is not None:
            if gap:
                rotate_list(points, amount=gap)
        else:
            self.outliers = self._get_outlier_segment_indices(points)

            if self.outliers:
                opposite_outlier_idx = int(len(self.outliers) / 2)
                step = self.outliers[opposite_outlier_idx] + 1
                rotate_list(points, amount=step)
            else:
                step = int(len(points) / 2)
                rotate_list(points, amount=step)

            self.step = step

            if len(self.outliers) > 1:
                self.is_shuffle_outliers = True

        self.coords = [self.mx @ p.co.xyz for p in points]
        self.orig_gap_coords = [self.mx @ p.co.xyz for p in [spline_data.points[0], spline_data.points[-1]]]

        self.outlier_coords = []

        if len(self.outliers) > 1 and self.is_shuffle_outliers:
            for pidx in self.outliers:
                if self.step != pidx + 1:
                    self.outlier_coords.append(self.mx @ spline_data.points[pidx].co.xyz)
                    self.outlier_coords.append(self.mx @ spline_data.points[pidx + 1].co.xyz)

        return points

    def _get_outlier_segment_indices(self, points: list) -> list[int]:
        """
        获取异常间隙段的索引列表

        Args:
            points: 点数据列表

        Returns:
            异常间隙段的起始索引列表
        """
        gap_lengths = []

        for idx, point in enumerate(points[1:]):
            prev_point = points[idx]
            length = (prev_point.co.xyz - point.co.xyz).length
            gap_lengths.append(length)

        lower_bound, upper_bound = find_outliers(gap_lengths, lowp=25, highp=75, multiplier=1.5, bounds=True)

        outliers = []

        for idx, length in enumerate(gap_lengths):
            if length < lower_bound:
                if 0 < idx < len(points) - 2:
                    outliers.append(idx)
            elif length > upper_bound:
                if 0 < idx < len(points) - 2:
                    outliers.append(idx)

        return outliers


def draw_gap_shuffle_status(op: CurveGapShuffle):
    """
    返回 CurveGapShuffle 操作的状态栏绘制回调函数

    Args:
        op: CurveGapShuffle 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='MMB_SCROLL', text="Gap Shuffle", gap=1)
        draw_status_item(row, active=op.act_spline.use_cyclic_u, key='C', text="Toggle Cyclic")

        if len(op.outliers) > 1:
            draw_status_item(row, active=op.is_shuffle_outliers, key='Q', text="Toggle Outliers")

    return draw
