"""
布尔修改器操作模块

为活动对象添加布尔修改器,支持多种布尔方法和求解器.

操作流程:
1. 选择活动对象和切割对象
2. 调用操作器
3. 调整布尔方法和求解器
4. 确认或取消操作

支持的选项:
- Method: 布尔方法 (DIFFERENCE/UNION/INTERSECT/SPLIT)
- Solver: 求解器 (FLOAT/EXACT/MANIFOLD)

快捷键:
- 滚轮: 切换布尔方法
- S: 切换求解器
- LMB/SPACE/RET/NUMPAD_ENTER: 完成操作
"""

__all__ = ["AddBooleanMod", "ApplyBooleanMod"]

import bpy
from bpy.props import EnumProperty, BoolProperty
from bpy.types import Operator, Context, Event, Object

from ...items import boolean_method_items, boolean_solver_items, mod_apply_mode_items
from ...utils import (
    draw_status_item,
    navigation_passthrough,
    scroll,
    scroll_up,
    step_enum,
    get_collection,
    add_boolean_modifier,
    add_displace_modifier,
    remove_modifier,
    set_object_parent,
    clear_object_parent,
)
from ...modal_base import ModalOperatorMixin


# ============================================================
# 添加布尔修改器操作器
# ============================================================
class AddBooleanMod(Operator, ModalOperatorMixin):
    """
    布尔修改器操作器

    功能: 为活动对象添加布尔修改器
    - 支持多种布尔方法 (DIFFERENCE/UNION/INTERSECT/SPLIT)
    - 支持多种求解器 (FLOAT/EXACT/MANIFOLD)

    要求: 物体模式下有活动网格对象和至少一个选中的切割对象
    """

    bl_idname = "ch.add_boolean_mod"
    bl_label = "Add Boolean Modifier"
    bl_description = "Add Boolean Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    method: EnumProperty(name="Method", items=boolean_method_items, default='DIFFERENCE')  # type: ignore
    solver: EnumProperty(name="Solver", items=boolean_solver_items, default='FLOAT')  # type: ignore
    set_parent: BoolProperty(name="Set Parent", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'OBJECT':
            return

        act_obj = context.active_object
        if not act_obj or act_obj.type != 'MESH':
            return

        return any(obj != act_obj and obj.type == 'MESH' for obj in context.selected_objects)

    def invoke(self, context: Context, event: Event):
        self.boolean_modifiers = []
        self.created_objects = []
        self.intersect_objs = []
        self.boolean_objs = []

        self.execute(context)

        self.init_status(context, func=_draw_boolean_status(self))
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        context.area.tag_redraw()

        if scroll(event):
            direction = 1 if scroll_up(event) else -1
            self.method = step_enum(self.method, boolean_method_items, direction)
            self._cleanup_previous()
            self._apply_boolean(context)

        elif event.type == 'S' and event.value == "PRESS":
            self.solver = step_enum(self.solver, boolean_solver_items)
            self._cleanup_previous()
            self._apply_boolean(context)

        elif navigation_passthrough(event):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            return self._complete_and_link(context)

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            return self._cancel(context)

        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        if not hasattr(self, 'boolean_modifiers'):
            self.boolean_modifiers = []
            self.created_objects = []
            self.intersect_objs = []
            self.boolean_objs = []

        context.view_layer.update()
        self.act_obj = context.active_object
        self.sel_objs = [obj for obj in context.selected_objects if obj != self.act_obj]
        self.sel_objs_count = len(self.sel_objs)

        self._apply_boolean(context)

        return {'FINISHED'}

    def _cleanup_previous(self):
        """清理之前的布尔操作"""
        for mod in self.boolean_modifiers:
            remove_modifier(mod)
        self.boolean_modifiers.clear()

        for obj in self.created_objects:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        self.created_objects.clear()
        self.intersect_objs.clear()
        self.boolean_objs.clear()

        for obj in self.sel_objs:
            obj.display_type = 'TEXTURED'
            clear_object_parent(obj)

    def _apply_boolean(self, context: Context):
        """应用布尔操作"""
        method_handlers = {
            'INTERSECT': self._intersect,
            'UNION': self._union,
            'DIFFERENCE': self._difference,
            'SPLIT': self._split,
        }
        method_handlers[self.method](context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "method", expand=True)
        layout.prop(self, "solver", expand=True)
        layout.prop(self, "set_parent")

    def _setup_boolean_cutter(self, target_obj: Object, cutter_obj: Object, method: str, mod_name: str):
        """
        设置布尔切割对象

        Args:
            target_obj: 目标对象(布尔操作的主体)
            cutter_obj: 切割对象
            method: 布尔方法
            mod_name: 修改器名称
        """
        boolean_mod = add_boolean_modifier(target_obj, cutter_obj, method=method, solver=self.solver)
        boolean_mod.name = mod_name
        self.boolean_modifiers.append(boolean_mod)
        cutter_obj.display_type = 'WIRE'

        if self.set_parent:
            set_object_parent(cutter_obj, target_obj)

    def _duplicate_object(self, obj: Object, name: str, parent: Object | None = None) -> Object:
        """
        复制对象并设置基本属性

        Args:
            obj: 源对象
            name: 新对象名称
            parent: 父级对象(可选)

        Returns:
            复制的新对象
        """
        new_obj = bpy.data.objects.new(name, obj.data)
        obj.users_collection[0].objects.link(new_obj)

        if parent:
            set_object_parent(new_obj, parent)
        new_obj.matrix_world = obj.matrix_world

        self.created_objects.append(new_obj)
        return new_obj

    def _intersect(self, context: Context):
        """交集操作"""
        self.boolean_objs = [self.act_obj]

        if self.sel_objs_count > 1:
            for i in range(self.sel_objs_count - 1):
                act_obj_dup = self._duplicate_object(self.act_obj, f"{self.act_obj.name}_dup_{i+1}", self.act_obj.parent)
                self.boolean_objs.append(act_obj_dup)

        for i, (target, cutter) in enumerate(zip(self.boolean_objs, self.sel_objs)):
            self._setup_boolean_cutter(target, cutter, 'INTERSECT', f"Intersect_{i+1}")

    def _union(self, context: Context):
        """并集操作"""
        for i, cutter in enumerate(self.sel_objs):
            self._setup_boolean_cutter(self.act_obj, cutter, 'UNION', f"Union_{i+1}")

    def _difference(self, context: Context):
        """差集操作"""
        for i, cutter in enumerate(self.sel_objs):
            self._setup_boolean_cutter(self.act_obj, cutter, 'DIFFERENCE', f"Difference_{i+1}")

    def _split(self, context: Context):
        """分割操作"""
        for i, cutter in enumerate(self.sel_objs):
            self._setup_boolean_cutter(self.act_obj, cutter, 'DIFFERENCE', f"Difference_{i+1}")

        for i, cutter in enumerate(self.sel_objs):
            act_obj_intersect = self._duplicate_object(self.act_obj, f"{self.act_obj.name}_dup_{i+1}", self.act_obj.parent)

            sel_obj_intersect = self._duplicate_object(cutter, f"{cutter.name}_intersect_{i+1}", act_obj_intersect if self.set_parent else None)

            add_displace_modifier(sel_obj_intersect)
            self.intersect_objs.append(sel_obj_intersect)

            self._setup_boolean_cutter(act_obj_intersect, sel_obj_intersect, 'INTERSECT', f"Intersect_{i+1}")

    def _complete_and_link(self, context: Context) -> set:
        """完成操作(收尾清理 + 把结果物体挂回集合)并返回状态集合.

        注意: 本方法不是约定 10 的 finish 阶段方法(后者只做状态栏/模态处理器/头部文本收敛);
        本算子的 finish 阶段收敛在 _cleanup() 内, 由本方法与 _cancel() 共同调用.
        """
        self._cleanup()
        self._link_to_collection(context, self.sel_objs)
        if self.intersect_objs:
            self._link_to_collection(context, self.intersect_objs)
        return {'FINISHED'}

    def _cancel(self, context: Context) -> set:
        """取消操作"""
        self._cleanup()

        for mod in self.boolean_modifiers:
            remove_modifier(mod)

        for obj in self.created_objects:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)

        for obj in self.sel_objs:
            obj.display_type = 'TEXTURED'
            clear_object_parent(obj)

        return {'CANCELLED'}

    def _cleanup(self):
        """清理资源"""
        self.finish_status()
        self.finish_modal_handlers()

    def _link_to_collection(self, context: Context, cutters: list[Object]):
        """
        将切割对象链接到布尔集合

        Args:
            context: Blender上下文
            cutters: 切割对象列表
        """
        bcol = get_collection(context, "Boolean_Cutters")

        for obj in cutters:
            if obj.name not in bcol.objects:
                bcol.objects.link(obj)


def _draw_boolean_status(op):
    """返回 Boolean 操作的状态栏绘制回调函数"""

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='MMB_SCROLL', prop=op.method.title())
        draw_status_item(row, key='S', prop=op.solver.title())

    return draw


# ============================================================
# 移除或应用布尔修改器操作器
# ============================================================
class ApplyBooleanMod(Operator):
    """
    应用布尔修改器操作器

    功能: 自动应用或移除布尔修改器
    - 支持两种应用模式: 应用/移除
    - 应用模式: 应用布尔修改器, 可选删除切割物体
    - 移除模式: 移除布尔修改器并恢复原始状态, 删除创建的对象, 可选删除切割物体

    要求: 物体模式下有选中物体且存在布尔修改器
    """

    bl_idname = "ch.apply_boolean_mod"
    bl_label = "Apply Boolean Modifier"
    bl_description = "Automatically apply the boolean modifier"
    bl_options = {'REGISTER', 'UNDO'}

    apply_mode: EnumProperty(name="Apply Mode", description="The mode to apply the boolean modifier", items=mod_apply_mode_items, default='APPLY')  # type: ignore
    is_delete_cutter: BoolProperty(name="Delete Cutters", description="Whether to delete the cutter after applying the boolean operation", default=False)  # type: ignore
    is_clear_parent: BoolProperty(name="Clear Parent", description="Whether to clear parent relationship when not deleting cutter", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'OBJECT':
            return

        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for mod in obj.modifiers:
                    if mod.type == 'BOOLEAN':
                        return True

    def execute(self, context: Context):
        context.view_layer.update()

        self.valid_objs = [obj for obj in context.selected_objects if obj.type == 'MESH' and any(mod.type == 'BOOLEAN' and mod.object is not None for mod in obj.modifiers)]
        if not self.valid_objs:
            self.report({'INFO'}, "No valid objects selected")
            return {'CANCELLED'}

        mode_handlers = {
            'APPLY': self._apply_boolean_modifiers,
            'REMOVE': self._remove_boolean_modifiers,
        }
        mode_handlers[self.apply_mode](context)

        return {'FINISHED'}

    def _apply_boolean_modifiers(self, context: Context):
        """应用布尔修改器"""
        cutter_objs = []

        for obj in self.valid_objs:
            if obj.data.users > 1:
                obj.data = obj.data.copy()

            # 复制修改器列表, 避免在迭代时修改列表
            boolean_mods = [mod for mod in obj.modifiers if mod.type == 'BOOLEAN' and mod.object is not None]

            for mod in boolean_mods:
                cutter_objs.append(mod.object)
                with context.temp_override(object=obj):
                    bpy.ops.object.modifier_apply(modifier=mod.name)

        self._process_cutters(context, cutter_objs, restore_display=False)

    def _remove_boolean_modifiers(self, context: Context):
        """移除布尔修改器并恢复原始状态"""
        cutter_objs = []
        created_objs = []

        for obj in self.valid_objs:
            boolean_mods = [mod for mod in obj.modifiers if mod.type == 'BOOLEAN' and mod.object is not None]

            for mod in boolean_mods:
                cutter_objs.append(mod.object)
                remove_modifier(mod)

            if self._is_created_object(obj):
                created_objs.append(obj)

        self._delete_created_objects(created_objs)
        self._process_cutters(context, cutter_objs, restore_display=True)

    def _is_created_object(self, obj: Object) -> bool:
        """检查对象是否为布尔操作创建的对象"""
        return '_dup_' in obj.name or '_intersect_' in obj.name

    def _delete_created_objects(self, created_objs: list[Object]):
        """删除布尔操作创建的对象"""
        for obj in created_objs:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)

    def _process_cutters(self, context: Context, cutter_objs: list[Object], restore_display: bool):
        """
        处理切割对象

        Args:
            context: Blender上下文
            cutter_objs: 切割对象列表
            restore_display: 是否恢复显示类型为TEXTURED
        """
        if not cutter_objs:
            return

        for cutter in set(cutter_objs):
            if cutter.name not in bpy.data.objects:
                continue

            if self._is_created_object(cutter) or self.is_delete_cutter:
                bpy.data.objects.remove(cutter, do_unlink=True)
            else:
                if restore_display:
                    cutter.display_type = 'TEXTURED'

                if self.is_clear_parent:
                    clear_object_parent(cutter)

                bcol = get_collection(context, "Boolean_Cutters")
                if bcol and cutter.name in bcol.objects:
                    bcol.objects.unlink(cutter)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "apply_mode", expand=True)
        layout.prop(self, "is_delete_cutter")

        col = layout.column()
        col.enabled = not self.is_delete_cutter
        col.prop(self, "is_clear_parent")
