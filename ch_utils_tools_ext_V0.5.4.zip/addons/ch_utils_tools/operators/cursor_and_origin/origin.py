"""
原点操作器模块

提供以下功能:
- OriginToGeometry: 原点到几何中心
- OriginToCursor: 原点到游标
- OriginToActive: 原点到活动元素
- OriginToBoundBottom: 原点到边界盒底部

约定: 事件修饰键以类级缺省声明, 因 execute 可能未经 invoke 直接执行(脚本调用 / F9 重做),
此时按无修饰键处理; 上下文派生的活动物体在 execute 现算, 保证 execute 可独立执行.
"""

__all__ = [
    "OriginToGeometry",
    "OriginToCursor",
    "OriginToActive",
    "OriginToBoundBottom",
]

import bpy
import bmesh
from bpy.types import Object, Operator, Context, Event
from mathutils import Matrix
from bmesh.types import BMVert, BMEdge, BMFace

from ...constants import ORIGIN_EDIT_SUPPORT_TYPES
from ...utils import (
    MeasureObject,
    get_average_position,
    get_lerp_position,
    set_object_origin,
    get_evaluated_object,
    get_active_element_from_bmesh,
    has_selected_curve_element,
    get_rotation_matrix_from_vert,
    get_rotation_matrix_from_edge,
    get_rotation_matrix_from_face,
)


# ============================================================
# 原点到几何中心
# ============================================================
class OriginToGeometry(Operator):
    """
    原点到几何中心

    功能:将选中物体的原点设置到几何中心
    - 默认:设置到边界盒中心
    - Alt:设置到质心(表面)
    - Ctrl:设置到质心(体积)
    - Shift:将几何体移动到原点

    要求:物体模式
    """

    bl_idname = "ch.origin_to_geometry"
    bl_label = "Origin To Geometry"
    bl_description = "Set Selected Objects' Origin to Geometry\n+Alt: to Center of Mass (Surface)\n+Ctrl: to Center of Mass (Volume)\n+Shift: Geometry to Origin"
    bl_options = {'REGISTER', 'UNDO'}

    use_to_mass_surface: bool = False  # invoke 中按 Alt 键设置
    use_to_mass_volume: bool = False  # invoke 中按 Ctrl 键设置
    use_geometry_to_origin: bool = False  # invoke 中按 Shift 键设置

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def invoke(self, context: Context, event: Event):
        self.use_to_mass_surface = event.alt
        self.use_to_mass_volume = event.ctrl
        self.use_geometry_to_origin = event.shift

        # Alt 和 Ctrl 不能同时按下
        if self.use_to_mass_surface and self.use_to_mass_volume:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        return self.execute(context)

    def execute(self, context: Context):
        # 根据修饰键选择原点设置方式
        if self.use_to_mass_surface:
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
        elif self.use_to_mass_volume:
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME')
        elif self.use_geometry_to_origin:
            bpy.ops.object.origin_set(type='GEOMETRY_ORIGIN')
        else:
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')

        return {'FINISHED'}


# ============================================================
# 原点到游标
# ============================================================
class OriginToCursor(Operator):
    """
    原点到游标

    功能:将物体原点设置到游标位置
    - 物体模式:设置选中物体的原点到游标
    - 编辑模式(网格):设置活动网格物体的原点到游标
    - 编辑模式(曲线):设置活动曲线物体的原点到游标
    - Alt:仅设置原点位置
    - Ctrl:仅设置原点旋转
    """

    bl_idname = "ch.origin_to_cursor"
    bl_label = "Origin To Cursor"
    bl_description = "Set Object Origin to Cursor\n+Alt: Only set Origin Location\n+Ctrl: Only set Origin Rotation"
    bl_options = {'REGISTER', 'UNDO'}

    is_only_loc: bool = False  # invoke 中按 Alt 键设置
    is_only_rot: bool = False  # invoke 中按 Ctrl 键设置

    @classmethod
    def description(cls, context: Context, properties):
        if context.mode == 'OBJECT':
            return "Set Selected Objects' Origin to Cursor\n+Alt: only set Origin Location\n+Ctrl: only set Origin Rotation"
        elif context.mode == 'EDIT_MESH':
            return "Set Mesh Object's Origin to Cursor\n+Alt: only set Origin Location\n+Ctrl: only set Origin Rotation"
        elif context.mode == 'EDIT_CURVE':
            return "Set Object's Origin to Cursor"

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'OBJECT':
            sel_objs = (obj for obj in context.selected_objects if obj.type in ORIGIN_EDIT_SUPPORT_TYPES)
            if next(sel_objs, None):
                return True
        elif context.mode in {'EDIT_MESH', 'EDIT_CURVE'}:
            return True

    def invoke(self, context: Context, event: Event):
        self.is_only_loc = event.alt
        self.is_only_rot = event.ctrl

        # Alt 和 Ctrl 不能同时按下
        if self.is_only_loc and self.is_only_rot:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        return self.execute(context)

    def execute(self, context: Context):
        self.cur_mx = context.scene.cursor.matrix

        match context.mode:
            case 'OBJECT':
                self._origin_to_cursor_object(context, self.is_only_loc, self.is_only_rot)
            case 'EDIT_MESH':
                self._origin_to_cursor_edit_mesh(context, self.is_only_loc, self.is_only_rot)
            case 'EDIT_CURVE':
                self._origin_to_cursor_edit_curve(context)

        return {'FINISHED'}

    def _origin_to_cursor_object(self, context: Context, is_only_loc: bool = False, is_only_rot: bool = False) -> None:
        """
        物体模式:将选中物体的原点设置到游标

        Args:
            context: Blender上下文
            is_only_loc: 是否仅设置位置
            is_only_rot: 是否仅设置旋转
        """
        sel_objs = [obj for obj in context.selected_objects if obj.type in ORIGIN_EDIT_SUPPORT_TYPES]

        for obj in sel_objs:
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'LATTICE'}:
                loc, rot, sca = obj.matrix_world.decompose()
                new_loc, new_rot, _ = self.cur_mx.decompose()

                # 根据模式构建新的变换矩阵
                if is_only_loc:
                    new_mx = Matrix.LocRotScale(new_loc, rot, sca)
                elif is_only_rot:
                    new_mx = Matrix.LocRotScale(loc, new_rot, sca)
                else:
                    new_mx = self.cur_mx

                set_object_origin(obj, new_mx)
            else:
                # 不支持的类型:临时隔离选择后调用系统操作, 避免覆盖已处理物体的原点
                pre_selected = context.selected_objects.copy()

                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                for restore_obj in pre_selected:
                    restore_obj.select_set(True)

    def _origin_to_cursor_edit_mesh(self, context: Context, is_only_loc: bool = False, is_only_rot: bool = False) -> None:
        """
        网格编辑模式:将活动网格物体的原点设置到游标

        Args:
            context: Blender上下文
            is_only_loc: 是否仅设置位置
            is_only_rot: 是否仅设置旋转
        """
        act_obj = context.object
        loc, rot, sca = act_obj.matrix_world.decompose()
        new_loc, new_rot, _ = self.cur_mx.decompose()

        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()

        # 根据模式构建新的变换矩阵
        if is_only_loc:
            new_mx = Matrix.LocRotScale(new_loc, rot, sca)
        elif is_only_rot:
            new_mx = Matrix.LocRotScale(loc, new_rot, sca)
        else:
            new_mx = self.cur_mx

        set_object_origin(act_obj, new_mx, bm)

    def _origin_to_cursor_edit_curve(self, context: Context) -> None:
        """
        曲线编辑模式:将活动曲线物体的原点设置到游标

        通过临时切换到物体模式调用系统操作实现

        Args:
            context: Blender上下文
        """
        bpy.ops.object.editmode_toggle()
        try:
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        finally:
            bpy.ops.object.editmode_toggle()


# ============================================================
# 原点到活动元素
# ============================================================
class OriginToActive(Operator):
    """
    原点到活动元素

    功能:将物体原点设置到活动元素位置
    - 物体模式:设置选中物体的原点到活动物体
    - 编辑模式(网格):设置原点到活动顶点/边/面
    - 编辑模式(曲线):设置原点到选中点
    - Alt:仅设置原点位置
    - Ctrl:仅设置原点旋转
    """

    bl_idname = "ch.origin_to_active"
    bl_label = "Origin To Active"
    bl_description = "Set Object Origin to Cursor"
    bl_options = {'REGISTER', 'UNDO'}

    is_only_loc: bool = False  # invoke 中按 Alt 键设置
    is_only_rot: bool = False  # invoke 中按 Ctrl 键设置

    @classmethod
    def description(cls, context: Context, properties):
        if context.mode == 'OBJECT':
            return "Set Selected Objects' Origin to Active Object\n+Alt: only set Origin Location\n+Ctrl: only set Origin Rotation"
        elif context.mode == 'EDIT_MESH':
            return "Set Mesh Object's Origin to Active Vert/Edge/Face\n+Alt: only set Origin Location\n+Ctrl: only set Origin Rotation"
        elif context.mode == 'EDIT_CURVE':
            return "Set Curve Object's Origin to Selected point(s)"

    @classmethod
    def poll(cls, context: Context):
        act_obj = context.active_object
        if act_obj:
            if context.mode == 'OBJECT':
                sel_objs = (obj for obj in context.selected_objects if obj != act_obj and obj.type in ORIGIN_EDIT_SUPPORT_TYPES)
                if next(sel_objs, None):
                    return True

            elif context.mode == 'EDIT_MESH':
                bm = bmesh.from_edit_mesh(act_obj.data)
                return get_active_element_from_bmesh(context, bm)

            elif context.mode == 'EDIT_CURVE':
                return has_selected_curve_element(act_obj)

    def invoke(self, context: Context, event: Event):
        self.is_only_loc = event.alt
        self.is_only_rot = event.ctrl

        # Alt 和 Ctrl 不能同时按下
        if self.is_only_loc and self.is_only_rot:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        return self.execute(context)

    def execute(self, context: Context):
        # 活动物体为上下文派生, 在 execute 现算以保证其可独立执行
        self.act_obj = context.active_object

        if context.mode == 'OBJECT':
            self._origin_to_active_object(context, self.is_only_loc, self.is_only_rot)
        elif context.mode == 'EDIT_MESH':
            self._origin_to_active_edit_mesh(context, self.act_obj, self.is_only_loc, self.is_only_rot)
        elif context.mode == 'EDIT_CURVE':
            self._origin_to_active_edit_curve(context)

        return {'FINISHED'}

    def _origin_to_active_object(self, context: Context, is_only_loc: bool, is_only_rot: bool) -> None:
        """
        物体模式:将选中物体的原点设置到活动物体

        Args:
            context: Blender上下文
            is_only_loc: 是否仅设置位置
            is_only_rot: 是否仅设置旋转
        """
        sel_objs = [obj for obj in context.selected_objects if obj != self.act_obj and obj.type in ORIGIN_EDIT_SUPPORT_TYPES]
        new_loc, new_rot, _ = self.act_obj.matrix_world.decompose()

        for obj in sel_objs:
            if obj.type in {'MESH', 'CURVE', 'SURFACE', 'LATTICE'}:
                loc, rot, sca = obj.matrix_world.decompose()

                # 根据模式构建新的变换矩阵
                if is_only_loc:
                    new_mx = Matrix.LocRotScale(new_loc, rot, sca)
                elif is_only_rot:
                    new_mx = Matrix.LocRotScale(loc, new_rot, sca)
                else:
                    new_mx = self.act_obj.matrix_world

                set_object_origin(obj, new_mx)
            else:
                # 不支持的类型:临时隔离选择并移动游标, 调用系统操作后恢复
                pre_selected = context.selected_objects.copy()
                cur_mx = context.scene.cursor.matrix.copy()

                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj

                try:
                    context.scene.cursor.matrix = self.act_obj.matrix_world.copy()
                    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
                finally:
                    context.scene.cursor.matrix = cur_mx
                    for restore_obj in pre_selected:
                        restore_obj.select_set(True)

    def _origin_to_active_edit_mesh(self, context: Context, act_obj: Object, is_only_loc: bool, is_only_rot: bool) -> None:
        """
        网格编辑模式:将原点设置到活动元素

        根据活动元素类型(顶点/边/面)计算位置和旋转

        Args:
            context: Blender上下文
            act_obj: 活动物体
            is_only_loc: 是否仅设置位置
            is_only_rot: 是否仅设置旋转
        """
        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.verts.ensure_lookup_table()

        act_element = get_active_element_from_bmesh(context, bm)
        act_mx = act_obj.matrix_world.copy()

        # 根据活动元素类型计算位置和旋转
        if isinstance(act_element, BMVert):
            # 顶点模式:计算选中顶点的平均位置
            vert_list = [v for v in bm.verts if v.select]
            vertex_center = get_average_position([v.co for v in vert_list])
            loc = act_mx @ vertex_center
            rot = get_rotation_matrix_from_vert(context, act_mx, act_element)

        elif isinstance(act_element, BMEdge):
            # 边模式:计算选中边的中点平均位置
            edge_list = [e for e in bm.edges if e.select]
            edge_center = get_average_position([get_lerp_position(*e.verts) for e in edge_list])
            loc = act_mx @ edge_center
            rot = get_rotation_matrix_from_edge(context, act_mx, act_element)

        elif isinstance(act_element, BMFace):
            # 面模式:计算选中面的中心平均位置
            face_list = [f for f in bm.faces if f.select]
            face_center = get_average_position([f.calc_center_median_weighted() for f in face_list])
            loc = act_mx @ face_center
            rot = get_rotation_matrix_from_face(act_mx, act_element)

        # 根据模式构建新的变换矩阵
        new_loc = act_mx.to_translation() if is_only_rot else loc
        new_rot = act_mx.to_quaternion() if is_only_loc else rot.to_quaternion()
        new_mx = Matrix.LocRotScale(new_loc, new_rot, act_obj.scale)

        set_object_origin(act_obj, new_mx, bm)

    def _origin_to_active_edit_curve(self, context: Context) -> None:
        """
        曲线编辑模式:将原点设置到选中点

        通过临时移动游标到选中点,调用系统操作实现

        Args:
            context: Blender上下文
        """
        cur_mx = context.scene.cursor.matrix.copy()
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.editmode_toggle()
        try:
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        finally:
            bpy.ops.object.editmode_toggle()
            context.scene.cursor.matrix = cur_mx


# ============================================================
# 原点到边界盒底部
# ============================================================
class OriginToBoundBottom(Operator):
    """
    原点到边界盒底部,+Alt键到顶部

    功能:将网格物体的原点设置到边界盒底部中心
    - 适用于需要将物体"放置"在地面的场景

    要求:物体模式下有选中的网格物体
    """

    bl_idname = "ch.origin_to_bound_bottom"
    bl_label = "Origin To BBox Bottom"
    bl_description = "Set Object Origin to BBox Bottom\n+Alt: Set Origin to BBox Top"
    bl_options = {'REGISTER', 'UNDO'}

    is_alt: bool = False  # invoke 中按 Alt 键设置

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'OBJECT':
            return 'MESH' in {obj.type for obj in context.selected_objects}

    def invoke(self, context: Context, event: Event):
        self.is_alt = event.alt
        return self.execute(context)

    def execute(self, context: Context):
        sel_objs = [obj for obj in context.selected_objects if obj.type == 'MESH']

        for obj in sel_objs:
            # 获取评估后的物体并计算底部中心位置
            dep_obj = get_evaluated_object(context, obj)
            measure = MeasureObject(dep_obj, dep_obj.matrix_world)
            target_pos = measure.top_center_pos if self.is_alt else measure.bottom_center_pos

            # 构建新的变换矩阵(保持旋转和缩放)
            new_mx = Matrix.LocRotScale(target_pos, obj.rotation_euler, obj.scale)
            set_object_origin(obj, new_mx)

        return {'FINISHED'}
