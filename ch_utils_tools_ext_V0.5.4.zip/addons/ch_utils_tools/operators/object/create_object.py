"""
网格物体创建操作器模块

提供以下功能:
- CreatePointObject: 创建单点物体
- CreateMeshQuadSphere: 创建四边面球体
- DupAndSep: 复制并分离选中元素
"""

__all__ = [
    "CreatePointObject",
    "CreateMeshQuadSphere",
    "DupAndSep",
]

import bpy
import bmesh
from bpy.types import Context, Operator, Event
from bpy.props import BoolProperty, IntProperty
from mathutils import Matrix, Quaternion, Vector

from ...utils import get_active_element_from_bmesh



# ============================================================
# 创建点物体
# ============================================================
class CreatePointObject(Operator):
    """
    创建网格点物体或曲线点物体,+alt键创建曲线点物体
    要求:物体模式
    """

    bl_idname = "ch.create_point"
    bl_label = "Add Point"
    bl_description = "Create a mesh point object\n+Alt: Create a curve point object"
    bl_options = {'REGISTER', 'UNDO'}

    is_align_rotation: BoolProperty(name="Align to Cursor Rotation", default=False, description="Align rotation to cursor")  # type: ignore

    use_curve_point: bool = False  # invoke 中按 Alt 键设置

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def invoke(self, context: Context, event: Event):
        self.use_curve_point = event.alt
        return self.execute(context)

    def execute(self, context: Context):
        if self.use_curve_point:
            obdata = self._create_curve_point(context)
        else:
            obdata = self._create_mesh_point(context)

        # 创建物体并链接到场景
        point_obj = bpy.data.objects.new("CurvePoint" if self.use_curve_point else "MeshPoint", obdata)
        context.collection.objects.link(point_obj)

        # 清除当前选择并选中新创建的点物体
        bpy.ops.object.select_all(action='DESELECT')
        point_obj.select_set(True)
        context.view_layer.objects.active = point_obj

        # 对齐游标变换
        loc, rot, _ = context.scene.cursor.matrix.decompose()
        rotation = rot if self.is_align_rotation else Quaternion()
        point_obj.matrix_world = Matrix.LocRotScale(loc, rotation, Vector((1, 1, 1)))

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "is_align_rotation")

    def _create_curve_point(self, context: Context):
        # 创建曲线物体数据
        curve_data = bpy.data.curves.new(name="CurvePoint", type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.use_fill_caps = True

        # 创建曲线点
        spline = curve_data.splines.new('POLY')
        point = spline.points[0]
        point.co = Vector((0, 0, 0, 1))
        point.select = True

        return curve_data

    def _create_mesh_point(self, context: Context):
        # 创建新的网格数据,包含单个顶点
        mesh_data = bpy.data.meshes.new('MeshPoint')
        mesh_data.from_pydata([(0, 0, 0)], [], [])

        return mesh_data


# ============================================================
# 创建网格四边面球体
# ============================================================
class CreateMeshQuadSphere(Operator):
    """
    创建四边面球体

    功能:创建一个由四边面组成的球体
    - 基于立方体细分化后球形化
    - 支持自定义细分级数
    - 支持自动平滑着色
    - 支持对齐游标旋转

    要求:物体模式
    """

    bl_idname = "ch.create_mesh_quadsphere"
    bl_label = "Add Quad Sphere"
    bl_description = "Create a quad sphere object"
    bl_options = {'REGISTER', 'UNDO'}

    subdivisions: IntProperty(name="Subdivisions", default=5, min=1, max=8)  # type: ignore
    is_shade_auto_smooth: BoolProperty(name="Shade Auto Smooth", default=True)  # type: ignore
    is_align_rotation: BoolProperty(name="Align Cursor Rotation", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def execute(self, context: Context):
        # 创建立方体(对齐游标或世界)
        bpy.ops.mesh.primitive_cube_add(align='CURSOR' if self.is_align_rotation else 'WORLD')

        # 进入编辑模式进行细分化
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.subdivide(number_cuts=self.subdivisions, smoothness=1)

        # 球形化变形
        bpy.ops.transform.tosphere(value=1)

        # 返回物体模式
        bpy.ops.object.mode_set(mode='OBJECT')

        # 应用自动平滑着色
        if self.is_shade_auto_smooth:
            bpy.ops.object.shade_auto_smooth()

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "subdivisions")
        layout.prop(self, "is_shade_auto_smooth")
        layout.prop(self, "is_align_rotation")


# ============================================================
# 复制并分离
# ============================================================
class DupAndSep(Operator):
    """
    复制并分离

    功能:分离选中的网格元素
    - 默认:直接分离选中元素
    - Alt:先复制再分离

    要求:网格编辑模式下有选中元素
    """

    bl_idname = "ch.duplicate_and_separate"
    bl_label = "Duplicate and Separate"
    bl_description = "Separate selected elements\n+Alt: Duplicate and Separate"
    bl_options = {'REGISTER', 'UNDO'}

    is_separate: bool = False  # invoke 中按 Alt 键设置

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return get_active_element_from_bmesh(context, bm)

    def invoke(self, context: Context, event: Event):
        self.is_separate = event.alt
        return self.execute(context)

    def execute(self, context: Context):
        # Alt 按下时先复制
        if self.is_separate:
            bpy.ops.mesh.duplicate()

        # 分离选中元素
        bpy.ops.mesh.separate(type='SELECTED')

        return {'FINISHED'}
