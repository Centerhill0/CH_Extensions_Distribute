"""
相机辅助操作器模块

提供以下功能:
- ToggleCamera: 切换相机操作器
- SetAsSceneCamera: 设为场景相机操作器
- CreateAlignCamera: 创建对齐视图相机操作器
"""

import bpy
from bpy.props import BoolProperty
from bpy.types import Operator, Context, Event

from ...preference import get_prefs


# ============================================================
# 切换相机操作器
# ============================================================
class ToggleCamera(Operator):
    """
    切换相机

    功能:在场景中的相机之间切换
    - Previous:切换到上一个相机
    - Next:切换到下一个相机
    - 可选择是否自动对齐视图

    要求:物体模式
    """

    bl_idname = "ch.toggle_camera"
    bl_label = "Toggle Camera"
    bl_description = "Toggle the camera object"

    toggle_next: BoolProperty(name="Toggle Next", default=True)  # type: ignore

    camera_list: list

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def _get_visible_cameras(self, context: Context) -> list:
        return [obj for obj in context.view_layer.objects if obj.type == 'CAMERA']

    def invoke(self, context: Context, event: Event):
        self.camera_list = self._get_visible_cameras(context)
        self.camera_list.sort(key=lambda x: x.name)

        if not self.camera_list:
            self.report({'WARNING'}, "No camera found in view layer")
            return {'CANCELLED'}

        for obj in context.selected_objects:
            obj.select_set(False)

        return self.execute(context)

    def execute(self, context: Context):
        if not hasattr(self, 'camera_list') or not self.camera_list:
            self.camera_list = self._get_visible_cameras(context)
            self.camera_list.sort(key=lambda x: x.name)
            if not self.camera_list:
                self.report({'WARNING'}, "No camera found in view layer")
                return {'CANCELLED'}

        addon_prefs = get_prefs()
        camera_count = len(self.camera_list)

        current_camera = context.scene.camera
        if current_camera in self.camera_list:
            current_index = self.camera_list.index(current_camera)
        elif context.active_object in self.camera_list:
            current_index = self.camera_list.index(context.active_object)
        else:
            current_index = camera_count - 1 if not self.toggle_next else -1

        if self.toggle_next:
            next_index = (current_index + 1) % camera_count
        else:
            next_index = (current_index - 1) % camera_count

        next_camera = self.camera_list[next_index]
        next_camera.select_set(True)
        context.view_layer.objects.active = next_camera

        if addon_prefs.is_align:
            bpy.ops.view3d.object_as_camera()

        return {'FINISHED'}


# ============================================================
# 设为场景相机操作器
# ============================================================
class SetAsSceneCamera(Operator):
    """
    设为场景相机

    功能:将活动物体设为场景的活动相机
    - 不自动切换到相机视图

    要求:物体模式
    """

    bl_idname = "ch.set_as_scene_camera"
    bl_label = "Set As Scene Camera"
    bl_description = "Set the active object as the scene camera"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def execute(self, context: Context):
        context.scene.camera = context.active_object
        return {'FINISHED'}


# ============================================================
# 创建对齐视图相机操作器
# ============================================================
class CreateAlignCamera(Operator):
    """
    创建对齐视图相机

    功能:创建一个新相机并自动对齐到当前视图
    - 创建新相机
    - 设为场景相机
    - 对齐到当前视图

    要求:物体模式
    """

    bl_idname = "ch.create_align_camera"
    bl_label = "Create Align Camera"
    bl_description = "Create a camera for aligning the view"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        # 创建相机
        bpy.ops.object.camera_add()

        # 设为场景相机并对齐到视图
        context.scene.camera = context.active_object
        bpy.ops.view3d.camera_to_view()

        return {'FINISHED'}
