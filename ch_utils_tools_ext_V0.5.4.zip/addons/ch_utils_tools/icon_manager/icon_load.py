"""
图标管理模块

提供以下功能:
- 加载和管理自定义图标
- 获取图标 ID 用于界面显示

使用方法:
1. 在插件注册时调用 load_icon() 加载图标
2. 使用 get_icon_id(icon_name) 获取图标 ID
3. 在插件注销时调用 clear_icon() 清理资源
"""

import bpy.utils.previews
import os
from typing import Optional, Dict

# 图标文件夹路径
_icons_dir = os.path.join(os.path.dirname(__file__), "icons")

# 预览集合对象(全局变量)
pcoll: Optional[bpy.utils.previews.ImagePreviewCollection] = None


def create_icon_dict() -> Dict[str, str]:
    """
    创建图标文件名字典

    扫描 icons 文件夹下的所有 PNG 文件,
    生成以文件名(不含扩展名)为键,完整文件名为值的字典.

    Returns:
        Dict[str, str]: 图标名字典 {图标名: 文件名.扩展名}
    """
    # 检查图标文件夹是否存在
    if not os.path.isdir(_icons_dir):
        return {}

    # 使用字典推导式生成图标字典
    return {icon.rsplit(".", 1)[0]: icon for icon in os.listdir(_icons_dir) if icon.endswith(".png")}


def load_icon() -> bpy.utils.previews.ImagePreviewCollection:
    """
    加载所有图标到预览集合

    创建 ImagePreviewCollection 并加载 icons 文件夹中的所有 PNG 图标.
    应在插件注册时调用此函数.

    Returns:
        ImagePreviewCollection: 包含所有已加载图标的预览集合
    """
    global pcoll

    # 如果已经加载过,先清理避免内存泄漏
    if pcoll is not None:
        clear_icon()

    # 创建新的预览集合
    pcoll = bpy.utils.previews.new()

    # 加载所有图标
    icon_dict = create_icon_dict()
    for key, filename in icon_dict.items():
        path = os.path.join(_icons_dir, filename)
        pcoll.load(key, path, 'IMAGE')

    return pcoll


def clear_icon() -> None:
    """
    清除预览集合

    释放预览集合占用的资源.
    应在插件注销时调用此函数.
    """
    global pcoll
    if pcoll is not None:
        bpy.utils.previews.remove(pcoll)
        pcoll = None


def get_icon_id(icon_name: str) -> Optional[int]:
    """
    获取图标 ID

    根据图标名称获取对应的图标 ID,用于在界面中显示图标.

    Args:
        icon_name: 图标名称(不含扩展名)

    Returns:
        Optional[int]: 图标 ID,如果图标不存在或未初始化则返回 None
    """
    if pcoll is not None and icon_name in pcoll:
        return pcoll[icon_name].icon_id

    print(f"WARNING: icon '{icon_name}' not found in preview collection")
    return None
