"""
数据处理模块

提供列表旋转, 数值格式化, 枚举步进等数据处理功能.

主要功能:
- rotate_list: 循环旋转列表
- format_adaptive_precision: 自适应精度格式化
- step_enum: 枚举步进
- step_list: 列表步进
- negate_string: 反转正负号
"""

from math import log10, floor


def rotate_list(lst: list, amount: int) -> list:
    """
    循环旋转列表元素(原地修改)

    Args:
        lst: 需要旋转的列表
        amount: 旋转位移,正数向左,负数向右
    Returns:
        旋转后的同一列表对象
    """
    n = len(lst)
    if n == 0 or amount == 0:
        return lst

    amount = amount % n
    if amount:
        lst[:] = lst[amount:] + lst[:amount]
    return lst


def format_adaptive_precision(value: float, decimal_offset: int = 2) -> str:
    """
    根据数值大小动态调整小数精度的格式化输出
    Args:
        value: 需要格式化的数值
        decimal_offset: 额外增加的小数位数(默认 2, 保证十分位以上精度)
    Returns:
        自动适配精度的数值文本
    """
    if round(value, 6) == 0:
        return '0'

    abs_value = abs(value)
    log10_abs = log10(abs_value)

    if log10_abs < 0:
        precision = floor(abs(log10_abs)) + 1 + decimal_offset
    else:
        precision = decimal_offset

    sign = '-' if value < 0 else ''
    return f"{sign}{abs_value:.{precision}f}"


def step_enum(current: str, items: list[tuple], step: int = 1, loop: bool = True) -> str:
    """
    在枚举项列表中按步长移动, 获取目标枚举值
    Args:
        current: 当前枚举值
        items: 枚举项列表, 格式为 [(value, label), ...]
        step: 移动步长, 正数向后, 负数向前
        loop: 是否循环遍历, 为 True 时超出边界循环到另一端
    Returns:
        目标枚举值
    """
    return step_list(current, [item[0] for item in items], step, loop)


def step_list(current, lst: list, step: int = 1, loop: bool = True):
    """
    在列表中按步长移动, 获取目标元素

    Args:
        current: 当前元素
        lst: 列表
        step: 移动步长, 正数向后, 负数向前
        loop: 是否循环遍历, 为 True 时超出边界循环到另一端

    Returns:
        目标元素
    """
    item_idx = lst.index(current)
    step_idx = item_idx + step

    if step_idx >= len(lst):
        step_idx = 0 if loop else len(lst) - 1

    elif step_idx < 0:
        step_idx = len(lst) - 1 if loop else 0

    return lst[step_idx]


def negate_string(floatstring: str) -> str:
    """反转数值字符串的正负号"""
    return floatstring[1:] if floatstring.startswith("-") else "-" + floatstring
