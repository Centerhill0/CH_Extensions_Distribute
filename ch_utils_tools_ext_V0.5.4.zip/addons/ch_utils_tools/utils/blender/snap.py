"""
吸附工具模块

提供场景物体吸附(Snapping)功能.

主要功能:
- Snap: 场景物体吸附功能类, 支持射线检测, 对象排除, 编辑模式处理, 缓存等
- SnapCache: 吸附缓存类, 缓存对象, 网格, bmesh, 三角面等
"""

import bpy
import bmesh
from bpy.types import Context, Object, Modifier, Mesh

from .raycast import raycast_from_mouse


class Snap:
    """
    场景物体吸附(Snapping)功能类
    支持射线检测, 对象排除, 编辑模式处理, 缓存等
    """

    def __init__(self, context: Context, include: list[Object] | None = None, exclude: list[Object] | None = None, exclude_wire: bool = False, alternative: list[Object] | None = None):
        """
        初始化 Snap 实例

        Args:
            context: Blender 上下文
            include: 仅包含的对象列表
            exclude: 排除的对象列表
            exclude_wire: 是否排除线框对象
            alternative: 备选对象列表
        """
        self.depsgraph = None
        self.cache = None

        self.exclude: list[Object] = []
        self.exclude_wire = False
        self.alternative: list[Object] = []

        self.hit = None
        self.hit_obj: Object | None = None
        self.hit_index: int | None = None
        self.hit_location = None
        self.hit_normal = None
        self.hit_mx = None
        self.hit_face = None
        self._last_hit_name: str | None = None

        self._edit_mesh_objs: list[Object] = []
        self._modifiers: list[tuple[Object, Modifier]] = []

        self._init_edit_mode(context)
        self._init_exclude(context, include, exclude, exclude_wire)
        self._init_alternatives(context, alternative)
        self.depsgraph = context.evaluated_depsgraph_get()
        self.cache = SnapCache()

    def finish(self) -> None:
        """结束吸附, 恢复修改器, 移除备选对象, 清理缓存"""
        if self._modifiers:
            self._enable_modifiers()
        self._remove_alternatives()
        self.cache.clear()

    def update_hit(self, mouse_pos) -> None:
        """
        根据鼠标位置进行射线检测, 更新命中信息和缓存

        Args:
            mouse_pos: 鼠标位置
        """
        self.hit, self.hit_obj, self.hit_index, self.hit_location, self.hit_normal, self.hit_mx = raycast_from_mouse(mouse_pos, self.depsgraph, exclude=self.exclude, exclude_wire=self.exclude_wire, temp_unhide=self.alternative)

        if not self.hit:
            # 未命中时清空残留命中数据, 避免消费方读到上一次的结果
            self.hit_obj = None
            self.hit_index = None
            self.hit_location = None
            self.hit_normal = None
            self.hit_mx = None
            self.hit_face = None
            return

        name = self.hit_obj.name

        if name not in self.cache.objects:
            self._cache_hit_object(name)

        # 命中对象切换时必须重置hit_face, 否则面索引巧合相同会残留上一个对象的face
        if name != self._last_hit_name:
            self._last_hit_name = name
            self.hit_face = None

        if self.hit_face is None or self.hit_face.index != self.hit_index:
            self.hit_face = self.cache.bmeshes[name].faces[self.hit_index]

        if self.hit_index not in self.cache.tri_coords[name]:
            self._cache_tri_coords(name)

    def _cache_hit_object(self, name: str) -> None:
        """缓存命中对象的相关数据"""
        self.cache.objects[name] = self.hit_obj
        mesh = bpy.data.meshes.new_from_object(self.hit_obj.evaluated_get(self.depsgraph), depsgraph=self.depsgraph)
        self.cache.meshes[name] = mesh
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        self.cache.bmeshes[name] = bm
        self.cache.loop_triangles[name] = bm.calc_loop_triangles()
        self.cache.tri_coords[name] = {}

    def _cache_tri_coords(self, name: str) -> None:
        """缓存三角面坐标"""
        loop_triangles = self.cache.loop_triangles[name]
        tri_coords = [self.hit_mx @ l.vert.co for tri in loop_triangles if tri[0].face == self.hit_face for l in tri]
        self.cache.tri_coords[name][self.hit_index] = tri_coords

    def _init_edit_mode(self, context: Context) -> None:
        """编辑模式下, 更新网格并禁用修改器"""
        if context.mode == 'EDIT_MESH':
            self._update_meshes(context)
            self._disable_modifiers()

    def _init_exclude(self, context: Context, include: list[Object] | None, exclude: list[Object] | None, exclude_wire: bool) -> None:
        """初始化排除对象列表"""
        if include:
            self.exclude = [obj for obj in context.visible_objects if obj not in include]
        elif exclude:
            self.exclude = exclude

        view = context.space_data
        if view.local_view:
            hidden = [obj for obj in context.view_layer.objects if not obj.visible_get()]
            self.exclude.extend(hidden)
        self.exclude_wire = exclude_wire

    def _init_alternatives(self, context: Context, alternative: list[Object] | None) -> None:
        """初始化备选对象(复制并隐藏)"""
        if not alternative:
            return

        for obj in alternative:
            if obj not in self.exclude:
                self.exclude.append(obj)
            dup = obj.copy()
            dup.data = obj.data.copy()
            context.scene.collection.objects.link(dup)
            dup.hide_set(True)
            self.alternative.append(dup)

    def _remove_alternatives(self) -> None:
        """移除所有备选对象"""
        for obj in self.alternative:
            bpy.data.meshes.remove(obj.data, do_unlink=True)

    def _update_meshes(self, context: Context) -> None:
        """编辑模式下, 更新所有可见编辑对象的网格"""
        self._edit_mesh_objs = [obj for obj in context.visible_objects if obj.mode == 'EDIT']
        for obj in self._edit_mesh_objs:
            obj.update_from_editmode()

    def _disable_modifiers(self) -> None:
        """禁用编辑对象的所有可见修改器"""
        self._modifiers = [(obj, mod) for obj in self._edit_mesh_objs for mod in obj.modifiers if mod.show_viewport]
        for obj, mod in self._modifiers:
            if mod.type == 'NODES' and mod.node_group and mod.node_group.name.startswith('Smooth by Angle'):
                continue
            mod.show_viewport = False

    def _enable_modifiers(self) -> None:
        """恢复之前禁用的所有修改器"""
        for obj, mod in self._modifiers:
            mod.show_viewport = True


class SnapCache:
    """
    吸附缓存类, 缓存对象, 网格, bmesh, 三角面等, 便于高效重复使用
    """

    def __init__(self) -> None:
        """初始化缓存"""
        self.objects: dict[str, Object] = {}
        self.meshes: dict[str, Mesh] = {}
        self.bmeshes: dict[str, bmesh.types.BMesh] = {}
        self.loop_triangles: dict[str, list] = {}
        self.tri_coords: dict[str, dict[int, list]] = {}

    def clear(self) -> None:
        """清理所有缓存, 释放内存"""
        for name, mesh in self.meshes.items():
            bpy.data.meshes.remove(mesh, do_unlink=True)

        for name, bm in self.bmeshes.items():
            bm.free()

        self.objects.clear()
        self.meshes.clear()
        self.bmeshes.clear()
        self.loop_triangles.clear()
        self.tri_coords.clear()
