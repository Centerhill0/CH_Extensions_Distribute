"""
材质工具模块

提供材质节点获取, 材质输出节点查找等功能.

主要功能:
- get_material_output: 获取材质输出节点
- get_last_node: 获取连接到输出节点的最后一个节点
"""

from bpy.types import Material, Node


def get_material_output(mat: Material) -> Node | None:
    """
    获取材质的输出节点

    Args:
        mat: 材质对象

    Returns:
        材质输出节点, 如果不存在则返回None
    """
    output = mat.node_tree.nodes.get('Material Output')
    if output:
        return output

    for node in mat.node_tree.nodes:
        if node.type == 'OUTPUT_MATERIAL':
            return node

    return None


def get_last_node(mat: Material, skip_mix_node: bool = True) -> Node | None:
    """
    获取材质节点树的最后一个节点(连接到输出节点的节点)

    Args:
        mat: 材质对象
        skip_mix_node: 是否跳过混合着色器节点

    Returns:
        最后一个节点, 如果不存在则返回None
    """
    output = get_material_output(mat)
    if not output:
        return None

    surf = output.inputs.get("Surface")
    if not surf or not surf.links:
        return None

    node = surf.links[0].from_node

    if node.type == 'MIX_SHADER' and skip_mix_node:
        if node.inputs[1].links:
            node = node.inputs[1].links[0].from_node

    return node
