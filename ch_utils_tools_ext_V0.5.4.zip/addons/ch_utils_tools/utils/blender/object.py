"""
物体操作模块

提供物体评估, 原点设置, 子物体补偿等功能.

主要功能:
- get_evaluated_object: 获取单个物体的依赖图对象
- get_evaluated_objects: 获取多个物体的依赖图列表
- compensate_children: 补偿子物体的变换矩阵
- set_object_origin: 设置网格物体的原点位置和旋转
- set_object_parent: 设置物体的父级关系
- clear_object_parent: 移除物体的父级关系
"""

import bmesh
from mathutils import Matrix
from bpy.types import Context, Object
from bmesh.types import BMesh


def get_evaluated_object(context: Context, obj: Object) -> Object:
    """
    获取单个物体的依赖图对象(计算后的物体)

    Args:
        context: Blender上下文
        obj: 要获取依赖图的物体

    Returns:
        计算后的物体对象
    """
    depsgraph = context.evaluated_depsgraph_get()
    return obj.evaluated_get(depsgraph)


def get_evaluated_objects(context: Context, objs: list[Object]) -> list[Object]:
    """
    获取多个物体的依赖图列表

    Args:
        context: Blender上下文
        objs: 物体列表

    Returns:
        计算后的物体对象列表
    """
    depsgraph = context.evaluated_depsgraph_get()
    return [obj.evaluated_get(depsgraph) for obj in objs]


def compensate_children(obj: Object, old_mx: Matrix, new_mx: Matrix) -> None:
    """
    补偿子物体的变换矩阵

    在父物体的变换矩阵发生变化时(例如调整父物体的原点位置),
    调整子物体的父矩阵逆, 以确保子物体在世界空间中的位置, 旋转和缩放保持不变.

    Args:
        obj: 父物体
        old_mx: 旧变换矩阵
        new_mx: 新变换矩阵
    """
    delta_mx = new_mx.inverted_safe() @ old_mx
    for child in obj.children:
        child.matrix_parent_inverse = delta_mx @ child.matrix_parent_inverse


def set_object_origin(obj: Object, new_mx: Matrix, bm: BMesh = None) -> None:
    """
    设置网格物体的原点位置和旋转

    Args:
        obj: 需要调整原点的物体
        new_mx: 新的原点位置和旋转矩阵
        bm: BMesh对象(可选), 如果提供将对BMesh数据进行变换
            注意: 调用者需要负责释放bm
    """
    obj_mx = obj.matrix_world.copy()

    if obj.children:
        compensate_children(obj, obj_mx, new_mx)

    obj.matrix_world = new_mx

    delta_mx = new_mx.inverted_safe() @ obj_mx
    if bm:
        bmesh.ops.transform(bm, verts=bm.verts, matrix=delta_mx)
        bmesh.update_edit_mesh(obj.data)
    else:
        obj.data.transform(delta_mx)

    if obj.type == 'MESH':
        obj.data.update()


def set_object_parent(obj: Object, parent_obj: Object) -> None:
    """
    设置物体的父级关系

    Args:
        obj: 需要设置父级的子物体
        parent_obj: 父物体
    """
    if obj.parent:
        clear_object_parent(obj)

    if parent_obj:
        obj.parent = parent_obj
        obj.matrix_parent_inverse = parent_obj.matrix_world.inverted_safe()


def clear_object_parent(obj: Object) -> None:
    """
    移除物体的父级关系, 保持其在世界空间中的位置不变

    Args:
        obj: 需要移除父级关系的物体
    """
    if not obj.parent:
        return

    world_mx = obj.matrix_world.copy()
    obj.parent = None
    obj.matrix_world = world_mx
