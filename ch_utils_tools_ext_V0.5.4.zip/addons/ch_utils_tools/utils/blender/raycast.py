"""
射线检测模块

提供从点和鼠标位置发射射线检测场景物体的功能.

主要功能:
- RaycastCache: BVH射线检测缓存(缓存对象的BMesh与BVH树)
- raycast_from_point: 从给定点和方向发射射线检测
- raycast_from_mouse: 从鼠标位置发射射线检测
- raycast_scene: 场景级射线检测(scene.ray_cast 封装)
- get_hittable_objects: 获取场景中可被射线检测的对象列表
"""

import sys
import bpy
import bmesh
from bmesh.types import BMesh
from mathutils import Vector
from bpy.types import Object, Depsgraph
from mathutils.bvhtree import BVHTree as BVH
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d


class RaycastCache:
    """
    BVH射线检测缓存

    按对象名缓存BMesh与BVH树, 供 raycast_from_point 在模态操作中重复使用.
    网格数据变化后应调用 clear() 丢弃旧缓存.
    """

    def __init__(self) -> None:
        """初始化缓存"""
        self.bmeshes: dict[str, BMesh] = {}
        self.bvhs: dict[str, BVH] = {}

    def get_bmesh(self, obj: Object) -> BMesh:
        """
        获取对象的BMesh缓存, 不存在时构建

        Args:
            obj: 网格对象

        Returns:
            BMesh对象
        """
        bm = self.bmeshes.get(obj.name)
        if bm is None:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            self.bmeshes[obj.name] = bm
        return bm

    def get_bvh(self, obj: Object, bm: BMesh) -> BVH:
        """
        获取对象的BVH树缓存, 不存在时构建

        Args:
            obj: 网格对象
            bm: 对象的BMesh

        Returns:
            BVH树对象
        """
        bvh = self.bvhs.get(obj.name)
        if bvh is None:
            bvh = BVH.FromBMesh(bm)
            self.bvhs[obj.name] = bvh
        return bvh

    def clear(self) -> None:
        """释放所有缓存的BMesh并清空缓存"""
        for bm in self.bmeshes.values():
            bm.free()
        self.bmeshes.clear()
        self.bvhs.clear()


def raycast_from_point(origin: Vector, direction: Vector, cache: RaycastCache | None = None, candidates: list[Object] | None = None) -> tuple:
    """
    从给定点和方向发射射线, 检测candidates中所有mesh对象的最近交点

    Args:
        origin: 射线起点
        direction: 射线方向
        cache: BVH缓存对象, 为None时现场构建不缓存; 模态操作应复用同一缓存对象
        candidates: 待检测对象列表

    Returns:
        tuple: (命中对象, 命中位置, 法线, 三角索引, 距离)
               未命中时全部为None
    """
    cache = cache if cache is not None else RaycastCache()

    mesh_objects = [obj for obj in (candidates or []) if obj.type == "MESH"]
    best_hit = None
    min_distance = sys.maxsize

    for obj in mesh_objects:
        bm = cache.get_bmesh(obj)
        bvh = cache.get_bvh(obj, bm)

        location, normal, idx, _ = bvh.ray_cast(origin, direction)
        # location为None表示未命中; 命中距离可能为0(起点恰在表面), 不能用真值判断
        if location is not None:
            distance = (location - origin).length
            if distance < min_distance:
                best_hit = (obj, location, normal, idx, distance)
                min_distance = distance

    if best_hit:
        return best_hit
    return None, None, None, None, None


def raycast_from_mouse(mouse_pos: Vector, depsgraph: Depsgraph, exclude: list[Object] | None = None, exclude_wire: bool = False, temp_unhide: list[Object] | None = None, cache: dict | None = None, region=None) -> tuple:
    """
    从鼠标位置发射射线, 检测场景中最近的mesh命中

    Args:
        mouse_pos: 鼠标二维坐标
        depsgraph: 依赖图
        exclude: 排除对象列表
        exclude_wire: 是否排除线框显示对象
        temp_unhide: 临时显示的对象列表
        cache: 缓存字典, 用于存储hittable对象
        region: 指定区域(可选)

    Returns:
        tuple: (命中标志, 对象, 三角索引, 位置, 法线, 变换矩阵)
               未命中时全部为None
    """
    exclude = exclude or []
    temp_unhide = temp_unhide or []

    if region:
        region_data = region.data
    else:
        region = bpy.context.region
        region_data = bpy.context.region_data

    view_origin = region_2d_to_origin_3d(region, region_data, mouse_pos)
    view_dir = region_2d_to_vector_3d(region, region_data, mouse_pos)
    scene = bpy.context.scene

    # 记录temp_unhide的原始可见性, 结束后还原而非强制隐藏
    original_visibility = [(ob, ob.hide_get()) for ob in temp_unhide]
    for ob in temp_unhide:
        ob.hide_set(False)

    if cache and 'hittable_objects' in cache:
        hittable_objects = cache['hittable_objects']
    else:
        hittable_objects = get_hittable_objects(bpy.context, exclude=exclude, exclude_wire=exclude_wire)
        if cache is not None:
            cache['hittable_objects'] = hittable_objects

    hit, location, normal, idx, obj, mx = scene.ray_cast(depsgraph=depsgraph, origin=view_origin, direction=view_dir)
    hidden_objs = []

    while hit and (obj in exclude or (exclude_wire and obj.display_type == 'WIRE') or obj not in hittable_objects):
        obj.hide_set(True)
        hidden_objs.append(obj)
        hit, location, normal, idx, obj, mx = scene.ray_cast(depsgraph=depsgraph, origin=view_origin, direction=view_dir)

    for ob, was_hidden in original_visibility:
        ob.hide_set(was_hidden)
    for ob in hidden_objs:
        ob.hide_set(False)

    if hit:
        return hit, obj, idx, location, normal, mx
    return None, None, None, None, None, None


def raycast_scene(depsgraph: Depsgraph, origin: Vector, direction: Vector, distance: float = 1.70141e38) -> tuple:
    """
    场景级射线检测(scene.ray_cast 封装)

    Args:
        depsgraph: 依赖图
        origin: 射线起点
        direction: 射线方向
        distance: 最大检测距离

    Returns:
        tuple: (命中标志, 对象, 三角索引, 位置, 法线, 变换矩阵)
               未命中时命中标志为False, 其余为None
    """
    return bpy.context.scene.ray_cast(depsgraph=depsgraph, origin=origin, direction=direction, distance=distance)


def get_hittable_objects(context, exclude: list[Object] | None = None, exclude_wire: bool = False) -> set[Object]:
    """
    获取场景中可被射线检测的对象列表

    Args:
        context: Blender上下文
        exclude: 排除对象列表
        exclude_wire: 是否排除线框显示对象

    Returns:
        可被射线检测的对象集合
    """
    exclude = exclude or []

    hittable_objects = set(obj for obj in context.visible_objects if obj.display_type != 'BOUNDS' and obj.type in ['MESH', 'CURVE', 'FONT', 'SURFACE', 'META'])

    hittable_objects.difference_update(exclude)

    if exclude_wire:
        wire_objects = set(obj for obj in hittable_objects if obj.display_type == 'WIRE' and not obj.select_get())
        hittable_objects.difference_update(wire_objects)

    return hittable_objects
