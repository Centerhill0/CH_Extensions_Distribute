"""
曲线工具模块

提供曲线数据提取, 验证和样条创建功能.

主要功能:
- CurveData / SplineData / SplinePoint: 曲线载荷数据类
- get_curve_data: 提取曲线数据为CurveData结构
- has_active_spline / has_active_selection: 活动样条与选中点查询
- is_active_end_selected / is_active_selection_continuous: 选择状态验证
- get_curve_selection_indices: 获取曲线中所有选中点的索引集合
- create_spline_from_data: 根据SplineData创建新的样条
- update_selection_history: 更新曲线选择历史记录
"""

from dataclasses import dataclass, field
from mathutils import Vector
from bpy.types import Curve, Spline
from ..math.geometry import get_average_position


@dataclass
class SplinePoint:
    """
    样条点数据

    存储单个曲线点的所有属性, 与 Blender SplinePoint 对应.
    is_gap/is_intersect/keep/line/is_redundant/is_first 为对称化等算法的
    载荷字段(非 Blender 原生属性), 默认值保持中性.
    """

    co: Vector  # 点坐标
    index: int = -1  # 点在样条中的索引
    hide: bool = False  # 是否隐藏
    radius: float = 1.0  # 点半径
    select: bool = False  # 点是否选中
    tilt: float = 0.0  # 点倾斜角度
    weight: float = 1.0  # 点权重(NURBS专用)
    handle_left: Vector | None = None  # 左手柄坐标(贝塞尔曲线专用)
    handle_right: Vector | None = None  # 右手柄坐标(贝塞尔曲线专用)
    is_gap: bool = False  # 是否为循环样条的首尾缺口点(对称化算法)
    is_intersect: bool = False  # 是否为镜像平面交点(对称化算法)
    keep: bool = True  # 对称化时是否保留(对称化算法)
    line: list | None = None  # 原始点与镜像点的连线[原坐标, 镜像坐标](对称化算法)
    is_redundant: bool = False  # 是否为冗余共线点(对称化算法)
    is_first: bool = False  # 是否为循环重排的起始点(对称化算法)
    is_split: bool = False  # 是否为切割产生的分割点(曲线切割算法)


@dataclass
class SplineData:
    """
    样条数据

    存储单个样条的所有属性和点数据, 与 Blender Spline 对应.
    """

    spline_type: str = "POLY"  # 样条类型, ['POLY', 'BEZIER', 'NURBS']
    points: list["SplinePoint"] = field(default_factory=list)  # 样条点列表
    active: bool = False  # 是否活动样条
    is_cyclic: bool = False  # 是否循环样条
    smooth: bool = False  # 是否平滑样条
    endpoint: bool = False  # 是否使用端点样条(NURBS专用)
    order: int = 4  # 样条阶数(NURBS专用)
    resolution: int = 12  # 样条分辨率


@dataclass
class CurveData:
    """
    曲线数据

    存储整条曲线的完整数据, 包括所有样条, 活动样条和选择信息, 与 Blender Curve 对应.
    """

    splines: list["SplineData"] = field(default_factory=list)  # 所有样条数据列表
    active: SplineData | None = None  # 活动样条线
    active_selection: list["SplinePoint"] = field(default_factory=list)  # 活动样条中选中的点列表
    active_selection_mid_point: Vector | None = None  # 选中点的中心位置


def get_curve_data(curve: Curve, include_selection: bool = True) -> CurveData:
    """
    提取曲线数据为CurveData结构

    将曲线的所有样条和点数据提取为CurveData格式
    包含活动样条, 选中点及其中心位置等信息.

    Args:
        curve: Blender曲线数据对象
        include_selection: 是否包含选择状态信息, 默认True

    Returns:
        CurveData对象, 包含以下属性:
        - splines: 所有样条数据列表
        - active: 活动样条数据(仅当include_selection为True)
        - active_selection: 活动样条中选中的点列表(仅当include_selection为True)
        - active_selection_mid_point: 选中点的中心位置(仅当有选中点时)
    """
    data = CurveData()

    for spline in curve.splines:
        is_active = spline == curve.splines.active

        # 提取样条属性
        spline_data = SplineData(
            spline_type=spline.type,
            smooth=spline.use_smooth,
            is_cyclic=spline.use_cyclic_u,
            endpoint=spline.use_endpoint_u,
            order=spline.order_u,
            resolution=spline.resolution_u,
        )

        if include_selection:
            spline_data.active = is_active

            if is_active:
                data.active = spline_data

        # 提取点数据
        for point_idx, point in enumerate(spline.points):
            point_data = SplinePoint(
                co=point.co.copy(),
                index=point_idx,
                radius=point.radius,
                tilt=point.tilt,
                hide=point.hide,
            )

            if include_selection:
                point_data.select = point.select

            spline_data.points.append(point_data)

            if include_selection and is_active and point.select:
                data.active_selection.append(point_data)

        if include_selection and data.active_selection:
            data.active_selection_mid_point = get_average_position([pt.co.xyz for pt in data.active_selection])

        data.splines.append(spline_data)

    return data


def has_active_spline(data: CurveData) -> SplineData | None:
    """
    获取曲线数据中的活动样条

    Args:
        data: 由get_curve_data返回的CurveData对象

    Returns:
        活动样条数据, 不存在时返回None
    """
    return data.active


def has_active_selection(data: CurveData) -> list:
    """
    获取活动样条中的选中点列表

    Args:
        data: CurveData对象

    Returns:
        选中点列表, 可能为空列表
    """
    return data.active_selection


def is_active_end_selected(data: CurveData) -> bool:
    """
    验证活动样条的端点是否被选中

    Args:
        data: CurveData对象

    Returns:
        首个或末个点被选中返回True; 无活动样条返回False
    """
    active = has_active_spline(data)
    if not active:
        return False

    first, last = active.points[0], active.points[-1]
    return first.select or last.select


def is_active_selection_continuous(data: CurveData) -> bool:
    """
    验证活动样条中的选中点是否连续

    Args:
        data: CurveData对象

    Returns:
        选中点索引连续返回True; 无选中点或无活动样条返回False
    """
    selection = has_active_selection(data)
    active = has_active_spline(data)
    if not selection or not active:
        return False

    points = active.points
    indices = [points.index(pt) for pt in selection]
    return all(indices[i] == indices[i - 1] + 1 for i in range(1, len(indices)))


def get_curve_selection_indices(data: CurveData) -> set[tuple[int, int]]:
    """
    获取曲线中所有选中点的索引集合

    Args:
        data: 由get_curve_data返回的CurveData对象

    Returns:
        选中点索引集合,每个元素为(样条索引, 点索引)元组
    """
    selection = set()

    for spline_idx, spline in enumerate(data.splines):
        for point_idx, point in enumerate(spline.points):
            if point.select:
                selection.add((spline_idx, point_idx))

    return selection


def create_spline_from_data(curve: Curve, spline_data: SplineData, custom_points: list[SplinePoint] | None = None) -> Spline:
    """
    根据SplineData创建新的样条

    Args:
        curve: 目标曲线对象
        spline_data: SplineData对象,包含类型,属性和点数据
        custom_points: 自定义SplinePoint列表,如果提供则使用此列表替代spline_data中的点

    Returns:
        新创建的样条对象
    """
    new_spline = curve.splines.new(spline_data.spline_type)
    points = custom_points if custom_points else spline_data.points

    # 设置为活动样条
    if spline_data.active:
        curve.splines.active = new_spline

    # 添加点(Blender 默认创建1个点,需要添加剩余点)
    new_spline.points.add(len(points) - 1)

    # 设置点属性
    for point, point_data in zip(new_spline.points, points):
        point.co = point_data.co
        point.radius = point_data.radius
        point.tilt = point_data.tilt
        point.select = point_data.select
        point.hide = point_data.hide

    new_spline.use_cyclic_u = spline_data.is_cyclic
    new_spline.use_smooth = spline_data.smooth

    if spline_data.spline_type == 'NURBS':
        new_spline.use_endpoint_u = spline_data.endpoint
        new_spline.order_u = spline_data.order
        new_spline.resolution_u = spline_data.resolution

    return new_spline


def update_selection_history(data: CurveData) -> list[tuple[int, int]]:
    """
    更新曲线选择历史记录

    根据当前选择状态更新选择历史, 用于追踪最后选择的点.
    使用函数属性存储状态, 可以在多次调用间保持历史记录.

    Args:
        data: 由get_curve_data返回的CurveData对象

    Returns:
        当前的选择历史列表
    """
    if not hasattr(update_selection_history, '_history'):
        update_selection_history._history: list[tuple[int, int]] = []
        update_selection_history._previous: set[tuple[int, int]] = set()

    selection = get_curve_selection_indices(data)
    symdiff = selection.symmetric_difference(update_selection_history._previous)

    if symdiff:
        if len(symdiff) == 1:
            change = symdiff.pop()

            if change in selection:
                # 新选中的点, 添加到历史
                update_selection_history._history.append(change)
            else:
                # 取消选中的点, 从历史中移除
                if change in update_selection_history._history:
                    update_selection_history._history.remove(change)
                else:
                    # 历史中没有这个点, 清空历史
                    update_selection_history._history = []
        else:
            update_selection_history._history = []

    if not update_selection_history._history and len(selection) == 1:
        update_selection_history._history = list(selection)

    update_selection_history._previous = selection

    return update_selection_history._history
