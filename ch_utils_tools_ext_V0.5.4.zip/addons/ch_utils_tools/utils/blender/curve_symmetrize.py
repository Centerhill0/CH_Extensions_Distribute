"""
曲线对称化算法模块

提供样条数据的镜像对称化纯算法: 镜像平面求解, 交点计算, 点分类,
简单/复杂镜像与冗余点标记.
不接触 Blender 数据, 输入输出均为 CurveData 域的 SplineData/SplinePoint 载荷.

主要功能:
- get_mirror_plane: 由滑动方向法线与物体/游标矩阵求镜像平面
- compute_symmetrized_splines: 对称化主入口
"""

from copy import copy
from math import degrees

from mathutils import Matrix, Vector
from mathutils.geometry import intersect_line_plane

from ..infrastructure.data import rotate_list
from .curve import SplineData, SplinePoint


def get_mirror_plane(base_normal: Vector | None, is_cursor: bool, mx: Matrix, cmx: Matrix) -> tuple[Vector, Vector | None, Vector]:
    """
    获取镜像平面数据(物体局部空间)

    Args:
        base_normal: 滑动方向对应的物体空间法线, 未选方向时为None
        is_cursor: 是否使用游标空间作为镜像基准
        mx: 物体世界矩阵
        cmx: 游标世界矩阵

    Returns:
        (平面点, 平面法线, 平面偏移) 元组
    """
    loc = Vector()
    offset = Vector()

    if is_cursor and base_normal:
        loc = mx.inverted_safe() @ cmx @ loc
        normal = mx.to_3x3().inverted_safe() @ (cmx.to_quaternion() @ base_normal)
        i = intersect_line_plane(Vector(), normal, loc, normal)
        if i:
            offset = i * 2
    else:
        normal = base_normal

    return loc, normal, offset


def compute_symmetrized_splines(spline_data: SplineData, loc: Vector, normal: Vector, offset: Vector) -> dict:
    """
    对称化样条数据主入口

    根据活动样条与镜像平面, 计算对称化后的样条列表.
    直接修改传入样条点的载荷字段(is_gap/keep/is_intersect等).

    Args:
        spline_data: 活动样条数据(get_curve_data 返回)
        loc: 镜像平面上的点(物体局部空间)
        normal: 镜像平面法线
        offset: 平面偏移

    Returns:
        {'type': 'INVALID'|'COMPLEX'|'EASY',
         'mirrored_splines': list[SplineData],
         'has_redundant': bool} 字典
    """
    is_cyclic = spline_data.is_cyclic
    points = spline_data.points

    for idx, point in enumerate(points):
        point.is_gap = is_cyclic and (idx == 0 or idx == len(points) - 1)

    intersected_points = _compute_intersections(points, loc, normal, is_cyclic)
    _classify_points(intersected_points, loc, normal)

    if not any(p.keep for p in intersected_points):
        return {'type': 'INVALID', 'mirrored_splines': [], 'has_redundant': False}

    if any(p.is_intersect or not p.keep for p in intersected_points):
        mirrored = _get_complex_mirror_data(normal, offset, spline_data, intersected_points)
        has_redundant = _mark_redundant_points(mirrored)
        return {'type': 'COMPLEX', 'mirrored_splines': mirrored, 'has_redundant': has_redundant}

    return {'type': 'EASY', 'mirrored_splines': _get_easy_mirror_data(normal, offset, spline_data, intersected_points), 'has_redundant': False}


def _compute_intersections(points: list[SplinePoint], loc: Vector, normal: Vector, is_cyclic: bool) -> list[SplinePoint]:
    """计算样条段与镜像平面的交点, 返回插入交点后的点列"""

    def get_next_point(idx):
        if is_cyclic:
            return copy(points[(idx + 1) % len(points)])
        elif idx < len(points) - 1:
            return copy(points[idx + 1])

    intersected = []
    pidx = 0

    for point in points:
        dup = copy(point)
        dup.index = pidx
        dup.is_intersect = point.is_intersect
        intersected.append(dup)

        next_point = get_next_point(point.index)

        if next_point and not dup.is_intersect:
            i = intersect_line_plane(point.co.xyz, next_point.co.xyz, loc, normal)

            if i:
                cur_dist = (i - point.co.xyz).length

                if round(cur_dist, 6) == 0:
                    dup.is_intersect = True
                    pidx += 1
                    continue

                direction = next_point.co.xyz - point.co.xyz
                i_dir = i - point.co.xyz

                if direction.normalized().dot(i_dir.normalized()) > 0.99 and i_dir.length < direction.length:
                    pidx += 1
                    is_inbetween_gap = point.is_gap and next_point.is_gap
                    if is_inbetween_gap:
                        intersected[-1].is_gap = False

                    intersect_point = SplinePoint(
                        co=Vector((*i, 1.0)),
                        index=pidx,
                        radius=(point.radius + next_point.radius) / 2,
                        tilt=(point.tilt + next_point.tilt) / 2,
                        hide=False,
                        select=False,
                    )
                    intersect_point.is_gap = is_inbetween_gap
                    intersect_point.is_intersect = True
                    intersected.append(intersect_point)

        pidx += 1

    return intersected


def _classify_points(points: list[SplinePoint], loc: Vector, normal: Vector):
    """分类点(保留/移除)"""
    for point in points:
        if point.is_intersect:
            point.keep = True
        else:
            i = intersect_line_plane(point.co.xyz, point.co.xyz + normal, loc, normal)
            side_dir = i - point.co.xyz
            dot = side_dir.normalized().dot(normal)
            point.keep = dot >= 0
            if dot == 0:
                point.is_intersect = True


def _get_easy_mirror_data(mirror_normal: Vector, mirror_offset: Vector, spline_data: SplineData, points: list[SplinePoint]) -> list[SplineData]:
    """获取简单镜像数据(整条样条镜像)"""
    mirrored_points = []
    for p in points:
        original_co = p.co.xyz
        mirror_co = original_co.reflect(mirror_normal) + mirror_offset
        mirrored_point = SplinePoint(
            co=Vector((*mirror_co, 1.0)),
            index=p.index,
            radius=p.radius,
            tilt=-p.tilt,
            hide=False,
            select=False,
        )
        mirrored_point.line = [original_co, mirror_co]
        mirrored_points.append(mirrored_point)

    mirrored_data = copy(spline_data)
    mirrored_data.points = mirrored_points

    return [mirrored_data]


def _get_complex_mirror_data(mirror_normal: Vector, mirror_offset: Vector, spline_data: SplineData, points: list[SplinePoint]) -> list[SplineData]:
    """获取复杂镜像数据(按交点拆分为多段)"""
    if spline_data.is_cyclic and sum(1 for p in points if p.is_gap and p.keep) == 2:
        remove_indices = [idx for idx, p in enumerate(points) if not p.keep and not p.is_gap]
        if remove_indices:
            points[0].is_first = True
            rotate_list(points, amount=remove_indices[0])

    new_spline_points = []
    start_new_spline = False

    for point in points:
        if not point.keep:
            continue
        if not new_spline_points or point.is_intersect:
            start_new_spline = not start_new_spline
            if start_new_spline:
                new_spline_points.append([])
        new_spline_points[-1].append(point)

    mirrored = []

    for keep_points in new_spline_points:
        data = copy(spline_data)
        data.points = []
        data.is_cyclic = len(keep_points) > 2 and keep_points[0].is_intersect and keep_points[-1].is_intersect

        if keep_points[-1].is_intersect:
            _collect_original_points(keep_points, data)
            _create_mirrored_points(keep_points, data, mirror_normal, mirror_offset)
        else:
            _create_mirrored_points(keep_points, data, mirror_normal, mirror_offset)
            _collect_original_points(keep_points, data)

        mirrored.append(data)

    for mirror_data in mirrored:
        if first := [p for p in mirror_data.points if p.is_first]:
            if amount := first[0].index:
                rotate_list(mirror_data.points, amount=amount)

    return mirrored


def _collect_original_points(keep_points: list[SplinePoint], data: SplineData):
    """收集原始点"""
    for idx, point in enumerate(keep_points):
        data.points.append(point)
        data.points[-1].index = idx


def _create_mirrored_points(keep_points: list[SplinePoint], data: SplineData, mirror_normal: Vector, mirror_offset: Vector):
    """创建镜像点"""
    idx = len(data.points)
    for point in reversed(keep_points):
        if not point.is_intersect:
            mirror_co = point.co.xyz.reflect(mirror_normal) + mirror_offset
            mirrored_point = SplinePoint(
                co=Vector((*mirror_co, 1.0)),
                index=idx,
                radius=point.radius,
                tilt=point.tilt,
                hide=False,
                select=False,
            )
            mirrored_point.line = [point.co.xyz, mirror_co]
            data.points.append(mirrored_point)
            idx += 1


def _mark_redundant_points(mirrored: list[SplineData]) -> bool:
    """标记冗余共线点, 返回是否存在冗余点"""

    def get_adjacent_point(idx, points, cyclic, offset):
        if cyclic:
            return points[(idx + offset) % len(points)]
        new_idx = idx + offset
        return points[new_idx] if 0 <= new_idx < len(points) else None

    for spline_data in mirrored:
        points = spline_data.points
        for idx, point in enumerate(points):
            if not point.is_intersect:
                continue

            prev_point = get_adjacent_point(idx, points, spline_data.is_cyclic, -1)
            next_point = get_adjacent_point(idx, points, spline_data.is_cyclic, 1)

            if prev_point and next_point:
                prev_dir = (prev_point.co.xyz - point.co.xyz).normalized()
                next_dir = (next_point.co.xyz - point.co.xyz).normalized()
                if round(degrees(prev_dir.angle(next_dir)), 2) == 180:
                    point.is_redundant = True

    return any(p.is_redundant for data in mirrored for p in data.points)
