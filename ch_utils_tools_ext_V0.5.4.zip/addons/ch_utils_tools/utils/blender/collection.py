"""
集合工具模块

提供集合的获取, 创建和管理功能.

主要功能:
- get_collection: 获取或创建集合
"""

import bpy
from bpy.types import Context, Collection


def get_collection(context: Context, name: str, color_tag: str = 'COLOR_01', is_create: bool = True, is_hide_render: bool = True) -> Collection | None:
    """
    获取或创建集合

    Args:
        context: Blender上下文
        name: 集合名称
        color_tag: 集合颜色标签
        is_create: 集合不存在时是否创建
        is_hide_render: 是否禁用渲染

    Returns:
        集合对象, 如果不存在且不创建则返回None
    """
    for layer_col in context.view_layer.layer_collection.children:
        if layer_col.name == name:
            col = layer_col.collection
            break
    else:
        col = None

    if col is None:
        if not is_create:
            return None

        col = bpy.data.collections.new(name)
        col.color_tag = color_tag
        context.scene.collection.children.link(col)

    if is_hide_render:
        col.hide_render = True

    return col
