"""
顶点组操作模块

提供顶点组的创建, 存储和获取功能.

主要功能:
- add_vgroup: 创建或获取顶点组并添加顶点
"""

import bpy
from bpy.types import Object, VertexGroup


def add_vgroup(obj: Object, name: str = "", verts_idx: list[int] | None = None, weight: float = 1.0) -> VertexGroup:
    """
    创建或获取顶点组, 并将指定顶点加入其中

    Args:
        obj: 网格物体
        name: 顶点组名称, 已存在同名组时复用
        verts_idx: 顶点索引列表, 为None或空时不添加顶点
        weight: 顶点权重

    Returns:
        顶点组
    """
    vgroups = obj.vertex_groups
    vgroup = vgroups.get(name) if name else None
    if vgroup is None:
        vgroup = vgroups.new(name=name)

    if verts_idx:
        _add_verts(obj, vgroup, verts_idx, weight)

    return vgroup


def _add_verts(obj: Object, vgroup: VertexGroup, verts_idx: list[int], weight: float) -> None:
    """
    将顶点加入顶点组

    VertexGroup.add() 禁止在编辑模式下调用, 此时临时切换物体模式写入后切回.
    编辑模式下的 bmesh deform 层写入不可靠(覆盖已有权重与部分新键会被静默丢弃),
    故不使用该途径.
    统一使用 REPLACE 模式: 传入的 weight 即为顶点最终权重, ADD 模式对已在组内的
    顶点不生效(仅新增顶点), 会使显式传入的权重失效.

    Args:
        obj: 网格物体
        vgroup: 顶点组
        verts_idx: 顶点索引列表
        weight: 顶点权重
    """
    if obj.mode != 'EDIT':
        vgroup.add(verts_idx, weight, "REPLACE")
        return

    active_obj = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = obj

    bpy.ops.object.mode_set(mode='OBJECT')
    vgroup.add(verts_idx, weight, "REPLACE")
    bpy.ops.object.mode_set(mode='EDIT')

    bpy.context.view_layer.objects.active = active_obj
