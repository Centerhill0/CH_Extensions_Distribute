"""
物体测量模块

提供物体边界框测量功能.

主要功能:
- MeasureObject: 测量单个物体的属性
- MeasureObjects: 测量多个物体的属性
- measure_objects_evaluated: 一步式构建世界坐标测量的工厂函数
"""

import numpy as np
from mathutils import Vector, Matrix
from bpy.types import Context, Object

from ..blender.object import get_evaluated_objects
from ..mesh.bmesh_utils import get_mesh
from ..math.transform import apply_matrix_to_points
from .._constants import BBOX_TYPE_VERTICES, BBOX_TYPE_LATTICE, BBOX_TYPE_CURVE, BBOX_TYPE_BOUNDS
from .base import BaseMeasure, BaseMeasures


class MeasureObject(BaseMeasure):
    """
    测量单个物体的属性
    Args:
        obj: 要测量的物体
        mx: 自定义变换矩阵, 默认为None(局部坐标系); 需要世界坐标时显式传入 obj.matrix_world
    """

    def __str__(self) -> str:
        return f"Measure({self.name}, dims={self.dims}, location={self.location})"

    def __init__(self, obj: Object, mx: Matrix = None):
        self._object = obj
        self._matrix = mx.copy() if mx else None

        self.name = obj.name
        self.location = obj.location
        self.min_pos, self.max_pos = self._get_bound_box()

    def _get_bound_box(self) -> tuple[Vector, Vector]:
        """计算物体经过变换矩阵后的边界框"""

        if self._object.type in BBOX_TYPE_VERTICES:
            mesh = get_mesh(self._object)
            verts = mesh.vertices
            np_co = np.empty(len(verts) * 3, dtype=np.float32)
            verts.foreach_get("co", np_co)
            np_co_array = np_co.reshape(-1, 3)

        elif self._object.type in BBOX_TYPE_LATTICE:
            points = self._object.data.points
            np_co = np.zeros(len(points) * 3, dtype=np.float32)
            points.foreach_get("co_deform", np_co)
            np_co_array = np_co.reshape(-1, 3)

        elif self._object.type in BBOX_TYPE_CURVE:
            curve_points = []
            for spline in self._object.data.splines:
                src = spline.bezier_points if spline.type == 'BEZIER' else spline.points
                curve_points.extend(p.co[:3] for p in src)
            np_co_array = np.array(curve_points, dtype=np.float32)

        elif self._object.type in BBOX_TYPE_BOUNDS:
            np_co_array = np.array(self._object.bound_box, dtype=np.float32)

        else:
            np_co_array = np.array(((0, 0, 0), (0, 0, 0)))

        if self._matrix:
            np_co_array = apply_matrix_to_points(np_co_array, self._matrix)

        return Vector(np.min(np_co_array, axis=0)), Vector(np.max(np_co_array, axis=0))

    @property
    def bottom_center_pos(self) -> Vector:
        """物体边界盒底部中心点"""
        return Vector(((self.min_pos.x + self.max_pos.x) / 2, (self.min_pos.y + self.max_pos.y) / 2, self.min_pos.z))

    @property
    def top_center_pos(self) -> Vector:
        """物体边界盒顶部中心点"""
        return Vector(((self.min_pos.x + self.max_pos.x) / 2, (self.min_pos.y + self.max_pos.y) / 2, self.max_pos.z))


class MeasureObjects(BaseMeasures):
    """
    测量多个物体的属性
    Args:
        objects: 要测量的物体列表
        matrices: 自定义变换矩阵,可以是单个矩阵或矩阵列表
    """

    def __str__(self) -> str:
        return f"Measures(count={len(self.original_measures)}, dims={self.dims})"

    def __init__(self, objects: list[Object], matrices: Matrix | list[Matrix] = None):
        if matrices is None:
            self.original_measures = [MeasureObject(obj) for obj in objects]
        elif isinstance(matrices, Matrix):
            self.original_measures = [MeasureObject(obj, matrices) for obj in objects]
        else:
            self.original_measures = [MeasureObject(obj, mx) for obj, mx in zip(objects, matrices)]

        super().__init__(self.original_measures)

        self.sorted_measures: list[MeasureObject] = self.original_measures.copy()
        self.sorted_axis: int = -1

    def __iter__(self):
        return iter(self.original_measures)

    @property
    def sum_dims(self) -> Vector:
        """所有物体尺寸之和"""
        return sum((m.dims for m in self.original_measures), Vector())

    @property
    def offset_by_clearance(self) -> Vector:
        """分布模式每个物体的净距"""
        if len(self.original_measures) < 2:
            return Vector()
        return (self.dims - self.sum_dims) / (len(self.original_measures) - 1)

    def get_offset_by_origin(self, is_sorted: bool = False) -> Vector:
        """
        分布模式每个物体的中心间距
        Args:
            is_sorted: 是否使用排序后的列表
        Returns:
            中心间距向量
        """
        measures = self.sorted_measures if is_sorted else self.original_measures
        if len(measures) < 2:
            return Vector()
        return (measures[-1].location - measures[0].location) / (len(measures) - 1)

    def sorted_by_axis(self, axis: int) -> list[MeasureObject]:
        """
        按指定轴对物体列表进行排序
        Args:
            axis: 排序轴向(0=X, 1=Y, 2=Z)
        Returns:
            排序后的MeasureObject列表
        """
        self.sorted_measures = sorted(self.original_measures, key=lambda m: m.center_pos[axis])
        self.sorted_axis = axis
        return self.sorted_measures


def measure_objects_evaluated(context: Context, objs: list[Object], matrices: Matrix | list[Matrix] | None = None) -> tuple[MeasureObjects, list[Object]]:
    """
    一步式构建世界坐标系的物体测量(最常用调用路径的工厂函数)

    完成 view_layer更新 -> 获取依赖图评估对象 -> 以各自matrix_world构建
    MeasureObjects 的固定搭配; matrices 显式提供时覆盖默认的世界矩阵.

    Args:
        context: Blender上下文
        objs: 原始物体列表
        matrices: 自定义矩阵, 单个矩阵或与objs等长的列表; None时逐对象取matrix_world

    Returns:
        (MeasureObjects, 原始物体列表) 元组;
        原始物体按名从场景回取, 写回变换时应使用它们, 评估对象仅用于几何查询
    """
    context.view_layer.update()
    dep_objs = get_evaluated_objects(context, objs)
    if matrices is None:
        matrices = [obj.matrix_world for obj in dep_objs]
    measures = MeasureObjects(dep_objs, matrices)
    original_objs = [context.scene.objects[obj.name] for obj in dep_objs]
    return measures, original_objs
