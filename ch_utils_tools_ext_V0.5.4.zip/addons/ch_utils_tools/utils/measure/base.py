"""
测量系统基类模块

提取 MeasureObject / MeasureIsland / MeasureNode 三个模块的公共接口, 减少代码重复.

主要功能:
- BaseMeasure: 单个元素测量基类
- BaseMeasures: 多个元素测量集合基类
"""

import numpy as np
from mathutils import Vector


class BaseMeasure:
    """单个元素测量基类"""

    min_pos: Vector
    max_pos: Vector

    @property
    def dims(self) -> Vector:
        return self.max_pos - self.min_pos

    @property
    def center_pos(self) -> Vector:
        return (self.min_pos + self.max_pos) / 2


class BaseMeasures:
    """多个元素测量集合基类"""

    def __init__(self, measures: list[BaseMeasure]):
        self.measures: list[BaseMeasure] = measures
        self._points = [p for m in self.measures for p in (m.min_pos, m.max_pos)]

    @property
    def min_pos(self) -> Vector:
        return Vector(np.min(self._points, axis=0))

    @property
    def max_pos(self) -> Vector:
        return Vector(np.max(self._points, axis=0))

    @property
    def dims(self) -> Vector:
        return self.max_pos - self.min_pos

    @property
    def center_pos(self) -> Vector:
        return (self.min_pos + self.max_pos) / 2
