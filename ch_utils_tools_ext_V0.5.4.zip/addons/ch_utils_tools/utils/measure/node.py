"""
节点测量工具模块

提供节点坐标的测量功能, 用于节点对齐和分布操作.

坐标系说明:
- 画布坐标: XY标准坐标系, 每格20个单位(非像素单位, 不受界面缩放值影响)
- 节点位置(location): 基准点(0,0)在左上角, 位置基于画布坐标
- 节点尺寸(dimensions): 单位像素(受界面缩放值影响)
- 坐标转换: δ(loc_x) = dim / (system.dpi/72)

主要功能:
- MeasureNode: 测量单个节点的几何信息
- MeasureNodes: 测量多个节点的几何信息集合
"""

import bpy
from bpy.types import Node
from mathutils import Vector


class MeasureNode:
    """
    测量单个节点的几何信息

    Args:
        node: 要测量的节点对象

    Attributes:
        name: 节点名称
        location: 节点位置 Vector((X, Y)),单位为画布坐标
        width: 节点宽度(画布坐标单位)
        height: 节点高度(画布坐标单位)
        parent: 父节点(Frame节点),无父节点时为None
        is_frame: 是否为Frame节点
    """

    def __init__(self, node: Node):
        self._node = node
        self._scale = None

    def __str__(self) -> str:
        return f"MeasureNode({self.name}, loc={self.location})"

    @property
    def name(self) -> str:
        return self._node.name

    @property
    def location(self) -> Vector:
        return self._node.location

    @property
    def width(self) -> float:
        return self._node.dimensions.x / self._get_scale()

    @property
    def height(self) -> float:
        return self._node.dimensions.y / self._get_scale()

    @property
    def parent(self) -> Node | None:
        return self._node.parent

    @property
    def is_frame(self) -> bool:
        return self._node.type == "FRAME"

    def _get_scale(self) -> float:
        if self._scale is None:
            self._scale = bpy.context.preferences.system.dpi / 72
        return self._scale


class MeasureNodes:
    """
    测量多个节点的几何信息集合

    提供节点分组,排序,边界计算等功能.

    Args:
        nodes: 要测量的节点列表

    Attributes:
        measure_nodes: MeasureNode对象列表
    """

    def __init__(self, nodes: list[Node]):
        self.measure_nodes = [MeasureNode(node) for node in nodes]
        self._grouped_cache = None
        self._sorted_x_cache = None
        self._sorted_y_cache = None

    def __str__(self) -> str:
        return f"MeasureNodes(count={len(self.measure_nodes)})"

    @property
    def grouped_by_frame(self) -> dict[str, list[MeasureNode]]:
        """将节点按父框架分组,键为框架名称,值为该框架下的节点列表,未指定父框架的节点将分组为"ch" """
        if self._grouped_cache is None:
            grouped = {}
            for node in self.measure_nodes:
                if node.is_frame:
                    continue
                key = node.parent.name if node.parent else "ch"
                grouped.setdefault(key, []).append(node)
            self._grouped_cache = grouped
        return self._grouped_cache

    @property
    def sorted_by_x(self) -> dict[str, list[MeasureNode]]:
        """将节点按父框架分组,键为框架名称,值为该框架下的节点列表,按X坐标排序"""
        if self._sorted_x_cache is None:
            self._sorted_x_cache = {key: sorted(nodes, key=lambda n: n.location.x) for key, nodes in self.grouped_by_frame.items()}
        return self._sorted_x_cache

    @property
    def sorted_by_y(self) -> dict[str, list[MeasureNode]]:
        """将节点按父框架分组,键为框架名称,值为该框架下的节点列表,按Y坐标排序"""
        if self._sorted_y_cache is None:
            self._sorted_y_cache = {key: sorted(nodes, key=lambda n: n.location.y) for key, nodes in self.grouped_by_frame.items()}
        return self._sorted_y_cache

    def get_align_position(self, frame_key: str, align_type: str) -> float:
        """获取指定Frame内节点的对齐边界位置"""
        match align_type:
            case "Align_Left":
                return self.sorted_by_x[frame_key][0].location.x
            case "Align_Right":
                return self.sorted_by_x[frame_key][-1].location.x
            case "Align_Up":
                return self.sorted_by_y[frame_key][-1].location.y
            case "Align_Down":
                return self.sorted_by_y[frame_key][0].location.y
            case _:
                return 0.0
