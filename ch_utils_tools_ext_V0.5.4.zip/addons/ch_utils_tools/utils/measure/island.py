"""
孤岛测量模块

提供选中顶点孤岛的测量功能.

主要功能:
- MeasureIsland: 测量单个孤岛的属性
- MeasureIslands: 测量物体所有孤岛属性
"""

from bpy.types import Object
from mathutils import Matrix
from bmesh.types import BMesh

from ..mesh.bmesh_utils import get_selected_vert_bound_box, get_bmesh
from ..mesh.topology import get_selected_vert_islands
from .base import BaseMeasure, BaseMeasures


class MeasureIsland(BaseMeasure):
    """
    测量单个孤岛的属性
    Args:
        obj: 要测量的物体
        island_idx: 孤岛编号
        selected_vertices_idx: 孤岛内的顶点编号集合
        mx: 变换矩阵,默认为None(局部坐标系)
        bm: 复用的BMesh对象,传入时避免重复构建; 未传入时自行构建且自行管理释放
    """

    def __str__(self) -> str:
        return f"Measure({self.island_idx}, dims={self.dims}, count={len(self.selected_vertices_idx)})"

    def __init__(self, obj: Object, island_idx: int, selected_vertices_idx: set[int], mx: Matrix = None, bm: BMesh | None = None):
        self._object = obj
        self._matrix = mx.copy() if mx else None
        self.island_idx = island_idx
        self.selected_vertices_idx = list(selected_vertices_idx)

        if bm is None:
            bm = get_bmesh(self._object)
        bound_box = get_selected_vert_bound_box(bm, self.selected_vertices_idx, self._matrix)
        self.min_pos = bound_box[0]
        self.max_pos = bound_box[1]


class MeasureIslands(BaseMeasures):
    """
    测量物体所有孤岛属性
    Args:
        obj: 要测量的物体
        mx: 变换矩阵,默认为None(局部坐标系)
    """

    def __str__(self) -> str:
        return f"Measures(dims={self.dims}, count={len(self.islands)})"

    def __iter__(self):
        return iter(self.islands)

    def __init__(self, obj: Object, mx: Matrix = None):
        self._object = obj
        self._matrix = mx.copy() if mx else None
        self.islands = []
        self.selected_vertices_idx = []

        self._collect_islands()
        super().__init__(self.islands)  # 初始化父类

    def _collect_islands(self):
        """收集所有孤岛并创建 MeasureIsland 对象"""
        bm = get_bmesh(self._object)
        island_data = get_selected_vert_islands(bm)

        for island_idx, verts_idx_set in island_data.items():
            if not verts_idx_set:
                continue
            island = MeasureIsland(self._object, island_idx, verts_idx_set, self._matrix, bm=bm)
            self.islands.append(island)
            self.selected_vertices_idx.extend(verts_idx_set)

        # 物体模式下get_bmesh返回独立构建的BMesh, 收集完成后释放
        if not self._object.data.is_editmode:
            bm.free()
