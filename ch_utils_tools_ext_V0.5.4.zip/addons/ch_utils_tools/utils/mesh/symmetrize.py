"""
网格对称化算法模块

提供编辑模式网格对称化的核心算法: 顶点三侧分类, 镜像顶点/面/循环映射,
自定义法线镜像, UV偏移与顶点组清理等.

主要功能:
- symmetrize: 对网格执行对称化操作, 返回结果映射信息
"""

import bpy
import bmesh
from bmesh.types import BMesh, BMVert
from bpy.types import Object
from mathutils import Vector

from ..infrastructure.data import negate_string
from .bmesh_utils import update_loop_index
from .normal import normal_clear, normal_transfer_from_object


def symmetrize(obj: Object, data: dict) -> dict:
    """
    对称化网格函数

    Args:
        obj: Blender 网格对象
        data: 对称化参数字典

    Returns:
        包含对称化结果信息的字典:
            - 'original': 原始顶点索引列表
            - 'mirror': 镜像顶点索引列表
            - 'center': 中心顶点索引列表
            - 'custom_normal': 是否处理了自定义法线
    """

    def _offset_mirrored_uvs(bm: BMesh, sides: tuple[list, list, list], offset: Vector):
        """偏移镜像面的 UV 坐标"""
        mirrored_vert_indices = set(sides[1])
        mirrored_faces = {f for v in bm.verts if v.index in mirrored_vert_indices for f in v.link_faces}

        if mirrored_faces:
            layers = bm.loops.layers.uv
            for f in mirrored_faces:
                for loop in f.loops:
                    for layer in layers:
                        loop[layer].uv += offset

    def _classify_vertex(v: BMVert, axis_idx: int, threshold: float, symdir: str) -> str:
        """根据轴索引和方向分类顶点"""
        if -threshold < v.co[axis_idx] < threshold:
            v.co[axis_idx] = 0

        co_val = v.co[axis_idx]
        if co_val == 0:
            return 'center'

        is_positive_side = (symdir == "POSITIVE" and co_val > 0) or (symdir == "NEGATIVE" and co_val < 0)
        return 'original' if is_positive_side else 'mirror'

    def _sort_verts_into_sides(bm: BMesh, axis_idx: int, symdir: str, threshold: float, partial: bool) -> tuple[list, list, list]:
        """将顶点分类到原始,镜像和中心三侧"""
        original, mirror, center = [], [], []
        verts = [v for v in bm.verts if v.select] if partial else bm.verts

        for v in verts:
            side = _classify_vertex(v, axis_idx, threshold, symdir)
            if side == 'original':
                original.append(v.index)
            elif side == 'mirror':
                mirror.append(v.index)
            else:
                center.append(v.index)
            v.select = False

        bm.select_flush(False)
        return original, mirror, center

    def _get_mirror_verts_by_index(original: list, mirror: list, center: list) -> dict:
        """通过索引映射获取镜像顶点"""
        mirror_verts = dict(zip(original, mirror))
        mirror_verts.update({vz: vz for vz in center})
        return mirror_verts

    def _get_mirror_verts_by_location(bm: BMesh, axis: str, original: list, center: list, precision: int = 10) -> dict:
        """通过位置映射获取镜像顶点"""
        axis_idx = {'X': 0, 'Y': 1, 'Z': 2}[axis]
        coord_keys = {0: (1, 2), 1: (0, 2), 2: (0, 1)}[axis_idx]

        coord_map = {}
        for v in bm.verts:
            coords = [f"{v.co[i]:.{precision}f}" for i in range(3)]
            key = (coords[coord_keys[0]], coords[coord_keys[1]])
            if key not in coord_map:
                coord_map[key] = {}
            coord_map[key][coords[axis_idx]] = v.index

        mirror_verts = {}
        for idx in original:
            vo = bm.verts[idx]
            coords = [f"{vo.co[i]:.{precision}f}" for i in range(3)]
            key = (coords[coord_keys[0]], coords[coord_keys[1]])
            negated = negate_string(coords[axis_idx])
            mirror_verts[idx] = coord_map[key][negated]

        mirror_verts.update({vc: vc for vc in center})
        return mirror_verts

    def _get_mirror_faces_and_loops(bm: BMesh, mirror_verts: dict) -> tuple[dict, dict]:
        """获取镜像面和循环映射"""
        faces = {}
        loops = {}

        for face in bm.faces:
            vertlist = frozenset(v.index for v in face.verts)
            faces[vertlist] = face.index
            for loop in face.loops:
                loops[(face.index, loop.vert.index)] = loop.index

        mirror_faces = {}
        for vertlist, face_idx in faces.items():
            try:
                mirrored = frozenset(mirror_verts[idx] for idx in vertlist)
                if mirrored in faces:
                    mirror_faces[face_idx] = faces[mirrored]
            except KeyError:
                pass

        return mirror_faces, loops

    def _get_mirror_loops(bm: BMesh, mirror_faces: dict, mirror_verts: dict, loops: dict) -> dict:
        """获取镜像循环映射"""
        mirror_loops = {}
        for fidx, target_fidx in mirror_faces.items():
            for loop in bm.faces[fidx].loops:
                mirror_loops[loop.index] = loops[(target_fidx, mirror_verts[loop.vert.index])]
        return mirror_loops

    def _fix_center_seam(obj: Object, center: list, fix_method: str, clear_sharps: bool):
        """修复中心缝合边"""
        for v in obj.data.vertices:
            v.select = v.index in center

        bpy.ops.object.mode_set(mode='EDIT')
        mode = tuple(bpy.context.scene.tool_settings.mesh_select_mode)

        if mode != (True, False, False):
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')

        if bpy.app.version < (5, 1, 0):
            bpy.ops.mesh.loop_multi_select(ring=False)
        else:
            bpy.ops.mesh.select_edge_loop_multi()

        if clear_sharps:
            bpy.ops.mesh.mark_sharp(clear=True)

        if fix_method == "CLEAR":
            normal_clear(obj, limit=False)
        elif fix_method == "TRANSFER":
            normal_transfer_from_object(obj, obj, vert_ids=center, remove_vgroup=True)

        bpy.ops.mesh.select_all(action='DESELECT')
        if mode != (True, False, False):
            bpy.context.scene.tool_settings.mesh_select_mode = mode

    def _remove_vertex_groups(bm: BMesh, vg, sides: tuple[list, list, list]):
        """移除镜像和中心顶点的顶点组"""
        for idx in sides[1] + sides[2]:
            for vg_idx in list(bm.verts[idx][vg].keys()):
                del bm.verts[idx][vg][vg_idx]

    def _build_sides_from_mesh() -> tuple[BMesh, tuple]:
        """切换到物体模式, 从网格构建顶点三侧分类(游标空间对称时先转入游标空间再分类)"""
        bpy.ops.object.mode_set(mode='OBJECT')
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        update_loop_index(bm)

        if cursor_to_object:
            for v in bm.verts:
                v.co = object_to_cursor @ v.co

        return bm, _sort_verts_into_sides(bm, axis_idx, symdir, threshold, partial)

    def _apply_uv_offset_and_vertex_groups(bm: BMesh, sides: tuple):
        """应用UV偏移与顶点组清理, 有写入时回写网格"""
        if is_uv_offset:
            _offset_mirrored_uvs(bm, sides, uv_offset)

        if not mirror_vertex_groups:
            _remove_vertex_groups(bm, bm.verts.layers.deform.verify(), sides)

        if is_uv_offset or not mirror_vertex_groups:
            if cursor_to_object:
                for v in bm.verts:
                    v.co = cursor_to_object @ v.co

            bm.to_mesh(obj.data)

    direction = data['direction']
    threshold = data['threshold']
    partial = data['partial']
    remove = data['remove']
    remove_redundant_center = data['remove_redundant_center']
    redundant_threshold = data['redundant_threshold']
    uv_offset = data['uv_offset']
    mirror_vertex_groups = data['mirror_vertex_groups']
    mirror_custom_normals = data['mirror_custom_normals']
    custom_normal_method = data['custom_normal_method']
    fix_center = data['fix_center']
    fix_center_method = data['fix_center_method']
    clear_sharps = data['clear_sharps']
    use_cursor = data.get('use_cursor', False)
    cursor_matrix = data.get('cursor_matrix')
    mirror_vector = data['mirror_vector']

    symdir, axis = direction.split('_')
    axis_idx = {'X': 0, 'Y': 1, 'Z': 2}[axis]

    # 游标空间对称时预计算空间互转矩阵: 对称平面在游标平面, 顶点分类与位置匹配均须基于游标空间坐标
    cursor_to_object = None
    if use_cursor and cursor_matrix:
        cursor_to_object = obj.matrix_world.inverted() @ cursor_matrix
        object_to_cursor = cursor_to_object.inverted()

    is_uv_offset = obj.data.uv_layers and (uv_offset.x or uv_offset.y)
    is_normal_mirror = not remove and not partial and mirror_custom_normals

    normal_source_obj = None
    if not remove and not partial and obj.data.has_custom_normals:
        if mirror_custom_normals and fix_center and fix_center_method == "TRANSFER":
            obj.update_from_editmode()
            normal_source_obj = obj.copy()
            normal_source_obj.data = obj.data.copy()

    if not partial:
        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action='SELECT')

    if cursor_to_object:
        bm_cursor = bmesh.from_edit_mesh(obj.data)
        bm_cursor.verts.ensure_lookup_table()

        for v in bm_cursor.verts:
            v.co = object_to_cursor @ v.co

        bmesh.update_edit_mesh(obj.data)

    bpy.ops.mesh.symmetrize(direction=direction, threshold=threshold)

    if cursor_to_object:
        bm_cursor = bmesh.from_edit_mesh(obj.data)
        bm_cursor.verts.ensure_lookup_table()

        for v in bm_cursor.verts:
            v.co = cursor_to_object @ v.co

        bmesh.update_edit_mesh(obj.data)

    if not partial:
        bpy.ops.mesh.select_all(action='DESELECT')

    if is_normal_mirror:
        bm, sides = _build_sides_from_mesh()
        loop_normals = [loop.normal.normalized() for loop in obj.data.loops]

        _apply_uv_offset_and_vertex_groups(bm, sides)

        if custom_normal_method == "INDEX":
            mirror_verts = _get_mirror_verts_by_index(*sides)
        else:
            mirror_verts = _get_mirror_verts_by_location(bm, axis, sides[0], sides[2])

        mirror_faces, loops = _get_mirror_faces_and_loops(bm, mirror_verts)
        mirror_loops = _get_mirror_loops(bm, mirror_faces, mirror_verts, loops)

        # 反射平面法线: 游标空间对称时须转换到网格空间, 平面法线用 object_to_cursor 线性部分的转置(抵消物体缩放);
        # 法线是方向向量, 只取决于平面朝向, 与平面位置偏移无关
        mirror_normal = mirror_vector
        if cursor_to_object:
            mirror_normal = (object_to_cursor.to_3x3().transposed() @ mirror_vector).normalized()

        for src_idx, dst_idx in mirror_loops.items():
            loop_normals[dst_idx] = loop_normals[src_idx].reflect(mirror_normal)

        bm.free()

        obj.data.normals_split_custom_set(loop_normals)

        if sides[2] and fix_center:
            _fix_center_seam(obj, sides[2], fix_center_method, clear_sharps)
        else:
            bpy.ops.object.mode_set(mode='EDIT')

        if normal_source_obj:
            bpy.data.objects.remove(normal_source_obj, do_unlink=True)

        return {'original': sides[0], 'mirror': sides[1], 'center': sides[2], 'custom_normal': True, 'vertmap': mirror_verts, 'facemap': mirror_faces, 'loopmap': mirror_loops}

    else:
        bm, sides = _build_sides_from_mesh()
        _apply_uv_offset_and_vertex_groups(bm, sides)

        bm.free()

        bpy.ops.object.mode_set(mode='EDIT')

        if remove or remove_redundant_center:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.normal_update()
            bm.verts.ensure_lookup_table()

            if remove:
                verts = [bm.verts[idx] for idx in sides[1]]
                bmesh.ops.delete(bm, geom=verts, context='VERTS')
            elif remove_redundant_center:
                center_set = set(sides[2])
                redundant_edges = [e for e in bm.edges if e.is_manifold and all(v.index in center_set for v in e.verts) and round(e.calc_face_angle(), 5) <= redundant_threshold]
                bmesh.ops.dissolve_edges(bm, edges=redundant_edges, use_verts=True, use_face_split=False)
                sides = (sides[0], sides[1], [])

            bmesh.update_edit_mesh(obj.data)

        return {'original': sides[0], 'mirror': sides[1], 'center': sides[2], 'custom_normal': False}
