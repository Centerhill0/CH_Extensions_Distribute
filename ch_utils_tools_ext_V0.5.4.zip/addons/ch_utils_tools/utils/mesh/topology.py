"""
拓扑工具模块

提供网格拓扑分析功能, 包括孤岛检测, 路径搜索, 序列提取等.

主要功能:
- get_selected_vert_islands: 获取网格孤岛选择块
- get_mesh_element_islands: 获取选中面片的连通域
- get_vert_sequences: 获取顶点序列
- dijkstra_path: Dijkstra最短路径算法
- get_shortest_path: 获取两个顶点之间的最短路径
- collect_vert_path: 收集多个选中顶点之间的最短路径
- split_vert_path_into_segments: 将顶点路径按选中顶点分割为多个段
- get_boundary_edges: 获取给定面集合的边界边
- build_mesh_graph: 构建网格图数据结构
"""

import heapq
from collections import deque
from bmesh.types import BMesh, BMVert, BMEdge, BMFace


def get_selected_vert_islands(bm: BMesh) -> dict[int, set[int]]:
    """
    获取网格孤岛选择块,返回对应的连通块顶点集合

    Args:
        bm: BMesh对象

    Returns:
        键是选择孤岛编号,值是顶点编号集合
    """
    bm.verts.ensure_lookup_table()
    selected_verts = [v for v in bm.verts if v.select]

    if not selected_verts:
        return {}

    visited = set()
    groups = []

    for vert in selected_verts:
        if vert in visited:
            continue
        queue = deque([vert])
        visited.add(vert)
        current_group = [vert]
        while queue:
            current_vert = queue.popleft()
            for edge in current_vert.link_edges:
                linked_vert = edge.other_vert(current_vert)
                if linked_vert.select and linked_vert not in visited:
                    visited.add(linked_vert)
                    queue.append(linked_vert)
                    current_group.append(linked_vert)
        groups.append(current_group)

    return {i: {v.index for v in group} for i, group in enumerate(groups)}


def get_mesh_element_islands(faces: list[BMFace]) -> list[tuple[list[BMVert], list[BMEdge], list[BMFace]]]:
    """
    获取选中面片的连通域(岛屿),返回每个岛屿的顶点, 边, 面集合

    Args:
        faces: 选中的面列表

    Returns:
        包含元组(顶点列表, 边列表, 面列表)的列表,按面数量降序排列
    """
    faces_set = set(faces)
    face_islands = []
    visited = set()

    while faces_set:
        start_face = next(iter(faces_set))
        island = []
        queue = deque([start_face])
        visited.add(start_face)

        while queue:
            current_face = queue.popleft()
            island.append(current_face)
            for edge in current_face.edges:
                for neighbor in edge.link_faces:
                    if neighbor.select and neighbor not in visited:
                        visited.add(neighbor)
                        queue.append(neighbor)

        face_islands.append(island)
        faces_set.difference_update(island)

    islands = []
    for island_faces in face_islands:
        verts_set = set()
        edges_set = set()
        for f in island_faces:
            verts_set.update(f.verts)
            edges_set.update(f.edges)
        islands.append((list(verts_set), list(edges_set), island_faces))

    return sorted(islands, key=lambda x: len(x[2]), reverse=True)


def get_vert_sequences(verts: list[BMVert], edges: list[BMEdge] | None = None, ensure_seq_len: bool = False) -> list[tuple[list[BMVert], bool]]:
    """
    获取顶点序列(路径或环)

    当 edges 参数为 None 时,使用边的选中状态(e.select)判断连接关系;
    当 edges 参数不为 None 时,使用给定的边集合判断连接关系.

    Args:
        verts: 顶点列表
        edges: 边列表(可选),如果提供则使用此边集合判断连接关系
        ensure_seq_len: 是否过滤掉长度<3的序列

    Returns:
        包含元组(sequence, is_cyclic)的列表
    """
    verts_set = set(verts)
    edges_set = set(edges) if edges else None
    sequences = []

    if edges_set is not None:
        edge_count = {v: sum(1 for e in v.link_edges if e in edges_set) for v in verts}
    else:
        edge_count = {v: sum(1 for e in v.link_edges if e.select) for v in verts}

    non_cyclic_start_verts = [v for v in verts if edge_count[v] == 1]
    current_vert = non_cyclic_start_verts[0] if non_cyclic_start_verts else next(iter(verts_set), None)
    current_seq = []

    while verts_set and current_vert is not None:
        current_seq.append(current_vert)
        verts_set.discard(current_vert)

        if current_vert in non_cyclic_start_verts:
            non_cyclic_start_verts.remove(current_vert)

        if edges_set is not None:
            next_verts = [e.other_vert(current_vert) for e in current_vert.link_edges if e in edges_set and e.other_vert(current_vert) in verts_set]
        else:
            next_verts = [e.other_vert(current_vert) for e in current_vert.link_edges if e.select and e.other_vert(current_vert) in verts_set]

        if next_verts:
            current_vert = next_verts[0]
        else:
            is_cyclic = edge_count.get(current_vert, 0) == 2
            sequences.append((current_seq, is_cyclic))

            current_seq = []
            if non_cyclic_start_verts:
                current_vert = non_cyclic_start_verts[0]
            elif verts_set:
                current_vert = next(iter(verts_set), None)
            else:
                current_vert = None

    if ensure_seq_len:
        sequences = [(seq, is_cyclic) for seq, is_cyclic in sequences if len(seq) >= 3]

    return sequences


def dijkstra_path(graph: dict[BMVert, list[tuple[BMVert, float]]], v_start: BMVert, v_end: BMVert, skip_selected_vert: bool = False) -> list[BMVert]:
    """
    Dijkstra最短路径算法

    Args:
        graph: 图字典 {顶点: [(邻居顶点, 权重), ...]}
        v_start: 起始顶点
        v_end: 结束顶点
        skip_selected_vert: 是否绕过中间选中的顶点(起始和结束点除外)

    Returns:
        从起始到结束的顶点路径列表,未找到则返回空列表
    """
    distances = {v: float('inf') for v in graph}
    predecessors = {v: None for v in graph}
    distances[v_start] = 0

    queue = [(0, v_start.index, v_start)]
    visited = set()
    found = False

    while queue:
        current_dist, _, current = heapq.heappop(queue)

        if current in visited:
            continue
        visited.add(current)

        if current == v_end:
            found = True
            break

        for neighbor, weight in graph[current]:
            if neighbor in visited:
                continue

            if skip_selected_vert and neighbor not in (v_start, v_end) and neighbor.select:
                continue

            new_dist = current_dist + weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                predecessors[neighbor] = current
                heapq.heappush(queue, (new_dist, neighbor.index, neighbor))

    path = []
    if found:
        current = v_end
        while current is not None:
            path.append(current)
            current = predecessors.get(current)
            if current in path:
                break
        path.reverse()
        if path and path[0] != v_start:
            return []

    return path


def get_shortest_path(bm: BMesh, v_start: BMVert, v_end: BMVert, use_topo: bool = False, skip_selected_vert: bool = False, graph: dict | None = None) -> list[BMVert]:
    """
    获取两个顶点之间的最短路径(拓扑或几何距离)

    Args:
        bm: BMesh对象
        v_start: 起始顶点
        v_end: 结束顶点
        use_topo: 是否使用拓扑距离(默认False,使用几何距离)
        skip_selected_vert: 是否绕过中间选中的顶点(起始和结束点除外)
        graph: 预构建的加权图(由 build_weighted_graph 生成), 提供时跳过全图重建; None时内部构建.
            多次搜索同一网格时应复用同一图(如 collect_vert_path 的做法)

    Returns:
        从起始顶点到结束顶点的顶点列表
    """
    if v_start == v_end:
        return [v_start]

    mg = graph if graph is not None else build_weighted_graph(bm.verts, bm.edges, use_topo)
    path = dijkstra_path(mg, v_start, v_end, skip_selected_vert)

    return list(dict.fromkeys(path))


def collect_vert_path(bm: BMesh, selected: list[int], use_topology_distance: bool) -> list[BMVert]:
    """
    收集多个选中顶点之间的最短路径

    根据选中顶点的顺序,依次计算相邻顶点间的最短路径并合并为完整路径.
    例如: [a, b, c] -> 计算 a→b 和 b→c 的路径并合并

    Args:
        bm: BMesh对象
        selected: 选中顶点的索引列表,按路径顺序排列
        use_topology_distance: 是否使用拓扑距离(True为拓扑距离,False为几何距离)

    Returns:
        完整的顶点路径列表
    """
    # 全程复用同一张加权图, 避免每段路径重复全图重建
    graph = build_weighted_graph(bm.verts, bm.edges, use_topology_distance)

    vert_path = []
    for i in range(len(selected) - 1):
        v_start = bm.verts[selected[i]]
        v_end = bm.verts[selected[i + 1]]
        segment = get_shortest_path(bm, v_start, v_end, use_topo=use_topology_distance, graph=graph)

        for v in segment:
            if v not in vert_path:
                vert_path.append(v)

    return vert_path


def split_vert_path_into_segments(bm: BMesh, selected: list[int], vert_path: list[BMVert]) -> tuple[list[BMVert], list[list[BMVert]]]:
    """
    将顶点路径按选中顶点分割为多个段

    根据选中顶点(节点)将完整路径分割为多个段,每个段包含两个相邻节点之间的所有顶点.
    例如: selected=[a1,b1,c1,d1], vert_path=[a1,a2,a3,b1,b2,c1,c2,c3,d1]
         -> knots=[a1,b1,c1,d1], segments=[[a1,a2,a3,b1],[b1,b2,c1],[c1,c2,c3,d1]]

    Args:
        bm: BMesh对象
        selected: 选中顶点的索引列表,按路径顺序排列
        vert_path: 完整的顶点路径列表

    Returns:
        元组 (knots, segments):
        - knots: 节点顶点列表(选中顶点)
        - segments: 段列表,每个段是两个相邻节点之间的顶点列表
    """
    knots: list[BMVert] = []
    segments: list[list[BMVert]] = [[]]

    for v in vert_path:
        current_knot_index = len(knots)
        current_knot = bm.verts[selected[current_knot_index]]

        if v == current_knot:
            knots.append(current_knot)
            segments[-1].append(v)

            if current_knot_index != 0 and current_knot_index != len(selected) - 1:
                segments.append([v])
        else:
            segments[-1].append(v)

    return knots, segments


def build_weighted_graph(verts: list[BMVert], edges: list[BMEdge], use_topo_dist: bool = False) -> dict[BMVert, list[tuple[BMVert, float]]]:
    """
    构建带权重的图结构用于路径搜索(Dijkstra算法)

    与 build_mesh_graph 不同,此函数使用顶点对象作为键,并计算边权重

    Args:
        verts: 顶点集合(列表或可迭代对象)
        edges: 边集合(列表或可迭代对象)
        use_topo_dist: 是否使用拓扑距离(默认False,使用几何距离)

    Returns:
        图字典 {顶点: [(邻居顶点, 权重), ...]}
    """
    graph = {v: [] for v in verts}
    for edge in edges:
        v1, v2 = edge.verts
        weight = 1 if use_topo_dist else (v1.co - v2.co).length
        graph[v1].append((v2, weight))
        graph[v2].append((v1, weight))
    return graph


def get_boundary_edges(faces: list[BMFace], region_to_loop: bool = False) -> list[BMEdge]:
    """
    获取给定面集合的边界边

    Args:
        faces: 面列表
        region_to_loop: 是否将选择从面转为边界边

    Returns:
        边界边列表
    """
    faces_set = set(faces)
    boundary_edges = []

    for f in faces:
        for e in f.edges:
            if (not e.is_manifold) or any(link_face not in faces_set for link_face in e.link_faces):
                boundary_edges.append(e)
    # 去重
    seen = set()
    boundary_edges = [x for x in boundary_edges if not (x in seen or seen.add(x))]

    if region_to_loop:
        for face in faces:
            face.select_set(False)
        for edge in boundary_edges:
            edge.select_set(True)

    return boundary_edges


def build_mesh_graph(bm: BMesh) -> dict[int, list[tuple[int, bool, bool]]]:
    """
    构建网格图数据结构,用于快速查询顶点之间的连接关系

    构建一个以顶点索引为键的字典,每个值是一个列表,
    包含与该顶点相连的所有边的信息(相邻顶点索引, 顶点选中状态, 边选中状态)

    Args:
        bm: BMesh对象

    Returns:
        键为顶点索引,值为相邻顶点信息列表
        格式: {顶点索引: [(相邻顶点索引, 顶点选中状态, 边选中状态), ...]}

    注意: 本函数不携带边权重, 且以顶点索引为键(供 chamfer 的轨道/扫描计算使用);
    路径搜索需要的加权图请用 build_weighted_graph.
    """
    mesh_graph = {v.index: [] for v in bm.verts}

    for edge in bm.edges:
        v1, v2 = edge.verts
        mesh_graph[v1.index].append((v2.index, v2.select, edge.select))
        mesh_graph[v2.index].append((v1.index, v1.select, edge.select))

    return mesh_graph
