"""
边环变形器模块

提供边环(Edge Loop)的变形操作功能.
支持曲线化, 线性化, 拉直和平滑混合等操作.

主要功能:
- EdgeLoopDeformer: 边环变形器类

支持的变形类型:
- 曲线变形: 使用贝塞尔曲线平滑边环
- 流动变形: 使用 Hermite 插值平滑边环
- 线性变形: 将边环顶点线性排列
- 拉直变形: 拉直单条边
- 混合变形: 混合起点和终点的变形效果
"""

import math
from mathutils import Vector
from mathutils.geometry import interpolate_bezier
from bmesh.types import BMesh, BMVert, BMEdge

from ..math.interpolation import smooth_step, hermite_3d
from .spline_deform import map_segment_onto_spline


class EdgeLoopDeformer:
    """
    边环变形器

    功能: 对边环序列执行各种变形操作
    - 支持曲线变形(贝塞尔曲线)
    - 支持流动变形(Hermite插值)
    - 支持线性变形
    - 支持拉直变形
    - 支持混合变形

    要求: 提供有效的边列表
    """

    def __init__(self, bm: BMesh, edges: list[BMEdge]):
        """
        初始化边环变形器

        Args:
            bm: BMesh对象
            edges: 边列表,按顺序排列
        """
        self.bm = bm
        self.edges = edges
        self.verts: list[BMVert] = []
        self._init_ordered_verts()

        self.initial_vert_positions: list[Vector] = [v.co.copy() for v in self.verts]

        self.is_cyclic = self.verts[0] == self.verts[-1]
        self.valences: list[int] = []
        self.max_valence: int = 0

        self.ring: dict[BMEdge, list[BMEdge]] = {e: [] for e in self.edges}
        self.edge_rings: dict[BMEdge, list] = {}
        self.ends: dict[BMEdge, tuple] = {}

    def _init_ordered_verts(self) -> None:
        """初始化有序顶点序列"""
        if len(self.edges) > 1:
            last_vert = self._find_endpoint_vert(0)
            self.verts.append(last_vert)

            for edge in self.edges:
                vert = edge.other_vert(last_vert)
                self.verts.append(vert)
                last_vert = vert
        else:
            self.verts = [self.edges[0].verts[0], self.edges[0].verts[1]]

        self._stabilize_start_vert()

    def _find_endpoint_vert(self, idx: int = 0) -> BMVert:
        """找到边环端点 (idx=0 起始, idx=-1 终止)"""
        edge = self.edges[idx]
        neighbor = self.edges[idx - 1] if idx < 0 else self.edges[1]
        for vert in edge.verts:
            if vert not in neighbor.verts:
                return vert
        return edge.verts[0]

    def _stabilize_start_vert(self) -> None:
        """确保起始顶点稳定(通过坐标和比较)"""
        start_sum = self.verts[0].co.x + self.verts[0].co.y + self.verts[0].co.z
        end_sum = self.verts[-1].co.x + self.verts[-1].co.y + self.verts[-1].co.z

        if start_sum < end_sum:
            self.verts.reverse()
            self.edges.reverse()

    def __str__(self) -> str:
        """返回边环信息字符串"""
        lines = []
        for idx, edge in enumerate(self.edges):
            line = f"edge: {edge.index} - valence: {self.valences[idx] if idx < len(self.valences) else 'N/A'}"
            ring_edges = self.get_ring_edges(edge)
            line += " | " + " | ".join(str(e.index) for e in ring_edges)
            lines.append(line)

        return "\n".join(lines)

    def __repr__(self) -> str:
        return self.__str__()

    def add_ring_edge(self, edge: BMEdge, ring_edge: BMEdge) -> None:
        """
        添加边环边

        Args:
            edge: 目标边
            ring_edge: 要添加的边环边
        """
        if edge in self.ring and len(self.ring[edge]) <= 2:
            self.ring[edge].append(ring_edge)

    def get_ring_edges(self, edge: BMEdge) -> list[BMEdge]:
        """
        获取边环边列表

        Args:
            edge: 目标边

        Returns:
            边环边列表

        Raises:
            ValueError: 边不在边环中
        """
        if edge in self.ring:
            return self.ring[edge]
        raise ValueError("Edge not in EdgeLoopDeformer!")

    def select(self) -> None:
        """选择所有边"""
        for edge in self.edges:
            edge.select = True

    def get_ring_boundary_edges(self, edge: BMEdge) -> tuple:
        """
        获取边环的边界边

        Args:
            edge: 目标边

        Returns:
            边界边元组 (start_edge, end_edge)
        """
        ring = self.edge_rings[edge]
        return (ring[0], ring[-1])

    def apply_curve_flow(self, tension: float, use_rail: bool, rail_type: str, rail_start: float, rail_end: float) -> None:
        """
        应用贝塞尔曲线变形

        使用贝塞尔曲线平滑边环,支持轨道模式扩展控制点.

        Args:
            tension: 张力参数,控制曲线弯曲程度
            use_rail: 是否使用轨道模式
            rail_type: 轨道类型, 'ABSOLUTE' 或 'FACTOR'
            rail_start: 起点轨道值
            rail_end: 终点轨道值
        """
        if len(self.edges) < 2 or self.is_cyclic:
            return

        self.bm.verts.ensure_lookup_table()
        self.bm.edges.ensure_lookup_table()

        start_vert = self._find_endpoint_vert(0)
        end_vert = self._find_endpoint_vert(-1)

        dir1_unnormalized = self.edges[0].other_vert(start_vert).co - start_vert.co
        dir1 = dir1_unnormalized.normalized()
        dir2_unnormalized = self.edges[-1].other_vert(end_vert).co - end_vert.co
        dir2 = dir2_unnormalized.normalized()

        p1, p4 = self._calc_control_points(start_vert, end_vert, dir1_unnormalized, dir2_unnormalized, dir1, dir2, use_rail, rail_type, rail_start, rail_end)

        scale = (p1 - p4).length * 0.5 * tension
        p2 = p1 + (dir1 * scale)
        p3 = p4 + (dir2 * scale)

        precision = 1000
        spline_points = interpolate_bezier(p1, p2, p3, p4, precision)
        map_segment_onto_spline(self.verts, spline_points)

    def _calc_control_points(self, start_vert: BMVert, end_vert: BMVert, dir1_unnormalized: Vector, dir2_unnormalized: Vector, dir1: Vector, dir2: Vector, use_rail: bool, rail_type: str, rail_start: float, rail_end: float) -> tuple[Vector, Vector]:
        """计算贝塞尔曲线控制点"""
        if use_rail:
            if rail_type == 'ABSOLUTE':
                p1 = start_vert.co + (dir1_unnormalized - dir1 * rail_start)
                p4 = end_vert.co + (dir2_unnormalized - dir2 * rail_end)
            else:
                p1 = start_vert.co + dir1_unnormalized * rail_start
                p4 = end_vert.co + dir2_unnormalized * rail_end
        else:
            p1 = start_vert.co
            p4 = end_vert.co

        return p1, p4

    def straighten_edge(self, distance: float) -> None:
        """
        拉直单条边

        将边的两个端点放置到等距位置.

        变形前: A' ------ A - B -- B'
        变形后: A' --- A --- B --- B'

        Args:
            distance: 端点到邻居的距离
        """
        edge = self.edges[0]

        a1, a2 = edge.verts[0], edge.verts[1]
        if len(a1.link_edges) <= 3 or len(a2.link_edges) <= 3:
            return

        b1 = self._find_straighten_neighbour(a1, edge)
        b2 = self._find_straighten_neighbour(a2, edge)

        direction = (b2 - b1).normalized()
        max_distance = (b2 - b1).length

        if distance * 2.0 > max_distance:
            distance = max_distance * 0.5

        a1.co = b1 + distance * direction
        a2.co = b2 - distance * direction

    def _find_straighten_neighbour(self, vert: BMVert, edge: BMEdge) -> Vector:
        """找到拉直操作的邻居位置"""
        link_edges = set(vert.link_edges)
        link_edges.remove(edge)

        face_a_is_quad = len(edge.link_faces[0].verts) == 4
        edges = link_edges

        if face_a_is_quad:
            edges -= set(edge.link_faces[0].edges)

        if not edge.is_boundary:
            face_b_is_quad = len(edge.link_faces[1].verts) == 4
            if face_b_is_quad:
                edges -= set(edge.link_faces[1].edges)

        avg_pos = Vector((0, 0, 0))
        count = 0

        for e in edges:
            for v in e.verts:
                if v != vert:
                    avg_pos += v.co
                    count += 1

        return avg_pos / count if count > 0 else vert.co

    def apply_linear(self, even_spacing: bool) -> None:
        """
        应用线性变形

        将边环顶点线性排列在起点和终点之间.

        Args:
            even_spacing: 是否均匀分布顶点
        """
        if len(self.edges) < 2 or self.is_cyclic:
            return

        p1 = self._find_endpoint_vert(0)
        p2 = self._find_endpoint_vert(-1)

        edge_count = len(self.edges)
        direction = (p2.co - p1.co) / edge_count
        direction_normalized = direction.normalized()

        last_vert = p1
        for i in range(edge_count - 1):
            vert = self.edges[i].other_vert(last_vert)

            if even_spacing:
                vert.co = p1.co + direction * (i + 1)
            else:
                proj = vert.co - p1.co
                scalar = proj.dot(direction_normalized)
                vert.co = p1.co + direction_normalized * scalar

            last_vert = vert

    def blend_ends(self, blend_start: int, blend_end: int, blend_type: str) -> None:
        """
        混合起点和终点的变形效果

        从起点和终点逐渐过渡变形效果,实现平滑混合.

        Args:
            blend_start: 起点混合顶点数
            blend_end: 终点混合顶点数
            blend_type: 混合类型, 'LINEAR' 或 'SMOOTH'
        """
        if self.is_cyclic:
            return

        vert_count = len(self.verts)
        start_count, end_count = self._calc_blend_counts(blend_start, blend_end, vert_count)

        if start_count > 0:
            self._apply_blend(min(vert_count - 1, start_count), reverse=False, blend_type=blend_type)
        if end_count > 0:
            self._apply_blend(min(vert_count - 1, end_count), reverse=True, blend_type=blend_type)

    def _calc_blend_counts(self, blend_start: int, blend_end: int, vert_count: int) -> tuple[int, int]:
        """计算混合顶点数"""
        start_count = blend_start
        end_count = blend_end

        if start_count + end_count >= vert_count:
            if start_count < end_count:
                end_count = max(vert_count - start_count - 1, 0)
            elif end_count < start_count:
                start_count = max(vert_count - end_count - 1, 0)
            else:
                mid_count = math.floor(vert_count / 2)
                start_count = vert_count - mid_count
                end_count = vert_count - start_count

        return start_count, end_count

    def _apply_blend(self, blend_range: int, reverse: bool, blend_type: str) -> None:
        """应用混合变形"""
        vert_count = len(self.verts)
        indices = list(range(vert_count))
        if reverse:
            indices.reverse()

        distances = [0]
        total_length = 0.0

        for i in range(1, blend_range + 1):
            length = (self.verts[indices[i]].co - self.verts[indices[i - 1]].co).length
            total_length += length
            distances.append(total_length)

        if total_length == 0:
            return

        for i in range(blend_range + 1):
            blend_value = distances[i] / total_length

            if blend_type == 'SMOOTH':
                blend_value = smooth_step(0.0, 1.0, blend_value)

            vert = self.verts[indices[i]]
            initial_pos = self.initial_vert_positions[indices[i]]
            vert.co = initial_pos.lerp(vert.co, blend_value)

    def apply_flow(self, tension: float, min_angle: float) -> None:
        """
        应用流动变形

        使用 Hermite 插值平滑边环,支持最小角度限制.

        Args:
            tension: 张力参数
            min_angle: 最小角度限制(弧度)
        """
        for edge in self.edges:
            if edge.is_boundary:
                continue

            target = self._calc_flow_targets(edge, tension, min_angle)

            for vert, new_co in target.items():
                vert.co = new_co

    def _calc_flow_targets(self, edge: BMEdge, tension: float, min_angle: float) -> dict[BMVert, Vector]:
        """计算流动变形的目标位置"""
        target = {}

        for loop in edge.link_loops:
            ring1 = loop.link_loop_next.link_loop_next
            ring2 = loop.link_loop_radial_prev.link_loop_prev.link_loop_prev

            center = edge.other_vert(loop.vert)

            p2 = ring1.vert
            p3 = ring2.link_loop_radial_next.vert

            p1 = self._calc_flow_control_point(ring1, p2, p3, center, min_angle, is_p1=True)
            p4 = self._calc_flow_control_point(ring2, p3, p2, center, min_angle, is_p1=False)

            if p1 == p2.co or p3.co == p4:
                continue

            new_co = self._calc_hermite_position(p1, p2.co, p3.co, p4, tension)
            target[center] = new_co

        return target

    def _calc_flow_control_point(self, ring, p_center: BMVert, p_other: BMVert, center: BMVert, min_angle: float, is_p1: bool) -> Vector:
        """计算流动变形的控制点 (P1 或 P4)

        Args:
            ring: 当前环的 BMLoop
            p_center: 中心顶点 (P1 时为 p2, P4 时为 p3)
            p_other: 另一个顶点 (P1 时为 p3, P4 时为 p2)
            center: 偏移参考顶点
            min_angle: 最小角度阈值
            is_p1: True 表示计算 P1, False 表示计算 P4
        """
        if is_p1:
            final = ring.link_loop_radial_next.link_loop_next
        else:
            final = ring.link_loop_radial_prev.link_loop_prev

        if not final.edge.is_boundary:
            a, b = final.edge.verts
            p = b.co if p_center == a else a.co

            vec_a = (p - p_center.co).normalized()
            vec_b = (center.co - p_center.co).normalized()
            dot = max(-1.0, min(1.0, vec_a.dot(vec_b)))
            angle = math.acos(dot)

            if angle < min_angle:
                p = p_center.co - (p_other.co - p_center.co) * 0.5
        else:
            if is_p1:
                p = p_center.co - (p_other.co - p_center.co)
            else:
                p_center_other = ring.edge.other_vert(p_center)
                p = p_center_other.co - (p_other.co - p_center_other.co)

        return p

    def _calc_hermite_position(self, p1: Vector, p2: Vector, p3: Vector, p4: Vector, tension: float) -> Vector:
        """使用 Hermite 插值计算新位置"""
        dist = (p2 - p3).length * 0.5

        p1_normalized = p2 + (dist * (p1 - p2).normalized())
        p4_normalized = p3 + (dist * (p4 - p3).normalized())

        result = hermite_3d(tuple(p1_normalized), tuple(p2), tuple(p3), tuple(p4_normalized), 0.5, -tension, 0)
        return Vector(result)
