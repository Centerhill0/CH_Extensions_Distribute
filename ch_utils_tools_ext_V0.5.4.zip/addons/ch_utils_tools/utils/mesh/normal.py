"""
法线操作模块

提供法线清除, 法线传输等功能.

主要功能:
- normal_clear: 清除选中顶点的自定义法线
- normal_transfer_from_object: 从源对象传输法线到活动对象
"""

import bpy
import bmesh
from mathutils import Vector
from bpy.types import Object, VertexGroup

from ..blender.vertex_group import add_vgroup
from ..blender.modifier import add_normal_transfer_modifier


def normal_clear(active: Object, limit: bool = False) -> None:
    """
    清除选中顶点的自定义法线

    Args:
        active: 活动网格对象
        limit: 是否限制在选中的面内
    """
    prev_mode = active.mode
    bpy.ops.object.mode_set(mode='OBJECT')

    mesh = active.data
    loop_normals = [loop.normal for loop in mesh.loops]

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()

    verts = [v for v in bm.verts if v.select]
    faces = set(f for f in bm.faces if f.select) if limit else None

    for v in verts:
        for l in v.link_loops:
            if not limit or l.face in faces:
                loop_normals[l.index] = Vector()

    mesh.normals_split_custom_set(loop_normals)

    # 还原调用前的模式, 而非强制进入EDIT
    if prev_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode=prev_mode)

    bm.free()


def normal_transfer_from_object(active: Object, nrmsrc: Object, verts_idx: list[int] | None = None, vgroup: VertexGroup | None = None, remove_vgroup: bool = False):
    """
    从源对象传输法线到活动对象

    Args:
        active: 目标网格对象
        nrmsrc: 源网格对象
        verts_idx: 顶点索引列表,用于创建顶点组
        vgroup: 已有的顶点组
        remove_vgroup: 传输后是否移除顶点组
    """
    prev_mode = active.mode
    bpy.ops.object.mode_set(mode='OBJECT')

    if verts_idx:
        vgroup = add_vgroup(active, "NormalTransfer", verts_idx)

    if vgroup:
        vgname = vgroup.name
        data_transfer = add_normal_transfer_modifier(active, nrmsrc, vgname, vgroup)
        bpy.ops.object.modifier_apply(modifier=data_transfer.name)

        if remove_vgroup and (vg := active.vertex_groups.get(vgname)):
            active.vertex_groups.remove(vg)

    if prev_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode=prev_mode)
