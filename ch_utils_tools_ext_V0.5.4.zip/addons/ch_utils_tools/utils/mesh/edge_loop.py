"""
边环遍历模块

提供边环遍历, 循环选择, 边环变形器构建等功能. 从 topology.py 拆分而来.

主要功能:
- get_isolated_edges: 获取孤立的边
- select_loop_edges_by_angle: 基于角度选择循环边
- select_adjacent_quad_loop: 选择相邻四边形循环
- walk_boundary_edge_loop: 遍历边界边环
- walk_ngon_edge_loop: 遍历N边形边环
- walk_quad_edge_loop: 遍历四边形边环
- get_edge_loop: 获取边环变形器
- get_edge_loops: 获取多个边环变形器
"""

from collections import deque
from math import radians
from bmesh.types import BMesh, BMVert, BMEdge, BMFace, BMLoop

from ..math.geometry import get_edge_angle
from .deformer import EdgeLoopDeformer


def get_isolated_edges(edges: list[BMEdge]) -> list[BMEdge]:
    """
    获取孤立的边

    孤立边是指两端顶点没有其他选中边连接的边,常用于循环选择的起始边检测.

    Args:
        edges: 边列表

    Returns:
        孤立边列表
    """
    return [edge for edge in edges if not any(e.select for v in edge.verts for e in v.link_edges if e != edge)]


def select_loop_edges_by_angle(min_angle: float, edge: BMEdge, vert: BMVert, limit: int = 0, select: bool = False) -> list[BMEdge]:
    """
    基于角度选择循环边

    从指定边和顶点开始,沿着最大夹角方向选择连续的边.

    Args:
        min_angle: 最小角度阈值(度),小于此角度的边不会被选中
        edge: 起始边
        vert: 起始顶点(边的端点之一)
        limit: 最大选择边数,0表示无限制
        select: 是否自动选中找到的边

    Returns:
        选中的边列表(按选择顺序)
    """
    selected = []
    count = 0
    min_angle_rad = radians(min_angle)

    while True:
        other_vert = edge.other_vert(vert)
        candidate_edges = [(get_edge_angle(edge, candidate), candidate) for candidate in other_vert.link_edges if candidate != edge]

        if not candidate_edges:
            break

        best_angle, best_edge = max(candidate_edges, key=lambda x: x[0])

        if best_edge in selected or best_angle <= min_angle_rad:
            break

        if select:
            best_edge.select_set(True)

        selected.append(best_edge)
        vert = other_vert
        edge = best_edge
        count += 1

        if limit and count >= limit:
            break

    return selected


def select_adjacent_quad_loop(faces: list[BMFace], center_edge: BMEdge, reverse: bool = False) -> bool:
    """
    选择相邻四边形循环

    从中心边向两侧选择相邻的四边形面循环.

    Args:
        faces: 已选面列表(会被修改,添加新选中的面)
        center_edge: 中心边(两个已选面的公共边)
        reverse: 是否反向选择

    Returns:
        是否成功选择到循环面
    """
    loop = _find_quad_loop_start(center_edge, reverse)

    if not loop:
        return False

    while True:
        if reverse:
            loop = loop.link_loop_prev.link_loop_radial_next.link_loop_prev
        else:
            loop = loop.link_loop_next.link_loop_radial_next.link_loop_next

        loop_face = loop.face
        sel_face = loop.link_loop_radial_next.face

        if sel_face in faces or not loop_face or not sel_face or len(loop_face.verts) != 4:
            break

        sel_face.select_set(True)
        faces.append(sel_face)

    return True


def _find_quad_loop_start(center_edge: BMEdge, reverse: bool) -> BMLoop | None:
    """
    查找四边形循环的起始Loop

    Args:
        center_edge: 中心边
        reverse: 是否反向

    Returns:
        起始Loop,如果找不到则返回None
    """
    # 松散边(wire edge, 无关联面)的 link_loops 为空; 调用方通常已按返回值 None 处理
    if len(center_edge.link_loops) < 2:
        return None

    loop1 = center_edge.link_loops[0]
    loop2 = center_edge.link_loops[1]

    candidates = [
        (loop1.link_loop_next.link_loop_radial_next, loop2.link_loop_prev.link_loop_radial_next),
        (loop1.link_loop_prev.link_loop_radial_next, loop2.link_loop_next.link_loop_radial_next),
    ]

    for side_loop1, side_loop2 in candidates:
        side_face1 = side_loop1.face
        side_face2 = side_loop2.face

        if side_face1 == side_face2:
            continue

        if len(side_face1.verts) != 4 or len(side_face2.verts) != 4:
            continue

        if set(side_face1.edges).intersection(side_face2.edges):
            return side_loop1 if reverse else side_loop2

    return None


def walk_boundary_edge_loop(start_edge: BMEdge, limit_to_edges: set[BMEdge] | None = None) -> list[BMEdge]:
    """
    遍历边界边环

    从起始边开始,沿着边界遍历所有连续的边界边.

    Args:
        start_edge: 起始边界边
        limit_to_edges: 限制边集合,只遍历此集合内的边(可选)

    Returns:
        有序的边界边列表
    """
    edge_loop_set = {start_edge}
    visited = set()
    candidates = [start_edge]

    while candidates:
        for candidate in candidates:
            for vert in candidate.verts:
                if len(vert.link_edges) > 2:
                    for edge in vert.link_edges:
                        if edge.is_boundary and edge not in edge_loop_set:
                            if limit_to_edges is None or edge in limit_to_edges:
                                edge_loop_set.add(edge)
            visited.add(candidate)

        candidates = list(edge_loop_set - visited)
        if len(visited) == len(edge_loop_set):
            break

    raw_edge_loop = list(edge_loop_set)
    raw_edge_loop.remove(start_edge)

    sorted_loop = deque([start_edge])
    add = sorted_loop.append

    for vert in start_edge.verts:
        while True:
            edge = None
            for e in raw_edge_loop:
                if vert in e.verts:
                    edge = e
                    break

            if edge is not None:
                add(edge)
                vert = edge.other_vert(vert)
                raw_edge_loop.remove(edge)
            else:
                break

        add = sorted_loop.appendleft

    return list(sorted_loop)


def walk_ngon_edge_loop(start_edge: BMEdge, limit_to_edges: set[BMEdge] | None = None) -> list[BMEdge]:
    """
    遍历 N 边形边环

    从起始边开始,沿着 N 边形面遍历边环.

    Args:
        start_edge: 起始边
        limit_to_edges: 限制边集合,只遍历此集合内的边(可选)

    Returns:
        有序的边列表
    """
    edge_loop = deque([start_edge])

    start_loops = []
    face_valences = []
    for linked_loop in start_edge.link_loops:
        vert_count = len(linked_loop.face.verts)
        if vert_count > 4:
            start_loops.append(linked_loop)
            face_valences.append(vert_count)

    if not start_loops:
        return [start_edge]

    max_idx = face_valences.index(max(face_valences))
    start_loop = start_loops[max_idx]

    loop = start_loop.link_loop_next
    while len(loop.vert.link_edges) < 4 and loop.edge not in edge_loop:
        if limit_to_edges is not None and loop.edge not in limit_to_edges:
            break

        edge_loop.append(loop.edge)
        loop = loop.link_loop_next

    loop = start_loop.link_loop_prev
    while len(loop.edge.other_vert(loop.vert).link_edges) < 4 and loop.edge not in edge_loop:
        if limit_to_edges is not None and loop.edge not in limit_to_edges:
            break

        edge_loop.appendleft(loop.edge)
        loop = loop.link_loop_prev

    return list(edge_loop)


def walk_quad_edge_loop(start_edge: BMEdge, limit_to_edges: set[BMEdge] | None = None) -> list[BMEdge]:
    """
    遍历四边形边环

    从起始边开始,沿着四边形面遍历边环.

    Args:
        start_edge: 起始边
        limit_to_edges: 限制边集合,只遍历此集合内的边(可选)

    Returns:
        有序的边列表
    """
    edge_loop = deque([start_edge])
    add = edge_loop.append

    for loop in start_edge.link_loops:
        start_valence = len(loop.vert.link_edges)

        if start_valence <= 4:
            while True:
                valence = len(loop.vert.link_edges)

                if valence == 4 and start_valence == valence:
                    loop = loop.link_loop_prev.link_loop_radial_prev.link_loop_prev

                    if loop.edge in edge_loop:
                        break

                    if limit_to_edges is not None:
                        if loop.edge in limit_to_edges:
                            add(loop.edge)
                        else:
                            break
                    else:
                        add(loop.edge)
                else:
                    break

        add = edge_loop.appendleft

    return list(edge_loop)


def get_edge_loop(bm: BMesh, start_edge: BMEdge, limit_to_edges: set[BMEdge] | None = None) -> "EdgeLoopDeformer":
    """
    获取边环变形器

    根据起始边的拓扑特征,自动选择合适的遍历方法获取边环.

    Args:
        bm: BMesh对象
        start_edge: 起始边
        limit_to_edges: 限制边集合(可选)

    Returns:
        EdgeLoopDeformer 对象
    """
    start_loops = start_edge.link_loops

    is_ngon = any(len(loop.face.verts) > 4 for loop in start_loops)

    v0_valence = len(start_edge.verts[0].link_edges)
    v1_valence = len(start_edge.verts[1].link_edges)
    quad_flow = v0_valence == 4 and v1_valence == 4
    loop_end = (v0_valence > 4 and v1_valence == 4) or (v0_valence == 4 and v1_valence > 4)

    if is_ngon and not quad_flow and not loop_end:
        edges = walk_ngon_edge_loop(start_edge, limit_to_edges)
    elif start_edge.is_boundary:
        edges = walk_boundary_edge_loop(start_edge, limit_to_edges)
    else:
        edges = walk_quad_edge_loop(start_edge, limit_to_edges)

    return EdgeLoopDeformer(bm, edges)


def get_edge_loops(bm: BMesh, edges: list[BMEdge]) -> list["EdgeLoopDeformer"]:
    """
    获取多个边环变形器

    从边列表中提取所有独立的边环.

    Args:
        bm: BMesh对象
        edges: 边列表

    Returns:
        EdgeLoopDeformer 对象列表,按最大价数降序排列
    """
    not_visited = set(edges)
    edge_loops = []

    while not_visited:
        start_edge = not_visited.pop()
        edge_loop = get_edge_loop(bm, start_edge, not_visited)
        edge_loops.append(edge_loop)

        for edge in edge_loop.edges:
            not_visited.discard(edge)

    return _compute_edge_loop_data(edge_loops)


def _compute_edge_loop_data(edge_loops: list["EdgeLoopDeformer"]) -> list["EdgeLoopDeformer"]:
    """计算边环数据(邻居, 价数, 控制边环)"""
    edge_to_loop = {}
    for edge_loop in edge_loops:
        for edge in edge_loop.edges:
            edge_to_loop[edge] = edge_loop

    _find_edge_ring_neighbours(edge_loops, edge_to_loop)
    _compute_edge_ring_valences(edge_loops, edge_to_loop)
    _find_control_edge_loop(edge_loops, edge_to_loop)

    return sorted(edge_loops, key=lambda el: el.max_valence, reverse=True)


def _find_edge_ring_neighbours(edge_loops: list["EdgeLoopDeformer"], edge_to_loop: dict) -> None:
    """查找边环邻居"""
    for edge_loop in edge_loops:
        for edge in edge_loop.edges:
            if len(edge_loop.get_ring_edges(edge)) == 2:
                continue

            for link_loop in edge.link_loops:
                if len(link_loop.face.verts) != 4:
                    continue

                next_edge = link_loop.link_loop_next.link_loop_next.edge

                if next_edge not in edge_loop.get_ring_edges(edge):
                    if next_edge in edge_to_loop:
                        edge_loop.add_ring_edge(edge, next_edge)
                        edge_to_loop[next_edge].add_ring_edge(next_edge, edge)


def _compute_edge_ring_valences(edge_loops: list["EdgeLoopDeformer"], edge_to_loop: dict) -> None:
    """计算边环价数"""
    for edge_loop in edge_loops:
        max_valence = -1
        for edge in edge_loop.edges:
            valence = 0
            visited = set()
            search = {edge}

            while search:
                current = search.pop()
                visited.add(current)

                loop = edge_to_loop.get(current)
                if loop is None:
                    continue

                ring_edges = loop.get_ring_edges(current)
                add_to_valence = True
                for ring_edge in ring_edges:
                    if ring_edge not in visited:
                        search.add(ring_edge)
                        if add_to_valence:
                            valence += 1
                            add_to_valence = False

            edge_loop.valences.append(valence)
            max_valence = max(max_valence, valence)

        edge_loop.max_valence = max_valence


def _find_control_edge_loop(edge_loops: list["EdgeLoopDeformer"], edge_to_loop: dict) -> None:
    """查找控制边环"""
    for edge_loop in edge_loops:
        for edge in edge_loop.edges:
            if edge in edge_loop.edge_rings:
                continue

            # 松散边(wire edge)无 link_loops: 跳过, 否则 link_loops[0] 抛 IndexError
            # (用户选中一条 wire edge 后运行 Set Edge Flow/Linear/Curve 即可触发)
            if not edge.link_loops:
                continue

            edge_ring = deque([edge.link_loops[0]])
            ends = []
            append_func = edge_ring.append

            for idx, loop in enumerate(edge.link_loops):
                next_loop = loop
                visited = set()

                while True:
                    ring = next_loop.link_loop_prev.link_loop_prev
                    if ring in visited:
                        break
                    visited.add(ring)

                    if ring.edge not in edge_to_loop:
                        ends.append(ring)
                        break

                    append_func(ring)
                    next_loop = ring.link_loop_radial_prev

                    if ring.edge.is_boundary:
                        ends.append(ring)
                        break

                if idx == 0:
                    append_func = edge_ring.appendleft

            for ring in edge_ring:
                if ring.edge in edge_to_loop:
                    edge_to_loop[ring.edge].edge_rings[ring.edge] = edge_ring
                    edge_to_loop[ring.edge].ends[ring.edge] = ends
