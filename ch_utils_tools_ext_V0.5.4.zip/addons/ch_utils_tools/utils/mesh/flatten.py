"""
展平工具模块

提供沿边或法线方向展平顶点和面的功能.

主要功能:
- flatten_verts: 沿边或法线展平顶点
- flatten_faces: 沿边或法线展平面
"""

import bmesh
from bmesh.types import BMesh, BMVert
from mathutils import Vector
from mathutils.geometry import intersect_line_plane, normal


def flatten_verts(verts: list[BMVert], flatten_mode: str) -> tuple[list[Vector] | None, str | None]:
    """
    沿边或法线展平顶点

    根据3个选中顶点确定参考平面,将面上其他顶点投影到该平面.
    支持两种展平模式:沿边方向或沿法线方向.

    Args:
        verts: 选中的3个顶点列表,用于确定参考平面
        flatten_mode: 展平模式, 'EDGE' 为沿边方向, 'NORMAL' 为沿法线方向

    Returns:
        (坐标列表, 错误信息) 元组, 交替包含初始坐标和展平后坐标;
        顶点不足 3 个, 无公共面或三点共线时返回 (None, 错误信息)
    """
    # 需恰好可用的 3 个顶点定义参考平面: 少于 3 个索引会越界, 故先校验
    if len(verts) < 3:
        return None, "Flatten requires at least 3 selected vertices"

    shared_faces = [f for f in verts[0].link_faces
                    if f in verts[1].link_faces and f in verts[2].link_faces]
    if not shared_faces:
        return None, "Flatten requires 3 selected vertices sharing a face"

    face = shared_faces[0]
    flat_verts = [v for v in face.verts if v not in verts]

    plane_normal = normal(verts[0].co, verts[1].co, verts[2].co)
    if plane_normal.length < 1e-9:
        # 三点共线: 无法定义参考平面
        return None, "Flatten requires 3 non-collinear vertices"

    initial_coords = [v.co.copy() for v in flat_verts]

    if flatten_mode == "EDGE":
        vert_pairs = [(v, e.other_vert(v).co.copy()) for v in flat_verts for e in v.link_edges if e not in face.edges]
        flattened_coords = _flatten_along_edges(vert_pairs, verts[0].co, plane_normal)
    else:
        flattened_coords = _flatten_along_normal(flat_verts, verts[0].co, plane_normal)

    coords = []
    for init_co, flat_co in zip(initial_coords, flattened_coords):
        coords.extend([init_co, flat_co])

    return coords, None


def flatten_faces(bm: BMesh, edges: list, flatten_mode: str, dissolve: bool = True) -> list[Vector]:
    """
    沿边或法线展平面

    以活动面为参考平面,将其他选中面的顶点投影到该平面.
    支持两种展平模式:沿边方向或沿法线方向.
    可选择是否在展平后溶解所有选中面.

    Args:
        bm: BMesh对象
        edges: 选中的边列表,用于确定展平方向
        flatten_mode: 展平模式, 'EDGE' 为沿边方向, 'NORMAL' 为沿法线方向
        dissolve: 是否在展平后溶解所有选中面

    Returns:
        坐标列表,交替包含初始坐标和展平后坐标
    """
    flat = bm.faces.active
    faces = [f for f in bm.faces if f.select and f != flat]

    verts = {v for f in faces for v in f.verts if v not in flat.verts}

    if flatten_mode == "EDGE":
        vert_pairs = [(v, e.other_vert(v).co.copy()) for v in verts for e in v.link_edges if e not in edges]
        initial_coords = [v.co.copy() for v, _ in vert_pairs]
        flattened_coords = _flatten_along_edges(vert_pairs, flat.verts[0].co, flat.normal)
    else:
        initial_coords = [v.co.copy() for v in verts]
        flattened_coords = _flatten_along_normal(list(verts), flat.verts[0].co, flat.normal)

    coords = []
    for init_co, flat_co in zip(initial_coords, flattened_coords):
        coords.extend([init_co, flat_co])

    if dissolve:
        geo = bmesh.ops.dissolve_faces(bm, faces=faces + [flat], use_verts=True)

        if geo["region"]:
            new_face = geo["region"][0]
            new_face.select = True

    return coords


def _flatten_along_edges(vert_pairs: list[tuple[BMVert, Vector]], plane_co: Vector, plane_normal: Vector) -> list[Vector]:
    """
    沿边方向展平顶点(内部函数)

    将每个顶点沿其连接边方向投影到指定平面.
    边与平面平行时退化为沿法线投影, 保证输出坐标与输入顶点一一对应.

    Args:
        vert_pairs: 顶点对列表,每对包含(要展平的顶点, 边的另一端坐标)
        plane_co: 平面上的一点
        plane_normal: 平面法向量

    Returns:
        展平后的坐标列表
    """
    coords = []

    for vert, edge_end_co in vert_pairs:
        intersect_co = intersect_line_plane(vert.co, edge_end_co, plane_co, plane_normal)

        if intersect_co is None:
            intersect_co = intersect_line_plane(vert.co, vert.co + plane_normal, plane_co, plane_normal)

        if intersect_co is None:
            intersect_co = vert.co

        vert.co = intersect_co
        coords.append(intersect_co)

    return coords


def _flatten_along_normal(verts: list[BMVert], plane_co: Vector, plane_normal: Vector) -> list[Vector]:
    """
    沿法线方向展平顶点(内部函数)

    将每个顶点沿平面法线方向投影到指定平面.

    Args:
        verts: 要展平的顶点列表
        plane_co: 平面上的一点
        plane_normal: 平面法向量

    Returns:
        展平后的坐标列表
    """
    coords = []

    for vert in verts:
        perp_co = vert.co + plane_normal
        intersect_co = intersect_line_plane(vert.co, perp_co, plane_co, plane_normal)

        if intersect_co is None:
            continue

        vert.co = intersect_co
        coords.append(intersect_co)

    return coords
