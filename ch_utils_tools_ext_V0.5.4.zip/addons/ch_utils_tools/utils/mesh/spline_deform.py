"""
样条变形模块

提供基于样条曲线的顶点路径变形功能.

主要功能:
- map_segment_onto_spline: 将顶点段映射到样条曲线
- curve_hermite: Hermite曲线变形
- circle_3_points: 三点圆变形
- circle_2_points: 两点圆变形
"""

from mathutils import Vector
from mathutils.geometry import intersect_line_line
from bmesh.types import BMesh, BMVert

from .._constants import HERMITE_PRECISION, ARC_SAMPLE_MULTIPLIER
from ..math.interpolation import hermite_3d
from .topology import split_vert_path_into_segments


def _calc_arc_length(positions: list[Vector]) -> float:
    """计算位置列表的总弧长"""
    return sum((positions[i] - positions[i - 1]).magnitude for i in range(1, len(positions)))


def _generate_hermite_spline(p0: Vector, p1: Vector, p2: Vector, p3: Vector, tension: float, precision: int = HERMITE_PRECISION) -> list[Vector]:
    """生成 Hermite 样条曲线上的采样点"""
    bias = 0
    return [Vector(hermite_3d(tuple(p0), tuple(p1), tuple(p2), tuple(p3), i / float(precision), -tension, bias)) for i in range(precision)]


def _generate_arc_positions(start: Vector, middle: Vector, end: Vector, radius: float, center: Vector, samples: int) -> list[Vector]:
    """生成圆弧上的采样点"""
    positions = []
    for sample in range(samples):
        mu = sample / samples
        if mu <= 0.5:
            interpolated = start.slerp(middle, mu * 2.0).normalized() * radius
        else:
            interpolated = middle.slerp(end, (mu - 0.5) * 2.0).normalized() * radius
        positions.append(interpolated + center)
    return positions


def _map_arc_length_segment(segment: list[BMVert], positions: list[Vector], precision_mode: bool = True) -> None:
    """将顶点段按弧长映射到样条位置"""
    segment_len = len(segment)
    if segment_len <= 1:
        return

    total_length = _calc_arc_length(positions)
    segment_part_length = total_length / float(segment_len - 1)

    current_segment_idx = 1
    current_length = 0.0
    positions_len = len(positions)

    for pos_idx in range(1, positions_len):
        current_length += (positions[pos_idx] - positions[pos_idx - 1]).magnitude

        if precision_mode:
            if current_length >= segment_part_length:
                remainder = current_length - segment_part_length
                current_length = current_length % segment_part_length

                p1 = positions[pos_idx - 1]
                p2 = positions[pos_idx]
                p = p1 + (p1 - p2).normalized() * remainder

                if current_segment_idx not in (0, segment_len - 1):
                    segment[current_segment_idx].co = p
                    current_segment_idx += 1
        else:
            if current_length > segment_part_length:
                current_length = 0.0

                if current_segment_idx not in (0, segment_len - 1):
                    segment[current_segment_idx].co = positions[pos_idx]
                    current_segment_idx += 1


def map_segment_onto_spline(segment: list[BMVert], positions: list[Vector]) -> None:
    """
    将顶点段映射到样条曲线上

    计算样条曲线的总弧长,并均匀分布顶点位置.直接修改顶点坐标.

    Args:
        segment: 顶点段列表,首尾顶点位置不变,中间顶点被重新定位
        positions: 样条曲线上的采样点列表
    """
    _map_arc_length_segment(segment, positions, precision_mode=True)


def curve_hermite(bm: BMesh, selected: list[int], vert_path: list[BMVert], tension: float, space_evenly: bool) -> tuple[int, str]:
    """
    使用 Hermite 样条曲线变形顶点路径

    根据选中顶点作为控制点,使用 Hermite 插值生成平滑曲线,
    并将路径上的顶点移动到曲线上的相应位置.

    Args:
        bm: BMesh对象
        selected: 选中顶点的索引列表
        vert_path: 完整的顶点路径列表
        tension: 张力参数,控制曲线的平滑程度
        space_evenly: 是否均匀分布顶点

    Returns:
        元组 (status, message):
        - status: 0表示成功,1表示失败
        - message: 错误信息或空字符串
    """
    knots, segments = split_vert_path_into_segments(bm, selected, vert_path)

    if len(knots) < 3:
        # Hermite 需要前中后三个控制点(首尾分支还要取 knots[idx+2] / knots[-3])
        return 1, 'Path found is too short - try toggling "Edge Distance"'

    total_spline: list[Vector] = []
    segments_count = len(segments)

    for idx, segment in enumerate(segments):
        is_start = idx == 0
        is_end = idx == segments_count - 1

        if not is_start and not is_end:
            p0 = knots[idx - 1].co
            p1 = knots[idx].co
            p2 = knots[idx + 1].co
            p3 = knots[idx + 2].co
        elif is_start:
            p1 = knots[idx].co
            p2 = knots[idx + 1].co
            p3 = knots[idx + 2].co

            delta = p1 - p2
            p3 = p2 - ((p2 - p3).normalized() * delta.magnitude)

            p0 = _find_adjacent_vert_co(knots[idx], segment[idx + 1])
        else:
            p1 = knots[-2].co
            p2 = knots[-1].co

            # 末段镜像控制点: 长度取自本段切线, 不能用上一轮循环遗留的 p0
            # (与 start 分支对称: 该处以 p1 - p0 取长度, 此处对应 p2 - p1)
            delta = p2 - p1
            p0 = knots[-3].co
            p0 = p1 - ((p1 - p0).normalized() * delta.magnitude)

            p3 = _find_adjacent_vert_co(knots[-1], segment[-2])

        spline_points = _generate_hermite_spline(p0, p1, p2, p3, tension)

        if not space_evenly:
            map_segment_onto_spline(segment, spline_points)
        else:
            total_spline.extend(spline_points)

    if space_evenly:
        map_segment_onto_spline(vert_path, total_spline)

    return 0, ""


def _find_adjacent_vert_co(knot_vert: BMVert, adjacent_vert: BMVert) -> Vector:
    """通过拓扑查找相邻顶点的坐标, 添加防御性检查"""
    for corner in knot_vert.link_loops:
        if not corner.link_loop_next:
            continue
        if corner.link_loop_next.vert == adjacent_vert:
            prev_loop = corner.link_loop_prev
            if prev_loop and prev_loop.link_loop_radial_prev and prev_loop.link_loop_radial_prev.link_loop_prev:
                return prev_loop.link_loop_radial_prev.link_loop_prev.vert.co
        elif corner.link_loop_prev.vert == adjacent_vert:
            radial_prev = corner.link_loop_radial_prev
            if radial_prev and radial_prev.link_loop_next and radial_prev.link_loop_next.link_loop_next:
                return radial_prev.link_loop_next.link_loop_next.vert.co
    return Vector((0, 0, 0))


def circle_3_points(bm: BMesh, selected: list[int], vert_path: list[BMVert], tension: float, space_evenly: bool) -> tuple[int, str]:
    """
    使用三点圆弧变形顶点路径

    根据三个选中顶点确定圆弧,并将路径上的顶点移动到圆弧上.
    tension参数控制中间顶点的凸起程度.

    Args:
        bm: BMesh对象
        selected: 选中顶点的索引列表(需要3个)
        vert_path: 完整的顶点路径列表
        tension: 张力参数,控制圆弧的凸起程度,-1为直线
        space_evenly: 是否均匀分布顶点

    Returns:
        元组 (status, message):
        - status: 0表示成功,1表示失败
        - message: 错误信息或空字符串
    """
    knots, segments = split_vert_path_into_segments(bm, selected, vert_path)

    if len(knots) < 3:
        return 1, 'Path found is too short - try toggling "Edge Distance"'

    vert_a = knots[0]
    vert_b = knots[1]
    vert_c = knots[2]

    a = vert_a.co
    b = vert_b.co
    c = vert_c.co

    if tension == -1.0:
        samples = len(vert_path) * ARC_SAMPLE_MULTIPLIER
        positions = [a.lerp(c, sample / samples) for sample in range(samples)]
        map_segment_onto_spline(vert_path, positions)
        return 0, ""

    try:
        center, radius, start, middle, end = _compute_circle_from_three_points(a, b, c, tension)
    except ValueError:
        return 1, "found no intersection"

    if space_evenly:
        samples = len(vert_path) * ARC_SAMPLE_MULTIPLIER
        positions = _generate_arc_positions(start, middle, end, radius, center, samples)
        map_segment_onto_spline(vert_path, positions)
    else:
        _apply_arc_to_segment(segments[0], start, middle, radius, center)
        _apply_arc_to_segment(segments[1], middle, end, radius, center)

    return 0, ""


def _compute_circle_from_three_points(a: Vector, b: Vector, c: Vector, tension: float) -> tuple[Vector, float, Vector, Vector, Vector]:
    """从三点计算圆心, 半径和相对向量

    退化输入(三点共线/重合, 或张力把 b 推到 a-c 连线上)时抛 ValueError,
    由调用方 circle_3_points / circle_2_points 捕获并转为错误元组.
    """
    ac_center = (a + c) * 0.5
    b = b + (b - ac_center).normalized() * tension

    ab = b - a
    bc = c - b

    up = ab.cross(bc).normalized()

    # 共线/重合时 ab×bc 为零向量, normalized() 返回零向量而非报错;
    # 若不在此拦截, 后续 p2/p4 求交为空 -> 误报"无交点", 或写出坏几何后除零
    if up.length < 1e-9:
        raise ValueError("Degenerate three points: no circle can be computed")

    p1 = a + ab * 0.5
    p3 = b + bc * 0.5
    p2 = ab.cross(up).normalized()
    p4 = bc.cross(up).normalized()

    intersection = intersect_line_line(p1, p1 + p2, p3, p3 + p4)

    if not intersection:
        raise ValueError("No intersection found for circle computation")

    center = intersection[0]

    start = a - center
    middle = b - center
    end = c - center

    radius = (a - center).magnitude

    return center, radius, start, middle, end


def _apply_arc_to_segment(segment: list[BMVert], start_vec: Vector, end_vec: Vector, radius: float, center: Vector) -> None:
    """将圆弧应用到顶点段"""
    segment_len = len(segment)
    if segment_len <= 1:
        return
    for idx, vert in enumerate(segment):
        mu = idx / (segment_len - 1)
        interpolated = start_vec.slerp(end_vec, mu).normalized() * radius
        vert.co = interpolated + center


def circle_2_points(bm: BMesh, selected: list[int], vert_path: list[BMVert], tension: float, flip: bool, rotate: bool) -> tuple[int, str]:
    """
    使用两点圆弧变形顶点路径

    在两个选中顶点之间创建半圆弧,并将路径上的顶点移动到圆弧上.
    圆弧方向基于第一个顶点的拓扑结构确定.

    Args:
        bm: BMesh对象
        selected: 选中顶点的索引列表(需要2个)
        vert_path: 完整的顶点路径列表
        tension: 张力参数,控制圆弧的凸起程度,0为直线
        flip: 是否翻转圆弧方向
        rotate: 是否旋转圆弧方向

    Returns:
        元组 (status, message):
        - status: 0表示成功,1表示失败
        - message: 错误信息或空字符串
    """
    tension += 1.0

    if len(selected) < 2 or len(vert_path) < 2:
        return 1, 'Path found is too short - try toggling "Edge Distance"'

    vert_a = bm.verts[selected[0]]
    vert_c = bm.verts[selected[1]]

    a = vert_a.co
    c = vert_c.co

    if tension == 0.0:
        samples = len(vert_path) * ARC_SAMPLE_MULTIPLIER
        positions = [a.lerp(c, sample / samples) for sample in range(samples)]
        map_segment_onto_spline(vert_path, positions)
        return 0, ""

    radius = (a - c).magnitude * 0.5
    normal_dir = vert_a.normal.cross(c - a).normalized()

    if rotate:
        normal_dir = normal_dir.cross(a - c).normalized()

    if flip:
        normal_dir = -normal_dir

    ac_center = (a + c) * 0.5
    b = ac_center + normal_dir * radius * tension

    try:
        center, radius, start, middle, end = _compute_circle_from_three_points(a, b, c, tension=0.0)
    except ValueError:
        return 1, "found no intersection"

    samples = len(vert_path) * ARC_SAMPLE_MULTIPLIER
    positions = _generate_arc_positions(start, middle, end, radius, center, samples)
    map_segment_onto_spline(vert_path, positions)

    return 0, ""
