"""
选择工具模块

提供选择状态检测, 元素验证等功能.

主要功能:
- has_selected_curve_element: 判断曲线元素中是否有选中的顶点
- get_active_element_from_bmesh: 获取网格编辑模式下的活动元素
- is_valid_mesh_edit_selection: 判断是否满足网格编辑选择条件
- is_freestyle_edge: 判断指定索引的边是否为Freestyle边
- get_edge_ngon_face: 判断边连接的面是否为NGON
- is_ngon_face: 判断面是否为NGON
"""

import bmesh
from bpy.types import Context, Object, Mesh
from bmesh.types import BMesh, BMVert, BMEdge, BMFace


def has_selected_curve_element(obj: Object) -> bool:
    """
    判断曲线元素中是否有选中的顶点
    Args:
        obj: 曲线对象
    Returns:
        如果有选中的顶点返回True,否则返回False
    """
    for spl in obj.data.splines:
        if spl.type == 'BEZIER':
            if any(pt.select_control_point for pt in spl.bezier_points):
                return True
        elif spl.type in {'NURBS', 'POLY'}:
            if any(pt.select for pt in spl.points):
                return True
    return False


def get_active_element_from_bmesh(context: Context, bm: BMesh) -> BMVert | BMEdge | BMFace | None:
    """
    获取网格编辑模式下的活动元素
    Args:
        context: 上下文
        bm: BMesh对象
    Returns:
        活动元素(BMVert, BMEdge 或 BMFace),如果没有则返回 None
    """
    if bm.select_history:
        return bm.select_history.active

    sel_mode = context.scene.tool_settings.mesh_select_mode
    if sel_mode[2]:
        return next((f for f in bm.faces if f.select), None)
    elif sel_mode[1]:
        return next((e for e in bm.edges if e.select), None)
    elif sel_mode[0]:
        return next((v for v in bm.verts if v.select), None)
    return None


def is_valid_mesh_edit_selection(context: Context, element_type: str) -> bool:
    """
    判断是否满足网格编辑选择条件:
    活动物体有且仅有一个选中元素,选中物体中至少有一个有且仅有一个选中元素
    Args:
        context: 上下文
        element_type: 要检查的元素类型 ('verts', 'edges', 'faces')
    Returns:
        是否满足条件
    """
    if context.mode != "EDIT_MESH":
        return False

    act_obj = context.active_object
    sel_objs = [obj for obj in context.selected_objects if obj.type == 'MESH' and obj != act_obj]
    if not (act_obj and sel_objs):
        return False

    bm_act = bmesh.from_edit_mesh(act_obj.data)
    act_count = sum(1 for elem in getattr(bm_act, element_type) if elem.select)
    if act_count != 1:
        return False

    for obj in sel_objs:
        bm = bmesh.from_edit_mesh(obj.data)
        count = sum(1 for elem in getattr(bm, element_type) if elem.select)
        if count == 1:
            return True

    return False


def is_freestyle_edge(data: Mesh, idx: int) -> bool:
    """
    判断指定索引的边是否为Freestyle边
    Args:
        data: 网格数据
        idx: 边索引
    Returns:
        如果边标记为Freestyle边返回True,否则返回False
    """
    if idx >= len(data.edges):
        return False

    fs = data.attributes.get('freestyle_edge')
    if fs:
        return fs.data[idx].value

    return False


def get_edge_ngon_face(edge: BMEdge) -> BMFace | None:
    """
    判断边连接的面是否为NGON
    Args:
        edge: 边
    Returns:
        如果边连接的面为NGON则返回该面, 否则返回None
    """
    for f in edge.link_faces:
        if len(f.verts) > 4:
            return f
    return None


def is_ngon_face(face: BMFace) -> bool:
    """
    判断面是否为NGON
    Args:
        face: 面
    Returns:
        如果面为NGON则返回True,否则返回False
    """
    return len(face.verts) > 4
