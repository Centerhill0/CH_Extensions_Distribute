"""
GPU绘制模块

提供点, 线, 面, 文本等GPU绘制功能.

主要功能:
- draw_label: 绘制文本标签
- draw_point: 绘制单个点
- draw_points: 批量绘制点
- draw_line: 绘制连续线段
- draw_lines: 批量绘制线段
- draw_vector: 绘制向量
- draw_tris: 绘制三角面
- draw_circle: 绘制圆形
- draw_mesh_wire: 绘制网格线框

注: 绘制属性初始化(draw_init)已收编至插件根 modal_base.py 的 ModalOperatorMixin.
注: 全部绘制函数的实际透明度 = 入参 alpha * 全局透明度系数(_hud_opacity), 系数由
    插件根 modal_base.py 经 set_hud_opacity 同步自偏好设置(utils 禁止反向导入插件
    顶层模块, 故由根层单向下发).
"""

import blf
import gpu
from bpy.types import Context
from mathutils import Vector, Matrix, Quaternion
from gpu_extras.batch import batch_for_shader
from math import pi, cos, sin

from .._constants import HUD_BASE_FONT_SIZE, HUD_DEFAULT_FONT_ID
from ..blender.scene import get_ui_scale
from ..math.transform import transform_normal_to_world

_UNSET = object()

# HUD绘制全局透明度系数, 初始为 1.0, 由插件根 modal_base 经 set_hud_opacity 下发
# (utils 禁止反向导入插件顶层模块读取偏好, 采用根层写入的单向下发)
_hud_opacity: float = 1.0


def set_hud_opacity(opacity: float) -> None:
    """
    设置HUD绘制的全局透明度系数

    作用于全部 draw_* 函数: 实际透明度 = 入参 alpha * 系数.
    供插件根 modal_base 在绘制回调中同步偏好设置, 本模块不反向读取偏好.

    Args:
        opacity: 全局透明度系数(0~1, 0 时HUD完全不可见)
    """
    global _hud_opacity
    _hud_opacity = opacity


def draw_label(
    context: Context,
    title: str = "",
    coords: Vector | None = None,
    offset: float | object = _UNSET,
    font_id: int | object = _UNSET,
    center: bool | object = _UNSET,
    size: float | object = _UNSET,
    color: tuple[float, float, float] | object = _UNSET,
    alpha: float | object = _UNSET,
    scale: float | None = None,
    init_obj=None,
):
    """
    在屏幕上绘制文本标签

    Args:
        context: Blender上下文
        title: 要绘制的文本内容
        coords: 文本位置坐标元组(width, height),None则使用屏幕中心
        offset: 垂直偏移量,未传时从init_obj.offset兜底,再退回0
        font_id: 字体ID,未传时从init_obj.font_id兜底,再退回1
        center: 是否以文本中心为基准点,未传时从init_obj.center兜底,再退回True
        size: 字体大小(像素),未传时从init_obj.size兜底,再退回12
        color: 文本颜色RGB元组,未传时从init_obj.color兜底,再退回白色
        alpha: 文本透明度,未传时从init_obj.alpha兜底,再退回1.0
        scale: 总缩放系数(UI缩放*HUD缩放),为None时仅使用Blender UI缩放;
            模态算子应传 scale=self.hud_scale 以应用插件偏好中的HUD缩放
        init_obj: 绘制属性兜底来源(通常为调用了draw_init的算子实例)
    Returns:
        Vector: 文本的尺寸向量(width, height)
    """
    if offset is _UNSET:
        offset = getattr(init_obj, 'offset', 0) if init_obj else 0
    if font_id is _UNSET:
        font_id = getattr(init_obj, 'font_id', HUD_DEFAULT_FONT_ID) if init_obj else HUD_DEFAULT_FONT_ID
    if center is _UNSET:
        center = getattr(init_obj, 'center', True) if init_obj else True
    if size is _UNSET:
        size = getattr(init_obj, 'size', HUD_BASE_FONT_SIZE) if init_obj else HUD_BASE_FONT_SIZE
    if color is _UNSET:
        color = getattr(init_obj, 'color', (1.0, 1.0, 1.0)) if init_obj else (1.0, 1.0, 1.0)
    if alpha is _UNSET:
        alpha = getattr(init_obj, 'alpha', 1.0) if init_obj else 1.0
    alpha *= _hud_opacity

    if not coords:
        region = context.region
        width, height = region.width / 2, region.height / 2
    else:
        width, height = coords

    if scale is None:
        scale = get_ui_scale()
    fontsize = int(size * scale)

    blf.size(font_id, fontsize)
    blf.color(font_id, *color, alpha)

    if center:
        dims = blf.dimensions(font_id, title)
        blf.position(font_id, width - dims[0] / 2, height - (offset * scale), 0)
    else:
        blf.position(font_id, width, height - (offset * scale), 0)

    blf.draw(font_id, title)
    return Vector(blf.dimensions(font_id, title))


def draw_point(
    co: Vector,
    mx: Matrix = Matrix(),
    color: tuple[float, float, float] = (1, 1, 1),
    size: float = 6,
    alpha: float = 1,
    xray: bool = True,
):
    """
    绘制单个点到3D视图
    Args:
        co: 点坐标(Vector)
        mx: 变换矩阵
        color: 颜色RGB元组
        size: 点大小
        alpha: 透明度
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        shader = gpu.shader.from_builtin('POINT_UNIFORM_COLOR')
        shader.bind()
        shader.uniform_float("color", (*color, alpha))
        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA' if alpha < 1 else 'NONE')
        gpu.state.point_size_set(size)
        batch = batch_for_shader(shader, 'POINTS', {"pos": [mx @ co]})
        batch.draw(shader)

    draw()


def draw_points(
    coords: list[Vector],
    indices: list[tuple[int, int]] | None = None,
    mx: Matrix = Matrix(),
    color: tuple[float, float, float] = (1, 1, 1),
    size: float = 6,
    alpha: float = 1,
    xray: bool = True,
):
    """
    批量绘制多个点到3D视图
    Args:
        coords: 点坐标序列
        indices: 指定索引序列(可选)
        mx: 变换矩阵
        color: 颜色RGB元组
        size: 点大小
        alpha: 透明度
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        shader = gpu.shader.from_builtin('POINT_UNIFORM_COLOR')
        shader.bind()
        shader.uniform_float("color", (*color, alpha))
        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA' if alpha < 1 else 'NONE')
        gpu.state.point_size_set(size)

        pos = [mx @ co for co in coords] if mx != Matrix() else coords
        batch = batch_for_shader(shader, 'POINTS', {"pos": pos}, indices=indices)
        batch.draw(shader)

    draw()


def draw_line(
    coords: list[Vector],
    indices: list[tuple[int, int]] | None = None,
    mx: Matrix = Matrix(),
    color: tuple[float, float, float] = (1, 1, 1),
    alpha: float = 1,
    width: float = 1,
    xray: bool = True,
):
    """
    绘制连续线段(折线)到3D视图
    Args:
        coords: 顶点坐标序列
        indices: 线段索引序列(可选)
        mx: 变换矩阵
        color: 颜色RGB元组
        alpha: 透明度
        width: 线宽
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        nonlocal indices
        if indices is None:
            indices = [(i, i + 1) for i in range(len(coords) - 1)]

        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA')

        shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        shader.bind()
        shader.uniform_float("color", (*color, alpha))
        shader.uniform_float("lineWidth", width)
        shader.uniform_float("viewportSize", gpu.state.scissor_get()[2:])

        batch = batch_for_shader(shader, 'LINES', {"pos": [mx @ co for co in coords]}, indices=indices)
        batch.draw(shader)

    draw()


def draw_lines(
    coords: list[Vector],
    indices: list[tuple[int, int]] | None = None,
    mx: Matrix = Matrix(),
    color: tuple[float, float, float] = (1, 1, 1),
    width: float = 1,
    alpha: float = 1,
    xray: bool = True,
):
    """
    批量绘制多条独立线段到3D视图
    Args:
        coords: 顶点坐标序列
        indices: 线段索引序列(可选)
        mx: 变换矩阵
        color: 颜色RGB元组
        width: 线宽
        alpha: 透明度
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        nonlocal indices
        if not indices:
            indices = [(i, i + 1) for i in range(0, len(coords), 2)]

        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA')

        shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        shader.bind()
        shader.uniform_float("color", (*color, alpha))
        shader.uniform_float("lineWidth", width)
        shader.uniform_float("viewportSize", gpu.state.scissor_get()[2:])

        batch = batch_for_shader(shader, 'LINES', {"pos": [mx @ co for co in coords]}, indices=indices)
        batch.draw(shader)

    draw()


def draw_vector(
    vector: Vector,
    origin: Vector = Vector((0, 0, 0)),
    mx: Matrix = Matrix(),
    color: tuple[float, float, float] = (1, 1, 1),
    width: float = 1,
    alpha: float = 1,
    fade: bool = False,
    normal: bool = False,
    xray: bool = True,
):
    """
    绘制一个向量(箭头线段)到3D视图
    Args:
        vector: 向量
        origin: 起点
        mx: 变换矩阵
        color: 颜色RGB元组
        width: 线宽
        alpha: 透明度
        fade: 是否渐变尾部
        normal: 是否以法线变换
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        if normal:
            end_point = mx @ origin + transform_normal_to_world(vector, mx)
        else:
            end_point = mx @ origin + mx.to_3x3() @ vector

        coords = [mx @ origin, end_point]
        colors = ((*color, alpha), (*color, alpha / 10 if fade else alpha))

        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA')

        shader = gpu.shader.from_builtin('POLYLINE_SMOOTH_COLOR')
        shader.bind()
        shader.uniform_float("lineWidth", width)
        shader.uniform_float("viewportSize", gpu.state.scissor_get()[2:])

        batch = batch_for_shader(shader, 'LINES', {"pos": coords, "color": colors})
        batch.draw(shader)

    draw()


def draw_tris(
    coords: list[Vector],
    indices: list[tuple[int, int, int]] | None = None,
    mx: Matrix = Matrix(),
    color: tuple[float, float, float] = (1, 1, 1),
    alpha: float = 1,
    xray: bool = True,
):
    """
    绘制三角面片到3D视图

    Args:
        coords: 顶点坐标序列
        indices: 三角面索引序列(可选)
        mx: 变换矩阵
        color: 颜色RGB元组
        alpha: 透明度
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        shader.bind()
        shader.uniform_float("color", (*color, alpha))
        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA' if alpha < 1 else 'NONE')

        pos = [mx @ co for co in coords] if mx != Matrix() else coords
        batch = batch_for_shader(shader, 'TRIS', {"pos": pos}, indices=indices)
        batch.draw(shader)

    draw()


def draw_circle(
    loc: Vector = Vector(),
    rot: Quaternion = Quaternion(),
    radius: float = 100,
    segments: int | str = 'AUTO',
    width: float = 1,
    color: tuple[float, float, float] = (1, 1, 1),
    alpha: float = 1,
    xray: bool = True,
):
    """
    绘制圆形到3D视图

    Args:
        loc: 圆心位置
        rot: 旋转四元数
        radius: 半径
        segments: 分段数,'AUTO'时根据半径自动计算
        width: 线宽
        color: 颜色RGB元组
        alpha: 透明度
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        nonlocal segments

        seg_count = max(int(radius), 16) if segments == 'AUTO' else max(segments, 16)
        indices = [(i, i + 1) if i < seg_count - 1 else (i, 0) for i in range(seg_count)]

        coords = [Vector((loc.x + radius * cos(2 * pi * i / seg_count), loc.y + radius * sin(2 * pi * i / seg_count), 0)) for i in range(seg_count)]

        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA')

        shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        shader.uniform_float("color", (*color, alpha))
        shader.uniform_float("lineWidth", width)
        shader.uniform_float("viewportSize", gpu.state.scissor_get()[2:])
        shader.bind()

        batch = batch_for_shader(shader, 'LINES', {"pos": [rot @ co for co in coords]}, indices=indices)
        batch.draw(shader)

    draw()


def draw_mesh_wire(
    batch: tuple[list[Vector], list[tuple[int, int]]],
    color: tuple[float, float, float] = (1, 1, 1),
    width: float = 1,
    alpha: float = 1,
    xray: bool = True,
):
    """
    绘制网格线框到3D视图

    Args:
        batch: 包含(coords, indices)的元组
        color: 颜色RGB元组
        width: 线宽
        alpha: 透明度
        xray: 是否透视显示
    """
    alpha *= _hud_opacity

    def draw():
        coords, indices = batch

        gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
        gpu.state.blend_set('ALPHA')

        shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        shader.bind()
        shader.uniform_float("color", (*color, alpha))
        shader.uniform_float("lineWidth", width)
        shader.uniform_float("viewportSize", gpu.state.scissor_get()[2:])

        shader_batch = batch_for_shader(shader, 'LINES', {"pos": coords}, indices=indices)
        shader_batch.draw(shader)

    draw()
