"""
模态事件工具模块

提供模态操作的事件判断与状态栏绘制项等纯函数.
算子实例型辅助方法(状态栏初始化/模态处理器/计时器/修饰键等)已收编至插件根 modal_base.py 的 ModalOperatorMixin.

主要功能:
- draw_status_item: 绘制状态栏项
- force_ui_update: 强制UI刷新
- force_statusbar_redraw: 强制状态栏刷新
- ignore_events: 判断是否忽略事件
- scroll: 判断滚动事件
- scroll_up: 判断向上滚动
- scroll_down: 判断向下滚动
- navigation_passthrough: 判断导航事件
"""

from bpy.types import Event, Context, UILayout

from .._constants import NUMBERS_MAP


def draw_status_item(layout: UILayout, active=True, alert=False, key=None, text="", prop=None, gap=None):
    """
    在状态栏绘制一项操作提示
    Args:
        layout: Blender UI 布局对象
        active: 是否激活该行
        alert: 是否高亮警告
        key: 按键(str/int或list)
        text: 显示的文本
        prop: 显示的属性值
        gap: 左侧分隔宽度
    Returns:
        Blender 按键事件字符串
    """
    if key is None:
        key = []

    row = layout.row(align=True)
    row.active = active
    row.alert = alert

    keys = [key] if isinstance(key, (str, int)) else key

    if gap:
        row.separator(factor=gap)

    _draw_key_icons(row, [_get_event_string_from_key(k) for k in keys])

    if prop is not None:
        row.label(text=f"{text}: {prop}" if text else str(prop))
    elif text:
        row.label(text=text)


def force_ui_update(context: Context, active=None):
    """
    强制刷新Blender界面
    Args:
        context: Blender 上下文
        active: 指定激活对象(可选)
    """
    if context.mode == 'OBJECT':
        if active:
            active.select_set(True)
        else:
            if active := context.active_object:
                active.select_set(active.select_get())
            if visible := context.visible_objects:
                visible[0].select_set(visible[0].select_get())

    elif context.mode == 'EDIT_MESH':
        context.active_object.select_set(True)

    elif context.mode == 'EDIT_CURVE':
        curve = context.active_object.data
        for spline in curve.splines:
            for point in spline.points:
                if not point.hide:
                    point.select = point.select


def force_statusbar_redraw(context: Context):
    """
    强制刷新状态栏
    Args:
        context: Blender 上下文
    """
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'STATUSBAR':
                area.tag_redraw()


def ignore_events(event: Event, none=True, timer=True, timer_report=True):
    """
    判断事件类型是否应被忽略
    Args:
        event: Blender事件对象
        none: 是否忽略 'NONE' 事件
        timer: 是否忽略所有定时器相关事件
        timer_report: 是否忽略 'TIMER_REPORT' 事件
    Returns:
        若事件应被忽略则为True
    """
    ignore_types = ['INBETWEEN_MOUSEMOVE', 'WINDOW_DEACTIVATE']
    if none:
        ignore_types.append('NONE')
    if timer:
        ignore_types.extend(['TIMER', 'TIMER1', 'TIMER2', 'TIMER3'])
    if timer_report:
        ignore_types.append('TIMER_REPORT')

    return event.type in ignore_types


def scroll(event: Event, wheel: bool = True, pad: bool = True, key: bool = True) -> bool:
    """
    判断事件是否为滚动操作 (上/下)
    Args:
        event: Blender 事件对象
        wheel: 是否检测鼠标滚轮事件
        pad: 是否检测触控板平移事件
        key: 是否检测键盘按键事件
    Returns:
        如果是滚动操作返回 True
    """
    return scroll_up(event, wheel=wheel, pad=pad, key=key) or scroll_down(event, wheel=wheel, pad=pad, key=key)


_SCROLL_UP_KEYS: set[str] = {'ONE', 'UP_ARROW', 'PLUS', 'NUMPAD_PLUS'}
_SCROLL_DOWN_KEYS: set[str] = {'TWO', 'DOWN_ARROW', 'MINUS', 'NUMPAD_MINUS'}


def scroll_up(event: Event, wheel: bool = True, pad: bool = True, key: bool = True) -> bool:
    """
    判断事件是否为向上滚动操作
    Args:
        event: Blender 事件对象
        wheel: 是否检测鼠标滚轮事件
        pad: 是否检测触控板平移事件
        key: 是否检测键盘按键事件
    Returns:
        如果是向上滚动返回 True
    """
    if wheel and event.type == 'WHEELUPMOUSE':
        return True

    if pad and event.type == 'TRACKPADPAN':
        delta_y = event.mouse_y - event.mouse_prev_y
        if delta_y >= 5:
            return True

    if event.value != 'PRESS':
        return False

    if key and event.type in _SCROLL_UP_KEYS:
        return True

    return False


def scroll_down(event: Event, wheel: bool = True, pad: bool = True, key: bool = True) -> bool:
    """
    判断事件是否为向下滚动操作
    Args:
        event: Blender 事件对象
        wheel: 是否检测鼠标滚轮事件
        pad: 是否检测触控板平移事件
        key: 是否检测键盘按键事件
    Returns:
        如果是向下滚动返回 True
    """
    if wheel and event.type == 'WHEELDOWNMOUSE':
        return True

    if pad and event.type == 'TRACKPADPAN':
        delta_y = event.mouse_prev_y - event.mouse_y
        if delta_y >= 5:
            return True

    if event.value != 'PRESS':
        return False

    if key and event.type in _SCROLL_DOWN_KEYS:
        return True

    return False


def navigation_passthrough(event: Event, alt=True, wheel=False) -> bool:
    """
    判断事件是否应该传递给导航系统处理
    Args:
        event: Blender事件对象
        alt: 是否考虑Alt键修饰的鼠标点击事件
        wheel: 是否考虑鼠标滚轮事件
    Returns:
        如果事件应该传递给导航系统则返回True
    """
    if event.type == 'MIDDLEMOUSE' and event.value == 'PRESS':
        return True

    if event.type.startswith('NDOF'):
        return True

    if alt and event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} and event.value == 'PRESS':
        return True

    if wheel and event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
        return True

    return False


def _get_event_string_from_key(key) -> str:
    """
    根据按键名/编号返回Blender事件字符串
    Args:
        key: 按键名或编号
    Returns:
        Blender 事件字符串
    """
    if key in range(10):
        numbers = {v: k for k, v in NUMBERS_MAP.items()}
        return f"EVENT_{numbers[key]}KEY"
    if key in {'LMB', 'MMB', 'RMB', 'LMB_DRAG', 'LMB_2X', 'MMB_DRAG', 'MMB_SCROLL', 'RMB_DRAG', 'MOVE'}:
        return f"MOUSE_{key}"
    if key in {'COMMAND', 'CONTROL', 'EMPTY1', 'EMPTY2', 'EMPTY3', 'MENU', 'RING', 'OPTION', 'WINDOWS'}:
        return f"KEY_{key}"
    if key == 'SPACE':
        return "EVENT_SPACEKEY"
    return f"EVENT_{key}"


def _draw_key_icons(layout: UILayout, key) -> None:
    """
    在UI中绘制按键图标
    Args:
        layout: Blender UI 布局对象
        key: 按键图标名(str或list)
    """
    keys = [key] if isinstance(key, str) else key
    for icon in keys:
        layout.label(text='', icon=icon)

        if icon in ['KEY_EMPTY2', 'EVENT_CTRL', 'EVENT_ALT', 'EVENT_OS', 'EVENT_F10', 'EVENT_F11', 'EVENT_F12', 'EVENT_ESC', 'EVENT_PAUSE', 'EVENT_INSERT', 'EVENT_HOME', 'EVENT_END', 'EVENT_APP', 'EVENT_BACKSPACE', 'EVENT_DEL']:
            layout.separator(factor=1.5)
        elif icon in ['KEY_EMPTY3', 'EVENT_SPACEKEY']:
            layout.separator(factor=3)
