"""
倒角几何体处理工具模块

提供圆角转倒角, 倒角转硬边, 倒角转向, 三角角点处理等功能.

主要功能:
- fillet_to_chamfer: 将圆角面反向融合为倒角面
- unchamfer_loop_intersection: 通过循环边交点计算倒角转硬边
- unchamfer_face_intersection: 通过面法线交点计算倒角转硬边
"""

import bmesh
from bmesh.types import BMesh, BMVert
from mathutils.geometry import intersect_line_line

from .types import SweepData
from ..math.geometry import get_lerp_position


def fillet_to_chamfer(bm: BMesh, sweeps: list[tuple[BMVert, BMVert]]) -> tuple[list, None] | tuple[None, str]:
    """
    将圆角面反向融合为倒角面

    通过溶解边和顶点,将圆角几何体转换回倒角几何体.

    Args:
        bm: BMesh对象
        sweeps: 扫描顶点对列表

    Returns:
        (结果, 错误信息) 元组:
        - 成功: (倒角面列表, None)
        - 失败: (None, 错误信息), 由调用方决定如何呈现
    """
    edge_loops = []
    edge_loop_verts = []

    for sweep in sweeps[1:-1]:
        edge = bm.edges.get(sweep)
        edge_loops.append(edge)
        edge_loop_verts.extend(sweep)

        for loop in edge.link_loops:
            while len(loop.vert.link_edges) == 4:
                loop = loop.link_loop_prev.link_loop_radial_prev.link_loop_prev

                next_edge = loop.edge
                if next_edge in edge_loops:
                    break

                edge_loops.append(next_edge)
                edge_loop_verts.extend([v for v in next_edge.verts if v not in edge_loop_verts])

    remove_edge_loops = []
    edge_loop_faces = []

    for edge in edge_loops:
        for face in edge.link_faces:
            if face in edge_loop_faces:
                continue

            if len(face.verts) == 4:
                edge_loop_faces.append(face)
                face.select = True
            else:
                remove_edge_loops.append(edge)

    for edge in remove_edge_loops:
        if edge in edge_loops:
            edge_loops.remove(edge)
        for vert in edge.verts:
            if vert in edge_loop_verts:
                edge_loop_verts.remove(vert)

    other_faces = [f for f in bm.faces if f not in edge_loop_faces]

    try:
        bmesh.ops.dissolve_edges(bm, edges=edge_loops)
        bmesh.ops.dissolve_verts(bm, verts=edge_loop_verts)
        bm.verts.ensure_lookup_table()

        bm.select_flush(True)

        chamfer_faces = [f for f in bm.faces if f.select and f not in other_faces]

        for face in other_faces:
            if face.is_valid and face.select:
                face.select = False

        return chamfer_faces, None

    except Exception:
        return None, "You can't un-fuse bevels with triangular corners. Turn them into Quad Corners first!"


def unchamfer_loop_intersection(bm: BMesh, sweeps: list[SweepData]) -> list[BMVert] | None:
    """
    通过循环边交点计算倒角转硬边的顶点位置

    将每对顶点移动到两条循环边的交点处,实现倒角面的合并.
    该函数用于 unchamfer 操作的 LOOP 手柄方法.

    Args:
        bm: BMesh对象
        sweeps: 扫描数据列表,每个元素包含 verts 和 handles

    Returns:
        双顶点对列表,用于后续合并操作; 交点计算失败返回None
    """
    double_verts = []

    for face in bm.faces:
        face.select_set(False)

    for sweep in sweeps:
        v_left = sweep.verts[0]
        v_right = sweep.verts[1]

        handle_left_co = sweep.handles[0]
        handle_right_co = sweep.handles[1]

        intersection = intersect_line_line(v_left.co, handle_left_co, v_right.co, handle_right_co)

        if not intersection:
            return None

        v_left.co = intersection[0]
        v_right.co = intersection[0]

        v_left.select = True
        v_right.select = True
        bm.select_flush(True)

        double_verts.extend([v_left, v_right])

    return double_verts


def unchamfer_face_intersection(bm: BMesh, sweeps: list[SweepData], slide: float = 0) -> list[BMVert]:
    """
    通过面法线交点计算倒角转硬边的顶点位置

    将每对顶点移动到两个手柄之间的插值位置,支持滑动参数.
    该函数用于 unchamfer 操作的 FACE 手柄方法.

    Args:
        bm: BMesh对象
        sweeps: 扫描数据列表,每个元素包含 verts 和 handles
        slide: 滑动参数,范围 [-1, 1],控制顶点在手柄连线上的位置
            -1: 顶点在手柄1位置
            0: 顶点在手柄中点
            1: 顶点在手柄2位置

    Returns:
        双顶点对列表,用于后续合并操作
    """
    double_verts = []

    for face in bm.faces:
        face.select_set(False)

    for sweep in sweeps:
        v_left = sweep.verts[0]
        v_right = sweep.verts[1]

        handle_left_co = sweep.handles[0]
        handle_right_co = sweep.handles[1]

        remapped_factor = slide * 0.5 + 0.5
        slided_position = get_lerp_position(handle_left_co, handle_right_co, remapped_factor)

        v_left.co = slided_position
        v_right.co = slided_position

        v_left.select = True
        v_right.select = True
        bm.select_flush(True)
        double_verts.extend([v_left, v_right])

    return double_verts
