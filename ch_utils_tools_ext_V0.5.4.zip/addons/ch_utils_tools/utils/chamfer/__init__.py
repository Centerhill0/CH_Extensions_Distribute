"""
倒角/圆角核心算法子包

公共 API 经由本 __init__ 再导出至 utils 顶层命名空间;
未在此列出的模块成员为子包内部协作 API, 仅供 utils 内部使用.
"""

from .chamfer_ops import (
    fillet_to_chamfer,
    unchamfer_loop_intersection,
    unchamfer_face_intersection,
)
from .edge_mark import (
    set_rail_sharps_and_bweights,
    set_sharps_and_bweights,
    set_sweep_sharps_and_bweights,
    clear_rail_sharps_and_bweights,
)
from .handle import (
    create_loop_intersection_handles,
    create_face_intersection_handles,
)
from .loop import get_loops
from .sweep import (
    init_sweeps,
    get_2_rails_from_chamfer,
    get_sweeps_from_fillet,
    change_width,
    create_splines,
    fuse_surface,
)
from .types import (
    RailData,
    LoopData,
    SweepData,
    as_layers,
)

__all__ = [
    "fillet_to_chamfer",
    "unchamfer_loop_intersection",
    "unchamfer_face_intersection",
    "set_rail_sharps_and_bweights",
    "set_sharps_and_bweights",
    "set_sweep_sharps_and_bweights",
    "clear_rail_sharps_and_bweights",
    "create_loop_intersection_handles",
    "create_face_intersection_handles",
    "get_loops",
    "init_sweeps",
    "get_2_rails_from_chamfer",
    "get_sweeps_from_fillet",
    "change_width",
    "create_splines",
    "fuse_surface",
    "RailData",
    "LoopData",
    "SweepData",
    "as_layers",
]
