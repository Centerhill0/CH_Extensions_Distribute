"""
贝塞尔手柄计算模块(倒角专用)

提供贝塞尔手柄计算功能, 用于倒角转圆角操作.

主要功能:
- create_loop_intersection_handles: 通过循环边交点创建贝塞尔手柄
- create_face_intersection_handles: 通过面法线交点创建贝塞尔手柄
"""

import math
import mathutils

from ..math.geometry import get_distance_between_points


def create_loop_intersection_handles(sweeps: list, tension: float):
    """
    通过循环边交点创建贝塞尔手柄
    计算每个sweep顶点的手柄位置,用于构建平滑的倒角曲线
    Args:
        sweeps: 扫描数据列表
        tension: 手柄张力系数(0-1),控制曲线弯曲程度
    """
    for sweep in sweeps:
        edge = sweep.edges[0]
        edge_length = edge.calc_length()

        v_left = sweep.verts[0]
        v_right = sweep.verts[1]

        loop_left = sweep.loops[0]
        loop_left_dir = v_left.co - loop_left.co

        loop_right = sweep.loops[1]
        loop_right_dir = v_right.co - loop_right.co

        loop_angle = math.degrees(loop_left_dir.angle(loop_right_dir))

        intersect = mathutils.geometry.intersect_line_line(v_left.co, loop_left.co, v_right.co, loop_right.co)

        if intersect is None and 178 <= loop_angle <= 182:
            intersect_left_full = mathutils.geometry.intersect_point_line(v_right.co, v_left.co, loop_left.co)[0]
            intersect_right_full = mathutils.geometry.intersect_point_line(v_left.co, v_right.co, loop_right.co)[0]

            intersect_left = v_left.co + (intersect_left_full - v_left.co)
            intersect_right = v_right.co + (intersect_right_full - v_right.co)
            intersect = (intersect_left, intersect_right)

        elif intersect is None and -2 <= loop_angle <= 2:
            intersect_left = v_left.co + (loop_left.co - v_left.co).normalized()
            intersect_right = v_right.co + (loop_right.co - v_right.co).normalized()
            intersect = (intersect_left, intersect_right)

        if v_left.co == intersect[0] or v_right.co == intersect[1]:
            intersect_left = v_left.co + (loop_left.co - v_left.co).normalized()
            intersect_right = v_right.co + (loop_right.co - v_right.co).normalized()
            intersect = (intersect_left, intersect_right)

        handle_left_co = v_left.co + ((intersect[0] - v_left.co) * tension)
        handle_right_co = v_right.co + ((intersect[1] - v_right.co) * tension)

        handle_left_dir = handle_left_co - v_left.co
        handle_right_dir = handle_right_co - v_right.co

        dot_left = loop_left_dir.dot(handle_left_dir)
        dot_right = loop_right_dir.dot(handle_right_dir)

        if dot_left < 0:
            handle_left_co = v_left.co + loop_left_dir.normalized() * handle_left_dir.length
            handle_left_dir = handle_left_co - v_left.co

        if dot_right < 0:
            handle_right_co = v_right.co + loop_right_dir.normalized() * handle_right_dir.length
            handle_right_dir = handle_right_co - v_right.co

        handle_left_dist = get_distance_between_points(v_left.co, handle_left_co)
        handle_right_dist = get_distance_between_points(v_right.co, handle_right_co)

        handle_left_ratio = handle_left_dist / edge_length
        handle_right_ratio = handle_right_dist / edge_length

        handle_dir_angle = handle_left_dir.angle(handle_right_dir) + 0.0001

        ideal_ratio = tension / handle_dir_angle
        max_ratio = tension + ideal_ratio

        if handle_left_ratio > max_ratio or handle_right_ratio > max_ratio:
            if handle_left_ratio > max_ratio:
                intersect_left_full = mathutils.geometry.intersect_point_line(v_right.co, v_left.co, loop_left.co)[0]
                handle_left_co = v_left.co + (intersect_left_full - v_left.co) * tension

            if handle_right_ratio > max_ratio:
                intersect_right_full = mathutils.geometry.intersect_point_line(v_left.co, v_right.co, loop_right.co)[0]
                handle_right_co = v_right.co + (intersect_right_full - v_right.co) * tension

        sweep.handles = [handle_left_co, handle_right_co]


def create_face_intersection_handles(sweeps: list, tension: float, average: bool = False):
    """
    通过面法线交点创建贝塞尔手柄
    使用相邻面的平均法线计算手柄位置,适用于复杂拓扑
    Args:
        sweeps: 扫描数据列表
        tension: 手柄张力系数(0-1),控制曲线弯曲程度
        average: 是否平均左右手柄长度
    """
    for sweep in sweeps:
        v_left = sweep.verts[0]
        v_right = sweep.verts[1]

        loop_left = sweep.loops[0]
        loop_left_dir = v_left.co - loop_left.co

        loop_right = sweep.loops[1]
        loop_right_dir = v_right.co - loop_right.co

        normal_left = sweep.avg_face_normals[0]
        normal_right = sweep.avg_face_normals[1]

        intersect_left_co = mathutils.geometry.intersect_line_plane(v_left.co, loop_left.co, v_right.co, normal_right)
        intersect_right_co = mathutils.geometry.intersect_line_plane(v_right.co, loop_right.co, v_left.co, normal_left)

        if not all([intersect_left_co, intersect_right_co]):
            create_loop_intersection_handles([sweep], tension)
            continue

        handle_left_co = v_left.co + ((intersect_left_co - v_left.co) * tension)
        handle_right_co = v_right.co + ((intersect_right_co - v_right.co) * tension)

        handle_left_dir = handle_left_co - v_left.co
        handle_right_dir = handle_right_co - v_right.co

        dot_left = loop_left_dir.dot(handle_left_dir)
        dot_right = loop_right_dir.dot(handle_right_dir)

        if dot_left < 0:
            handle_left_co = v_left.co + loop_left_dir.normalized() * handle_left_dir.length
            handle_left_dir = handle_left_co - v_left.co

        if dot_right < 0:
            handle_right_co = v_right.co + loop_right_dir.normalized() * handle_right_dir.length
            handle_right_dir = handle_right_co - v_right.co

        if average:
            avg_length = (handle_left_dir.length + handle_right_dir.length) / 2
            handle_left_co = v_left.co + handle_left_dir.normalized() * avg_length
            handle_right_co = v_right.co + handle_right_dir.normalized() * avg_length

        sweep.handles = [handle_left_co, handle_right_co]
