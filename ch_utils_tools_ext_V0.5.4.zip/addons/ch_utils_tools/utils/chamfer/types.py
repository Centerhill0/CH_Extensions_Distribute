"""
倒角/圆角数据结构模块

提供类型安全的 dataclass 替代原来的嵌套 dict + 魔术索引访问模式.

主要功能:
- RailData: 轨道数据
- LoopData: 循环数据
- SweepData: 扫描数据
- as_layers: Bevel权重层参数归一化(内部协作)
"""

from dataclasses import dataclass, field
from mathutils import Vector


@dataclass
class RailData:
    """轨道数据"""

    verts: list = field(default_factory=list)  # 轨道顶点列表
    edges: list = field(default_factory=list)  # 轨道边列表
    cyclic: bool = False  # 是否循环


@dataclass
class LoopData:
    """
    循环数据(每个 sweep 顶点的循环边计算结果)

    替换原来的魔术下标元组:
    - 原 tuple[0] → type (循环类型: "TOPO" / "BIGGEST_ANGLE" / "PROJECTED")
    - 原 tuple[1] → co (循环目标坐标, 即循环边上的远端点)
    - 原 tuple[2] → edge_index (循环边索引, PROJECTED 时为 None)
    - 原 tuple[3] → angle (与轨道边夹角, 仅 BIGGEST_ANGLE 有效)
    - 原 tuple[4] → smooth (循环边平滑标志)
    - 原 tuple[5] → weights (各层的 (权重值, 层名) 列表)
    """

    type: str  # 循环类型
    co: Vector  # 循环目标坐标
    edge_index: int | None  # 循环边索引
    angle: float | None  # 与轨道边夹角
    smooth: bool | None  # 循环边平滑标志
    weights: list = field(default_factory=list)  # 各层的 (权重值, 层名) 列表


@dataclass
class SweepData:
    """
    扫描数据

    原来使用嵌套 dict 结构,现替换为类型安全的数据类.

    原 dict key 映射:
    - "verts" → verts
    - "edges" → edges
    - "loop_candidates" → loop_candidates
    - "loops" → loops
    - "handles" → handles
    - "avg_face_normals" → avg_face_normals
    - "rail_lengths" → rail_lengths
    """

    verts: object = None  # 扫描顶点对
    edges: list = field(default_factory=list)  # 扫描边
    loop_candidates: list = field(default_factory=list)  # 循环候选边
    loops: list = field(default_factory=list)  # 循环数据
    handles: list = field(default_factory=list)  # 贝塞尔手柄
    avg_face_normals: list = field(default_factory=list)  # 平均面法线
    rail_lengths: list = field(default_factory=list)  # 轨道长度
    rails: list[RailData] = field(default_factory=list)  # 轨道数据列表
    cyclic: bool = False  # 是否循环
    single: bool = False  # 是否单个

    @property
    def rail_0(self) -> RailData:
        return self.rails[0]

    @property
    def rail_1(self) -> RailData:
        return self.rails[1]


def as_layers(bw) -> list:
    """将Bevel权重层参数归一化为层列表(接受单层或层序列)"""
    return list(bw) if isinstance(bw, (list, tuple)) else [bw]
