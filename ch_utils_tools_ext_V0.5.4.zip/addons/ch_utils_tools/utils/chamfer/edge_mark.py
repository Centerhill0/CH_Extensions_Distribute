"""
边标记工具模块

提供边的锐度标记和倒角权重设置功能.

主要功能:
- set_rail_sharps_and_bweights: 设置轨道边的锐度和倒角权重
- set_sharps_and_bweights: 设置边的锐度和倒角权重
- set_sweep_sharps_and_bweights: 设置扫描边的锐度和Bevel权重
- clear_rail_sharps_and_bweights: 清除轨道边的锐度和Bevel权重
"""

from bmesh.types import BMesh, BMVert, BMEdge

from .types import as_layers


def _get_rail_edges(bm: BMesh, rails: list) -> list[BMEdge]:
    """按轨道顺序收集轨道边"""
    rail_edges = []
    for rail in rails:
        rail_edges.extend(bm.edges.get([vert, rail[idx + 1]]) for idx, vert in enumerate(rail) if idx < len(rail) - 1)
    return rail_edges


def set_rail_sharps_and_bweights(bm: BMesh, bw, rails: list[list[BMVert]], cyclic: bool, mark_sharp: bool = True, mark_bevel_weight: bool = True, bevel_weight: float = 1) -> None:
    """
    设置轨道边的锐度和倒角权重

    Args:
        bm: BMesh对象
        bw: 倒角权重数据层
        rails: 轨道顶点列表(不会被修改)
        cyclic: 是否为循环选择
        mark_sharp: 是否设置锐度
        mark_bevel_weight: 是否设置倒角权重
        bevel_weight: 倒角权重值
    """
    if cyclic:
        # 复制后闭合, 不修改调用方传入的列表
        rails = [rail + [rail[0]] for rail in rails]

    for rail_edge in _get_rail_edges(bm, rails):
        if mark_sharp:
            rail_edge.smooth = False
        if mark_bevel_weight:
            rail_edge[bw] = bevel_weight


def set_sharps_and_bweights(edges: list[BMEdge], bw, sharps: bool = True, bweights: bool = True, bweight: float = 1) -> None:
    """
    设置边的锐度和倒角权重

    根据参数设置边的平滑状态和倒角权重值.

    Args:
        edges: 边列表
        bw: 倒角权重数据层(必须为有效层, 由 ensure_default_data_layers 创建)
        sharps: 是否设置锐度标记
        bweights: 是否设置倒角权重(False 时跳过, 不改动现有权重)
        bweight: 倒角权重值,范围 [0, 1]
    """
    for edge in edges:
        edge.smooth = not sharps

        if bweights:
            edge[bw] = bweight


def set_sweep_sharps_and_bweights(bm: BMesh, bw, sweeps: list, spline_sweeps: list, vg=None):
    """
    设置扫描边的锐度和Bevel权重
    根据循环数据设置每条边的锐度标志和权重值
    Args:
        bm: BMesh对象
        bw: Bevel权重层或层列表
        sweeps: 扫描数据列表
        spline_sweeps: 样条顶点列表
        vg: 顶点组(可选)
    """
    layers = as_layers(bw)

    for sweep, verts in zip(sweeps, spline_sweeps):
        loops = sweep.loops

        sharp = not all(loop.smooth for loop in loops)

        edge_weights = [max(loop.weights[idx][0] for loop in loops) for idx in range(len(layers))]

        sweep_edges = [bm.edges.get([vert, verts[idx + 1]]) for idx, vert in enumerate(verts) if idx < len(verts) - 1]

        for sweep_edge in sweep_edges:
            if sharp:
                sweep_edge.smooth = False

            for weight, layer in zip(edge_weights, layers):
                sweep_edge[layer] = weight

        if vg and dict(verts[0][vg]) == dict(verts[-1][vg]):
            for vert in verts[1:-1]:
                for idx, weight in verts[0][vg].items():
                    vert[vg][idx] = weight


def clear_rail_sharps_and_bweights(bm: BMesh, bw, rails: list, cyclic: bool, select: bool = False):
    """
    清除轨道边的锐度和Bevel权重
    将所有轨道边设置为平滑并清除权重
    Args:
        bm: BMesh对象
        bw: Bevel权重层或层列表
        rails: 轨道顶点列表(不会被修改)
        cyclic: 是否为循环闭合
        select: 是否选中轨道边
    """
    layers = as_layers(bw)

    if cyclic:
        # 复制后闭合, 不修改调用方传入的列表
        rails = [rail + [rail[0]] for rail in rails]

    for rail_edge in _get_rail_edges(bm, rails):
        rail_edge.smooth = True

        for layer in layers:
            rail_edge[layer] = 0

        rail_edge.select = select
