"""
循环边计算模块(倒角专用)

提供循环边计算, 边循环对齐, 边循环传播等功能, 用于倒角转圆角操作.

主要功能:
- get_loops: 为每个sweep顶点计算循环数据
"""

import math
import mathutils
from bmesh.types import BMVert, BMEdge

from ..math.geometry import get_edge_angle, get_average_normals
from ..mesh.selection import get_edge_ngon_face
from .types import LoopData, SweepData, as_layers


def get_loops(bw, sweeps, force_projected: bool = False):
    """
    为每个sweep顶点计算循环(loop)数据
    根据loop_candidates的数量选择不同的计算策略:
    - 0个候选或强制投影: 使用投影循环
    - 1个候选: 使用拓扑循环(特殊情况下使用投影循环)
    - 多个候选: 使用最大角度循环
    Args:
        bw: Bevel权重层或层列表
        sweeps: 扫描数据列表
        force_projected: 是否强制使用投影循环
    """
    for sweep in sweeps:
        for idx, vert in enumerate(sweep.verts):
            candidate_count = len(sweep.loop_candidates[idx])

            if candidate_count == 0 or force_projected:
                loop_tuple = _projected_loop(vert, sweep.edges[0], bw)
                sweep.loops.append(loop_tuple)

            elif candidate_count == 1:
                loop_tuple = _handle_single_candidate(vert, sweep, idx, bw)
                sweep.loops.append(loop_tuple)

            else:
                loop_tuple = _handle_multiple_candidates(vert, sweep, idx, bw)
                sweep.loops.append(loop_tuple)


def _handle_single_candidate(vert: BMVert, sweep: SweepData, idx: int, bw):
    """
    处理单个候选边的情况
    Args:
        vert: 当前顶点
        sweep: 扫描数据对象
        idx: 顶点在sweep中的索引
        bw: Bevel权重层
    Returns:
        循环元组
    """
    loop_candidate = sweep.loop_candidates[idx][0]
    edge = sweep.edges[0]
    link_edges = [e for e in vert.link_edges]

    if not edge.is_manifold:
        pass
    elif get_edge_ngon_face(edge):
        if get_edge_ngon_face(loop_candidate):
            pass
    elif get_edge_ngon_face(loop_candidate) and len(link_edges) == 3:
        face_angle = math.degrees(edge.calc_face_angle())
        if not (89 < face_angle < 91):
            return _projected_loop(vert, sweep.edges[0], bw)

    return _topo_loop(vert, sweep.loop_candidates[idx], bw)


def _handle_multiple_candidates(vert: BMVert, sweep: SweepData, idx: int, bw):
    """
    处理多个候选边的情况
    Args:
        vert: 当前顶点
        sweep: 扫描数据对象
        idx: 顶点在sweep中的索引
        bw: Bevel权重层
    Returns:
        循环元组
    """
    loop_tuple = _biggest_angle_loop(vert, sweep.edges[0], sweep.loop_candidates[idx], bw)

    if loop_tuple:
        loop_edge_idx, angle = loop_tuple.edge_index, loop_tuple.angle

        if 89 <= angle <= 91:
            loop2_tuple = _topo_loop(vert, sweep.loop_candidates[idx], bw)
            loop2_edge_idx = loop2_tuple.edge_index

            if loop_edge_idx == loop2_edge_idx:
                return _projected_loop(vert, sweep.edges[0], bw)
            return loop2_tuple
        return loop_tuple

    return _projected_loop(vert, sweep.edges[0], bw)


def _topo_loop(vert: BMVert, loop_candidates: list[BMEdge], bw) -> LoopData:
    """
    基于拓扑关系计算循环
    直接使用第一条候选边的另一端点作为循环目标
    Args:
        vert: 当前顶点
        loop_candidates: 候选边列表
        bw: Bevel权重层或层列表
    Returns:
        LoopData: (类型, 目标坐标, 边索引, 角度, 平滑标志, 权重数据列表)
    """
    layers = as_layers(bw)

    loop_edge = loop_candidates[0]
    remote_co = loop_edge.other_vert(vert).co.copy()

    return LoopData("TOPO", remote_co, loop_edge.index, None, loop_edge.smooth, [(loop_edge[layer], layer.name) for layer in layers])


def _biggest_angle_loop(vert: BMVert, edge: BMEdge, loop_candidates: list[BMEdge], bw) -> LoopData | None:
    """
    选择与轨道边夹角最大的候选边作为循环
    Args:
        vert: 当前顶点
        edge: 轨道边
        loop_candidates: 候选边列表
        bw: Bevel权重层或层列表
    Returns:
        LoopData或None: 如果前两个角度差值小于10度则返回None,否则返回循环数据
    """
    layers = as_layers(bw)

    angles = []
    for candidate_edge in loop_candidates:
        angle = int(get_edge_angle(edge, candidate_edge, radians=False))
        angles.append((angle, candidate_edge))

    angles.sort(key=lambda a: a[0], reverse=True)

    first_angle, second_angle = angles[0][0], angles[1][0]
    if abs(first_angle - second_angle) < 10:
        return None

    angle, loop_edge = angles[0]
    remote_co = loop_edge.other_vert(vert).co.copy()

    return LoopData("BIGGEST_ANGLE", remote_co, loop_edge.index, angle, loop_edge.smooth, [(loop_edge[layer], layer.name) for layer in layers])


def _projected_loop(vert: BMVert, edge: BMEdge, bw) -> LoopData:
    """
    通过投影计算循环
    将边沿法线方向偏移后投影到相邻面上,得到循环目标点
    Args:
        vert: 当前顶点
        edge: 轨道边
        bw: Bevel权重层或层列表
    Returns:
        LoopData: (类型, 投影坐标, 边索引(None), 角度(None), 平滑标志(True), 权重数据列表)
    """
    layers = as_layers(bw)

    faces = [f for f in vert.link_faces if not f.select and f not in edge.link_faces]
    if not faces:
        return None
    face = faces[0]

    v1 = vert
    v2 = edge.other_vert(v1)

    normals = [f.normal.normalized() for f in edge.link_faces if f.select]
    avg_edge_normal = get_average_normals(normals) * 0.1

    avg_edge_face_normals = get_average_normals([avg_edge_normal, face.normal])
    v1_v2_dir = v2.co - v1.co

    dot = v1_v2_dir.dot(avg_edge_face_normals)

    if dot < 0:
        v1co_offset = v1.co - avg_edge_normal
    else:
        v1co_offset = v1.co + avg_edge_normal

    edge_dir = v1.co - v2.co
    ext_edgeco = v1co_offset + edge_dir
    perpco = ext_edgeco - face.normal

    intersect_co = mathutils.geometry.intersect_line_plane(ext_edgeco, perpco, v1.co, face.normal)

    return LoopData("PROJECTED", intersect_co, None, None, True, [(0, layer.name) for layer in layers])
