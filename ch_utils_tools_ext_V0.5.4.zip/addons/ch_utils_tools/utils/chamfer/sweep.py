"""
扫描轨道工具模块

提供扫描数据初始化, 轨道获取, 样条创建, 表面融合等功能, 用于倒角转圆角操作.

主要功能:
- init_sweeps: 初始化扫描数据
- get_2_rails_from_chamfer: 从倒角面获取两条轨道
- get_sweeps_from_fillet: 从圆角面获取扫描数据
- change_width: 改变扫描轨道宽度
- create_splines: 从扫描数据创建贝塞尔样条顶点
- fuse_surface: 将样条顶点融合为网格表面
"""

import bmesh
from bmesh.types import BMesh, BMVert, BMFace
from bpy.types import Object
from mathutils.geometry import intersect_line_line, interpolate_bezier
from math import degrees

from ..math.geometry import get_average_normals, get_distance_between_points
from ..mesh.selection import is_freestyle_edge
from ..mesh.topology import build_mesh_graph

from .types import SweepData


def init_sweeps(bm: BMesh, obj: Object, rails: list[list[BMVert]], freestyle: bool = True) -> list[SweepData]:
    """
    初始化Sweep扫描数据

    用于构建曲线扫描所需的各项数据,包括顶点,边,循环候选,轨道长度等.

    Args:
        bm: BMesh对象
        obj: 活动网格对象
        rails: 轨道顶点列表,rails[0]为左轨道,rails[1]为右轨道
        freestyle: 是否按Freestyle边过滤循环候选边

    Returns:
        扫描数据列表,每个元素包含 verts/edges/loop_candidates/loops/handles/avg_face_normals/rail_lengths
    """
    sweeps = []
    mesh_data = obj.data
    left_rail = rails[0]
    right_rail = rails[1]

    for idx, vert_pair in enumerate(zip(left_rail, right_rail)):
        sweep = SweepData(
            verts=vert_pair,
            edges=[bm.edges.get(vert_pair)],
            loops=[],
            handles=[],
        )

        for vert in sweep.verts:
            connected_edges = [e for e in vert.link_edges if not e.select and e.calc_length() != 0]

            if freestyle and connected_edges:
                freestyle_edges = {e for e in connected_edges if is_freestyle_edge(mesh_data, e.index)}
                freestyle_count = len(freestyle_edges)

                if freestyle_count > 0:
                    if freestyle_count == 1 and len(connected_edges) != 1:
                        connected_edges = list(freestyle_edges)
                    else:
                        connected_edges = [e for e in connected_edges if e not in freestyle_edges]

            sweep.loop_candidates.append(connected_edges)

        rail_edge = sweep.edges[0]
        linked_faces = set(rail_edge.link_faces) if rail_edge else set()

        for vert in sweep.verts:
            adjacent_faces = [f.normal.normalized() for f in vert.link_faces if not f.select and f not in linked_faces]
            sweep.avg_face_normals.append(get_average_normals(adjacent_faces))

        if idx == 0:
            sweep.rail_lengths.extend([0, 0])
        else:
            v_left = vert_pair[0]
            prev_v_left = left_rail[idx - 1]
            v_right = vert_pair[1]
            prev_v_right = right_rail[idx - 1]

            dist_left = get_distance_between_points(v_left.co, prev_v_left.co)
            dist_right = get_distance_between_points(v_right.co, prev_v_right.co)
            sweep.rail_lengths.extend([dist_left, dist_right])

        sweeps.append(sweep)

    return sweeps


def get_2_rails_from_chamfer(bm: BMesh, mg: dict, faces: list, reverse: bool = False) -> tuple[tuple[tuple[list[BMVert], list[BMVert]], bool], None] | tuple[None, str]:
    """
    从倒角面获取两条轨道(rail)用于生成圆角

    该函数分析选中的倒角面,提取出两条平行的顶点路径(轨道),
    用于后续生成圆角几何体.

    Args:
        bm: BMesh对象
        mg: 网格图(build_mesh_graph返回)
        faces: 面列表
        reverse: 是否反转轨道顺序

    Returns:
        (结果, 错误信息) 元组:
        - 成功: (((rail1, rail2), cyclic), None), rail1/rail2 为两条轨道的顶点列表,
          cyclic 为是否循环选择
        - 失败: (None, 错误信息), 由调用方决定如何呈现
    """
    error = _validate_quad_only_faces(faces)
    if error:
        return None, error

    boundary_edges = {e for f in faces for e in f.edges if len([lf for lf in e.link_faces if lf.select]) == 1}

    if any(not e.is_manifold for e in boundary_edges):
        is_all = all(not e.is_manifold for e in boundary_edges)
        msg = f"{'All' if is_all else 'Some'} Boundary Edges of the Selected Face{'s ' if len(faces) > 1 else ''}are non-manifold, aborting."
        detail = "This usually means you've split the faces from the rest of the mesh."
        return None, f"{msg}\n{detail}"

    if not faces:
        return None, "Selection does not include faces, aborting."

    length_mode = len(faces) == 1

    def get_corners(mesh_graph):
        return [bm.verts[idx] for idx in mesh_graph if bm.verts[idx].select and sum(vselect for _, vselect, eselect in mesh_graph[idx] if eselect) == 2]

    corners = get_corners(mg)

    if not corners:
        cyclic = True
        f = faces[0]
        f.select_set(False)

        mg = build_mesh_graph(bm)
        corners = get_corners(mg)

        if not corners:
            return None, "Selection is not a chamfer, aborting"
    else:
        cyclic = False

    c1 = corners[0]
    corners.remove(c1)

    connected_to_c1 = {idx for idx, vselect, eselect in mg[c1.index] if eselect}
    c2_candidates = [c for c in corners if c.index in connected_to_c1]

    if not c2_candidates:
        return None, "Selection is not a chamfer, aborting"

    if length_mode:
        c2, c3 = c2_candidates[0], c2_candidates[1]
        corners.remove(c2)
        corners.remove(c3)
        c4 = corners[-1]

        edge_a1 = bm.edges.get([c1, c3])
        edge_a2 = bm.edges.get([c2, c4])
        edge_b1 = bm.edges.get([c1, c2])
        edge_b2 = bm.edges.get([c3, c4])

        average_a = (edge_a1.calc_length() + edge_a2.calc_length()) / 2
        average_b = (edge_b1.calc_length() + edge_b2.calc_length()) / 2

        if average_a >= average_b:
            rail1, rail2 = [c1, c3], [c2, c4]
        else:
            rail1, rail2 = [c1, c2], [c3, c4]

        if reverse:
            rail1, rail2 = [rail1[0], rail2[0]], [rail1[1], rail2[1]]
    else:
        c2 = c2_candidates[0]
        corners.remove(c2)

        rail1, rail2 = [c1], [c2]

        not_yet_walked = list(faces)
        while not_yet_walked:
            v1, v2 = rail1[-1], rail2[-1]
            sweep = bm.edges.get([v1, v2])

            current_face = [f for f in sweep.link_faces if f.select and f in not_yet_walked]

            if current_face:
                cf = current_face[0]
                not_yet_walked.remove(cf)

                next_verts = [v for v in cf.verts if v not in rail1 + rail2]

                rail1_next = [e.other_vert(v1) for e in v1.link_edges if e.other_vert(v1) in next_verts][0]
                rail2_next = [e.other_vert(v2) for e in v2.link_edges if e.other_vert(v2) in next_verts][0]

                rail1.append(rail1_next)
                rail2.append(rail2_next)
            else:
                break

        if cyclic:
            f.select_set(True)

    return ((rail1, rail2), cyclic), None


def get_sweeps_from_fillet(bm: BMesh, mg: dict, faces: list) -> tuple[list[tuple[BMVert, BMVert]], None] | tuple[None, str]:
    """
    从圆角面获取扫描数据(sweep)用于反向操作

    该函数分析选中的圆角面,提取出扫描顶点对,
    用于后续的反向圆角操作.

    Args:
        bm: BMesh对象
        mg: 网格图(build_mesh_graph返回)
        faces: 面列表

    Returns:
        (结果, 错误信息) 元组:
        - 成功: (扫描顶点对列表, None), 每个元素为(vert1, vert2)元组
        - 失败: (None, 错误信息), 由调用方决定如何呈现
    """
    error = _validate_quad_only_faces(faces)
    if error:
        return None, error

    if len(faces) < 2:
        return None, "Selection has less than 2 faces, aborting"

    def get_corners(mesh_graph: dict) -> list:
        return [bm.verts[idx] for idx in mesh_graph if bm.verts[idx].select and sum(vselect for _, vselect, eselect in mesh_graph[idx] if eselect) == 2]

    corners = get_corners(mg)

    if not corners:
        return None, "Cyclic selections are not supported, aborting. Make sure you select a face strip going ACROSS the Bevel, not the entirety of the Bevel's faces around!"

    corner1 = corners[0]
    corners.remove(corner1)

    connected_to_corner1 = {idx for idx, _, eselect in mg[corner1.index] if eselect}
    corner2_candidates = [c for c in corners if c.index in connected_to_corner1]

    if not corner2_candidates:
        return None, "Selection is not a poly strip, aborting! Select a single strip going ACROSS the bevel, not all of its faces!"

    corner2 = corner2_candidates[0]
    corners.remove(corner2)

    rail1 = [corner1]
    rail2 = [corner2]
    sweeps = [(corner1, corner2)]

    not_yet_walked = list(faces)
    while not_yet_walked:
        v1, v2 = rail1[-1], rail2[-1]
        sweep = bm.edges.get([v1, v2])

        current_face = [f for f in sweep.link_faces if f.select and f in not_yet_walked]

        if not current_face:
            break

        cf = current_face[0]
        not_yet_walked.remove(cf)

        next_verts = [v for v in cf.verts if v not in rail1 + rail2]

        rail1_next = [e.other_vert(v1) for e in v1.link_edges if e.other_vert(v1) in next_verts][0]
        rail2_next = [e.other_vert(v2) for e in v2.link_edges if e.other_vert(v2) in next_verts][0]

        rail1.append(rail1_next)
        rail2.append(rail2_next)
        sweeps.append((rail1_next, rail2_next))

    return sweeps, None


def change_width(sweeps: list, width: float, taper: bool = False) -> bool:
    """
    改变扫描轨道的宽度
    通过调整每个sweep顶点的位置来改变轨道宽度,支持锥度效果
    Args:
        sweeps: 扫描数据列表
        width: 目标宽度
        taper: 是否应用锥度效果(从起点到终点逐渐变化)
    Returns:
        成功返回True,失败返回False
    """
    if taper:
        total_len_left = sum(s.rail_lengths[0] for s in sweeps)
        total_len_right = sum(s.rail_lengths[1] for s in sweeps)
        accumulated_len_left = 0
        accumulated_len_right = 0

    first_sweep = sweeps[0]
    second_sweep = sweeps[1]

    v_left = first_sweep.verts[0]
    v_left_next = second_sweep.verts[0]
    v_right = first_sweep.verts[1]
    v_right_next = second_sweep.verts[1]

    loop_left = first_sweep.loops[0]
    loop_left_next = second_sweep.loops[0]
    loop_right = first_sweep.loops[1]
    loop_right_next = second_sweep.loops[1]

    loop_left_dir = v_left.co + (loop_left.co - v_left.co).normalized() * width
    loop_right_dir = v_right.co + (loop_right.co - v_right.co).normalized() * width

    rail_left_dir = v_left_next.co - v_left.co
    rail_right_dir = v_right_next.co - v_right.co

    intersect_left = intersect_line_line(loop_left_dir, loop_left_dir + rail_left_dir, v_left_next.co, loop_left_next.co)
    intersect_right = intersect_line_line(loop_right_dir, loop_right_dir + rail_right_dir, v_right_next.co, loop_right_next.co)

    if not intersect_left or not intersect_right:
        return False

    if not taper:
        v_left.co = loop_left_dir
        v_right.co = loop_right_dir

    loop_left_ends = [intersect_left[0]]
    loop_right_ends = [intersect_right[0]]

    for idx, sweep in enumerate(sweeps):
        if idx == 0:
            continue

        if idx == len(sweeps) - 1:
            v_left_next.co = intersect_left[0]
            v_right_next.co = intersect_right[0]
            break

        v_left = sweep.verts[0]
        v_left_next = sweeps[idx + 1].verts[0]
        v_right = sweep.verts[1]
        v_right_next = sweeps[idx + 1].verts[1]

        loop_left = sweep.loops[0]
        loop_left_next = sweeps[idx + 1].loops[0]
        loop_right = sweep.loops[1]
        loop_right_next = sweeps[idx + 1].loops[1]

        loop_left_end = loop_left_ends[-1]
        loop_left_end_next = loop_left_next.co
        loop_right_end = loop_right_ends[-1]
        loop_right_end_next = loop_right_next.co

        loop_left_dir = v_left.co + (loop_left_end - v_left.co)
        loop_right_dir = v_right.co + (loop_right_end - v_right.co)

        sweep_left_dir = v_left_next.co - v_left.co
        sweep_right_dir = v_right_next.co - v_right.co

        if taper:
            accumulated_len_left += sweep.rail_lengths[0]
            accumulated_len_right += sweep.rail_lengths[1]

            factor_left = accumulated_len_left / total_len_left
            factor_right = accumulated_len_right / total_len_right

            taper_left_dir = v_left.co + (loop_left_end - v_left.co) * factor_left
            taper_right_dir = v_right.co + (loop_right_end - v_right.co) * factor_right

            v_left.co = taper_left_dir
            v_right.co = taper_right_dir
        else:
            v_left.co = loop_left_dir
            v_right.co = loop_right_dir

        intersect_left = intersect_line_line(loop_left_dir, loop_left_dir + sweep_left_dir, v_left_next.co, loop_left_end_next)
        intersect_right = intersect_line_line(loop_right_dir, loop_right_dir + sweep_right_dir, v_right_next.co, loop_right_end_next)

        if not intersect_left or not intersect_right:
            return False

        loop_left_ends.append(intersect_left[0])
        loop_right_ends.append(intersect_right[0])

    return True


def create_splines(bm: BMesh, sweeps: list, segments: int) -> list:
    """
    从扫描数据创建贝塞尔样条顶点
    使用贝塞尔插值在每对顶点之间生成平滑曲线
    Args:
        bm: BMesh对象
        sweeps: 扫描数据列表
        segments: 曲线分段数
    Returns:
        样条顶点列表,每个元素是一个顶点列表
    """
    spline_sweeps = []

    for sweep in sweeps:
        v_left = sweep.verts[0]
        v_right = sweep.verts[1]

        handle_left_co = sweep.handles[0]
        handle_right_co = sweep.handles[1]

        bezier_verts = interpolate_bezier(v_left.co, handle_left_co, handle_right_co, v_right.co, segments + 2)[1:-1]

        spline_verts = [v_left]
        for vert_co in bezier_verts:
            new_vert = bm.verts.new()
            new_vert.co = vert_co
            spline_verts.append(new_vert)
        spline_verts.append(v_right)

        spline_sweeps.append(spline_verts)

    return spline_sweeps


def fuse_surface(bm: BMesh, spline_sweeps: list, smooth: bool, mat_index: int = 0, cap_holes: bool = True, cap_dissolve_angle: int = 10, cyclic: bool = False, select: bool = True) -> tuple:
    """
    将样条顶点融合为网格表面
    在相邻的样条顶点之间创建四边面,支持循环闭合和端面封口
    Args:
        bm: BMesh对象
        spline_sweeps: 样条顶点列表
        smooth: 是否启用平滑着色
        mat_index: 材质索引
        cap_holes: 是否封住端面
        cap_dissolve_angle: 端面边溶解角度阈值
        cyclic: 是否为循环闭合
        select: 是否选中生成的面
    Returns:
        元组: (面列表, 端面列表或None)
    """
    faces = []

    for sweep_idx, sweep in enumerate(spline_sweeps):
        for rail_idx, vert in enumerate(sweep):
            corner1 = vert
            corner2 = sweep[rail_idx + 1]
            corner3 = spline_sweeps[sweep_idx + 1][rail_idx + 1]
            corner4 = spline_sweeps[sweep_idx + 1][rail_idx]

            face_corners = [corner1, corner2, corner3, corner4]
            face = bm.faces.new(face_corners)

            if smooth:
                face.smooth = True

            face.material_index = mat_index
            faces.append(face)

            if rail_idx + 2 == len(sweep):
                break

        if sweep_idx + 2 == len(spline_sweeps):
            break

    bmesh.ops.recalc_face_normals(bm, faces=faces)

    no_caps_selected = True
    caps = []
    if not cap_holes and not cyclic:
        if select:
            for face in faces:
                face.select = True
        return faces, None

    border_start = spline_sweeps[0]
    border_end = spline_sweeps[-1]

    if cyclic:
        cyclic_faces = _create_cyclic_faces(bm, border_start, border_end, smooth, mat_index)
        bmesh.ops.recalc_face_normals(bm, faces=cyclic_faces)

        if select:
            for face in faces + cyclic_faces:
                face.select = True

        return faces + cyclic_faces, None

    caps = [bm.faces.new(border_start), bm.faces.new(border_end)]
    bmesh.ops.recalc_face_normals(bm, faces=caps)

    _process_cap_edge(bm, border_start, faces, smooth, cap_dissolve_angle)
    _process_cap_edge(bm, border_end, faces, smooth, cap_dissolve_angle)

    cap_start_edge = bm.edges.get([border_start[0], border_start[-1]])
    cap_end_edge = bm.edges.get([border_end[0], border_end[-1]])

    if cap_start_edge and cap_start_edge.is_valid:
        caps[0].select = True
        no_caps_selected = False
        bm.select_history.add(caps[0])

    if cap_end_edge and cap_end_edge.is_valid:
        caps[1].select = True
        no_caps_selected = False
        bm.select_history.add(caps[1])

    if select and (no_caps_selected or not caps):
        for face in faces:
            face.select = True

    return faces, caps


def _create_cyclic_faces(bm: BMesh, border_start: list, border_end: list, smooth: bool, mat_index: int) -> list:
    """
    创建循环闭合面
    Args:
        bm: BMesh对象
        border_start: 起始边界顶点列表
        border_end: 结束边界顶点列表
        smooth: 是否启用平滑着色
        mat_index: 材质索引
    Returns:
        循环面列表
    """
    cyclic_faces = []

    for idx, (start_vert, end_vert) in enumerate(zip(border_start, border_end)):
        face_corners = [start_vert, border_start[idx + 1], border_end[idx + 1], end_vert]
        face = bm.faces.new(face_corners)

        if smooth:
            face.smooth = True

        face.material_index = mat_index
        cyclic_faces.append(face)

        if idx + 2 == len(border_start):
            break

    return cyclic_faces


def _process_cap_edge(bm: BMesh, border: list, faces: list, smooth: bool, dissolve_angle: int):
    """
    处理端面边,根据角度决定是否溶解
    Args:
        bm: BMesh对象
        border: 边界顶点列表
        faces: 已创建的面列表
        smooth: 是否启用平滑着色
        dissolve_angle: 溶解角度阈值
    """
    cap_edge = bm.edges.get([border[0], border[-1]])

    if not cap_edge.is_manifold:
        return

    cap_angle = degrees(cap_edge.calc_face_angle())

    if cap_angle < dissolve_angle or cap_angle > 181 - dissolve_angle:
        bmesh.ops.dissolve_edges(bm, edges=[cap_edge])

        if smooth:
            border_vert = border[1]
            cap_face = [f for f in border_vert.link_faces if f not in faces][0]
            cap_face.smooth = True


def _validate_quad_only_faces(faces: list[BMFace]) -> str | None:
    """
    验证面列表是否只包含四边形面(无 ngon 和 tri)

    Args:
        faces: 面列表

    Returns:
        验证失败时的错误信息, 通过验证返回None
    """
    ngons = [f for f in faces if len(f.verts) > 4]
    tris = [f for f in faces if len(f.verts) < 4]

    if ngons:
        return "Selection includes ngons, aborting"

    if tris:
        return "Selection includes tris, aborting"

    return None
