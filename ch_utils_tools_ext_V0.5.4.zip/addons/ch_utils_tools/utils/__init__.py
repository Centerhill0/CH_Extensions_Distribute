"""
算法层工具模块 (utils)

为交互层提供算法与封装, 依赖方向为: operators/ui -> utils -> common, utils 内部
子包自底向上为 math -> mesh -> blender -> measure -> chamfer, drawing 与
infrastructure 为横切层.

子包结构:
- blender/: Blender API 封装 (集合/曲线/材质/修改器/物体/射线/场景/吸附/顶点组)
- chamfer/: 倒角/圆角核心算法
- drawing/: GPU 绘制与模态事件 (算子实例型交互辅助已收编至插件根 modal_base.py)
- infrastructure/: 数据处理
- math/: 纯数学计算 (颜色/核心/几何/插值/变换)
- measure/: 测量系统
- mesh/: 网格操作 (BMesh/边环/变形器/展平/法线/选择/样条变形/拓扑)

公共 API: 各子包 __init__ 显式再导出的名字经星号导入汇聚于此;
未列出的模块成员为 utils 内部协作 API, 不进入本命名空间.
"""

from .blender import *
from .chamfer import *
from .drawing import *
from .infrastructure import *
from .math import *
from .measure import *
from .mesh import *
