"""
数学计算模块

提供向量, 矩阵运算等基础数学功能.

主要功能:
- lerp: 线性插值
- find_outliers: 查找异常值
"""

import numpy as np


def lerp(start: float, end: float, factor: float) -> float:
    """
    线性插值
    Args:
        start: 起始值
        end: 结束值
        factor: 插值因子(0-1)
    Returns:
        插值结果
    """
    return start + (end - start) * factor


def find_outliers(data: list[float], lowp: float = 25, highp: float = 75, multiplier: float = 1.5, bounds: bool = False) -> list[float]:
    """
    使用四分位距(IQR)方法查找数据中的异常值

    Args:
        data: 数据列表
        lowp: 下四分位数百分比,默认25
        highp: 上四分位数百分比,默认75
        multiplier: IQR乘数,默认1.5
        bounds: 是否返回边界值而非异常值列表

    Returns:
        如果bounds为True,返回 [lower_bound, upper_bound]
        否则返回异常值列表
    """
    q1 = np.percentile(data, lowp)
    q3 = np.percentile(data, highp)

    iqr = q3 - q1

    lower_bound = q1 - (multiplier * iqr)
    upper_bound = q3 + (multiplier * iqr)

    if bounds:
        return [lower_bound, upper_bound]

    return [x for x in data if x < lower_bound or x > upper_bound]
