"""
变换工具模块

提供矩阵变换, 坐标系生成, 法线变换等功能.

主要功能:
- apply_matrix_to_points: 应用矩阵变换到点集
- get_rotation_difference_matrix: 获取旋转差异矩阵
- transform_normal_to_world: 法线局部转世界
- generate_local_coordinate_system: 生成局部坐标系
- get_rotation_matrix_from_vert: 从顶点获取旋转矩阵
- get_rotation_matrix_from_edge: 从边获取旋转矩阵
- get_rotation_matrix_from_face: 从面获取旋转矩阵
"""

import math

import numpy as np
from bpy.types import Context
from mathutils import Matrix, Vector
from mathutils.geometry import intersect_line_plane
from bmesh.types import BMVert, BMEdge, BMFace

from .geometry import get_average_normals
from .._constants import (
    AXIS_X,
    AXIS_Y,
    AXIS_Z,
    PARALLEL_THRESHOLD,
    CIRCLE_DISTANCE_THRESH,
    CIRCLE_LENGTH_THRESH,
    CIRCLE_ANGLE_THRESH_DEG,
)


def _is_parallel_to_up(normal: Vector, up_vec: Vector, threshold: float = PARALLEL_THRESHOLD) -> bool:
    """检查法线是否与上行向量平行"""
    return abs(normal.dot(up_vec)) > threshold


def apply_matrix_to_points(np_co_array: np.ndarray, mx: Matrix) -> np.ndarray:
    """
    将三维坐标点集合与变换矩阵相乘,计算变换后的新坐标
    Args:
        np_co_array: numpy数组,形状为(N, 3)
        mx: 4x4变换矩阵
    Returns:
        变换后的坐标数组
    """
    homogeneous = np.ones((np_co_array.shape[0], 4), dtype=np_co_array.dtype)
    homogeneous[:, :3] = np_co_array
    homogeneous = homogeneous.T

    mat_arr = np.array(mx, dtype=np.float32)
    transformed = mat_arr @ homogeneous
    transformed /= transformed[3]

    return transformed.T[:, :3]


def get_rotation_difference_matrix(vec_1: Vector, vec_2: Vector) -> Matrix:
    """
    计算两个向量之间的旋转差异矩阵
    Args:
        vec_1: 第一个向量
        vec_2: 第二个向量
    Returns:
        旋转差异矩阵(3x3)
    """
    return vec_1.rotation_difference(vec_2).to_matrix()


def transform_normal_to_world(normal: Vector, mx: Matrix) -> Vector:
    """
    将法线从局部空间转换到世界空间
    法线变换需要使用逆转置矩阵,以确保非均匀缩放时法线仍垂直于表面
    Args:
        normal: 物体局部空间法线
        mx: 物体变换矩阵
    Returns:
        世界空间法线
    """
    return (mx.to_3x3().inverted_safe().transposed() @ normal).normalized()


def generate_local_coordinate_system(normal: Vector, ref_vec: Vector) -> Matrix:
    """
    根据法线(Z轴)与参考向量构建正交坐标系
    Args:
        normal: 法线向量(Z轴),内部会归一化
        ref_vec: 参考向量
    Returns:
        正交坐标系矩阵,行为(X, Y, Z)轴
    """
    nrm = normal.normalized()
    tangent = ref_vec.cross(nrm).normalized()
    bitangent = nrm.cross(tangent).normalized()
    return Matrix((tangent, bitangent, nrm)).transposed()


def get_rotation_matrix_from_vert(context: Context, mx: Matrix, vert: BMVert) -> Matrix:
    """
    基于顶点的法线和几何体创建旋转矩阵
    Args:
        context: 上下文
        mx: 变换矩阵
        vert: 顶点对象
    Returns:
        旋转矩阵
    """
    rot_mx = mx.to_3x3()
    normal = transform_normal_to_world(vert.normal, mx)

    if vert.link_edges:
        longest_edge = max(vert.link_edges, key=lambda e: e.calc_length())
        edge_vec = rot_mx @ (longest_edge.other_vert(vert).co - vert.co)
        view_up_vec = context.space_data.region_3d.view_rotation @ AXIS_Y
        if edge_vec.dot(view_up_vec) < 0:
            edge_vec.negate()
        return generate_local_coordinate_system(normal, edge_vec.normalized())

    obj_up_vec = rot_mx @ AXIS_Z
    if _is_parallel_to_up(normal, obj_up_vec):
        obj_up_vec = rot_mx @ AXIS_X
    return generate_local_coordinate_system(normal, obj_up_vec.normalized())


def get_rotation_matrix_from_edge(context: Context, mx: Matrix, edge: BMEdge) -> Matrix:
    """
    基于边的法线和几何体创建旋转矩阵
    Args:
        context: 上下文
        mx: 变换矩阵
        edge: 边对象
    Returns:
        旋转矩阵,其中Y轴与边方向对齐,Z轴与面法线对齐
    """

    rot_mx = mx.to_3x3()
    edge_vec = rot_mx @ (edge.verts[1].co - edge.verts[0].co)
    y_axis = edge_vec.normalized()

    view_up_vec = context.space_data.region_3d.view_rotation @ AXIS_Y
    if y_axis.dot(view_up_vec) < 0:
        y_axis.negate()

    if edge.link_faces:
        z_axis = get_average_normals([transform_normal_to_world(f.normal, mx) for f in edge.link_faces])
    else:
        z_axis = rot_mx @ AXIS_Z
        if _is_parallel_to_up(y_axis, z_axis):
            z_axis = rot_mx @ AXIS_X

    z_axis = (z_axis - z_axis.dot(y_axis) * y_axis).normalized()
    x_axis = y_axis.cross(z_axis).normalized()

    return Matrix((x_axis, y_axis, z_axis)).transposed()


def get_rotation_matrix_from_face(mx: Matrix, face: BMFace) -> Matrix:
    """
    基于面的法线和几何体创建旋转矩阵
    Args:
        mx: 变换矩阵
        face: 面对象
    Returns:
        旋转矩阵
    """
    normal = transform_normal_to_world(face.normal, mx)
    bitangent = None
    rot_mx = mx.to_3x3()

    if _is_circular_face(face):
        face_center = face.calc_center_median()
        for axis in (AXIS_Y, AXIS_X, AXIS_Z):
            intersection = intersect_line_plane(face_center + axis, face_center + axis + face.normal, face_center, face.normal)
            if intersection:
                projected = intersection - face_center
                if round(projected.length, 6):
                    bitangent = rot_mx @ projected
                    break

    if not bitangent:
        bitangent = rot_mx @ face.calc_tangent_edge_pair()

    return generate_local_coordinate_system(normal, bitangent.normalized())


def _is_circular_face(face: BMFace, distance_thresh: float = CIRCLE_DISTANCE_THRESH, length_thresh: float = CIRCLE_LENGTH_THRESH, angle_thresh_deg: float = CIRCLE_ANGLE_THRESH_DEG) -> bool:
    """
    判断一个bmesh面是否接近圆形
    Args:
        face: bmesh面
        distance_thresh: 顶点到几何中心的距离标准差阈值
        length_thresh: 边长的标准差阈值
        angle_thresh_deg: 角度分布均匀性的阈值(度)
    Returns:
        如果面接近圆形,返回True,否则返回False
    """
    num_verts = len(face.verts)
    if num_verts < 3:
        return False

    center = face.calc_center_median()

    coords = np.array([v.co for v in face.verts], dtype=np.float32)
    rel_coords = coords - np.array(center)
    distances = np.linalg.norm(rel_coords, axis=1)
    avg_dist = distances.mean()
    if avg_dist == 0:
        return False
    dist_std = distances.std() / avg_dist

    edge_lengths = np.array([e.calc_length() for e in face.edges], dtype=np.float32)
    avg_length = edge_lengths.mean()
    if avg_length == 0:
        return False
    length_std = edge_lengths.std() / avg_length

    angles = np.arctan2(rel_coords[:, 1], rel_coords[:, 0])
    angles = np.where(angles < 0, angles + 2 * math.pi, angles)
    angles.sort()
    expected_diff = 2 * math.pi / num_verts
    angle_diffs = np.diff(np.append(angles, angles[0] + 2 * math.pi)) - expected_diff
    angle_std_deg = math.degrees(np.sqrt((angle_diffs**2).mean()))

    return dist_std <= distance_thresh and length_std <= length_thresh and angle_std_deg <= angle_thresh_deg
