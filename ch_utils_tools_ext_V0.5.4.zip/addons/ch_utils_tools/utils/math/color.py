"""
颜色工具模块

提供颜色空间转换, 颜色混合等功能.

主要功能:
- linear_to_srgb: 线性转sRGB颜色空间
"""


def linear_to_srgb(color: tuple[float, float, float]) -> tuple[float, float, float]:
    """
    将线性颜色空间转换为sRGB颜色空间

    Args:
        color: 线性颜色RGB元组

    Returns:
        sRGB颜色RGB元组
    """

    def to_srgb(c: float) -> float:
        # sRGB 标准转换公式系数(IEC 61966-2-1), 数学常数
        if c <= 0.0031308:
            return 12.92 * c
        else:
            return 1.055 * (c ** (1.0 / 2.4)) - 0.055

    return tuple(to_srgb(c) for c in color)
