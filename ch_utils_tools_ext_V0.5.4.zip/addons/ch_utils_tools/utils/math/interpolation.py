"""
插值计算模块

提供纯数学的插值与平滑过渡功能.

主要功能:
- hermite_1d: 一维Hermite插值
- hermite_3d: 三维Hermite插值
- smooth_step: Hermite平滑过渡
- clamp: 值约束函数
"""


def hermite_1d(y0: float, y1: float, y2: float, y3: float, mu: float, tension: float, bias: float) -> float:
    """
    一维 Hermite 插值
    在 y1 和 y2 之间进行插值,y0 和 y3 用于控制切线

    Args:
        y0: 控制点0的值
        y1: 插值起点值
        y2: 插值终点值
        y3: 控制点3的值
        mu: 插值参数,范围 [0, 1],0对应y1,1对应y2
        tension: 张力参数,1为高张力,0为正常,-1为低张力
        bias: 偏置参数,0为均匀,正值偏向第一段,负值偏向第二段

    Returns:
        插值结果
    """
    mu2 = mu * mu
    mu3 = mu2 * mu

    tension_factor = (1 - tension) / 2
    m0 = (y1 - y0) * (1 + bias) * tension_factor + (y2 - y1) * (1 - bias) * tension_factor
    m1 = (y2 - y1) * (1 + bias) * tension_factor + (y3 - y2) * (1 - bias) * tension_factor

    a0 = 2 * mu3 - 3 * mu2 + 1
    a1 = mu3 - 2 * mu2 + mu
    a2 = mu3 - mu2
    a3 = -2 * mu3 + 3 * mu2

    return a0 * y1 + a1 * m0 + a2 * m1 + a3 * y2


def hermite_3d(point1: tuple[float, float, float], point2: tuple[float, float, float], point3: tuple[float, float, float], point4: tuple[float, float, float], mu: float, tension: float, bias: float) -> list[float]:
    """
    三维 Hermite 插值
    在 point2 和 point3 之间进行插值,point1 和 point4 用于控制切线

    Args:
        point1: 控制点1,影响起点处的切线方向
        point2: 插值起点
        point3: 插值终点
        point4: 控制点4,影响终点处的切线方向
        mu: 插值参数,范围 [0, 1],0对应point2,1对应point3
        tension: 张力参数,1为高张力,0为正常,-1为低张力
        bias: 偏置参数,0为均匀,正值偏向第一段,负值偏向第二段

    Returns:
        包含三个坐标分量的列表 [x, y, z]
    """
    return [hermite_1d(point1[i], point2[i], point3[i], point4[i], mu, tension, bias) for i in range(3)]


def smooth_step(edge0: float, edge1: float, x: float) -> float:
    """
    Hermite 平滑插值
    在 edge0 和 edge1 之间进行平滑过渡

    Args:
        edge0: 下边界值
        edge1: 上边界值
        x: 输入值

    Returns:
        平滑插值结果,范围 [0, 1]
    """
    t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def clamp(value: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """
    将值约束在指定范围内

    Args:
        value: 待约束的值
        min_val: 最小值
        max_val: 最大值

    Returns:
        约束后的值
    """
    if value < min_val:
        return min_val
    if value > max_val:
        return max_val
    return value
