"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(灯光控制模态参数 / 快捷键)
- get_prefs: 取本插件偏好实例

面板为左右两列布局(不再分页签):
- 左列: Light Control(灯光控制模态的区域归一幅度与精确比率)
- 右列: 本插件已注册的快捷键列表(饼菜单 + 灯光控制), 附 rna_keymap_ui 的标准改键控件

注: 列表的"选区同步"与"显示0用户"开关在面板选项菜单内,
状态存 WM 级 SceneHelperState, 不随 .blend 保存.
"""

from math import radians

import bpy
from bpy.types import AddonPreferences, Context, KeyConfig, UILayout
from rna_keymap_ui import draw_kmi

from .config import __addon_name__
from .keymaps import addon_keymaps


def _draw_hotkey_column(layout: UILayout, title: str, icon: str, groups: list, kc: KeyConfig) -> None:
    """绘制单列快捷键分组列表"""
    col = layout.box()
    col.label(text=title, icon=icon)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            try:
                draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
            except (ReferenceError, AttributeError, ValueError):
                # 用户在本页删除快捷键后, 保存的 kmi 句柄会失效; 跳过该行而不是让整页绘制崩溃
                split.label(text="(removed)")
        row.separator(factor=1, type='LINE')


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    # 灯光控制模态的区域归一幅度与 Shift 精确比率
    light_rig_angle_sweep: bpy.props.FloatProperty(
        name="Angle Sweep",
        description="Rotation for azimuth / elevation while the mouse crosses the full region width (modal L)",
        subtype='ANGLE',
        default=radians(180.0),
        min=0.0,
    )  # type: ignore
    light_rig_power_span: bpy.props.FloatProperty(
        name="Power Span",
        description="Brightness change while the mouse crosses the full region width (modal L)",
        subtype='POWER',
        default=1000.0,
        min=0.0,
    )  # type: ignore
    light_rig_distance_span: bpy.props.FloatProperty(
        name="Distance Span",
        description="Distance change while the mouse crosses the full region width (modal L)",
        subtype='DISTANCE',
        default=5.0,
        min=0.0,
    )  # type: ignore
    light_rig_shift_factor: bpy.props.FloatProperty(
        name="Precise Factor",
        description="Adjustment rate multiplier while Shift is held (modal L)",
        subtype='FACTOR',
        default=0.5,
        min=0.01,
        max=1.0,
    )  # type: ignore

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 左右两列: 左列参数设置, 右列快捷键(饼菜单 + 灯光控制)
        columns = layout.split(factor=0.4)

        # 左列: 灯光控制模态参数
        left = columns.column()
        box = left.box()
        box.label(text="Light Control", icon='ORIENTATION_GIMBAL')
        box.use_property_split = True
        box.use_property_decorate = False
        col = box.column(align=True)
        col.prop(self, "light_rig_angle_sweep", text="Angle Sweep")
        col.prop(self, "light_rig_power_span", text="Power Span")
        col.prop(self, "light_rig_distance_span", text="Distance Span")
        col.prop(self, "light_rig_shift_factor", text="Precise Factor")

        # 右列: 快捷键列表(饼菜单 + 灯光控制)
        right = columns.column()
        groups = [(name, items) for name, items in addon_keymaps.items()]
        _draw_hotkey_column(right, "Hotkeys", "KEY_COMMAND", groups, kc)


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
