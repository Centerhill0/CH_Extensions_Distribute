"""
列表行内动作算子模块

提供以下功能:
- ObjectSelect: 选中物体(Shift 切换选中, Ctrl 选中灯光的控制器), 行内选择按钮
- CameraSetView: 选中相机并切到相机视角
- ObjectViewportToggle / ObjectRenderToggle: 行内"在视图中禁用/在渲染中禁用"开关
  (+Ctrl 隔离同类, 再点恢复; 灯光的控制器视口可见位单向跟随灯光)
- FakeUserToggle: 伪用户开关(行内按钮, 图标随状态刷新; 库链接数据块置灰拒绝)

算法与状态访问分别在 utils 与 scene_state, 本模块只做上下文交互与报告.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...handlers import tag_3d_views
from ...scene_state import blocks_for, get_state, highlight_item, resolve_id
from ...utils import apply_light_isolate_world_mute, is_selectable, light_collections_isolated_by_hiding, rig_controller_of, select_object, select_only, sync_active_camera_resolution, sync_controllers_visibility, world_output_muted
from ._base import TranslatedDescriptionMixin


def resolve_object_block(scene, name: str, linked: bool):
    """按名称 + 库链接标记取场景物体(同名本地/链接对消歧), 都不匹配返回 None

    复制链接物体会产生同名本地副本, 且场景里同名本地/链接物体可共存(实测 5.1.2),
    行内算子必须按行标记消歧(与 scene_state._resolve_object 同口径).
    """
    obj = scene.objects.get(name)
    if obj is None:
        return None
    if bool(obj.library) == bool(linked):
        return obj
    for candidate in scene.objects:
        if candidate.name == name and bool(candidate.library) == bool(linked):
            return candidate
    return None


class ObjectSelect(TranslatedDescriptionMixin, Operator):
    """选中行内物体并高亮该列表项(+Shift 切换选中/减选; +Ctrl 选灯光的控制器)"""

    bl_idname = "ch.object_select"
    bl_label = "Select Object"
    bl_description = "Select this object and highlight its list item\n+Shift: Toggle selection\n+Ctrl: Select the controller empty of the light (lights with a controller only)"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore
    obj_linked: BoolProperty(name="Linked", description="Whether the object is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    list_kind: EnumProperty(name="List", items=(("cameras", "Cameras", ""), ("lights", "Lights", "")), default="cameras")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Select the light's controller empty instead of the light (set by +Ctrl)")  # type: ignore

    def execute(self, context: Context):
        return self._select(context, toggle=False, use_controller=self.is_ctrl)

    def invoke(self, context: Context, event: Event):
        self.is_ctrl = bool(event.ctrl)
        return self._select(context, toggle=bool(event.shift), use_controller=self.is_ctrl)

    def _select(self, context: Context, toggle: bool, use_controller: bool = False):
        """独占选中/切换选中(invoke/execute 共用; execute 直调按独占处理)

        高亮跟随活动项: 减选非活动项时高亮留在活动项行; 减选活动项时活动与高亮
        一起跳回列表序中前一个仍选中的项(没有则清空活动物体, 高亮留在原行).
        全部取消选中是合法状态(+Shift 逐个减选即可清空, 作者 2026-10-24 定).
        +Ctrl 选中灯光的控制器空物体(没有控制器则照常选灯光), 高亮始终留在灯光行;
        加选路径把活动物体切到控制器, 作为模态算子(L)的空物体侧入口.
        """
        obj = resolve_object_block(context.scene, self.obj_name, self.obj_linked)
        if obj is None:
            return {'CANCELLED'}
        target = obj
        if use_controller and obj.type == 'LIGHT':
            controller = rig_controller_of(obj)
            if controller is not None:
                target = controller
        if not toggle:
            select_object(context, target)
            highlight_item(context, self.list_kind, obj.name, 'OBJECT')
        elif target.select_get():
            select_object(context, target, deselect=True)
            self._jump_back(context, obj)
        else:
            select_object(context, target, extend=True)
            if target is not obj and is_selectable(context, target):
                # 加选控制器时把活动物体切到控制器(模态算子 L 的空物体侧入口);
                # 控制器在被排除集合时不可设活动(5.1.2 抛 RuntimeError), 守卫跳过
                context.view_layer.objects.active = target
            highlight_item(context, self.list_kind, obj.name, 'OBJECT')
        return {'FINISHED'}

    def _jump_back(self, context: Context, obj) -> None:
        """减选的是活动项: 活动物体与列表高亮跳回列表序中最近的仍选中项

        优先取前一个, 前方没有则取后方最近的(否则减选列表首个选中项时无目标,
        高亮会留在已减选行); 没有任何剩余选中项则清空活动物体, 高亮留在原行.
        """
        if context.view_layer.objects.active is not obj:
            act = context.view_layer.objects.active
            if act is not None:
                highlight_item(context, self.list_kind, act.name, 'OBJECT')
            return
        prev = None
        after = None
        passed = False
        for block in blocks_for(context, self.list_kind):
            if block is None:
                continue
            if block is obj:
                passed = True
                continue
            if not block.select_get():
                continue
            if not passed:
                prev = block
            elif after is None:
                after = block
        target = prev if prev is not None else after
        if target is not None:
            context.view_layer.objects.active = target
            highlight_item(context, self.list_kind, target.name, 'OBJECT')
        else:
            context.view_layer.objects.active = None


class CameraSetView(Operator):
    """选中相机并切换到该相机视角"""

    bl_idname = "ch.camera_set_view"
    bl_label = "Set View"
    bl_description = "Select this camera and look through it"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore
    obj_linked: BoolProperty(name="Linked", description="Whether the object is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        obj = resolve_object_block(context.scene, self.obj_name, self.obj_linked)
        if obj is None or obj.type != 'CAMERA':
            self.report({'WARNING'}, report("Camera not found"))
            return {'CANCELLED'}
        select_only(context, [obj])
        context.scene.camera = obj
        # 独立分辨率即时跟随(改场景相机的其它路径由 handlers 兜底, 此处求即时)
        sync_active_camera_resolution(context.scene)
        space = getattr(context, "space_data", None)
        if space is not None and getattr(space, "type", "") == 'VIEW_3D' and bpy.ops.view3d.object_as_camera.poll():
            bpy.ops.view3d.object_as_camera()
        return {'FINISHED'}


class _ObjectDisableMixin:
    """行内禁用开关的共享实现(普通混入类, 不参与注册); attr 由子类指定

    视口/渲染拆成两个算子类是必须的: 同一行画两个同 bl_idname 的按钮, 重绘时按钮
    按名字匹配复用旧属性, 后画按钮设的标志会串到先画按钮上(2026-10-27 作者实测).
    """

    attr = "hide_viewport"
    # 普通缺省值: 直调(EXEC_DEFAULT)绕过 invoke 时 isolate 可读(子类 RNA 声明在注册时接管)
    isolate = False

    def invoke(self, context: Context, event: Event):
        self.isolate = bool(event is not None and event.ctrl)
        return self.execute(context)

    def execute(self, context: Context):
        scene = context.scene
        obj = resolve_object_block(scene, self.obj_name, self.obj_linked)
        if obj is None:
            return {'CANCELLED'}
        attr = self.attr
        if not self.isolate:
            setattr(obj, attr, not getattr(obj, attr))
            self._sync_controller_visibility(context, obj, attr)
            return {'FINISHED'}
        # +Ctrl 隔离: 目标态 = 其余同类里还有可见项 -> 隐藏它们; 已全部隐藏 -> 恢复
        others = [other for other in scene.objects if other is not obj and other.type == obj.type]
        isolate_active = any(not getattr(other, attr) for other in others)
        for other in others:
            setattr(other, attr, isolate_active)
        setattr(obj, attr, False)
        if obj.type == 'LIGHT':
            if not others:
                # 场景只有这一盏灯: 没有同类可隐藏, 视口/渲染两档隔离都落到世界上(按世界
                # 屏蔽位记住隔离态, 再点一次即恢复), 见 utils.blender.light.world_output_muted
                isolate_active = not world_output_muted(scene.world)
            # 开关状态见 props.lights_mute_world(与灯光集合隔离共用), 恢复口径见
            # utils.apply_light_isolate_world_mute; 聚合归位同时尊重集合侧仍生效的隔离
            # (只信 hide 位口径, 归属说明见 utils.lights_isolated_by_hiding)
            apply_light_isolate_world_mute(scene, isolate_active or light_collections_isolated_by_hiding(context.view_layer), get_state(context).lights_mute_world)
            # 静音连线不触发着色器重估与视口重绘, 显式刷新
            tag_3d_views()
        self._sync_controller_visibility(context, obj, attr)
        return {'FINISHED'}

    def _sync_controller_visibility(self, context: Context, obj, attr: str) -> None:
        """灯光的视口开关联动其控制器空物体(单向跟随)

        行内开关与 +Ctrl 隔离两路统一收口到 sync_controllers_visibility: 灯光藏
        控制器跟着藏, 恢复跟着显; 渲染位不涉及空物体, 不同步.
        """
        if obj.type == 'LIGHT' and attr == "hide_viewport":
            sync_controllers_visibility(context.scene)


class ObjectViewportToggle(_ObjectDisableMixin, TranslatedDescriptionMixin, Operator):
    """行内"在视图中禁用"开关, +Ctrl 隔离同类(隐藏其余同类, 再点恢复); 灯光的控制器跟随"""

    bl_idname = "ch.object_disable_viewport"
    bl_label = "Disable in Viewport"
    bl_description = "Toggle viewport visibility for this object\n+Ctrl: Show only this object among the objects of the same type (isolate), click again to restore\nLights with a controller: the controller empty follows this toggle"
    bl_options = {'REGISTER', 'UNDO'}

    attr = "hide_viewport"
    obj_name: StringProperty(name="Name")  # type: ignore
    obj_linked: BoolProperty(name="Linked", description="Whether the object is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    isolate: BoolProperty(options={'HIDDEN'}, default=False, description="Isolate among the same-type objects instead of toggling (set by +Ctrl)")  # type: ignore


class ObjectRenderToggle(_ObjectDisableMixin, TranslatedDescriptionMixin, Operator):
    """行内"在渲染中禁用"开关, +Ctrl 隔离同类(排除其余同类渲染, 再点恢复)"""

    bl_idname = "ch.object_disable_render"
    bl_label = "Disable in Render"
    bl_description = "Toggle render exclusion for this object\n+Ctrl: Render only this object among the objects of the same type (isolate), click again to restore"
    bl_options = {'REGISTER', 'UNDO'}

    attr = "hide_render"
    obj_name: StringProperty(name="Name")  # type: ignore
    obj_linked: BoolProperty(name="Linked", description="Whether the object is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    isolate: BoolProperty(options={'HIDDEN'}, default=False, description="Isolate among the same-type objects instead of toggling (set by +Ctrl)")  # type: ignore


class FakeUserToggle(Operator):
    """切换数据块的伪用户标记(列表行内按钮)"""

    bl_idname = "ch.fake_user_toggle"
    bl_label = "Fake User"
    bl_description = "Keep this data-block saved even when it has no users"
    bl_options = {'REGISTER', 'UNDO'}

    id_name: StringProperty(name="Name")  # type: ignore
    id_kind: StringProperty(name="Kind")  # type: ignore
    id_linked: BoolProperty(name="Linked", description="Whether the data-block is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        datablock = resolve_id(self.id_kind, self.id_name, self.id_linked)
        if datablock is None:
            return {'CANCELLED'}
        if datablock.library is not None:
            # 库链接数据块的伪用户无意义(标志挂在库数据上, 会话内"生效"但重载即丢):
            # 按钮在面板侧保持可点(不置灰)但不动作(作者 2026-10-27 定), 此处静默返回
            return {'CANCELLED'}
        datablock.use_fake_user = not datablock.use_fake_user
        return {'FINISHED'}
