"""
数学计算子包

公共 API 经由本 __init__ 再导出至 utils 顶层命名空间;
未在此列出的模块成员为子包内部协作 API, 仅供 utils 内部使用.
"""

from .color import linear_to_srgb
from .core import (
    lerp,
    find_outliers,
)
from .geometry import (
    get_distance_between_points,
    get_lerp_position,
    get_vertex_coords,
    get_edge_direction,
    get_average_position,
    get_average_normals,
    get_face_angle,
    get_edge_angle,
    calc_loop_normal,
    get_edge_end_coords,
    get_circumcenter,
    get_circle_points,
    is_point_in_polygon_2d,
)
from .interpolation import (
    hermite_1d,
    hermite_3d,
    smooth_step,
    clamp,
)
from .transform import (
    apply_matrix_to_points,
    get_rotation_difference_matrix,
    transform_normal_to_world,
    generate_local_coordinate_system,
    get_rotation_matrix_from_vert,
    get_rotation_matrix_from_edge,
    get_rotation_matrix_from_face,
)

__all__ = [
    "linear_to_srgb",
    "lerp",
    "find_outliers",
    "get_distance_between_points",
    "get_lerp_position",
    "get_vertex_coords",
    "get_edge_direction",
    "get_average_position",
    "get_average_normals",
    "get_face_angle",
    "get_edge_angle",
    "calc_loop_normal",
    "get_edge_end_coords",
    "get_circumcenter",
    "get_circle_points",
    "is_point_in_polygon_2d",
    "hermite_1d",
    "hermite_3d",
    "smooth_step",
    "clamp",
    "apply_matrix_to_points",
    "get_rotation_difference_matrix",
    "transform_normal_to_world",
    "generate_local_coordinate_system",
    "get_rotation_matrix_from_vert",
    "get_rotation_matrix_from_edge",
    "get_rotation_matrix_from_face",
]
