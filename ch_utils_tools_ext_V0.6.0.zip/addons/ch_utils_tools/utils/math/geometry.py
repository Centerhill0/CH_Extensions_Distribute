"""
几何计算模块

提供角度, 距离, 位置等几何计算功能.

主要功能:
- get_distance_between_points: 计算两点距离
- get_lerp_position: 计算插值位置
- get_vertex_coords: 获取顶点坐标数组
- get_edge_direction: 计算边方向
- get_average_position: 计算平均位置
- get_average_normals: 计算平均法线
- get_face_angle: 获取面夹角
- get_edge_angle: 获取边夹角
- calc_loop_normal: 以 Newell 法计算顶点环法线
- get_edge_end_coords: 按目标长度计算边的两端新坐标
- get_circumcenter: 计算三点外接圆圆心
- get_circle_points: 计算闭合圆环的均分点列
- is_point_in_polygon_2d: 判断点是否在二维多边形内
"""

import math
from math import pi, degrees

import numpy as np
from mathutils import Vector, Matrix
from bmesh.types import BMVert, BMEdge

from .._constants import INTERSECT_EPSILON


def get_distance_between_points(pt_a: BMVert | Vector, pt_b: BMVert | Vector) -> float:
    """
    计算两个点之间的距离
    Args:
        pt_a: 点A或顶点A
        pt_b: 点B或顶点B
    Returns:
        两点之间的距离, 输入无效时返回 0.0
    """
    if not (pt_a and pt_b):
        return 0.0
    co_a = pt_a.co if hasattr(pt_a, 'co') else pt_a
    co_b = pt_b.co if hasattr(pt_b, 'co') else pt_b
    return (co_b - co_a).length


def get_lerp_position(pt_a: BMVert | Vector, pt_b: BMVert | Vector, factor: float = 0.5) -> Vector:
    """
    计算两个顶点或点之间的插值位置
    Args:
        pt_a: 顶点A或点A
        pt_b: 顶点B或点B
        factor: 插值比例,默认0.5表示中点
    Returns:
        插值位置,输入无效则返回零向量
    """
    if not (pt_a and pt_b):
        return Vector()
    co_a = pt_a.co if hasattr(pt_a, 'co') else pt_a
    co_b = pt_b.co if hasattr(pt_b, 'co') else pt_b
    return co_a + (co_b - co_a) * factor


def get_vertex_coords(mesh, mx: Matrix | None = None, offset: float = 0, return_edge_indices: bool = False) -> np.ndarray | tuple[np.ndarray, np.ndarray]:
    """
    获取网格顶点坐标数组

    高效提取网格顶点坐标,支持法线偏移, 矩阵变换和边索引返回.

    Args:
        mesh: Blender网格数据对象
        mx: 变换矩阵,用于将坐标转换到目标空间,默认None表示不变换
        offset: 沿法线方向的偏移距离,默认0表示不偏移
        return_edge_indices: 是否同时返回边的顶点索引数组

    Returns:
        顶点坐标数组,形状为(顶点数, 3),类型为np.float32
        如果return_edge_indices为True,则返回(坐标数组, 边索引数组)元组
    """
    vertices = mesh.vertices
    vert_count = len(vertices)

    coords = np.empty((vert_count, 3), dtype=np.float32)
    vertices.foreach_get('co', np.reshape(coords, vert_count * 3))

    if offset:
        normals = np.empty((vert_count, 3), dtype=np.float32)
        vertices.foreach_get('normal', np.reshape(normals, vert_count * 3))
        coords += normals * offset

    if mx is not None:
        coords_4d = np.ones((vert_count, 4), dtype=np.float32)
        coords_4d[:, :-1] = coords
        coords = np.einsum('ij,aj->ai', mx, coords_4d)[:, :-1]
        coords = np.float32(coords)

    if return_edge_indices:
        edges = mesh.edges
        edge_indices = np.empty((len(edges), 2), dtype=np.int32)
        edges.foreach_get('vertices', np.reshape(edge_indices, len(edges) * 2))
        return coords, edge_indices

    return coords


def get_edge_direction(pt_a: BMVert, pt_b: BMVert) -> Vector:
    """
    计算两个顶点之间的边方向(A 指向 B 的单位向量)
    Args:
        pt_a: 顶点A
        pt_b: 顶点B
    Returns:
        归一化边方向向量,输入无效则返回零向量
    """
    if not (pt_a and pt_b):
        return Vector()
    return (pt_b.co - pt_a.co).normalized()


def get_average_position(pts_co_list: list[Vector]) -> Vector:
    """
    计算顶点列表的平均位置
    Args:
        pts_co_list: 顶点位置矢量列表
    Returns:
        平均位置,列表为空则返回零向量
    """
    if not pts_co_list:
        return Vector()
    return sum(pts_co_list, Vector()) / len(pts_co_list)


def get_average_normals(normal_list: list[Vector]) -> Vector:
    """
    计算法线列表的平均法线
    Args:
        normal_list: 法线列表
    Returns:
        平均法线,列表为空则返回零向量
    """
    if not normal_list:
        return Vector()
    return sum(normal_list, Vector()).normalized()


def get_face_angle(edge: BMEdge, signed: bool = False, deg: bool = True, fallback: float = 9999.0) -> float:
    """
    获取边的面夹角(弧度或角度,支持符号)
    Args:
        edge: BMEdge对象
        signed: 是否返回带符号的夹角(True为带符号,False为绝对值)
        deg: 是否返回角度(True为角度,False为弧度)
        fallback: 计算失败时的默认值
    Returns:
        边的面夹角(float,单位由deg决定)
    """
    angle = edge.calc_face_angle_signed(fallback) if signed else edge.calc_face_angle(fallback)
    return math.degrees(angle) if deg else angle


def get_edge_angle(edge1: BMEdge, edge2: BMEdge, radians: bool = True) -> float:
    """
    计算两条边之间的夹角

    如果两条边共享一个顶点,则以该公共顶点为夹角中心点;
    否则以两条边的方向向量计算夹角(不共享顶点时可能无几何意义).

    Args:
        edge1: 第一条边
        edge2: 第二条边
        radians: 是否返回弧度值(True返回弧度,False返回角度)
    Returns:
        两条边之间的夹角
    """
    if not edge1.calc_length() or not edge2.calc_length():
        return pi

    shared_vert = None
    for vert in edge1.verts:
        if vert in edge2.verts:
            shared_vert = vert
            break

    if shared_vert:
        vec1 = shared_vert.co - edge1.other_vert(shared_vert).co
        vec2 = shared_vert.co - edge2.other_vert(shared_vert).co
    else:
        vec1 = edge1.verts[0].co - edge1.verts[1].co
        vec2 = edge2.verts[0].co - edge2.verts[1].co

    angle = vec1.angle(vec2)
    return angle if radians else degrees(angle)


def calc_loop_normal(verts: list[BMVert | Vector], fallback: Vector | None = None) -> Vector:
    """
    以 Newell 法计算顶点环的法线

    闭合环以首元素与末元素为同一对象标记; 半开环按闭合多边形积分.

    Args:
        verts: 有序顶点或坐标列表, 闭合环时首尾为同一元素
        fallback: 环法线退化(零向量)时的回退值
    Returns:
        归一化环法线, 退化时返回 fallback(未提供则为零向量)
    """
    normal = Vector()
    coords = [v.co if hasattr(v, 'co') else v for v in verts]
    step_range = range(1, len(verts)) if verts[0] is verts[-1] else range(len(verts))

    for idx in step_range:
        co_a, co_b = coords[idx - 1], coords[idx]
        normal.x += (co_a.y - co_b.y) * (co_a.z + co_b.z)
        normal.y += (co_a.z - co_b.z) * (co_a.x + co_b.x)
        normal.z += (co_a.x - co_b.x) * (co_a.y + co_b.y)

    if normal != Vector():
        return normal.normalized()
    return fallback.copy() if fallback else Vector()


def get_edge_end_coords(co_a: Vector, co_b: Vector, target_length: float, anchor: str = 'CENTER') -> tuple[tuple[Vector, Vector] | None, str | None]:
    """
    按目标长度计算边的两端新坐标(方向保持原边方向)

    Args:
        co_a: 端点A坐标
        co_b: 端点B坐标
        target_length: 目标长度
        anchor: 锚定方式('CENTER'两端对称缩放 / 'START'固定A端 / 'END'固定B端)
    Returns:
        ((新A坐标, 新B坐标), 错误信息) 元组, 失败时结果为 None
    """
    vec = co_b - co_a
    if vec.length == 0.0:
        return None, "Degenerate edge with zero length"
    if target_length <= 0.0:
        return None, "Target length must be positive"

    vec.length = target_length
    if anchor == 'START':
        return (co_a.copy(), co_a + vec), None
    if anchor == 'END':
        return (co_b - vec, co_b.copy()), None

    center_co = (co_a + co_b) / 2
    return (center_co - vec / 2, center_co + vec / 2), None


def get_circumcenter(pt_a: Vector, pt_b: Vector, pt_c: Vector) -> tuple[Vector | None, str | None]:
    """
    计算三点外接圆圆心

    Args:
        pt_a: 点A坐标
        pt_b: 点B坐标
        pt_c: 点C坐标
    Returns:
        (圆心坐标, 错误信息) 元组, 三点共线时圆心为 None
    """
    vec_ab = pt_b - pt_a
    vec_ac = pt_c - pt_a
    normal_vec = vec_ab.cross(vec_ac)
    # 叉积长度相对两边长之积过小即视为共线(尺度无关), 退化边同样落入此分支
    if normal_vec.length <= INTERSECT_EPSILON * vec_ab.length * vec_ac.length:
        return None, "Selected points are collinear"

    center = pt_a + (vec_ac.length_squared * normal_vec.cross(vec_ab)
                     + vec_ab.length_squared * vec_ac.cross(normal_vec)) / (2.0 * normal_vec.length_squared)
    return center, None


def get_circle_points(center: Vector, anchor: Vector, axis: Vector, count: int, scale: float = 1.0) -> list[Vector]:
    """
    计算闭合圆环的均分点列

    以 anchor 到 center 的方向为起点, 绕 axis 均分 count 份;
    anchor 与 center 的连线须垂直于 axis(圆所在平面内).

    Args:
        center: 圆心坐标
        anchor: 起始参考点(圆上一点, 与 center 距离乘 scale 为半径)
        axis: 圆面法线(单位向量)
        count: 点数, 小于 3 时按 3 处理
        scale: 半径缩放系数
    Returns:
        count 个圆上坐标(与输入同空间)
    """
    radius_vec = (anchor - center) * scale
    count = max(3, count)
    return [center + Matrix.Rotation(2.0 * pi * idx / count, 4, axis) @ radius_vec for idx in range(count)]


def is_point_in_polygon_2d(poly_pts: list[Vector], pt: Vector) -> bool:
    """
    判断点是否在二维多边形内(even-odd 奇偶规则, 仅取 x/y 分量)

    Args:
        poly_pts: 多边形顶点坐标列表(按序排列, 是否闭合重复尾点均可)
        pt: 待判定点坐标
    Returns:
        点位于多边形内返回 True
    """
    inside = False
    count = len(poly_pts)
    for idx in range(count):
        co_a = poly_pts[idx]
        co_b = poly_pts[(idx + 1) % count]
        if (co_a.y > pt.y) != (co_b.y > pt.y):
            x_cross = co_a.x + (pt.y - co_a.y) / (co_b.y - co_a.y) * (co_b.x - co_a.x)
            if pt.x < x_cross:
                inside = not inside
    return inside
