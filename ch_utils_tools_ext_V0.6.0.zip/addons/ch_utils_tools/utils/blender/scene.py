"""
场景视图工具模块

提供UI缩放, 视图轴向, 空间变换, 光标操作等功能.

主要功能:
- set_cursor_rotation: 根据光标的旋转模式设置旋转
- set_cursor_transform: 设置光标位置和旋转
- get_view_aligned_axes: 获取3D空间轴向相对视图XY轴的对应关系
- get_zoom_factor: 计算视图缩放因子
- get_view_origin_and_dir: 获取视图的原点和方向向量
- is_on_screen: 检查2D坐标是否在屏幕范围内
- get_location_2d: 将3D坐标转换为2D屏幕坐标
- get_ui_scale: 获取当前Blender UI缩放比例
- get_length_unit_symbol: 按场景单位设置返回长度单位符号
- transform_local_to_space: 获取将顶点从局部空间转换到目标空间的变换矩阵
- transform_space_to_local: 获取将坐标从目标空间转换回物体局部空间的变换矩阵
- get_space_transform_matrix: 获取空间坐标系矩阵
"""

import bpy
from bpy.types import Context, Object, View3DCursor
from mathutils import Vector, Matrix, Quaternion
from bpy_extras.view3d_utils import (
    region_2d_to_location_3d,
    location_3d_to_region_2d,
    region_2d_to_origin_3d,
    region_2d_to_vector_3d,
)


def set_cursor_rotation(cursor: View3DCursor, rot: Quaternion) -> None:
    """
    根据光标的旋转模式设置旋转

    Args:
        cursor: 光标对象
        rot: 旋转四元数
    """
    if cursor.rotation_mode == 'QUATERNION':
        cursor.rotation_quaternion = rot
    elif cursor.rotation_mode == 'AXIS_ANGLE':
        cursor.rotation_axis_angle = rot.to_axis_angle()
    else:
        cursor.rotation_euler = rot.to_euler(cursor.rotation_mode)


def set_cursor_transform(context: Context, mx: Matrix = None, loc: Vector = None, rot: Quaternion = None) -> None:
    """
    设置光标位置和旋转

    Args:
        context: 上下文
        mx: 变换矩阵, 如果提供将优先使用
        loc: 位置向量, 当mx未提供时使用
        rot: 旋转四元数, 当mx未提供时使用
    """
    cursor = context.scene.cursor
    if mx:
        cursor.location = mx.to_translation()
        cursor.rotation_quaternion = mx.to_quaternion()
        cursor.rotation_mode = 'QUATERNION'
    else:
        cursor.location = loc if loc else Vector()
        if rot:
            set_cursor_rotation(cursor, rot)


def get_view_aligned_axes(context: Context, mx: Matrix = Matrix()) -> tuple[int, int, bool, bool]:
    """
    获取3D空间轴向相对视图XY轴的对应关系

    Args:
        context: Blender上下文
        mx: 变换矩阵

    Returns:
        (x轴索引, y轴索引, x轴是否翻转, y轴是否翻转)
    """
    r3d = context.space_data.region_3d
    view_right = r3d.view_rotation @ Vector((1, 0, 0))
    view_up = r3d.view_rotation @ Vector((0, 1, 0))

    axes_right, axes_up = [], []
    rot_mx = mx.to_3x3()

    for idx, axis in enumerate((Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1)))):
        space_axis = rot_mx @ axis
        axes_right.append((view_right.dot(space_axis), idx))
        axes_up.append((view_up.dot(space_axis), idx))

    axis_right = max(axes_right, key=lambda x: abs(x[0]))
    right_idx = axis_right[1]

    axes_up_filtered = [item for item in axes_up if item[1] != right_idx]
    axis_up = max(axes_up_filtered, key=lambda x: abs(x[0]))
    up_idx = axis_up[1]

    is_flip_right = axis_right[0] < 0
    is_flip_up = axis_up[0] < 0

    return right_idx, up_idx, is_flip_right, is_flip_up


def get_zoom_factor(context: Context, depth_location: Vector, scale: float = 10, ignore_obj_scale: bool = False) -> float:
    """
    计算视图缩放因子,用于将屏幕像素距离转换为3D空间距离

    Args:
        context: Blender上下文
        depth_location: 深度参考点(3D坐标),用于确定投影的深度平面
        scale: 屏幕像素距离,默认为10像素
        ignore_obj_scale: 是否忽略物体缩放,默认为False(考虑物体缩放)

    Returns:
        视图缩放因子(单位/像素),默认表示10像素对应的3D空间距离
    """
    center = Vector((context.region.width / 2, context.region.height / 2))
    offset = center + Vector((scale, 0))

    center_3d = region_2d_to_location_3d(context.region, context.region_data, center, depth_location)
    offset_3d = region_2d_to_location_3d(context.region, context.region_data, offset, depth_location)

    zoom_factor = (center_3d - offset_3d).length

    if context.active_object and not ignore_obj_scale:
        mx = context.active_object.matrix_world.to_3x3()

        zoom_vector = mx.inverted_safe() @ Vector((zoom_factor, 0, 0))
        zoom_factor = zoom_vector.length

    return zoom_factor


def get_view_origin_and_dir(context: Context, coord: Vector | None = None) -> tuple[Vector, Vector]:
    """
    获取视图的原点和方向向量

    Args:
        context: Blender上下文
        coord: 2D屏幕坐标,默认为视图中心

    Returns:
        (视图原点, 视图方向向量)
    """
    if coord is None:
        coord = Vector((context.region.width / 2, context.region.height / 2))

    view_origin = region_2d_to_origin_3d(context.region, context.region_data, coord)
    view_dir = region_2d_to_vector_3d(context.region, context.region_data, coord)

    return view_origin, view_dir


def is_on_screen(context: Context, co2d: Vector) -> bool:
    """
    检查2D坐标是否在屏幕范围内

    Args:
        context: Blender上下文
        co2d: 2D屏幕坐标

    Returns:
        是否在屏幕内
    """
    if co2d is None:
        return False

    return 0 < co2d.x < context.region.width and 0 < co2d.y < context.region.height


def get_location_2d(context: Context, co3d: Vector, default: tuple = (0, 0)) -> Vector:
    """
    将3D坐标转换为2D屏幕坐标

    Args:
        context: Blender上下文
        co3d: 3D坐标
        default: 默认值,当转换失败时返回

    Returns:
        2D屏幕坐标
    """
    if default == 'OFF_SCREEN':
        default = Vector((-1000, -1000))

    co2d = location_3d_to_region_2d(context.region, context.region_data, co3d)

    if co2d is None:
        return Vector(default)

    return Vector(round(i) for i in co2d)


# -----------------------------Others--------------------------------
def get_ui_scale() -> float:
    """获取当前Blender UI缩放比例"""
    return bpy.context.preferences.system.ui_scale


def get_length_unit_symbol(context: Context) -> str:
    """
    按场景单位设置返回长度单位符号(header 数值显示用)

    Args:
        context: Blender上下文
    Returns:
        长度单位符号(如 'm'/'cm'/'mm'/'ft')
    """
    unit_settings = context.scene.unit_settings
    symbols = {'METERS': 'm', 'CENTIMETERS': 'cm', 'MILLIMETERS': 'mm', 'MICROMETERS': 'µm',
               'FEET': 'ft', 'INCHES': 'in',
               'ADAPTIVE': 'm' if unit_settings.system == 'METRIC' else 'ft'}
    return symbols.get(unit_settings.length_unit, 'm')


def _get_space_basis(context: Context, obj: Object, space: str) -> Matrix:
    """
    获取目标空间在世界中的基准矩阵

    Args:
        context: Blender上下文
        obj: 物体对象
        space: 目标空间 ('LOCAL', 'WORLD', 'CURSOR')

    Returns:
        空间基准矩阵
    Raises:
        ValueError: 未知的空间类型
    """
    match space:
        case 'LOCAL':
            return obj.matrix_world
        case 'WORLD':
            return Matrix()
        case 'CURSOR':
            return context.scene.cursor.matrix
        case _:
            raise ValueError(f"未知的空间类型: {space}")


def transform_local_to_space(context: Context, obj: Object, space: str) -> Matrix:
    """
    获取将顶点从局部空间转换到目标空间的变换矩阵

    Args:
        context: Blender上下文
        obj: 物体对象
        space: 目标空间 ('LOCAL', 'WORLD', 'CURSOR')

    Returns:
        变换矩阵
    """
    return _get_space_basis(context, obj, space).inverted_safe() @ obj.matrix_world


def transform_space_to_local(context: Context, obj: Object, space: str) -> Matrix:
    """
    获取将坐标从目标空间转换回物体局部空间的变换矩阵

    Args:
        context: Blender上下文
        obj: 物体对象
        space: 目标空间 ('LOCAL', 'WORLD', 'CURSOR')

    Returns:
        逆变换矩阵
    """
    return obj.matrix_world.inverted_safe() @ _get_space_basis(context, obj, space)


def get_space_transform_matrix(context: Context, obj: Object, space: str) -> Matrix:
    """
    获取空间坐标系矩阵(该空间在世界中的基准矩阵)

    Args:
        context: Blender上下文
        obj: 物体对象
        space: 空间类型 ('LOCAL', 'WORLD', 'CURSOR')

    Returns:
        空间矩阵
    """
    return _get_space_basis(context, obj, space)
