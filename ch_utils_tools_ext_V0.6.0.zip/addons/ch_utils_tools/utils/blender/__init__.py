"""
Blender API 封装子包

公共 API 经由本 __init__ 再导出至 utils 顶层命名空间;
未在此列出的模块成员为子包内部协作 API, 仅供 utils 内部使用.
"""

from .collection import get_collection
from .curve_symmetrize import (
    get_mirror_plane,
    compute_symmetrized_splines,
)
from .curve import (
    SplinePoint,
    SplineData,
    CurveData,
    get_curve_data,
    has_active_spline,
    has_active_selection,
    is_active_end_selected,
    is_active_selection_continuous,
    get_curve_selection_indices,
    create_spline_from_data,
    update_selection_history,
)
from .material import (
    get_material_output,
    get_last_node,
)
from .modifier import (
    remove_modifier,
    add_boolean_modifier,
    add_displace_modifier,
    add_lattice_modifier,
    add_shrinkwrap_modifier,
    get_shrinkwrap_modifier,
    get_mirror_planes,
)
from .object import (
    get_evaluated_object,
    get_evaluated_objects,
    compensate_children,
    set_object_origin,
    set_object_parent,
    clear_object_parent,
)
from .raycast import (
    RaycastCache,
    raycast_from_point,
    raycast_from_mouse,
    raycast_scene,
    get_hittable_objects,
)
from .scene import (
    set_cursor_rotation,
    set_cursor_transform,
    get_view_aligned_axes,
    get_zoom_factor,
    get_view_origin_and_dir,
    is_on_screen,
    get_location_2d,
    get_ui_scale,
    get_length_unit_symbol,
    transform_local_to_space,
    transform_space_to_local,
    get_space_transform_matrix,
)
from .snap import (
    Snap,
    SnapCache,
)
from .vertex_group import add_vgroup

__all__ = [
    "get_collection",
    "get_mirror_plane",
    "compute_symmetrized_splines",
    "SplinePoint",
    "SplineData",
    "CurveData",
    "get_curve_data",
    "has_active_spline",
    "has_active_selection",
    "is_active_end_selected",
    "is_active_selection_continuous",
    "get_curve_selection_indices",
    "create_spline_from_data",
    "update_selection_history",
    "get_material_output",
    "get_last_node",
    "remove_modifier",
    "add_boolean_modifier",
    "add_displace_modifier",
    "add_lattice_modifier",
    "add_shrinkwrap_modifier",
    "get_shrinkwrap_modifier",
    "get_mirror_planes",
    "get_evaluated_object",
    "get_evaluated_objects",
    "compensate_children",
    "set_object_origin",
    "set_object_parent",
    "clear_object_parent",
    "RaycastCache",
    "raycast_from_point",
    "raycast_from_mouse",
    "raycast_scene",
    "get_hittable_objects",
    "set_cursor_rotation",
    "set_cursor_transform",
    "get_view_aligned_axes",
    "get_zoom_factor",
    "get_view_origin_and_dir",
    "is_on_screen",
    "get_location_2d",
    "get_ui_scale",
    "get_length_unit_symbol",
    "transform_local_to_space",
    "transform_space_to_local",
    "get_space_transform_matrix",
    "Snap",
    "SnapCache",
    "add_vgroup",
]
