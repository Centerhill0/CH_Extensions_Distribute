"""
修改器工具模块

提供修改器相关的工具函数, 包括布尔集合管理, 集合可见性控制等.

主要功能:
- remove_modifier: 移除指定修改器
- add_boolean_modifier: 为物体添加布尔修改器
- add_normal_transfer_modifier: 添加法线传输修改器
- add_displace_modifier: 为物体添加置换修改器
- add_lattice_modifier: 为物体添加晶格修改器
- add_shrinkwrap_modifier: 为物体添加收缩包裹修改器
- get_shrinkwrap_modifier: 获取物体的收缩包裹修改器
- get_mirror_planes: 读取物体 Mirror 修改器的镜像平面列表
"""

from bpy.types import Object, Modifier, VertexGroup
from mathutils import Vector

from .._constants import AXIS_X, AXIS_Y, AXIS_Z, LOOP_MAPPING_DICT
from .vertex_group import add_vgroup


def remove_modifier(mod: Modifier):
    """
    移除指定修改器

    Args:
        mod: 要移除的修改器
    """
    obj = mod.id_data
    obj.modifiers.remove(mod)


def add_boolean_modifier(obj: Object, operator: Object, method: str = 'DIFFERENCE', solver: str = 'FLOAT') -> Modifier:
    """
    为物体添加布尔修改器

    Args:
        obj: 目标物体
        operator: 布尔操作对象(切割物体)
        method: 布尔方法 (DIFFERENCE/UNION/INTERSECT/SPLIT默认DIFFERENCE)
        solver: 求解器 (FLOAT/EXACT/MANIFOLD)

    Returns:
        创建的布尔修改器
    """
    mod = obj.modifiers.new(name=method.title(), type="BOOLEAN")
    mod.object = operator
    mod.solver = solver
    mod.operation = 'DIFFERENCE' if method == 'SPLIT' else method

    return mod


def add_normal_transfer_modifier(obj: Object, nrmsrc: Object, name: str, vgroup: VertexGroup, mapping: str | None = None) -> Modifier:
    """
    添加法线传输修改器

    Args:
        obj: 目标对象
        nrmsrc: 源对象
        name: 修改器名称
        vgroup: 顶点组
        mapping: 循环映射方式,默认为"NEAREST FACE"

    Returns:
        创建的修改器
    """
    mod = obj.modifiers.new(name, "DATA_TRANSFER")
    mod.object = nrmsrc
    mod.use_loop_data = True
    mod.loop_mapping = LOOP_MAPPING_DICT.get(mapping, LOOP_MAPPING_DICT["NEAREST FACE"])
    mod.vertex_group = vgroup.name
    mod.data_types_loops = {'CUSTOM_NORMAL'}
    mod.show_expanded = False
    mod.show_in_editmode = True
    mod.use_object_transform = False

    return mod


def add_displace_modifier(obj: Object, direction: str = 'NORMAL', strength: float = 0, midlevel: float = 0.5) -> Modifier:
    """
    为物体添加置换修改器

    Args:
        obj: 目标物体
        direction: 置换方向 (NORMAL/VERT)
        strength: 置换强度
        midlevel: 中间值

    Returns:
        创建的置换修改器
    """
    mod = obj.modifiers.new(name=f"{obj.name}_Displace", type="DISPLACE")
    mod.direction = direction
    mod.strength = strength
    mod.mid_level = midlevel

    return mod


def add_lattice_modifier(obj: Object, lattice_obj: Object, name: str, verts_idx: list | None = None) -> Modifier:
    """
    为物体添加晶格修改器

    Args:
        obj: 目标物体
        lattice_obj: 晶格物体
        name: 修改器名称
        verts_idx: 顶点索引列表(可选)
    """
    mod = obj.modifiers.new(name=name, type='LATTICE')
    mod.object = lattice_obj

    # 指定顶点索引时创建顶点组限定作用范围; 未指定时不设顶点组(作用于整个物体)
    if verts_idx is not None:
        mod.vertex_group = add_vgroup(obj, name, verts_idx).name

    return mod


def add_shrinkwrap_modifier(obj: Object, target: Object, name: str) -> Modifier:
    """
    为物体添加收缩包裹修改器

    Args:
        obj: 目标物体
        target: 收缩包裹目标物体
        name: 修改器名称

    Returns:
        创建的收缩包裹修改器
    """
    mod = obj.modifiers.new(name=name, type="SHRINKWRAP")
    mod.target = target
    mod.show_on_cage = True
    mod.show_expanded = False
    return mod


def get_shrinkwrap_modifier(obj: Object, name: str) -> Modifier | None:
    """
    获取物体的收缩包裹修改器

    Args:
        obj: 目标物体
        name: 修改器名称

    Returns:
        收缩包裹修改器, 如果不存在则返回None
    """
    for mod in obj.modifiers:
        if mod.type == 'SHRINKWRAP' and name in mod.name:
            return mod
    return None


def get_mirror_planes(obj: Object) -> list[tuple[Vector, Vector, float]]:
    """
    读取物体 Mirror 修改器的镜像平面列表(物体局部空间)

    仅统计启用合并(use_mirror_merge)的镜像修改器; 配置了镜像物体的
    按其世界矩阵相对物体的变换换算各轴法线.

    Args:
        obj: 网格物体
    Returns:
        (平面点, 平面法线, 合并阈值) 元组列表, 空列表表示无镜像平面
    """
    mirror_planes = []
    obj_mat_inv = obj.matrix_world.inverted()

    for mod in obj.modifiers:
        if mod.type != 'MIRROR' or not mod.use_mirror_merge:
            continue

        if not mod.mirror_object:
            loc = Vector()
            normals = (AXIS_X.copy(), AXIS_Y.copy(), AXIS_Z.copy())
        else:
            mirror_mat_local = obj_mat_inv @ mod.mirror_object.matrix_world
            loc = mirror_mat_local.to_translation()
            mx_x, mx_y, mx_z, _ = mirror_mat_local.adjugated()
            normals = (mx_x.to_3d().normalized(), mx_y.to_3d().normalized(), mx_z.to_3d().normalized())

        for use_axis, normal in zip(mod.use_axis, normals):
            if use_axis:
                mirror_planes.append((loc, normal, mod.merge_threshold))

    return mirror_planes
