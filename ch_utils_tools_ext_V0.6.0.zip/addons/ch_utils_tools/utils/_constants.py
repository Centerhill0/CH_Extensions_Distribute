"""
插件级数值常量模块

收集插件各模块共用的魔法数字和硬编码数值, 提供统一的常量定义.
收口原则: 多处引用或有可能调参的数值常量; 仅单处使用且无修改价值的常数
(sRGB 公式系数等)直接内联在使用处, 不在本模块定义 (2026-09-24 用户定论).
注: 顶层 constants.py(物体类型/模式集合与颜色元组)/mappings.py(输入与轴映射)
为各自领域的自持定义模块, 不在本模块收口, 勿改造成再导出层.
"""

from mathutils import Vector

# ---- 几何阈值 ----
PARALLEL_THRESHOLD = 0.9999
# 近邻平行判定(方向夹角正弦), 与 PARALLEL_THRESHOLD 同口径(cos 0.9999 ≈ 0.81°);
# 求交前拦截"方向几乎平行"的退化输入: 交点会落到 1/sin 倍远处, 延伸即生成失控长边
NEAR_PARALLEL_SIN_THRESHOLD = 0.0141

# ---- 圆检测阈值 ----
CIRCLE_DISTANCE_THRESH = 0.05
CIRCLE_LENGTH_THRESH = 0.1
CIRCLE_ANGLE_THRESH_DEG = 10

# ---- 求交容差 ----
# 线线/线面求交与共点判定的距离容差, 及求交后新顶点的焊接距离阈值
INTERSECT_EPSILON = 1e-5
WELD_DIST_THRESHOLD = 0.0001

# ---- UI / 交互 ----
NUMBERS_MAP = {'ONE': 1, 'TWO': 2, 'THREE': 3, "FOUR": 4, "FIVE": 5, "SIX": 6, "SEVEN": 7, "EIGHT": 8, "NINE": 9, "ZERO": 0}
# 模态拖动灵敏度(像素 -> 参数增量系数): 增量 = 像素差 * 参考量 * 该系数
MODAL_DRAG_SENSITIVITY = 0.002

# ---- UI / HUD ----
# 模态HUD文字的基础字号与默认字体ID, modal_base.draw_init 与 gpu.draw_label 兜底共用
HUD_BASE_FONT_SIZE = 12
HUD_DEFAULT_FONT_ID = 1

# ---- 采样精度 ----
ARC_SAMPLE_MULTIPLIER = 100
HERMITE_PRECISION = 1000

# ---- 坐标轴向量 ----
AXIS_X = Vector((1.0, 0.0, 0.0))
AXIS_Y = Vector((0.0, 1.0, 0.0))
AXIS_Z = Vector((0.0, 0.0, 1.0))

# ---- 法线传输循环映射 ----
LOOP_MAPPING_DICT = {
    'NEAREST FACE': "POLYINTERP_NEAREST",
    'PROJECTED': "POLYINTERP_LNORPROJ",
    'NEAREST NORMAL': "NEAREST_NORMAL",
    'NEAREST POLY NORMAL': "NEAREST_POLYNOR",
}

# ---- 边界盒物体类型 ----
BBOX_TYPE_VERTICES = {'MESH'}
BBOX_TYPE_LATTICE = {'LATTICE'}
BBOX_TYPE_CURVE = {'CURVE', 'SURFACE'}
BBOX_TYPE_BOUNDS = {'GREASEPENCIL', 'FONT', 'CURVES', 'ARMATURE', 'META', 'POINTCLOUD'}
# BBOX_TYPE_INVALID = {'VOLUME', 'EMPTY', 'LIGHT', 'LIGHT_PROBE', 'CAMERA', 'SPEAKER'}
