"""
BMesh网格操作模块

提供BMesh获取, 会话管理, 三角面, 数据层管理等功能.

主要功能:
- get_mesh: 从物体或网格数据中获取网格数据
- get_bmesh: 获取网格的BMesh数据
- bmesh_session: BMesh会话上下文管理器(统一编辑/物体模式的所有权差异)
- get_selected_vert_bound_box: 获取选定顶点的边界盒
- get_loop_triangles: 获取bmesh的三角面列表
- ensure_face_cut_layer: 确保BMesh中存在用于标记切割面的整数层
- ensure_default_data_layers: 确保BMesh中存在默认的数据层
- get_custom_data_layers: 获取BMesh中用户自定义的边数据层
- update_loop_index: 更新BMesh中所有loop的索引
- snapshot_vert_positions: 快照顶点坐标列表
- restore_vert_positions: 将快照坐标写回顶点
"""

from contextlib import contextmanager

import bmesh
import numpy as np
from mathutils import Vector, Matrix
from bmesh.types import BMesh, BMVert
from bpy.types import Object, Mesh

from ..math.transform import apply_matrix_to_points


def get_mesh(data: Object | Mesh) -> Mesh:
    """
    从物体或网格数据中获取网格数据
    Args:
        data: 网格物体或网格数据
    Returns:
        网格对象
    Raises:
        TypeError: 输入不是有效的网格或网格物体
    """
    if isinstance(data, Mesh):
        data.update()
        return data
    elif isinstance(data, Object) and data.type == 'MESH':
        data.update_from_editmode()
        return data.data
    raise TypeError(f"输入的对象 {data} 不是一个有效的网格或网格物体")


def get_bmesh(data: Object | Mesh) -> BMesh:
    """
    获取网格的BMesh数据 (Object 或 Mesh)

    注意: 返回的BMesh所有权取决于模式, 编辑模式下返回共享的编辑态BMesh(不可free),
    物体模式下返回独立构建的BMesh(调用方负责free). 优先使用 bmesh_session 避免混淆.

    Args:
        data: 输入一个网格或物体
    Returns:
        返回一个BMesh对象,如果不是网格物体则会返回错误
    """
    try:
        me = get_mesh(data)
    except TypeError as e:
        raise ValueError(f"无法获取网格数据:{e}")

    if me.is_editmode:
        bm = bmesh.from_edit_mesh(me)
    else:
        bm = bmesh.new()
        bm.from_mesh(me)
    bm.normal_update()
    return bm


@contextmanager
def bmesh_session(data: Object | Mesh, write_back: bool = False, normal_update: bool = True):
    """
    BMesh 会话上下文管理器, 统一编辑/物体两种模式的所有权差异

    - 编辑模式: 复用编辑态BMesh(退出时不free), write_back=True 时回写编辑网格
    - 物体模式: 独立构建BMesh(退出时自动free), write_back=True 时回写网格数据

    Args:
        data: 网格物体或网格数据
        write_back: 是否在退出时回写BMesh改动
        normal_update: 进入时是否更新法线
    Yields:
        BMesh对象
    """
    me = get_mesh(data)
    if me.is_editmode:
        bm = bmesh.from_edit_mesh(me)
        if normal_update:
            bm.normal_update()
        yield bm
        if write_back:
            bmesh.update_edit_mesh(me)
    else:
        bm = bmesh.new()
        bm.from_mesh(me)
        try:
            if normal_update:
                bm.normal_update()
            yield bm
            if write_back:
                bm.to_mesh(me)
                me.update()
        finally:
            bm.free()


def get_selected_vert_bound_box(bm: BMesh, selected_vertices_idx: list[int], mx: Matrix = None) -> list[Vector]:
    """
    获取选定顶点的边界盒(最大与最小坐标)
    Args:
        bm: 输入BMesh对象
        selected_vertices_idx: 输入顶点编号索引列表
        mx: 输入矩阵,当使用默认值,则基于局部坐标系
    Returns:
        最小值和最大值组成的列表
    """
    bm.verts.ensure_lookup_table()
    coords = np.array([bm.verts[idx].co for idx in selected_vertices_idx], dtype=np.float32)
    if mx:
        coords = apply_matrix_to_points(coords, mx)

    min_co, max_co = coords.min(axis=0), coords.max(axis=0)

    return [Vector(min_co), Vector(max_co)]


def get_loop_triangles(bm: BMesh, faces: list = None) -> list:
    """
    获取bmesh的三角面(loop triangles)列表.
    如果指定faces参数,则只返回属于这些面的三角面.
    否则返回所有三角面.
    Args:
        bm: BMesh对象
        faces: 需要筛选的BMFace列表或集合,可为None
    Returns:
        list,三元组(loop)组成的三角面片列表
    """
    all_tris = bm.calc_loop_triangles()
    if faces is None:
        return all_tris
    faces_set = set(faces)
    return [lt for lt in all_tris if lt[0].face in faces_set]


def ensure_face_cut_layer(bm: BMesh, name: str) -> bmesh.types.BMLayerItem:
    """
    确保BMesh中存在用于标记切割面的整数层(自定义数据层),如果不存在则创建一个新的层
    Args:
        bm: 输入的BMesh对象
        name: 层名称
    Returns:
        返回整数层对象,可以用于标记切割面
    """
    return bm.faces.layers.int.get(name) or bm.faces.layers.int.new(name)


def ensure_default_data_layers(bm: BMesh, vertex_groups: bool = True, bevel_weights: bool = True, crease: bool = True) -> list:
    """
    确保BMesh中存在默认的数据层,包括顶点组, 倒角权重和折痕

    Args:
        bm: BMesh对象
        vertex_groups: 是否确保顶点组(deform)层存在,默认为True
        bevel_weights: 是否确保倒角权重层存在,默认为True
        crease: 是否确保折痕层存在,默认为True

    Returns:
        存在的数据层列表,只包含成功创建或已存在的层
    """
    vert_vg_layer = bm.verts.layers.deform.verify() if vertex_groups else None

    if bevel_weights:
        edge_bw_layer = bm.edges.layers.float.get('bevel_weight_edge')
        if not edge_bw_layer:
            edge_bw_layer = bm.edges.layers.float.new('bevel_weight_edge')
    else:
        edge_bw_layer = None

    if crease:
        edge_crease_layer = bm.edges.layers.float.get('crease_edge')
        if not edge_crease_layer:
            edge_crease_layer = bm.edges.layers.float.new('crease_edge')
    else:
        edge_crease_layer = None

    return [layer for layer in [vert_vg_layer, edge_bw_layer, edge_crease_layer] if layer is not None]


def get_custom_data_layers(bm: BMesh, edge: bool = True) -> list:
    """
    获取BMesh中用户自定义的边数据层,排除默认的倒角权重和折痕层

    Args:
        bm: BMesh对象
        edge: 是否获取边数据层,默认为True

    Returns:
        自定义边数据层列表
    """
    if not edge:
        return []

    custom_layers = []

    for layer in bm.edges.layers.float:
        if layer.name not in ('bevel_weight_edge', 'crease_edge'):
            custom_layers.append(layer)

    for layer in bm.edges.layers.int:
        custom_layers.append(layer)

    return custom_layers


def update_loop_index(bm: BMesh) -> int:
    """
    更新BMesh中所有loop的索引

    遍历所有面的loop,按顺序重新分配索引值

    Args:
        bm: BMesh对象

    Returns:
        loop总数
    """
    count = 0
    for f in bm.faces:
        for l in f.loops:
            l.index = count
            count += 1

    return count


def snapshot_vert_positions(verts: list[BMVert]) -> list[Vector]:
    """
    快照顶点坐标列表(用于模态算子的基线还原)
    Args:
        verts: 顶点列表
    Returns:
        与顶点顺序对齐的坐标拷贝列表
    """
    return [vert.co.copy() for vert in verts]


def restore_vert_positions(verts: list[BMVert], coords: list[Vector]) -> None:
    """
    将快照坐标写回顶点(顺序需与快照时一致)
    Args:
        verts: 顶点列表
        coords: 快照坐标列表
    """
    for vert, co in zip(verts, coords):
        vert.co = co
