"""
网格求交与延伸算法模块

为元素延伸/元素求交算子提供几何求解: 边边延伸(V/T 形态), 边面延伸,
批量求交切割(边边交叉与面切割穿面边)与交点焊接(含交点处既有顶点的复用).

主要功能:
- extend_edges_to_intersection: 将两条边向其交点延伸(V/T 形态)
- extend_edge_to_face: 将边延伸到面所在平面
- intersect_elements: 切割所有真实相交的选中元素并焊接交点

新建几何统一置为选中(新建元素默认未选中): 选区即操作结果, 便于接续变换.
去选元素后校验选择历史: 直接改 select 标志不移除历史中的未选中元素,
残留的活动元素会让视口保留高亮.
"""

import itertools

import bmesh
from bmesh.types import BMEdge, BMFace, BMesh, BMVert
from mathutils import Vector
from mathutils.geometry import intersect_line_line, intersect_line_plane, intersect_point_line

from .._constants import AXIS_X, AXIS_Y, INTERSECT_EPSILON, NEAR_PARALLEL_SIN_THRESHOLD, WELD_DIST_THRESHOLD
from ..math.geometry import is_point_in_polygon_2d


def _make_vert(bm: BMesh, co: Vector) -> BMVert:
    """
    新建选中状态的顶点

    Args:
        bm: 工作BMesh
        co: 顶点坐标
    Returns:
        新顶点
    """
    vert = bm.verts.new(co)
    vert.select = True
    return vert


def _make_edge(bm: BMesh, vert_a: BMVert, vert_b: BMVert) -> BMEdge:
    """
    新建选中状态的边

    Args:
        bm: 工作BMesh
        vert_a: 端点A
        vert_b: 端点B
    Returns:
        新边
    """
    edge = bm.edges.new((vert_a, vert_b))
    edge.select = True
    return edge


def _direction_sine(vec_a: Vector, vec_b: Vector) -> float:
    """
    计算两方向夹角的正弦(方向接近平行时趋近 0)

    零长度方向返回 0, 由调用方既有校验处理.

    Args:
        vec_a: 方向A
        vec_b: 方向B
    Returns:
        夹角正弦(0~1)
    """
    if vec_a.length == 0.0 or vec_b.length == 0.0:
        return 0.0
    return vec_a.cross(vec_b).length / (vec_a.length * vec_b.length)


def _coincident_verts(co: Vector, verts: tuple[BMVert, ...]) -> list[BMVert]:
    """
    获取交点处已存在的顶点(预存 T 形节点/面顶点)

    这些顶点须与交点处新建的顶点一同焊接, 否则留下距离 0 的重合双顶点.

    Args:
        co: 交点坐标
        verts: 参与相交的元素的顶点
    Returns:
        与交点重合(焊接阈值内)的既有顶点列表
    """
    return [vert for vert in verts if (vert.co - co).length <= WELD_DIST_THRESHOLD]


def _point_on_segment(co: Vector, seg_a: Vector, seg_b: Vector, epsilon: float = INTERSECT_EPSILON) -> bool:
    """
    判断点是否落在线段上(含端点, 距离容差换算为线段比例)

    Args:
        co: 待判定点坐标
        seg_a: 线段端点A坐标
        seg_b: 线段端点B坐标
        epsilon: 距离容差
    Returns:
        点位于线段上(含端点)返回 True
    """
    length = (seg_b - seg_a).length
    if length == 0.0:
        return False
    _closest, factor = intersect_point_line(co, seg_a, seg_b)
    margin = epsilon / length
    return -margin <= factor <= 1.0 + margin


def _nearest_vert(edge: BMEdge, co: Vector) -> BMVert:
    """
    获取边上距指定坐标最近的端点顶点

    Args:
        edge: 目标边
        co: 参考坐标
    Returns:
        距离较近的端点顶点
    """
    return min(edge.verts, key=lambda vert: (vert.co - co).length)


def _split_edge_at_points(edge: BMEdge, co_list: list[Vector]) -> list[BMVert]:
    """
    沿边依次切分多个交点

    交点按边内参数排序后从一端向另一端顺序切分; 边缘情形(交点距端点在
    容差内, 或多个交点相距在容差内)的交点跳过切分.

    Args:
        edge: 待切分边(切分后原边对象保留为末段)
        co_list: 切分点坐标列表(须位于边所在直线上)
    Returns:
        按切分顺序排列的新顶点列表(已置为选中), 无有效交点时为空列表
    """
    if not co_list:
        return []

    vert_a, vert_b = edge.verts
    vec_full = vert_b.co - vert_a.co
    if vec_full.length_squared == 0.0:
        # 零长度退化边无可切分位置
        return []
    min_gap = INTERSECT_EPSILON / vec_full.length

    # 交点按边内参数排序, 过滤端点邻域与容差内重复的交点
    pairs = sorted(((co - vert_a.co).dot(vec_full) / vec_full.length_squared, co) for co in co_list)
    cut_pairs = []
    for factor, co in pairs:
        if factor <= min_gap or factor >= 1.0 - min_gap:
            continue
        if cut_pairs and factor - cut_pairs[-1][0] <= min_gap:
            continue
        cut_pairs.append((factor, co))

    new_verts = []
    cur_edge = edge
    base_vert = vert_a
    for _factor, co in cut_pairs:
        # 原边对象经切分后保留为末段, 基准顶点推进到上一个切分点
        far_vert = cur_edge.other_vert(base_vert)
        vec = far_vert.co - base_vert.co
        pct = (co - base_vert.co).dot(vec) / vec.length_squared if vec.length_squared else 0.0
        pct = min(max(pct, 0.0), 1.0)
        new_edge, new_vert = bmesh.utils.edge_split(cur_edge, base_vert, pct)
        # 切分产物不继承顶点选区, 显式置位以延续"结果即选区"约定
        new_vert.select = True
        new_edge.select = True
        new_verts.append(new_vert)
        base_vert = new_vert

    return new_verts


def _co_inside_face(face: BMFace, co: Vector) -> bool:
    """
    判断坐标是否位于面多边形内部(沿面法线正交投影到二维判定)

    Args:
        face: 目标面
        co: 待判定坐标(须位于面所在平面内)
    Returns:
        坐标位于面内返回 True
    """
    face_normal = face.normal
    if face_normal == Vector():
        return False

    helper = AXIS_X if abs(face_normal.x) < 0.9 else AXIS_Y
    axis_u = helper.cross(face_normal).normalized()
    axis_v = face_normal.cross(axis_u)
    pt_2d = Vector((co.dot(axis_u), co.dot(axis_v), 0.0))
    poly_2d = [Vector((vert.co.dot(axis_u), vert.co.dot(axis_v), 0.0)) for vert in face.verts]
    return is_point_in_polygon_2d(poly_2d, pt_2d)


def extend_edges_to_intersection(bm: BMesh, edge_a: BMEdge, edge_b: BMEdge) -> tuple[str | None, str | None]:
    """
    将两条不共顶点的共面边向其交点延伸

    V 形(交点在两边段之外): 两边各从近端顶点新建边连到交点, 原边保留;
    T 形(交点落在其中一边段上): 该边在交点处切分, 另一边从近端顶点
    新建边连到交点; 交叉形态(交点同时落在两边段上)属求交范畴, 不予处理.
    近邻平行(夹角正弦小于阈值)一并拒绝: 交点落在 1/sin 倍远处, 延伸即失控长边.
    新建顶点与边置为选中, 原边选区保持.

    Args:
        bm: 工作BMesh
        edge_a: 第一条边
        edge_b: 第二条边
    Returns:
        (形态 'V'/'T', 错误信息) 元组, 失败时形态为 None
    """
    if set(edge_a.verts) & set(edge_b.verts):
        return None, "Edges share a vertex"

    co_a1, co_a2 = (vert.co for vert in edge_a.verts)
    co_b1, co_b2 = (vert.co for vert in edge_b.verts)
    points = intersect_line_line(co_a1, co_a2, co_b1, co_b2)
    if not points:
        return None, "Edges are parallel"

    if _direction_sine(co_a2 - co_a1, co_b2 - co_b1) <= NEAR_PARALLEL_SIN_THRESHOLD:
        return None, "Edges are nearly parallel"

    co_isect = (points[0] + points[1]) / 2
    if (points[0] - points[1]).length > INTERSECT_EPSILON:
        return None, "Edges are not coplanar"

    on_a = _point_on_segment(co_isect, co_a1, co_a2)
    on_b = _point_on_segment(co_isect, co_b1, co_b2)
    if on_a and on_b:
        return None, "Edges already intersect"

    if not on_a and not on_b:
        vert_isect = _make_vert(bm, co_isect)
        _make_edge(bm, _nearest_vert(edge_a, co_isect), vert_isect)
        _make_edge(bm, _nearest_vert(edge_b, co_isect), vert_isect)
        return 'V', None

    # T 形: 交点所在边切分于交点, 另一边从近端顶点连入切分顶点
    edge_on, edge_from = (edge_a, edge_b) if on_a else (edge_b, edge_a)
    cut_verts = _split_edge_at_points(edge_on, [co_isect])
    vert_isect = cut_verts[0] if cut_verts else _nearest_vert(edge_on, co_isect)
    _make_edge(bm, _nearest_vert(edge_from, co_isect), vert_isect)
    return 'T', None


def extend_edge_to_face(bm: BMesh, edge: BMEdge, face: BMFace) -> tuple[str | None, str | None]:
    """
    将边沿自身方向延伸到面所在平面

    交点落在边段之外时, 从近端顶点新建边连到平面交点; 交点已落在边段上
    (边与面所在平面相交)属求交范畴, 不予处理; 边与平面近邻平行
    (夹角正弦小于阈值)一并拒绝: 交点落在 1/sin 倍远处, 延伸即失控长边.

    Args:
        bm: 工作BMesh
        edge: 与面分离的边
        face: 目标面
    Returns:
        (形态 'EXTENDED', 错误信息) 元组, 失败时形态为 None
    """
    co_a, co_b = (vert.co for vert in edge.verts)
    co_isect = intersect_line_plane(co_a, co_b, face.calc_center_median(), face.normal)
    if not co_isect:
        return None, "Edge does not intersect the face plane"

    if abs((co_b - co_a).normalized().dot(face.normal)) <= NEAR_PARALLEL_SIN_THRESHOLD:
        return None, "Edge is nearly parallel to the face plane"

    if _point_on_segment(co_isect, co_a, co_b):
        return None, "Edge crosses the face plane"

    vert_isect = _make_vert(bm, co_isect)
    _make_edge(bm, _nearest_vert(edge, co_isect), vert_isect)
    return 'EXTENDED', None


def intersect_elements(bm: BMesh, edges: list[BMEdge], faces: list[BMFace]) -> tuple[int | None, str | None]:
    """
    切割所有真实相交的选中元素并焊接交点

    边边: 交点同时落在两边段上的成对边各在交点处切分;
    边面: 穿透面多边形的边在穿透点处切分;
    全部切分完成后统一焊接新顶点(不同边交于同一点时合并为单点),
    交点处已有顶点(预存 T 形节点/面顶点)时一并焊接, 不产生重合双顶点;
    新顶点置为选中, 未参与任何相交的选中边取消选择并校验选择历史.

    Args:
        bm: 工作BMesh
        edges: 可见选中边列表
        faces: 可见选中面列表(可为空)
    Returns:
        (切割点数(焊接前的新顶点数), 错误信息) 元组
    """
    cut_map: dict[BMEdge, list[Vector]] = {}
    # 交点处已存在的顶点: 与交点处新建的顶点一同焊接
    weld_verts: set[BMVert] = set()

    # 先收集全部交点再统一切分: 切分会改变边段范围, 边切边算会漏掉后段交点
    for edge_a, edge_b in itertools.combinations(edges, 2):
        if set(edge_a.verts) & set(edge_b.verts):
            continue
        co_a1, co_a2 = (vert.co for vert in edge_a.verts)
        co_b1, co_b2 = (vert.co for vert in edge_b.verts)
        points = intersect_line_line(co_a1, co_a2, co_b1, co_b2)
        if not points:
            continue
        if (points[0] - points[1]).length > INTERSECT_EPSILON:
            continue
        co_isect = (points[0] + points[1]) / 2
        if not (_point_on_segment(co_isect, co_a1, co_a2) and _point_on_segment(co_isect, co_b1, co_b2)):
            continue
        cut_map.setdefault(edge_a, []).append(co_isect)
        cut_map.setdefault(edge_b, []).append(co_isect)
        weld_verts.update(_coincident_verts(co_isect, (*edge_a.verts, *edge_b.verts)))

    # 面平面按面预计算, 避免边面成对求解时重复取中点与法线
    planes = [(face, face.calc_center_median(), face.normal) for face in faces]

    for edge in edges:
        co_a, co_b = (vert.co for vert in edge.verts)
        for face, plane_co, plane_no in planes:
            co_isect = intersect_line_plane(co_a, co_b, plane_co, plane_no)
            if not co_isect or not _point_on_segment(co_isect, co_a, co_b):
                continue
            if not _co_inside_face(face, co_isect):
                continue
            cut_map.setdefault(edge, []).append(co_isect)
            weld_verts.update(_coincident_verts(co_isect, (*edge.verts, *face.verts)))

    new_verts = []
    for edge, co_list in cut_map.items():
        new_verts.extend(_split_edge_at_points(edge, co_list))

    if not new_verts:
        # 未产生任何切割: 不动网格与选区, 由调用方提示选区无效
        return 0, "No intersections found"

    bmesh.ops.remove_doubles(bm, verts=[*new_verts, *weld_verts], dist=WELD_DIST_THRESHOLD)

    # 未参与相交的选中边取消选择, 反馈实际切割范围
    for edge in edges:
        if edge not in cut_map:
            edge.select = False

    # 直接改 select 标志不校验选择历史, 被去选边若为活动元素会残留视口高亮
    bm.select_history.validate()

    return len(new_verts), None
