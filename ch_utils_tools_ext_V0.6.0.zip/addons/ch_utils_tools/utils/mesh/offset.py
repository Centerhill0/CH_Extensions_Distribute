"""
边环偏移方向求解模块

为偏移/挤出/移动选中边环提供位移方向求解: 依据环法线, 邻接面, 内部边轨道与
镜像平面, 为环上每个顶点解出一对 (宽度方向, 深度方向) 单位向量.

主要功能:
- get_directions: 求解边环每个顶点的位移方向对
"""

from bmesh.types import BMEdge, BMFace, BMVert
from mathutils import Vector

from ..math.geometry import calc_loop_normal


def get_adj_faces(edges: list[BMEdge]) -> list[BMFace | None]:
    """
    获取边环各边的邻接面(可见且法线有效, 选中面优先)

    Args:
        edges: 边环的有序边列表
    Returns:
        与边对齐的邻接面列表, 无法确定时对应项为 None
    """
    adj_faces = []

    for edge in edges:
        adj_face = None
        co_adj = 0
        for face in edge.link_faces:
            if not face.hide and face.normal != Vector():
                adj_face = face
                co_adj += 1
                if face.select:
                    adj_faces.append(face)
                    break
        else:
            # 未遇到选中面: 恰有一个有效邻接面时采用它, 否则视为不确定
            adj_faces.append(adj_face if co_adj == 1 else None)

    return adj_faces


def get_edge_rail(vert: BMVert, set_edges: set[BMEdge]) -> Vector | None:
    """
    获取顶点处内部边(未参与偏移的边)方向作为轨道

    优先采用选中的内部边; 恰有一条内部边时也采用, 两条以上视为不确定.

    Args:
        vert: 环上顶点
        set_edges: 参与偏移的边集合
    Returns:
        归一化轨道方向, 无法确定时返回 None
    """
    co_unselected = co_selected = 0
    vec_inner = None

    for edge in vert.link_edges:
        if edge not in set_edges and (edge.select or (co_selected == 0 and not edge.hide)):
            vec = edge.other_vert(vert).co - vert.co
            if vec != Vector():
                vec_inner = vec
                if edge.select:
                    co_selected += 1
                    if co_selected == 2:
                        return None
                else:
                    co_unselected += 1

    if co_selected == 1 or co_unselected == 1:
        vec_inner.normalize()
        return vec_inner
    return None


def get_cross_rail(vec_tan: Vector, vec_edge_r: Vector, vec_edge_l: Vector, normal_r: Vector, normal_l: Vector) -> Vector | None:
    """
    获取两侧面法线叉积作为轨道(两侧面不共面时的折中方向)

    Args:
        vec_tan: 顶点处平均切向
        vec_edge_r: 右侧边方向
        vec_edge_l: 左侧边方向
        normal_r: 右侧面法线
        normal_l: 左侧面法线
    Returns:
        归一化叉积轨道, 与边夹角过小时返回 None
    """
    vec_cross = normal_r.cross(normal_l)
    if vec_cross.dot(vec_tan) < 0.0:
        vec_cross *= -1

    cos_min = min(vec_tan.dot(vec_edge_r), vec_tan.dot(-vec_edge_l))
    if vec_cross.dot(vec_tan) >= cos_min:
        vec_cross.normalize()
        return vec_cross
    return None


def get_mirror_rail(mirror_plane: tuple, vec_up: Vector) -> tuple[Vector | None, Vector]:
    """
    获取镜像平面上的轨道, 并把上方向投影到平面内

    Args:
        mirror_plane: (平面点, 平面法线, 合并阈值) 元组
        vec_up: 待投影的上方向
    Returns:
        (平面内轨道方向(可为 None), 投影后的上方向)
    """
    plane_normal = mirror_plane[1]
    mirror_rail = vec_up.cross(plane_normal)
    if mirror_rail != Vector():
        mirror_rail.normalize()
        vec_up = (vec_up - vec_up.project(plane_normal)).normalized()
        return mirror_rail, vec_up
    return None, vec_up


def reorder_loop(verts: list[BMVert], edges: list[BMEdge], lp_normal: Vector, adj_faces: list[BMFace | None]) -> tuple[list[BMVert], list[BMEdge], Vector, list[BMFace | None]]:
    """
    按邻接面法线对齐环方向(必要时反转环, 使法线与邻接面朝向一致)

    Args:
        verts: 环顶点列表
        edges: 环边列表
        lp_normal: 环法线
        adj_faces: 与边对齐的邻接面列表
    Returns:
        (对齐后的顶点列表, 边列表, 法线, 邻接面列表)
    """
    for idx, adj_face in enumerate(adj_faces):
        if adj_face is None:
            continue
        v1, v2 = verts[idx], verts[idx + 1]
        face_verts = tuple(adj_face.verts)
        if face_verts[face_verts.index(v1) - 1] is v2:
            verts.reverse()
            edges.reverse()
            adj_faces.reverse()
        if lp_normal.dot(adj_face.normal) < 0.0:
            lp_normal *= -1
        break
    else:
        # 全部邻接面不确定时, 依据任一非零顶点法线对齐
        for vert in verts:
            if vert.normal != Vector():
                if lp_normal.dot(vert.normal) < 0.0:
                    verts.reverse()
                    edges.reverse()
                    lp_normal *= -1
                break

    return verts, edges, lp_normal, adj_faces


def get_directions(lp: list, vec_upward: Vector, normal_fallback: Vector, vert_mirror_pairs: dict[BMVert, tuple] | None,
                   follow_face: bool = False, edge_rail: bool = False, edge_rail_only_end: bool = False,
                   threshold: float = 0.0) -> tuple[list[BMVert], list[tuple[Vector, Vector]]]:
    """
    求解边环上每个顶点的位移方向对

    Args:
        lp: [v, e, v, e, ..., v] 交错环序列(闭合环首尾为同一顶点对象)
        vec_upward: 统一环朝向用的参考上方向(follow_face 关闭时)
        normal_fallback: 环法线无法计算时的回退法线
        vert_mirror_pairs: 顶点到镜像平面的映射(无则传 None)
        follow_face: 是否沿邻接面求解方向
        edge_rail: 是否沿内部边对齐
        edge_rail_only_end: 仅对环端点应用内部边轨道
        threshold: 两邻接面视为共面的法线夹角阈值(弧度)
    Returns:
        (环顶点列表(可能已反序, 闭合环不含重复尾顶点), 与顶点对齐的 (宽度方向, 深度方向) 列表)
    """
    verts, edges = lp[::2], lp[1::2]
    set_edges = set(edges)
    lp_normal = calc_loop_normal(verts, fallback=normal_fallback)

    if lp_normal.dot(vec_upward) < 0.0:
        # 统一环法线朝向参考上方向
        verts.reverse()
        edges.reverse()
        lp_normal *= -1

    if follow_face:
        adj_faces = get_adj_faces(edges)
        verts, edges, lp_normal, adj_faces = reorder_loop(verts, edges, lp_normal, adj_faces)
    else:
        adj_faces = (None,) * len(edges)

    vec_edges = tuple((e.other_vert(v).co - v.co).normalized() for v, e in zip(verts, edges))

    if verts[0] is verts[-1]:
        # 闭合环: 去掉重复尾顶点
        verts.pop()
        half_loop = False
    else:
        half_loop = True

    directions = []
    for idx, vert in enumerate(verts):
        ix_right, ix_left = idx, idx - 1

        vert_end = False
        if half_loop:
            if idx == 0:
                ix_left = ix_right
                vert_end = True
            elif idx == len(verts) - 1:
                ix_right = ix_left
                vert_end = True

        edge_right, edge_left = vec_edges[ix_right], vec_edges[ix_left]
        face_right, face_left = adj_faces[ix_right], adj_faces[ix_left]

        normal_right = face_right.normal if face_right else lp_normal
        normal_left = face_left.normal if face_left else lp_normal
        two_normals = normal_right.angle(normal_left) > threshold

        tan_right = edge_right.cross(normal_right).normalized()
        tan_left = edge_left.cross(normal_left).normalized()
        tan_avr = (tan_right + tan_left).normalized()
        norm_avr = (normal_right + normal_left).normalized()

        rail = None
        if two_normals or edge_rail:
            if two_normals or (not edge_rail_only_end) or vert_end:
                rail = get_edge_rail(vert, set_edges)
        if vert_mirror_pairs and vert_end and vert in vert_mirror_pairs:
            rail, norm_avr = get_mirror_rail(vert_mirror_pairs[vert], norm_avr)
        if not rail and two_normals:
            rail = get_cross_rail(tan_avr, edge_right, edge_left, normal_right, normal_left)
        if rail:
            if tan_avr.dot(rail) > 0.0:
                tan_avr = rail
            elif tan_avr.dot(rail) < 0.0:
                tan_avr = -rail

        vec_plane = norm_avr.cross(tan_avr)
        e_dot_p_r = edge_right.dot(vec_plane)
        e_dot_p_l = edge_left.dot(vec_plane)
        if e_dot_p_r or e_dot_p_l:
            # 沿边滑动分量校正: 使位移在边方向上不产生滑动
            if e_dot_p_r > e_dot_p_l:
                vec_edge, e_dot_p = edge_right, e_dot_p_r
            else:
                vec_edge, e_dot_p = edge_left, e_dot_p_l

            vec_tan = (tan_avr - tan_avr.project(vec_edge)).normalized()
            vec_up = vec_tan.cross(vec_edge)

            vec_width = vec_tan - (vec_tan.dot(vec_plane) / e_dot_p) * vec_edge
            vec_depth = vec_up - (vec_up.dot(vec_plane) / e_dot_p) * vec_edge
        else:
            vec_width = tan_avr
            vec_depth = norm_avr

        directions.append((vec_width, vec_depth))

    return verts, directions
