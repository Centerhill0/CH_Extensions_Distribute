"""
网格操作子包

公共 API 经由本 __init__ 再导出至 utils 顶层命名空间;
未在此列出的模块成员为子包内部协作 API, 仅供 utils 内部使用.
"""

from .bmesh_utils import (
    get_mesh,
    get_bmesh,
    bmesh_session,
    get_selected_vert_bound_box,
    get_loop_triangles,
    ensure_face_cut_layer,
    ensure_default_data_layers,
    get_custom_data_layers,
    update_loop_index,
    snapshot_vert_positions,
    restore_vert_positions,
)
from .deformer import EdgeLoopDeformer
from .edge_loop import (
    get_isolated_edges,
    select_loop_edges_by_angle,
    select_adjacent_quad_loop,
    walk_boundary_edge_loop,
    walk_ngon_edge_loop,
    walk_quad_edge_loop,
    get_edge_loop,
    get_edge_loops,
)
from .flatten import (
    flatten_verts,
    flatten_faces,
)
from .normal import (
    normal_clear,
    normal_transfer_from_object,
)
from .offset import get_directions
from .intersect import (
    extend_edges_to_intersection,
    extend_edge_to_face,
    intersect_elements,
)
from .selection import (
    has_selected_curve_element,
    get_active_element_from_bmesh,
    is_valid_mesh_edit_selection,
    get_selection_border_edges,
    is_freestyle_edge,
    get_edge_ngon_face,
    is_ngon_face,
)
from .symmetrize import symmetrize
from .spline_deform import (
    map_segment_onto_spline,
    curve_hermite,
    circle_3_points,
    circle_2_points,
)
from .topology import (
    get_selected_vert_islands,
    get_mesh_element_islands,
    get_vert_sequences,
    collect_loops,
    get_vert_mirror_pairs,
    dijkstra_path,
    get_shortest_path,
    collect_vert_path,
    split_vert_path_into_segments,
    get_boundary_edges,
    build_mesh_graph,
)

__all__ = [
    "get_mesh",
    "get_bmesh",
    "bmesh_session",
    "get_selected_vert_bound_box",
    "get_loop_triangles",
    "ensure_face_cut_layer",
    "ensure_default_data_layers",
    "get_custom_data_layers",
    "update_loop_index",
    "snapshot_vert_positions",
    "restore_vert_positions",
    "EdgeLoopDeformer",
    "get_isolated_edges",
    "select_loop_edges_by_angle",
    "select_adjacent_quad_loop",
    "walk_boundary_edge_loop",
    "walk_ngon_edge_loop",
    "walk_quad_edge_loop",
    "get_edge_loop",
    "get_edge_loops",
    "flatten_verts",
    "flatten_faces",
    "normal_clear",
    "normal_transfer_from_object",
    "get_directions",
    "has_selected_curve_element",
    "get_active_element_from_bmesh",
    "is_valid_mesh_edit_selection",
    "get_selection_border_edges",
    "is_freestyle_edge",
    "get_edge_ngon_face",
    "is_ngon_face",
    "symmetrize",
    "map_segment_onto_spline",
    "curve_hermite",
    "circle_3_points",
    "circle_2_points",
    "get_selected_vert_islands",
    "get_mesh_element_islands",
    "get_vert_sequences",
    "collect_loops",
    "get_vert_mirror_pairs",
    "dijkstra_path",
    "get_shortest_path",
    "collect_vert_path",
    "split_vert_path_into_segments",
    "get_boundary_edges",
    "build_mesh_graph",
    "extend_edges_to_intersection",
    "extend_edge_to_face",
    "intersect_elements",
]
