
"""
语言切换操作器模块

提供以下功能:
- SwitchLanguage: 在中英文界面之间切换
"""

from bpy.types import Operator, Context


class CH_OT_switch_language(Operator):
    """
    语言切换操作器

    功能:在中文和英文界面之间切换
    - 自动设置语言为简体中文
    - 保持工具提示翻译开启
    """

    bl_idname = "ch.switch_language"
    bl_label = "Switch Language"
    bl_description = "Switch language between Chinese and English"

    def execute(self, context: Context):
        view = context.preferences.view

        # 确保语言设置为简体中文
        if view.language != 'zh_HANS':
            view.language = 'zh_HANS'

        # 设置翻译选项
        view.use_translate_tooltips = True
        view.use_translate_new_dataname = False

        # 切换界面翻译状态
        view.use_translate_interface = not view.use_translate_interface
        view.use_translate_reports = bool(view.use_translate_interface)

        return {'FINISHED'}
