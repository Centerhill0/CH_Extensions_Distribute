"""
快速对称化操作模块

提供三种对称化操作:
1. EditMeshSymmetrize: 编辑模式下的网格对称化操作
2. ObjectSymmetrize: 物体模式下的镜像修改器添加操作
3. EditCurveSymmetrize: 编辑模式下的曲线对称化操作

通过鼠标滑动方向快速确定对称轴和方向,实现网格或曲线的对称化操作.

EditMeshSymmetrize 操作流程:
1. 在网格编辑模式下调用操作器
2. 移动鼠标选择对称轴(X/Y/Z)和方向(正/负)
3. 滑动鼠标超过阈值距离:
   - Mirror模式: 执行对称操作,然后显示1秒新顶点预览效果
   - Remove模式: 直接执行
4. 可选: 仅对选中部分对称化,移除一侧,镜像顶点组等

ObjectSymmetrize 操作流程:
1. 在物体模式下调用操作器
2. 移动鼠标选择镜像轴(X/Y/Z)
3. 滑动鼠标超过阈值距离或点击确认添加镜像修改器
4. 可选: 启用切分,翻转切分方向,镜像顶点组
5. 基于游标镜像时生成镜像空物体, 并父子绑定到源物体(移动/旋转/缩放源物体时空物体跟随)

EditCurveSymmetrize 操作流程:
1. 在曲线编辑模式下调用操作器
2. 移动鼠标选择对称轴(X/Y/Z)和方向(正/负)
3. 滑动鼠标超过阈值距离执行对称化
4. 可选: 在光标空间对称化,移除冗余中心点

支持的选项:
EditMeshSymmetrize:
- scope: 对称化范围 (ALL/SELECTED)
- mode: 操作模式 (MIRROR/REMOVE)
- use_cursor: 游标空间对称化
- mirror_vertex_groups: 镜像顶点组
- mirror_custom_normals: 镜像自定义法线
- offset_uvs: 偏移UV

ObjectSymmetrize:
- use_cursor: 游标空间镜像
- use_bisect: 启用切分
- use_flip: 翻转切分方向
- bisect_threshold: 切分阈值
- mirror_vertex_groups: 镜像顶点组

EditCurveSymmetrize:
- use_cursor: 在光标空间对称化
- remove_redundant: 移除冗余中心点

快捷键:
EditMeshSymmetrize:
- 滑动鼠标: 选择对称轴和方向
- M: 切换模式 (Mirror/Remove)
- S: 切换范围 (All/Selected, 仅Mirror模式, Remove模式始终对整体生效)
- C: 切换游标空间
- D: 切换UV偏移 (mode=MIRROR 且 has_uvs)
- N: 切换镜像自定义法线 (mode=MIRROR 且 has_custom_normals)
- R: 切换移除冗余中心 (mode=MIRROR 且 scope=ALL)
- V: 切换镜像顶点组 (mode=MIRROR 且 scope=ALL 且 has_vertex_groups)

ObjectSymmetrize:
- 滑动鼠标: 选择镜像轴
- C: 切换游标空间镜像
- B: 切换切分 (Clip)
- F: 切换翻转 (Flip, use_bisect=True时可用)
- G: 切换镜像顶点组 (has_vertex_groups时可用)

EditCurveSymmetrize:
- 滑动鼠标: 选择对称轴和方向
- C: 切换光标空间
- R: 切换移除冗余中心 (has_redundant时可用)
"""

__all__ = [
    "EditMeshSymmetrize",
    "ObjectSymmetrize",
    "EditCurveSymmetrize",
]

import bpy
import bmesh
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntVectorProperty
from bpy.types import Context, Event, Operator
from bpy_extras.view3d_utils import region_2d_to_location_3d, region_2d_to_origin_3d, region_2d_to_vector_3d
from mathutils import Vector

from ...items import axis_items
from ...constants import red, green, blue, white, yellow, black
from ...mappings import axis_vector_mappings
from ...utils import (
    compute_symmetrized_splines,
    get_mirror_plane,
    draw_status_item,
    ignore_events,
    force_ui_update,
    get_zoom_factor,
    navigation_passthrough,
    draw_vector,
    draw_point,
    draw_line,
    draw_points,
    draw_circle,
    get_curve_data,
    create_spline_from_data,
    symmetrize,
)
from ...modal_base import ModalOperatorMixin
from ...preference import get_prefs


# 局部空间六个方向的单位向量, 同时用作曲线对称的镜像平面法线;
# 键序为 X+,X-,Y+,Y-,Z+,Z-, 与 _AXIS_COLORS 的配色一一对应
_AXIS_VECTORS = {
    f'{direction}_{axis}': vec.copy() if direction == 'POSITIVE' else -vec
    for axis, vec in axis_vector_mappings.items()
    for direction in ('POSITIVE', 'NEGATIVE')
}

_AXIS_COLORS = (red, red, green, green, blue, blue)


def _get_axis_vectors(matrix_world) -> dict:
    """获取世界坐标系下的轴向量"""
    quat = matrix_world.to_quaternion()
    return {direction: quat @ vec for direction, vec in _AXIS_VECTORS.items()}


def _init_flick_context(op: Operator, context: Context, event: Event, use_cursor: bool):
    """初始化模态滑动交互的公共状态(锚点/缩放/轴向/颜色)"""
    op.flick_distance = get_prefs().symmetrize_flick_distance
    op.mousepos = Vector((event.mouse_region_x, event.mouse_region_y, 0))

    view_origin = region_2d_to_origin_3d(context.region, context.region_data, op.mousepos)
    view_dir = region_2d_to_vector_3d(context.region, context.region_data, op.mousepos)

    op.origin = view_origin + view_dir * 10
    op.zoom = get_zoom_factor(context, depth_location=op.origin, scale=op.flick_distance)

    op.init_mouse = op.mousepos
    op.init_mouse_3d = region_2d_to_location_3d(context.region, context.region_data, op.init_mouse, op.origin)

    op.flick_vector = op.mousepos - op.init_mouse
    op.flick_dir = None
    op.colors = _AXIS_COLORS
    op.axes = _get_axis_vectors(op.cmx if use_cursor else op.mx)


def _reset_flick_anchor(op: Operator, context: Context):
    """视图导航穿透后重置滑动锚点"""
    op.pass_through = False
    op.init_mouse = op.mousepos
    op.init_mouse_3d = region_2d_to_location_3d(context.region, context.region_data, op.init_mouse, op.origin)
    op.zoom = get_zoom_factor(context, depth_location=op.origin, scale=op.flick_distance)


def _draw_flick_hud(flick_vector: Vector, init_mouse: Vector, flick_distance: float, color: tuple, alpha: float, fade: bool = False):
    """绘制滑动HUD"""
    draw_vector(flick_vector, origin=init_mouse, fade=fade, alpha=alpha)
    draw_circle(init_mouse, radius=flick_distance, width=3, color=color, alpha=alpha)


def _draw_axis_vectors(axes: dict, colors: list, init_mouse_3d: Vector, zoom: float, flick_dir: str | None, point_size: int = 5):
    """绘制3D视图中的轴向量"""
    for direction, axis, color in zip(axes.keys(), axes.values(), colors):
        is_positive = 'POSITIVE' in direction
        draw_vector(axis * zoom / 1.5, origin=init_mouse_3d, color=color, width=2 if is_positive else 1, alpha=0.99 if is_positive else 0.3)

    if flick_dir:
        draw_point(init_mouse_3d + axes[flick_dir] * zoom / 1.5 * 1.1, size=point_size*1.2, alpha=0.8)


# ============================================================
# 网格编辑模式快速对称化操作器
# ============================================================
class EditMeshSymmetrize(Operator, ModalOperatorMixin):
    """
    网格快速对称化操作器

    功能: 通过鼠标滑动方向快速确定对称轴和方向
    - 支持Mirror模式(镜像)和Remove模式(移除一侧)
    - Remove模式始终对整体网格生效, Scope选项仅Mirror模式可用
    - Mirror模式执行后显示1秒新顶点预览效果
    - 支持部分对称化(仅选中元素)
    - 支持游标空间对称化
    - 支持镜像顶点组,自定义法线,UV偏移

    要求: 网格编辑模式下有活动网格对象
    """

    bl_idname = "ch.editmesh_symmetrize"
    bl_label = "Edit Mesh Symmetrize"
    bl_description = "Edit mesh symmetry with flick direction"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(name="Mode", items=[('MIRROR', "Mirror", "Mirror mesh"), ('REMOVE', "Remove", "Remove one side")], default='MIRROR')  # type: ignore
    scope: EnumProperty(name="Scope", items=[('ALL', "All", "Full symmetry"), ('SELECTED', "Selected", "Selected only")], default='ALL')  # type: ignore
    use_cursor: BoolProperty(name="Cursor", description="Symmetrize in Cursor Space", default=False)  # type: ignore
    axis: EnumProperty(name="Axis", items=axis_items, default="X")  # type: ignore
    direction: EnumProperty(name="Direction", items=[('POSITIVE', "+", ""), ('NEGATIVE', "-", "")], default="POSITIVE")  # type: ignore
    threshold: FloatProperty(name="Threshold", default=0.0001)  # type: ignore

    remove_redundant_center: BoolProperty(name="Remove Redundant Center", default=False)  # type: ignore
    redundant_threshold: FloatProperty(name="Angle Threshold", default=0.05, min=0, max=1, step=0.1)  # type: ignore

    has_custom_normals: BoolProperty(default=False)  # type: ignore
    mirror_custom_normals: BoolProperty(name="Mirror Custom Normals", default=True)  # type: ignore

    has_vertex_groups: BoolProperty(default=False)  # type: ignore
    mirror_vertex_groups: BoolProperty(name="Mirror Vertex Groups", default=False)  # type: ignore

    has_uvs: BoolProperty(default=False)  # type: ignore
    offset_uvs: BoolProperty(name="Offset UVs", default=True)  # type: ignore
    uv_offset: IntVectorProperty(name="UV Offset", default=(1, 0), size=2, min=-100, max=100)  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    is_previewing: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    time: FloatProperty(default=0.4, options={'HIDDEN'})  # type: ignore
    _object_name: str = ""  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self._object_name = self.act_obj.name
        self.mx = self.act_obj.matrix_world
        self.cmx = context.scene.cursor.matrix

        self.bm = bmesh.from_edit_mesh(self.act_obj.data)
        self.bm.verts.ensure_lookup_table()
        self.all_coords = [self.mx @ v.co for v in self.bm.verts]

        has_selection = any(v.select for v in self.bm.verts)
        if has_selection:
            self.scope = 'SELECTED'
        else:
            self.scope = 'ALL'

        self.has_custom_normals = self.act_obj.data.has_custom_normals
        self.has_vertex_groups = bool(self.act_obj.vertex_groups)
        self.has_uvs = bool(self.act_obj.data.uv_layers)

        _init_flick_context(self, context, event, self.use_cursor)

        self.init_status(context, func=_draw_symmetrize_status(self))
        self.init_modal_handlers(context, hud=True, view3d=True)
        context.active_object.select_set(True)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        # 预览阶段需接收TIMER事件驱动顶点预览渐隐与超时结束, 故此时不忽略定时器事件
        if ignore_events(event, timer=not self.is_previewing):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()
        self.mousepos = Vector((event.mouse_region_x, event.mouse_region_y, 0))

        if self.is_previewing:
            return self._handle_preview_modal(context, event)

        events = ['MOUSEMOVE', 'M', 'C']

        if self.mode == 'MIRROR':
            events.append('S')

            if self.has_uvs:
                events.append('D')

            if self.scope == 'ALL':
                if not self.has_custom_normals or not self.mirror_custom_normals:
                    events.append('R')

                if self.has_vertex_groups:
                    events.append('V')

            if self.has_custom_normals:
                events.append('N')

        if event.type in events:
            if self.pass_through:
                _reset_flick_anchor(self, context)

            self._get_flick_dir_from_mouse(context)

            if self.flick_vector.length > self.flick_distance:
                if self.mode == 'MIRROR':
                    self._start_preview(context)
                    return {'RUNNING_MODAL'}
                else:
                    self.finish(context)
                    self._execute_symmetrize(context)
                    return {'FINISHED'}

            if event.value == 'PRESS':
                self._handle_key_press(context, event)
                force_ui_update(context)

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)

            if self.flick_dir:
                self.direction, self.axis = self._get_blender_symmetrize_direction()

            self._execute_symmetrize(context)

            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context)
            force_ui_update(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _handle_preview_modal(self, context: Context, event: Event):
        """处理预览状态的模态事件"""
        if event.type == 'TIMER':
            self.update_countdown()

            if self.countdown <= 0:
                self._finish_preview(context)
                return {'FINISHED'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self._finish_preview(context)
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def _start_preview(self, context: Context):
        """开始预览状态:先执行对称操作,然后预览新创建的顶点"""
        self.is_previewing = True
        self.direction, self.axis = self._get_blender_symmetrize_direction()

        result = self._execute_symmetrize(context)

        self.bm = bmesh.from_edit_mesh(self.act_obj.data)
        self.bm.verts.ensure_lookup_table()
        self.all_coords = [self.mx @ v.co for v in self.bm.verts]

        self.preview_mirror_indices = result['mirror']

        self.init_timer_modal()
        self.TIMER = context.window_manager.event_timer_add(0.05, window=context.window)

    def _finish_preview(self, context: Context):
        """结束预览状态"""
        self.is_previewing = False
        if hasattr(self, 'TIMER'):
            context.window_manager.event_timer_remove(self.TIMER)
            self.TIMER = None
        self.finish_status()
        self.finish_modal_handlers()

    def execute(self, context: Context):
        """直接执行对称化操作"""
        # 重做会在同一实例上重跑 execute, invoke 保存的物体引用经撤销回退后失效,
        # 须按名重解析并刷新矩阵, 不能沿用可能失效的旧引用
        self.act_obj = None
        if self._object_name:
            self.act_obj = context.scene.objects.get(self._object_name)

        if self.act_obj is None:
            self.act_obj = context.active_object

        if self.act_obj is None:
            self.report({'WARNING'}, "No active mesh object")
            return {'CANCELLED'}

        self.mx = self.act_obj.matrix_world
        self.cmx = context.scene.cursor.matrix

        # 重做面板可把scope改为SELECTED, 此时不经过invoke的自动回落, 无选中须提示并取消
        if self.mode == 'MIRROR' and self.scope == 'SELECTED':
            bm = bmesh.from_edit_mesh(self.act_obj.data)
            if not any(v.select for v in bm.verts):
                self.report({'WARNING'}, "No selected elements")
                return {'CANCELLED'}

        self._execute_symmetrize(context)
        return {'FINISHED'}

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器)"""
        self.finish_status()
        self.finish_modal_handlers()

    def draw(self, context: Context):
        """绘制操作面板"""
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "mode")

        if self.mode == 'MIRROR':
            row = layout.row(align=True)
            row.prop(self, 'scope')

        layout.prop(self, "use_cursor")

        row = layout.row(align=True)
        row.prop(self, "axis", expand=True)

        row = layout.row(align=True)
        row.prop(self, "direction", expand=True)

        if self.mode == 'MIRROR':
            if self.has_uvs:
                row = layout.row(align=True)
                row.prop(self, "offset_uvs")

                row = layout.row(align=True)
                row.prop(self, "uv_offset", expand=True)
                row.active = self.offset_uvs

            if self.has_custom_normals:
                layout.prop(self, "mirror_custom_normals")

            if self.scope == 'ALL':
                if not self.has_custom_normals or not self.mirror_custom_normals:
                    layout.prop(self, "remove_redundant_center")

                    row = layout.row(align=True)
                    row.prop(self, "redundant_threshold")
                    row.active = self.remove_redundant_center

                if self.has_vertex_groups:
                    layout.prop(self, "mirror_vertex_groups")

    def draw_HUD(self, context: Context):
        """绘制HUD信息"""
        if context.area != self.area or self.pass_through or self.is_previewing:
            return

        color = red if self.mode == 'REMOVE' else white
        alpha = 0.3 if self.mode == 'REMOVE' else 0.1
        _draw_flick_hud(self.flick_vector, self.init_mouse, self.flick_distance, color, alpha)

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图中的轴向量和预览顶点"""
        if context.area != self.area:
            return

        if self.is_previewing:
            progress = self.get_timer_progress()
            alpha = max(0.1, progress)

            draw_points(self.all_coords, indices=self.preview_mirror_indices, color=white, size=5, alpha=alpha)
        else:
            _draw_axis_vectors(self.axes, self.colors, self.init_mouse_3d, self.zoom, self.flick_dir)

    def _execute_symmetrize(self, context: Context) -> dict:
        """执行对称化操作"""
        direction = f"{self.direction}_{self.axis}"

        data = {
            'direction': direction,
            'threshold': self.threshold,
            'partial': self.mode == 'MIRROR' and self.scope == 'SELECTED',
            'remove': self.mode == 'REMOVE',
            'remove_redundant_center': self.remove_redundant_center,
            'redundant_threshold': self.redundant_threshold,
            'uv_offset': Vector(self.uv_offset) if self.has_uvs and self.offset_uvs else Vector((0, 0)),
            'mirror_vertex_groups': bool(self.has_vertex_groups and self.mirror_vertex_groups),
            'mirror_custom_normals': bool(self.has_custom_normals and self.mirror_custom_normals),
            'custom_normal_method': 'INDEX',
            'fix_center': False,
            'fix_center_method': 'CLEAR',
            'clear_sharps': True,
            'use_cursor': self.use_cursor,
            'cursor_matrix': self.cmx if self.use_cursor else None,
            'mirror_vector': axis_vector_mappings[self.axis],
        }

        return symmetrize(self.act_obj, data)

    def _get_flick_dir_from_mouse(self, context: Context):
        """根据鼠标位置获取滑动方向"""
        self.flick_vector = self.mousepos - self.init_mouse

        if self.flick_vector.length:
            self.flick_dir = self.get_flick_dir(context, ['X', 'Y', 'Z'])

            if self.flick_dir:
                self.direction, self.axis = self._get_blender_symmetrize_direction()

    def _get_blender_symmetrize_direction(self) -> tuple:
        """获取Blender对称化方向"""
        direction, axis = self.flick_dir.split('_')
        return 'POSITIVE' if direction == 'NEGATIVE' else 'NEGATIVE', axis

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        key_actions = {
            'M': lambda: setattr(self, 'mode', 'REMOVE' if self.mode == 'MIRROR' else 'MIRROR'),
            'S': lambda: setattr(self, 'scope', 'SELECTED' if self.scope == 'ALL' else 'ALL'),
            'C': lambda: self._toggle_cursor(),
            'D': lambda: setattr(self, 'offset_uvs', not self.offset_uvs),
            'R': lambda: setattr(self, 'remove_redundant_center', not self.remove_redundant_center),
            'V': lambda: setattr(self, 'mirror_vertex_groups', not self.mirror_vertex_groups),
            'N': lambda: setattr(self, 'mirror_custom_normals', not self.mirror_custom_normals),
        }

        if event.type in key_actions:
            key_actions[event.type]()

    def _toggle_cursor(self):
        """切换游标空间"""
        self.use_cursor = not self.use_cursor
        self.axes = _get_axis_vectors(self.cmx if self.use_cursor else self.mx)


def _draw_symmetrize_status(op: EditMeshSymmetrize):
    """
    Symmetrize状态栏绘制函数

    Args:
        op: EditMeshSymmetrize 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text='Finish')
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text='Cancel')
        draw_status_item(row, key='MOVE', text='Pick Axis')

        draw_status_item(row, key='M', text='Remove' if op.mode == 'REMOVE' else 'Mirror', gap=1)
        draw_status_item(row, active=op.use_cursor, key='C', text='Cursor')

        if op.mode == 'MIRROR':
            draw_status_item(row, key='S', text='Selected Only' if op.scope == 'SELECTED' else 'All')

            if op.has_uvs:
                draw_status_item(row, active=op.offset_uvs, key='D', text='Offset UVs')

            if op.has_custom_normals:
                draw_status_item(row, active=op.mirror_custom_normals, key='N', text='Mirror Custom Normals')

            if op.scope == 'ALL':
                if op.has_vertex_groups:
                    draw_status_item(row, active=op.mirror_vertex_groups, key='V', text='Mirror Vertex Groups')

                if not op.has_custom_normals or not op.mirror_custom_normals:
                    draw_status_item(row, active=op.remove_redundant_center, key='R', text='Remove Redundant Center')

    return draw


# ============================================================
# 物体模式快速添加镜像修改器操作器
# ============================================================
class ObjectSymmetrize(Operator, ModalOperatorMixin):
    """
    快速添加镜像修改器操作器

    功能: 通过鼠标滑动方向快速确定镜像轴向并添加镜像修改器
    - 支持游标空间镜像
    - 支持镜像顶点组
    - 支持裁剪
    - 支持设置合并阈值

    要求: 物体模式下有活动网格对象
    """

    bl_idname = "ch.object_symmetrize"
    bl_label = "Object Symmetrize"
    bl_description = "Symmetrize object with flick direction picking"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(name="Axis", items=axis_items, default="X")  # type: ignore
    use_cursor: BoolProperty(name="Cursor", description="Mirror across Cursor", default=False)  # type: ignore
    use_bisect: BoolProperty(name="Bisect", default=False)  # type: ignore
    use_flip: BoolProperty(name="Flip", default=False)  # type: ignore
    bisect_threshold: FloatProperty(name="Bisect Distance", default=0.001, min=0, max=1, precision=3, subtype="DISTANCE")  # type: ignore

    has_vertex_groups: BoolProperty(default=False)  # type: ignore
    mirror_vertex_groups: BoolProperty(name="Mirror Vertex Groups", default=True)  # type: ignore

    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    _mirror_modifier_name: str = ""  # type: ignore
    _object_name: str = ""  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        obj = context.active_object
        return context.mode == 'OBJECT' and obj is not None and obj.type == 'MESH'

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self._object_name = self.act_obj.name
        self.mx = self.act_obj.matrix_world
        self.cmx = context.scene.cursor.matrix

        self.has_vertex_groups = bool(self.act_obj.vertex_groups)

        _init_flick_context(self, context, event, self.use_cursor)

        self.init_status(context, func=_draw_object_symmetrize_status(self))
        self.init_modal_handlers(context, hud=True, view3d=True)
        context.active_object.select_set(True)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        self.mousepos = Vector((event.mouse_region_x, event.mouse_region_y, 0))

        events = ['MOUSEMOVE', 'C', 'B', 'F']

        if self.has_vertex_groups:
            events.append('G')

        if event.type in events:
            if self.pass_through:
                _reset_flick_anchor(self, context)

            self._get_flick_dir_from_mouse(context)

            if self.flick_vector.length > self.flick_distance:
                self.finish(context)
                self._add_mirror_modifier(context)
                return {'FINISHED'}

            if event.value == 'PRESS':
                self._handle_key_press(context, event)
                force_ui_update(context)

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            self._add_mirror_modifier(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context)
            force_ui_update(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        """直接执行添加镜像修改器"""
        # 重做会在同一实例上重跑 execute, invoke 保存的物体引用经撤销回退后失效,
        # 须按名重解析并刷新矩阵, 不能沿用可能失效的旧引用
        self.act_obj = None
        if self._object_name:
            self.act_obj = context.scene.objects.get(self._object_name)

        if self.act_obj is None:
            self.act_obj = context.active_object

        if self.act_obj is None:
            self.report({'WARNING'}, "No active mesh object")
            return {'CANCELLED'}

        self.has_vertex_groups = bool(self.act_obj.vertex_groups)
        self.mx = self.act_obj.matrix_world
        self.cmx = context.scene.cursor.matrix

        if self._mirror_modifier_name:
            mod = self.act_obj.modifiers.get(self._mirror_modifier_name)
            if mod:
                self._update_mirror_modifier(mod)
            else:
                self._add_mirror_modifier(context)
        else:
            self._add_mirror_modifier(context)
        return {'FINISHED'}

    def check(self, context: Context):
        """检查属性变化并更新修改器"""
        if self._object_name:
            obj = context.scene.objects.get(self._object_name)
            if obj:
                if self._mirror_modifier_name:
                    mod = obj.modifiers.get(self._mirror_modifier_name)
                    if mod:
                        self._update_mirror_modifier(mod)
                    else:
                        self.act_obj = obj
                        self._add_mirror_modifier(context)
                return True
        return False

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器)"""
        self.finish_status()
        self.finish_modal_handlers()

    def draw(self, context: Context):
        """绘制操作面板"""
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "use_cursor")

        row = layout.row(align=True)
        row.prop(self, "axis", expand=True)

        layout.prop(self, "use_bisect")
        col = layout.column()
        col.prop(self, "use_flip")
        col.prop(self, "bisect_threshold")
        col.active = self.use_bisect

        col = layout.column()
        col.prop(self, "mirror_vertex_groups")
        col.active = self.has_vertex_groups

    def draw_HUD(self, context: Context):
        """绘制HUD信息"""
        if context.area != self.area or self.pass_through:
            return

        color = red if self.use_bisect else white
        alpha = 0.3 if self.use_bisect else 0.1
        _draw_flick_hud(self.flick_vector, self.init_mouse, self.flick_distance, color, alpha)

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图中的轴向量"""
        if context.area != self.area:
            return

        _draw_axis_vectors(self.axes, self.colors, self.init_mouse_3d, self.zoom, self.flick_dir, point_size=5)

    def _get_flick_dir_from_mouse(self, context: Context):
        """根据鼠标位置获取滑动方向"""
        self.flick_vector = self.mousepos - self.init_mouse

        if self.flick_vector.length:
            self.flick_dir = self.get_flick_dir(context, ['X', 'Y', 'Z'])

            if self.flick_dir:
                direction, self.axis = self.flick_dir.split('_')
                self.use_flip = direction == 'POSITIVE'

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        key_actions = {
            'C': lambda: self._toggle_cursor(),
            'B': lambda: setattr(self, 'use_bisect', not self.use_bisect),
            'F': lambda: setattr(self, 'use_flip', not self.use_flip),
            'G': lambda: setattr(self, 'mirror_vertex_groups', not self.mirror_vertex_groups),
        }

        if event.type in key_actions:
            key_actions[event.type]()

    def _toggle_cursor(self):
        """切换游标空间镜像"""
        self.use_cursor = not self.use_cursor
        self.axes = _get_axis_vectors(self.cmx if self.use_cursor else self.mx)

    def _add_mirror_modifier(self, context: Context):
        """添加镜像修改器"""
        self._object_name = self.act_obj.name
        mod = self.act_obj.modifiers.new(name="Mirror", type='MIRROR')
        self._mirror_modifier_name = mod.name

        if self.use_cursor:
            mirror_object = bpy.data.objects.new(name=f"{self.act_obj.name} Mirror", object_data=None)
            # 空物体归属源物体所在集合: 大纲管理器中仅作为源物体的子级显示, 不在场景集合顶层重复出现
            for coll in self.act_obj.users_collection or [context.scene.collection]:
                coll.objects.link(mirror_object)
            mirror_object.matrix_world = self.cmx
            mirror_object.parent = self.act_obj
            mirror_object.matrix_parent_inverse = self.act_obj.matrix_world.inverted()
            mirror_object.empty_display_type = 'ARROWS'
            mirror_object.empty_display_size = (self.cmx.to_translation() - self.act_obj.matrix_world.to_translation()).length / 10
            mirror_object.hide_viewport = True
            mirror_object.hide_set(True)
            mod.mirror_object = mirror_object

        self._update_mirror_modifier(mod)

    def _update_mirror_modifier(self, mod):
        """更新镜像修改器参数"""
        axis_index = {'X': 0, 'Y': 1, 'Z': 2}[self.axis]

        for i in range(3):
            mod.use_axis[i] = i == axis_index
            mod.use_bisect_axis[i] = i == axis_index and self.use_bisect
            mod.use_bisect_flip_axis[i] = i == axis_index and self.use_flip

        mod.bisect_threshold = self.bisect_threshold

        if self.has_vertex_groups:
            mod.use_mirror_vertex_groups = self.mirror_vertex_groups


def _draw_object_symmetrize_status(op: ObjectSymmetrize):
    """
    ObjectSymmetrize状态栏绘制函数

    Args:
        op: ObjectSymmetrize 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text='Finish')
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text='Cancel')
        draw_status_item(row, key='MOVE', text='Pick Axis')

        draw_status_item(row, active=op.use_cursor, key='C', text='Cursor', gap=1)
        draw_status_item(row, active=op.use_bisect, key='B', text='Clip')
        if op.use_bisect:
            draw_status_item(row, active=op.use_flip, key='F', text='Flip')

        if op.has_vertex_groups:
            draw_status_item(row, active=op.mirror_vertex_groups, key='G', text='Mirror Vertex Groups')

    return draw


# ============================================================
# 曲线编辑模式快速对称化操作器
# ============================================================
class EditCurveSymmetrize(Operator, ModalOperatorMixin):
    """
    曲线快速对称化操作器

    功能: 通过鼠标滑动方向快速确定对称轴和方向
    - 支持在光标空间或物体空间对称化
    - 支持移除冗余中心点

    要求: 曲线编辑模式下有活动的POLY或NURBS样条
    """

    bl_idname = "ch.editcurve_symmetrize"
    bl_label = "Edit Curve Symmetrize"
    bl_description = "Edit curve symmetry with flick direction"
    bl_options = {'REGISTER', 'UNDO'}

    use_cursor: BoolProperty(name="Cursor", description="Symmetrize in Cursor Space", default=False)  # type: ignore
    remove_redundant: BoolProperty(name="Remove Redundant", description="Remove Redundant Center Points", default=True)  # type: ignore
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'EDIT_CURVE':
            act_obj = context.active_object
            if act_obj and act_obj.type == 'CURVE':
                active_spline = act_obj.data.splines.active
                return active_spline and active_spline.type in ['POLY', 'NURBS']

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_curve = self.act_obj.data
        self.mx = self.act_obj.matrix_world
        self.cmx = context.scene.cursor.matrix

        self.last_direction = None
        self.is_valid = False
        self.has_redundant = False

        self.coords = {}
        self.data = get_curve_data(self.act_curve)

        _init_flick_context(self, context, event, self.use_cursor)

        self.init_status(context, func=_draw_editcurve_symmetrize_status(self))
        self.init_modal_handlers(context, hud=True, view3d=True)
        force_ui_update(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()
        self.mousepos = Vector((event.mouse_region_x, event.mouse_region_y, 0))

        events = ['MOUSEMOVE', 'C']
        if self.has_redundant:
            events.append('R')

        if event.type in events:
            if self.pass_through:
                _reset_flick_anchor(self, context)

            self._get_flick_dir_from_mouse(context)

            if self.flick_vector.length > self.flick_distance:
                self.finish(context)
                if self.is_valid:
                    self._symmetrize_spline()
                return {'FINISHED'}

            if event.value == 'PRESS':
                self._handle_key_press(context, event)
                force_ui_update(context)

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            if self.is_valid:
                self._symmetrize_spline()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context)
            if self.flick_dir:
                self._restore_spline_visibility()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器)"""
        self.finish_status()
        self.finish_modal_handlers()

    def _restore_spline_visibility(self):
        """恢复样条可见性"""
        active_points = self.act_curve.splines.active.points
        original_points = self.data.active.points
        for idx, point in enumerate(active_points):
            if point.hide != original_points[idx].hide:
                point.hide = not point.hide

    def draw_HUD(self, context: Context):
        """绘制HUD信息"""
        if context.area != self.area or self.pass_through:
            return

        color, alpha = (white, 0.02) if self.is_valid or not self.flick_dir else (red, 0.5)
        _draw_flick_hud(self.flick_vector, self.init_mouse, self.flick_distance, color, alpha, fade=True)

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图中的轴向量和预览"""
        if context.area != self.area or self.pass_through:
            return

        _draw_axis_vectors(self.axes, self.colors, self.init_mouse_3d, self.zoom, self.flick_dir)

        if 'geometry' in self.coords:
            for is_cyclic, coords in self.coords['geometry']:
                draw_line(coords, width=2, color=white if self.is_valid else red)
                draw_points(coords, color=black if self.is_valid else red)
                if self.is_valid and is_cyclic:
                    draw_line([coords[0], coords[-1]], width=2, color=black)

        if self.coords.get('lines'):
            color = red if '_X' in self.flick_dir else green if '_Y' in self.flick_dir else blue
            for vec, origin in zip(self.coords['lines']['vectors'], self.coords['lines']['origins']):
                draw_vector(vec, origin=origin, fade=True, color=color, alpha=0.3)

        if coords := self.coords.get('redundant', []):
            draw_points(coords, color=red if self.remove_redundant else yellow)

    def _get_axes(self) -> dict:
        """获取轴向向量"""
        return _get_axis_vectors(self.cmx if self.use_cursor else self.mx)

    def _get_flick_dir_from_mouse(self, context: Context):
        """根据鼠标位置获取滑动方向"""
        self.flick_vector = self.mousepos - self.init_mouse

        if not self.flick_vector.length:
            return

        self.flick_dir = self.get_flick_dir(context, ['X', 'Y', 'Z'])

        if self.flick_dir != self.last_direction:
            self.last_direction = self.flick_dir
            self._refresh_symmetrize_data()

    def _refresh_symmetrize_data(self):
        """刷新对称化数据"""
        base_normal = _AXIS_VECTORS.get(self.flick_dir)
        loc, normal, offset = get_mirror_plane(base_normal, self.use_cursor, self.mx, self.cmx)
        self.symmetrize_data = compute_symmetrized_splines(self.data.active, loc, normal, offset)
        self.has_redundant = self.symmetrize_data['has_redundant']
        self.is_valid = self.flick_dir is not None and self.symmetrize_data['type'] != 'INVALID'
        self._set_active_spline_visibility()
        self._create_preview_coords()

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        key_actions = {
            'C': lambda: self._toggle_cursor(context),
            'R': lambda: setattr(self, 'remove_redundant', not self.remove_redundant),
        }

        if event.type in key_actions:
            key_actions[event.type]()

    def _toggle_cursor(self, context: Context):
        """切换光标空间"""
        self.use_cursor = not self.use_cursor
        self.axes = self._get_axes()

        if self.flick_vector.length:
            self.flick_dir = self.get_flick_dir(context, ['X', 'Y', 'Z'])
            self.last_direction = self.flick_dir
            self._refresh_symmetrize_data()

    def _create_preview_coords(self):
        """创建预览坐标"""
        self.coords['geometry'] = []
        self.coords['lines'] = {'vectors': [], 'origins': []}
        self.coords['redundant'] = []

        if not self.is_valid:
            active = self.act_curve.splines.active
            coords = [self.mx @ p.co.xyz for p in active.points]
            self.coords['geometry'].append((active.use_cyclic_u, coords))
            return

        for data in self.symmetrize_data['mirrored_splines']:
            coords = [self.mx @ p.co.xyz for p in data.points]
            self.coords['geometry'].append((data.is_cyclic, coords))

            for point in data.points:
                if point.line:
                    self.coords['lines']['vectors'].append(self.mx.to_3x3() @ (point.line[1].xyz - point.line[0].xyz))
                    self.coords['lines']['origins'].append(self.mx @ point.line[0].xyz)
                if point.is_redundant:
                    self.coords['redundant'].append(self.mx @ point.co.xyz)

    def _set_active_spline_visibility(self):
        """设置活动样条可见性"""
        active_points = self.act_curve.splines.active.points
        if self.symmetrize_data['type'] == 'COMPLEX':
            for point in active_points:
                point.hide = True
        else:
            original_points = self.data.active.points
            for idx, point in enumerate(active_points):
                if point.hide != original_points[idx].hide:
                    point.hide = not point.hide

    def _symmetrize_spline(self):
        """执行样条对称化"""
        if self.symmetrize_data['type'] == 'COMPLEX':
            self.act_curve.splines.remove(self.act_curve.splines.active)
            if self.has_redundant and self.remove_redundant:
                for spline_data in self.symmetrize_data['mirrored_splines']:
                    spline_data.points = [p for p in spline_data.points if not p.is_redundant]

        active = None
        for spline_data in self.symmetrize_data['mirrored_splines']:
            spline = create_spline_from_data(self.act_curve, spline_data)
            if not active:
                active = spline

        self.act_curve.splines.active = active


def _draw_editcurve_symmetrize_status(op: EditCurveSymmetrize):
    """
    EditCurveSymmetrize状态栏绘制函数

    Args:
        op: EditCurveSymmetrize 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text='Finish')
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text='Cancel')
        draw_status_item(row, key='MOVE', text='Pick Axis', gap=1)
        draw_status_item(row, active=op.use_cursor, key='C', text='Cursor')

        if op.has_redundant:
            draw_status_item(row, active=op.remove_redundant, key='R', text='Remove Redundant')

    return draw
