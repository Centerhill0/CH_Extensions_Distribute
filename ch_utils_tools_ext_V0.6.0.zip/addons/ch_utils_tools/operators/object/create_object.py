"""
网格物体创建操作器模块

提供以下功能:
- CreatePointObject: 创建单点物体
- CreateMeshQuadSphere: 创建四边面球体
- CreateCircle: 添加圆环(+Alt 基于三个选中顶点生成外接圆环)
- DupAndSep: 复制并分离选中元素
"""

__all__ = [
    "CreatePointObject",
    "CreateMeshQuadSphere",
    "CreateCircle",
    "DupAndSep",
]

import bpy
import bmesh
from bpy.types import Context, Object, Operator, Event
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from mathutils import Matrix, Quaternion, Vector
from mathutils.geometry import normal

from ...items import circle_fill_type_items, circle_size_mode_items
from ...utils import get_active_element_from_bmesh, get_circle_points, get_circumcenter


# ============================================================
# 创建点物体
# ============================================================
class CreatePointObject(Operator):
    """
    创建网格点物体或曲线点物体,+alt键创建曲线点物体
    要求:物体模式
    """

    bl_idname = "ch.create_point"
    bl_label = "Add Point"
    bl_description = "Create a mesh point object\n+Alt: Create a curve point object"
    bl_options = {'REGISTER', 'UNDO'}

    is_align_rotation: BoolProperty(name="Align to Cursor Rotation", default=False, description="Align rotation to cursor")  # type: ignore

    use_curve_point: bool = False  # invoke 中按 Alt 键设置

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def invoke(self, context: Context, event: Event):
        self.use_curve_point = event.alt
        return self.execute(context)

    def execute(self, context: Context):
        if self.use_curve_point:
            obdata = self._create_curve_point(context)
        else:
            obdata = self._create_mesh_point(context)

        # 创建物体并链接到场景
        point_obj = bpy.data.objects.new("CurvePoint" if self.use_curve_point else "MeshPoint", obdata)
        context.collection.objects.link(point_obj)

        # 清除当前选择并选中新创建的点物体
        bpy.ops.object.select_all(action='DESELECT')
        point_obj.select_set(True)
        context.view_layer.objects.active = point_obj

        # 对齐游标变换
        loc, rot, _ = context.scene.cursor.matrix.decompose()
        rotation = rot if self.is_align_rotation else Quaternion()
        point_obj.matrix_world = Matrix.LocRotScale(loc, rotation, Vector((1, 1, 1)))

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "is_align_rotation")

    def _create_curve_point(self, context: Context):
        # 创建曲线物体数据
        curve_data = bpy.data.curves.new(name="CurvePoint", type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.use_fill_caps = True

        # 创建曲线点
        spline = curve_data.splines.new('POLY')
        point = spline.points[0]
        point.co = Vector((0, 0, 0, 1))
        point.select = True

        return curve_data

    def _create_mesh_point(self, context: Context):
        # 创建新的网格数据,包含单个顶点
        mesh_data = bpy.data.meshes.new('MeshPoint')
        mesh_data.from_pydata([(0, 0, 0)], [], [])

        return mesh_data


# ============================================================
# 创建网格四边面球体
# ============================================================
class CreateMeshQuadSphere(Operator):
    """
    创建四边面球体

    功能:创建一个由四边面组成的球体
    - 基于立方体细分化后球形化
    - 支持自定义细分级数
    - 支持自动平滑着色
    - 支持对齐游标旋转

    要求:物体模式
    """

    bl_idname = "ch.create_mesh_quadsphere"
    bl_label = "Add Quad Sphere"
    bl_description = "Create a quad sphere object"
    bl_options = {'REGISTER', 'UNDO'}

    subdivisions: IntProperty(name="Subdivisions", default=5, min=1, max=8)  # type: ignore
    is_shade_auto_smooth: BoolProperty(name="Shade Auto Smooth", default=True)  # type: ignore
    is_align_rotation: BoolProperty(name="Align Cursor Rotation", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def execute(self, context: Context):
        # 创建立方体(对齐游标或世界)
        bpy.ops.mesh.primitive_cube_add(align='CURSOR' if self.is_align_rotation else 'WORLD')

        # 进入编辑模式进行细分化
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.subdivide(number_cuts=self.subdivisions, smoothness=1)

        # 球形化变形
        bpy.ops.transform.tosphere(value=1)

        # 返回物体模式
        bpy.ops.object.mode_set(mode='OBJECT')

        # 应用自动平滑着色
        if self.is_shade_auto_smooth:
            bpy.ops.object.shade_auto_smooth()

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "subdivisions")
        layout.prop(self, "is_shade_auto_smooth")
        layout.prop(self, "is_align_rotation")


# ============================================================
# 添加圆环
# ============================================================
class CreateCircle(Operator):
    """
    添加圆环

    功能:默认添加网格圆环图元, +Alt 基于三个选中顶点生成外接圆环
    - 默认:转调内置 mesh.primitive_circle_add, Redo 面板镜像其顶点数/半径/填充参数
    - +Alt:反推三点外接圆圆心, 按分段数生成闭合圆环, 不移动 3D 游标
    - 圆环尺寸由 Scale(外接圆半径缩放)或 Radius(绝对半径)择一控制
    - 两分支都将新圆环置为唯一选区, 便于紧接着变换

    要求:网格编辑模式; +Alt 时恰好选中三个顶点
    """

    bl_idname = "ch.create_circle"
    bl_label = "Add Circle"
    bl_description = "Add a circle primitive\n+Alt: Generate a circle ring from three selected vertices"
    bl_options = {'REGISTER', 'UNDO'}

    num_verts: IntProperty(name="Vertices", description="Vertex count of the generated circle ring", default=12, min=3, max=60)  # type: ignore
    size_mode: EnumProperty(name="Size Mode", description="Parameter that controls the generated ring size", items=circle_size_mode_items, default='SCALE')  # type: ignore
    scale: FloatProperty(name="Scale", description="Radius scale relative to the circumradius of the three vertices", default=1.0, min=0.0001, precision=4)  # type: ignore
    radius: FloatProperty(name="Radius", description="Circle radius", default=1.0, min=0.0, precision=5, unit='LENGTH')  # type: ignore
    vertices: IntProperty(name="Vertices", description="Number of vertices for the added circle", default=32, min=3, max=10000000)  # type: ignore
    fill_type: EnumProperty(name="Fill Type", description="Fill type for the added circle", items=circle_fill_type_items, default='NOTHING')  # type: ignore

    is_from_points: bool = False  # invoke 中按 Alt 键设置

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def invoke(self, context: Context, event: Event):
        self.is_from_points = event.alt
        return self.execute(context)

    def execute(self, context: Context):
        if not self.is_from_points:
            bpy.ops.mesh.primitive_circle_add('EXEC_DEFAULT', vertices=self.vertices, radius=self.radius, fill_type=self.fill_type)
            return {'FINISHED'}

        self.act_obj: Object = context.active_object
        bm = bmesh.from_edit_mesh(self.act_obj.data)

        verts = [vert for vert in bm.verts if vert.select and not vert.hide]
        if len(verts) != 3:
            self.report({'WARNING'}, "Select exactly three vertices")
            return {'CANCELLED'}

        center, err = get_circumcenter(verts[0].co, verts[1].co, verts[2].co)
        if err:
            self.report({'WARNING'}, err)
            return {'CANCELLED'}

        axis = normal(verts[0].co, verts[1].co, verts[2].co)
        if self.size_mode == 'SCALE':
            anchor = verts[0].co
            scale = self.scale
        else:
            anchor = center + (verts[0].co - center).normalized() * self.radius
            scale = 1.0
        points = get_circle_points(center, anchor, axis, self.num_verts, scale)

        # 新圆环置为唯一选区: 对齐默认分支(内置图元算子)的行为, 源顶点随旧选区一并去选
        for vert in bm.verts:
            vert.select = False
        for edge in bm.edges:
            edge.select = False
        for face in bm.faces:
            face.select = False

        ring_verts = []
        for co in points:
            vert = bm.verts.new(co)
            vert.select = True
            ring_verts.append(vert)
        for idx in range(len(ring_verts)):
            edge = bm.edges.new((ring_verts[idx], ring_verts[(idx + 1) % len(ring_verts)]))
            edge.select = True

        # 直接改 select 标志不校验选择历史, 活动顶点仍指向源顶点而残留视口高亮:
        # 校验剔除历史中的未选中元素, 并立新环末顶点为活动元素
        bm.select_history.validate()
        bm.select_history.add(ring_verts[-1])

        bmesh.update_edit_mesh(self.act_obj.data)
        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        if self.is_from_points:
            layout.prop(self, "num_verts")
            row = layout.row()
            row.prop(self, "size_mode", expand=True)
            if self.size_mode == 'SCALE':
                layout.prop(self, "scale")
            else:
                layout.prop(self, "radius")
        else:
            # 默认分支转调内置算子, 镜像其 Redo 可调参数
            layout.prop(self, "vertices")
            layout.prop(self, "radius")
            layout.prop(self, "fill_type")


# ============================================================
# 复制并分离
# ============================================================
class DupAndSep(Operator):
    """
    复制并分离

    功能:分离选中的网格元素
    - 默认:直接分离选中元素
    - Alt:先复制再分离

    要求:网格编辑模式下有选中元素
    """

    bl_idname = "ch.duplicate_and_separate"
    bl_label = "Duplicate and Separate"
    bl_description = "Separate selected elements\n+Alt: Duplicate and Separate"
    bl_options = {'REGISTER', 'UNDO'}

    is_separate: bool = False  # invoke 中按 Alt 键设置

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return get_active_element_from_bmesh(context, bm)

    def invoke(self, context: Context, event: Event):
        self.is_separate = event.alt
        return self.execute(context)

    def execute(self, context: Context):
        # Alt 按下时先复制
        if self.is_separate:
            bpy.ops.mesh.duplicate()

        # 分离选中元素
        bpy.ops.mesh.separate(type='SELECTED')

        return {'FINISHED'}
