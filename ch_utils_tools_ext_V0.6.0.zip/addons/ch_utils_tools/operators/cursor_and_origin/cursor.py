"""
游标操作器模块

提供以下功能:
- CursorToSelected: 吸附游标到选中项
- SelectedToCursor: 吸附选中项到游标
- CursorToOrigin: 吸附游标到世界原点

约定: 事件修饰键以类级缺省声明, 因 execute 可能未经 invoke 直接执行(脚本调用 / F9 重做),
此时按无修饰键处理; 上下文派生的选择状态在 execute 现算, 保证 execute 可独立执行.
"""

__all__ = [
    "CursorToSelected",
    "SelectedToCursor",
    "CursorToOrigin",
]

import bpy
import bmesh
from bpy.types import Object, Operator, Context, Event
from mathutils import Matrix, Vector, Quaternion
from bmesh.types import BMVert, BMEdge, BMFace

from .....common.i18n.i18n import tip

from ...utils import (
    get_active_element_from_bmesh,
    get_average_position,
    get_lerp_position,
    compensate_children,
    set_cursor_transform,
    get_rotation_matrix_from_vert,
    get_rotation_matrix_from_edge,
    get_rotation_matrix_from_face,
)


# ============================================================
# 吸附游标到选中项
# ============================================================
class CursorToSelected(Operator):
    """
    吸附游标到选中项

    功能:将 3D 游标对齐到选中的物体或元素
    - 物体模式:对齐到活动物体或选中物体的中心
    - 编辑模式:对齐到选中的顶点/边/面
    - Alt:仅设置游标位置
    - Ctrl:仅设置游标旋转
    """

    bl_idname = "ch.cursor_to_selected"
    bl_label = "Cursor To Selected"
    bl_description = "Snap Cursor to Selected Geometry\n+Alt: Only set Cursor Location"
    # bl_options = {'REGISTER', 'UNDO'}

    is_only_loc: bool = False  # invoke 中按 Alt 键设置
    is_only_rot: bool = False  # invoke 中按 Ctrl 键设置

    @classmethod
    def description(cls, context: Context, properties):
        if context.mode == 'OBJECT':
            return tip("Align Cursor with Selected Object(s)\n+Alt: Only set Cursor Location\n+Ctrl: Only set Cursor Rotation")
        elif context.mode == 'EDIT_MESH':
            return tip("Align Cursor with Vert/Edge/Face\n+Alt: Only set Cursor Location\n+Ctrl: Only set Cursor Rotation")

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'OBJECT':
            return bool(context.active_object or context.selected_objects)
        elif context.mode == 'EDIT_MESH':
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return bool(get_active_element_from_bmesh(context, bm))

    def invoke(self, context: Context, event: Event):
        self.is_only_loc = event.alt
        self.is_only_rot = event.ctrl

        # Alt 和 Ctrl 不能同时按下
        if self.is_only_loc and self.is_only_rot:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        return self.execute(context)

    def execute(self, context: Context):
        # 选择状态为上下文派生, 与事件无关, 在 execute 现算以保证其可独立执行
        self.act_obj = context.active_object
        self.sel_objs = [obj for obj in context.selected_objects if obj != self.act_obj]

        # 如果没有活动对象,将第一个选中对象设为活动对象
        if self.sel_objs and not self.act_obj:
            context.view_layer.objects.active = self.sel_objs[0]
            self.sel_objs.remove(context.active_object)

        cur_mx = context.scene.cursor.matrix

        # 物体模式且只有活动对象
        if context.mode == 'OBJECT' and self.act_obj and not self.sel_objs:
            self._cursor_to_selected_active_object(context, self.act_obj, cur_mx, self.is_only_loc, self.is_only_rot)

        # 网格编辑模式
        elif context.mode == 'EDIT_MESH':
            self._cursor_to_selected_edit_mesh(context, self.act_obj, cur_mx, self.is_only_loc, self.is_only_rot)

        # 其他情况:调用系统默认工具(物体模式多选)
        else:
            bpy.ops.view3d.snap_cursor_to_selected()

        return {'FINISHED'}

    def _cursor_to_selected_active_object(self, context: Context, act_obj: Object, cur_mx: Matrix, is_only_loc: bool, is_only_rot: bool) -> None:
        """
        将游标对齐到活动物体

        Args:
            context: Blender上下文
            act_obj: 活动物体
            cur_mx: 当前游标矩阵
            is_only_loc: 是否仅设置位置
            is_only_rot: 是否仅设置旋转
        """
        loc, rot, _ = act_obj.matrix_world.decompose()
        set_cursor_transform(
            context,
            loc=cur_mx.to_translation() if is_only_rot else loc,
            rot=cur_mx.to_quaternion() if is_only_loc else rot,
        )

    def _cursor_to_selected_edit_mesh(self, context: Context, act_obj: Object, cur_mx: Matrix, is_only_loc: bool, is_only_rot: bool) -> None:
        """
        将游标对齐到编辑模式下的选中元素

        根据活动元素类型(顶点/边/面)计算位置和旋转

        Args:
            context: Blender上下文
            act_obj: 活动物体
            cur_mx: 当前游标矩阵
            is_only_loc: 是否仅设置位置
            is_only_rot: 是否仅设置旋转
        """
        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.verts.ensure_lookup_table()

        act_element = get_active_element_from_bmesh(context, bm)
        act_mx = act_obj.matrix_world.copy()

        # 根据活动元素类型处理
        if isinstance(act_element, BMVert):
            # 顶点模式:计算选中顶点的平均位置
            vert_list = [v for v in bm.verts if v.select]
            vertex_center = get_average_position([v.co for v in vert_list])
            loc = act_mx @ vertex_center
            rot = get_rotation_matrix_from_vert(context, act_mx, act_element)

        elif isinstance(act_element, BMEdge):
            # 边模式:计算选中边的中点平均位置
            edge_list = [e for e in bm.edges if e.select]
            edge_center = get_average_position([get_lerp_position(*e.verts) for e in edge_list])
            loc = act_mx @ edge_center
            rot = get_rotation_matrix_from_edge(context, act_mx, act_element)

        elif isinstance(act_element, BMFace):
            # 面模式:计算选中面的中心平均位置
            face_list = [f for f in bm.faces if f.select]
            face_center = get_average_position([f.calc_center_median_weighted() for f in face_list])
            loc = act_mx @ face_center
            rot = get_rotation_matrix_from_face(act_mx, act_element)

        # 更新游标位置和旋转
        set_cursor_transform(
            context,
            loc=cur_mx.to_translation() if is_only_rot else loc,
            rot=cur_mx.to_quaternion() if is_only_loc else rot.to_quaternion(),
        )


# ============================================================
# 吸附选中项到游标
# ============================================================
class SelectedToCursor(Operator):
    """
    吸附选中项到游标

    功能:将选中的物体变换到游标位置和旋转
    - 默认:同时设置位置和旋转
    - Alt:仅设置位置
    - Ctrl:仅设置旋转

    要求:物体模式下有选中物体
    """

    bl_idname = "ch.selected_to_cursor"
    bl_label = "Selected To Cursor"
    bl_description = "Transform Selected Objects to Cursor\n+Alt: Only set Location\n+Ctrl: Only set Rotation"
    bl_options = {'REGISTER', 'UNDO'}

    is_only_loc: bool = False  # invoke 中按 Alt 键设置
    is_only_rot: bool = False  # invoke 中按 Ctrl 键设置

    @classmethod
    def poll(cls, context):
        if context.mode == 'OBJECT':
            return bool(context.active_object or context.selected_objects)

    def invoke(self, context: Context, event: Event):
        self.is_only_loc = event.alt
        self.is_only_rot = event.ctrl

        # Alt 和 Ctrl 不能同时按下
        if self.is_only_loc and self.is_only_rot:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        return self.execute(context)

    def execute(self, context: Context):
        # 选择状态为上下文派生, 与事件无关, 在 execute 现算以保证其可独立执行
        act_obj = context.active_object
        self.sel_objs = [obj for obj in context.selected_objects]
        if act_obj not in self.sel_objs and act_obj is not None:
            self.sel_objs.append(act_obj)

        # 获取游标的位置和旋转
        new_loc, new_rot, _ = context.scene.cursor.matrix.decompose()

        for obj in self.sel_objs:
            loc, rot, sca = obj.matrix_world.decompose()

            # 根据模式构建新的变换矩阵
            if self.is_only_loc:
                new_mx = Matrix.LocRotScale(new_loc, rot, sca)
            elif self.is_only_rot:
                new_mx = Matrix.LocRotScale(loc, new_rot, sca)
            else:
                new_mx = Matrix.LocRotScale(new_loc, new_rot, sca)

            # 处理子物体补偿
            if obj.children and context.scene.tool_settings.use_transform_skip_children:
                compensate_children(obj, obj.matrix_world, new_mx)

            obj.matrix_world = new_mx

        return {'FINISHED'}


# ============================================================
# 吸附游标到原点
# ============================================================
class CursorToOrigin(Operator):
    """
    吸附游标到世界原点

    功能:将 3D 游标重置到世界原点
    - 默认:同时重置位置和旋转
    - Alt:仅重置位置
    - Ctrl:仅重置旋转
    """

    bl_idname = "ch.cursor_to_origin"
    bl_label = "Cursor To Origin"
    bl_description = "Reset Cursor to World Origin\n+Alt: Only reset Cursor Location\n+Ctrl: Only reset Cursor Rotation"

    is_only_loc: bool = False  # invoke 中按 Alt 键设置
    is_only_rot: bool = False  # invoke 中按 Ctrl 键设置

    @classmethod
    def poll(cls, context: Context):
        return True

    def invoke(self, context: Context, event: Event):
        self.is_only_loc = event.alt
        self.is_only_rot = event.ctrl

        # Alt 和 Ctrl 不能同时按下
        if self.is_only_loc and self.is_only_rot:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        return self.execute(context)

    def execute(self, context: Context):
        cur_mx = context.scene.cursor.matrix
        set_cursor_transform(
            context,
            loc=cur_mx.to_translation() if self.is_only_rot else Vector(),
            rot=cur_mx.to_quaternion() if self.is_only_loc else Quaternion(),
        )
        return {'FINISHED'}
