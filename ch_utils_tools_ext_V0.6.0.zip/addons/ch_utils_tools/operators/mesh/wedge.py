"""
楔形几何体创建操作模块

从选中的边创建楔形(Wedge)几何体.
通过在边的端点处创建新的面来形成楔形结构.

操作流程:
1. 选择一条流形边(manifold edge)
2. 区域定义模式: 移动鼠标定义楔形区域,按LMB进入深度定义模式
3. 深度定义模式: 移动鼠标定义楔形深度,按LMB确认完成
4. 按RMB可从深度模式返回区域模式,或取消操作

支持的选项:
- Planar Quad: 创建平面四边形楔形(P键切换)
- Flip: 翻转楔形方向(F键,当两端都有面时可用)
- Slide: 滑动楔形角点位置(S键)

快捷键:
区域定义模式:
- 鼠标移动: 定义楔形区域
- LMB: 进入深度定义模式
- F: 翻转楔形方向
- S: 滑动楔形角点
- RMB/ESC: 取消操作

深度定义模式:
- 鼠标移动: 定义楔形深度
- LMB/Space: 确认完成
- P: 切换平面四边形模式
- RMB: 返回区域定义模式
- ESC: 取消操作
"""

__all__ = ["WedgeExtrude"]

import bmesh
from bpy.types import Operator, Context, Event
from bpy.props import BoolProperty, FloatProperty, IntProperty
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d
from mathutils import Matrix, Vector
from mathutils.geometry import intersect_point_line, intersect_line_line, intersect_line_plane

from ...constants import white, red, blue, green, yellow, black
from ...utils import (
    Snap,
    ensure_default_data_layers,
    ignore_events,
    draw_line,
    draw_lines,
    draw_points,
    rotate_list,
    draw_status_item,
    force_ui_update,
    navigation_passthrough,
    get_edge_angle,
    format_adaptive_precision,
)
from ...modal_base import ModalOperatorMixin

from dataclasses import dataclass, field


@dataclass
class WedgeEndData:
    """楔形端面数据(端点边/端面/顶点及其坐标缓存)"""

    edge: dict = field(default_factory=dict)  # 端点边 {面索引: 边索引}
    other_edge: dict = field(default_factory=dict)  # 端点另一条边 {面索引: 边索引}
    edge_coords: dict = field(default_factory=dict)  # 端点边坐标 {面索引: [端点坐标]}
    other_edge_coords: dict = field(default_factory=dict)  # 端点另一条边坐标 {面索引: [端点坐标]}
    face: int | None = None  # 端面索引
    face_no: Vector | None = None  # 端面法线
    vert: int | None = None  # 端点顶点索引
    vert_co: Vector | None = None  # 端点顶点坐标


@dataclass
class WedgeData:
    """楔形操作数据(由 _get_wedge_data 构建的选择快照)"""

    mx: Matrix  # 物体世界矩阵
    edge: int | None = None  # 楔形基准边索引
    edge_sharp: bool = False  # 基准边是否锐边
    edge_bw: float = 0  # 基准边倒角权重
    edge_coords: list = field(default_factory=list)  # 基准边端点坐标
    side_faces: list = field(default_factory=list)  # 两侧面索引
    end1: WedgeEndData = field(default_factory=WedgeEndData)  # 端点1
    end2: WedgeEndData = field(default_factory=WedgeEndData)  # 端点2


class WedgeExtrude(Operator, ModalOperatorMixin):
    """
    楔形几何体创建操作器

    功能: 从选中的边创建楔形几何体
    - 支持平面四边形模式
    - 支持翻转楔形方向
    - 支持滑动楔形角点

    要求: 选择一条流形边,至少有一端连接到恰好两条其他边
    """

    bl_idname = "ch.wedge_extrude"
    bl_label = "Wedge Extrude"
    bl_description = "Create Wedge Extrude from Edge Selection"
    bl_options = {'REGISTER', 'UNDO'}

    planar_wedge_quad: BoolProperty(name="Planar", default=True)  # type: ignore
    flip: BoolProperty(name="Flip Direction", default=False)  # type: ignore
    depth_amount: FloatProperty(name="Depth Amount", step=0.1)  # type: ignore
    slide_amount: FloatProperty(name="Slide Amount", step=0.1)  # type: ignore

    index: IntProperty(name="Edge Index", options={'HIDDEN'})  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.active_object:
            return context.mode in ["EDIT_MESH", "OBJECT"]

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.mx = self.act_obj.matrix_world

        self.data: WedgeData = self._get_wedge_data(context, self.index)

        if self.data:
            self.init_mouse_position(event)

            if context.mode == "OBJECT":
                self.mods = [(mod, mod.show_viewport) for mod in self.act_obj.modifiers]

                for mod, _ in self.mods:
                    mod.show_viewport = False

            self.S = Snap(context, include=[self.act_obj])

            self.count = 0

            self.flip = False
            self.can_flip = self.data.end1.face is not None and self.data.end2.face is not None

            self.is_sliding_corner = False
            self.is_setting_depth = False

            self.hitindex = None
            self.hitlocation = None
            self.hitnormal = None

            self.wedge_corner = None
            self.slide_dir = Vector()
            self.slide_amount = 0

            self.edge_intersection = None
            self.end_edge_intersection = None
            self.end_other_edge_intersection = None
            self.end_face_intersection = None

            self.depth_dir = None
            self.depth_amount = 0

            self.wedge_axis_coords = []
            self.wedge_axis_dots_coords = []
            self.wedge_width_coords = []
            self.wedge_length_coords = []
            self.wedge_depth_on_end_face_coords = []
            self.wedge_side_coords = []

            self.init_status(context, func=_draw_wedge_status(self))
            self.init_modal_handlers(context, view3d=True)
            force_ui_update(context)
            return {"RUNNING_MODAL"}

        self.report(
            {"WARNING"},
            "Make sure to select a single, manifold edge, with at least one end leading to exactly 2 other edges, where neither should be parallel to the active edge!",
        )
        return {"CANCELLED"}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {"RUNNING_MODAL"}

        context.area.tag_redraw()

        self.init_mouse_position(event)

        events = ["MOUSEMOVE", "P"]

        if self.can_flip:
            events.append("F")

        if not self.is_setting_depth:
            events.append("S")

        if event.type in events:
            if event.type == "MOUSEMOVE":
                self._handle_mouse_move(context)
            elif event.type == "S" and event.value == "PRESS":
                self._toggle_slide_mode(context)
            elif event.type in ["P", "F"] and event.value == "PRESS":
                self._handle_key_press(context, event)

        elif navigation_passthrough(event, alt=False, wheel=False):
            return {"PASS_THROUGH"}

        elif self.S.hit and self.S.hit_index in self.data.side_faces and event.type == "LEFTMOUSE" and event.value == "PRESS":
            self.is_setting_depth = True
            context.active_object.select_set(True)

        if self.is_setting_depth:
            # 仅以按下事件确认完成: 进入深度阶段的按下在释放前若已有鼠标移动,
            # 其释放同样落在该分支内, 会误判为确认而跳过深度定义
            if self.depth_dir and event.value == "PRESS" and event.type in {"SPACE", "LEFTMOUSE"}:
                self.finish(context)
                return self.execute(context)

            elif event.type == "RIGHTMOUSE" and event.value == "PRESS":
                self._reset_to_area_mode(context)
                return {"RUNNING_MODAL"}

            elif event.type == "ESC" and event.value == "PRESS":
                self.finish(context)
                return {"CANCELLED"}

        else:
            if event.type in {"RIGHTMOUSE", "ESC"} and event.value == "PRESS":
                self.finish(context)
                return {"CANCELLED"}

        return {"RUNNING_MODAL"}

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; 楔形几何完全由模态交互(拾取区域/深度/滑动)派生,
        # 无交互状态时无法重建, 干净取消而非崩溃.
        # 注意: 不可复入 invoke 重建——invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # F9 重做走持久实例, count 已存在, 不受此守卫影响
        if not hasattr(self, "count"):
            self.report({"WARNING"}, "Wedge Extrude requires interactive viewport input and cannot be executed directly")
            return {"CANCELLED"}

        context.evaluated_depsgraph_get()

        if self.count:
            self._get_wedge_area(self.hitindex, self.hitlocation, self.hitnormal)
            self._get_end_area()

        self._create_wedge_geometry(context, self.S.hit_index)

        self.count += 1
        return {"FINISHED"}

    def finish(self, context: Context):
        """完成操作,清理资源"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        self.S.finish()

        if context.mode == "OBJECT":
            for mod, state in self.mods:
                mod.show_viewport = state

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "depth_amount")
        layout.prop(self, "slide_amount")
        layout.prop(self, "planar_wedge_quad")
        layout.active = self.can_flip
        layout.prop(self, "flip")

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        unit_settings = context.scene.unit_settings
        length_unit = unit_settings.length_unit

        unit_symbols = {'METERS': 'm', 'CENTIMETERS': 'cm', 'MILLIMETERS': 'mm', 'MICROMETERS': 'µm', 'FEET': 'ft', 'INCHES': 'in', 'ADAPTIVE': 'm' if unit_settings.system == 'METRIC' else 'ft'}
        unit_symbol = unit_symbols.get(length_unit, 'm')

        if self.is_setting_depth and self.depth_dir:
            depth_text = format_adaptive_precision(self.depth_amount, 1)
            slide_text = format_adaptive_precision(self.slide_amount, 1)
            text = f"Depth: {depth_text} {unit_symbol} | Slide: {slide_text} {unit_symbol}"
        elif self.slide_amount > 0:
            slide_text = format_adaptive_precision(self.slide_amount, 1)
            text = f"Slide: {slide_text} {unit_symbol}"
        else:
            text = ""

        context.area.header_text_set(text)

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图中的预览"""
        if context.area == self.area:
            if self.wedge_corner:
                draw_line(self.wedge_axis_coords, mx=self.mx, color=yellow, width=2, alpha=0.99)

                draw_points(self.wedge_axis_dots_coords, mx=self.mx, color=yellow, size=3)

                draw_line(self.wedge_width_coords, mx=self.mx, color=black, width=1.5, alpha=0.99)

                draw_line(self.wedge_length_coords, mx=self.mx, color=green, alpha=0.99)

                if self.depth_dir:
                    draw_lines(self.wedge_depth_on_end_face_coords, mx=self.mx, color=blue, alpha=0.99)
                    draw_lines(self.wedge_side_coords, mx=self.mx, color=white if self.planar_wedge_quad else red, alpha=0.5)

    def _handle_mouse_move(self, context: Context):
        """处理鼠标移动事件"""
        if self.is_setting_depth:
            self._get_wedge_depth(context)

            if self.depth_dir:
                self._get_end_area()

        elif self.is_sliding_corner:
            self.S.update_hit(self.mouse_region_pos)

            if self.S.hit and self.S.hit_index in self.data.side_faces:
                self._slide_wedge_corner(self.S.hit_location)

        else:
            self.S.update_hit(self.mouse_region_pos)

            if self.S.hit and self.S.hit_index in self.data.side_faces:
                self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)

        self._get_view3d_coords()
        self.update_header_text(context)

    def _toggle_slide_mode(self, context: Context):
        """切换滑动模式"""
        self.is_sliding_corner = not self.is_sliding_corner
        context.active_object.select_set(True)

        if not self.is_sliding_corner:
            self.slide_dir = Vector()
            self.slide_amount = 0

            self.S.update_hit(self.mouse_region_pos)

            if self.S.hit and self.S.hit_index in self.data.side_faces:
                self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)
                self._get_view3d_coords()

        self.update_header_text(context)

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.value != "PRESS":
            return

        key_actions = {
            "P": lambda: setattr(self, "planar_wedge_quad", not self.planar_wedge_quad),
            "F": lambda: self._flip_wedge_direction(context),
        }

        if event.type in key_actions:
            key_actions[event.type]()

        if self.is_setting_depth:
            self._get_wedge_depth(context)

            if self.depth_dir:
                self._get_end_area()

        self._get_view3d_coords()
        force_ui_update(context)

    def _flip_wedge_direction(self, context: Context):
        """翻转楔形方向"""
        self.flip = not self.flip
        self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)
        force_ui_update(context, self.act_obj)

    def _reset_to_area_mode(self, context: Context):
        """重置到区域调整模式"""
        self.is_setting_depth = False
        self.depth_dir = None
        self.is_sliding_corner = False
        self.slide_dir = Vector()
        self.slide_amount = 0
        self.is_statusbar_updated = False

        self.S.update_hit(self.mouse_region_pos)

        if self.S.hit and self.S.hit_index in self.data.side_faces:
            self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)
            self._get_view3d_coords()

        self.update_header_text(context)
        context.active_object.select_set(True)

    def _get_wedge_data(self, context: Context, idx: int | None = None) -> WedgeData | None:
        """
        获取楔形几何体的数据

        Args:
            context: Blender上下文
            idx: 边索引(对象模式下使用)

        Returns:
            WedgeData | None: 楔形数据,无效选择返回None
        """
        active = context.active_object
        owns_bm = context.mode == "OBJECT"

        if context.mode == "OBJECT":
            bm = bmesh.new()
            bm.from_mesh(active.data)
            bm.edges.ensure_lookup_table()
            bw = ensure_default_data_layers(bm)[1]
            edge = bm.edges[idx]
        else:
            bm = bmesh.from_edit_mesh(active.data)

            bw = ensure_default_data_layers(bm)[1]
            selected = [e for e in bm.edges if e.select]

            if len(selected) == 1:
                edge = selected[0]
            else:
                return None

        bm.faces.ensure_lookup_table()
        bm.normal_update()

        data = WedgeData(mx=active.matrix_world)

        side_faces = [f for f in edge.link_faces]

        if len(side_faces) == 2:
            end1_faces = [f for f in edge.verts[0].link_faces if f not in side_faces]
            end2_faces = [f for f in edge.verts[1].link_faces if f not in side_faces]

            end1_face = end1_faces[0] if len(end1_faces) == 1 else None
            end2_face = end2_faces[0] if len(end2_faces) == 1 else None

            if end1_face or end2_face:
                if end1_face:
                    end1_vert = [v for v in edge.verts if v in end1_face.verts][0]

                    end1_edges = [e for e in end1_vert.link_edges if e != edge and e in side_faces[0].edges]
                    end1_other_edges = [e for e in end1_vert.link_edges if e != edge and e not in end1_edges]

                    if not end1_edges or not end1_other_edges:
                        end1_face = None
                    else:
                        end1_edge = end1_edges[0]
                        end1_other_edge = end1_other_edges[0]

                    if end1_face:
                        angle1 = round(get_edge_angle(edge, end1_edge, radians=False), 4)
                        angle2 = round(get_edge_angle(edge, end1_other_edge, radians=False), 4)

                        if angle1 >= 180 or angle2 >= 180:
                            end1_face = None

                if end2_face:
                    end2_vert = [v for v in edge.verts if v in end2_face.verts][0]

                    end2_edges = [e for e in end2_vert.link_edges if e != edge and e in side_faces[0].edges]
                    end2_other_edges = [e for e in end2_vert.link_edges if e != edge and e not in end2_edges]

                    if not end2_edges or not end2_other_edges:
                        end2_face = None
                    else:
                        end2_edge = end2_edges[0]
                        end2_other_edge = end2_other_edges[0]

                    if end2_face:
                        angle1 = round(get_edge_angle(edge, end2_edge, radians=False), 4)
                        angle2 = round(get_edge_angle(edge, end2_other_edge, radians=False), 4)

                        if angle1 >= 180 or angle2 >= 180:
                            end2_face = None

                data.edge = edge.index
                data.edge_sharp = not edge.smooth
                data.edge_bw = edge[bw]
                data.edge_coords = [v.co.copy() for v in edge.verts]

                data.side_faces = [f.index for f in side_faces]

                if end1_face:
                    data.end1.face = end1_face.index
                    data.end1.face_no = end1_face.normal.copy()

                    data.end1.vert = end1_vert.index
                    data.end1.vert_co = end1_vert.co.copy()

                    for idx, face in enumerate(side_faces):
                        if idx == 0:
                            data.end1.edge[face.index] = end1_edge.index
                            data.end1.other_edge[face.index] = end1_other_edge.index

                            data.end1.edge_coords[face.index] = [v.co.copy() for v in end1_edge.verts]
                            data.end1.other_edge_coords[face.index] = [v.co.copy() for v in end1_other_edge.verts]
                        else:
                            data.end1.edge[face.index] = end1_other_edge.index
                            data.end1.other_edge[face.index] = end1_edge.index

                            data.end1.edge_coords[face.index] = [v.co.copy() for v in end1_other_edge.verts]
                            data.end1.other_edge_coords[face.index] = [v.co.copy() for v in end1_edge.verts]

                if end2_face:
                    data.end2.face = end2_face.index
                    data.end2.face_no = end2_face.normal.copy()

                    data.end2.vert = end2_vert.index
                    data.end2.vert_co = end2_vert.co.copy()

                    for idx, face in enumerate(side_faces):
                        if idx == 0:
                            data.end2.edge[face.index] = end2_edge.index
                            data.end2.other_edge[face.index] = end2_other_edge.index

                            data.end2.edge_coords[face.index] = [v.co.copy() for v in end2_edge.verts]
                            data.end2.other_edge_coords[face.index] = [v.co.copy() for v in end2_other_edge.verts]
                        else:
                            data.end2.edge[face.index] = end2_other_edge.index
                            data.end2.other_edge[face.index] = end2_edge.index

                            data.end2.edge_coords[face.index] = [v.co.copy() for v in end2_other_edge.verts]
                            data.end2.other_edge_coords[face.index] = [v.co.copy() for v in end2_edge.verts]

                if owns_bm:
                    bm.free()

                return data

            if owns_bm:
                bm.free()

            return None

        if owns_bm:
            bm.free()

        return None

    def _get_end(self) -> str:
        """获取当前使用的端点名称"""
        if self.can_flip:
            if self.flip:
                return "end2"
            else:
                return "end1"
        elif self.data.end1.face is not None:
            return "end1"
        elif self.data.end2.face is not None:
            return "end2"
        return "end1"

    def _get_wedge_area(self, faceidx: int, location: Vector, normal: Vector):
        """计算楔形区域"""
        mx = self.data.mx
        edge_coords = [mx @ co for co in self.data.edge_coords]

        closest_on_edge, _ = intersect_point_line(location, *edge_coords)

        self.hitindex = faceidx
        self.hitlocation = location
        self.hitnormal = normal

        self.wedge_corner = mx.inverted_safe() @ location
        self.edge_intersection = mx.inverted_safe() @ closest_on_edge

        end_data = getattr(self.data, self._get_end())
        end_edge_coords = [mx @ co for co in end_data.edge_coords[faceidx]]
        edge_dir = edge_coords[1] - edge_coords[0]

        intersection = intersect_line_line(location, location + edge_dir, *end_edge_coords)

        if intersection:
            self.end_edge_intersection = self.mx.inverted_safe() @ intersection[1]

        if self.slide_dir == Vector() and self.end_edge_intersection is not None:
            self.slide_dir = (self.end_edge_intersection - self.wedge_corner).normalized()

    def _slide_wedge_corner(self, location: Vector):
        """滑动楔形角点"""
        wedge_dir_coords = [self.wedge_corner, self.end_edge_intersection]

        closest_on_wedge_dir, _ = intersect_point_line(self.mx.inverted_safe() @ location, *wedge_dir_coords)

        slide_dir = closest_on_wedge_dir - self.wedge_corner

        self.slide_dir = slide_dir.normalized()
        self.slide_amount = slide_dir.length

    def _get_wedge_depth(self, context: Context):
        """计算楔形深度"""
        hitlocation = self.hitlocation + (self.slide_dir * self.slide_amount)

        normal_coords = [hitlocation, hitlocation + self.hitnormal]

        view_origin = region_2d_to_origin_3d(context.region, context.region_data, self.mouse_region_pos)
        view_dir = region_2d_to_vector_3d(context.region, context.region_data, self.mouse_region_pos)

        intersection = intersect_line_line(*normal_coords, view_origin, view_origin + view_dir)

        if not intersection:
            return

        closest_on_normal = intersection[0]

        depth_dir = self.mx.inverted_safe().to_quaternion() @ (closest_on_normal - hitlocation)

        self.depth_dir = depth_dir.normalized()
        self.depth_amount = depth_dir.length

    def _get_end_area(self):
        """计算端面区域"""
        end_data = getattr(self.data, self._get_end())
        end_face_normal = end_data.face_no

        edge_dir = self.data.edge_coords[1] - self.data.edge_coords[0]
        intersector = [
            self.end_edge_intersection + self.depth_dir * self.depth_amount,
            self.end_edge_intersection + self.depth_dir * self.depth_amount + edge_dir,
        ]

        i = intersect_line_plane(*intersector, self.end_edge_intersection, end_face_normal)

        if i:
            self.end_face_intersection = i
            end_other_edge_coords = end_data.other_edge_coords[self.hitindex]

            if self.planar_wedge_quad:
                wedge_corner = self.wedge_corner + self.slide_dir * self.slide_amount

                tri_v1 = (self.edge_intersection - wedge_corner).normalized()
                tri_v2 = (self.end_face_intersection - wedge_corner).normalized()
                tri_no = tri_v1.cross(tri_v2)

                i = intersect_line_plane(*end_other_edge_coords, wedge_corner, tri_no)

                if i:
                    self.end_other_edge_intersection = i
            else:
                end_edge_coords = end_data.edge_coords[self.hitindex]
                end_edge_dir = (end_edge_coords[1] - end_edge_coords[0]).normalized()

                intersection = intersect_line_line(self.end_face_intersection, self.end_face_intersection + end_edge_dir, *end_other_edge_coords)
                i = intersection[1] if intersection else None

                if i:
                    self.end_other_edge_intersection = i

    def _get_view3d_coords(self):
        """获取3D视图坐标"""
        if self.wedge_corner:
            end_data = getattr(self.data, self._get_end())

            wedge_corner = self.wedge_corner + self.slide_dir * self.slide_amount

            self.wedge_axis_coords = [wedge_corner, self.edge_intersection]
            self.wedge_axis_dots_coords = [
                self.wedge_axis_coords[0] + (self.wedge_axis_coords[0] - self.wedge_axis_coords[1]) * 0.2,
                self.wedge_axis_coords[1] - (self.wedge_axis_coords[0] - self.wedge_axis_coords[1]) * 0.2,
            ]

            self.wedge_width_coords = [end_data.vert_co, self.end_edge_intersection]
            self.wedge_length_coords = [wedge_corner, self.end_edge_intersection]

            if self.depth_dir:
                end_vert_co = end_data.vert_co

                self.wedge_depth_on_end_face_coords = [self.end_edge_intersection, self.end_face_intersection]
                self.wedge_depth_on_end_face_coords.extend([end_vert_co, self.end_other_edge_intersection])
                self.wedge_depth_on_end_face_coords.extend([self.end_face_intersection, self.end_other_edge_intersection])

                self.wedge_side_coords = [wedge_corner, self.end_face_intersection]
                self.wedge_side_coords.extend([self.edge_intersection, self.end_other_edge_intersection])

    def _create_wedge_geometry(self, context: Context, faceidx: int):
        """创建楔形几何体"""
        if self.end_other_edge_intersection is None:
            return

        active = context.active_object

        if context.mode == "OBJECT":
            bm = bmesh.new()
            bm.from_mesh(active.data)
        else:
            bm = bmesh.from_edit_mesh(active.data)

        bm.normal_update()
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        bw = ensure_default_data_layers(bm)[1]

        edge = bm.edges[self.data.edge]
        end_data = getattr(self.data, self._get_end())

        side_face = bm.faces[faceidx]
        other_side_face = [bm.faces[idx] for idx in self.data.side_faces if idx != faceidx][0]
        end_face = bm.faces[(end_data.face)]

        side_face_verts = [v for v in side_face.verts]
        other_side_face_verts = [v for v in other_side_face.verts]
        end_face_verts = [v for v in end_face.verts]

        end_vert = bm.verts[end_data.vert]

        idx = side_face_verts.index(end_vert)
        if idx != 0:
            rotate_list(side_face_verts, idx)

        idx = other_side_face_verts.index(end_vert)
        if idx != 0:
            rotate_list(other_side_face_verts, idx)

        idx = end_face_verts.index(end_vert)
        if idx != 0:
            rotate_list(end_face_verts, idx)

        loop = [l for l in edge.link_loops if l.face == side_face][0]
        loop_vert_is_end = loop.vert == end_vert

        edge_vert = bm.verts.new(self.edge_intersection)
        wedge_corner_vert = bm.verts.new(self.wedge_corner + self.slide_dir * self.slide_amount)
        end_edge_vert = bm.verts.new(self.end_edge_intersection)
        end_face_vert = bm.verts.new(self.end_face_intersection)

        for v in side_face.verts:
            v.select_set(True)

        side_face_verts.remove(end_vert)

        if loop_vert_is_end:
            side_face_verts.insert(0, edge_vert)
            side_face_verts.insert(0, wedge_corner_vert)
            side_face_verts.insert(0, end_edge_vert)
        else:
            side_face_verts.insert(0, end_edge_vert)
            side_face_verts.insert(0, wedge_corner_vert)
            side_face_verts.insert(0, edge_vert)

        side_face.hide_set(True)
        new_side_face = bm.faces.new(side_face_verts)
        new_side_face.smooth = side_face.smooth

        for v in other_side_face.verts:
            v.select_set(True)

        if loop_vert_is_end:
            other_side_face_verts.insert(0, edge_vert)
        else:
            other_side_face_verts.insert(1, edge_vert)

        other_side_face.hide_set(True)
        new_other_side_face = bm.faces.new(other_side_face_verts)
        new_other_side_face.smooth = other_side_face.smooth

        end_vert.co = self.end_other_edge_intersection

        for v in end_face.verts:
            v.select_set(True)

        if loop_vert_is_end:
            end_face_verts.insert(1, end_face_vert)
            end_face_verts.insert(2, end_edge_vert)
        else:
            end_face_verts.insert(0, end_face_vert)
            end_face_verts.insert(0, end_edge_vert)

        end_face.hide_set(True)
        new_end_face = bm.faces.new(end_face_verts)
        new_end_face.smooth = end_face.smooth

        if loop_vert_is_end:
            wedge_tri = bm.faces.new([wedge_corner_vert, end_edge_vert, end_face_vert])
            wedge_quad = bm.faces.new([end_vert, edge_vert, wedge_corner_vert, end_face_vert])
        else:
            wedge_tri = bm.faces.new([wedge_corner_vert, end_face_vert, end_edge_vert])
            wedge_quad = bm.faces.new([end_vert, end_face_vert, wedge_corner_vert, edge_vert])

        wedge_tri.smooth = new_side_face.smooth
        wedge_quad.smooth = new_side_face.smooth

        axis_edge = bm.edges.get([edge_vert, wedge_corner_vert])
        length_edge = bm.edges.get([wedge_corner_vert, end_edge_vert])
        wedge_edge1 = bm.edges.get([edge_vert, end_vert])
        wedge_edge2 = bm.edges.get([wedge_corner_vert, end_face_vert])
        end_face_edge1 = bm.edges.get([end_edge_vert, end_face_vert])
        end_face_edge2 = bm.edges.get([end_vert, end_face_vert])

        edges = [axis_edge, length_edge, wedge_edge1, wedge_edge2, end_face_edge1, end_face_edge2]
        connected_edges = [e for v in [edge_vert, end_edge_vert] for e in v.link_edges if e not in edges]

        for e in edges + connected_edges:
            e.smooth = not self.data.edge_sharp
            e[bw] = self.data.edge_bw

        bmesh.ops.delete(bm, geom=[side_face, other_side_face, end_face], context="FACES")

        bm.normal_update()

        if context.mode == "OBJECT":
            bm.to_mesh(active.data)
            bm.free()
            active.select_set(True)
        else:
            bmesh.update_edit_mesh(active.data)


def _draw_wedge_status(op: WedgeExtrude):
    """
    返回 WedgeExtrude 操作的状态栏绘制回调函数

    Args:
        op: WedgeExtrude 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        if not op.is_setting_depth:
            draw_status_item(row, key="LMB", text="Confirm")
            draw_status_item(row, key='MMB', text="Viewport Navigation")
            draw_status_item(row, key="RMB", text="Cancel")

            draw_status_item(row, key="MOVE", text="Define Area", gap=3)
            if op.can_flip:
                draw_status_item(row, key="F", text="Flip")

            draw_status_item(row, active=op.is_sliding_corner, key="S", text="Slide Corner")
        else:
            draw_status_item(row, key="LMB", text="Finish")
            draw_status_item(row, key='MMB', text="Viewport Navigation")
            draw_status_item(row, key="RMB", text="Go Back")

            draw_status_item(row, key="MOVE", text="Define Depth", gap=3)
            draw_status_item(row, active=op.can_flip, key="F", text="Flip")
            draw_status_item(row, active=op.planar_wedge_quad, key="P", text="Planar")

    return draw
