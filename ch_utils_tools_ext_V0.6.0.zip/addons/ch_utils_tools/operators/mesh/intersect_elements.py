"""
元素求交操作器模块

提供以下功能:
- IntersectElements: 切割所有真实相交的选中元素并焊接交点

操作流程:
1. 网格编辑模式下选中需要求交的边(数量不限), 可配合选中面
2. 执行操作, 边边交叉在交点处切分并焊接, 穿透面多边形的边在穿透点处切分
3. 未参与相交的选中边自动取消选择
"""

__all__ = ["IntersectElements"]

import bmesh
from bpy.types import Context, Object, Operator

from ...utils import intersect_elements


# ============================================================
# 元素求交操作器
# ============================================================
class IntersectElements(Operator):
    """
    元素求交

    功能:切割所有真实相交的选中元素并焊接交点
    - 边边: 交点同时落在两边段上的成对边在交点处切分
    - 边面: 穿透面多边形的边在穿透点处切分
    - 交点与既有顶点重合时焊接到该顶点, 不产生重合双顶点
    - 切割出的新顶点置为选中, 未参与相交的选中边自动取消选择

    要求:网格编辑模式下选中至少一条边, 可配合选中面
    """

    bl_idname = "ch.intersect_elements"
    bl_label = "Intersect Elements"
    bl_description = "Cut selected elements at their real intersections and weld the points"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def execute(self, context: Context):
        self.act_obj: Object = context.active_object
        bm = bmesh.from_edit_mesh(self.act_obj.data)

        edges = [edge for edge in bm.edges if edge.select and not edge.hide]
        if not edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}

        faces = [face for face in bm.faces if face.select and not face.hide]

        _count, err = intersect_elements(bm, edges, faces)
        if err:
            self.report({'WARNING'}, err)
            return {'CANCELLED'}

        bmesh.update_edit_mesh(self.act_obj.data)
        return {'FINISHED'}
