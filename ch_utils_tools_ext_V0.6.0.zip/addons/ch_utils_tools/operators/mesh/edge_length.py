"""
边长设置操作器模块

提供以下功能:
- SetEdgeLength: 将选中的独立边实时调整为指定长度

操作流程:
1. 网格编辑模式下选中若干互不共享顶点的边
2. 自定义模式下拖动鼠标或输入数值实时调整长度; W 切换长度模式自动设置
3. B 切换锚定方式, X 重置
4. 左键确认, 右键取消(还原)

快捷键:
- 拖动: 调整目标长度(仅自定义模式, 灵敏度固定)
- 数字键: 精确输入长度(自动切回自定义模式)
- W: 循环长度模式(自定义/最短/最长/平均/活动边), 自动模式驻留;
  数字输入会切回自定义模式
- B: 循环锚定方式(中心对称/固定起点/固定终点)
- X: 重置为初始长度
- 左键/空格/回车: 确认
- 右键/ESC: 取消
- MMB: 旋转视图

注意: Redo 面板拖动长度输入框会自动切回自定义模式(在 execute 内以 _last_length 差分检测;
Operator 属性的 update 回调是延迟触发的, 不能用抑制标志在回调里做状态变更).
"""

__all__ = ["SetEdgeLength"]

import bmesh
from bmesh.types import BMEdge, BMesh, BMVert
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Context, Event, Object, Operator
from mathutils import Vector

from ...items import edge_anchor_mode_items, edge_length_mode_items
from ...mappings import input_mappings, numbers
from ...utils import (
    draw_status_item,
    force_ui_update,
    format_adaptive_precision,
    get_edge_end_coords,
    get_length_unit_symbol,
    ignore_events,
    navigation_passthrough,
    restore_vert_positions,
    snapshot_vert_positions,
    step_enum,
)
from ...utils._constants import MODAL_DRAG_SENSITIVITY
from ...modal_base import ModalOperatorMixin

MIN_LENGTH = 0.001
MODE_LABELS = {identifier: label for identifier, label, *_ in edge_length_mode_items}
ANCHOR_LABELS = {identifier: label for identifier, label, *_ in edge_anchor_mode_items}


def _validate_disjoint_edges(edges: list[BMEdge]) -> str | None:
    """
    校验选中边之间互不共享顶点
    Args:
        edges: 选中边列表
    Returns:
        错误信息, 无共享顶点时返回 None
    """
    seen_verts = set()
    for edge in edges:
        for vert in edge.verts:
            if vert in seen_verts:
                return "Selected edges must not share vertices. Use scaling instead"
            seen_verts.add(vert)
    return None


def _get_active_edge_length(bm) -> float | None:
    """
    从选择历史中取最近选中边的长度
    Args:
        bm: 工作BMesh
    Returns:
        活动边长度, 选择历史中无边时返回 None
    """
    for elem in reversed(bm.select_history):
        if isinstance(elem, BMEdge):
            return elem.calc_length()
    return None


def _get_derived_length(length_mode: str, init_lengths: list[float], active_length: float | None) -> float | None:
    """
    按长度模式从初始长度快照推导目标长度

    基于快照而非当前几何: 连续切换模式时各模式给出不同的确定值
    (若基于当前值, 第一次应用后选中集已归一化, 后续模式推导值全部收敛相同).

    Args:
        length_mode: 长度模式
        init_lengths: invoke 时各选中边的初始长度快照
        active_length: invoke 时活动边的初始长度
    Returns:
        推导出的长度, 自定义模式或无法推导时返回 None
    """
    if length_mode == 'CUSTOM':
        return None
    if length_mode == 'MIN':
        return min(init_lengths)
    if length_mode == 'MAX':
        return max(init_lengths)
    if length_mode == 'AVERAGE':
        return sum(init_lengths) / len(init_lengths)
    return active_length


# ============================================================
# 边长设置操作器
# ============================================================
class SetEdgeLength(Operator, ModalOperatorMixin):
    """
    边长设置

    功能:将选中的独立边实时调整为指定长度
    - 自定义模式拖动/数值调整, 其余模式按选中集自动设置
    - 支持中心对称/固定单端锚定
    - Redo 面板拖动长度自动切回自定义模式

    要求:网格编辑模式下有选中的边, 且边之间互不共享顶点
    """

    bl_idname = "ch.set_edge_length"
    bl_label = "Set Edge Length"
    bl_description = "Set selected edges to a target length"
    bl_options = {'REGISTER', 'UNDO'}

    length: FloatProperty(name="Length", description="Target edge length", default=1.0, min=MIN_LENGTH, precision=5, unit='LENGTH')  # type: ignore
    length_mode: EnumProperty(name="Length Mode", description="How the target length is set", items=edge_length_mode_items, default='CUSTOM')  # type: ignore
    anchor: EnumProperty(name="Anchor", description="Which end stays in place", items=edge_anchor_mode_items, default='CENTER')  # type: ignore

    is_numeric_input: BoolProperty(default=False)  # type: ignore
    numeric_input_amount: StringProperty(default='0')  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def invoke(self, context: Context, event: Event):
        self.act_obj: Object = context.active_object
        self.bm: BMesh = bmesh.from_edit_mesh(self.act_obj.data)

        edges = [edge for edge in self.bm.edges if edge.select]
        if not edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}

        if err := _validate_disjoint_edges(edges):
            self.report({'WARNING'}, err)
            return {'CANCELLED'}

        if any(edge.calc_length() == 0.0 for edge in edges):
            self.report({'WARNING'}, "Selection contains degenerate (zero-length) edges")
            return {'CANCELLED'}

        # 每条边的两端顶点与初始坐标快照(取消还原与基线重放共用); 长度快照供模式推导
        self.edges_data: list[tuple[BMVert, BMVert]] = [(edge.verts[0], edge.verts[1]) for edge in edges]
        self.init_coords: list[Vector] = snapshot_vert_positions([vert for pair in self.edges_data for vert in pair])
        self.init_lengths: list[float] = [edge.calc_length() for edge in edges]
        self.init_active_length: float | None = _get_active_edge_length(self.bm)

        # 初始长度取当前边长(仅作显示基线, 不立即应用到几何)
        init_length = _get_derived_length(self.length_mode, self.init_lengths, self.init_active_length) or _get_active_edge_length(self.bm) or edges[0].calc_length()
        self.length = init_length
        self.init_length: float = init_length
        self._last_length: float = init_length

        if not context.region_data:
            return self.execute(context)

        self.init_mouse_position(event)
        self.drag_base_x: int = event.mouse_x
        self.is_numeric_input = False
        self.numeric_input_amount = '0'

        self.init_status(context, func=_draw_edge_length_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context)
        force_ui_update(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()
        self.init_mouse_position(event)

        return self._handle_modal_events(context, event)

    def _handle_modal_events(self, context: Context, event: Event):
        if self._handle_numeric_input(context, event):
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            self._handle_mouse_move(context, event)
        elif navigation_passthrough(event, alt=True):
            # 视图导航(MMB 旋转等): 事件交给导航系统, 下一个 MOUSEMOVE 重置拖动基线
            self.pass_through = True
            return {'PASS_THROUGH'}
        elif event.value == 'PRESS':
            return self._handle_key_press(context, event)

        return {'RUNNING_MODAL'}

    def _handle_mouse_move(self, context: Context, event: Event):
        """水平拖动调整目标长度(仅自定义模式; 自动模式下鼠标移动不调整, 模式稳定驻留)"""
        if self.pass_through:
            # 视图导航结束: 重置拖动基线, 不更新长度
            self.pass_through = False
            self.drag_base_x = event.mouse_x
            return

        if self.is_numeric_input or self.length_mode != 'CUSTOM':
            return

        self.length = max(MIN_LENGTH, self.length + (event.mouse_x - self.drag_base_x) * max(MIN_LENGTH, self.init_length) * MODAL_DRAG_SENSITIVITY)
        self._last_length = self.length
        self.drag_base_x = event.mouse_x

        self._apply_length()
        self.update_header_text(context)
        force_ui_update(context)

    def _handle_key_press(self, context: Context, event: Event):
        """按键分发: W 循环长度模式, B 循环锚定方式, X 重置, 确认与取消"""
        if event.type == 'W':
            self.length_mode = step_enum(self.length_mode, edge_length_mode_items, 1)
            self.is_numeric_input = False
            if self.length_mode != 'CUSTOM':
                # 自动模式: 立即按初始长度快照推导并应用
                derived = _get_derived_length(self.length_mode, self.init_lengths, self.init_active_length)
                if derived:
                    self.length = max(MIN_LENGTH, derived)
                    self._last_length = self.length
                    self._apply_length()
        elif event.type == 'B':
            self.anchor = step_enum(self.anchor, edge_anchor_mode_items, 1)
            self._apply_length()
        elif event.type == 'X':
            self.length = self.init_length
            self._last_length = self.length
            self._apply_length()
        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'}:
            self.finish(context)
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.is_numeric_input:
                self.is_numeric_input = False
            else:
                self._cancel(context)
                return {'CANCELLED'}

        self.update_header_text(context)
        force_ui_update(context)
        return {'RUNNING_MODAL'}

    def _handle_numeric_input(self, context: Context, event: Event) -> bool:
        """数字键精确输入长度, 返回事件是否已被消费; 自动模式下的输入会切回自定义模式"""
        numeric_events = [*numbers, 'PERIOD', 'NUMPAD_PERIOD', 'BACK_SPACE']

        if not self.is_numeric_input:
            if event.value == 'PRESS' and event.type in [*numbers, 'PERIOD', 'NUMPAD_PERIOD']:
                if self.length_mode != 'CUSTOM':
                    # 手动输入即切回自定义模式(与 Redo 面板行为一致)
                    self.length_mode = 'CUSTOM'
                self.is_numeric_input = True
                self.numeric_input_amount = input_mappings.get(event.type, '.')
                self.update_header_text(context)
                force_ui_update(context)
                return True
            return False

        if event.type not in numeric_events or event.value != 'PRESS':
            return False

        if event.type in numbers:
            self.numeric_input_amount += input_mappings[event.type]
        elif event.type == 'BACK_SPACE':
            if len(self.numeric_input_amount) > 1:
                self.numeric_input_amount = self.numeric_input_amount[:-1]
            else:
                self.is_numeric_input = False
                return True
        elif '.' not in self.numeric_input_amount:
            self.numeric_input_amount += '.'

        try:
            self.length = max(MIN_LENGTH, float(self.numeric_input_amount))
            self._last_length = self.length
        except ValueError:
            return True

        self._apply_length()
        self.update_header_text(context)
        force_ui_update(context)
        return True

    def _apply_length(self):
        """按当前长度与锚定方式从初始坐标重放全部边端点"""
        length = max(MIN_LENGTH, self.length)
        for idx, (v_a, v_b) in enumerate(self.edges_data):
            co_a, co_b = self.init_coords[idx * 2], self.init_coords[idx * 2 + 1]
            (co_new_a, co_new_b), err = get_edge_end_coords(co_a, co_b, length, self.anchor)
            if err:
                # 退化边等异常: 保持原坐标
                continue
            v_a.co = co_new_a
            v_b.co = co_new_b
        self._last_length = length

        bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=False, destructive=False)

    def _cancel(self, context: Context):
        """取消: 还原全部边端点到初始坐标后收敛"""
        flat_verts = [vert for pair in self.edges_data for vert in pair]
        restore_vert_positions(flat_verts, self.init_coords)
        bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=False, destructive=False)
        self.finish(context)

    def execute(self, context: Context):
        # 自包含执行: 从当前选区全新解析, 不依赖 invoke 写入的实例状态 ——
        # F9 重做经撤销系统重建编辑态 BMesh, 模态期持有的顶点引用已失效, 不能复用;
        # 重建式执行同时让脚本直调可用(对齐源算子语义)
        act_obj = context.active_object
        bm = bmesh.from_edit_mesh(act_obj.data)

        edges = [edge for edge in bm.edges if edge.select]
        if not edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}
        if err := _validate_disjoint_edges(edges):
            self.report({'WARNING'}, err)
            return {'CANCELLED'}

        # F9 拖动长度输入框: 与最近应用值不同即视为手动调整, 切回自定义模式
        # (Operator 属性的 update 回调是延迟触发的, 抑制标志方案不可靠, 故用差分检测)
        if getattr(self, "_last_length", None) is not None and abs(self.length - self._last_length) > 1e-9:
            self.length_mode = 'CUSTOM'

        # 非自定义模式按初始长度快照推导(覆盖 F9 下拉切换); 自定义模式用长度输入框的值
        if getattr(self, "init_lengths", None) is not None:
            derived = _get_derived_length(self.length_mode, self.init_lengths, self.init_active_length)
        else:
            derived = _get_derived_length(self.length_mode, [edge.calc_length() for edge in edges], _get_active_edge_length(bm))
        length = max(MIN_LENGTH, derived or self.length)
        if self.length_mode != 'CUSTOM':
            # 推导值回写长度属性, Redo 面板长度栏即显示当前边长
            self.length = length

        base_coords = snapshot_vert_positions([vert for edge in edges for vert in edge.verts])
        for idx, edge in enumerate(edges):
            co_a, co_b = base_coords[idx * 2], base_coords[idx * 2 + 1]
            (co_new_a, co_new_b), err = get_edge_end_coords(co_a, co_b, length, self.anchor)
            if err:
                # 退化边等异常: 保持原坐标
                continue
            edge.verts[0].co = co_new_a
            edge.verts[1].co = co_new_b
        # 同步差分基准: 否则此后每次 execute 都会误判"用户手动调整"而翻转回自定义
        self._last_length = length

        bmesh.update_edit_mesh(act_obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 头部文本 -> 释放资源)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        self.act_obj.update_from_editmode()

    def update_header_text(self, context: Context):
        """更新区域header文本, 只显示数值信息"""
        unit = get_length_unit_symbol(context)
        if self.is_numeric_input:
            text = f"Length: {self.numeric_input_amount} {unit}"
        else:
            text = f"Length: {format_adaptive_precision(self.length, 2)} {unit}"

        context.area.header_text_set(text)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "length_mode")
        layout.prop(self, "length")
        layout.prop(self, "anchor")


def _draw_edge_length_status(op: SetEdgeLength):
    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, active=True, key='W', text=MODE_LABELS[op.length_mode], gap=3)
        draw_status_item(row, active=True, key='B', text=ANCHOR_LABELS[op.anchor])

        draw_status_item(row, key='X', text="Reset")

    return draw
