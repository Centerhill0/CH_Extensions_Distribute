"""
偏移边环操作器模块

提供以下功能:
- OffsetEdges: 对选中的边环做偏移/挤出/移动

操作流程:
1. 网格编辑模式下选中要偏移的边(或面选区的边界)
2. 水平拖动调宽度(MOVE 模式实时位移, 其余模式 GPU 折线预览虚拟偏移环, 挤出另绘原顶点连接线)
3. W 切换几何模式, F/R/M 切换沿面/轨道/镜像(只读重算方向)
4. 左键确认时一次性执行真实拓扑变更, 右键取消还原

快捷键:
- 拖动: 水平调宽度(仅宽度, 深度/角度只在 Redo 面板调节)
- 数字键: 精确输入宽度
- W: 循环几何模式(偏移/挤出/移动)
- F: 切换沿邻接面
- R: 切换内部边轨道
- M: 切换镜像修改器
- X: 重置宽度
- 左键/空格/回车: 确认
- 右键/ESC: 取消
- MMB: 旋转视图

注意: 模态不做角度/深度调整也不做拓扑手术(遵循 chamfer/hole_extrude 的既有模式:
模态期只做宽度坐标重放与 GPU 预览, 真实拓扑变更在确认时一次性执行), 深度/角度仅 F9 路径.
"""

__all__ = ["OffsetEdges"]

from dataclasses import dataclass, field

import bmesh
from bmesh.types import BMEdge, BMesh, BMVert
from math import cos, pi, radians, sin
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Context, Event, Object, Operator
from mathutils import Matrix, Vector

from ...constants import cyan, yellow
from ...items import depth_mode_items, offset_geometry_mode_items
from ...mappings import input_mappings, numbers
from ...utils import (
    collect_loops,
    draw_line,
    draw_lines,
    draw_status_item,
    force_ui_update,
    format_adaptive_precision,
    get_directions,
    get_length_unit_symbol,
    get_mirror_planes,
    get_selection_border_edges,
    get_vert_mirror_pairs,
    ignore_events,
    navigation_passthrough,
    restore_vert_positions,
    snapshot_vert_positions,
    step_enum,
)
from ...utils._constants import MODAL_DRAG_SENSITIVITY
from ...modal_base import ModalOperatorMixin

UPWARD = Vector((1.0, 1.0, 1.0)).normalized()  # 统一环朝向的参考上方向
NORMAL_FALLBACK = Vector((0.0, 0.0, 1.0))  # 环法线无法计算时的回退法线
FLAT_FACE_THRESHOLD = radians(0.05)  # 两邻接面视为共面的法线夹角阈值
DEFAULT_WIDTH = 0.2  # 宽度属性默认值与 X 重置值共用
MODE_LABELS = {identifier: label for identifier, label, *_ in offset_geometry_mode_items}


@dataclass
class OffsetLoopData:
    """偏移边环载荷(方向求解结果与基线快照)"""

    lp: list  # [v, e, v, ..., v] 交错环序列(重算方向时复用)
    edges_orig: list[BMEdge]  # 环原始边
    orig_verts: list[BMVert]  # 环原始顶点(闭合环不含重复尾顶点)
    orig_base_coords: list[Vector]  # 原顶点基线坐标(取消还原与预览共用)
    directions: list[tuple[Vector, Vector]]  # 与原顶点对齐的 (宽度方向, 深度方向)
    is_closed: bool  # 是否闭合环
    preview_coords: list[Vector] = field(default_factory=list)  # 虚拟偏移环坐标(GPU 预览)


def _extrude_edges(bm: bmesh.types.BMesh, edges_orig: list[BMEdge]) -> dict:
    """
    挤出原始边并归类返回几何
    Args:
        bm: 工作BMesh
        edges_orig: 要挤出的边列表
    Returns:
        含 verts(副本顶点)/edges(副本边)/faces(新面)/side(侧边) 的字典
    """
    extruded = bmesh.ops.extrude_edge_only(bm, edges=edges_orig)['geom']
    co_edges = co_faces = len(edges_orig)
    co_verts = len(extruded) - co_edges - co_faces

    verts = set(extruded[:co_verts])
    edges = set(extruded[co_verts : co_verts + co_edges])
    faces = set(extruded[co_verts + co_edges :])

    return {'verts': verts, 'edges': edges, 'faces': faces, 'side': {e for v in verts for e in v.link_edges if e not in edges}}


def _collect_moved_verts(orig_verts: list[BMVert], geom: dict) -> list[BMVert]:
    """
    按原顶点顺序定位各自的挤出副本顶点(经侧边连接)
    Args:
        orig_verts: 环原顶点列表
        geom: _extrude_edges 返回的几何字典
    Returns:
        与原顶点顺序对齐的副本顶点列表
    """
    moved = []
    for vert in orig_verts:
        for edge in vert.link_edges:
            if edge in geom['side']:
                moved.append(edge.other_vert(vert))
                break
    return moved


def _clean_selection(bm: bmesh.types.BMesh, geometry_mode: str, edges_orig: list[BMEdge], geom: dict | None):
    """
    重置选择状态; offset 模式额外删除侧边与新生成的面
    Args:
        bm: 工作BMesh
        geometry_mode: 几何模式
        edges_orig: 环原始边
        geom: 挤出几何字典, MOVE 模式为 None
    """
    for face in bm.faces:
        face.select = False

    if geom:
        for edge in geom['edges']:
            edge.select = True
        if geometry_mode == 'OFFSET':
            bmesh.ops.delete(bm, geom=list(geom['side']) + list(geom['faces']), context='EDGES')
    else:
        for edge in edges_orig:
            edge.select = True


# ============================================================
# 偏移边环操作器
# ============================================================
class OffsetEdges(Operator, ModalOperatorMixin):
    """
    偏移边环

    功能:对选中的边环做偏移/挤出/移动
    - 宽度与深度双参数控制位移
    - 支持沿邻接面/内部边轨道/镜像修改器
    - 模态期只做坐标重放与 GPU 预览, 真实拓扑变更在确认时一次性执行

    要求:网格编辑模式下有选中的边, 且边环互不重叠
    """

    bl_idname = "ch.offset_edges"
    bl_label = "Offset Edges"
    bl_description = "Offset / extrude / move selected edge loops"
    bl_options = {'REGISTER', 'UNDO'}

    geometry_mode: EnumProperty(name="Mode", description="How to apply the offset", items=offset_geometry_mode_items, default='OFFSET')  # type: ignore
    width: FloatProperty(name="Width", description="Offset width", default=DEFAULT_WIDTH, precision=4, step=1)  # type: ignore
    flip_width: BoolProperty(name="Flip Width", description="Flip width direction", default=False)  # type: ignore
    depth: FloatProperty(name="Depth", description="Offset depth", default=0.0, precision=4, step=1)  # type: ignore
    flip_depth: BoolProperty(name="Flip Depth", description="Flip depth direction", default=False)  # type: ignore
    depth_mode: EnumProperty(name="Depth Mode", description="How to derive the depth", items=depth_mode_items, default='DEPTH')  # type: ignore
    angle: FloatProperty(name="Angle", description="Angle between width and depth", default=0.0, precision=3, step=0.1, min=-2 * pi, max=2 * pi, subtype='ANGLE')  # type: ignore
    flip_angle: BoolProperty(name="Flip Angle", description="Flip angle direction", default=False)  # type: ignore
    follow_face: BoolProperty(name="Follow Face", description="Offset along faces around", default=False)  # type: ignore
    edge_rail: BoolProperty(name="Inner Edge Rail", description="Align vertices along inner edges", default=False)  # type: ignore
    edge_rail_only_end: BoolProperty(name="Edge Rail Only End", description="Apply edge rail to end verts only", default=False)  # type: ignore
    use_mirror: BoolProperty(name="Mirror Modifier", description="Take into account of Mirror modifier", default=False)  # type: ignore
    threshold: FloatProperty(name="Flat Face Threshold", description="If difference of angle between two adjacent faces is below this value, those faces are regarded as flat", default=FLAT_FACE_THRESHOLD, precision=5, step=1e-4, subtype='ANGLE', options={'HIDDEN'})  # type: ignore

    is_numeric_input: BoolProperty(default=False)  # type: ignore
    numeric_input_amount: StringProperty(default='0')  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def _resolve_mirror_edges(self, border_edges: set[BMEdge], obj: Object) -> tuple[dict | None, set[BMEdge]]:
        """
        按镜像开关过滤整体落在镜像平面上的边

        Args:
            border_edges: 选区边界边集合
            obj: 目标网格物体
        Returns:
            (顶点到镜像平面的映射, 过滤后的边集合); 过滤后为空集时报错提示
        """
        if not self.use_mirror:
            return None, border_edges

        mirror_pairs, set_edges = get_vert_mirror_pairs(border_edges, get_mirror_planes(obj))
        if not set_edges:
            self.report({'WARNING'}, "All selected edges lie on mirror planes. Disable Mirror Modifier or select other edges")
        return mirror_pairs, set_edges

    def _build_loops(self, set_edges: set[BMEdge], mirror_pairs: dict | None) -> list[OffsetLoopData] | None:
        """
        求解边环方向并构建载荷列表

        Args:
            set_edges: 参与偏移的边集合
            mirror_pairs: 顶点到镜像平面的映射(无则 None)
        Returns:
            载荷列表; 边环重叠无法串接时返回 None
        """
        loops = collect_loops(set_edges)
        if loops is None:
            return None

        loops_data = []
        for lp in loops:
            verts, directions = get_directions(
                lp,
                UPWARD,
                NORMAL_FALLBACK,
                mirror_pairs,
                follow_face=self.follow_face,
                edge_rail=self.edge_rail,
                edge_rail_only_end=self.edge_rail_only_end,
                threshold=self.threshold,
            )
            if not verts:
                continue
            loops_data.append(
                OffsetLoopData(
                    lp=lp,
                    edges_orig=lp[1::2],
                    orig_verts=verts,
                    orig_base_coords=snapshot_vert_positions(verts),
                    directions=directions,
                    is_closed=lp[0] is lp[-1],
                )
            )
        return loops_data

    def invoke(self, context: Context, event: Event):
        self.act_obj: Object = context.active_object
        self.act_mx: Matrix = self.act_obj.matrix_world
        self.bm: BMesh = bmesh.from_edit_mesh(self.act_obj.data)

        self.border_edges: set[BMEdge] = get_selection_border_edges(self.bm)
        if not self.border_edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}

        # 面选中时自动沿邻接面(沿用源算子行为); 模态不做角度调整, 强制深度模式
        if any(face.select for face in self.bm.faces):
            self.follow_face = True
        self.depth_mode = 'DEPTH'

        self.mirror_pairs: dict | None
        self.set_edges: set[BMEdge]
        self.mirror_pairs, self.set_edges = self._resolve_mirror_edges(self.border_edges, self.act_obj)
        if not self.set_edges:
            return {'CANCELLED'}

        self.loops_data: list[OffsetLoopData] = self._build_loops(self.set_edges, self.mirror_pairs)
        if self.loops_data is None:
            self.report({'WARNING'}, "Overlap detected. Select non-overlapping edge loops")
            return {'CANCELLED'}

        if not context.region_data:
            return self.execute(context)

        self.init_mouse_position(event)
        self.drag_base_x: int = event.mouse_x
        self.is_numeric_input = False
        self.numeric_input_amount = '0'

        self.init_status(context, func=_draw_offset_edges_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context, view3d=True)
        force_ui_update(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()
        self.init_mouse_position(event)

        return self._handle_modal_events(context, event)

    def _handle_modal_events(self, context: Context, event: Event):
        if self._handle_numeric_input(context, event):
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            self._handle_mouse_move(context, event)
        elif navigation_passthrough(event, alt=True):
            # 视图导航(MMB 旋转等): 事件交给导航系统, 下一个 MOUSEMOVE 重置拖动基线
            self.pass_through = True
            return {'PASS_THROUGH'}
        elif event.value == 'PRESS':
            return self._handle_key_press(context, event)

        return {'RUNNING_MODAL'}

    def _handle_mouse_move(self, context: Context, event: Event):
        """水平拖动调宽度(模态只调宽度, 灵敏度固定)"""
        if self.pass_through:
            # 视图导航结束: 重置拖动基线, 不更新参数
            self.pass_through = False
            self.drag_base_x = event.mouse_x
            return

        if self.is_numeric_input:
            return

        self.width += (event.mouse_x - self.drag_base_x) * MODAL_DRAG_SENSITIVITY
        self.drag_base_x = event.mouse_x

        self._apply_preview()
        self.update_header_text(context)
        force_ui_update(context)

    def _handle_key_press(self, context: Context, event: Event):
        """按键分发: W 切几何模式, F/R/M 切选项, X 重置宽度, 确认与取消"""
        if event.type == 'W':
            self.geometry_mode = step_enum(self.geometry_mode, offset_geometry_mode_items, 1)
        elif event.type in {'F', 'R', 'M'}:
            if event.type == 'F':
                self.follow_face = not self.follow_face
            elif event.type == 'R':
                self.edge_rail = not self.edge_rail
            else:
                self.use_mirror = not self.use_mirror
            self._recompute_directions()
        elif event.type == 'X':
            self._reset_params()
        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'}:
            self._apply_final()
            self.finish(context)
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.is_numeric_input:
                self.is_numeric_input = False
            else:
                self._cancel(context)
                return {'CANCELLED'}

        self._apply_preview()
        self.update_header_text(context)
        force_ui_update(context)
        return {'RUNNING_MODAL'}

    def _handle_numeric_input(self, context: Context, event: Event) -> bool:
        """数字键精确输入宽度, 返回事件是否已被消费"""
        numeric_events = [*numbers, 'PERIOD', 'NUMPAD_PERIOD', 'BACK_SPACE']

        if not self.is_numeric_input:
            if event.value == 'PRESS' and event.type in [*numbers, 'PERIOD', 'NUMPAD_PERIOD']:
                self.is_numeric_input = True
                self.numeric_input_amount = input_mappings.get(event.type, '.')
                self.update_header_text(context)
                force_ui_update(context)
                return True
            return False

        if event.type not in numeric_events or event.value != 'PRESS':
            return False

        if event.type in numbers:
            self.numeric_input_amount += input_mappings[event.type]
        elif event.type == 'BACK_SPACE':
            if len(self.numeric_input_amount) > 1:
                self.numeric_input_amount = self.numeric_input_amount[:-1]
            else:
                self.is_numeric_input = False
                return True
        elif '.' not in self.numeric_input_amount:
            self.numeric_input_amount += '.'

        try:
            self.width = float(self.numeric_input_amount)
        except ValueError:
            return True

        self._apply_preview()
        self.update_header_text(context)
        force_ui_update(context)
        return True

    def _reset_params(self):
        """重置宽度参数(深度/角度不在模态调整, 不动)"""
        self.width = DEFAULT_WIDTH
        self.flip_width = False

    def _get_width_depth(self) -> tuple[float, float]:
        """按深度模式与翻转开关换算实际的宽度/深度标量"""
        if self.depth_mode == 'ANGLE':
            angle = -self.angle if self.flip_angle else self.angle
            width = self.width * cos(angle)
            depth = self.width * sin(angle)
        else:
            width, depth = self.width, self.depth

        return (-width if self.flip_width else width, -depth if self.flip_depth else depth)

    def _recompute_directions(self):
        """F/R/M 选项变化重算方向(只读, 不动拓扑)

        先还原原顶点到基线, 再按当前选项重新过滤镜像边集并重建环(与 invoke 同一条管线):
        否则"整体落在镜像平面上的边不参与偏移"这条源规则只在 invoke 时 M 已开启的情况下生效,
        模态中按 M 打开镜像会把这些边仍留在环里参与偏移.
        """
        for loop in self.loops_data:
            restore_vert_positions(loop.orig_verts, loop.orig_base_coords)

        self.mirror_pairs, self.set_edges = self._resolve_mirror_edges(self.border_edges, self.act_obj)
        if not self.set_edges:
            self.loops_data = []
            return

        loops_data = self._build_loops(self.set_edges, self.mirror_pairs)
        if loops_data is None:
            # 镜像过滤只可能减少边, 不会新增重叠; 保留原载荷以防万一
            return
        self.loops_data = loops_data

    def _apply_preview(self):
        """按当前参数应用预览: MOVE 模式实时位移原顶点, 其余模式还原原顶点并记录虚拟偏移环坐标供 GPU 绘制"""
        width, depth = self._get_width_depth()

        for loop in self.loops_data:
            loop.preview_coords = [base_co + width * vec_width + depth * vec_depth for base_co, (vec_width, vec_depth) in zip(loop.orig_base_coords, loop.directions)]
            if self.geometry_mode == 'MOVE':
                for vert, co in zip(loop.orig_verts, loop.preview_coords):
                    vert.co = co
            else:
                # 离开 MOVE 模式时还原原顶点到初始位置, 保证偏移始终基于初始网格
                restore_vert_positions(loop.orig_verts, loop.orig_base_coords)

        # 顶点坐标被写(位移或还原), 重算法线保证预览着色正确
        self.bm.normal_update()
        bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=False, destructive=False)

    def _apply_final(self):
        """确认: 一次性执行真实拓扑变更(挤出/清理)并把副本顶点写到预览位置; MOVE 模式顶点已在位"""
        if self.geometry_mode == 'MOVE':
            return

        width, depth = self._get_width_depth()
        for loop in self.loops_data:
            geom = _extrude_edges(self.bm, loop.edges_orig)
            moved_verts = _collect_moved_verts(loop.orig_verts, geom)
            _clean_selection(self.bm, self.geometry_mode, loop.edges_orig, geom)

            for vert, base_co, (vec_width, vec_depth) in zip(moved_verts, loop.orig_base_coords, loop.directions):
                vert.co = base_co + width * vec_width + depth * vec_depth

        # 顶点位移/挤出后重算法线(着色正确), 再以拓扑变更参数同步
        self.bm.normal_update()
        # 拓扑已变更(挤出/删除): destructive=True 通知依赖系统失效, loop_triangles=True 重算三角化
        # ——否则绘制系统 extract_tris 用陈旧三角化索引新几何, ACCESS_VIOLATION 崩溃
        bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=True, destructive=True)

    def _cancel(self, context: Context):
        """取消: MOVE 模式还原原顶点坐标并恢复选择后收敛; 其余模式模态期未动网格"""
        if self.geometry_mode == 'MOVE':
            for loop in self.loops_data:
                restore_vert_positions(loop.orig_verts, loop.orig_base_coords)
                for edge in loop.edges_orig:
                    edge.select = True
            # 还原后重算法线
            self.bm.normal_update()
            bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=False, destructive=False)

        self.finish(context)

    def execute(self, context: Context):
        # 自包含执行: 从当前选区全新解析并构建, 不依赖 invoke 写入的实例状态 ——
        # F9 重做经撤销系统重建编辑态 BMesh, 模态期持有的顶点引用已失效, 不能复用;
        # 重建式执行同时让脚本直调可用(对齐源算子语义)
        act_obj = context.active_object
        bm = bmesh.from_edit_mesh(act_obj.data)

        border_edges = get_selection_border_edges(bm)
        if not border_edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}

        mirror_pairs, set_edges = self._resolve_mirror_edges(border_edges, act_obj)
        if not set_edges:
            return {'CANCELLED'}

        loops_data = self._build_loops(set_edges, mirror_pairs)
        if loops_data is None:
            self.report({'WARNING'}, "Overlap detected. Select non-overlapping edge loops")
            return {'CANCELLED'}

        width, depth = self._get_width_depth()
        for loop in loops_data:
            if self.geometry_mode == 'MOVE':
                moved_verts, base_coords = loop.orig_verts, loop.orig_base_coords
                geom = None
            else:
                geom = _extrude_edges(bm, loop.edges_orig)
                moved_verts = _collect_moved_verts(loop.orig_verts, geom)
                base_coords = snapshot_vert_positions(moved_verts)
                _clean_selection(bm, self.geometry_mode, loop.edges_orig, geom)

            for vert, base_co, (vec_width, vec_depth) in zip(moved_verts, base_coords, loop.directions):
                vert.co = base_co + width * vec_width + depth * vec_depth

        # 顶点位移/挤出后重算法线(着色正确), 再以拓扑变更参数同步(见 _apply_final 注释)
        bm.normal_update()
        bmesh.update_edit_mesh(act_obj.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 头部文本 -> 释放资源)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        self.act_obj.update_from_editmode()

    def update_header_text(self, context: Context):
        """更新区域header文本, 只显示数值信息"""
        if self.is_numeric_input:
            text = f"Width: {self.numeric_input_amount} {get_length_unit_symbol(context)}"
        else:
            text = f"Width: {format_adaptive_precision(self.width, 2)} {get_length_unit_symbol(context)}"

        context.area.header_text_set(text)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "geometry_mode")

        row = layout.row(align=True)
        row.prop(self, "width")
        row.prop(self, "flip_width", icon='ARROW_LEFTRIGHT', icon_only=True)

        row = layout.row(align=True)
        row.prop(self, "depth_mode", expand=True)
        row = layout.row(align=True)
        if self.depth_mode == 'ANGLE':
            row.prop(self, "angle")
            row.prop(self, "flip_angle", icon='ARROW_LEFTRIGHT', icon_only=True)
        else:
            row.prop(self, "depth")
            row.prop(self, "flip_depth", icon='ARROW_LEFTRIGHT', icon_only=True)

        layout.prop(self, "follow_face")
        row = layout.row()
        row.prop(self, "edge_rail")
        if self.edge_rail:
            row.prop(self, "edge_rail_only_end", text="Only End", toggle=True)
        layout.prop(self, "use_mirror")
        if self.follow_face:
            layout.prop(self, "threshold")

    def draw_VIEW3D(self, context: Context):
        """GPU 预览: OFFSET 青色折线, EXTRUDE 黄色折线 + 原顶点连接线(表现挤出壁), 模式一目了然"""
        if self.pass_through or context.area != self.area:
            return
        if self.geometry_mode == 'MOVE':
            return

        for loop in self.loops_data:
            coords = loop.preview_coords
            if len(coords) < 2:
                continue
            if loop.is_closed:
                indices = [(idx, (idx + 1) % len(coords)) for idx in range(len(coords))]
            else:
                indices = [(idx, idx + 1) for idx in range(len(coords) - 1)]

            color = yellow if self.geometry_mode == 'EXTRUDE' else cyan
            draw_line(coords, indices=indices, mx=self.act_mx, color=color, alpha=0.8, xray=True)

            if self.geometry_mode == 'EXTRUDE':
                connectors = [co for base_co, preview_co in zip(loop.orig_base_coords, coords) for co in (base_co, preview_co)]
                draw_lines(connectors, mx=self.act_mx, color=cyan, alpha=0.5, width=2, xray=True)


def _draw_offset_edges_status(op: OffsetEdges):
    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, active=True, key='W', text=MODE_LABELS[op.geometry_mode], gap=3)

        draw_status_item(row, active=op.follow_face, key='F', text="Follow Face")
        draw_status_item(row, active=op.edge_rail, key='R', text="Inner Edge Rail")
        draw_status_item(row, active=op.use_mirror, key='M', text="Mirror")

        draw_status_item(row, key='X', text="Reset")

    return draw
