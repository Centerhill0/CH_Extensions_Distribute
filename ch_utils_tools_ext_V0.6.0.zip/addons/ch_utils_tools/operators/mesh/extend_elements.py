"""
元素延伸操作器模块

提供以下功能:
- ExtendElements: 将两条边或一条边与一个面延伸相接

操作流程:
1. 网格编辑模式下选中两条边(边边延伸), 或一个面与一条和它分离的边(边面延伸)
2. 执行操作, 自动判定延伸形态并完成连接
3. 边边延伸自动识别 V 形(两边向交点延伸)与 T 形(一边延伸搭接另一边);
   已相交的形态不予处理, 交由元素求交工具切割
"""

__all__ = ["ExtendElements"]

import bmesh
from bmesh.types import BMEdge, BMFace, BMesh
from bpy.types import Context, Object, Operator

from ...utils import extend_edge_to_face, extend_edges_to_intersection


# ============================================================
# 元素延伸操作器
# ============================================================
class ExtendElements(Operator):
    """
    元素延伸

    功能:将两条边或一条边与一个面延伸相接
    - 边边: 自动识别 V 形(两边向交点延伸)与 T 形(一边延伸搭接另一边)
    - 边面: 将边沿自身方向延伸到面所在平面
    - 已相交的形态不予处理, 交由元素求交工具切割
    - 延伸新建的顶点与边置为选中, 原边选区保持

    要求:网格编辑模式下选中两条边, 或一个面与一条和它分离的边
    """

    bl_idname = "ch.extend_elements"
    bl_label = "Extend Elements"
    bl_description = "Extend two edges, or an edge to a face, until they meet"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def execute(self, context: Context):
        self.act_obj: Object = context.active_object
        bm = bmesh.from_edit_mesh(self.act_obj.data)

        if err := self._dispatch_extend(bm):
            self.report({'WARNING'}, err)
            return {'CANCELLED'}

        bmesh.update_edit_mesh(self.act_obj.data)
        return {'FINISHED'}

    def _dispatch_extend(self, bm: BMesh) -> str | None:
        """
        按选区形态分派延伸处理

        Args:
            bm: 工作BMesh
        Returns:
            错误信息, 成功时返回 None
        """
        faces = [face for face in bm.faces if face.select and not face.hide]

        if len(faces) == 1:
            edge = self._get_off_face_edge(bm, faces[0])
            if not edge:
                return "Select one face and one edge detached from it"
            _result, err = extend_edge_to_face(bm, edge, faces[0])
            return err

        if not faces:
            edges = [edge for edge in bm.edges if edge.select and not edge.hide]
            if len(edges) != 2:
                return "Select two edges, or one edge and one face"
            _result, err = extend_edges_to_intersection(bm, *edges)
            return err

        return "Select two edges, or one edge and one face"

    def _get_off_face_edge(self, bm: BMesh, face: BMFace) -> BMEdge | None:
        """
        获取与选中面分离的选中边(面外选中顶点恰为该边两端)

        以选中顶点差集探测, 兼容面/边选择模式下的选法.

        Args:
            bm: 工作BMesh
            face: 选中的目标面
        Returns:
            分离边, 选区不符时返回 None
        """
        face_verts = set(face.verts)
        outer_verts = [vert for vert in bm.verts if vert.select and not vert.hide and vert not in face_verts]
        if len(outer_verts) != 2:
            return None
        return bm.edges.get(outer_verts)
