"""
展平操作模块

将选中的面或顶点沿边或法线方向展平.

操作流程:
1. 选择面模式: 选择多个面, 活动面作为参考平面
2. 选择顶点模式: 选择3个顶点, 确定参考平面
3. 执行后可在 redo 面板(F9)切换展平模式(沿边/沿法线)与是否溶解面

支持的展平模式:
- EDGE: 沿边方向展平
- NORMAL: 沿法线方向展平
"""

__all__ = ["Flatten"]

import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Context, Operator

from .....common.i18n.i18n import report

from ...items import flatten_mode_items
from ...utils import flatten_faces, flatten_verts


class Flatten(Operator):
    """
    展平操作器

    功能: 将选中的面或顶点沿边或法线方向展平
    - 面模式: 选择多个面, 活动面作为参考平面
    - 顶点模式: 选择3个顶点确定参考平面

    要求:
    - 面模式: 面选择模式下选择多个面
    - 顶点模式: 选择3个共面的顶点
    """

    bl_idname = "ch.flatten"
    bl_label = "Flatten"
    bl_description = "Flatten Polygon(s) along Edges or Normal"
    bl_options = {'REGISTER', 'UNDO'}

    flatten_mode: EnumProperty(name="Mode", items=flatten_mode_items, default="EDGE")  # type: ignore
    dissolve: BoolProperty(name="Dissolve Edges", default=False)  # type: ignore
    face_mode: BoolProperty(name="Face Mode", default=False)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != "EDIT_MESH":
            return

        bm = bmesh.from_edit_mesh(context.active_object.data)
        select_mode = tuple(context.scene.tool_settings.mesh_select_mode)

        if select_mode == (False, False, True):
            return bm.faces.active and any(f.select for f in bm.faces)

        verts = [v for v in bm.verts if v.select]
        if len(verts) != 3:
            return

        vert_faces = [{f for f in v.link_faces} for v in verts if v.link_faces]
        if len(vert_faces) != 3:
            return

        return len(vert_faces[0].intersection(vert_faces[1], vert_faces[2])) == 1

    def execute(self, context: Context):
        act_obj = context.active_object

        try:
            self._main(act_obj)
        except Exception as e:
            # _main 出错时可能停在 OBJECT 模式, 先还原编辑模式再报错
            if context.mode == "OBJECT":
                bpy.ops.object.mode_set(mode="EDIT")

            self.report({'ERROR'}, report("Flatten error: {}").format(e))
            return {'CANCELLED'}

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "flatten_mode", expand=True)

        if self.face_mode:
            layout.prop(self, "dissolve")

    def _main(self, act_obj):
        """
        执行展平操作的核心逻辑

        Args:
            act_obj: 活动对象

        Returns:
            操作是否成功
        """
        bpy.ops.object.mode_set(mode="OBJECT")

        bm = bmesh.new()
        bm.from_mesh(act_obj.data)

        bm.normal_update()
        bm.verts.ensure_lookup_table()

        verts = [v for v in bm.verts if v.select]
        edges = [e for e in bm.edges if e.select]
        faces = [f for f in bm.faces if f.select]

        if len(faces) > 1:
            self.face_mode = True
            flatten_faces(bm, edges, self.flatten_mode, self.dissolve)
        else:
            self.face_mode = False
            _coords, err = flatten_verts(verts, self.flatten_mode)
            if err:
                # 交由 execute 统一 report(还原编辑模式后提示)
                raise ValueError(err)

        bm.normal_update()
        bm.to_mesh(act_obj.data)
        bm.free()

        bpy.ops.object.mode_set(mode="EDIT")
        return True
