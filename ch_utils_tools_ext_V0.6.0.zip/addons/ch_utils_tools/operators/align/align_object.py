"""
物体对齐操作器模块

提供以下功能:
- ObjectAlignByView: 按视图方向对齐选中物体
"""

__all__ = ["ObjectAlignByView"]

from bpy.types import Operator, Context, Event, Object
from bpy.props import EnumProperty
from mathutils import Matrix

from .....common.i18n.i18n import report, tip

from ...utils import MeasureObjects, MeasureObject, get_evaluated_objects, get_evaluated_object, get_view_aligned_axes, measure_objects_evaluated
from ...items import align_direction_items, space_items


# ============================================================
# 按视图对齐物体操作器
# ============================================================
class ObjectAlignByView(Operator):
    """
    按视图方向对齐物体
    功能: 将选中的物体按视图方向对齐
    - 支持上下左右边界对齐
    - 支持中心对齐 (水平/垂直)
    - 支持全部对齐到中心点
    - Alt: 活动物体局部空间对齐
    - Ctrl: 游标空间对齐
    - Shift: 对齐到活动物体 (仅水平/垂直对齐时有效)
    要求: 至少选中 2 个物体
    """

    bl_idname = "ch.align_object_by_view"
    bl_label = "Align Objects"
    bl_description = "Align Objects to View Axis\n+Alt: Active Object Local Space\n+Ctrl: Cursor Space\n+Shift: Align to Active Object"
    bl_options = {'REGISTER', 'UNDO'}

    align_direction: EnumProperty(
        name="Align Direction",
        description="Choose the axis to align the object",
        items=align_direction_items,
        default='Align_Center',
    )  # type: ignore
    align_space: EnumProperty(
        name="Align Space",
        description="Align in World, Local or Cursor Space",
        items=space_items,
        default='WORLD',
    )  # type: ignore

    # 修饰键缺省为 False: execute 可能未经 invoke 直接执行(脚本调用 / F9 重做), 此时按无修饰键处理
    use_align_to_active: bool = False  # invoke 中按 Shift 键设置

    @classmethod
    def poll(cls, context: Context):
        return len(context.selected_objects) >= 2

    @classmethod
    def description(cls, context: Context, properties):
        if properties.align_direction == 'Align_Center':
            return tip("Align to center\n+Shift: Align to active object position")
        if properties.align_direction in {'Align_Center_H', 'Align_Center_V'}:
            return tip("World Space Align\n+Alt: Active object local space\n+Ctrl: Cursor space\n+Shift: Align to active object")
        return tip("World Space Align\n+Alt: Active object local space\n+Ctrl: Cursor space")

    def invoke(self, context: Context, event: Event):
        if event.alt and event.ctrl:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        self.use_align_to_active = event.shift and self.align_direction in {'Align_Center_H', 'Align_Center_V', 'Align_Center'}

        if self.align_direction == 'Align_Center':
            self.align_space = 'WORLD'
        else:
            if event.ctrl:
                self.align_space = 'CURSOR'
            elif event.alt:
                self.align_space = 'LOCAL'
            else:
                self.align_space = 'WORLD'

        return self.execute(context)

    def execute(self, context: Context):
        context.view_layer.update()

        act_obj = context.active_object

        if self.align_direction == 'Align_Center':
            if self.use_align_to_active:
                if act_obj is None:
                    self.report({'ERROR'}, "No Active Object!")
                    return {'CANCELLED'}
                target_pos = act_obj.location
                objs = list(context.selected_objects)
                for obj in objs:
                    obj.location = target_pos
            else:
                target_measure, objs = measure_objects_evaluated(context, context.selected_objects)
                target_pos = target_measure.center_pos
                for obj in objs:
                    obj.location = target_pos

            context.view_layer.update()
            self.report({'INFO'}, report("Aligned {} objects").format(len(objs)))
            return {'FINISHED'}

        if self.align_space == 'LOCAL':
            if act_obj is None:
                self.report({'ERROR'}, "No Active Object!")
                return {'CANCELLED'}
            space_mx = act_obj.matrix_world
        elif self.align_space == 'CURSOR':
            space_mx = context.scene.cursor.matrix
        else:
            space_mx = Matrix()

        inv_space_mx = space_mx.inverted_safe()

        axis_right_idx, axis_up_idx, is_flip_right, is_flip_up = get_view_aligned_axes(context, mx=space_mx)

        dep_objs = get_evaluated_objects(context, context.selected_objects)
        objs = [context.scene.objects[obj.name] for obj in dep_objs]

        def mx_of(dep_obj: Object) -> Matrix:
            """目标空间下的测量矩阵"""
            return inv_space_mx @ dep_obj.matrix_world if self.align_space != 'WORLD' else dep_obj.matrix_world

        measure_objs = [MeasureObject(dep_obj, mx_of(dep_obj)) for dep_obj in dep_objs]

        if self.use_align_to_active:
            if act_obj is None:
                self.report({'ERROR'}, "No Active Object!")
                return {'CANCELLED'}
            act_idx = next((i for i, obj in enumerate(dep_objs) if obj.name == act_obj.name), None)
            if act_idx is not None:
                target_measure = measure_objs[act_idx]
                objs = [obj for i, obj in enumerate(objs) if i != act_idx]
                align_measure_objs = [m for i, m in enumerate(measure_objs) if i != act_idx]
            else:
                target_measure = MeasureObject(get_evaluated_object(context, act_obj), mx_of(act_obj))
                align_measure_objs = measure_objs
        else:
            target_measure = MeasureObjects(dep_objs, [mx_of(obj) for obj in dep_objs])
            align_measure_objs = measure_objs

        global_center = target_measure.center_pos

        match self.align_direction:
            case 'Align_Right' | 'Align_Left' | 'Align_Up' | 'Align_Down':
                global_min = target_measure.min_pos
                global_max = target_measure.max_pos

                if self.align_direction in {'Align_Right', 'Align_Left'}:
                    align_dir = is_flip_right if self.align_direction == 'Align_Right' else not is_flip_right
                    axis_idx = axis_right_idx
                else:
                    align_dir = is_flip_up if self.align_direction == 'Align_Up' else not is_flip_up
                    axis_idx = axis_up_idx

                global_value = global_min[axis_idx] if align_dir else global_max[axis_idx]

                for obj, m_obj in zip(objs, align_measure_objs):
                    if self.align_space != 'WORLD':
                        obj_space_pos = inv_space_mx @ obj.location
                        local_min = m_obj.min_pos
                        local_max = m_obj.max_pos
                        local_value = local_min[axis_idx] if align_dir else local_max[axis_idx]
                        obj_space_pos[axis_idx] = global_value - (local_value - obj_space_pos[axis_idx])
                        obj.location = space_mx @ obj_space_pos
                    else:
                        local_value = m_obj.min_pos[axis_idx] if align_dir else m_obj.max_pos[axis_idx]
                        obj.location[axis_idx] += global_value - local_value

            case 'Align_Center_H' | 'Align_Center_V':
                axis_idx = axis_right_idx if self.align_direction == 'Align_Center_H' else axis_up_idx
                for obj in objs:
                    if self.align_space != 'WORLD':
                        obj_space_pos = inv_space_mx @ obj.location
                        obj_space_pos[axis_idx] = global_center[axis_idx]
                        obj.location = space_mx @ obj_space_pos
                    else:
                        obj.location[axis_idx] = global_center[axis_idx]

        context.view_layer.update()

        self.report({'INFO'}, report("Aligned {} objects").format(len(objs)))
        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.3

        # 3x3 方向网格
        grid = layout.grid_flow(row_major=True, columns=3, even_columns=True, even_rows=True, align=True)
        grid.separator()
        grid.prop_enum(self, "align_direction", "Align_Up")
        grid.separator()
        grid.prop_enum(self, "align_direction", "Align_Left")
        grid.prop_enum(self, "align_direction", "Align_Center")
        grid.prop_enum(self, "align_direction", "Align_Right")
        grid.separator()
        grid.prop_enum(self, "align_direction", "Align_Down")
        grid.separator()

        # 水平/垂直中心对齐按钮
        row = layout.row(align=True)
        row.prop_enum(self, "align_direction", "Align_Center_V")
        row.prop_enum(self, "align_direction", "Align_Center_H")
