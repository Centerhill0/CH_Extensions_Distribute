"""
网格对齐操作器模块

提供以下功能:
- AlignEditMesh: 编辑模式下顶点对齐
- AlignObjectToVert: 将对象对齐到顶点
- AlignObjectToEdge: 将对象对齐到边
- AlignObjectToFace: 将对象对齐到面
"""

__all__ = [
    "AlignEditMesh",
    "AlignObjectToVert",
    "AlignObjectToEdge",
    "AlignObjectToFace",
]

import bmesh

from abc import abstractmethod
from mathutils import Matrix, Vector
from bmesh.types import BMVert
from bpy.props import EnumProperty, BoolProperty
from bpy.types import Operator, Context, Event, Object
from mathutils.geometry import intersect_point_line, intersect_line_plane

from .....common.i18n.i18n import tip

from ...items import (
    align_type_items,
    sorted_axis_items,
    align_direction_items,
    space_items,
    face_snap_mode_items,
    edge_snap_mode_items,
)
from ...utils import (
    MeasureIsland,
    MeasureIslands,
    get_view_aligned_axes,
    get_lerp_position,
    get_edge_direction,
    get_rotation_difference_matrix,
    transform_normal_to_world,
    get_active_element_from_bmesh,
    is_valid_mesh_edit_selection,
    transform_local_to_space,
    transform_space_to_local,
    get_space_transform_matrix,
)


# ============================================================
# 编辑模式网格对齐操作器
# ============================================================
class AlignEditMesh(Operator):
    """
    编辑模式下顶点对齐操作器
    功能:将选中的顶点对齐到指定轴向
    - 默认:局部空间对齐
    - Alt:世界空间对齐
    - Ctrl:游标空间对齐
    - Shift: 对齐到活动顶点(仅 Align_Center_H/V)
    """

    bl_idname = "ch.align_edit_mesh"
    bl_label = "Align Edit Mesh"
    bl_description = "Align Selected Vertices to Axis\n+Alt: World Space\n+Ctrl: Cursor Space\n+Shift: Align to Active Vertex"
    bl_options = {'REGISTER', 'UNDO'}

    align_axis: EnumProperty(name="Align Axis", items=sorted_axis_items, description="Align on the X, Y or Z Axis", default='0')  # type: ignore
    align_space: EnumProperty(name="Align Space", items=space_items, description="Align in Local, World or Cursor Space", default='LOCAL')  # type: ignore
    align_direction: EnumProperty(name="Align Direction", items=align_direction_items[:6], description="Align Direction", default='Align_Right')  # type: ignore
    align_type: EnumProperty(name="Align Type", items=align_type_items, description="Align to Average, Zero or Cursor", default='AVERAGE')  # type: ignore
    is_individual: BoolProperty(name="Individual Origins", description="Align each island individually", default=False)  # type: ignore

    # 修饰键缺省为 False: execute 可能未经 invoke 直接执行(脚本调用 / F9 重做), 此时按无修饰键处理
    is_shift: bool = False  # invoke 中按 Shift 键设置

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return get_active_element_from_bmesh(context, bm)

    @classmethod
    def description(cls, context: Context, properties):
        if properties.align_direction in {'Align_Center_H', 'Align_Center_V'}:
            return tip("Local Space Align\n+Alt: World Space Align\n+Ctrl: Cursor Space Align\n+Shift: Align to active vert")
        return tip("Local Space Align\n+Alt: World Space Align\n+Ctrl: Cursor Space Align")

    def invoke(self, context: Context, event: Event):
        # Shift键:对齐到活动顶点(仅对Align_Center_H/V有效)
        self.is_shift = event.shift

        # Alt和Ctrl不能同时按下 (无论Shift是否按下)
        if event.alt and event.ctrl:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        # 根据修饰键设置对齐空间 (Shift可以和Alt或Ctrl组合)
        if event.ctrl:
            self.align_space = 'CURSOR'
        elif event.alt:
            self.align_space = 'WORLD'
        else:
            self.align_space = 'LOCAL'

        self.act_obj = context.active_object

        # 获取视图对齐的坐标轴信息(invoke 用于定轴, execute 对齐时共用翻转标记)
        self._update_view_axes(context)

        # 根据对齐方向设置轴向
        match self.align_direction:
            case 'Align_Right' | 'Align_Left' | 'Align_Center_H':
                self.align_axis = str(self.axis_right_idx)
            case 'Align_Up' | 'Align_Down' | 'Align_Center_V':
                self.align_axis = str(self.axis_up_idx)

        # 检查是否为"各自原点"模式
        self.is_individual = context.scene.tool_settings.transform_pivot_point == 'INDIVIDUAL_ORIGINS'

        return self.execute(context)

    def _update_view_axes(self, context: Context) -> None:
        """计算视图对齐轴与翻转标记(上下文派生, invoke 与 execute 各自现算)"""
        self.axis_right_idx, self.axis_up_idx, self.is_flip_right, self.is_flip_up = get_view_aligned_axes(
            context,
            mx=get_space_transform_matrix(context, self.act_obj, self.align_space),
        )

    def execute(self, context: Context):
        # 上下文派生状态现算, 保证 execute 可未经 invoke 直接执行(脚本调用 / F9 重做)
        self.act_obj = context.active_object
        self._update_view_axes(context)

        self.bm = bmesh.from_edit_mesh(self.act_obj.data)
        self.bm.verts.ensure_lookup_table()
        axis = int(self.align_axis)
        transform_mx = transform_local_to_space(context, self.act_obj, self.align_space)
        inverted_transform_mx = transform_space_to_local(context, self.act_obj, self.align_space)
        all_islands = MeasureIslands(self.act_obj, mx=transform_mx)

        # 获取活动顶点位置(Shift键对齐用)
        self._active_vert_pos = None
        if self.is_shift and self.align_direction in {'Align_Center_H', 'Align_Center_V'}:
            act_vert = self._get_active_vert()
            if act_vert:
                self._active_vert_pos = transform_mx @ act_vert.co
            else:
                self.report({'ERROR'}, "No Active Vert!")
                return {'CANCELLED'}

        # 根据模式处理顶点
        if self.is_individual:
            # 各自原点模式:每个孤岛独立对齐
            for island in all_islands.islands:
                selected_verts = [self.bm.verts[idx] for idx in island.selected_vertices_idx]
                for vert in selected_verts:
                    self._align_vertex(context, vert, island, axis, transform_mx, inverted_transform_mx)
        else:
            # 整体模式:所有选中顶点一起对齐
            selected_verts = [self.bm.verts[idx] for idx in all_islands.selected_vertices_idx]
            for vert in selected_verts:
                self._align_vertex(context, vert, all_islands, axis, transform_mx, inverted_transform_mx)

        self.bm.normal_update()
        bmesh.update_edit_mesh(self.act_obj.data)

        return {'FINISHED'}

    def _get_active_vert(self) -> BMVert | None:
        """获取活动顶点 (从 select_history 中获取)"""
        active = self.bm.select_history.active
        if isinstance(active, BMVert) and active.select:
            return active
        return None

    def _align_vertex(self, context: Context, vert: BMVert, island: MeasureIsland | MeasureIslands, axis: int, mx: Matrix, inv_mx: Matrix) -> None:
        """
        对齐单个顶点
        Args:
            context: Blender上下文
            vert: 要对齐的顶点
            island: 顶点所属的孤岛测量数据
            axis: 对齐轴向索引
            mx: 局部到目标空间的变换矩阵
            inv_mx: 目标空间到局部的逆变换矩阵
        """
        # 将顶点坐标转换到目标空间
        new_co = mx @ vert.co

        match self.align_direction:
            case 'Align_Right' | 'Align_Left' | 'Align_Up' | 'Align_Down':
                # 边界对齐模式
                if self.align_direction in {'Align_Right', 'Align_Left'}:
                    is_flip = self.is_flip_right if self.align_direction == 'Align_Right' else not self.is_flip_right
                else:
                    is_flip = self.is_flip_up if self.align_direction == 'Align_Up' else not self.is_flip_up
                new_co[axis] = island.min_pos[axis] if is_flip else island.max_pos[axis]

            case 'Align_Center_H' | 'Align_Center_V':
                # 中心对齐模式
                if self.is_shift and self._active_vert_pos is not None:
                    # Shift键:对齐到活动顶点
                    new_co[axis] = self._active_vert_pos[axis]
                else:
                    match self.align_type:
                        case 'AVERAGE':
                            new_co[axis] = island.center_pos[axis]
                        case 'ZERO':
                            new_co[axis] = 0
                        case 'CURSOR':
                            # 根据空间类型处理游标位置
                            match self.align_space:
                                case 'LOCAL':
                                    cur_loc = context.scene.cursor.location
                                    cur_loc_local = self.act_obj.matrix_world.inverted_safe() @ cur_loc
                                    new_co[axis] = cur_loc_local[axis]
                                case 'WORLD':
                                    new_co[axis] = context.scene.cursor.location[axis]
                                case 'CURSOR':
                                    new_co[axis] = 0

        # 转换回局部空间并更新顶点坐标
        vert.co = inv_mx @ new_co

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "is_individual")
        row = layout.row()
        row.prop(self, "align_axis", expand=True)

        layout.prop(self, "align_space", expand=True)
        layout.prop(self, "align_direction")

        if self.align_direction in {'Align_Center_H', 'Align_Center_V'}:
            layout.prop(self, "align_type", expand=True)


# ============================================================
# 对齐对象到元素的 Mixin 类
# ============================================================
class AlignObjectMixin:
    """
    对齐对象到元素的 Mixin 类
    提供共享功能:
    - poll 方法:检查选择的有效性
    - 工具方法:获取选中对象,安全获取活动对象
    子类需要实现:
    - element_type: 类属性,指定元素类型 ('verts', 'edges', 'faces')
    - get_element_info(): 获取元素信息的方法
    - execute(): 具体的对齐逻辑
    子类各自实现 invoke(修饰键映射 snap_mode / 直接执行) 与 Redo 面板 draw
    """

    element_type: str = ''

    @classmethod
    def poll(cls, context: Context):
        """
        检查操作器是否可用
        Returns:
            bool: 是否有有效的元素选择
        """
        if not cls.element_type:
            raise NotImplementedError("子类必须定义 element_type 类属性")
        return is_valid_mesh_edit_selection(context, cls.element_type)

    def get_selected_objects(self, context: Context, exclude_obj: Object = None) -> list[Object]:
        """
        获取选中的网格对象(排除活动对象)
        Args:
            context: Blender上下文
            exclude_obj: 要排除的对象,默认为活动对象
        Returns:
            选中的网格对象列表
        """
        exclude = exclude_obj or context.active_object
        return [obj for obj in context.selected_objects if obj.type == 'MESH' and obj != exclude]

    def get_active_object_safe(self, context: Context) -> Object | None:
        """
        安全获取活动对象,通过 view_layer 获取活动对象,避免 execute 中对象引用失效的问题
        Returns:
            活动对象或 None
        """
        return context.view_layer.objects.active

    @abstractmethod
    def get_element_info(self, obj: Object, *args, **kwargs):
        """
        获取对象的元素信息(抽象方法)
        Args:
            obj: 要获取信息的对象
        Returns:
            元素信息元组或 None
        """
        pass


# ============================================================
# 对齐对象到顶点
# ============================================================
class AlignObjectToVert(AlignObjectMixin, Operator):
    """
    将对象对齐到顶点
    功能:将选中对象的位置对齐到活动对象的选中顶点
    要求:活动对象有且仅有一个选中的顶点
    """

    bl_idname = "ch.align_object_to_vert"
    bl_label = "Align Object to Vert"
    bl_description = "Align one or more objects to vertex in active object"
    bl_options = {'REGISTER', 'UNDO'}

    element_type = 'verts'

    def invoke(self, context: Context, event: Event) -> set:
        """顶点对齐不需要修饰键处理,直接执行"""
        return self.execute(context)

    def execute(self, context: Context) -> set:
        """执行顶点对齐操作"""
        act_obj = context.active_object
        sel_objs = self.get_selected_objects(context, act_obj)

        # 获取活动对象的选中顶点(返回坐标快照而非 BMVert 引用:
        # 循环内对其他网格 from_edit_mesh 会使先前捕获的 BMVert 失效)
        act_obj_vert_co = self.get_element_info(act_obj)
        if not act_obj_vert_co:
            self.report({'ERROR'}, "Active object must have only one selected vertex")
            return {'CANCELLED'}

        act_obj_mx = act_obj.matrix_world

        # 对齐每个选中对象
        for obj in sel_objs:
            obj_vert_co = self.get_element_info(obj)
            if not obj_vert_co:
                continue

            obj_mx = obj.matrix_world
            # 计算平移矩阵:活动顶点世界位置 - 选中顶点世界位置
            translation = Matrix.Translation(act_obj_mx @ act_obj_vert_co - obj_mx @ obj_vert_co)
            obj.matrix_world = translation @ obj_mx

        context.view_layer.update()
        return {'FINISHED'}

    def get_element_info(self, obj: Object) -> Vector | None:
        """
        获取对象的选中顶点
        Args:
            obj: 目标对象
        Returns:
            选中顶点的局部坐标快照(仅一个)或 None
        """
        bm = bmesh.from_edit_mesh(obj.data)
        selected_verts = [v for v in bm.verts if v.select]
        if len(selected_verts) != 1:
            return None
        return selected_verts[0].co.copy()


# ============================================================
# 对齐对象到边
# ============================================================
class AlignObjectToEdge(AlignObjectMixin, Operator):
    """
    将对象对齐到边
    功能:将选中对象的旋转对齐到活动对象的选中边
    - 默认:仅旋转对齐
    - Alt:吸附到最近(边所在直线上)
    - Ctrl:吸附到边的中点
    要求:活动对象有且仅有一条选中的边
    """

    bl_idname = "ch.align_object_to_edge"
    bl_label = "Align Object to Edge"
    bl_description = "Align one or more objects to edge in active object\n" "+Alt: Snap objects to edge by proximity\n" "+Ctrl: Snap objects to edge by midpoint"
    bl_options = {'REGISTER', 'UNDO'}

    element_type = 'edges'

    # RNA 属性: Redo(F9) 面板可显示与持久化, invoke 中按修饰键写入, 面板中可继续调整
    snap_mode: EnumProperty(
        name="Snap Mode",
        description="Align and snap object(s) to the edge",
        items=edge_snap_mode_items,
        default='ALIGN',
    )  # type: ignore

    def invoke(self, context: Context, event: Event) -> set:
        """按修饰键映射吸附模式(Alt+Ctrl 组合无效)后直接执行, 活动对象由 execute 现取"""
        if event.alt and event.ctrl:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}
        if event.alt:
            self.snap_mode = 'PROXIMITY'
        elif event.ctrl:
            self.snap_mode = 'CENTER'
        else:
            self.snap_mode = 'ALIGN'
        # 新一次手动执行清空原始矩阵记录(Redo 重执行不经过 invoke, 保留记录供还原)
        self._orig_mxs: dict[str, Matrix] = {}
        return self.execute(context)

    def execute(self, context: Context) -> set:
        """执行边对齐操作"""
        # 活动对象必须现取: 缓存 Object 引用会在 Redo 重执行时指向已释放的 StructRNA
        act_obj = self.get_active_object_safe(context)
        if act_obj is None:
            self.report({'ERROR'}, "No Active Object!")
            return {'CANCELLED'}

        sel_objs = self.get_selected_objects(context, act_obj)

        # 获取活动边信息
        act_obj_info = self.get_element_info(act_obj)
        if not act_obj_info:
            self.report({'ERROR'}, "Active object must have one selected edge")
            return {'CANCELLED'}

        act_obj_edge_vec, act_obj_edge_mid_loc, act_obj_edge_coords = act_obj_info
        act_obj_edge_mid_world = act_obj.matrix_world @ act_obj_edge_mid_loc

        # Redo 重执行确定性: Blender 不会自动还原本算子对对象矩阵的修改,
        # 首次执行记录各对象原始矩阵(按名字缓存, 字符串可安全跨 Redo),
        # Redo 重算前先还原, 保证面板调整后从原始状态重算
        orig_mxs: dict[str, Matrix] | None = getattr(self, "_orig_mxs", None)
        if orig_mxs is None:
            orig_mxs = {}
            self._orig_mxs = orig_mxs

        # 对齐每个选中对象
        for obj in sel_objs:
            if obj.name not in orig_mxs:
                orig_mxs[obj.name] = obj.matrix_world.copy()
            else:
                obj.matrix_world = orig_mxs[obj.name]

            result = self.get_element_info(obj)
            if not result:
                continue

            obj_edge_vec, obj_edge_mid_loc, _ = result

            # 确保边向量方向一致
            if obj_edge_vec.dot(act_obj_edge_vec) < 0:
                obj_edge_vec.negate()

            # 计算旋转矩阵并应用(围绕对象原点旋转)
            loc, *_ = obj.matrix_world.decompose()
            rot_mx = get_rotation_difference_matrix(obj_edge_vec, act_obj_edge_vec)
            trans_mx = Matrix.Translation(loc)
            obj.matrix_world = trans_mx @ rot_mx.to_4x4() @ trans_mx.inverted() @ obj.matrix_world

            # 处理吸附
            if self.snap_mode != 'ALIGN':
                obj_edge_mid_world = obj.matrix_world @ obj_edge_mid_loc

                if self.snap_mode == 'CENTER':
                    # 吸附到边中点
                    trans_mx = Matrix.Translation(act_obj_edge_mid_world - obj_edge_mid_world)
                else:
                    # 吸附到最近(边所在直线上的最近点)
                    closest_co, _ = intersect_point_line(obj_edge_mid_world, *act_obj_edge_coords)
                    trans_mx = Matrix.Translation(closest_co - obj_edge_mid_world)
                obj.matrix_world = trans_mx @ obj.matrix_world

        context.view_layer.update()
        return {'FINISHED'}

    def draw(self, context: Context) -> None:
        """绘制操作器面板"""
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "snap_mode", expand=True)

    def get_element_info(self, obj: Object) -> tuple[Vector, Vector, list[Vector]] | None:
        """
        获取对象的边信息
        Args:
            obj: 目标对象
        Returns:
            tuple: (边向量, 边中点局部坐标, 边两端点世界坐标列表) 或 None
        """
        bm = bmesh.from_edit_mesh(obj.data)
        selected_edges = [e for e in bm.edges if e.select]
        if len(selected_edges) != 1:
            return None

        edge = selected_edges[0]
        # 边向量(世界空间)
        edge_vec = obj.matrix_world.to_3x3() @ get_edge_direction(*edge.verts)
        # 边中点(局部空间)
        edge_mid_local = get_lerp_position(*edge.verts)
        # 边端点坐标(世界空间)
        edge_coords = [obj.matrix_world @ v.co for v in edge.verts]
        return edge_vec, edge_mid_local, edge_coords


# ============================================================
# 对齐对象到面
# ============================================================
class AlignObjectToFace(AlignObjectMixin, Operator):
    """
    将对象对齐到面
    功能:将选中对象的旋转对齐到活动对象的选中面
    - 默认:仅旋转对齐
    - Alt:按距离吸附到面上
    - Ctrl:吸附到面的中点
    要求:活动对象有且仅有一个选中的面
    """

    bl_idname = "ch.align_object_to_face"
    bl_label = "Align Object to Face"
    bl_description = "Align one or more objects to face in active object\n" "+Alt: Snap objects to face by proximity\n" "+Ctrl: Snap objects to face by midpoint"
    bl_options = {'REGISTER', 'UNDO'}

    element_type = 'faces'

    is_flip: BoolProperty(
        name="Flip Object(s)",
        description="Flip the direction of the object(s) to align to the face",
        default=False,
    )  # type: ignore

    # RNA 属性: Redo(F9) 面板可显示与持久化, invoke 中按修饰键写入, 面板中可继续调整
    snap_mode: EnumProperty(
        name="Snap Mode",
        description="Align and snap object(s) to the face",
        items=face_snap_mode_items,
        default='ALIGN',
    )  # type: ignore

    def invoke(self, context: Context, event: Event) -> set:
        """按修饰键映射吸附模式(Alt+Ctrl 组合无效)后直接执行, 活动对象由 execute 现取"""
        if event.alt and event.ctrl:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}
        if event.alt:
            self.snap_mode = 'PROXIMITY'
        elif event.ctrl:
            self.snap_mode = 'CENTER'
        else:
            self.snap_mode = 'ALIGN'
        # 新一次手动执行清空原始矩阵记录(Redo 重执行不经过 invoke, 保留记录供还原)
        self._orig_mxs: dict[str, Matrix] = {}
        return self.execute(context)

    def execute(self, context: Context) -> set:
        """执行面对齐操作"""
        # 活动对象必须现取: 缓存 Object 引用会在 Redo 重执行时指向已释放的 StructRNA
        # (ReferenceError), 经 view_layer 现查则始终有效
        act_obj = self.get_active_object_safe(context)
        if act_obj is None:
            self.report({'ERROR'}, "No Active Object!")
            return {'CANCELLED'}

        # 获取活动面信息(世界空间)
        act_obj_info = self.get_element_info(act_obj, is_world_space=True)
        if not act_obj_info:
            self.report({'ERROR'}, "Active object must have one selected face")
            return {'CANCELLED'}

        act_obj_face_normal_world, act_obj_face_mid_world = act_obj_info
        sel_objs = self.get_selected_objects(context, act_obj)

        # Redo 重执行确定性: Blender 不会自动还原本算子对对象矩阵的修改,
        # 首次执行记录各对象原始矩阵(按名字缓存, 字符串可安全跨 Redo),
        # Redo 重算前先还原, 保证面板调整后从原始状态重算
        orig_mxs: dict[str, Matrix] | None = getattr(self, "_orig_mxs", None)
        if orig_mxs is None:
            orig_mxs = {}
            self._orig_mxs = orig_mxs

        # 对齐每个选中对象
        for obj in sel_objs:
            if obj.name not in orig_mxs:
                orig_mxs[obj.name] = obj.matrix_world.copy()
            else:
                obj.matrix_world = orig_mxs[obj.name]

            result = self.get_element_info(obj)
            if not result:
                continue

            obj_face_normal_local, obj_face_mid_local = result
            obj_face_normal_world = transform_normal_to_world(obj_face_normal_local, obj.matrix_world)

            # 处理翻转
            if self.is_flip:
                obj_face_normal_world.negate()

            # 计算旋转矩阵并应用
            loc, rot, sca = obj.matrix_world.decompose()
            rot_mx = get_rotation_difference_matrix(obj_face_normal_world, act_obj_face_normal_world)
            new_rot = rot_mx @ rot.to_matrix()
            obj.matrix_world = Matrix.LocRotScale(loc, new_rot, sca)

            # 处理吸附
            if self.snap_mode != 'ALIGN':
                obj_face_mid_world = obj.matrix_world @ obj_face_mid_local

                if self.snap_mode == 'CENTER':
                    # 吸附到面中心
                    trans_mx = Matrix.Translation(act_obj_face_mid_world - obj_face_mid_world)
                else:
                    # 吸附到最近(面所在平面上的最近点)
                    obj_face_normal_world = transform_normal_to_world(obj_face_normal_local, obj.matrix_world)
                    if self.is_flip:
                        obj_face_normal_world.negate()
                    closest_co = intersect_line_plane(obj_face_mid_world, obj_face_mid_world + obj_face_normal_world, act_obj_face_mid_world, act_obj_face_normal_world)
                    trans_mx = Matrix.Translation(closest_co - obj_face_mid_world)
                obj.matrix_world = trans_mx @ obj.matrix_world

        return {'FINISHED'}

    def get_element_info(self, obj: Object, is_world_space: bool = False) -> tuple[Vector, Vector] | None:
        """
        获取对象的面信息
        Args:
            obj: 目标对象
            is_world_space: 是否返回世界空间坐标
        Returns:
            tuple: (面法向量, 面中心坐标) 或 None
        """
        bm = bmesh.from_edit_mesh(obj.data)
        selected_faces = [f for f in bm.faces if f.select]
        if len(selected_faces) != 1:
            return None

        face = selected_faces[0]
        if is_world_space:
            # 世界空间
            face_normal_world = transform_normal_to_world(face.normal, obj.matrix_world)
            face_mid_world = obj.matrix_world @ face.calc_center_median()
            return face_normal_world, face_mid_world
        else:
            # 局部空间
            return face.normal, face.calc_center_median()

    def draw(self, context: Context) -> None:
        """绘制操作器面板"""
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "is_flip")
        layout.prop(self, "snap_mode", expand=True)
