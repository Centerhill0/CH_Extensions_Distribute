"""
曲线点滑动操作器模块

提供以下功能:
- CurvePointSlide: 沿相邻线段滑动单个曲线点

操作流程:
1. 选择单个曲线点
2. 拖动鼠标沿相邻线段滑动点
3. 确认完成

支持的曲线类型:
- POLY: 多边形曲线
- NURBS: NURBS曲线

快捷键:
- 鼠标移动: 沿线段滑动点
- Alt: 锁定当前滑动方向
- Shift: 精细调整
- 左键/空格: 确认操作
- 右键/ESC: 取消操作
"""

__all__ = ["CurvePointSlide"]

from bpy.types import Operator, Context, Event
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d, location_3d_to_region_2d
from mathutils.geometry import intersect_line_line

from ...constants import green, yellow
from ...utils import (
    get_curve_data,
    get_curve_selection_indices,
    get_zoom_factor,
    ignore_events,
    navigation_passthrough,
    draw_status_item,
    draw_point,
    draw_line,
    draw_vector,
)
from ...modal_base import ModalOperatorMixin


class CurvePointSlide(Operator, ModalOperatorMixin):
    """
    曲线点滑动

    功能:沿相邻线段滑动单个曲线点
    - 支持POLY和NURBS曲线类型
    - 支持锁定滑动方向
    - 支持精细调整

    要求:曲线编辑模式下选中单个点
    """

    bl_idname = "ch.curve_point_slide"
    bl_label = "Curve Point Slide"
    bl_description = "Slide single curve point on its connected segments"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode == 'EDIT_CURVE':
            act_obj = context.active_object
            if act_obj.type == 'CURVE':
                curve = act_obj.data
                data = get_curve_data(curve)
                selection = get_curve_selection_indices(data)

                if len(selection) == 1:
                    sidx, pidx = selection.pop()
                    spline_len = len(curve.splines[sidx].points)
                    return spline_len > 1

        return False

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_curve = self.act_obj.data
        self.mx = self.act_obj.matrix_world

        self.is_shift = False
        self.is_alt = False

        self.slide_data = self._get_slide_data(context)
        if not self.slide_data['point_co_2d']:
            self.report({'WARNING'}, "Selected point is out of the current view!")
            return {'CANCELLED'}

        self.zoom = get_zoom_factor(context, self.slide_data['point_co'])

        self.init_mouse_position(event)
        self.mouse_offset = self.slide_data['point_co_2d'] - self.mouse_region_pos

        self.init_status(context, func=draw_curve_slide_status(self))
        self.init_modal_handlers(context, view3d=True)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        self.is_shift = event.shift
        self.is_alt = event.alt

        if self.is_alt and self.slide_data['slide_segment'] and not self.slide_data['locked']:
            self.slide_data['locked'] = self.slide_data['slide_segment']
            seg = self.slide_data['slide_segment']
            self.slide_data['locked_coords'] = [self.slide_data['point_co'], self.slide_data['point_co'] + self.slide_data['point_co'] - self.slide_data[f'{seg}_point_co']]

        elif self.slide_data['locked'] and not self.is_alt:
            self.slide_data['locked'] = None
            self.slide_data['locked_coords'] = []

        if event.type == 'MOUSEMOVE':
            self.init_mouse_position(event)
            self._slide_point(context)

        # alt=False: Alt 是本算子的锁定修饰键, Alt+点击需留给确认与取消, 不可穿透给视图导航
        elif navigation_passthrough(event, alt=False, wheel=False):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context)
            self.slide_data['point'].co.xyz = self.slide_data['point_co_local']
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图预览"""
        if context.area != self.area:
            return

        data = self.slide_data

        draw_point(data['point_co'], size=4, alpha=0.3)

        if data['prev_point_co']:
            draw_line([data['point_co'], data['prev_point_co']], alpha=0.2)

        if data['next_point_co']:
            draw_line([data['point_co'], data['next_point_co']], alpha=0.2)

        seg = data['slide_segment']
        locked = data['locked']

        if seg:
            length = self.zoom * 20 * context.preferences.system.ui_scale

            edge_dir = (data[f'{locked if locked else seg}_point_co'] - data['point_co']).normalized()
            draw_vector(edge_dir * length, origin=data['point_co'], color=green, width=2, alpha=0.75, fade=True)

            if data['prev_dir'] and data['next_dir']:
                if locked:
                    edge_dir = (data['locked_coords'][1] - data['locked_coords'][0]).normalized()
                    draw_vector(edge_dir * length, origin=data['point_co'], color=yellow, width=2, alpha=0.75, fade=True)

            else:
                draw_vector(-edge_dir * length, origin=data['point_co'], color=green, width=2, alpha=0.75, fade=True)

    def finish(self, context: Context):
        """
        清理模态操作资源

        Args:
            context: Blender上下文
        """
        self.finish_status()
        self.finish_modal_handlers()

    def _get_slide_data(self, context: Context) -> dict:
        """
        获取滑动操作所需的数据

        Args:
            context: Blender上下文

        Returns:
            包含滑动参数的字典
        """
        data = get_curve_data(self.act_curve)
        selection = get_curve_selection_indices(data)
        sidx, pidx = selection.pop()

        points = self.act_curve.splines[sidx].points
        point = points[pidx]
        point_co_2d = location_3d_to_region_2d(context.region, context.region_data, self.mx @ point.co.xyz)

        slide_data = {
            'point': point,
            'point_co': self.mx @ point.co.xyz,
            'point_co_local': point.co.xyz.copy(),
            'point_co_2d': point_co_2d,
            'prev_point_co': None,
            'next_point_co': None,
            'prev_dir': None,
            'next_dir': None,
            'slide_segment': None,
            'locked': None,
            'locked_coords': [],
        }

        if 0 < pidx < len(points) - 1:
            prev_point = points[pidx - 1]
            next_point = points[pidx + 1]

            slide_data['prev_point_co'] = self.mx @ prev_point.co.xyz
            slide_data['next_point_co'] = self.mx @ next_point.co.xyz

            prev_dir = prev_point.co.xyz - point.co.xyz
            next_dir = next_point.co.xyz - point.co.xyz

            slide_data['prev_dir'] = (self.mx.to_3x3() @ prev_dir).normalized()
            slide_data['next_dir'] = (self.mx.to_3x3() @ next_dir).normalized()

        elif pidx == 0:
            next_point = points[pidx + 1]
            slide_data['next_point_co'] = self.mx @ next_point.co.xyz

            next_dir = next_point.co.xyz - point.co.xyz
            slide_data['next_dir'] = (self.mx.to_3x3() @ next_dir).normalized()

        else:
            prev_point = points[pidx - 1]
            slide_data['prev_point_co'] = self.mx @ prev_point.co.xyz

            prev_dir = prev_point.co.xyz - point.co.xyz
            slide_data['prev_dir'] = (self.mx.to_3x3() @ prev_dir).normalized()

        return slide_data

    def _slide_point(self, context: Context):
        """
        执行点的滑动操作

        Args:
            context: Blender上下文
        """
        mouse_pos_2d = self.mouse_region_pos + self.mouse_offset
        view_origin = region_2d_to_origin_3d(context.region, context.region_data, mouse_pos_2d)
        view_dir = region_2d_to_vector_3d(context.region, context.region_data, mouse_pos_2d)

        point_co = self.slide_data['point_co']
        prev_dir = self.slide_data['prev_dir']
        next_dir = self.slide_data['next_dir']
        locked = self.slide_data['locked']

        prev_i_co = None
        next_i_co = None
        prev_m_co = None
        next_m_co = None

        if prev_dir:
            intersection = intersect_line_line(point_co, point_co + prev_dir, view_origin, view_origin + view_dir)
            if intersection:
                prev_i_co, prev_m_co = intersection

        if next_dir:
            intersection = intersect_line_line(point_co, point_co + next_dir, view_origin, view_origin + view_dir)
            if intersection:
                next_i_co, next_m_co = intersection

        # 锁定模式下仅沿锁定方向求解, 交点失效时保持原位
        if locked:
            target_i_co = prev_i_co if locked == 'prev' else next_i_co
            if target_i_co is None:
                return

            slide_co = self.mx.inverted_safe() @ target_i_co
            self.slide_data['slide_segment'] = locked

        elif prev_dir and next_dir and prev_i_co is not None and next_i_co is not None:
            prev_mouse_dir = (prev_m_co - point_co).normalized()
            prev_dot = prev_mouse_dir.dot(prev_dir)

            next_mouse_dir = (next_m_co - point_co).normalized()
            next_dot = next_mouse_dir.dot(next_dir)

            slide_co = self.mx.inverted_safe() @ (next_i_co if next_dot > prev_dot else prev_i_co)
            self.slide_data['slide_segment'] = 'next' if next_dot > prev_dot else 'prev'

        elif prev_dir and prev_i_co is not None:
            slide_co = self.mx.inverted_safe() @ prev_i_co
            self.slide_data['slide_segment'] = 'prev'

        elif next_i_co is not None:
            slide_co = self.mx.inverted_safe() @ next_i_co
            self.slide_data['slide_segment'] = 'next'

        else:
            # 视线与滑动段平行时无有效交点, 保持原位
            return

        if self.is_shift:
            point_co_local = self.slide_data['point_co_local']
            slide_vec = slide_co - point_co_local
            slide_co = point_co_local + slide_vec * 0.2

        self.slide_data['point'].co.xyz = slide_co


def draw_curve_slide_status(op: CurvePointSlide):
    """
    返回 CurvePointSlide 操作的状态栏绘制回调函数

    Args:
        op: CurvePointSlide 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='MOVE', text="Slide", gap=1)

        seg = op.slide_data['slide_segment']
        locked = op.slide_data['locked']

        if seg and op.slide_data['prev_dir'] and op.slide_data['next_dir']:
            draw_status_item(row, active=bool(locked), key='ALT', text="Clamp")

    return draw
