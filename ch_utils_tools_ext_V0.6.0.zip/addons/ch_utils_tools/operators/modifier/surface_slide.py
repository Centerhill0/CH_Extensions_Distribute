"""
Surface Slide 操作模块

提供 Surface Slide 功能,允许在修改拓扑的同时保持初始形态不变.
通过 Shrinkwrap 修改器实现网格在目标表面上的滑动.

操作流程:
1. 在编辑模式下选择网格对象
2. 执行 SurfaceSlide 操作,创建收缩包裹目标
3. 编辑网格拓扑
4. 执行 FinishSurfaceSlide 操作,应用修改器并清理

支持的选项:
- 自动处理实例对象
- 自动创建临时目标网格
- 支持撤销操作
"""

from uuid import uuid4

import bpy
from bpy.types import Operator, Context

from .....common.i18n.i18n import report

from ...utils import (
    add_shrinkwrap_modifier,
    get_shrinkwrap_modifier,
    set_object_parent,
)

__all__ = ["SurfaceSlide", "FinishSurfaceSlide"]

# Surface Slide 修改器的名称约定, add/get 均按此名称查找(供 UI 侧判断复用)
SURFACE_SLIDE_MOD_NAME = 'SurfaceSlide'


class SurfaceSlide(Operator):
    """
    Surface Slide 操作器

    功能: 开始 Surface Slide 模式
    - 在修改拓扑的同时保持初始形态不变
    - 自动创建收缩包裹目标
    - 支持处理实例对象

    要求: 编辑模式下有活动网格对象,且没有形态键
    """

    bl_idname = "ch.surface_slide"
    bl_label = "Surface Slide"
    bl_description = "Start Surface Sliding: modify the topology while keeping the initial form intact"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        act_obj = context.active_object

        if not act_obj or act_obj.type != 'MESH':
            return

        if act_obj.data.shape_keys:
            cls.poll_message_set("You can't Surface Slide on Objects with Shape Keys")
            return

        return get_shrinkwrap_modifier(act_obj, SURFACE_SLIDE_MOD_NAME) is None

    def execute(self, context: Context):
        act_obj = context.active_object
        act_obj.update_from_editmode()
        act_obdata = act_obj.data

        instances = [obj for obj in bpy.data.objects if obj != act_obj and obj.data == act_obdata]

        if instances:
            self.report({'INFO'}, report("Object '{}' has {} instances, creating temporary unique mesh data").format(act_obj.name, len(instances)))

            bpy.ops.object.mode_set(mode='OBJECT')

            instance_mesh = act_obdata.copy()
            instance_mesh.name = f"{act_obj.name}_INSTANCE"
            act_obj.data = instance_mesh

            bpy.ops.object.mode_set(mode='EDIT')

            dup_hash = str(uuid4())

            # dup_hash 为插件注册时挂载到 Object 的自定义属性(见 __init__.py _addon_properties)
            act_obj.dup_hash = dup_hash

            for obj in instances:
                obj.dup_hash = dup_hash

        target = bpy.data.objects.new(name=f"{act_obj.name}_SURFACE", object_data=act_obdata.copy())
        target.data.name = f"{act_obdata.name}_SURFACE"
        target.use_fake_user = True
        target.matrix_world = act_obj.matrix_world

        add_shrinkwrap_modifier(act_obj, target, SURFACE_SLIDE_MOD_NAME)

        set_object_parent(target, act_obj)

        return {'FINISHED'}


class FinishSurfaceSlide(Operator):
    """
    Finish Surface Slide 操作器

    功能: 结束 Surface Slide 模式
    - 应用 Shrinkwrap 修改器
    - 清理临时目标网格
    - 恢复实例对象的共享网格数据

    要求: 活动对象有 Surface Slide 修改器
    """

    bl_idname = "ch.finish_surface_slide"
    bl_label = "Finish Surface Slide"
    bl_description = "Stop Surface Sliding"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        act_obj = context.active_object
        if act_obj and act_obj.type == 'MESH':
            return get_shrinkwrap_modifier(act_obj, SURFACE_SLIDE_MOD_NAME) is not None

    def execute(self, context: Context):
        act_obj = context.active_object
        act_obdata = act_obj.data
        surface_slide = get_shrinkwrap_modifier(act_obj, SURFACE_SLIDE_MOD_NAME)

        if not surface_slide:
            self.report({'ERROR'}, "No Surface Slide modifier found")
            return {'CANCELLED'}

        surface = surface_slide.target

        editmode = context.mode == 'EDIT_MESH'

        if editmode:
            bpy.ops.object.mode_set(mode='OBJECT')

        try:
            bpy.ops.object.modifier_apply(modifier=surface_slide.name)
        except RuntimeError as e:
            self.report({'ERROR'}, report("Failed to apply modifier: {}").format(e))
            if editmode:
                bpy.ops.object.mode_set(mode='EDIT')
            return {'CANCELLED'}

        if editmode:
            bpy.ops.object.mode_set(mode='EDIT')

        if surface and surface.data:
            bpy.data.meshes.remove(surface.data, do_unlink=True)

        if dup_hash := act_obj.dup_hash:
            instances = [obj for obj in bpy.data.objects if obj != act_obj and obj.dup_hash == dup_hash]

            dup_mesh = None

            for obj in instances:
                if dup_mesh is None:
                    dup_mesh = obj.data

                obj.data = act_obdata
                obj.dup_hash = ''

            act_obj.dup_hash = ''
            act_obdata.name = act_obdata.name.replace('_INSTANCE', '')

            if dup_mesh and not dup_mesh.users:
                bpy.data.meshes.remove(dup_mesh, do_unlink=True)

        return {'FINISHED'}
