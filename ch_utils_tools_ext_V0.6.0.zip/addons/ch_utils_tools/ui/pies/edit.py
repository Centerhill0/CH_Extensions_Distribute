"""
各种物体编辑饼菜单模块

提供以下功能:
- ObjectPie:物体模式
- EditMeshPie:网格编辑
- EditCurvePie:曲线编辑
- EditArmaturePie:骨架编辑
- PosePie:姿态
"""

import bpy
from bpy.types import Menu, Context, UILayout
from ...operators.mesh.chamfer import ChamferToFillet, FilletToChamfer, Unchamfer, Unfillet
from ...operators.mesh.edge_length import SetEdgeLength
from ...operators.mesh.offset_edges import OffsetEdges
from ...operators.mesh.extend_elements import ExtendElements
from ...operators.mesh.intersect_elements import IntersectElements
from ...operators.curve.blend import CurvePointsBlend
from ...operators.curve.knife import CurveKnife
from ...operators.curve.merge import CurveMergeToLast, CurveMergeToCenter
from ...operators.curve.shuffle import CurveGapShuffle
from ...operators.curve.slide import CurvePointSlide
from ...operators.curve.smooth import CurveSmooth
from ...operators.object.create_object import CreatePointObject, CreateMeshQuadSphere, CreateCircle, DupAndSep


def _draw_bone_collections(col: UILayout, bone):
    """绘制骨骼所属集合列表"""
    row = col.row(align=True)
    row.label(text="Collections:")
    row.separator(factor=2.5)

    if len(bone.collections) != 0:
        box = row.box()
        box.scale_y = 0.6
        sub = box.row(align=True)
        sub.scale_x = 0.6
        for bcoll in bone.collections:
            row = sub.row(align=True)
            row.label(text="•")
            row.prop(bcoll, "name", text="", emboss=False)
    else:
        row.label(text="No Collection Assigned")


# ============================================================
# 物体编辑饼菜单
# ============================================================
class ObjectPie(Menu):
    """
    物体饼菜单

    在物体模式下提供操作:
    - 变换操作(球化,剪切,弯曲,镜像等)
    - 创建网格图元和曲线
    - 视口显示设置
    - 资产标记和转换

    要求: 物体模式
    """

    bl_idname = "VIEW3D_MT_ch_object_pie"
    bl_label = "CH Object Pie"
    bl_description = "Object Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:变换操作
        col = pie.column(align=False)
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator("transform.tosphere")
        row.separator(factor=0.3)
        row.operator("transform.shear")

        row = col.row(align=True)
        row.operator("transform.bend")
        row.separator(factor=0.3)
        row.operator("transform.push_pull")

        row = col.row(align=True)
        row.operator("object.randomize_transform")
        row.separator(factor=0.3)
        row.operator("transform.mirror", text="Interactive Mirror")

        row = col.row(align=True)
        row.operator("transform.transform", text="Align to Transform Orientation")
        row.separator(factor=0.3)
        row.operator("object.origin_clear", text="Origin Clear")

        if context.view_layer.objects.active:
            row = col.row(align=True)
            row.alignment = 'CENTER'
            row.scale_x = 3
            row.prop(context.view_layer.objects.active, "hide_select", text="")
            row.separator(factor=0.3)
            row.prop(context.view_layer.objects.active, "hide_viewport", text="")
            row.separator(factor=0.3)
            row.prop(context.view_layer.objects.active, "hide_render", text="")

        # 右:创建图元
        col = pie.column()
        col.scale_x = 2.0
        col.ui_units_x = 8
        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.operator("mesh.primitive_plane_add", text="", icon='MESH_PLANE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_cube_add", text="", icon='MESH_CUBE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_uv_sphere_add", text="", icon='MESH_UVSPHERE')
        row.separator(factor=0.3)
        row.operator(CreateMeshQuadSphere.bl_idname, text="", icon='SPHERE')

        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.operator(CreatePointObject.bl_idname, text="", icon='DOT')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_cylinder_add", text="", icon='MESH_CYLINDER')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_cone_add", text="", icon='MESH_CONE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_ico_sphere_add", text="", icon='MESH_ICOSPHERE')

        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.operator("mesh.primitive_monkey_add", text="", icon='MESH_MONKEY')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_torus_add", text="", icon='MESH_TORUS')
        row.separator(factor=0.3)
        row.operator("object.grease_pencil_add", text="", icon='STROKE')
        row.separator(factor=0.3)
        row.operator("object.armature_add", text="", icon='OUTLINER_OB_ARMATURE')

        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.operator("curve.primitive_bezier_curve_add", text="", icon='CURVE_BEZCURVE')
        row.separator(factor=0.3)
        row.operator("curve.primitive_nurbs_curve_add", text="", icon='CURVE_NCURVE')
        row.separator(factor=0.3)
        row.operator("curve.primitive_nurbs_path_add", text="", icon='CURVE_PATH')
        row.separator(factor=0.3)
        row.operator("object.text_add", text="", icon='OUTLINER_OB_FONT')

        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.operator("object.light_add", text="", icon='LIGHT_POINT').type = 'POINT'
        row.separator(factor=0.3)
        row.operator("object.light_add", text="", icon='LIGHT_SUN').type = 'SUN'
        row.separator(factor=0.3)
        row.operator("object.light_add", text="", icon='LIGHT_SPOT').type = 'SPOT'
        row.separator(factor=0.3)
        row.operator("object.light_add", text="", icon='LIGHT_AREA').type = 'AREA'

        # 下:视口显示
        if context.view_layer.objects.active:
            col = pie.column()
            col.ui_units_x = 15

            row = col.row(align=False)
            split = row.split(factor=0.4, align=False)
            split.separator()
            split.label(text="Viewport Display")

            row = col.row(align=True)
            row.prop(context.view_layer.objects.active, "show_name", text="Name")
            row.prop(context.view_layer.objects.active, "show_axis", text="Axes")
            row.prop(context.view_layer.objects.active, "show_in_front", text="In Front")
            row.prop(context.view_layer.objects.active, "show_bounds", text="Bounds")

            row = col.row(align=True)
            row.prop(context.view_layer.objects.active, "display_type", expand=True)

            row = col.row(align=True)
            row.prop(context.view_layer.objects.active, "show_wire")
            row.prop(context.space_data.overlay, "wireframe_threshold")

        # 上:资产和转换
        col = pie.column()
        col.ui_units_x = 15
        row = col.row(align=True)
        row.operator("asset.mark", icon='ASSET_MANAGER')
        row.separator(factor=0.3)
        row.operator("asset.clear", icon='NONE')
        row.separator(factor=0.3)
        row.operator("asset.clear", text="Clear Asset (Set Fake User)", icon='NONE').set_fake_user = True

        row = col.row(align=True)
        row.operator("object.make_dupli_face", text="Make Instance Face")
        row.separator(factor=0.3)
        row.operator("object.make_local", text="Make Local")
        row.separator(factor=0.3)
        row.operator("object.make_single_user", text="Make Single User")

        row = col.row(align=True)
        row.operator("object.convert", text="Convert to Mesh", icon='OUTLINER_OB_MESH').target = 'MESH'
        row.separator(factor=0.3)
        row.operator("object.convert", text="Convert to Curve", icon='OUTLINER_OB_CURVE').target = 'CURVE'

        row.separator(factor=0.3)
        row.operator("object.convert", text="Convert to Point Cloud", icon='OUTLINER_OB_POINTCLOUD').target = 'POINTCLOUD'


# ============================================================
# 网格编辑饼菜单
# ============================================================
class EditMeshPie(Menu):
    """
    网格编辑饼菜单

    在网格编辑模式下提供操作:
    - 变换操作(球化,剪切,弯曲等)
    - 创建网格图元
    - 法线操作和相交
    - 桥接,填充,细分
    - 平滑,分离

    要求: 网格编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editmesh_pie"
    bl_label = "CH Edit Mesh Pie"
    bl_description = "Edit Mesh Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:变换操作
        col = pie.column()
        col.ui_units_x = 11

        row = col.row(align=True)
        row.operator(ChamferToFillet.bl_idname)
        row.separator(factor=0.3)
        row.operator(Unfillet.bl_idname)
        if bpy.app.version >= (5, 2, 0):
            row.separator(factor=0.3)
            row.operator("mesh.circularize")

        row = col.row(align=True)
        row.operator(FilletToChamfer.bl_idname)
        row.separator(factor=0.3)
        row.operator(Unchamfer.bl_idname)
        if bpy.app.version >= (5, 2, 0):
            row.separator(factor=0.3)
            row.operator("mesh.flatten")

        row = col.row(align=True)
        row.operator("transform.vertex_random")
        # row.separator(factor=0.3)
        # row.operator("transform.shrink_fatten")
        row.separator(factor=0.3)
        row.operator("mesh.knife_project")
        if bpy.app.version >= (5, 2, 0):
            row.separator(factor=0.3)
            row.operator("mesh.space_edge_loops_evenly")

        # 右:创建网格图元
        col = pie.column()
        col.scale_x = 2.0
        row = col.row(align=True)
        row.operator("mesh.primitive_plane_add", text="", icon='MESH_PLANE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_cube_add", text="", icon='MESH_CUBE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_uv_sphere_add", text="", icon='MESH_UVSPHERE')
        row = col.row(align=True)
        row.operator(CreateCircle.bl_idname, text="", icon='MESH_CIRCLE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_cylinder_add", text="", icon='MESH_CYLINDER')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_cone_add", text="", icon='MESH_CONE')
        row = col.row(align=True)
        row.operator("mesh.primitive_monkey_add", text="", icon='MESH_MONKEY')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_ico_sphere_add", text="", icon='MESH_ICOSPHERE')
        row.separator(factor=0.3)
        row.operator("mesh.primitive_torus_add", text="", icon='MESH_TORUS')

        # 下:法线操作和相交
        col = pie.column()
        col.scale_x = 1.0
        col.ui_units_x = 13
        row = col.row(align=True)
        row.operator("mesh.flip_normals", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.normals_make_consistent", text="Recalculate Outside", icon='NONE').inside = False
        row.separator(factor=0.3)
        row.operator("mesh.normals_make_consistent", text="Recalculate Inside", icon='NONE').inside = True

        row = col.row(align=True)
        row.operator("mesh.intersect", text="Intersect (Knife)", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.intersect_boolean", text="Intersect (Boolean)", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.face_split_by_edges", text="Weld Edges into Faces", icon='NONE')

        row = col.row(align=True)
        row.operator(SetEdgeLength.bl_idname)
        row.separator(factor=0.3)
        row.operator(OffsetEdges.bl_idname)

        row = col.row(align=True)
        row.operator(ExtendElements.bl_idname)
        row.separator(factor=0.3)
        row.operator(IntersectElements.bl_idname)

        # 上:桥接,填充,细分
        col = pie.column()
        col.ui_units_x = 13
        row = col.row(align=True)
        row.operator("mesh.bridge_edge_loops", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.solidify", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.wireframe", icon='NONE')

        row = col.row(align=True)
        row.operator("mesh.fill", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.fill_grid", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.beautify_fill", icon='NONE')

        row = col.row(align=True)
        row.operator("mesh.poke", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.quads_convert_to_tris", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.tris_convert_to_quads", icon='NONE')

        # 左上:细分和取消细分
        col = pie.column()
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator("mesh.subdivide", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.unsubdivide", icon='NONE')

        # 右上:平滑
        col = pie.column()
        col.ui_units_x = 10
        row = col.row(align=True)
        row.operator("mesh.vertices_smooth", icon='NONE').factor = 0.5
        row.separator(factor=0.3)
        row.operator("mesh.vertices_smooth_laplacian", text="Smooth Vertices (Laplacian)", icon='NONE')

        # 左下:拆分
        col = pie.column()
        col.ui_units_x = 12
        row = col.row(align=True)
        row.operator("mesh.split", text="Split by Selection", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.edge_split", text="Faces by Edges", icon='NONE').type = 'EDGE'
        row.separator(factor=0.3)
        row.operator("mesh.edge_split", text="Faces & Edges by Vertices", icon='NONE').type = 'VERT'

        # 右下:分离
        col = pie.column()
        col.ui_units_x = 12
        row = col.row(align=True)
        row.operator(DupAndSep.bl_idname, text="Separate Selection", icon='NONE')
        row.separator(factor=0.3)
        row.operator("mesh.separate", text="By Material", icon='NONE').type = 'MATERIAL'
        row.separator(factor=0.3)
        row.operator("mesh.separate", text="By Loose Parts", icon='NONE').type = 'LOOSE'


# ============================================================
# 曲线编辑饼菜单
# ============================================================
class EditCurvePie(Menu):
    """
    曲线编辑饼菜单

    在曲线编辑模式下提供操作:
    - 变换操作(球化,剪切,弯曲等)
    - 创建曲线图元
    - 样条类型设置
    - 手柄类型设置
    - 倾斜和平滑操作

    要求: 曲线编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_editcurve_pie"
    bl_label = "CH Edit Curve Pie"
    bl_description = "Edit Curve Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_CURVE'

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:变换操作
        col = pie.column()
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator(CurvePointsBlend.bl_idname)
        row.separator(factor=0.3)
        row.operator(CurvePointSlide.bl_idname)
        row = col.row(align=True)
        row.operator(CurveSmooth.bl_idname)
        row.separator(factor=0.3)
        row.operator(CurveGapShuffle.bl_idname)
        row = col.row(align=True)
        row.operator(CurveMergeToLast.bl_idname)
        row.separator(factor=0.3)
        row.operator(CurveMergeToCenter.bl_idname)
        row = col.row(align=True)
        row.operator(CurveKnife.bl_idname)
        row.separator(factor=0.3)
        row.operator("curve.cyclic_toggle")

        # 右:创建曲线图元
        col = pie.column()
        col.scale_x = 2.0
        row = col.row(align=True)
        row.operator("curve.primitive_bezier_curve_add", text="", icon='CURVE_BEZCURVE')
        row.separator(factor=0.3)
        row.operator("curve.primitive_bezier_circle_add", text="", icon='CURVE_BEZCIRCLE')
        row = col.row(align=True)
        row.operator("curve.primitive_nurbs_curve_add", text="", icon='CURVE_NCURVE')
        row.separator(factor=0.3)
        row.operator("curve.primitive_nurbs_circle_add", text="", icon='CURVE_NCIRCLE')
        row = col.row(align=True)
        row.operator("curve.primitive_nurbs_path_add", text="", icon='CURVE_PATH')

        # 下:样条和手柄类型
        col = pie.column()
        col.ui_units_x = 13
        row = col.row(align=True)
        row.operator("curve.spline_type_set", text="Poly").type = 'POLY'
        row.separator(factor=0.3)
        row.operator("curve.spline_type_set", text="Bézier").type = 'BEZIER'
        row.separator(factor=0.3)
        row.operator("curve.spline_type_set", text="NURBS").type = 'NURBS'

        row = col.row(align=True)
        row.operator("curve.handle_type_set", text="Automatic").type = 'AUTOMATIC'
        row.operator("curve.handle_type_set", text="Vector").type = 'VECTOR'
        row.operator("curve.handle_type_set", text="Aligned").type = 'ALIGNED'
        row.operator("curve.handle_type_set", text="Free").type = 'FREE_ALIGN'

        # 上:倾斜和平滑操作
        col = pie.column()
        col.ui_units_x = 13
        row = col.row(align=True)
        row.operator("transform.tilt")
        row.operator("curve.tilt_clear")
        row.separator(factor=0.3)
        row.operator("curve.normals_make_consistent")

        row = col.row(align=True)
        row.operator("curve.smooth_tilt")
        row.operator("curve.smooth_radius")
        row.operator("curve.smooth_weight")

        # 左上:细分和方向
        col = pie.column()
        row = col.row(align=True)
        row.operator("curve.subdivide")
        row.separator(factor=0.3)
        row.operator("curve.switch_direction")

        # 右上:平滑
        col = pie.column()
        row = col.row(align=True)
        row.operator("transform.transform", text="Radius").mode = 'CURVE_SHRINKFATTEN'
        row.separator(factor=0.3)
        row.operator("curve.smooth")

        # 左下:分离和拆分
        col = pie.column()
        row = col.row(align=True)
        row.operator("curve.split")
        row.separator(factor=0.3)
        row.operator("curve.separate")

        # 右下:保留位置
        act_obj = context.active_object
        curve = act_obj.data
        act_spline = curve.splines.active
        col = pie.column()
        col.ui_units_x = 13

        row = col.row(align=True)
        row.prop(curve, "bevel_depth")
        row.separator(factor=0.3)
        row.prop(curve, "extrude")

        row = col.row(align=True)
        sub_row = row.row(align=True)
        sub_row.prop(curve, "bevel_resolution")
        sub_row.enabled = bool(curve.bevel_depth)

        row.separator(factor=0.3)
        sub_row = row.row(align=True)
        sub_row.prop(curve, "resolution_u")
        sub_row.enabled = bool(act_spline and act_spline.type in {'NURBS', 'BEZIER'})


# ============================================================
# 骨架编辑模式饼菜单
# ============================================================
class EditArmaturePie(Menu):
    """
    骨架编辑模式饼菜单

    功能:提供骨架编辑操作
    - 变换工具(球化,剪切,弯曲,推拉等)
    - 骨骼属性设置
    - 视口显示选项
    - 骨骼滚动和命名操作
    - 骨骼层级和集合管理

    要求:骨架编辑模式下有活动骨骼
    """

    bl_idname = "VIEW3D_MT_ch_editarmature_pie"
    bl_label = "CH Edit Armature Pie"
    bl_description = "Edit Armature Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'EDIT_ARMATURE' and context.active_bone

    def draw(self, context: Context):
        bone = context.active_bone
        arm = context.object.data
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:变换工具
        col = pie.column()
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator("transform.tosphere")
        row.separator(factor=0.3)
        row.operator("transform.shear")
        row = col.row(align=True)
        row.operator("transform.bend")
        row.separator(factor=0.3)
        row.operator("transform.push_pull")
        row = col.row(align=True)
        row.operator("transform.vertex_warp")
        row.separator(factor=0.3)
        row.operator("transform.vertex_random")
        row = col.row(align=True)
        row.operator("armature.align")

        # 右:骨骼属性
        col = pie.column()
        col.ui_units_x = 9
        col_fl = col.column_flow(columns=2, align=False)

        col_fl.prop(bone, "use_deform")
        col_fl.prop(bone, "use_envelope_multiply", text="Envelope Multiply")
        col_fl.prop(bone, "lock")

        col_fl.prop(bone, "use_connect")
        col_fl.prop(bone, "use_local_location")
        col_fl.prop(bone, "use_inherit_rotation")

        col.prop(bone, "inherit_scale")

        # 下:视口显示选项
        col = pie.column()
        col.ui_units_x = 13
        row = col.row(align=False)
        split = row.split(factor=0.4, align=False)
        split.separator()
        split.label(text="Viewport Display")

        row = col.row(align=True)
        row.prop(arm, "show_names", text="Names")
        row.prop(arm, "show_bone_custom_shapes", text="Shapes")
        row.prop(arm, "show_bone_colors", text="Bone Colors")
        row.prop(arm, "show_axes", text="Axes")

        col_fl = col.column_flow(columns=3, align=False)
        col_fl.prop(context.active_bone, "display_type", expand=True)

        # 上:骨骼滚动和命名
        col = pie.column()
        col.ui_units_x = 13
        row = col.row(align=True)
        row.operator("armature.calculate_roll")
        row.operator("transform.transform", text="Set Roll").mode = 'BONE_ROLL'
        row.operator("armature.roll_clear")

        row = col.row(align=True)
        row.operator("armature.autoside_names", text="Auto-Name Left/Right").type = 'XAXIS'
        row.operator("armature.autoside_names", text="Auto-Name Front/Back").type = 'YAXIS'
        row.operator("armature.flip_names")

        # 左上:骨骼操作
        col = pie.column()
        col.ui_units_x = 10
        row = col.row(align=True)
        row.operator("armature.subdivide")
        row.separator(factor=0.3)
        row.operator("armature.switch_direction")
        row.separator(factor=0.3)
        row.operator("armature.symmetrize")

        # 右上:骨骼父级
        col = pie.column()
        col.ui_units_x = 10
        col.prop(bone, "parent")

        # 左下:骨骼分离
        col = pie.column()
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator("armature.split")
        row.separator(factor=0.3)
        row.operator("armature.separate")

        # 右下:骨骼集合
        col = pie.column()
        _draw_bone_collections(col, bone)


# ============================================================
# 姿态模式饼菜单
# ============================================================
class PosePie(Menu):
    """
    姿态模式饼菜单

    功能:提供姿态模式操作
    - 变换工具(球化,剪切,弯曲,推拉等)
    - 骨骼属性设置
    - 视口显示选项
    - 骨骼命名操作
    - IK 和约束管理
    - 骨骼集合显示

    要求:姿态模式下有活动骨骼
    """

    bl_idname = "VIEW3D_MT_ch_pose_pie"
    bl_label = "CH Pose Pie"
    bl_description = "Pose Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'POSE' and context.active_bone

    def draw(self, context: Context):
        bone = context.active_bone
        arm = context.object.data
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:变换工具
        col = pie.column()
        col.ui_units_x = 8
        row = col.row(align=True)
        row.operator("transform.tosphere")
        row.separator(factor=0.3)
        row.operator("transform.shear")
        row = col.row(align=True)
        row.operator("transform.bend")
        row.separator(factor=0.3)
        row.operator("transform.push_pull")
        row = col.row(align=True)
        row.operator("pose.transforms_clear")
        row.separator(factor=0.3)
        row.operator("pose.user_transforms_clear", text="Reset Unkeyed")
        row = col.row(align=True)
        row.operator("pose.quaternions_flip")
        row.separator(factor=0.3)
        row.operator("poselib.create_pose_asset")

        # 右:骨骼属性
        col = pie.column()
        col.ui_units_x = 9
        col_fl = col.column_flow(columns=2, align=False)

        col_fl.prop(bone, "use_deform")
        col_fl.prop(bone, "use_envelope_multiply", text="Envelope Multiply")
        col_fl.prop(bone, "use_relative_parent")
        # col_fl.prop(bone, "lock")

        col_fl.prop(bone, "use_connect")
        col_fl.prop(bone, "use_local_location")
        col_fl.prop(bone, "use_inherit_rotation")

        col.prop(bone, "inherit_scale")

        # 下:视口显示选项
        col = pie.column()
        col.ui_units_x = 13
        row = col.row(align=False)
        split = row.split(factor=0.4, align=False)
        split.separator()
        split.label(text="Viewport Display")

        row = col.row(align=True)
        row.prop(arm, "show_names", text="Names")
        row.prop(arm, "show_bone_custom_shapes", text="Shapes")
        row.prop(arm, "show_bone_colors", text="Bone Colors")
        row.prop(arm, "show_axes", text="Axes")

        col_fl = col.column_flow(columns=3, align=False)
        col_fl.prop(context.active_bone, "display_type", expand=True)

        # 上:骨骼命名
        col = pie.column()
        col.ui_units_x = 12
        row = col.row(align=True)
        row.operator("pose.autoside_names", text="Auto-Name Left/Right").axis = 'XAXIS'
        row.operator("pose.autoside_names", text="Auto-Name Front/Back").axis = 'YAXIS'
        row.operator("pose.flip_names")

        # 左上:IK 管理
        col = pie.column()
        row = col.row(align=True)
        row.operator("pose.ik_add")
        row.operator("pose.ik_clear")

        # 右上:骨骼父级
        col = pie.column()
        col.ui_units_x = 10
        col.prop(bone, "parent")

        # 左下:约束管理
        col = pie.column()
        row = col.row(align=True)
        row.operator("pose.constraint_add_with_targets")
        row.operator("pose.constraints_clear")

        # 右下:骨骼集合
        col = pie.column()
        _draw_bone_collections(col, bone)
