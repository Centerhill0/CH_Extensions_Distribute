"""
物体模式切换饼菜单模块


提供以下功能:
- 物体模式切换:支持网格,曲线,骨架,蜡笔等物体类型的模式切换.
- 图像/UV编辑器切换:支持图像编辑器和UV编辑器之间的切换.
"""

import bpy
from bpy.props import EnumProperty
from bpy.types import Menu, Operator, Context, UILayout

from ...constants import (
    OBJ_TYPES_WITH_PIE,
    MESH_OBJ_ALL_MODES,
    CURVES_OBJ_ALL_MODES,
    ARMATURE_OBJ_ALL_MODES,
    GP_OBJ_ALL_MODES,
    OBJ_TYPES_TAB_DIR,
    OTHER_OBJ_TYPES,
)


#region 物体模式切换饼菜单
class CH_OT_modes_toggle(Operator):
    """
    物体模式切换操作符

    根据物体类型切换到对应的模式切换饼菜单.

    要求: 存在活动物体
    """

    bl_idname = "ch.modes_toggle"
    bl_label = "Modes Toggle"
    bl_description = "Toggle Between Object Modes"

    @classmethod
    def poll(cls, context: Context):
        return context.object is not None

    def execute(self, context: Context):
        if context.object.type in OBJ_TYPES_WITH_PIE:
            bpy.ops.wm.call_menu_pie(name=ModesTogglePie.bl_idname)
        elif context.object.type in OBJ_TYPES_TAB_DIR:
            bpy.ops.object.editmode_toggle()
        elif context.object.type in OTHER_OBJ_TYPES:
            return {'CANCELLED'}
        return {'FINISHED'}


class ModesTogglePie(Menu):
    """
    物体模式切换饼菜单

    根据物体类型提供不同的模式切换选项:
    - 网格: 物体,编辑,雕刻,纹理绘制,权重绘制,顶点绘制,粒子编辑
    - 曲线: 物体,编辑,雕刻
    - 骨架: 物体,编辑,姿态
    - 蜡笔: 物体,编辑,绘制,雕刻,权重绘制,顶点绘制

    要求: 存在活动物体
    """

    bl_idname = "VIEW3D_MT_ch_modes_toggle_pie"
    bl_label = "Modes Toggle"
    bl_description = "Modes Toggle Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.object is not None

    def draw(self, context: Context):
        pie = self.layout.menu_pie()

        if context.mode in MESH_OBJ_ALL_MODES and context.active_object.type == 'MESH':
            self._mesh_object_mode_set(context, pie)
        elif context.mode in CURVES_OBJ_ALL_MODES and context.active_object.type == 'CURVES':
            self._curves_object_mode_set(context, pie)
        elif context.mode in ARMATURE_OBJ_ALL_MODES and context.active_object.type == 'ARMATURE':
            self._armature_object_mode_set(context, pie)
        elif context.mode in GP_OBJ_ALL_MODES and context.active_object.type == 'GREASEPENCIL':
            self._gpencil_object_mode_set(context, pie)

    def _mesh_object_mode_set(self, context: Context, pie: UILayout):
        """网格物体的七种模式切换"""
        # 左:顶点选择模式
        sel_mode = context.scene.tool_settings.mesh_select_mode
        if context.mode == 'EDIT_MESH':
            pie.operator("mesh.select_mode", text="Vertex", icon='VERTEXSEL', depress=sel_mode[0]).type = 'VERT'
        else:
            op = pie.operator("object.mode_set_with_submode", text="Vertex", icon='VERTEXSEL')
            op.mode = 'EDIT'
            op.mesh_select_mode = {'VERT'}

        # 右:边选择模式
        if context.mode == 'EDIT_MESH':
            pie.operator("mesh.select_mode", text="Edge", icon='EDGESEL', depress=sel_mode[1]).type = 'EDGE'
        else:
            op = pie.operator("object.mode_set_with_submode", text="Edge", icon='EDGESEL')
            op.mode = 'EDIT'
            op.mesh_select_mode = {'EDGE'}

        # 下:面选择模式
        if context.mode == 'EDIT_MESH':
            pie.operator("mesh.select_mode", text="Face", icon='FACESEL', depress=sel_mode[2]).type = 'FACE'
        else:
            op = pie.operator("object.mode_set_with_submode", text="Face", icon='FACESEL')
            op.mode = 'EDIT'
            op.mesh_select_mode = {'FACE'}

        # 上:物体/编辑模式切换
        if context.mode in {'SCULPT', 'PAINT_TEXTURE', 'PAINT_WEIGHT', 'PAINT_VERTEX', 'PARTICLE'}:
            pie.operator("object.mode_set", text="Object", icon='OBJECT_DATAMODE')
        elif context.mode in {'OBJECT', 'EDIT_MESH'}:
            pie.operator(
                "object.editmode_toggle",
                text=("Object" if context.mode == 'EDIT_MESH' else "Edit"),
                icon=('OBJECT_DATAMODE' if context.mode == 'EDIT_MESH' else 'EDITMODE_HLT'),
            )

        # 左上:模式快捷按钮
        row = pie.row(align=True)
        row.scale_x = 1.2
        row.scale_y = 1.5
        if context.object.particle_systems.active:
            row.operator("object.mode_set", text="", icon='PARTICLEMODE').mode = 'PARTICLE_EDIT'
        row.operator("object.mode_set", text="", icon='TPAINT_HLT').mode = 'TEXTURE_PAINT'
        row.operator("object.mode_set", text="", icon='WPAINT_HLT').mode = 'WEIGHT_PAINT'
        row.operator("object.mode_set", text="", icon='VPAINT_HLT').mode = 'VERTEX_PAINT'
        row.operator("object.mode_set", text="", icon='SCULPTMODE_HLT').mode = 'SCULPT'

        # 右上:骨骼选择遮罩
        if context.mode == 'PAINT_WEIGHT':
            if context.object.parent and context.object.parent.type == 'ARMATURE':
                pie.prop(context.object.data, "use_paint_bone_selection", text="Bone Selection")
            else:
                pie.separator()
        else:
            pie.separator()

        # 左下:绘制遮罩
        if context.mode in {'PAINT_TEXTURE', 'PAINT_WEIGHT', 'PAINT_VERTEX'}:
            pie.prop(context.object.data, "use_paint_mask", text="Paint Mask")

        # 右下:顶点选择遮罩
        if context.mode in {'PAINT_WEIGHT', 'PAINT_VERTEX'}:
            pie.prop(context.object.data, "use_paint_mask_vertex", text="Vertex Selection")

    def _curves_object_mode_set(self, context: Context, pie: UILayout):
        """Curves曲线(新毛发对象)的三种模式切换"""
        # 左:点选择模式
        pie.operator(SwitchCurvesEditDomain.bl_idname, text="Point", icon='CURVE_BEZCIRCLE').domain = 'POINT'

        # 右:曲线选择模式
        pie.operator(SwitchCurvesEditDomain.bl_idname, text="Curve", icon='CURVE_PATH').domain = 'CURVE'

        # 下:编辑/雕刻模式切换
        if context.mode == 'SCULPT_CURVES':
            pie.operator("object.mode_set", text="Edit", icon='EDITMODE_HLT').mode = 'EDIT'
        elif context.mode in {'OBJECT', 'EDIT_CURVES'}:
            pie.operator("object.mode_set", text="Sculpt", icon='SCULPTMODE_HLT').mode = 'SCULPT_CURVES'

        # 上:物体/编辑模式切换
        if context.mode == 'SCULPT_CURVES':
            pie.operator("object.mode_set", text="Object", icon='OBJECT_DATAMODE')
        elif context.mode in {'OBJECT', 'EDIT_CURVES'}:
            pie.operator(
                "object.editmode_toggle",
                text=("Object" if context.mode == 'EDIT_CURVES' else "Edit"),
                icon=('OBJECT_DATAMODE' if context.mode == 'EDIT_CURVES' else 'EDITMODE_HLT'),
            )

    def _armature_object_mode_set(self, context: Context, pie: UILayout):
        """Armature的三种模式切换"""
        # 左:编辑模式
        pie.operator("object.mode_set", text="Edit", icon='EDITMODE_HLT').mode = 'EDIT'

        # 右:姿态模式
        pie.operator("object.mode_set", text="Pose", icon='POSE_HLT').mode = 'POSE'

        # 下:保留位置
        pie.separator()

        # 上:物体模式
        pie.operator("object.mode_set", text="Object", icon='OBJECT_DATAMODE').mode = 'OBJECT'

    def _gpencil_object_mode_set(self, context: Context, pie: UILayout):
        """GPencil的六种模式切换"""
        # 左:点模式
        self._add_gpencil_domain_button(context, pie, 'POINT', 'Point', 'GP_SELECT_POINTS', 'use_gpencil_vertex_select_mask_point', 'use_gpencil_select_mask_point')

        # 右:笔画模式
        self._add_gpencil_domain_button(context, pie, 'STROKE', 'Stroke', 'GP_SELECT_STROKES', 'use_gpencil_vertex_select_mask_stroke', 'use_gpencil_select_mask_stroke')

        # 下:线段模式
        self._add_gpencil_domain_button(context, pie, 'SEGMENT', 'Segment', 'GP_SELECT_BETWEEN_STROKES', 'use_gpencil_vertex_select_mask_segment', 'use_gpencil_select_mask_segment')

        # 上:物体/编辑模式切换
        if context.mode in {'PAINT_GREASE_PENCIL', 'WEIGHT_GREASE_PENCIL', 'VERTEX_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'}:
            pie.operator("object.mode_set", text="Object", icon='OBJECT_DATAMODE')
        elif context.mode in {'OBJECT', 'EDIT_GREASE_PENCIL'}:
            pie.operator(
                "object.editmode_toggle",
                text=("Object" if context.mode == 'EDIT_GREASE_PENCIL' else "Edit"),
                icon=('OBJECT_DATAMODE' if context.mode == 'EDIT_GREASE_PENCIL' else 'EDITMODE_HLT'),
            )

        # 左上:模式快捷按钮
        row = pie.row(align=True)
        row.scale_x = 1.2
        row.scale_y = 1.5
        row.operator("object.mode_set", text="", icon='GREASEPENCIL').mode = 'PAINT_GREASE_PENCIL'
        row.operator("object.mode_set", text="", icon='WPAINT_HLT').mode = 'WEIGHT_GREASE_PENCIL'
        row.operator("object.mode_set", text="", icon='VPAINT_HLT').mode = 'VERTEX_GREASE_PENCIL'
        row.operator("object.mode_set", text="", icon='SCULPTMODE_HLT').mode = 'SCULPT_GREASE_PENCIL'

    def _add_gpencil_domain_button(self, context: Context, pie: UILayout, domain: str, text: str, icon: str, mask_vertex: str, mask_sculpt: str):
        sel_mode = context.scene.tool_settings.gpencil_selectmode_edit
        if context.mode in {'OBJECT', 'WEIGHT_GREASE_PENCIL', 'PAINT_GREASE_PENCIL'}:
            pie.operator(SwitchGPencilEditDomain.bl_idname, text=text, icon=icon).domain = domain
        elif context.mode == 'EDIT_GREASE_PENCIL':
            pie.operator("grease_pencil.set_selection_mode", text=text, icon=icon, depress=sel_mode == domain).mode = domain
        elif context.mode == 'VERTEX_GREASE_PENCIL':
            pie.prop(context.scene.tool_settings, mask_vertex, text=text)
        elif context.mode == 'SCULPT_GREASE_PENCIL':
            pie.prop(context.scene.tool_settings, mask_sculpt, text=text)


class SwitchCurvesEditDomain(Operator):
    """
    切换曲线编辑域

    在曲线编辑模式下切换选择域(点/曲线).
    如果在物体模式下调用,会自动进入编辑模式.

    要求: 活动物体为曲线类型
    """

    bl_idname = "ch.switch_curves_edit_domain"
    bl_label = "Switch Curve Edit Domain"
    bl_description = "Switch the curve edit domain in object mode"

    domain: EnumProperty(
        items=[
            ("POINT", "Point", ""),
            ("CURVE", "Curve", ""),
        ],
        name="Domain",
        default="POINT",
    )  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.object is not None and context.object.type == 'CURVES'

    def execute(self, context: Context):
        if context.mode == 'OBJECT':
            bpy.ops.object.editmode_toggle()
        bpy.ops.curves.set_selection_domain(domain=self.domain)
        return {'FINISHED'}


class SwitchGPencilEditDomain(Operator):
    """
    切换GPencil编辑模式的指定模式

    在GPencil物体模式下可直接切换到指定模式(点/笔画/线段).

    要求: 活动物体为GPencil类型
    """

    bl_idname = "ch.switch_gpencil_edit_domain"
    bl_label = "Switch GPencil Edit Domain"
    bl_description = "Switch the GPencil edit domain in object mode"

    domain: EnumProperty(
        items=[
            ("POINT", "Point", ""),
            ("STROKE", "Stroke", ""),
            ("SEGMENT", "Segment", ""),
        ],
        name="Domain",
        default="POINT",
    )  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.object is not None and context.object.type == 'GREASEPENCIL'

    def execute(self, context: Context):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.grease_pencil.set_selection_mode(mode=self.domain)
        return {'FINISHED'}

#endregion


#region 图像/UV编辑器切换饼菜单
class ImageUVModesSwitchPie(Menu):
    """
    图像/UV编辑器切换饼菜单

    根据当前编辑器类型提供不同功能:
    - 图像编辑器: 切换视图模式,跳转到UV编辑器
    - UV编辑器: 选择模式切换,同步选择设置,跳转到图像编辑器
    """

    bl_idname = "VIEW3D_MT_ch_imageuv_modes_switch_pie"
    bl_label = "Modes Switch"
    bl_description = "Image & UV Modes Switch Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.object is not None and context.object.type == 'MESH' and context.area is not None and context.area.ui_type in ('IMAGE_EDITOR', 'UV')

    def draw(self, context: Context):
        pie = self.layout.menu_pie()

        if context.area.ui_type == 'IMAGE_EDITOR':
            pie.prop(context.space_data, "ui_mode", text=context.space_data.ui_mode, expand=True)
            pie.operator(SwitchToUVEditor.bl_idname, text="UV Editor", icon='UV')

        elif context.area.ui_type == 'UV':

            if context.scene.tool_settings.use_uv_select_sync:
                pie.operator("mesh.select_mode", text="Vertex", icon='VERTEXSEL').type = 'VERT'
                pie.operator("mesh.select_mode", text="Edge", icon='EDGESEL').type = 'EDGE'
                pie.operator("mesh.select_mode", text="Face", icon='FACESEL').type = 'FACE'
            else:
                pie.operator("uv.select_mode", text="Vertex", icon='UV_VERTEXSEL').type = 'VERTEX'
                pie.operator("uv.select_mode", text="Edge", icon='UV_EDGESEL').type = 'EDGE'
                pie.operator("uv.select_mode", text="Face", icon='UV_FACESEL').type = 'FACE'

            pie.operator(SwitchToImageEditor.bl_idname, text="Image Editor", icon='IMAGE')
            pie.prop(context.scene.tool_settings, "use_uv_select_sync", text="Sync Selection")
            pie.prop(context.scene.tool_settings, "use_uv_select_island", text="UV Island Selection")


class SwitchToUVEditor(Operator):
    """
    切换到UV编辑器

    将当前图像编辑器切换为UV编辑器.
    如果活动物体是网格,自动进入编辑模式.
    """

    bl_idname = "ch.switch_to_uv_editor"
    bl_label = "Switch to UV Editor"
    bl_description = "Switch to UV Editor"

    def execute(self, context: Context):
        if context.area.ui_type == 'IMAGE_EDITOR':
            context.area.ui_type = 'UV'
            if context.object is not None and context.object.type == 'MESH':
                bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


class SwitchToImageEditor(Operator):
    """
    切换到图像编辑器

    将当前UV编辑器切换为图像编辑器.
    """

    bl_idname = "ch.switch_to_image_editor"
    bl_label = "Switch to Image Editor"
    bl_description = "Switch to Image Editor"

    def execute(self, context: Context):
        if context.area.ui_type == 'UV':
            context.area.ui_type = 'IMAGE_EDITOR'
        return {'FINISHED'}
#endregion
