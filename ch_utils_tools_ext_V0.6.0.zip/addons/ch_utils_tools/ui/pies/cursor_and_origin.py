"""
游标与原点饼菜单模块

提供游标吸附和原点设置功能的饼菜单.
包含游标到选中项,选中项到游标,设置原点等操作.
"""

import bmesh
from bpy.types import Menu, Context
from bmesh.types import BMVert, BMEdge, BMFace

from .....common.i18n.i18n import iface

from ...utils import get_active_element_from_bmesh, has_selected_curve_element
from ...constants import ORIGIN_EDIT_SUPPORT_TYPES
from ...operators.cursor_and_origin.cursor import CursorToSelected, SelectedToCursor, CursorToOrigin
from ...operators.cursor_and_origin.origin import OriginToGeometry, OriginToCursor, OriginToActive, OriginToBoundBottom


class CursorAndOrigin(Menu):
    """
    游标与原点饼菜单

    提供游标吸附和原点设置功能:
    - 游标到选中项/世界原点/栅格点
    - 选中项到游标/栅格点
    - 设置物体原点

    支持模式: 物体模式,网格编辑模式,曲线编辑模式,GP编辑模式
    """

    bl_idname = "VIEW3D_MT_ch_cursor_and_origin_pie"
    bl_label = "CH Cursor And Origin Pie"
    bl_description = "Cursor And Origin Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.active_object or context.selected_objects

    def draw(self, context: Context):
        layout = self.layout
        pie = layout.menu_pie()
        act_obj = context.active_object

        # 左:吸附游标到选中项
        if context.mode == 'OBJECT':
            pie.operator(CursorToSelected.bl_idname, text="Cursor to Selected", icon='PIVOT_CURSOR')

        elif context.mode == 'EDIT_MESH':
            bm = bmesh.from_edit_mesh(act_obj.data)
            act_element = get_active_element_from_bmesh(context, bm)
            sel = None
            if isinstance(act_element, BMVert):
                sel, icon = ('Vert', 'VERTEXSEL')
            elif isinstance(act_element, BMEdge):
                sel, icon = ('Edge', 'EDGESEL')
            elif isinstance(act_element, BMFace):
                sel, icon = ('Face', 'FACESEL')
            if sel:
                pie.operator(CursorToSelected.bl_idname, text=iface("Cursor to {}").format(iface(sel)), icon='PIVOT_CURSOR')
            else:
                pie.operator(CursorToSelected.bl_idname, text="Select None", icon='ERROR')

        elif context.mode == 'EDIT_GREASE_PENCIL':
            pie.operator("grease_pencil.snap_cursor_to_selected", text="Cursor to Selected", icon='PIVOT_CURSOR')
        else:
            pie.operator("view3d.snap_cursor_to_selected", text="Cursor to Selected", icon='PIVOT_CURSOR')

        # 右:吸附选中项到游标
        if context.mode == 'OBJECT':
            pie.operator(SelectedToCursor.bl_idname, text="Selection to Cursor", icon='RESTRICT_SELECT_OFF')
        elif context.mode == 'EDIT_GREASE_PENCIL':
            pie.operator("grease_pencil.snap_to_cursor", text="Selection to Cursor", icon='RESTRICT_SELECT_OFF').use_offset = False
        else:
            pie.operator("view3d.snap_selected_to_cursor", text="Selection to Cursor", icon="RESTRICT_SELECT_OFF").use_offset = False

        # 下:设置物体原点
        sel_object_types = {obj.type for obj in context.selected_objects}
        if context.mode == 'OBJECT' and (sel_object_types & ORIGIN_EDIT_SUPPORT_TYPES):
            col = pie.column()
            row = col.split(factor=0.35)
            row.separator()
            row.label(text="Set Origin")
            col.scale_y = 1.5
            grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=True)
            grid.operator(OriginToGeometry.bl_idname, text="to Geometry", icon='SNAP_FACE_CENTER')
            grid.operator(OriginToCursor.bl_idname, text="to Cursor", icon='PIVOT_CURSOR')
            grid.operator(OriginToActive.bl_idname, text="to Active", icon='PIVOT_ACTIVE')
            grid.operator(OriginToBoundBottom.bl_idname, text="to Bottom", icon='IMPORT')

        elif context.mode in {'EDIT_MESH', 'EDIT_CURVE'}:
            col = pie.column()
            row = col.split(factor=0.35)
            row.separator()
            row.label(text="Set Origin")
            col.scale_y = 1.5
            grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=True)

            if context.mode == 'EDIT_MESH':
                bm = bmesh.from_edit_mesh(act_obj.data)
                act_element = get_active_element_from_bmesh(context, bm)
                sel = None
                if isinstance(act_element, BMVert):
                    sel, icon = ('Vert', 'VERTEXSEL')
                elif isinstance(act_element, BMEdge):
                    sel, icon = ('Edge', 'EDGESEL')
                elif isinstance(act_element, BMFace):
                    sel, icon = ('Face', 'FACESEL')

                if sel:
                    grid.operator(OriginToActive.bl_idname, text=iface("to {}").format(iface(sel)), icon=icon)
                else:
                    grid.operator(OriginToActive.bl_idname, text="Select None", icon='ERROR')

            elif context.mode == 'EDIT_CURVE':
                if has_selected_curve_element(act_obj):
                    grid.operator(OriginToActive.bl_idname, text="to Points", icon='CURVE_BEZCURVE')
                else:
                    grid.operator(OriginToActive.bl_idname, text="Select None", icon='ERROR')

            grid.operator(OriginToCursor.bl_idname, text="to Cursor", icon='LAYER_ACTIVE')

        else:
            pie.separator()

        # 上:吸附到活动项
        if context.mode in {'OBJECT', 'EDIT_MESH'}:
            pie.operator("view3d.snap_selected_to_active", icon='RESTRICT_SELECT_OFF')
        else:
            pie.separator()

        # 左上:吸附游标到世界原点
        pie.operator(CursorToOrigin.bl_idname, text="Cursor to World Origin", icon='PIVOT_CURSOR')

        # 右上:吸附选中项到游标(保持偏移)
        if context.mode == 'EDIT_GREASE_PENCIL':
            pie.operator("grease_pencil.snap_to_cursor", text="Selection to Cursor (Keep Offset)", icon='RESTRICT_SELECT_OFF').use_offset = True
        else:
            pie.operator("view3d.snap_selected_to_cursor", text="Selection to Cursor (Keep Offset)", icon="RESTRICT_SELECT_OFF").use_offset = True

        # 左下:吸附游标到栅格点
        pie.operator("view3d.snap_cursor_to_grid", text="Cursor to Grid", icon="PIVOT_CURSOR")

        # 右下:吸附选中项到栅格点
        if context.mode == 'EDIT_GREASE_PENCIL':
            pie.operator("grease_pencil.snap_to_grid", text="Selection to Grid", icon='RESTRICT_SELECT_OFF')
        else:
            pie.operator("view3d.snap_selected_to_grid", text="Selection to Grid", icon="RESTRICT_SELECT_OFF")
