"""
灯光饼菜单模块

提供灯光模式下的操作饼菜单.
包含调节灯光基本属性,可见性,灯光链接,阴影链接等.
"""

from bpy.types import Menu, Context

from .....common.i18n.i18n import iface


class LightPie(Menu):
    """
    灯光饼菜单

    提供添加不同类型灯光的快捷选项.
    支持点光源,太阳光源,聚光灯和区域光源.
    """

    bl_idname = "VIEW3D_MT_ch_light_pie"
    bl_label = "CH Light Pie"
    bl_description = "Light Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'LIGHT' and context.scene.render.engine != 'BLENDER_WORKBENCH'

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()
        obj = context.active_object
        light = obj.data

        # 左:灯光的独有设定
        col = pie.column()
        light_titles = {
            'POINT': "Point",
            'SUN': "Sun",
            'SPOT': "Spot",
            'AREA': "Area",
        }
        col.label(text=iface("{} Settings").format(iface(light_titles.get(light.type, light.type.title()))))
        col.ui_units_x = 10

        sub_col = col.box().column()
        row = sub_col.row(align=True)
        if light.type in {'POINT', 'SPOT'}:
            row.prop(light, "shadow_soft_size", text="Radius")
            row.prop(light, "use_soft_falloff")
        elif light.type == 'SUN':
            row.prop(light, "angle")
        elif light.type == 'AREA':
            row.prop(light, "shape", expand=True)

            sub = sub_col.column(align=True)
            if light.shape in {'SQUARE', 'DISK'}:
                sub.prop(light, "size")
            elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
                sub_1 = sub.row(align=True)
                sub_1.prop(light, "size", text="Size X")
                sub_1.prop(light, "size_y", text="Y")

        if light.type == 'SPOT':
            sub_row = col.box().row(align=True)
            sub_row.prop(light, "spot_size")
            sub_row.prop(light, "spot_blend", text="Blend")

        if light.type == 'AREA' and context.scene.render.engine == 'CYCLES':
            sub_col = col.box().column()
            sub_col.prop(light, "spread")

        # 绘制可见性
        row = col.row()
        row.label(text="Visibility")
        col = row.box().column(align=False)

        row = col.row(align=False)
        row.prop(obj, "visible_diffuse", text="Diffuse")
        row.prop(obj, "visible_glossy", text="Glossy")
        row = col.row(align=False)
        row.prop(obj, "visible_transmission", text="Transmission")
        row.prop(obj, "visible_volume_scatter", text="Volume Scatter")

        # 右:灯光的公共设定
        col = pie.column()
        col.label(text="Light Settings")
        col = col.box().column()
        col.ui_units_x = 10
        row = col.row(align=True, heading="Temperature")
        row.prop(light, "use_temperature", text="")

        sub = row.row()
        sub.active = light.use_temperature
        sub.prop(light, "temperature", text="")

        row = col.row(align=True, heading="Tint" if light.use_temperature else "Color")
        row.prop(light, "color", text="")

        row = col.row(align=True, heading="Power")
        row.prop(light, "energy", text="")

        if context.scene.render.engine == 'BLENDER_EEVEE':
            col.prop(light, "use_shadow", text="Cast Shadow")

        if context.scene.render.engine == 'CYCLES':
            col = col.row(align=False, heading="Light Group")

            col.prop(obj, "lightgroup", text="")

        # 下:阴影链接
        col = pie.column()
        row = col.row()
        row.label(text="Shadow Linking")
        sub = row.box().column(align=False)
        sub.ui_units_x = 8
        sub_row = sub.row(align=False)
        sub_row.operator("object.light_linking_blockers_link", text="Include").link_state = 'INCLUDE'
        sub_row.operator("object.light_linking_blockers_link", text="Exclude").link_state = 'EXCLUDE'

        # 上:灯光链接
        col = pie.column()
        row = col.row()
        row.label(text="Light Linking")
        sub = row.box().column(align=False)
        sub.ui_units_x = 8
        sub_row = sub.row(align=False)
        sub_row.operator("object.light_linking_receivers_link", text="Include").link_state = 'INCLUDE'
        sub_row.operator("object.light_linking_receivers_link", text="Exclude").link_state = 'EXCLUDE'
