"""
添加物体修改器饼菜单模块

提供物体模式下添加物体修改器的操作饼菜单.
包含添加,删除,应用,屏蔽修改器等功能.
"""

import bpy
from bpy.types import Menu, Context, Operator
from ...operators.modifier.boolean import AddBooleanMod, ApplyBooleanMod
from ...operators.modifier.lattice import LatticeOverlay, ApplyLattice
from ...operators.modifier.surface_slide import SurfaceSlide, FinishSurfaceSlide, SURFACE_SLIDE_MOD_NAME

SUPPORT_TYPES = {'MESH', 'CURVE', 'SURFACE', 'FONT', 'GREASEPENCIL'}


class AddModifierPie(Menu):
    """
    添加修改器饼菜单

    根据活动物体类型显示对应的修改器添加选项.
    支持网格,曲线,曲面,字体和蜡笔类型.
    """

    bl_idname = "VIEW3D_MT_ch_add_modifier_pie"
    bl_label = "CH Add Modifier Pie"
    bl_description = "Add Modifier Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.active_object is not None and context.active_object.type in SUPPORT_TYPES

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()
        act_obj = context.active_object

        # 左:绘制修改器列表
        _draw_modifier_list(self, act_obj, pie)

        # 右:根据物体类型添加修改器
        match act_obj.type:
            case 'MESH':
                _draw_add_modifier_mesh(self, pie)
            case 'CURVE' | 'SURFACE' | 'FONT':
                _draw_add_modifier_curve(self, pie)
            case 'GREASEPENCIL':
                _draw_add_modifier_gp(self, pie)
            case _:
                pass

        # 下:绘制修改器列表
        col = pie.column(align=False)

        ## 晶格修改器
        box = col.box()
        sub_col = box.column(align=True)
        row = sub_col.row()
        row.operator(LatticeOverlay.bl_idname, text="Lattice Overlay", icon='MOD_LATTICE')
        row.operator(ApplyLattice.bl_idname, text="Convert To Shape Key", icon='GROUP_VERTEX').apply_mode = 'TO_SHAPE_KEY'
        sub_col.separator(factor=0.3)
        row = sub_col.row()
        row.operator(ApplyLattice.bl_idname, text="Remove Lattice Modifier", icon='REMOVE').apply_mode = 'REMOVE'
        row.operator(ApplyLattice.bl_idname, text="Apply Lattice Modifier", icon='ADD').apply_mode = 'APPLY'

        ## 布尔修改器
        box = col.box()
        sub_col = box.column(align=True)
        row = sub_col.row()
        row.operator(AddBooleanMod.bl_idname, icon='MOD_BOOLEAN')
        row.operator(AddBooleanMod.bl_idname, text="", icon='SELECT_INTERSECT').method = 'INTERSECT'
        row.operator(AddBooleanMod.bl_idname, text="", icon='SELECT_EXTEND').method = 'UNION'
        row.operator(AddBooleanMod.bl_idname, text="", icon='SELECT_SUBTRACT').method = 'DIFFERENCE'
        row.operator(AddBooleanMod.bl_idname, text="", icon='SELECT_DIFFERENCE').method = 'SPLIT'
        sub_col.separator(factor=0.3)
        row = sub_col.row()
        row.operator(ApplyBooleanMod.bl_idname, text="Remove Boolean Modifier", icon='REMOVE').apply_mode = 'REMOVE'
        row.operator(ApplyBooleanMod.bl_idname, text="Apply Boolean Modifier", icon='ADD').apply_mode = 'APPLY'

        # 上:应用/移除所有修改器, 隐藏/显示所有修改器
        box = pie.box()
        row = box.row(align=False)
        row.operator(ModifierEdit.bl_idname, text="Apply All", icon='IMPORT').mode = 'APPLY_ALL'
        row.operator(ModifierEdit.bl_idname, text="Remove All", icon='X').mode = 'REMOVE_ALL'

        row = box.row(align=False)
        row.operator(ModifierEdit.bl_idname, text="Hide All", icon='RESTRICT_VIEW_ON').mode = 'HIDE_ALL'
        row.operator(ModifierEdit.bl_idname, text="Show All", icon='RESTRICT_VIEW_OFF').mode = 'SHOW_ALL'

        # 左上:表面滑动 (添加缩裹修改器)
        box = pie.box()
        row = box.row()
        has_surface_slide = [mod for mod in act_obj.modifiers if mod.type == 'SHRINKWRAP' and SURFACE_SLIDE_MOD_NAME in mod.name]
        if has_surface_slide:
            row.alert = True
            row.operator(FinishSurfaceSlide.bl_idname, icon='OUTLINER_DATA_SURFACE')
        else:
            row.operator(SurfaceSlide.bl_idname, icon='OUTLINER_DATA_SURFACE')


def _draw_modifier_list(self, obj, pie):
    """绘制修改器列表,包含每个修改器的操作按钮."""
    col = pie.column(align=True)
    col.label(text="Modifiers List", icon='MODIFIER')
    box = col.box()

    col = box.column(align=True)

    if obj is None:
        col.label(text="No active object", icon='ERROR')
    elif len(obj.modifiers) == 0:
        col.label(text="No modifiers", icon='INFO')
    else:
        for i, mod in enumerate(obj.modifiers):
            row = col.row(align=True)
            row.label(text=str(i + 1))
            icon = _get_modifier_icon(mod.type)
            row.label(text=mod.name, icon=icon)

            sub_1 = row.row(align=True)
            sub_1.active = mod.show_viewport
            sub_11 = sub_1.row(align=True)
            sub_11.active = mod.show_in_editmode
            sub_11.prop(mod, "show_on_cage", text="")
            sub_1.prop(mod, "show_in_editmode", text="")

            sub_2 = row.row(align=True)
            sub_2.prop(mod, "show_viewport", text="")

            row.separator(factor=0.5)

            sub_3 = row.row(align=True)
            sub_3.operator("object.modifier_apply", text="", icon='IMPORT').modifier = mod.name
            sub_3.operator("object.modifier_remove", text="", icon='X').modifier = mod.name

            row.separator(factor=0.5)
            if i > 0:
                op = row.operator("object.modifier_move_up", text="", icon='TRIA_UP')
                op.modifier = mod.name
            else:
                row.label(text="", icon='BLANK1')

            if i < len(obj.modifiers) - 1:
                op = row.operator("object.modifier_move_down", text="", icon='TRIA_DOWN')
                op.modifier = mod.name
            else:
                row.label(text="", icon='BLANK1')


def _draw_add_modifier_mesh(self, pie):
    """绘制网格物体添加修改器按钮."""
    col = pie.column()
    col.scale_x = 2.0
    col.ui_units_x = 8

    row = col.row(align=True)
    row.alignment = 'CENTER'
    op = row.operator("object.modifier_add_node_group", text="", icon='MOD_ARRAY')
    op.asset_library_type = 'ESSENTIALS'
    op.asset_library_identifier = ""
    op.relative_asset_identifier = "nodes/geometry_nodes_essentials.blend/NodeTree/Array"

    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_BEVEL').type = 'BEVEL'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_DECIM').type = 'DECIMATE'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_REMESH').type = 'REMESH'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    op = row.operator("object.modifier_add_node_group", text="", icon='MOD_SCATTER_ON_SURFACE')
    op.asset_library_type = 'ESSENTIALS'
    op.asset_library_identifier = ""
    op.relative_asset_identifier = "nodes/geometry_nodes_essentials.blend/NodeTree/Scatter on Surface"

    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_SKIN').type = 'SKIN'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_SOLIDIFY').type = 'SOLIDIFY'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='AUTOMERGE_OFF').type = 'WELD'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_WIREFRAME').type = 'WIREFRAME'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_CAST').type = 'CAST'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_CURVE').type = 'CURVE'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_DISPLACE').type = 'DISPLACE'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_SHRINKWRAP').type = 'SHRINKWRAP'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_MESHDEFORM').type = 'SURFACE_DEFORM'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_NORMALEDIT').type = 'NORMAL_EDIT'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_NORMALEDIT').type = 'WEIGHTED_NORMAL'


def _draw_add_modifier_curve(self, pie):
    """绘制曲线,曲面,字体物体添加修改器按钮."""
    col = pie.column()
    col.scale_x = 2.0
    col.ui_units_x = 8

    row = col.row(align=True)
    row.alignment = 'CENTER'
    op = row.operator("object.modifier_add_node_group", text="", icon='MOD_ARRAY')
    op.asset_library_type = 'ESSENTIALS'
    op.asset_library_identifier = ""
    op.relative_asset_identifier = "nodes/geometry_nodes_essentials.blend/NodeTree/Array"

    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_BEVEL').type = 'BEVEL'
    row.separator(factor=0.3)
    op = row.operator("object.modifier_add_node_group", text="", icon='MOD_CURVE_TO_TUBE')
    op.asset_library_type = 'ESSENTIALS'
    op.asset_library_identifier = ""
    op.relative_asset_identifier = "nodes/geometry_nodes_essentials.blend/NodeTree/Curve to Tube"

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_MIRROR').type = 'MIRROR'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_SOLIDIFY').type = 'SOLIDIFY'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_SUBSURF').type = 'SUBSURF'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='AUTOMERGE_OFF').type = 'WELD'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_CAST').type = 'CAST'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_CURVE').type = 'CURVE'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_MESHDEFORM').type = 'MESH_DEFORM'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_SHRINKWRAP').type = 'SHRINKWRAP'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_SIMPLEDEFORM').type = 'SIMPLE_DEFORM'


def _draw_add_modifier_gp(self, pie):
    """绘制蜡笔物体添加修改器按钮."""
    col = pie.column()
    col.scale_x = 2.0
    col.ui_units_x = 8

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_ARRAY').type = 'GREASE_PENCIL_ARRAY'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_DASH').type = 'GREASE_PENCIL_DASH'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_ENVELOPE').type = 'GREASE_PENCIL_ENVELOPE'
    row.separator(factor=0.3)

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_MIRROR').type = 'GREASE_PENCIL_MIRROR'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='GP_MULTIFRAME_EDITING').type = 'GREASE_PENCIL_MULTIPLY'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_OUTLINE').type = 'GREASE_PENCIL_OUTLINE'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='MOD_NOISE').type = 'GREASE_PENCIL_NOISE'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_OFFSET').type = 'GREASE_PENCIL_OFFSET'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_THICKNESS').type = 'GREASE_PENCIL_THICKNESS'

    row = col.row(align=True)
    row.alignment = 'CENTER'
    row.operator("object.modifier_add", text="", icon='OPTIONS').type = 'GREASE_PENCIL_COLOR'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_OPACITY').type = 'GREASE_PENCIL_OPACITY'
    row.separator(factor=0.3)
    row.operator("object.modifier_add", text="", icon='MOD_TINT').type = 'GREASE_PENCIL_TINT'


_MODIFIER_ICON_CACHE = {}


def _get_modifier_icon(mod_type):
    """返回修改器类型对应的图标名称,若不存在则返回通用修改器图标(结果缓存)."""
    if mod_type not in _MODIFIER_ICON_CACHE:
        icon_candidate = 'MOD_' + mod_type
        icon_items = bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys()
        _MODIFIER_ICON_CACHE[mod_type] = icon_candidate if icon_candidate in icon_items else 'MODIFIER'
    return _MODIFIER_ICON_CACHE[mod_type]


class ModifierEdit(Operator):
    """
    修改器批量操作
    提供批量应用,移除,显示,隐藏修改器的功能.
    """

    bl_idname = "ch.modifier_edit"
    bl_label = "Modifier Edit"
    bl_description = "Batch Apply, Remove, Show or Hide Modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        description="Edit mode",
        items=[
            ('REMOVE_ALL', "Remove All", "Remove all modifiers"),
            ('APPLY_ALL', "Apply All", "Apply all modifiers"),
            ('HIDE_ALL', "Hide All", "Hide all modifiers"),
            ('SHOW_ALL', "Show All", "Show all modifiers"),
        ],
        default='APPLY_ALL',
    )  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.active_object is not None and len(context.active_object.modifiers) > 0

    def execute(self, context: Context):
        obj = context.active_object
        match self.mode:
            case 'REMOVE_ALL':
                bpy.ops.object.modifiers_clear()
            case 'APPLY_ALL':
                # FONT 等物体类型无法应用修改器, 与 lattice._match_apply_mode 保持一致
                if obj.type not in {'CURVE', 'SURFACE', 'MESH', 'GREASEPENCIL'}:
                    self.report({'ERROR'}, "Cannot apply modifier for this object type")
                    return {'CANCELLED'}

                for mod in list(obj.modifiers):
                    bpy.ops.object.modifier_apply(modifier=mod.name)
            case 'HIDE_ALL':
                for mod in obj.modifiers:
                    mod.show_viewport = False
            case 'SHOW_ALL':
                for mod in obj.modifiers:
                    mod.show_viewport = True
        return {'FINISHED'}
