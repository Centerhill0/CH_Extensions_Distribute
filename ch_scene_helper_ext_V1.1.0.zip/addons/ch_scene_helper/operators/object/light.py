"""
灯光辅助操作器模块

提供以下功能:
- LightOrganize: 灯光整理, 把灯光集合之外的灯光物体移入最新创建的灯光集合
- LightAdvancedModeSet: 高级设置模式切换(联动灯光类型)
- LightAssetLibrarySet: 资产选择器的资产库选定(库菜单项的落点)
- LightAssetCategorySet: 资产选择器的分类选定(分类菜单项的落点)
- LightAssetThumbCycle: 资产选择器的缩略图循环应用
"""

from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Menu, Operator

from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...preference import library_roots, resolve_library_root
from ...scene_state import active_block, get_state, highlight_item
from ...utils import collect_orphan_nodes, collect_stray_lights, create_light_collection, find_advanced_node, find_or_load_image, list_assets, list_categories, move_objects_to_collection, newest_light_collection, rig_controller_of

_ADVANCED_MODES = ('NONE', 'GRADIENT', 'IMAGE', 'IES')

# 资产种类 -> 面板状态里记录"选中资产库根目录"的字段名
_LIBRARY_FIELDS = {'IMAGE': "adv_image_library", 'IES': "adv_ies_library"}


def _asset_root(state, kind: str) -> str:
    """资产种类 -> 选中资产库的根目录(库被删/禁用/改了路径时回落该用途首个可用库, 无库为空串)"""
    return resolve_library_root(kind, getattr(state, _LIBRARY_FIELDS[kind]))[0]


def _category_field(kind: str) -> str:
    """资产种类 -> 分类目录名的状态字段名"""
    return "adv_image_category" if kind == 'IMAGE' else "adv_ies_category"


class LightOrganize(Operator):
    """灯光整理: 把灯光集合之外的灯光物体(不含被排除集合内的)移入最新创建的灯光集合"""

    bl_idname = "ch.light_organize"
    bl_label = "Organize Lights"
    bl_description = "Move every light outside the light collections into the newest light collection (one is created first when there is no light collection)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        scene = context.scene
        # 先判"有活可干"能避免为了空整理凭空建集合(无集合时新建的 CLS_01_ 本身不含灯光, 顺序无影响)
        lights = collect_stray_lights(scene, context.view_layer)
        if not lights:
            self.report({'INFO'}, report("No lights outside the light collections"))
            return {'CANCELLED'}
        target = newest_light_collection(scene)
        if target is None:
            target = create_light_collection(scene)
        # 灯光随迁其控制器空物体(rig 整体进集合): 控制器不在灯光集合也一并移入,
        # 报告口径仍按灯光数
        objects = list(lights)
        for light in lights:
            controller = rig_controller_of(light)
            if controller is not None:
                objects.append(controller)
        move_objects_to_collection(objects, target)
        refresh_lists()
        highlight_item(context, "light_collections", target.name)
        self.report({'INFO'}, report("Moved {} lights into {}").format(len(lights), target.name))
        return {'FINISHED'}


class LightAssetLibrarySet(Operator):
    """高级设置资产选择器的资产库选定(库菜单项的落点)

    只写面板状态里的选中库根目录: 分类与缩略图的失效回退由绘制侧/枚举回调统一处理
    (换库后原分类多半不在新库里, 回落首分类).
    """

    bl_idname = "ch.light_asset_library_set"
    bl_label = "Set Asset Library"
    bl_description = "Use this asset library for the active picker"
    bl_options = {'REGISTER', 'UNDO'}

    pick_kind: StringProperty(name="Kind", description="Asset kind: IMAGE or IES", default="IMAGE", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    library_path: StringProperty(name="Library", description="Root directory of the asset library", default="", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        kind = self.pick_kind if self.pick_kind in {'IMAGE', 'IES'} else 'IMAGE'
        setattr(get_state(context), _LIBRARY_FIELDS[kind], self.library_path)
        return {'FINISHED'}


class LightAdvancedModeSet(Operator):
    """高级设置模式切换, 同时按模式联动灯光类型

    IES 一律切点光; 渐变/图像一律切面光(+Shift 改切聚光, 无论当前是什么灯型);
    "无"不联动. 先切灯型再写模式——灯型切换会重建灯光节点树, 顺序反了会先建链再被
    重建冲掉(即便有 depsgraph 自愈钩子, 也不该依赖它补自己的窟窿).
    """

    bl_idname = "ch.light_advanced_mode_set"
    bl_label = "Set Advanced Mode"
    bl_description = "Switch the advanced mode of the active light; the light type follows the mode (IES -> point; gradient and image -> area)\n+Shift: gradient and image switch to a spot light"
    bl_options = {'REGISTER', 'UNDO'}

    mode: StringProperty(name="Mode", description="Target advanced mode", default="NONE", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    is_shift: bool = False

    def invoke(self, context: Context, event):
        self.is_shift = event.shift
        return self.execute(context)

    def execute(self, context: Context):
        mode = self.mode if self.mode in _ADVANCED_MODES else 'NONE'
        obj = active_block(context, "lights")
        if obj is None or obj.type != 'LIGHT':
            return {'CANCELLED'}
        if obj.library is not None:
            self.report({'WARNING'}, report("Linked light data is read-only"))
            return {'CANCELLED'}
        light = obj.data
        if mode == 'IES':
            if light.type != 'POINT':
                light.type = 'POINT'
        elif mode in {'GRADIENT', 'IMAGE'}:
            target = 'SPOT' if self.is_shift else 'AREA'
            if light.type != target:
                light.type = target
        light.ch_advanced.mode = mode
        return {'FINISHED'}


class LightAssetLibraryMenuImage(Menu):
    """图像纹理选择器的资产库下拉(列出该用途下启用的资产库, 当前项打勾)"""

    bl_idname = "CH_MT_light_asset_library_image"
    bl_label = "Asset Library"

    def draw(self, context):
        _draw_library_menu(self.layout, context, 'IMAGE')


class LightAssetLibraryMenuIES(Menu):
    """IES 光域网选择器的资产库下拉(同图像选择器)"""

    bl_idname = "CH_MT_light_asset_library_ies"
    bl_label = "Asset Library"

    def draw(self, context):
        _draw_library_menu(self.layout, context, 'IES')


def _draw_library_menu(layout, context: Context, kind: str) -> None:
    """资产库菜单项(两类共用): 当前库打勾, 菜单项落 Set 算子

    库里名称是用户自定义的中文: 走算子按钮 text(翻译链安全), 不进动态枚举.
    """
    state = get_state(context)
    current = resolve_library_root(kind, getattr(state, _LIBRARY_FIELDS[kind]))[0]
    for path, name in library_roots(kind):
        item = layout.operator(LightAssetLibrarySet.bl_idname, text=name, icon='CHECKMARK' if path == current else 'BLANK1')
        item.pick_kind = kind
        item.library_path = path


class LightAssetCategoryMenuImage(Menu):
    """图像纹理选择器的分类下拉(点击分类名展开, 当前项打勾, 菜单项落 Set 算子)"""

    bl_idname = "CH_MT_light_asset_category_image"
    bl_label = "Asset Category"

    def draw(self, context):
        _draw_category_menu(self.layout, context, 'IMAGE')


class LightAssetCategoryMenuIES(Menu):
    """IES 光域网选择器的分类下拉(同图像选择器)"""

    bl_idname = "CH_MT_light_asset_category_ies"
    bl_label = "Asset Category"

    def draw(self, context):
        _draw_category_menu(self.layout, context, 'IES')


def _draw_category_menu(layout, context: Context, kind: str) -> None:
    """分类菜单项(两类共用): 扫描当前选中资产库, 当前分类打勾"""
    state = get_state(context)
    current = getattr(state, _category_field(kind), "")
    for name in list_categories(_asset_root(state, kind)):
        item = layout.operator(LightAssetCategorySet.bl_idname, text=name, icon='CHECKMARK' if name == current else 'BLANK1')
        item.pick_kind = kind
        item.category = name


class LightAssetCategorySet(Operator):
    """高级设置资产选择器的分类选定(下拉菜单项的落点)"""

    bl_idname = "ch.light_asset_category_set"
    bl_label = "Set Asset Category"
    bl_description = "Set the category folder of the advanced settings asset picker"
    bl_options = {'REGISTER', 'UNDO'}

    pick_kind: StringProperty(name="Kind", description="Asset kind: IMAGE or IES", default="IMAGE", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    category: StringProperty(name="Category", description="Category folder name", default="", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        kind = self.pick_kind if self.pick_kind in {'IMAGE', 'IES'} else 'IMAGE'
        setattr(get_state(context), _category_field(kind), self.category)
        return {'FINISHED'}


class LightAssetThumbCycle(Operator):
    """高级设置资产选择器的缩略图循环应用: 上一项/下一项(回环; 未选中时下一从首项起、上一从末项起)

    写选中键即触发其 update 回调应用到面板活跃灯光, 与直接点缩略图同路径.
    """

    bl_idname = "ch.light_asset_thumb_cycle"
    bl_label = "Cycle Asset Thumbnail"
    bl_description = "Apply the previous or next thumbnail in the current category (wraps around)"

    pick_kind: StringProperty(name="Kind", description="Asset kind: IMAGE or IES", default="IMAGE", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    is_next: BoolProperty(name="Next", description="Cycle forward when set, backward otherwise", default=True, options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        kind = self.pick_kind if self.pick_kind in {'IMAGE', 'IES'} else 'IMAGE'
        state = get_state(context)
        root = _asset_root(state, kind)
        categories = list_categories(root)
        category = getattr(state, _category_field(kind), "")
        if category not in categories:
            category = categories[0] if categories else ""
        assets = list_assets(root, category, kind)
        if not assets:
            self.report({'WARNING'}, report("No thumbnails in this category"))
            return {'CANCELLED'}
        pick_field = "adv_image_pick" if kind == 'IMAGE' else "adv_ies_pick"
        current_key = getattr(state, pick_field, "")
        idx = next((i for i, asset in enumerate(assets) if asset["key"] == current_key), -1)
        if idx == -1 and not self.is_next:
            idx = 0
        step = 1 if self.is_next else -1
        setattr(state, pick_field, assets[(idx + step) % len(assets)]["key"])
        return {'FINISHED'}


class LightAdvancedCleanup(Operator):
    """高级设置折叠头挂钮: 清理灯光节点树里的孤立节点(从 Light Output 反向不可达)

    Frame 是节点组织容器恒保留; 插件链在模式激活时全线接线(不会被清), 切回"无"档后的
    残留链即成孤立节点, 由本钮一键清掉. 经算子执行进撤销栈(Ctrl+Z 可回).
    """

    bl_idname = "ch.light_advanced_cleanup"
    bl_label = "Cleanup Light Nodes"
    bl_description = "Delete nodes of the light node tree that are not connected to the Light Output (plugin leftovers and stray nodes; frames are kept)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        obj = active_block(context, "lights")
        if obj is None or obj.type != 'LIGHT':
            return {'CANCELLED'}
        if obj.library is not None:
            self.report({'WARNING'}, report("Linked light data is read-only"))
            return {'CANCELLED'}
        tree = obj.data.node_tree
        if tree is None:
            return {'CANCELLED'}
        orphans = collect_orphan_nodes(obj.data)
        if not orphans:
            self.report({'INFO'}, report("No orphan nodes in the light node tree"))
            return {'CANCELLED'}
        for node in orphans:
            for child in tree.nodes:
                if child.parent == node:
                    child.parent = None
            tree.nodes.remove(node)
        # 清理后腾空的插件 Frame 一并移除(旧布局随清理自然迁移到新 Frame 组织)
        for node in list(tree.nodes):
            if node.type == 'FRAME' and node.get("ch_advanced") is not None and not any(child.parent == node for child in tree.nodes):
                tree.nodes.remove(node)
        self.report({'INFO'}, report("Cleaned {} orphan nodes").format(len(orphans)))
        return {'FINISHED'}


class LightAdvancedClearExternal(Operator):
    """高级设置外部文件路径的清除按钮: 置空后恢复缩略图选择器的控制权"""

    bl_idname = "ch.light_advanced_clear_external"
    bl_label = "Clear External File"
    bl_description = "Clear the external file path to restore asset picker control"
    bl_options = {'REGISTER', 'UNDO'}

    pick_kind: StringProperty(name="Kind", description="Asset kind: IMAGE or IES", default="IMAGE", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        kind = self.pick_kind if self.pick_kind in {'IMAGE', 'IES'} else 'IMAGE'
        obj = active_block(context, "lights")
        if obj is None or obj.type != 'LIGHT':
            return {'CANCELLED'}
        field = "image_external" if kind == 'IMAGE' else "ies_external"
        setattr(obj.data.ch_advanced, field, "")
        return {'FINISHED'}


class LightAdvancedRefreshSource(Operator):
    """高级设置来源刷新: 按优先级解析来源路径(外部路径优先/缩略图次之)并重载入到链节点"""

    bl_idname = "ch.light_advanced_refresh_source"
    bl_label = "Refresh Source"
    bl_description = "Reload the currently applied image texture or IES file into the node from its source path"
    bl_options = {'REGISTER', 'UNDO'}

    pick_kind: StringProperty(name="Kind", description="Asset kind: IMAGE or IES", default="IMAGE", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        kind = self.pick_kind if self.pick_kind in {'IMAGE', 'IES'} else 'IMAGE'
        obj = active_block(context, "lights")
        if obj is None or obj.type != 'LIGHT':
            return {'CANCELLED'}
        light = obj.data
        settings = light.ch_advanced
        marker = "IMAGE_TEX" if kind == 'IMAGE' else "IES_TEX"
        node = find_advanced_node(light, marker)
        if node is None:
            return {'CANCELLED'}
        # 来源路径解析: 外部路径优先, 空则回落缩略图选中的资产源文件
        ext = settings.image_external if kind == 'IMAGE' else settings.ies_external
        if ext:
            source = ext
        else:
            state = get_state(context)
            root = _asset_root(state, kind)
            category = getattr(state, _category_field(kind), "")
            # 分类走与绘制侧/枚举回调同款的失效回退: 首开态存储值为空, 直读会查无资产静默早退
            categories = list_categories(root)
            if not categories:
                self.report({'WARNING'}, report("No category folders in this asset library"))
                return {'CANCELLED'}
            if category not in categories:
                category = categories[0]
            assets = list_assets(root, category, kind)
            if not assets:
                # 先按空集早退再读动态枚举值: 空集读存值会产生 C 层 "matches no enum" 告警
                self.report({'WARNING'}, report("No thumbnails in this category"))
                return {'CANCELLED'}
            pick_key = getattr(state, "adv_image_pick" if kind == 'IMAGE' else "adv_ies_pick", "")
            asset = next((a for a in assets if a["key"] == pick_key), None)
            if asset is None:
                self.report({'WARNING'}, report("No thumbnails in this category"))
                return {'CANCELLED'}
            source = asset["source"]
        if kind == 'IMAGE':
            image = find_or_load_image(source)
            if image is None:
                return {'CANCELLED'}
            try:
                image.reload()
            except RuntimeError as e:
                # 文件态异常(被移走/权限): 与 image_ops/image 模块的 reload 口径一致, 友好提示不炸
                self.report({'WARNING'}, str(e))
            node.image = image
        else:
            node.filepath = source
        return {'FINISHED'}
