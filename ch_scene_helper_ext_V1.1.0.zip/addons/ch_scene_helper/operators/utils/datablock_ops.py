"""
数据块与世界环境算子模块

提供以下功能:
- DatablockDelete: 删除灯光集合数据块并立即刷新列表
  (默认只删集合, 内容改挂 Lights/场景集合; +Shift 删除层级: 内部物体与子集合一并删)
- CollectionViewportToggle / CollectionRenderToggle: 行内"在视图中禁用/在渲染中禁用"开关
  (+Ctrl 隔离灯光集合)
- WorldUnlink: 解除世界与场景的关联(默认); Shift 点击删除世界数据块
- WorldAssign: 把指定世界指认为场景世界
- WorldNew: 新建世界并指认为场景世界
- CollectionNew: 新建灯光集合(CLS_NN_ 编号命名, 挂到 Lights 集合下)
- CollectionActivateToggle: 灯光集合的激活过滤标记
"""

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from .....common.blender.list_order import assign_order_at_end
from ...handlers import refresh_lists, tag_3d_views
from ...scene_state import all_blocks_for, get_state, highlight_item, id_collection, resolve_id
from ...utils import LIGHTS_COLLECTION_NAME, LIGHT_COLLECTION_PREFIX, apply_light_isolate_world_mute, create_light_collection, lights_isolated_by_hiding, real_user_count, relink_collection_contents, remove_collection_hierarchy, world_output_muted
from ._base import TranslatedDescriptionMixin, deletion_guard


def resolve_world_block(name: str, linked: bool):
    """按名称 + 库链接标记取世界数据块(同名本地/链接对消歧), 都不匹配返回 None

    复制链接世界会产生同名本地副本, 而 bpy.data 按名查找恒命中本地块, 行内算子
    必须按行标记消歧(与 scene_state._resolve_by_library 同口径).
    """
    world = bpy.data.worlds.get(name)
    if world is None:
        return None
    if bool(world.library) == bool(linked):
        return world
    for candidate in bpy.data.worlds:
        if candidate.name == name and bool(candidate.library) == bool(linked):
            return candidate
    return None


def resolve_collection_block(name: str, linked: bool):
    """按名称 + 库链接标记取集合数据块(同名本地/链接对消歧), 都不匹配返回 None"""
    coll = bpy.data.collections.get(name)
    if coll is None:
        return None
    if bool(coll.library) == bool(linked):
        return coll
    for candidate in bpy.data.collections:
        if candidate.name == name and bool(candidate.library) == bool(linked):
            return candidate
    return None


class DatablockDelete(Operator):
    """删除灯光集合数据块(默认只删集合; +Shift 删除层级)"""

    bl_idname = "ch.datablock_delete"
    bl_label = "Delete Collection"
    bl_description = "Delete this collection data-block\n+Shift: Also delete the objects and child collections inside"
    bl_options = {'REGISTER', 'UNDO'}

    id_name: StringProperty(name="Name", description="Name of the datablock", options={'HIDDEN'})  # type: ignore
    id_kind: StringProperty(name="Kind", description="Type of the datablock", options={'HIDDEN'})  # type: ignore
    id_linked: BoolProperty(name="Linked", description="Whether the data-block is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore
    hierarchy: BoolProperty(name="Delete Hierarchy", description="Also delete the objects and child collections inside the collection", default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        datablock = resolve_id(self.id_kind, self.id_name, self.id_linked)
        if datablock is None:
            return {'CANCELLED'}
        self.hierarchy = self.id_kind == 'COLLECTION' and event is not None and event.shift
        if datablock.library is not None:
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        if self.hierarchy:
            # 层级删除连带删内部物体与子集合, 破坏性动作: 仍有使用者时弹确认.
            # 默认只删集合(内容改挂 Lights/场景集合)可 Undo, 不需要确认
            blocked = deletion_guard(self, context, event, datablock, users_msg="Collection hierarchy delete also removes the objects and child collections inside ({} users)")
            if blocked is not None:
                return blocked
        return self.execute(context)

    def execute(self, context: Context):
        datablock = resolve_id(self.id_kind, self.id_name, self.id_linked)
        collection = id_collection(self.id_kind)
        if datablock is None or collection is None:
            return {'CANCELLED'}
        # 直调(EXEC_DEFAULT)绕过 invoke: linked 数据拒绝删; 层级删除未确认且仍有使用者时拒绝
        if datablock.library is not None:
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        if self.hierarchy:
            users = real_user_count(datablock)
            if users > 0 and not self.confirmed:
                self.report({'WARNING'}, report("Collection hierarchy delete also removes the objects and child collections inside ({} users)").format(users))
                return {'CANCELLED'}
            # 大纲"删除层级"语义: 集合内的物体与子集合一并删除
            remove_collection_hierarchy(datablock)
        else:
            # 默认只删集合数据块: 内部物体先改挂 Lights(或场景集合), 否则会孤儿化并从场景消失
            # 只认本地同名集合作回退(链接集合不可 link 成员); 无则落场景主集合
            fallback = next((child for child in context.scene.collection.children if child.name == LIGHTS_COLLECTION_NAME and child.library is None), None)
            if fallback is None or fallback is datablock:
                fallback = context.scene.collection
            relink_collection_contents(datablock, fallback)
            collection.remove(datablock, do_unlink=True)
        # 数据块移除与活跃索引夹取统一交给快照重建, 不再按 bpy.data 总数手算(过滤列表会错位)
        refresh_lists()
        return {'FINISHED'}


class CollectionActivateToggle(Operator):
    """勾选/取消勾选灯光集合的激活标记(勾选的集合过滤灯光列表, 可多选, 全不勾选显示全部)"""

    bl_idname = "ch.collection_activate_toggle"
    bl_label = "Activate Collection"
    bl_description = "Toggle this collection as the lights list filter (none checked shows all lights)"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(name="Collection", description="Name of the collection", options={'HIDDEN'})  # type: ignore
    collection_linked: BoolProperty(name="Linked", description="Whether the collection is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        coll = resolve_collection_block(self.collection_name, self.collection_linked)
        if coll is None:
            return {'CANCELLED'}
        # ch_lights_active 为插件动态注册属性(idprop-backed): 写库链接集合不抛错、
        # 会话内生效(重载即丢属已知限制, 作者 2026-10-26 实测定论, 与材质激活同款)——
        # 不做防护性拒绝, 与 row_ops 的 hide_viewport(结构体 RNA 真只读)性质不同
        coll.ch_lights_active = not coll.ch_lights_active
        return {'FINISHED'}


class _CollectionDisableMixin:
    """灯光集合行内禁用开关的共享实现(普通混入类, 不参与注册); attr 由子类指定

    视口/渲染拆成两个算子类: 同一行画两个同 bl_idname 的按钮, 重绘时按钮按名字匹配
    复用旧属性, 后设的标志会串到先画的按钮上(同 row_ops._ObjectDisableMixin).
    """

    attr = "hide_viewport"
    # 普通缺省值: 直调(EXEC_DEFAULT)绕过 invoke 时 isolate 可读(子类 RNA 声明在注册时接管)
    isolate = False

    def invoke(self, context: Context, event: Event):
        self.isolate = bool(event is not None and event.ctrl)
        return self.execute(context)

    def execute(self, context: Context):
        coll = resolve_collection_block(self.collection_name, self.collection_linked)
        if coll is None:
            return {'CANCELLED'}
        if coll.library is not None:
            # 库链接集合的 RNA 属性只读, 行内开关写入会抛 AttributeError(+Ctrl 隔离更会半完成)
            self.report({'WARNING'}, report("Linked data-block cannot be toggled"))
            return {'CANCELLED'}
        attr = self.attr
        if not self.isolate:
            setattr(coll, attr, not getattr(coll, attr))
            return {'FINISHED'}
        # +Ctrl 隔离: 目标态 = 其余集合里还有可见项 -> 隐藏它们; 已全部隐藏 -> 恢复
        # (链接集合不可写, 排除出隔离集保持原状, 防循环中途炸掉留下部分隐藏态)
        siblings = [c for c in bpy.data.collections if c.name.startswith(LIGHT_COLLECTION_PREFIX) and c is not coll and c.library is None]
        isolate_active = any(not getattr(sibling, attr) for sibling in siblings)
        for sibling in siblings:
            setattr(sibling, attr, isolate_active)
        setattr(coll, attr, False)
        if not siblings:
            # 只有这一个灯光集合: 没有同级可隐藏, 视口/渲染两档隔离都落到世界上(按世界
            # 屏蔽位记住隔离态, 再点一次即恢复), 与单灯隔离同口径(见 utils.blender.light.world_output_muted)
            isolate_active = not world_output_muted(context.scene.world)
        # 开关与灯光列表共用(props.lights_mute_world), 恢复口径见 apply_light_isolate_world_mute;
        # 聚合归位同时尊重灯光侧仍生效的隔离(只信 hide 位口径, 归属说明见 utils.lights_isolated_by_hiding)
        apply_light_isolate_world_mute(context.scene, isolate_active or lights_isolated_by_hiding(context.scene, context.view_layer), get_state(context).lights_mute_world)
        # 静音连线不触发着色器重估与视口重绘, 显式刷新
        tag_3d_views()
        return {'FINISHED'}


class CollectionViewportToggle(_CollectionDisableMixin, TranslatedDescriptionMixin, Operator):
    """行内"在视图中禁用"开关, +Ctrl 隔离灯光集合(隐藏其余集合, 再点恢复)"""

    bl_idname = "ch.collection_disable_viewport"
    bl_label = "Disable in Viewport"
    bl_description = "Toggle viewport visibility for this collection\n+Ctrl: Show only this collection among the light collections (isolate), click again to restore"
    bl_options = {'REGISTER', 'UNDO'}

    attr = "hide_viewport"
    collection_name: StringProperty(name="Collection", description="Name of the collection", options={'HIDDEN'})  # type: ignore
    collection_linked: BoolProperty(name="Linked", description="Whether the collection is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    isolate: BoolProperty(options={'HIDDEN'}, default=False, description="Isolate among the light collections instead of toggling (set by +Ctrl)")  # type: ignore


class CollectionRenderToggle(_CollectionDisableMixin, TranslatedDescriptionMixin, Operator):
    """行内"在渲染中禁用"开关, +Ctrl 隔离灯光集合(排除其余集合渲染, 再点恢复)"""

    bl_idname = "ch.collection_disable_render"
    bl_label = "Disable in Render"
    bl_description = "Toggle render exclusion for this collection\n+Ctrl: Render only this collection among the light collections (isolate), click again to restore"
    bl_options = {'REGISTER', 'UNDO'}

    attr = "hide_render"
    collection_name: StringProperty(name="Collection", description="Name of the collection", options={'HIDDEN'})  # type: ignore
    collection_linked: BoolProperty(name="Linked", description="Whether the collection is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    isolate: BoolProperty(options={'HIDDEN'}, default=False, description="Isolate among the light collections instead of toggling (set by +Ctrl)")  # type: ignore


class WorldUnlink(Operator):
    """解除世界与场景的关联(默认); Shift 点击删除世界数据块"""

    bl_idname = "ch.world_unlink"
    bl_label = "Unlink World"
    bl_description = "Unlink this world from the scene (keep the data-block)\n+Shift: Delete the world data-block directly"
    bl_options = {'REGISTER', 'UNDO'}

    world_name: StringProperty(name="World", description="Name of the world", options={'HIDDEN'})  # type: ignore
    world_linked: BoolProperty(name="Linked", description="Whether the world is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    delete: BoolProperty(name="Delete", description="Delete the world data-block instead of only unlinking it", default=False)  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.delete = bool(event is not None and event.shift)
        if self.delete:
            world = resolve_world_block(self.world_name, self.world_linked)
            if world is not None:
                blocked = deletion_guard(self, context, event, world)
                if blocked is not None:
                    return blocked
        return self.execute(context)

    def execute(self, context: Context):
        world = resolve_world_block(self.world_name, self.world_linked)
        if world is None:
            return {'CANCELLED'}
        if self.delete:
            # 直调绕过 invoke: 未确认且有场景仍在引用时拒绝删除
            if world.library is not None:
                self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
                return {'CANCELLED'}
            users = real_user_count(world)
            if users > 0 and not self.confirmed:
                self.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
                return {'CANCELLED'}
            bpy.data.worlds.remove(world, do_unlink=True)
            refresh_lists()
            return {'FINISHED'}
        if context.scene.world is not world:
            self.report({'INFO'}, report("World is not linked to the scene"))
            return {'CANCELLED'}
        context.scene.world = None
        refresh_lists()
        return {'FINISHED'}


class WorldAssign(Operator):
    """把该世界指认为场景世界"""

    bl_idname = "ch.world_assign"
    bl_label = "Assign World"
    bl_description = "Use this world as the scene world"
    bl_options = {'REGISTER', 'UNDO'}

    world_name: StringProperty(name="World", description="Name of the world", options={'HIDDEN'})  # type: ignore
    world_linked: BoolProperty(name="Linked", description="Whether the world is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        world = resolve_world_block(self.world_name, self.world_linked)
        if world is None:
            return {'CANCELLED'}
        context.scene.world = world
        highlight_item(context, "worlds", world.name, 'WORLD')
        return {'FINISHED'}


class WorldNew(Operator):
    """新建世界并指认为场景世界"""

    bl_idname = "ch.world_new"
    bl_label = "Add World"
    bl_description = "Create a new world and use it as the scene world"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        world = bpy.data.worlds.new("World")
        context.scene.world = world
        # 新建项默认追加到列表末尾(不按名称插入无顺序值组)
        assign_order_at_end(world, all_blocks_for(context, "worlds"))
        refresh_lists()
        # 高亮新建项(重名由 Blender 自动加后缀, 按真实名定位)
        highlight_item(context, "worlds", world.name)
        return {'FINISHED'}


class CollectionNew(Operator):
    """新建灯光集合(CLS_NN_ 编号命名, 挂到 Lights 集合下)"""

    bl_idname = "ch.collection_new"
    bl_label = "Add Collection"
    bl_description = "Create a new light collection (auto-numbered CLS_NN_) inside the Lights collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        # 编号自动检测与挂靠(Lights 父集合)见 utils.create_light_collection: 灯光整理
        # 算子无集合时也要走同一条创建路径
        new_coll = create_light_collection(context.scene)
        # 新建项默认追加到列表末尾(不按名称插入无顺序值组)
        assign_order_at_end(new_coll, all_blocks_for(context, "light_collections"))
        refresh_lists()
        # 高亮新建项(重名由 Blender 自动加后缀, 按真实名定位)
        highlight_item(context, "light_collections", new_coll.name)
        return {'FINISHED'}
