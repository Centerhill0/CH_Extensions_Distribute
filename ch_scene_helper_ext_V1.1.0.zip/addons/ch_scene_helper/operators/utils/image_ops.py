"""
图像资源维护算子模块

提供以下功能:
- ImageSelectUsers: 选中材质里引用该图像的全部物体
- IesSelectLights: 选中 IES 节点引用了该 IES 资源的灯光(图像列表 IES 行首)
- ImageOpen: 打开图像文件(转发原生 image.open), 载入完成后图像列表高亮新条目
- ImageRelocate: 打开文件浏览器重定位单张图像(行内载入状态标记点击)
- ImageDelete: 解除图像引用(默认)或删除图像数据块(+Shift); 库链接图像两档都拒绝
- ImagePack / ImageUnpack: 打包/解包
- ImageReloadAll / ImageSaveAll: 批量重载与保存
- ImageRename: 按引用文件名重命名
- ImageMerge: 把重复图像(name.001)在节点里并回原图
- ImageReplace: 替换节点里对旧图的引用

算法在 utils.blender.image, 本模块只做上下文交互与报告.
"""

import os

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...handlers import expect_image_import, refresh_lists
from ...scene_state import get_state, highlight_item
from ...utils import find_image_users, find_ies_lights, merge_duplicate_images, real_user_count, reload_external_images, rename_image_from_file, replace_image_reference, select_only, unlink_image_references
from ._base import deletion_guard


def _active_image_item(context: Context):
    """图像列表当前活跃条目; 无有效活跃项返回 None"""
    state = get_state(context)
    idx = state.images_active_index
    if not 0 <= idx < len(state.images):
        return None
    return state.images[idx]


def _active_image_name(context: Context) -> str:
    """图像列表当前活跃项的真实名; 无有效活跃项或数据块已删时返回空串"""
    item = _active_image_item(context)
    if item is None:
        return ""
    name = item.src_name
    return name if bpy.data.images.get(name) is not None else ""


def _get_image(op: Operator, name: str, warn: bool = False):
    """按名称取图像; 不存在时按需报告并返回 None"""
    img = bpy.data.images.get(name)
    if img is None and warn:
        op.report({'WARNING'}, report("Image not found"))
    return img


def _get_image_by_library(name: str, linked: bool):
    """按名称 + 库链接标记取图像数据块(同名本地/链接对消歧), 都不匹配返回 None

    复制链接图像会产生同名本地副本, 而 bpy.data 按名查找恒命中本地块, 行内算子
    必须按行标记消歧(与 scene_state._resolve_by_library 同口径).
    """
    img = bpy.data.images.get(name)
    if img is None:
        return None
    if bool(img.library) == bool(linked):
        return img
    for candidate in bpy.data.images:
        if candidate.name == name and bool(candidate.library) == bool(linked):
            return candidate
    return None


class ImageSelectUsers(Operator):
    """选中材质里引用该图像的全部物体"""

    bl_idname = "ch.image_select_users"
    bl_label = "Select Users"
    bl_description = "Select all objects whose materials use this image"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image", description="Name of the image datablock", options={'HIDDEN'})  # type: ignore
    image_linked: BoolProperty(name="Linked", description="Whether the image is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        img = _get_image_by_library(self.image_name, self.image_linked)
        if img is None:
            self.report({'WARNING'}, report("Image not found"))
            return {'CANCELLED'}
        highlight_item(context, "images", img.name)
        users = find_image_users(context.scene, img)
        if not users:
            self.report({'INFO'}, report("No objects use this image"))
            return {'FINISHED'}
        select_only(context, users)
        return {'FINISHED'}


class ImageOpen(Operator):
    """打开图像文件(转发原生 image.open), 载入完成后图像列表高亮新条目"""

    bl_idname = "ch.image_open"
    bl_label = "Open Image"
    bl_description = "Open image file(s); newly imported entries are highlighted in the images list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return bpy.ops.image.open.poll()

    def invoke(self, context: Context, event: Event):
        # 文件对话框异步载入, 算子拿不到完成时机: 先登记现有图像名集合, 快照重建按差集高亮
        expect_image_import()
        return bpy.ops.image.open('INVOKE_DEFAULT')

    def execute(self, context: Context):
        # 直调(EXEC_DEFAULT)无文件对话框: 原生算子按缺省 filepath 报错, 口径与原生一致
        return bpy.ops.image.open('EXEC_DEFAULT')


class ImagePack(Operator):
    """把图像打包进 .blend"""

    bl_idname = "ch.image_pack"
    bl_label = "Pack Image"
    bl_description = "Pack this image into the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image", description="Name of the image datablock", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        img = _get_image(self, self.image_name)
        if img is None:
            return {'CANCELLED'}
        try:
            img.pack()
        except RuntimeError as e:
            self.report({'WARNING'}, report("Pack failed: {}").format(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class ImageUnpack(Operator):
    """把已打包图像解包到磁盘"""

    bl_idname = "ch.image_unpack"
    bl_label = "Unpack Image"
    bl_description = "Unpack this image to disk"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image", description="Name of the image datablock", options={'HIDDEN'})  # type: ignore

    def invoke(self, context: Context, event: Event):
        img = _get_image(self, self.image_name)
        if img is None:
            return {'CANCELLED'}
        # 解包固定写回原始路径, 仅当目标文件已存在、确有覆盖风险时才弹确认
        # (否则每次解包都多一次无意义的点击; 与 ImageReloadAll 的"有脏数据才确认"同口径)
        path = bpy.path.abspath(img.filepath) if img.filepath else ""
        if path and os.path.isfile(path):
            self.report({'WARNING'}, report("Unpacking writes to the original path and may overwrite it"))
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context: Context):
        img = _get_image(self, self.image_name)
        if img is None:
            return {'CANCELLED'}
        try:
            img.unpack(method='USE_ORIGINAL')
        except RuntimeError as e:
            self.report({'WARNING'}, report("Unpack failed: {}").format(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class ImageReloadAll(Operator):
    """重载全部外部图像"""

    bl_idname = "ch.image_reload_all"
    bl_label = "Reload All Images"
    bl_description = "Reload every image that references an external file"

    def invoke(self, context: Context, event: Event):
        dirty = [img for img in bpy.data.images if img.is_dirty and img.filepath]
        if not dirty:
            return self.execute(context)
        # 重载会丢弃内存中未保存的绘制/修改
        self.report({'WARNING'}, report("Reloading discards unsaved image edits"))
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: Context):
        count, _error = reload_external_images()
        screen = getattr(context, "screen", None)
        if screen is not None:
            for area in screen.areas:
                area.tag_redraw()
        self.report({'INFO'}, report("Images reloaded: {}").format(count))
        return {'FINISHED'}


class ImageSaveAll(Operator):
    """保存全部已修改图像"""

    bl_idname = "ch.image_save_all"
    bl_label = "Save All Modified"
    bl_description = "Save every modified image that has a file path"

    def execute(self, context: Context):
        if not any(img.is_dirty and img.filepath for img in bpy.data.images):
            self.report({'WARNING'}, report("No modified images to save"))
            return {'CANCELLED'}
        bpy.ops.image.save_all_modified()
        return {'FINISHED'}


class ImageRename(Operator):
    """把图像名改成引用文件名"""

    bl_idname = "ch.image_rename"
    bl_label = "Rename to File Name"
    bl_description = "Rename the image to the name of the file it references"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image", description="Name of the image datablock", options={'HIDDEN'})  # type: ignore
    image_linked: BoolProperty(name="Linked", description="Whether the image is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    keep_extension: BoolProperty(name="Keep Extension", default=True, description="Keep the file extension in the image name")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return bool(_active_image_name(context))

    def invoke(self, context: Context, event: Event):
        if not self.image_name:
            item = _active_image_item(context)
            if item is None:
                self.report({'WARNING'}, report("No image selected"))
                return {'CANCELLED'}
            # 同名本地/链接对按行标记消歧: 链接行的名称只读, 改名必失败(见 rename_image_from_file)
            self.image_name = item.src_name
            self.image_linked = bool(item.linked)
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context: Context):
        self.layout.prop(self, "keep_extension")

    def execute(self, context: Context):
        if self.image_name:
            img = _get_image_by_library(self.image_name, self.image_linked)
            if img is None:
                self.report({'WARNING'}, report("Image not found"))
                return {'CANCELLED'}
        else:
            item = _active_image_item(context)
            img = None if item is None else _get_image_by_library(item.src_name, bool(item.linked))
            if img is None:
                self.report({'WARNING'}, report("No image selected"))
                return {'CANCELLED'}
        ok, error = rename_image_from_file(img, self.keep_extension)
        if not ok:
            self.report({'WARNING'}, report("Rename failed: {}").format(error))
            return {'CANCELLED'}
        return {'FINISHED'}


class ImageMerge(Operator):
    """把重复图像(名称带 .001 后缀)在节点里并回原图"""

    bl_idname = "ch.image_merge"
    bl_label = "Merge Duplicate Images"
    bl_description = "Point image texture nodes at the original image when they use a duplicate such as name.001"
    bl_options = {'REGISTER', 'UNDO'}

    partition: StringProperty(name="Partition", default=".", description="Character that separates the name from the numeric suffix")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context: Context):
        self.layout.prop(self, "partition")

    def execute(self, context: Context):
        count, error = merge_duplicate_images(self.partition)
        if error:
            self.report({'WARNING'}, report(error))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Image references merged: {}").format(count))
        return {'FINISHED'}


class ImageReplace(Operator):
    """把所有材质图像节点里对旧图的引用换成新图"""

    bl_idname = "ch.image_replace"
    bl_label = "Replace Image"
    bl_description = "Replace every reference to the old image with another image"
    bl_options = {'REGISTER', 'UNDO'}

    old_name: StringProperty(name="Old Image", description="Current name of the image")  # type: ignore
    new_name: StringProperty(name="New Image", description="New name for the image")  # type: ignore
    all_materials: BoolProperty(name="All Materials", default=True, description="Scan every material instead of the active material only")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context: Context):
        layout = self.layout
        layout.prop_search(self, "old_name", bpy.data, "images", text="Old")
        layout.prop_search(self, "new_name", bpy.data, "images", text="New")
        layout.prop(self, "all_materials")

    def execute(self, context: Context):
        old = _get_image(self, self.old_name, warn=True)
        new = _get_image(self, self.new_name, warn=True)
        if old is None or new is None:
            return {'CANCELLED'}
        count, error = replace_image_reference(old, new, self.all_materials)
        if error:
            self.report({'WARNING'}, report(error))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Image references replaced: {}").format(count))
        return {'FINISHED'}


class IesSelectLights(Operator):
    """选中 IES 节点引用了该 IES 资源的灯光(图像列表 IES 行首, 与图像行首同款三态图标)"""

    bl_idname = "ch.ies_select_lights"
    bl_label = "Select Lights"
    bl_description = "Select the lights whose IES nodes reference this file"
    bl_options = {'REGISTER', 'UNDO'}

    ies_source: StringProperty(options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        highlight_item(context, "images", self.ies_source)
        users = find_ies_lights(context.scene, self.ies_source)
        if not users:
            self.report({'WARNING'}, report("No lights use this IES"))
            return {'FINISHED'}
        select_only(context, users)
        return {'FINISHED'}


class ImageRelocate(Operator):
    """打开文件浏览器重定位单张图像, 选定后改路径并立即载入

    服务于行内载入状态标记(有路径未载入/无路径异常); 不用原生 find_missing_files
    ——它按所选目录重映射**全场景**缺失文件, 没有单图语义(源码 BKE_bpath_missing_files_find
    作用于整个 bmain), 行内点击必须是本图这一张.
    """

    bl_idname = "ch.image_relocate"
    bl_label = "Relocate Image"
    bl_description = "Open a file browser to relocate this image and load it from the new location"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image", description="Name of the image datablock", options={'HIDDEN'})  # type: ignore
    filepath: StringProperty(name="File", subtype='FILE_PATH', description="New path of the image file")  # type: ignore

    def invoke(self, context: Context, event: Event):
        img = _get_image(self, self.image_name, warn=True)
        if img is None:
            return {'CANCELLED'}
        # 浏览器从图像当前所在目录起步(无路径时回落 .blend 所在目录)
        self.filepath = bpy.path.abspath(img.filepath) if img.filepath else ""
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        img = _get_image(self, self.image_name, warn=True)
        if img is None:
            return {'CANCELLED'}
        if not self.filepath:
            return {'CANCELLED'}
        # 选在 .blend 目录内时改写相对路径(保持随工程移动), 其余保持绝对
        try:
            img.filepath = bpy.path.relpath(self.filepath)
        except ValueError:
            img.filepath = self.filepath
        try:
            img.reload()
        except RuntimeError as e:
            self.report({'WARNING'}, report("Reload failed: {}").format(e))
            return {'CANCELLED'}
        # "立即载入"是本算子的文档契约(行内 ERROR/MARKER 档点击即载): 5.1.2 实测 reload
        # 对部分图像态只刷新文件信息, 像素缓冲惰性分配(has_data 仍 False)——访问像素缓冲
        # 强制载入(同步 tip 已加防强制载入门控, 不再代做这件事, 见 handlers._sync_image_tips)。
        # reload 对缺失/损坏文件不抛(读盘惰性), 此时缓冲为空序列——IndexError 静默回落
        try:
            _ = img.pixels[0]
        except IndexError:
            pass
        refresh_lists()
        return {'FINISHED'}


class ImageDelete(Operator):
    """解除图像引用或删除图像数据块

    默认把材质图像节点里对该图像的引用置空(用户归 0, 保留数据块, Ctrl+Z 可撤销);
    Shift 点击才真正删除图像数据块(在用图像由 Blender 自动清空节点引用).
    库链接图像两档都拒绝: 数据块来自库, 摘引用等于把库贴图从在用材质上摘掉.
    """

    bl_idname = "ch.image_delete"
    bl_label = "Unlink Image"
    bl_description = "Clear every material node reference to this image (the data-block is kept)\n+Shift: Delete the image data-block directly"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image", description="Name of the image datablock", options={'HIDDEN'})  # type: ignore
    image_linked: BoolProperty(name="Linked", description="Whether the image is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    delete: BoolProperty(name="Delete", description="Delete the image data-block instead of only clearing references", default=False)  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        # Shift 点击 = 删除数据块; invoke 直调(event 为 None)时保持默认的解除引用
        self.delete = bool(event is not None and event.shift)
        img = _get_image_by_library(self.image_name, self.image_linked)
        if img is None:
            self.report({'WARNING'}, report("Image not found"))
            return {'CANCELLED'}
        if img.library is not None:
            # 库链接图像两档都不许: Shift 删数据块会连带摘掉库里来的数据块;
            # 默认档的"解除引用"逐材质改节点, 等于把库贴图从在用材质上摘掉, 同样不许.
            # 面板侧删除按钮据此置灰(ImagesPanel._draw_delete_button).
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        if self.delete:
            blocked = deletion_guard(self, context, event, img)
            if blocked is not None:
                return blocked
        return self.execute(context)

    def execute(self, context: Context):
        img = _get_image_by_library(self.image_name, self.image_linked)
        if img is None:
            self.report({'WARNING'}, report("Image not found"))
            return {'CANCELLED'}
        # 直调(EXEC_DEFAULT)绕过 invoke: 库链接图像两档都拒绝, 口径见 invoke
        if img.library is not None:
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        if self.delete:
            # 未确认且仍有使用者时拒绝删除, 避免静默清空节点引用
            users = real_user_count(img)
            if users > 0 and not self.confirmed:
                self.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
                return {'CANCELLED'}
            bpy.data.images.remove(img, do_unlink=True)
            refresh_lists()
            return {'FINISHED'}
        count, _error = unlink_image_references(img)
        # 用户数变化可能触碰"显示0用户"过滤口径, 重建一次快照
        refresh_lists()
        if count == 0:
            self.report({'INFO'}, report("No material nodes use this image"))
            return {'FINISHED'}
        self.report({'INFO'}, report("Image references cleared: {}").format(count))
        return {'FINISHED'}
