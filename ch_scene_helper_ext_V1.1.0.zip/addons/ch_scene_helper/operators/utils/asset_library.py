"""
资产库列表操作器模块

偏好面板"资产库路径"盒里库列表的增删与移位入口. 集合的增删改都由偏好模块的属主方法执行
(add_asset_library / remove_asset_library / move_asset_library)——偏好是全局设置,
面板与算子层不得直接写(规范17), 写入点收敛在 preference.py.

操作流程:
- 添加: 打开文件浏览器选定目录 -> 以目录末级名建库(名称随路径同步)

提供以下功能:
- CHSceneHelperAssetLibraryAdd: 选定目录并追加资产库
- CHSceneHelperAssetLibraryRemove: 移除当前选中的资产库
- CHSceneHelperAssetLibraryEnabledToggle: 行末启用图标, 翻转该行是否进选择器菜单
- CHSceneHelperAssetLibraryMoveUp / MoveDown: 选中行上移/下移一格
"""

import os

import bpy
from bpy.props import BoolProperty, IntProperty, StringProperty
from bpy.types import Context, Operator

from .....common.i18n.i18n import report
from ...preference import get_prefs


def _selected_dir(path: str) -> str:
    """校验并归一文件浏览器回填的目录(空串/指向文件/不存在均视为未选定, 返回空串)

    相对 // 前缀路径在当前未存盘时无法判定, 按已选定原样接受.
    """
    if not path:
        return ""
    if path.startswith("//"):
        return path
    absolute = bpy.path.abspath(path)
    return path if os.path.isdir(absolute) else ""


class CHSceneHelperAssetLibraryAdd(Operator):
    """添加资产库: 打开文件浏览器选定目录, 以目录名建库(同一目录不重复追加)"""

    bl_idname = "ch.asset_library_add"
    bl_label = "Add Asset Library"
    bl_description = "Pick a directory and add it as an asset library (the folder name becomes the library name)"

    directory: StringProperty(name="Directory", subtype='DIR_PATH', options={'SKIP_SAVE'})  # type: ignore
    filter_folder: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def invoke(self, context: Context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        path = _selected_dir(self.directory)
        if not path:
            self.report({'WARNING'}, report("No directory selected"))
            return {'CANCELLED'}
        prefs = get_prefs()
        existing = prefs.find_asset_library(path)
        if existing >= 0:
            # 同一目录已在列表里: 不追加重复行, 只把活跃项指过去并提示
            prefs.set_active_asset_library(existing)
            self.report({'INFO'}, report("This asset library is already in the list"))
            return {'CANCELLED'}
        prefs.add_asset_library(path=path)
        return {'FINISHED'}


class CHSceneHelperAssetLibraryRemove(Operator):
    """移除资产库: 删除当前选中的条目(无选中项时置灰)"""

    bl_idname = "ch.asset_library_remove"
    bl_label = "Remove Asset Library"
    bl_description = "Remove the selected asset library from the list"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if get_prefs().active_asset_library() is not None:
            return True

    def execute(self, context: Context):
        prefs = get_prefs()
        if prefs.active_asset_library() is None:
            return {'CANCELLED'}
        prefs.remove_asset_library(prefs.asset_libraries_active_index)
        return {'FINISHED'}


class CHSceneHelperAssetLibraryEnabledToggle(Operator):
    """资产库启用开关: 翻转该行是否出现在选择器的库菜单里"""

    bl_idname = "ch.asset_library_enabled_toggle"
    bl_label = "Toggle Asset Library Enabled"
    bl_description = "Include this asset library in the pickers; turn off to keep it in the list but hide it from the menus"

    index: IntProperty(name="Index", default=0, options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        get_prefs().toggle_asset_library_enabled(self.index)
        return {'FINISHED'}


class _MoveAssetLibraryMixin:
    """上移/下移共用实现: 子类声明 offset(-1 上移 / +1 下移)"""

    offset: int = -1

    @classmethod
    def poll(cls, context: Context):
        prefs = get_prefs()
        # 首行不能上移、末行不能下移: 按钮随位置置灰
        if 0 <= prefs.asset_libraries_active_index + cls.offset < len(prefs.asset_libraries):
            return True

    def execute(self, context: Context):
        prefs = get_prefs()
        prefs.move_asset_library(prefs.asset_libraries_active_index, self.offset)
        return {'FINISHED'}


class CHSceneHelperAssetLibraryMoveUp(_MoveAssetLibraryMixin, Operator):
    """资产库上移: 与上一行互换位置"""

    bl_idname = "ch.asset_library_move_up"
    bl_label = "Move Asset Library Up"
    bl_description = "Move the selected asset library one row up"
    bl_options = {'REGISTER', 'UNDO'}

    offset = -1


class CHSceneHelperAssetLibraryMoveDown(_MoveAssetLibraryMixin, Operator):
    """资产库下移: 与下一行互换位置"""

    bl_idname = "ch.asset_library_move_down"
    bl_label = "Move Asset Library Down"
    bl_description = "Move the selected asset library one row down"
    bl_options = {'REGISTER', 'UNDO'}

    offset = 1
