import bpy

from .config import __addon_name__
from .i18n.dictionary import dictionary
from ...common.class_loader import auto_load
from ...common.class_loader.auto_load import add_properties, remove_properties
from ...common.i18n.dictionary import common_dictionary
from ...common.i18n.i18n import load_dictionary
from .keymaps import register_keymaps, unregister_keymaps
from .props import CameraResolutionSettings, LightAdvancedSettings, SceneHelperState, SceneResolutionState
from .scene_state import STATE_PROP
from .utils import release_previews
from .utils.drawing import remove_all_view_draws

# You may declare properties like following, framework will automatically add and remove them.
# Do not define your own property group class in the __init__.py file. Define it in a separate file and import it here.
# 注意不要在__init__.py文件中自定义PropertyGroup类.请在单独的文件中定义它们并在此处导入.
_addon_properties = {
    # WM 级场景资源列表快照(相机/灯光/材质/世界/图像), 不随 .blend 保存
    bpy.types.WindowManager: {
        STATE_PROP: bpy.props.PointerProperty(type=SceneHelperState),
    },
    # Object/Material/World/Image/Collection 的 ch_scene_order 为**纯遮蔽注册**
    # (排序值读写仍走数据块自定义属性裸通道; 同名运行期 RNA 使其不进"自定义属性"面板,
    # 见 rna_prop_ui 对 is_runtime 同名键的 "API Defined" 过滤; 对齐 ch_ai_order 的处理。
    # 注意 5.1.2 实测同名 RNA 与裸 idprop 两套存储互不互通, 顺序值禁走 RNA 通道读写)
    # ch_rig_init_distance(rig 初始距离, 读写同走裸 idprop 通道)同属纯遮蔽注册
    bpy.types.Object: {
        "ch_resolution": bpy.props.PointerProperty(type=CameraResolutionSettings),
        "ch_scene_order": bpy.props.IntProperty(),
        "ch_rig_init_distance": bpy.props.FloatProperty(),
    },
    # 灯光高级设置状态(灯光数据块级, 随 .blend 保存; 多物体共享数据块时同步生效)
    bpy.types.Light: {
        "ch_advanced": bpy.props.PointerProperty(type=LightAdvancedSettings),
    },
    bpy.types.Scene: {
        "ch_res_state": bpy.props.PointerProperty(type=SceneResolutionState),
    },
    bpy.types.Collection: {
        "ch_lights_active": bpy.props.BoolProperty(name="Lights Active", default=False),
        "ch_scene_order": bpy.props.IntProperty(),
    },
    bpy.types.Material: {
        "ch_material_active": bpy.props.BoolProperty(name="Material Active", default=False),
        "ch_scene_order": bpy.props.IntProperty(),
    },
    bpy.types.World: {
        "ch_scene_order": bpy.props.IntProperty(),
    },
    bpy.types.Image: {
        "ch_scene_order": bpy.props.IntProperty(),
    },
}


def register():
    """注册插件"""
    # Register classes
    auto_load.init()
    auto_load.register()

    register_keymaps()

    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(__addon_name__))


def unregister():
    """注销插件"""
    # 先摘快捷键与 WM 指针属性, 再注销类: 指针属性引用 SceneHelperState,
    # 若类先注销, WM 上会残留指向已注销类型的属性.
    unregister_keymaps()
    # 视图绘制回调兜底清空: 模态异常退出可能留下轨迹预览处理器,
    # 不摘除会在注销后继续按帧访问已失效模块
    remove_all_view_draws()
    # 资产选择器的文件级预览集合整体释放(条目与图标归还 Blender, 注销后不再绘制)
    release_previews()
    remove_properties(_addon_properties)

    # Internationalization
    bpy.app.translations.unregister(__addon_name__)

    # unRegister classes
    auto_load.unregister()
    print("{} addon is uninstalled.".format(__addon_name__))
