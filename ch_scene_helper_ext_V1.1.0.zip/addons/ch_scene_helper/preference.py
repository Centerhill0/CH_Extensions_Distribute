"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(灯光控制模态参数 / 资产库列表 / 快捷键)
- CHAssetLibrary: 资产库条目(根目录 + 用途标签, 决定其出现在哪些选择器)
- CH_UL_asset_libraries: 资产库列表行(目录名 + 用途下拉 + 末位激活开关)
- get_prefs: 取本插件偏好实例
- library_roots / resolve_library_root: 按用途取可用资产库, 以及选中库的根目录解析
- LIBRARY_PURPOSE_ITEMS: 用途枚举(单选: 纹理 / IES / PBR 材质 / 世界环境纹理)

面板为左右两列布局(不再分页签):
- 左列: Light Control(灯光控制模态的区域归一幅度与精确比率 + 轨迹预览总开关与线型参数,
  线型参数仅在总开关打开时绘制)与 Light & Shadow Linking(预览三色与线宽)
- 右列: 资产库路径(库列表 + 上移/下移 + 选中库的路径, 及缩略图尺寸)在上,
  本插件已注册的快捷键列表(饼菜单 + 灯光控制)在下

注: 列表的"选区同步"与"显示0用户"开关在面板选项菜单内,
状态存 WM 级 SceneHelperState, 不随 .blend 保存.
"""

import os
from math import radians

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Context, KeyConfig, PropertyGroup, UIList, UILayout
from rna_keymap_ui import draw_kmi

from .config import __addon_name__
from .keymaps import addon_keymaps

# 资产库列表算子的 bl_idname: 偏好 draw 与算子模块共用(偏好 → 算子会循环导入, 以常量单向引用)
ASSET_LIBRARY_ADD_OP = "ch.asset_library_add"
ASSET_LIBRARY_REMOVE_OP = "ch.asset_library_remove"
ASSET_LIBRARY_MOVE_UP_OP = "ch.asset_library_move_up"
ASSET_LIBRARY_MOVE_DOWN_OP = "ch.asset_library_move_down"
ASSET_LIBRARY_TOGGLE_OP = "ch.asset_library_enabled_toggle"

# 用途枚举(标识即选择器种类, 一个库只归一种用途): 前两档已接入选择器, 后两档待其面板落地
LIBRARY_PURPOSE_ITEMS = (
    ('IMAGE', "Texture", "Offer this library in the image texture picker of the light advanced settings"),
    ('IES', "IES", "Offer this library in the IES profile picker of the light advanced settings"),
    ('PBR', "PBR Material", "Offer this library in the PBR material picker (not available yet)"),
    ('WORLD', "World Environment", "Offer this library in the world environment texture picker (not available yet)"),
)

# 用途标识集合(校验外部传入的用途)
LIBRARY_PURPOSE_KINDS = tuple(identifier for identifier, _name, _description in LIBRARY_PURPOSE_ITEMS)

# 资产库名在列表行内的截断上限(每帧布局, 长文本会拖慢偏好面板)
_LIBRARY_NAME_MAX = 32


def _is_library_dir(path: str) -> bool:
    """路径是否为现存目录(空串/相对 // 路径在当前未存盘时无法判定, 按存在处理不误报)"""
    if not path:
        return False
    if path.startswith("//"):
        return True
    return os.path.isdir(bpy.path.abspath(path))


def asset_library_name(path: str, fallback: str = "") -> str:
    """由目录路径派生库名(取末级目录名; 路径为空/无末级段时用 fallback)"""
    if not path:
        return fallback
    name = os.path.basename(os.path.normpath(bpy.path.abspath(path).rstrip("/\\")))
    return name if name not in {"", ".", ".."} else fallback


def _truncate(text: str, limit: int) -> str:
    """列表行文本截断(超出上限补省略号)"""
    return text if len(text) <= limit else text[:limit] + "..."


def _path_key(path: str) -> str:
    """路径比较键(去重判据): 绝对化 + 规范化 + 大小写归一; 空串返回空串"""
    if not path:
        return ""
    return os.path.normcase(os.path.normpath(bpy.path.abspath(path)))


def _on_library_path_update(self, context: Context):
    """路径变更时以目录末级名同步库名(列表名称即资产库文件夹名)"""
    name = asset_library_name(self.path, "")
    if name:
        self.name = name


def library_roots(kind: str) -> list:
    """某用途下的可用资产库 [(根目录, 名称)]

    判据: 启用 + 用途归该档 + 已填路径, 保持偏好列表顺序; 未知用途返回空表.
    """
    if kind not in LIBRARY_PURPOSE_KINDS:
        return []
    return [(lib.path, lib.name) for lib in get_prefs().asset_libraries if lib.enabled and lib.purpose == kind and lib.path]


def resolve_library_root(kind: str, selected: str) -> tuple:
    """按选中的根目录解析 (根目录, 名称): 空/失效(库被删、禁用或改了路径)回落该用途首个可用库

    无可用库返回 ("", ""), 调用方按"未配目录"画提示行.
    """
    roots = library_roots(kind)
    if not roots:
        return "", ""
    for path, name in roots:
        if path == selected:
            return path, name
    return roots[0]


def _draw_hotkey_column(layout: UILayout, title: str, icon: str, groups: list, kc: KeyConfig) -> None:
    """绘制单列快捷键分组列表"""
    col = layout.box()
    col.label(text=title, icon=icon)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            try:
                draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
            except (ReferenceError, AttributeError, ValueError):
                # 用户在本页删除快捷键后, 保存的 kmi 句柄会失效; 跳过该行而不是让整页绘制崩溃
                split.label(text="(removed)")
        row.separator(factor=1, type='LINE')


class CHAssetLibrary(PropertyGroup):
    """资产库条目: 一个根目录 + 启用开关 + 用途标签

    目录约定 = <根>/<分类>/ 顶层 PNG 为缩略图, Textures/ 或 IES/ 子目录内同名文件为源.
    名称不由用户手填, 而是随路径同步为目录末级名(列表名称即资产库文件夹名).
    用途标签决定该库出现在哪个面板的选择器里(PBR 材质与世界环境纹理两档的面板尚未落地,
    标签先可配置, 待对应选择器接入后即生效).
    """

    name: StringProperty(name="Name", description="Name shown in the asset library menu of the pickers")  # type: ignore
    path: StringProperty(
        name="Path",
        description="Root directory of this asset library: category subfolders, top-level PNG thumbnails, same-name source files in the Textures or IES subfolder",
        subtype='DIR_PATH',
        update=_on_library_path_update,
    )  # type: ignore
    enabled: BoolProperty(name="Enabled", description="Include this asset library in the pickers; turn off to keep it in the list but hide it from the menus", default=True)  # type: ignore
    # 用途单选: 一个库只服务一个选择器(纹理/IES 已接入, PBR 材质与世界环境纹理待其面板落地)
    purpose: EnumProperty(name="Purpose", items=LIBRARY_PURPOSE_ITEMS, default='IMAGE', description="Which picker offers this asset library")  # type: ignore


class CH_UL_asset_libraries(UIList):
    """偏好面板的资产库列表: 行内 = 目录名 + 用途下拉 + 末位启用图标(勾选/未勾选)

    路径失效/未填时只把目录名置 alert 标红, 不画警告图标也不牵连同行控件: 图标位会占一个
    图标宽度让名称离开列表左沿, alert 只染色不占位, 名称恒与左沿齐平.
    """

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        row = layout.row(align=True)
        name_row = row.row(align=True)
        name_row.alert = not _is_library_dir(item.path)
        name_row.label(text=_truncate(item.name, _LIBRARY_NAME_MAX))
        tail = row.row(align=True)
        tail.alignment = 'RIGHT'
        tail.prop(item, "purpose", text="", emboss=False)
        toggle = tail.operator(ASSET_LIBRARY_TOGGLE_OP, text="", icon='CHECKBOX_HLT' if item.enabled else 'CHECKBOX_DEHLT', emboss=False)
        toggle.index = idx


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    # 灯光控制模态的区域归一幅度与 Shift 精确比率
    light_rig_angle_sweep: bpy.props.FloatProperty(
        name="Angle Sweep",
        description="Rotation for azimuth / elevation / self rotation while the mouse crosses the full region width (modal L)",
        subtype='ANGLE',
        default=radians(180.0),
        min=0.0,
    )  # type: ignore
    light_rig_power_span: bpy.props.FloatProperty(
        name="Power Span",
        description="Brightness change while the mouse crosses the full region width (modal L)",
        subtype='POWER',
        default=1000.0,
        min=0.0,
    )  # type: ignore
    light_rig_distance_span: bpy.props.FloatProperty(
        name="Distance Span",
        description="Distance change while the mouse crosses the full region width (modal L)",
        subtype='DISTANCE',
        default=5.0,
        min=0.0,
    )  # type: ignore
    light_rig_shift_factor: bpy.props.FloatProperty(
        name="Precise Factor",
        description="Adjustment rate multiplier while Shift is held (modal L)",
        subtype='FACTOR',
        default=0.5,
        min=0.01,
        max=1.0,
    )  # type: ignore

    # 模态 A/D 档的轨迹预览(方位圆环 + 高度大圆): 总开关与线型参数
    light_rig_show_preview: bpy.props.BoolProperty(
        name="Trajectory Preview",
        description="Draw the trajectory preview (azimuth ring and elevation great circle) in the 3D view while adjusting (modal L, A and D modes)",
        default=True,
    )  # type: ignore
    light_rig_preview_azimuth_color: bpy.props.FloatVectorProperty(
        name="Azimuth Track Color",
        description="Color of the horizontal azimuth ring and the plain tick marks",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 0.0),
    )  # type: ignore
    light_rig_preview_elevation_color: bpy.props.FloatVectorProperty(
        name="Elevation Track Color",
        description="Color of the elevation great circle",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.0, 1.0, 1.0),
    )  # type: ignore
    # 半径连线(控制器 -> 灯)的颜色: 独立偏好, 不再复用轨迹色(默认即手调后的现行连线色)
    light_rig_preview_spoke_color: bpy.props.FloatVectorProperty(
        name="Spoke Color",
        description="Color of the radius line from the controller to the light",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.0, 1.0, 1.0),
    )  # type: ignore
    # 轨迹线最远端的 alpha 终点(近端写死 1.0 不透明): 偏好是衰减终点的唯一出处
    light_rig_preview_track_dim: bpy.props.FloatProperty(
        name="Track Dim",
        description="Alpha of the trajectory lines at the point farthest from the light (the nearest end is always opaque)",
        subtype='FACTOR',
        default=0.1,
        min=0.0,
        max=1.0,
    )  # type: ignore
    light_rig_preview_line_width: bpy.props.FloatProperty(
        name="Track Line Width",
        description="Preview line width in pixels",
        subtype='PIXEL',
        default=2.0,
        min=0.5,
        max=5.0,
    )  # type: ignore
    light_rig_preview_show_ticks: bpy.props.BoolProperty(
        name="Reference Ticks",
        description="Draw tick dots on both tracks; the four axis ticks (0/90/180/270 degrees) use the X/Y/Z axis colors",
        default=True,
    )  # type: ignore
    # 键名由 light_rig_preview_tick_step 改为 ..._tick_angle: 从"整数度"改成 ANGLE 子类型
    # (内部弧度、界面显示度). 沿用旧键会让已存的 15 被当成 15 弧度并钳到上限 90°, 故换名
    # 让新键按默认值 30° 起步
    light_rig_preview_tick_angle: bpy.props.FloatProperty(
        name="Tick Interval",
        description="Degrees between tick marks on the trajectory",
        subtype='ANGLE',
        default=radians(30.0),
        min=radians(1.0),
        max=radians(90.0),
    )  # type: ignore
    # 刻度显示厚度的单一来源: 直径 = 轨迹线宽 x 该系数(正轴恒为其 1.5 倍), 替代算子侧硬编码倍率
    light_rig_preview_tick_scale: bpy.props.FloatProperty(
        name="Tick Scale",
        description="Tick dot diameter relative to the trajectory line width; the four axis ticks are always 1.5 times the regular ticks",
        # subtype='FACTOR',
        default=3.0,
        min=1.0,
        max=5.0,
    )  # type: ignore
    light_rig_preview_xray: bpy.props.BoolProperty(
        name="Always in Front",
        description="Draw the preview over the scene objects; turn off to let the geometry hide it",
        default=True,
    )  # type: ignore

    # 资产库列表(高级设置图像/IES 选择器的扫描来源): 每个库一个根目录 + 用途标签
    asset_libraries: CollectionProperty(name="Asset Libraries", type=CHAssetLibrary)  # type: ignore
    asset_libraries_active_index: IntProperty(name="Active Asset Library", default=0)  # type: ignore
    # 资产选择器缩略图尺寸: 图像纹理与 IES 两选择器共用同一设置
    asset_thumb_size: bpy.props.FloatProperty(
        name="Thumbnail Size",
        description="Size of the thumbnails in the asset picker",
        default=4.0,
        min=2.0,
        max=16.0,
        precision=1,
    )  # type: ignore
    # 放大镜弹窗(大网格)的格子相对行内网格的放大系数: template_icon_view 的 scale_popup = scale x 该系数
    asset_thumb_popup_factor: bpy.props.FloatProperty(
        name="Popup Zoom",
        description="Size of the thumbnail cells in the popup grid relative to the inline grid",
        default=1.2,
        min=1.0,
        max=6.0,
        precision=1,
    )  # type: ignore
    # 灯光&阴影链接预览(饼菜单四钮): 三色语义 = 接入且激活按测分色(黄/紫), 接入未激活统一取偏好单色(默认淡绿)
    light_linking_preview_receiver_color: bpy.props.FloatVectorProperty(
        name="Light Link Color",
        description="Color of the light linking preview lines and bounding box wireframes for included members",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 0.85, 0.0),
    )  # type: ignore
    light_linking_preview_blocker_color: bpy.props.FloatVectorProperty(
        name="Shadow Link Color",
        description="Color of the shadow linking preview lines and bounding box wireframes for included members",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.65, 0.35, 0.85),
    )  # type: ignore
    light_linking_preview_inactive_color: bpy.props.FloatVectorProperty(
        name="Inactive Link Color",
        description="Color for preview lines and wireframes of members that are in the linking collection but currently excluded",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.40, 0.70, 0.40),
    )  # type: ignore
    light_linking_preview_line_width: bpy.props.FloatProperty(
        name="Preview Line Width",
        description="Line width of the light linking preview lines and bounding box wireframes",
        subtype='PIXEL',
        default=1.5,
        min=0.5,
        max=6.0,
    )  # type: ignore

    def find_asset_library(self, path: str) -> int:
        """按根目录查找已有资产库, 返回列表下标(空路径/无匹配返回 -1)"""
        key = _path_key(path)
        if not key:
            return -1
        for index, lib in enumerate(self.asset_libraries):
            if _path_key(lib.path) == key:
                return index
        return -1

    def add_asset_library(self, path: str = "", name: str = "", purpose: str = 'IMAGE') -> CHAssetLibrary:
        """在列表末尾追加一个资产库并设为活跃项(偏好集合增删的属主方法之一)

        名称缺省取目录末级名(列表名称即资产库文件夹名); 路径为空时退到递增默认名.
        purpose 取 LIBRARY_PURPOSE_KINDS 之一, 非法值回落纹理档.
        同一根目录已在列表里时不重复追加: 直接把活跃项指向既有条目并原样返回它.
        """
        existing = self.find_asset_library(path)
        if existing >= 0:
            self.asset_libraries_active_index = existing
            return self.asset_libraries[existing]
        lib = self.asset_libraries.add()
        # 路径先写: 其 update 回调会把库名同步成目录名, 显式传入的 name 随后覆盖它
        lib.path = path
        lib.name = name or asset_library_name(path) or self._unused_library_name()
        lib.purpose = purpose if purpose in LIBRARY_PURPOSE_KINDS else 'IMAGE'
        self.asset_libraries_active_index = len(self.asset_libraries) - 1
        return lib

    def remove_asset_library(self, index: int) -> None:
        """移除指定资产库并把活跃索引夹回有效范围(越界索引直接忽略)"""
        if not 0 <= index < len(self.asset_libraries):
            return
        self.asset_libraries.remove(index)
        self.asset_libraries_active_index = max(0, min(self.asset_libraries_active_index, len(self.asset_libraries) - 1))

    def move_asset_library(self, index: int, offset: int) -> None:
        """把指定行与相邻行互换(offset=-1 上移 / +1 下移), 越界不动且活跃索引跟随

        集合本身不重排(bpy_prop_collection 无 move), 交换两行的有效载荷即等价于换位.
        """
        target = index + offset
        if not (0 <= index < len(self.asset_libraries)) or not (0 <= target < len(self.asset_libraries)):
            return
        fields = ("path", "name", "enabled", "purpose")
        first, second = self.asset_libraries[index], self.asset_libraries[target]
        payload_first = [getattr(first, field) for field in fields]
        payload_second = [getattr(second, field) for field in fields]
        for field, value in zip(fields, payload_second):
            setattr(first, field, value)
        for field, value in zip(fields, payload_first):
            setattr(second, field, value)
        self.asset_libraries_active_index = target

    def set_active_asset_library(self, index: int) -> None:
        """把活跃索引指向指定行(越界夹到有效范围; 空列表不动)"""
        if not self.asset_libraries:
            return
        self.asset_libraries_active_index = max(0, min(index, len(self.asset_libraries) - 1))

    def toggle_asset_library_enabled(self, index: int) -> None:
        """翻转指定行的启用开关(越界索引直接忽略)"""
        if not 0 <= index < len(self.asset_libraries):
            return
        lib = self.asset_libraries[index]
        lib.enabled = not lib.enabled

    def active_asset_library(self):
        """当前选中行对应的资产库条目(索引越界返回 None)"""
        idx = self.asset_libraries_active_index
        return self.asset_libraries[idx] if 0 <= idx < len(self.asset_libraries) else None

    def _unused_library_name(self) -> str:
        """递增取一个未占用的默认库名(路径为空的新条目用)"""
        existing = {item.name for item in self.asset_libraries}
        name = "Asset Library"
        suffix = 1
        while name in existing:
            name = "Asset Library.{:03d}".format(suffix)
            suffix += 1
        return name

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 左右两列: 左列参数设置, 右列资产库(上)与快捷键(下)
        split = layout.split(factor=0.5)

        # 左列: 灯光控制模态参数
        left = split.column()
        box = left.box()
        box.label(text="Light Control", icon='ORIENTATION_GIMBAL')
        box.use_property_split = True
        box.use_property_decorate = False
        box.prop(self, "light_rig_angle_sweep", text="Angle Sweep")
        box.prop(self, "light_rig_power_span", text="Power Span")
        box.prop(self, "light_rig_distance_span", text="Distance Span")
        box.prop(self, "light_rig_shift_factor", text="Precise Factor")
        # 轨迹预览开关紧跟精确比率; 关闭时整组线型参数**不绘制**(而非置灰)
        box.prop(self, "light_rig_show_preview")
        if self.light_rig_show_preview:
            box = box.box()
            box.prop(self, "light_rig_preview_xray", text="Always in Front")
            box.prop(self, "light_rig_preview_azimuth_color", text="Azimuth Track Color")
            box.prop(self, "light_rig_preview_elevation_color", text="Elevation Track Color")
            box.prop(self, "light_rig_preview_spoke_color", text="Spoke Color")
            box.prop(self, "light_rig_preview_line_width", text="Track Line Width")
            box.prop(self, "light_rig_preview_track_dim", text="Track Dim")
            row = box.row(heading="Reference Ticks")
            row.prop(self, "light_rig_preview_show_ticks", text="")
            sub_row = row.row(align=True)
            sub_row.active = self.light_rig_preview_show_ticks
            sub_row.prop(self, "light_rig_preview_tick_angle", text="Tick Interval")
            sub_row.prop(self, "light_rig_preview_tick_scale", text="Tick Scale")

        box = left.box()
        box.label(text="Light & Shadow Linking", icon='LINKED')
        box.use_property_split = True
        box.use_property_decorate = False
        box.prop(self, "light_linking_preview_receiver_color", text="Light Link Color")
        box.prop(self, "light_linking_preview_blocker_color", text="Shadow Link Color")
        box.prop(self, "light_linking_preview_inactive_color", text="Inactive Link Color")
        box.prop(self, "light_linking_preview_line_width", text="Preview Line Width")

        # 右列: 资产库路径(在上) + 快捷键列表(在下)
        right = split.column()
        _draw_asset_library_box(right, self)
        groups = [(name, items) for name, items in addon_keymaps.items()]
        _draw_hotkey_column(right, "Hotkeys", "KEY_COMMAND", groups, kc)


def _draw_asset_library_box(layout: UILayout, prefs: CHSceneHelperPreferences) -> None:
    """资产库路径盒: 库列表(+/-/上移/下移) + Path / 缩略图尺寸 / 弹窗放大属性行

    列表区不参与属性分栏(列表与按钮列占满整行); 下方属性行不置 use_property_split——
    Path 单独一行, Thumbnail Size 与 Popup Zoom 并排一行(标签与控件同行, 不做两栏排布).
    列表行为"目录名 + 用途单选下拉 + 激活开关"(见 CH_UL_asset_libraries).
    """
    box = layout.box()
    box.label(text="Asset Library Paths", icon='FILE_FOLDER')
    box.use_property_decorate = False
    row = box.row()
    # UIList 的 template_list 标识是类名(UIList 没有默认 bl_idname), 与本模块 CH_UL_asset_libraries 同名
    row.template_list("CH_UL_asset_libraries", "", prefs, "asset_libraries", prefs, "asset_libraries_active_index", rows=4)
    buttons = row.column(align=True)
    buttons.operator(ASSET_LIBRARY_ADD_OP, text="", icon='ADD')
    buttons.operator(ASSET_LIBRARY_REMOVE_OP, text="", icon='REMOVE')
    buttons.separator(factor=0.5)
    buttons.operator(ASSET_LIBRARY_MOVE_UP_OP, text="", icon='TRIA_UP')
    buttons.operator(ASSET_LIBRARY_MOVE_DOWN_OP, text="", icon='TRIA_DOWN')

    lib = prefs.active_asset_library()
    if lib is None:
        hint = box.row()
        hint.enabled = False
        hint.label(text="No asset library yet", icon='INFO')
    props = box.column()
    if lib is not None:
        props.prop(lib, "path", text="Path")
    row = props.row()
    row.prop(prefs, "asset_thumb_size", text="Thumbnail Size")
    row.prop(prefs, "asset_thumb_popup_factor", text="Popup Zoom")


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
