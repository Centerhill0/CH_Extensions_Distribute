"""
场景助手资源列表模块

UIList(类名含 _UL_ 标记, 类名即 template_list 查找 id):
相机 / 灯光 / 材质 / 世界环境 / 图像 五个主列表, 外加灯光集合(CLS_ 前缀)管理列表.
数据源是 WM 级快照(SceneHelperState), 顺序由快照序决定(按 ch_scene_order 排序).

主要功能:
- 行内只有名称与状态/参数控件, 详情统一由列表面板下方的可折叠子面板显示
- 名称经快照条目的 name 属性编辑并写穿到真实数据块, 双击才进入编辑
- 名称过滤 / 字母排序 / 反序由 common.blender.list_snapshot.StandardFilterMixin 提供
  (字母排序关闭时保持快照序, 反序最后统一应用)
- 首个图标统一为"选中关联物体": 点击会选中关联物体并高亮该列表项
- 伪用户按钮统一为算子切换(图标按当前状态绘制, 点击即时刷新)
"""

import bpy
from bpy.types import Context, UIList, UILayout

from .....common.blender.list_snapshot import StandardFilterMixin, standard_filter
from ...constants import IMAGE_SOURCE_ICONS, NO_FILE_SOURCES
from ...operators.object.light_linking import LightLinkingCollectionSingleUser, LightLinkingFocusEmitter
from ...operators.utils.datablock_ops import CollectionActivateToggle, CollectionRenderToggle, CollectionViewportToggle, WorldAssign
from ...operators.utils.image_ops import ImagePack, ImageRelocate, ImageUnpack
from ...operators.utils.material_ops import MaterialActivateToggle, MaterialMerge
from ...operators.utils.row_ops import CameraSetView
from ...scene_state import LIST_KINDS, STATE_PROP, block_for_item, get_state
from ...utils import is_runtime_image, refresh_ies_users_map_cache, refresh_users_map_cache, scene_collection_names
from ._rows import (
    camera_icon,
    can_split_columns,
    draw_fake_user_count,
    draw_ies_select,
    draw_image_select,
    draw_link_state_toggle,
    draw_missing_item,
    draw_name_cell,
    draw_object_toggles,
    draw_select_button,
    light_icon,
    material_preview_icon,
)


def _pinned_image_sort_key(pair) -> tuple:
    """图像行字母排序的键: 运行期图像(恒钉最前)取 (0, 固定次序), 其余行取 (1, 名称)

    供 sort_items_helper 使用(与 standard_filter 同一助手, 顺序表契约一致);
    IES 显示行不是图像数据块, 按名称与常规行同排(与原标准行为一致).
    """
    _idx, item = pair
    image = bpy.data.images.get(item.src_name) if item.kind == 'IMAGE' else None
    if image is not None and is_runtime_image(image):
        return (0, 0 if image.type == 'RENDER_RESULT' else 1, "")
    return (1, 0, item.name.lower())


def _mirror_filter_flags(context: Context, ulist, propname: str) -> None:
    """把 UIList 漏斗开关镜像到 WM 状态(供"上移/下移"按显示顺序换算)

    template_list 的漏斗状态只存在于 UIList 实例上, 算子无法读取; 每次绘制列表时镜像
    到 scene_state 的 filter_alpha/filter_reverse 向量. 重写 filter_items 的列表
    (如灯光列表的激活过滤)必须同样调用本函数, 否则排序开关对移动算子不可见.
    """
    state = getattr(context.window_manager, STATE_PROP, None)
    if state is not None and propname in LIST_KINDS:
        idx = LIST_KINDS.index(propname)
        state.filter_alpha[idx] = bool(ulist.use_filter_sort_alpha)
        state.filter_reverse[idx] = bool(ulist.use_filter_sort_reverse)


class _SceneFilterMixin(StandardFilterMixin):
    """内建过滤/排序 + 把开关镜像到 WM 状态"""

    def filter_items(self, context: Context, data, propname: str):
        _mirror_filter_flags(context, self, propname)
        return super().filter_items(context, data, propname)


def _draw_material_row(context: Context, layout: UILayout, item, mat) -> None:
    """材质行: 激活(联动场景选中) / 合并材质 / 名称(预览图) / 通道索引 / 节点数 / 伪用户 / 使用者数"""
    state = get_state(context)
    row = layout.row(align=True)
    op = row.operator(MaterialActivateToggle.bl_idname, text="", icon='RESTRICT_SELECT_OFF' if mat.ch_material_active else 'RESTRICT_SELECT_ON', emboss=False)
    op.mat_name = mat.name
    op.mat_linked = mat.library is not None
    op = row.operator(MaterialMerge.bl_idname, text="", icon='IMPORT', emboss=False)
    op.mat_name = mat.name
    op.mat_linked = mat.library is not None
    show_pass_index = state.materials_show_pass_index
    show_node_count = state.materials_show_node_count
    split_columns = (show_pass_index or show_node_count) and can_split_columns(context)
    sub = draw_name_cell(row, item, icon='MATERIAL', icon_value=material_preview_icon(mat), name_factor=0.4 if split_columns else None, name_enabled=mat.library is None)
    if split_columns:
        if show_pass_index:
            sub.prop(mat, "pass_index", text="")
        if show_node_count:
            count = len(mat.node_tree.nodes) if mat.node_tree else 0
            sub.label(text="{:02d}".format(count), icon='NODE')
    draw_fake_user_count(sub, mat, 'MATERIAL')


class CH_UL_scene_cameras(_SceneFilterMixin, UIList):
    """相机列表(场景快照), 行内: 选择 / 相机视角 / 名称 / 焦距 / 类型 / 视口与渲染开关"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        obj = block_for_item(context, "cameras", item)
        if obj is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        draw_select_button(row, context, obj, "cameras")
        op = row.operator(CameraSetView.bl_idname, text="", icon=camera_icon(context, obj), emboss=False)
        op.obj_name = obj.name
        op.obj_linked = obj.library is not None
        show_columns = state.cameras_show_lens or state.cameras_show_type
        split_columns = show_columns and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else None, name_enabled=obj.library is None)
        cam = obj.data
        if split_columns:
            if state.cameras_show_lens:
                if cam.lens_unit == 'FOV':
                    sub.prop(cam, "angle", text="", emboss=False)
                else:
                    sub.prop(cam, "lens", text="", emboss=False)
            if state.cameras_show_type:
                sub.prop(cam, "type", text="", emboss=False)
        # 库链接行整体置灰: 行内开关/列属性在链接块上只读(算子侧另有同款守卫)
        sub.enabled = obj.library is None
        draw_object_toggles(sub, obj)


class CH_UL_scene_materials(_SceneFilterMixin, UIList):
    """材质列表(场景快照), 行内: 选择使用者 / 赋予 / 名称(预览图) / 通道索引 / 节点数 / 假用户"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        mat = block_for_item(context, "materials", item)
        if mat is None:
            draw_missing_item(layout, item)
            return
        _draw_material_row(context, layout, item, mat)


class CH_UL_scene_lights(_SceneFilterMixin, UIList):
    """灯光列表(场景快照), 行内: 选择 / 类型 / 名称 / 颜色 / 阴影 / 隔离 / 视口与渲染开关

    激活的灯光集合(ch_lights_active)作为语义过滤: 只显示挂在其内(含子集合)的灯光,
    全不激活时显示场景全部.
    """

    def filter_items(self, context: Context, data, propname: str):
        # 直调 standard_filter 而非 super(): 本方法被 e2e 以 MethodType 绑到鸭子实例上运行,
        # 零参 super() 要求真实子类实例; 行为与 StandardFilterMixin.filter_items 逐字一致.
        # 漏斗开关镜像不可省(见 _mirror_filter_flags), 漏掉会让排序开关对移动算子不可见.
        _mirror_filter_flags(context, self, propname)
        flt_flags, flt_neworder = standard_filter(self, data, propname)
        active = [coll for coll in bpy.data.collections if getattr(coll, "ch_lights_active", False)]
        if active:
            # 有效范围 = 各激活集合的子树; 集合外灯光按位清可见标志(与名称过滤叠加)
            effective: set = set()
            for coll in active:
                effective |= scene_collection_names(coll)
            for idx, item in enumerate(getattr(data, propname)):
                obj = context.scene.objects.get(item.src_name)
                if obj is None or not any(c.name in effective for c in obj.users_collection):
                    flt_flags[idx] &= ~self.bitflag_filter_item
        return flt_flags, flt_neworder

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        obj = block_for_item(context, "lights", item)
        if obj is None:
            draw_missing_item(layout, item)
            return
        light = obj.data
        row = layout.row(align=True)
        draw_select_button(row, context, obj, "lights")
        row.prop(light, "type", text="", icon=light_icon(obj), icon_only=True, emboss=False)
        show_columns = state.lights_show_color or state.lights_show_shadow
        split_columns = show_columns and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else None, name_enabled=obj.library is None)
        if split_columns:
            if state.lights_show_color:
                sub.prop(light, "color", text="")
            if state.lights_show_shadow:
                sub.prop(light, "use_shadow", text="", icon='GHOST_ENABLED' if light.use_shadow else 'GHOST_DISABLED', emboss=False)
        # 库链接行整体置灰: 行内开关/列属性在链接块上只读(算子侧另有同款守卫)
        sub.enabled = obj.library is None
        draw_object_toggles(sub, obj)


class CH_UL_scene_light_collections(_SceneFilterMixin, UIList):
    """灯光集合列表(CLS_ 前缀集合快照), 行内: 激活过滤 / 名称 / 视口与渲染禁用开关(+Ctrl 隔离)"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        coll = block_for_item(context, "light_collections", item)
        if coll is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        # 行首激活图标用 CHECKBOX 对: 语义是"过滤开关"而非选中, 与其它列表的 RESTRICT_SELECT 区分
        op = row.operator(CollectionActivateToggle.bl_idname, text="", icon='CHECKBOX_HLT' if coll.ch_lights_active else 'CHECKBOX_DEHLT', emboss=False)
        op.collection_name = coll.name
        op.collection_linked = coll.library is not None
        # 名称格不带图标(与灯光行同款): 行内图标会占掉名称的宽度, 窄面板时集合名比
        # 灯光名更早截断; 无列行走原生行布局——名称吃掉行尾按钮之外的全部宽度,
        # 行尾禁用按钮恒宽贴右缘(见 draw_name_cell)
        right = draw_name_cell(row, item, name_enabled=coll.library is None)
        # 视口/渲染禁用开关(+Ctrl 隔离其余灯光集合, 见 CollectionViewportToggle)
        op = right.operator(CollectionViewportToggle.bl_idname, text="", icon='RESTRICT_VIEW_ON' if coll.hide_viewport else 'RESTRICT_VIEW_OFF', emboss=False)
        op.collection_name = coll.name
        op.collection_linked = coll.library is not None
        op = right.operator(CollectionRenderToggle.bl_idname, text="", icon='RESTRICT_RENDER_ON' if coll.hide_render else 'RESTRICT_RENDER_OFF', emboss=False)
        op.collection_name = coll.name
        op.collection_linked = coll.library is not None


class CH_UL_light_link_members(UIList):
    """灯光/阴影链接集合成员列表(镜像), 行内: 名称 / 包含-排除单钮(勾叉对, 点击翻转)

    数据源 = props.SceneHelperState.link_members(绘制期签名比对重建, 见
    utils.light_linking.sync_link_member_list); 不挂过滤混入: 链接集合成员量小,
    且过滤开关镜像向量按 LIST_KINDS 索引, 与本列表无关.
    """

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        row = layout.row(align=True)
        row.prop(item, "src_name", text="", emboss=False, icon='OUTLINER_COLLECTION' if item.is_collection else 'OBJECT_DATA', translate=False)
        sub = row.row(align=True)
        sub.enabled = item.writable
        payload = {"link_type": item.link_type, "emitter_name": item.emitter_name, "target_name": item.src_name, "target_is_collection": item.is_collection}
        draw_link_state_toggle(sub, item.state, payload, 'CHECKBOX_HLT', 'CHECKBOX_DEHLT')


class CH_UL_object_link_lights(UIList):
    """物体链接反查列表(镜像, 灯光/阴影合并行: 一行一灯), 行内: 定位钮 / 灯名 / 双侧切换钮 / 共享灯数

    数据源 = object_light_links(sync_object_link_lists), 反查主体随集合视角开关
    (props.use_collection_view)取活动物体或活动集合, 载荷主体随条目携带(subject_name
    / is_collection). 行头定位钮把该灯设为面板灯光列表活跃项; 两枚切换钮恒绘——
    已加入时点击翻转包含/排除(图标示当前态), **未加入时置灰禁用仅作标识**(加入走
    灯光/阴影链接模式侧列"添加活动物体"), 灯光链接钮用灯图标对、阴影链接钮用探针
    图标对区分两测; 末尾数字 = 共享该灯灯光链接集合的灯数, 点击独立化(同"使其独立
    化"语义, 副本保成员与状态), 零填充两位数文本与伪用户钮同款(近方形窄钮). 间接
    成员(经子集合被链接)的行切换钮同样可点: 翻转会在该灯链接集合生成直连条目,
    覆盖嵌套集合带来的状态且只影响该灯.
    """

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        row = layout.row(align=True)
        focus = row.operator(LightLinkingFocusEmitter.bl_idname, text="", icon='ZOOM_IN', emboss=False)
        focus.emitter_name = item.src_name
        row.prop(item, "src_name", text="", emboss=False, translate=False)
        sub = row.row(align=True)
        sub.enabled = item.writable
        # 未加入 = 置灰禁用仅标识(不可点击); 包裹行为 content-width, 在 align 行内不产生间隙
        light_col = sub.row(align=True)
        light_col.enabled = item.state != ""
        payload = {"link_type": 'RECEIVER', "emitter_name": item.src_name, "target_name": item.subject_name, "target_is_collection": item.is_collection}
        draw_link_state_toggle(light_col, item.state, payload, 'OUTLINER_OB_LIGHT', 'LIGHT')
        shadow_col = sub.row(align=True)
        shadow_col.enabled = item.shadow_state != ""
        payload = {"link_type": 'BLOCKER', "emitter_name": item.src_name, "target_name": item.subject_name, "target_is_collection": item.is_collection}
        draw_link_state_toggle(shadow_col, item.shadow_state, payload, 'OUTLINER_OB_LIGHTPROBE', 'OUTLINER_DATA_LIGHTPROBE')
        users_op = sub.operator(LightLinkingCollectionSingleUser.bl_idname, text="{:02d}".format(item.users), emboss=False)
        users_op.emitter_name = item.src_name


class CH_UL_scene_images(_SceneFilterMixin, UIList):
    """图像列表(图像数据块快照 + IES 光域网条目)

    运行期图像(Render Result/合成 Viewer)钉在快照前两位(collect 端实现), 字母排序
    漏斗开启时经 filter_items 仍钉最前(反序由显示层统一取反, 钉住行随整表翻转).
    图像行内: 选择使用者 / 来源图标 / 名称 / 伪用户 / 打包解包 / 载入状态(未载入可点击重定位);
    分辨率与引用路径经 ListItem.tip 走 template_list 的 item_dyntip_propname 显示在
    整行悬停信息里(handlers._sync_image_tips 回填), 不占行内宽度.
    IES 行(快照 kind='IES')为纯显示行: 不是图像数据块, 无行内按钮、名称不可编辑、点行无联动.
    """

    def filter_items(self, context: Context, data, propname: str):
        # 直调 standard_filter 而非 super(): 本方法被 e2e 以 MethodType 绑到鸭子实例上运行,
        # 零参 super() 要求真实子类实例(与灯光列表同款); 漏斗开关镜像不可省(见 _mirror_filter_flags)
        _mirror_filter_flags(context, self, propname)
        # 行首"选中使用者"按钮的使用者映射每轮重绘建一次, 各行 draw_item 查表:
        # 逐行现算是全文件扫描, 大文件上列表卡顿主因(见 utils.image.refresh_users_map_cache)
        refresh_users_map_cache(context.scene)
        # IES 显示行的同款映射(图像侧已摊平、IES 侧此前漏改): 行绘制查 IES_USERS_MAP_CACHE
        refresh_ies_users_map_cache(context.scene)
        flt_flags, flt_neworder = standard_filter(self, data, propname)
        if not self.use_filter_sort_alpha:
            # 快照序本身已钉前(collect 端), 不返回顺序表与标准行为一致
            return flt_flags, flt_neworder
        items = getattr(data, propname)
        flt_neworder = bpy.types.UI_UL_list.sort_items_helper([(idx, item) for idx, item in enumerate(items)], _pinned_image_sort_key)
        return flt_flags, flt_neworder

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        if item.kind == 'IES':
            # 行首选择按钮后补 LIGHT 来源图标: 与图像行的"选择按钮+来源图标+名称"同构,
            # 名称起始位对齐
            row = layout.row(align=True)
            draw_ies_select(row, context, item.src_name)
            row.label(text="", icon='LIGHT')
            row.label(text=bpy.path.basename(item.src_name))
            row.label(text="", icon='BLANK1')
            return
        img = block_for_item(context, "images", item)
        if img is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        draw_image_select(row, context, img)
        row.label(text="", icon=IMAGE_SOURCE_ICONS.get(img.source, 'IMAGE_DATA'))
        sub = draw_name_cell(row, item, name_enabled=img.library is None)
        # 载入状态标记: 已有像素或无文件背书的来源(GENERATED/VIEWER/RENDER_RESULT, 未生成
        # 像素是常态)留空占位; 有路径未载入(MARKER)与无路径异常(ERROR)是可点击的重定位入口.
        # 库链接图像恒为占位: 路径由库文件决定, 重定位不适用.
        if img.library is not None or img.has_data or img.source in NO_FILE_SOURCES:
            sub.label(text="", icon='BLANK1')
        else:
            op = sub.operator(ImageRelocate.bl_idname, text="", icon='MARKER' if img.filepath else 'ERROR', emboss=False)
            op.image_name = img.name
        if img.library is not None:
            # 库链接图像: 打包/解包换成 LINKED 纯显示标记(点击无动作; 数据块来自库, 打包语义不适用)
            sub.label(text="", icon='LINKED')
        elif img.packed_file is not None:
            op = sub.operator(ImageUnpack.bl_idname, text="", icon='PACKAGE', emboss=False)
            op.image_name = img.name
        else:
            op = sub.operator(ImagePack.bl_idname, text="", icon='UGLYPACKAGE', emboss=False)
            op.image_name = img.name
        # 伪用户按钮收尾(状态标记与打包靠名称, 伪用户贴最右)
        draw_fake_user_count(sub, img, 'IMAGE')


class CH_UL_scene_worlds(_SceneFilterMixin, UIList):
    """世界环境列表(世界数据块快照), 行内: 指派 / 名称 / 颜色 / 伪用户 / 使用者数"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        world = block_for_item(context, "worlds", item)
        if world is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        active = context.scene.world is world
        op = row.operator(WorldAssign.bl_idname, text="", icon='RESTRICT_SELECT_OFF' if active else 'RESTRICT_SELECT_ON', emboss=False)
        op.world_name = world.name
        op.world_linked = world.library is not None
        split_columns = state.worlds_show_color and can_split_columns(context)
        sub = draw_name_cell(row, item, icon='WORLD', name_factor=0.5 if split_columns else None, name_enabled=world.library is None)
        if split_columns:
            sub.prop(world, "color", text="")
        draw_fake_user_count(sub, world, 'WORLD')
