"""
场景助手资源面板模块

五个侧栏面板(相机 / 灯光 / 材质 / 世界环境 / 图像), 统一布局:
- 列表 + 右侧纵向按钮列(新建 / 上移 / 下移 / 删除 / 选项)
- 列表下方可折叠详情子面板: 相机/灯光设置、材质着色器参数与 PBR 设置;
  无活动项时画占位提示; 世界/图像不画详情子面板
- 列表过滤/排序用 UIList 内建标准过滤行(名称 + 字母序 + 反序), 选项菜单另有一键按名称重排序

交互约定:
- 点击名称/行只切换高亮, 不改变场景选中; 点行首"选中关联物体"按钮才选中物体并高亮该行
- 选项菜单公共项: 选区同步(Sync Selection, 四面板共用, 世界无) -> 按名称重排序
  -> 显示0用户(材质/图像); 整理动作/状态开关紧跟公共项; 无对应项的面板按顺序顺延
- 灯光列表只列灯光物体
"""

from bpy.types import Context, Panel, UILayout

from ...constants import TAB_CATEGORY
from ...operators.object.camera import CreateAlignCamera, ToggleCamera
from ...operators.object.light_linking import (
    LightLinkingBlockerCollectionNew,
    LightLinkingEntryAdd,
    LightLinkingEntryRemove,
    LightLinkingReceiverCollectionNew,
    LightLinkingSelectTargets,
)
from ...operators.object.light_rig import LightAdd, LightControllerSet, LightCopy, LightControllerRemove, LightInstanceCopy, LightRigAdjust, LightRigParamsReset
from ...operators.utils.datablock_ops import CollectionNew, DatablockDelete, WorldNew, WorldUnlink
from ...operators.utils.image_ops import ImageDelete, ImageOpen
from ...operators.utils.list_ops import ListMove, ObjectDelete
from ...operators.utils.material_ops import MaterialAssign, MaterialDelete, MaterialDuplicate, MaterialNew
from ...scene_state import LIST_SPECS, active_block, block_for_item, blocks_for, get_state, panel_material
from ...utils import (
    get_controller_azimuth,
    get_controller_elevation,
    get_light_distance,
    get_light_self_rotation,
    get_surface_bsdf,
    linking_collection_of,
    rig_controller_of,
    suppress_light_rig_sync,
    sync_link_member_list,
    sync_object_link_lists,
)
from ..lists.scene_lists import CH_UL_light_link_members, CH_UL_object_link_lights, CH_UL_scene_cameras, CH_UL_scene_images, CH_UL_scene_light_collections, CH_UL_scene_lights, CH_UL_scene_materials, CH_UL_scene_worlds
from ._settings import draw_bsdf_slots, draw_camera_settings, draw_details_section, draw_light_advanced, draw_light_settings, draw_material_pbr, setup_param_box
from .scene_options import CameraOptions, CollectionOptions, ImageOptions, LightOptions, MaterialOptions, WorldOptions

# 列表固定行数(空列表也占位, 便于用户在空场景中看到右侧按钮列)
_LIST_ROWS = 5

# 灯光集合列表的固定行数(附属列表, 比主列表矮)
_COLLECTION_LIST_ROWS = 3

# 链接列表行数(成员列表)与反查列表行数(物体模式两列表, 比成员列表矮)
_LINK_LIST_ROWS = 4
_OBJECT_LINK_LIST_ROWS = 3


def _active_scene_object(context: Context, kind: str, obj_type: str):
    """按列表活跃项取场景物体; 越界/类型不符/已失效时返回 None"""
    obj = active_block(context, kind)
    return obj if getattr(obj, "type", None) == obj_type else None


# ------------------------------------------------------------
# 可折叠详情子面板(列表下方)
# ------------------------------------------------------------


def _draw_camera_details(layout: UILayout, context: Context, state) -> None:
    """相机详情子面板: 活动相机的设置属性; 无活动相机时画占位提示"""
    obj = _active_scene_object(context, "cameras", 'CAMERA')

    def draw_body(box: UILayout):
        if obj is None:
            # 原文刻意避开系统词条 "No active camera"(其系统译文"无活动摄像机"与
            # 灯光/材质面板的"没有活动X"不统一)
            box.label(text="No camera is active", icon='INFO')
        else:
            draw_camera_settings(box, obj, context)

    draw_details_section(layout, state, "show_camera_details", "Camera Settings", draw_body)


def _draw_light_details(layout: UILayout, context: Context, state) -> None:
    """灯光详情子面板: 活动灯光的设置属性; 材质条目或无活动项时画占位提示"""
    obj = _active_scene_object(context, "lights", 'LIGHT')

    def draw_body(box: UILayout):
        if obj is None:
            box.label(text="No active light", icon='INFO')
        else:
            draw_light_settings(box, obj, context)

    draw_details_section(layout, state, "show_light_details", "Light Settings", draw_body)


def _draw_light_advanced_section(layout: UILayout, context: Context, state) -> None:
    """灯光高级设置子面板(灯光设置与灯光方位之间), 绘制见 _settings.draw_light_advanced"""
    obj = _active_scene_object(context, "lights", 'LIGHT')
    draw_light_advanced(layout, context, state, obj)


def _draw_material_details(layout: UILayout, context: Context, state) -> None:
    """材质详情子面板: 活动材质的着色器参数; 无活动材质/无表面着色器时画占位提示"""
    mat = panel_material(context)

    def draw_body(box: UILayout):
        if mat is None:
            box.label(text="No active material", icon='INFO')
            return
        bsdf = get_surface_bsdf(mat)
        if bsdf is None:
            box.label(text="No surface shader", icon='INFO')
            return
        draw_bsdf_slots(box, bsdf)

    draw_details_section(layout, state, "show_material_details", "Material Settings", draw_body)


# ------------------------------------------------------------
# 面板额外行(相机切换 / 材质动作)
# ------------------------------------------------------------


def _draw_camera_switch_row(layout: UILayout) -> None:
    """相机列表下方: 上一/下一相机(文字标签, 按列表顺序切换, 总是对齐相机视角)"""
    row = layout.row(align=True)
    op = row.operator(ToggleCamera.bl_idname, text="Previous", icon='TRIA_UP_BAR')
    op.toggle_next = False
    row.separator(factor=0.5)
    op = row.operator(ToggleCamera.bl_idname, text="Next", icon='TRIA_DOWN_BAR')
    op.toggle_next = True


def _draw_material_actions_row(layout: UILayout) -> None:
    """材质列表下方: 复制材质 / 赋予材质(一行两键, 中间 factor=0.5 间隔)"""
    row = layout.row(align=True)
    row.operator(MaterialDuplicate.bl_idname, text="Duplicate Material", icon='DUPLICATE')
    row.separator(factor=0.5)
    row.operator(MaterialAssign.bl_idname, text="Apply Material", icon='KEY_RETURN')


def _draw_light_rig_actions_row(layout: UILayout, context: Context) -> None:
    """灯光列表下方: 复制灯光/实例复制 + 设置控制器/移除控制器(两行)

    可用性按面板活跃灯光绘制期判定: 复制/实例/移除控制器需活跃灯带控制器, 设置
    控制器恒可用(无控制器走添加, 有本地控制器走挪位重设); 库链接灯光一律置灰
    (控制器族算子对链接灯拒绝), 控制器为库链接时设置控制器也置灰. poll 是"面板行
    或选中集"的联合判定拿不到入口标记, 按钮精度由这里的 enabled 保证.
    """
    light = _active_scene_object(context, "lights", 'LIGHT')
    controller = rig_controller_of(light) if light is not None else None
    has_local_rig = light is not None and light.library is None and controller is not None
    can_set = light is not None and light.library is None and (controller is None or controller.library is None)
    row = layout.row(align=True)
    copy_col = row.row(align=True)
    copy_col.enabled = has_local_rig
    copy_col.operator(LightCopy.bl_idname, text="Copy Light", icon='DUPLICATE')
    row.separator(factor=0.5)
    inst_col = row.row(align=True)
    inst_col.enabled = has_local_rig
    inst_col.operator(LightInstanceCopy.bl_idname, text="Instance Copy", icon='SEQ_STRIP_DUPLICATE')
    row = layout.row(align=True)
    set_col = row.row(align=True)
    set_col.enabled = can_set
    set_col.operator(LightControllerSet.bl_idname, text="Set Controller", icon='LIGHTPROBE_PLANE')
    row.separator(factor=0.5)
    rem_col = row.row(align=True)
    rem_col.enabled = has_local_rig
    rem_col.operator(LightControllerRemove.bl_idname, text="Remove Controller", icon='UNLINKED')


def _draw_light_rig_section(layout: UILayout, context: Context, state) -> None:
    """灯光方位折叠区: 控制器的方位角/高度角与灯光的距离/自旋转(变换的镜像视图)

    前三行与自旋转经状态组镜像绘制(绘制前从变换回读, 用户改动经 update 回调写回
    变换); 自旋转只暴露灯光局部旋转的 Y 分量(X/Z 由 lock_rotation 锁定承担瞄准
    不变量); 无控制器画提示行. 纯运行期镜像不落自定义属性.
    模态唤起按钮与重置参数按钮在折叠头标题行右侧(均仅图标).
    """
    obj = _active_scene_object(context, "lights", 'LIGHT')

    def draw_body(box: UILayout):
        if obj is None:
            box.label(text="No active light", icon='INFO')
            return
        controller = rig_controller_of(obj)
        if controller is None:
            box.label(text="No controller", icon='INFO')
            return
        setup_param_box(box)
        with suppress_light_rig_sync():
            state.rig_azimuth = get_controller_azimuth(controller)
            state.rig_elevation = get_controller_elevation(controller)
            state.rig_distance = get_light_distance(obj)
            state.rig_self_rotation = get_light_self_rotation(obj)
        col = box.column()
        col.prop(state, "rig_azimuth", text="Azimuth")
        col.prop(state, "rig_elevation", text="Elevation")
        col.prop(state, "rig_distance", text="Distance")
        col.prop(state, "rig_self_rotation", text="Self Rotation")

    def header_tail(header: UILayout) -> None:
        row = header.row(align=True)
        row.operator(LightRigAdjust.bl_idname, text="", icon='ORIENTATION_GIMBAL')
        row.separator(factor=0.5)
        # 重置按钮按面板活跃灯绘制期置灰(poll 为联合判定拿不到入口标记); 模态唤起钮
        # 的 poll 即本口径(选区优先 + 面板回退), 无需另置
        controller = rig_controller_of(obj) if obj is not None else None
        reset_col = row.row(align=True)
        reset_col.enabled = obj is not None and obj.library is None and controller is not None and controller.library is None
        reset_col.operator(LightRigParamsReset.bl_idname, text="", icon='FILE_REFRESH')

    draw_details_section(layout, state, "show_light_rig", "Light Rig", draw_body, header_tail)


def _draw_emitter_linking_body(box: UILayout, context: Context, state, mode: str) -> None:
    """灯光/阴影链接模式体: 面板活跃灯光的链接集合成员列表(发射器 = 面板活跃灯光行)

    与灯光集合列表同款 template_list + 侧按钮列; 集合行的新建钮接自家算子(原生新建
    绑定 context_active_object, 面板语境会改错灯), 按类型拆两枚分别指回. 侧列:
    添加选中物体 / 移除活跃项 / 选中接收者(遮挡者).
    """
    link_type = 'RECEIVER' if mode == 'LIGHT_LINKING' else 'BLOCKER'
    light = _active_scene_object(context, "lights", 'LIGHT')
    if light is None:
        box.label(text="No active light", icon='INFO')
        return
    writable = light.library is None
    row = box.row()
    row.label(text=light.name, icon='LIGHT', translate=False)
    collection_prop = "receiver_collection" if link_type == 'RECEIVER' else "blocker_collection"
    new_op = LightLinkingReceiverCollectionNew.bl_idname if link_type == 'RECEIVER' else LightLinkingBlockerCollectionNew.bl_idname
    row = box.row()
    row.enabled = writable
    row.template_ID(light.light_linking, collection_prop, new=new_op)
    if linking_collection_of(light, link_type) is None:
        return
    sync_link_member_list(state, mode, light, link_type)
    row = box.row(align=True)
    row.template_list(CH_UL_light_link_members.__name__, "ch_light_link_members", state, "link_members", state, "link_members_index", rows=_LINK_LIST_ROWS)
    column = row.column(align=False)
    add_remove = column.column(align=True)
    add_remove.enabled = writable
    add = add_remove.operator(LightLinkingEntryAdd.bl_idname, text="", icon='ADD')
    add.link_type = link_type
    # 侧列移除作用于活跃项(与删除按钮列同口径); operator() 属性对象没有 enabled,
    # 置灰只能落在 UILayout 上
    rem_col = add_remove.column(align=False)
    has_active = 0 <= state.link_members_index < len(state.link_members)
    rem_col.enabled = has_active
    remove = rem_col.operator(LightLinkingEntryRemove.bl_idname, text="", icon='REMOVE')
    if has_active:
        item = state.link_members[state.link_members_index]
        remove.link_type = item.link_type
        remove.emitter_name = item.emitter_name
        remove.target_name = item.src_name
        remove.target_is_collection = item.is_collection
    select = column.operator(LightLinkingSelectTargets.bl_idname, text="", icon='RESTRICT_SELECT_OFF')
    select.link_type = link_type


def _draw_object_linking_body(box: UILayout, context: Context, state) -> None:
    """物体链接模式体: 反查主体被哪些灯灯光/阴影链接(合并单列表, 一行一灯)

    主体二态(作者定的集合视角): 默认 = 视口活动物体; 集合视角开关激活后 = 活动集合
    (状态取其作为各灯链接集合**直接子集合条目**的状态, 不递归, 与原生"只列直接成员"
    同口径), 切换钮画在侧列移除钮下方(GROUP/OUTLINER_COLLECTION). 行内: 定位钮 /
    灯名 / 两枚恒绘切换钮(已加入点击翻转, 未加入置灰标识) / 共享灯数(点击独立化).
    计数并入主体行右侧. 间接成员(经子集合被链接)的行切换钮同样可点: 翻转生成该灯
    直连条目覆盖嵌套态, 只影响该灯.
    """
    lights = [light for light in blocks_for(context, "lights") if light is not None]
    if state.use_collection_view:
        # 5.1 的 ViewLayer 无 active_collection, 活动集合走 active_layer_collection 包装
        layer_collection = context.view_layer.active_layer_collection
        subject = layer_collection.collection if layer_collection is not None else None
        if subject is None:
            box.label(text="No active collection", icon='INFO')
            return
        subject_name = subject.name
        subject_icon = 'OUTLINER_COLLECTION'
    else:
        obj = context.object
        if obj is None:
            box.label(text="No active object", icon='INFO')
            return
        subject_name = obj.name
        subject_icon = 'OBJECT_DATA'
    sync_object_link_lists(state, subject_name, lights, state.use_collection_view)
    collection = state.object_light_links
    row = box.row()
    row.label(text=subject_name, icon=subject_icon, translate=False)
    count_row = row.row()
    count_row.alignment = 'RIGHT'
    count_row.label(text="{} / {}".format(len(collection), len(lights)))
    row = box.row(align=True)
    row.template_list(CH_UL_object_link_lights.__name__, "ch_object_link_lights", state, "object_light_links", state, "object_light_links_index", rows=_OBJECT_LINK_LIST_ROWS)
    column = row.column(align=True)
    has_active = 0 <= state.object_light_links_index < len(collection)
    rem_col = column.column(align=False)
    if has_active:
        item = collection[state.object_light_links_index]
        rem_col.enabled = item.writable and (item.direct or item.shadow_direct)
        remove = rem_col.operator(LightLinkingEntryRemove.bl_idname, text="", icon='REMOVE')
        remove.link_type = 'RECEIVER'
        remove.emitter_name = item.src_name
        remove.target_name = item.subject_name
        remove.target_is_collection = item.is_collection
        remove.also_shadow = True
    else:
        rem_col.enabled = False
        rem_col.operator(LightLinkingEntryRemove.bl_idname, text="", icon='REMOVE')
    # 集合视角切换(作者定): 反查主体在活动物体与活动集合间切换
    column.prop(state, "use_collection_view", text="", icon='OUTLINER_COLLECTION' if state.use_collection_view else 'GROUP', toggle=True)


def _draw_light_linking_section(layout: UILayout, context: Context, state) -> None:
    """灯光&阴影链接折叠区(默认收缩): 三模式枚举切换 + 模式体

    引擎口径(作者实测): 仅 Workbench 下只画提示行不画 UI(Cycles 与 EEVEE 均生效).
    """

    def draw_mode_body(box: UILayout):
        # 引擎口径(作者实测): Cycles 与 EEVEE 均支持灯光链接, 仅 Workbench 无效——
        # 此时只画提示行不画 UI(与灯光方位"无控制器"提示同款)
        if context.scene.render.engine == 'BLENDER_WORKBENCH':
            box.label(text="Please switch the render engine to Cycles or EEVEE", icon='INFO')
            return
        col = box.column()
        # 三模式单行枚举钮(带条目标签; row 包裹保证不逐项换行)
        sub_row = col.row(align=True)
        sub_row.scale_y = 1.2
        sub_row.prop(state, "light_linking_mode", expand=True)
        if state.light_linking_mode == 'OBJECT_LINKING':
            _draw_object_linking_body(col, context, state)
        else:
            _draw_emitter_linking_body(col, context, state, state.light_linking_mode)

    draw_details_section(layout, state, "show_light_linking", "Light & Shadow Linking", draw_mode_body)


def _draw_light_collection_list(layout: UILayout, context: Context, state) -> None:
    """灯光集合列表(CLS_NN_ 前缀, 灯光主列表上方): 新建/删除(紧凑一组) + 选项菜单

    只管理 CLS_ 前缀的集合; 名称双击重命名写穿集合数据块(改掉前缀即离开本列表);
    点击行把该集合设为活动层集合(大纲管理器联动); 删除默认只删集合, +Shift 删除层级.
    无上移/下移按钮(显示顺序只经选项菜单的按名称重排序调整).
    """
    spec = LIST_SPECS["light_collections"]
    coll = getattr(state, spec.collection)
    idx = getattr(state, spec.index)
    layout.label(text="Light Collections", icon='OUTLINER_COLLECTION')
    row = layout.row(align=True)
    row.template_list(CH_UL_scene_light_collections.__name__, "ch_scene_light_collections", state, spec.collection, state, spec.index, rows=_COLLECTION_LIST_ROWS)
    column = row.column(align=False)
    add_remove = column.column(align=True)
    add_remove.operator(CollectionNew.bl_idname, text="", icon='ADD')
    delete_col = add_remove.column(align=False)
    datablock = block_for_item(context, "light_collections", coll[idx]) if 0 <= idx < len(coll) else None
    # 统一口径: 库链接集合不可删、失效条目不可删, 删除按钮一律置灰
    delete_col.enabled = datablock is not None and datablock.library is None
    op = delete_col.operator(DatablockDelete.bl_idname, text="", icon='REMOVE')
    if datablock is not None:
        op.id_name = coll[idx].src_name
        op.id_kind = 'COLLECTION'
        op.id_linked = datablock.library is not None
    column.menu(CollectionOptions.bl_idname, text="", icon='DOWNARROW_HLT')


# ------------------------------------------------------------
# 面板公共骨架
# ------------------------------------------------------------


class _ScenePanelMixin:
    """五个资源面板的公共骨架(普通混入类, 非 bpy 类型故不参与自动注册)

    子类须提供: bl_idname / bl_order / _kind / _title / _title_icon / _ul_class / _menu_class / _add_operator;
    需要列表下方额外行(如相机切换)时重写 draw_extra.
    删除按钮默认走 ObjectDelete; 材质/世界/图像面板重写 _draw_delete_button.
    """

    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = TAB_CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    _kind = ""
    _title = ""
    _title_icon = 'NONE'
    _ul_class = None
    _menu_class = None
    _add_operator = ""
    # 整行悬停说明(ListItem.tip 字段名); 不需要悬停信息的面板留空
    _dyntip_prop = ""

    def _collection(self, context: Context):
        """该面板的 (状态组实例, 列表元数据, 快照集合, 活跃索引)"""
        spec = LIST_SPECS[self._kind]
        state = get_state(context)
        return state, spec, getattr(state, spec.collection), getattr(state, spec.index)

    def draw_header(self, context: Context):
        _state, _spec, coll, _index = self._collection(context)
        self.layout.label(text=self._title, icon=self._title_icon)
        self.layout.label(text="({})".format(len(coll)))

    def draw(self, context: Context):
        layout = self.layout.column()
        state, spec, coll, idx = self._collection(context)
        self.draw_above(layout, context, state)
        row = layout.row(align=True)
        row.template_list(self._ul_class.__name__, "ch_scene_" + self._kind, state, spec.collection, state, spec.index, rows=_LIST_ROWS, item_dyntip_propname=self._dyntip_prop)
        self._draw_side_buttons(row.column(align=False), context, coll, idx)
        self.draw_extra(layout, context, state)
        self.draw_details(layout, context, state)

    def _draw_side_buttons(self, layout: UILayout, context: Context, coll, idx: int) -> None:
        """右侧纵向按钮列: 新建/删除(紧凑一组) / 上移 / 下移 / 选项"""
        has_active = 0 <= idx < len(coll)
        column = layout.column(align=False)
        add_remove = column.column(align=True)
        add_remove.operator(self._add_operator, text="", icon='ADD')
        delete_col = add_remove.column(align=False)
        delete_col.enabled = has_active
        self._draw_delete_button(delete_col, context, coll, idx)
        reorder = column.column(align=True)
        reorder.enabled = len(coll) > 1
        for move_down, icon in ((False, 'TRIA_UP'), (True, 'TRIA_DOWN')):
            op = reorder.operator(ListMove.bl_idname, text="", icon=icon)
            op.list_kind = self._kind
            op.move_down = move_down
        column.menu(self._menu_class.bl_idname, text="", icon='DOWNARROW_HLT')

    def _draw_delete_button(self, layout: UILayout, context: Context, coll, idx: int) -> None:
        """删除按钮(默认删除相机/灯光物体; 材质/世界/图像面板重写)

        库链接物体不可删(ObjectDelete 拒绝), 活跃项为链接物体时置灰按钮.
        """
        obj = active_block(context, self._kind)
        layout.enabled = obj is not None and obj.library is None
        op = layout.operator(ObjectDelete.bl_idname, text="", icon='REMOVE')
        op.list_kind = self._kind

    def draw_above(self, layout: UILayout, context: Context, state) -> None:
        """主列表上方的附加块(默认无; 灯光面板用它画灯光集合管理列表)"""

    def draw_extra(self, layout: UILayout, context: Context, state) -> None:
        """列表与详情子面板之间的额外行(默认无)"""

    def draw_details(self, layout: UILayout, context: Context, state) -> None:
        """列表下方常驻详情子面板(不需要详情的面板重写为空)"""


# ------------------------------------------------------------
# 相机面板
# ------------------------------------------------------------


class CamerasPanel(_ScenePanelMixin, Panel):
    """相机面板: 列表 + 按钮列 + 上一/下一相机行 + 相机设置子面板(默认展开)"""

    bl_idname = "VIEW3D_PT_ch_scene_cameras"
    bl_order = 1
    # 相机面板默认展开
    bl_options = set()
    _kind = "cameras"
    _title = "Cameras"
    _title_icon = 'OUTLINER_OB_CAMERA'
    _ul_class = CH_UL_scene_cameras
    _menu_class = CameraOptions
    _add_operator = CreateAlignCamera.bl_idname

    def draw_extra(self, layout: UILayout, context: Context, state) -> None:
        _draw_camera_switch_row(layout)

    def draw_details(self, layout: UILayout, context: Context, state) -> None:
        _draw_camera_details(layout, context, state)


# ------------------------------------------------------------
# 灯光面板
# ------------------------------------------------------------


class LightsPanel(_ScenePanelMixin, Panel):
    """灯光面板: 灯光集合列表(CLS_ 前缀) + 灯光列表/按钮列 + rig 动作行 + 灯光设置/灯光方位/灯光&阴影链接子面板"""

    bl_idname = "VIEW3D_PT_ch_scene_lights"
    bl_order = 2
    _kind = "lights"
    _title = "Lights"
    _title_icon = 'LIGHT'
    _ul_class = CH_UL_scene_lights
    _menu_class = LightOptions
    _add_operator = LightAdd.bl_idname

    def draw_above(self, layout: UILayout, context: Context, state) -> None:
        _draw_light_collection_list(layout, context, state)

    def draw_extra(self, layout: UILayout, context: Context, state) -> None:
        _draw_light_rig_actions_row(layout, context)

    def draw_details(self, layout: UILayout, context: Context, state) -> None:
        _draw_light_details(layout, context, state)
        _draw_light_advanced_section(layout, context, state)
        _draw_light_rig_section(layout, context, state)
        _draw_light_linking_section(layout, context, state)


# ------------------------------------------------------------
# 材质面板
# ------------------------------------------------------------


class MaterialsPanel(_ScenePanelMixin, Panel):
    """材质面板: 列表 + 按钮列 + 材质设置/PBR设置子面板"""

    bl_idname = "VIEW3D_PT_ch_scene_materials"
    bl_order = 3
    _kind = "materials"
    _title = "Materials"
    _title_icon = 'MATERIAL'
    _ul_class = CH_UL_scene_materials
    _menu_class = MaterialOptions
    _add_operator = MaterialNew.bl_idname

    def _draw_delete_button(self, layout: UILayout, context: Context, coll, idx: int) -> None:
        """删除按钮: 只解除材质关联(Shift 档删数据块)

        统一口径: 库链接材质不可删、失效条目不可删, 删除按钮一律置灰
        (与相机/灯光/图像面板同款; 算子侧仍保留拒绝, 供脚本直调路径兜底).
        """
        mat = active_block(context, self._kind)
        layout.enabled = mat is not None and mat.library is None
        layout.operator(MaterialDelete.bl_idname, text="", icon='REMOVE')

    def draw_extra(self, layout: UILayout, context: Context, state) -> None:
        _draw_material_actions_row(layout)

    def draw_details(self, layout: UILayout, context: Context, state) -> None:
        _draw_material_details(layout, context, state)
        draw_material_pbr(layout, context, state)


# ------------------------------------------------------------
# 世界环境面板
# ------------------------------------------------------------


class WorldsPanel(_ScenePanelMixin, Panel):
    """世界环境面板: 列表 + 按钮列(无详情子面板)"""

    bl_idname = "VIEW3D_PT_ch_scene_worlds"
    bl_order = 4
    _kind = "worlds"
    _title = "Worlds"
    _title_icon = 'WORLD'
    _ul_class = CH_UL_scene_worlds
    _menu_class = WorldOptions
    _add_operator = WorldNew.bl_idname

    def _draw_delete_button(self, layout: UILayout, context: Context, coll, idx: int) -> None:
        """删除按钮: 只解除世界与场景的关联, 保留世界数据块

        统一口径: 库链接世界不可删(Shift 档)、失效条目不可删,
        删除按钮一律置灰(与相机/灯光/图像面板同款).
        """
        world = block_for_item(context, "worlds", coll[idx]) if 0 <= idx < len(coll) else None
        layout.enabled = world is not None and world.library is None
        op = layout.operator(WorldUnlink.bl_idname, text="", icon='REMOVE')
        if world is not None:
            op.world_name = world.name
            op.world_linked = world.library is not None


# ------------------------------------------------------------
# 图像面板
# ------------------------------------------------------------


class ImagesPanel(_ScenePanelMixin, Panel):
    """图像面板: 列表 + 按钮列(无详情子面板)"""

    bl_idname = "VIEW3D_PT_ch_scene_images"
    bl_order = 5
    _kind = "images"
    _title = "Images"
    _title_icon = 'IMAGE_DATA'
    _ul_class = CH_UL_scene_images
    _menu_class = ImageOptions
    # 原生 image.open 的文件对话框异步载入拿不到完成时机, 插件壳登记导入意图
    # (handlers.expect_image_import)让快照重建按差集高亮新条目
    _add_operator = ImageOpen.bl_idname
    # 分辨率与引用路径经 ListItem.tip 显示在整行悬停信息上
    _dyntip_prop = "tip"

    def _draw_delete_button(self, layout: UILayout, context: Context, coll, idx: int) -> None:
        """删除按钮: 默认解除材质节点引用(用户归 0), +Shift 删除图像数据块(ImageDelete)

        IES 显示行不是图像数据块、库链接图像两档都不许删(见 ImageDelete), 两者均置灰按钮.
        """
        item = coll[idx] if 0 <= idx < len(coll) else None
        img = block_for_item(context, "images", item) if item is not None and item.kind != 'IES' else None
        layout.enabled = img is not None and img.library is None
        op = layout.operator(ImageDelete.bl_idname, text="", icon='REMOVE')
        if item is not None:
            op.image_name = item.src_name
            op.image_linked = img is not None and img.library is not None
