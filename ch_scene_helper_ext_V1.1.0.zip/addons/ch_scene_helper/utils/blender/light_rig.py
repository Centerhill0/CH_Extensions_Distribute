"""灯光控制器 rig 工具模块

灯光与控制器空物体(父级)刚性绑定的算法层, 交互层算子见 operators/object/light_rig.py.
硬性约束: 一个控制器只挂一个灯光子级; 灯光与控制器的唯一恒定
约束是"灯光局部 -Z 指向控制器", 灯光的局部偏移是用户资产——除创建/添加控制器两次
初始摆位外, 任何功能(含反射模式)都不改写它.

主要功能:
- create_light_rig: 在指定位置创建"控制器 + AREA 面光源"整套 rig
- add_controller / remove_controller: 给既有灯光加/摘控制器(保灯光世界变换)
- copy_light_rig: 复制整套 rig(shared_data=True 实例复制, 共享灯光数据)
- rig_controller_of / rig_light_of / resolve_rig: 灯光与控制器互查及按选中集解析 rig
- get/set_controller_azimuth|elevation / get/set_light_distance: 四属性的变换读写
  (方位角=控制器旋转 Z 分量, 高度角=X 分量, 距离=灯光局部位置长度)
- rig_trajectory / rig_trajectory_ticks: 模态 A/D 档轨迹预览的几何(方位圆环/高度大圆/刻度点)
- rig_init_distance: rig 的"创建时初始距离"(记录在灯光自定义属性上, 随 .blend 保存;
  无记录的旧 rig 回退面板默认值)
- sync_controllers_visibility: 控制器视口可见位单向跟随灯光(行内开关与隔离共用)
- raycast_surface / reflection_direction / view_origin: 模态吸附的射线拾取与反射数学
- suppress_light_rig_sync: 面板 draw 期镜像回读的抑制(仿 material.py 同款深度计数)
"""

from contextlib import contextmanager
from math import pi, radians

import bpy
from bpy.types import Context, Object, Scene
from bpy_extras import view3d_utils
from mathutils import Euler, Matrix, Quaternion, Vector

from .._constants import RIG_DEFAULT_AREA_SIZE, RIG_DEFAULT_DISTANCE, RIG_DEFAULT_ELEVATION, RIG_DEFAULT_ENERGY
from .selection import select_only

# 灯光初始局部偏移 (0, d, 0) 的下限取 _constants.RIG_DEFAULT_DISTANCE(与面板距离镜像的
# 默认值同源), 与"活动物体包围盒 Y 方向尺寸"倍数二者取大(3 倍)
RIG_DISTANCE_BBOX_FACTOR = 3.0
# 零偏移方向回退(与初始 (0, d, 0) 的 +Y 轴方向一致, 供距离设置在零偏移时取方向)
RIG_DEFAULT_DIRECTION = Vector((0.0, 1.0, 0.0))
# 控制器显示尺寸: 等效"初始缩放 0.1 已应用"——空物体无几何可烘缩放, 用显示尺寸实现
# 视觉 0.1 且 scale 恒为 (1, 1, 1), 子级变换不受父级缩放污染
CONTROLLER_DISPLAY_SIZE = 0.1
# 灯光瞄准姿态(局部欧拉 XYZ, 弧度): 灯落在控制器局部 +Y 轴上时, 使局部 -Z 指向控制器
# 的旋转恰为 X -90°, Z 恒 0; Y 是自旋转自由轴(初值 0). 创建/添加控制器/重置控制器/
# 自旋转归零四处共用同一口径, 不得各自内联
LIGHT_AIM_ROTATION = (radians(-90.0), 0.0, 0.0)

# rig 初始距离的持久化键(灯光对象的自定义属性): 创建/添加控制器时写入, 重置参数的
# 距离默认值取该记录——创建路径的初始距离依赖活动物体包围盒(现算不可复现), 只能落盘.
# 随 .blend 保存, copy_light_rig 复制灯光时随副本走(副本的初始距离 = 源的初始距离)
RIG_INIT_DISTANCE_KEY = "ch_rig_init_distance"

_EPS = 1e-6

# 灯光方位镜像写回的抑制计数: 面板 draw 期把变换真值写进镜像属性时,
# props.on_light_rig_*_update 查此计数跳过写回 —— 否则每帧重画都会写一次变换.
# 用深度计数而非布尔值防嵌套(与 material.py 的坐标镜像抑制同款).
_suppress_depth = 0


@contextmanager
def suppress_light_rig_sync():
    """进入灯光方位镜像写回抑制(面板 draw 期把真值写回镜像时使用), 退出时恢复"""
    global _suppress_depth
    _suppress_depth += 1
    try:
        yield
    finally:
        _suppress_depth -= 1


def is_light_rig_sync_suppressed() -> bool:
    """灯光方位镜像属性的 update 回调当前是否应跳过(面板 draw 期)"""
    return _suppress_depth > 0


# ------------------------------------------------------------
# rig 解析(灯光 <-> 控制器互查)
# ------------------------------------------------------------


def rig_controller_of(light: Object) -> Object | None:
    """灯光物体的控制器空物体(空物体父级); 无空物体父级返回 None

    本方向不做"恰挂一灯"校验: 灯光的父级是空物体即视为其控制器(多灯误挂同属
    用户违反硬性约束, 收敛语义仍以各自父级为准).
    """
    if light is None or light.type != 'LIGHT':
        return None
    parent = light.parent
    if parent is not None and parent.type == 'EMPTY':
        return parent
    return None


def rig_light_of(controller: Object) -> Object | None:
    """控制器空物体挂载的灯光子级; 违反"恰挂一灯"硬性约束(0 盏或多盏)返回 None"""
    if controller is None or controller.type != 'EMPTY':
        return None
    lights = [child for child in controller.children if child.type == 'LIGHT']
    if len(lights) == 1:
        return lights[0]
    return None


def resolve_rig(context: Context) -> tuple[Object, Object] | None:
    """按作者激活条件解析 rig(灯光, 控制器): 选到灯光或控制器或二者都选中

    优先活动物体(带空物体父级的灯光 / 恰挂一盏灯光子级的空物体), 活动物体不在
    rig 上时按选中集扫描取首个命中; 多个 rig 同时选中取首个, 属边界情形.
    """
    active = context.view_layer.objects.active
    rig = _rig_of_object(active)
    if rig is not None:
        return rig
    for obj in context.selected_objects:
        rig = _rig_of_object(obj)
        if rig is not None:
            return rig
    return None


def _rig_of_object(obj: Object | None) -> tuple[Object, Object] | None:
    """单物体视角的 rig 解析: 灯光侧查父级, 空物体侧查唯一灯光子级"""
    if obj is None:
        return None
    if obj.type == 'LIGHT':
        controller = rig_controller_of(obj)
        return (obj, controller) if controller is not None else None
    if obj.type == 'EMPTY':
        light = rig_light_of(obj)
        return (light, obj) if light is not None else None
    return None


def filter_batch_lights(objects: list, require_controller: bool) -> tuple[list, list]:
    """选中集筛选批量目标灯: 灯光本体直取, 控制器空体经 rig_light_of 映射到其灯, 去重

    require_controller 为 True 时只保留带控制器的灯光(五钮与删除的批量口径); 为 False 时
    全部灯光保留(设置控制器批量口径, 由调用方再分重设/添加)。返回 (本地合格灯, 跳过的链接灯):
    库链接灯光不可编辑, 由调用方计数报告。
    """
    lights: list = []
    linked: list = []
    for obj in objects:
        if obj.type == 'LIGHT':
            light = obj
        elif obj.type == 'EMPTY':
            light = rig_light_of(obj)
        else:
            continue
        if light is None or light in lights:
            continue
        if require_controller and rig_controller_of(light) is None:
            continue
        (linked if light.library is not None else lights).append(light)
    return lights, linked


# ------------------------------------------------------------
# rig 创建 / 控制器增删 / 复制
# ------------------------------------------------------------


def rig_light_distance(active_obj: Object | None) -> float:
    """灯光初始距离 d = max(_constants.RIG_DEFAULT_DISTANCE, 3x 活动物体世界包围盒 Y 方向尺寸)

    无活动物体取下限; 包围盒按 8 个角点的世界坐标求 Y 跨度(物体可旋转).
    """
    distance = RIG_DEFAULT_DISTANCE
    if active_obj is not None:
        corners = [active_obj.matrix_world @ Vector(corner) for corner in active_obj.bound_box]
        ys = [corner.y for corner in corners]
        distance = max(distance, (max(ys) - min(ys)) * RIG_DISTANCE_BBOX_FACTOR)
    return distance


def rig_init_distance(light: Object) -> float:
    """rig 的"创建时初始距离"(重置参数的距离默认值)

    创建/添加控制器时记录在灯光的自定义属性上(见 RIG_INIT_DISTANCE_KEY); 本版本
    之前的旧 rig 无记录, 回退面板距离默认值 RIG_DEFAULT_DISTANCE.
    """
    return float(light.get(RIG_INIT_DISTANCE_KEY, RIG_DEFAULT_DISTANCE))


def _new_controller(light_name: str) -> Object:
    """新建控制器空物体(CUBE, 显示尺寸 0.1, 旋转 0), 名 = 灯光名 + "_C" 后缀

    两物体不能同名(作者定口径): 控制器显式取 "<灯光名>_C"(如 Light_C), 撞名时
    由 Blender 再加数字后缀。
    """
    name = light_name + "_C"
    controller = bpy.data.objects.new(name, None)
    if controller.name != name:
        # 物体命名空间撞名被加后缀时回写对齐(仍撞则由 Blender 再后缀, 尽力口径)
        controller.name = name
    controller.empty_display_type = 'CUBE'
    controller.empty_display_size = CONTROLLER_DISPLAY_SIZE
    return controller


def _link_like(obj: Object, src: Object, context: Context) -> None:
    """把新物体链入源物体的全部集合(无集合时回退当前活动集合)"""
    collections = list(src.users_collection) or [context.collection]
    for coll in collections:
        coll.objects.link(obj)


def _select_rig(context: Context, light: Object, controller: Object) -> None:
    """选中整套 rig 并以灯光为活动物体(handlers 的"新建即活动物体"高亮依赖)

    新建物体要等视图层求值后才进 view_layer.objects——select_only 的可选中判定
    会静默跳过(后台立即读为空是已知坑, 见 scene_data.visible_objects 文档),
    先显式 update 一次再选中.
    """
    context.view_layer.update()
    select_only(context, [light, controller], active=light)


def create_light_rig(context: Context, position: Vector, light_type: str = 'AREA') -> tuple[Object, Object]:
    """在 position 创建"控制器空物体 + 指定类型灯光"整套 rig, 返回 (灯光, 控制器)

    几何: 灯光初始在控制器的局部 +Y 轴上, 距离 = rig_light_distance;
    控制器绑定(旋转 0)后沿 X 轴转 45°——灯的仰角随之 45°, 高度角属性从创建起即真实值.
    - 控制器: CUBE 空物体, 显示尺寸 0.1, scale 1, 末态旋转 (45°, 0, 0), 名 = 灯光名 + "_C"
    - 灯光: 类型由 light_type 指定, 功率按 RIG_DEFAULT_ENERGY(太阳光量纲不同保持 Blender
      默认), 面光源边长按 RIG_DEFAULT_AREA_SIZE(形状保持默认 SQUARE); 局部位置 (0, d, 0),
      -Z 指向控制器(与控制器 Y 轴对齐), 局部旋转 X/Z 锁定(仅 Y 可转)
    - 两者链入当前活动集合, 均选中且灯光为活动物体(handlers 的"新建即活动物体"
      高亮依赖活动物体是灯光)
    """
    distance = rig_light_distance(context.view_layer.objects.active)
    light_data = bpy.data.lights.new(light_type.title(), light_type)
    if light_type != 'SUN':
        light_data.energy = RIG_DEFAULT_ENERGY
    if light_type == 'AREA':
        light_data.size = RIG_DEFAULT_AREA_SIZE
    light = bpy.data.objects.new(light_data.name, light_data)
    if light.name != light_data.name:
        light_data.name = light.name
    light.location = Vector((0.0, distance, 0.0))
    # 初始距离落自定义属性(重置参数的距离默认值): 创建路径依赖活动物体包围盒, 现算
    # 不可复现, 只能持久化
    light[RIG_INIT_DISTANCE_KEY] = distance
    # 父级空间内瞄准: 灯在控制器局部 +Y 轴上, -Z 指向父级原点的旋转恰为 X -90°——
    # 直接写欧拉(不走 to_track_quat: 其 Y-up 提示在纯 -Y 方向会引入扭转, 欧拉 Y≠0,
    # 违反"Y 分量初始归零")
    light.rotation_euler = LIGHT_AIM_ROTATION
    light.lock_rotation = (True, False, True)
    controller = _new_controller(light.name)
    # 活动集合为库链接集合时不可 link 成员(报错中断), 回落场景主集合——
    # 与原生添加自动回落可编辑父级的口径对齐(简版: 只处理常见的链接子集合情形)
    target_collection = context.collection
    if target_collection.library is not None:
        target_collection = context.scene.collection
    for obj in (light, controller):
        target_collection.objects.link(obj)
    # matrix_parent_inverse 缺省 Identity: 父级在 position 旋转 0, 局部偏移即世界偏移
    light.parent = controller
    controller.matrix_world = Matrix.Translation(position)
    # 绑定后再抬仰角: 灯光刚性跟随, 局部 (0, d, 0) 不变, 世界位 = 父级位 + Rx(45°)·(0, d, 0)
    controller.rotation_euler = (RIG_DEFAULT_ELEVATION, 0.0, 0.0)
    _select_rig(context, light, controller)
    return light, controller


def add_controller(context: Context, light: Object, position: Vector) -> Object:
    """给灯光添加控制器空物体并父级绑定, 灯光世界位置保持不变, 返回控制器

    添加后灯光 -Z 指向控制器(把"瞄准"约束补齐到既有灯光上); 控制器旋转使其 +Y 轴
    指向灯光——灯光落在控制器的局部 +Y 轴上, 与创建路径的几何约定一致(距离/方位
    属性直接可用). 控制器链入灯光所在的集合(整理/可见性口径与灯光同进退). 保位走
    "父级逆保持 Identity + 重写 matrix_world": setter 会反解出 basis = 父级空间偏移,
    局部位置语义与 create 路径一致(距离族函数依赖它; 5.1.2 实测: 先写 parent_inverse
    再写 matrix_world 会把 location 变成旧世界坐标——审查 P1 实锤).
    """
    controller = _new_controller(light.name)
    _link_like(controller, light, context)
    # 控制器世界矩阵显式构建(basis 直写即时生效): rotation_euler 写入不即时更新
    # obmat, 后续保位/瞄准若读 matrix_world 会拿到陈旧父级矩阵(e2e 实证)
    direction = light.matrix_world.translation - position
    controller_rotation = Matrix.Identity(4)
    if direction.length > 1e-6:
        # 控制器 +Y 轴指向灯光(灯落在控制器局部 +Y 轴上, 与创建路径约定一致)
        controller_rotation = direction.normalized().to_track_quat('Y', 'Z').to_matrix().to_4x4()
    controller_mx = Matrix.Translation(position) @ controller_rotation
    controller.matrix_basis = controller_mx
    world = light.matrix_world.copy()
    light.parent = controller
    # basis 显式解算(不依赖父级 obmat 的求值时效): world = 父级 x 父级逆 x basis
    # → basis = 父级逆⁻¹ x 控制器世界逆 x 灯光旧世界(父级逆为 Identity 时退化为
    # 控制器世界逆 x 旧世界; 用户手动父级化产生的非 Identity 父级逆不修正会跳位,
    # 漂移可达 5.39m 量级)
    light.matrix_basis = light.matrix_parent_inverse.inverted() @ controller_mx.inverted() @ world
    light.lock_rotation = (True, False, True)
    _aim_light_at_controller(light, controller_mx, world)
    # 记录初始距离(重置参数的距离默认值): 落点决定, = 绑定后的父级空间偏移长度
    light[RIG_INIT_DISTANCE_KEY] = get_light_distance(light)
    # 尾部求值一次: 调用方/用例随即读 matrix_world 时拿到的是含旋转的新状态
    context.view_layer.update()
    return controller


def reset_controller(context: Context, light: Object, position: Vector) -> str:
    """把灯光的控制器挪到 position 并重新瞄准, 灯光世界位置保持不变, 返回处理结果

    与 add_controller 同一套几何约定: 控制器 +Y 轴指向灯光(灯落在控制器局部 +Y
    轴上), 灯光局部旋转归位 X -90°(自旋转让参数归零); 距离随
    新位置自然变化(灯不动、控制器动). 结果:
    - "reset": 控制器为本地数据块, 已重定位并重新瞄准
    - "linked": 控制器是库链接数据块——basis 写入属会话改写库资产, 拒绝
    - "none": 灯光没有控制器
    """
    controller = rig_controller_of(light)
    if controller is None:
        return "none"
    if controller.library is not None:
        return "linked"
    direction = light.matrix_world.translation - position
    controller_rotation = Matrix.Identity(4)
    if direction.length > 1e-6:
        controller_rotation = direction.normalized().to_track_quat('Y', 'Z').to_matrix().to_4x4()
    controller_mx = Matrix.Translation(position) @ controller_rotation
    controller.matrix_basis = controller_mx
    world = light.matrix_world.copy()
    light.matrix_basis = light.matrix_parent_inverse.inverted() @ controller_mx.inverted() @ world
    _aim_light_at_controller(light, controller_mx, world)
    context.view_layer.update()
    return "reset"


def remove_controller(light: Object) -> str:
    """摘除灯光的控制器父级(保灯光世界变换), 返回处理结果

    - "removed": 控制器是本灯专有(恰挂一灯的本地空物体), 一并删除
    - "linked": 控制器是库链接数据块——remove 对链接 ID 不设防(坑册 §19), 只解绑定不删
    - "shared": 控制器还有其它子级(违反一控一灯的用户手挂)——留作普通空物体不删
    - "none": 灯光没有控制器
    解绑同时把 matrix_parent_inverse 复位 Identity: 陈旧的父级逆会在用户日后手动
    再父级化时悄悄歪斜变换.
    """
    controller = rig_controller_of(light)
    if controller is None:
        return "none"
    # 专有性判定走父级指针扫描而非 Object.children: 后者依赖依赖图求值, 同一会话内
    # "加完立刻摘"(脚本/e2e)会读到空列表而误判成共挂(e2e 实证); 且必须在解绑**前**扫描
    # ——解绑后 light.parent 已是 None, 扫描恒空(第一版修复即栽在这里).
    # 专有 = 除本灯外无任何其它子级(任意类型): 手挂辅助物与共挂灯同样阻止删除
    children = [obj for obj in bpy.data.objects if obj.parent is controller]
    is_sole_light = children == [light]
    world = light.matrix_world.copy()
    light.parent = None
    light.matrix_world = world
    light.matrix_parent_inverse = Matrix.Identity(4)
    # 旋转解锁: 瞄准约束随控制器一起移除, X/Z 轴交还给用户
    light.lock_rotation = (False, False, False)
    if controller.library is not None:
        return "linked"
    if not is_sole_light:
        return "shared"
    bpy.data.objects.remove(controller, do_unlink=True)
    return "removed"


def copy_light_rig(context: Context, light: Object, shared_data: bool) -> tuple[Object, Object] | None:
    """复制整套 rig, 返回 (新灯光, 新控制器); 无控制器返回 None

    shared_data=False 复制灯光(数据独立副本); True 实例复制(共享灯光数据块,
    改功率/颜色全联动). 两者都配各自的新控制器. 只建不选: 选中态是交互口径,
    由调用方按入口收尾(面板单灯即选该套, 饼菜单批量收尾一次选全体).
    """
    controller = rig_controller_of(light)
    if controller is None:
        return None
    new_light = light.copy()
    if not shared_data:
        new_light.data = light.data.copy()
    new_controller = controller.copy()
    # 控制器命名守 _C 约定(copy 沿用源名加数字后缀, 不遵约定会让改名跟随对复制
    # rig 永不失效; 撞名由 Blender 再加数字后缀)
    new_controller.name = new_light.name + "_C"
    _link_like(new_light, light, context)
    _link_like(new_controller, controller, context)
    # copy() 会继承对原控制器的父级引用, 重挂到新控制器(局部变换不变, 新控制器
    # 与原控制器世界矩阵相同, 世界位姿随之保持)
    new_light.parent = new_controller
    new_light.matrix_parent_inverse = light.matrix_parent_inverse.copy()
    return new_light, new_controller


# ------------------------------------------------------------
# 瞄准与四属性(变换读写)
# ------------------------------------------------------------


def _set_rotation(obj: Object, quat: Quaternion) -> None:
    """按物体自身的 rotation_mode 写入旋转(四元数/轴角/欧拉各自对号)"""
    if obj.rotation_mode == 'QUATERNION':
        obj.rotation_quaternion = quat
    elif obj.rotation_mode == 'AXIS_ANGLE':
        axis, angle = quat.to_axis_angle()
        obj.rotation_axis_angle = (axis.x, axis.y, axis.z, angle)
    else:
        obj.rotation_euler = quat.to_euler(obj.rotation_mode)


def _aim_light_at_controller(light: Object, controller_mx: Matrix, world: Matrix) -> None:
    """把灯光的局部旋转改为使其世界 -Z 指向控制器(位置不动)

    controller_mx/world 由调用方显式传入而非读 matrix_world: rotation_euler 写入
    不即时更新 obmat(与 matrix_world 写不同), 读旧值会把瞄准算错(e2e 实证).
    本函数仅适用于"控制器 +Y 轴指向灯光"的几何约定: 该约定下灯的局部瞄准方向恒为
    (0, -1, 0), 局部旋转恰为 X -90°——自旋转(Y 分量)随之归零.
    兼容任意 rotation_mode.
    """
    direction = controller_mx.translation - world.translation
    if direction.length <= _EPS:
        return
    _set_rotation(light, Euler(LIGHT_AIM_ROTATION, 'XYZ').to_quaternion())


def get_controller_azimuth(controller: Object) -> float:
    """方位角: 控制器旋转的 Z 分量(XYZ 欧拉口径, 弧度)

    转台模型: 方位角绕竖直轴(欧拉 Z)旋转时灯的高度角恒定
    ——绕 Y 分量会让 (0, h, h) 偏移的灯在扫方位时扎进地里。
    """
    return controller.matrix_basis.to_euler('XYZ').z


def get_controller_elevation(controller: Object) -> float:
    """高度角: 控制器旋转的 X 分量(XYZ 欧拉口径, 弧度)"""
    return controller.matrix_basis.to_euler('XYZ').x


def set_controller_azimuth(controller: Object, value: float) -> None:
    """写方位角(控制器旋转 Z 分量), 位置与缩放保持不变"""
    _set_basis_euler_component(controller, 2, value)


def set_controller_elevation(controller: Object, value: float) -> None:
    """写高度角(控制器旋转 X 分量), 位置与缩放保持不变"""
    _set_basis_euler_component(controller, 0, value)


def _set_basis_euler_component(controller: Object, axis_idx: int, value: float) -> None:
    """按 XYZ 欧拉口径改写控制器 basis 旋转的单个分量(兼容任意 rotation_mode)

    经 matrix_basis 分解-重组: 只换旋转部分, 位置/缩放原样保留; 用户后续在大纲
    改了控制器的 rotation_mode 也不丢数据.
    """
    eul = controller.matrix_basis.to_euler('XYZ')
    eul[axis_idx] = value
    loc, _rot, scale = controller.matrix_basis.decompose()
    controller.matrix_basis = Matrix.Translation(loc) @ eul.to_matrix().to_4x4() @ Matrix.Diagonal(scale.to_4d())


def get_light_distance(light: Object) -> float:
    """灯光到控制器的距离(父级空间局部位置长度)"""
    return light.location.length


def set_light_distance(light: Object, value: float) -> None:
    """写灯光到控制器的距离(保持局部偏移方向, 只缩放长度); 零偏移时取默认方向"""
    direction = light.location
    if direction.length <= _EPS:
        direction = RIG_DEFAULT_DIRECTION
    light.location = direction.normalized() * max(value, 0.0)


def get_light_self_rotation(light: Object) -> float:
    """自旋转: 灯光自身局部旋转的 Y 分量(弧度)

    自旋转是瞄准约束下唯一可自由调节的自由度(绕瞄准轴的自转, 面光源的矩形朝向/
    聚光灯的形状朝向随它转); X/Z 两轴由瞄准占用且已 lock_rotation 锁定. 非 XYZ
    欧拉模式下"Y 分量"口径不成立(审查探针: 四元数模式写 euler.y 零效果), 返回 0.
    """
    if light.rotation_mode != 'XYZ':
        return 0.0
    return light.rotation_euler.y


def set_light_self_rotation(light: Object, value: float) -> None:
    """写自旋转(只改灯光局部旋转的 Y 分量, X/Z 瞄准分量不动)

    经镜像属性而非直调 RNA: 用户在旋转属性上按 Backspace 会把三个分量全部归零
    (Blender 对整组欧拉的默认值语义), 只暴露 Y 分量可保住瞄准.
    非 XYZ 欧拉模式拒绝(镜像素材失效, 折叠区同步置灰).
    """
    if light.rotation_mode != 'XYZ':
        return
    light.rotation_euler.y = value


def reset_light_self_rotation(light: Object) -> None:
    """把灯光局部旋转整体归位到瞄准姿态(X -90°, Y/Z 0°), 顺带修复被带歪的瞄准分量

    面板自旋转镜像恢复默认值(0)时调用: 镜像只暴露 Y, 用户在大纲/
    属性面板按 Alt+R、改 rotation_mode 或脚本写 X/Z 都会破坏瞄准而面板无从察觉——归零
    自旋转顺带把三轴写回瞄准姿态, 即恢复"灯 -Z 指向控制器"这一不变量. 兼容任意
    rotation_mode(写四元数, 与瞄准路径同款), 不再受"仅 XYZ 可写"的限制.
    """
    _set_rotation(light, Euler(LIGHT_AIM_ROTATION, 'XYZ').to_quaternion())


# ------------------------------------------------------------
# 轨迹预览几何(模态 A 档的方位/高度轨迹)
# ------------------------------------------------------------

# 轨迹折线分段数: 96 段在常见距离与视角下已看不出折角, 单帧成本可忽略
TRAJECTORY_SEGMENTS = 96
# 正轴刻度的方位角/高度角(度): 转台模型以 Z 为方位转轴, 灯光初始落在 +Y 轴上,
# 故 0/90/180/270 依次对应 +Y/+X/-Y/-X(大圆上 90/270 对应 +Z/-Z)
TRAJECTORY_AXIS_ANGLES = (0.0, 90.0, 180.0, 270.0)


def _trajectory_frame(light: Object) -> tuple[Matrix, Vector, float, float] | None:
    """轨迹基准矩阵 B 与灯光的父级空间偏移, 附当前方位角/高度角; 无控制器返回 None

    B = controller.matrix_world · (Rz(方位角)·Rx(高度角))⁻¹ —— 剥掉两个转轴后剩下的
    世界变换(含父级与平移), 于是灯光世界位 = B · Rz · Rx · offset, 固定一轴扫另一轴
    即得两条轨迹. offset 取"父级逆 × 局部位置": 控制器 scale 恒为 1 属 rig 不变量,
    异常缩放时轨迹按比例失真, 不另行修正.
    """
    controller = rig_controller_of(light)
    if controller is None:
        return None
    eu = controller.matrix_basis.to_euler('XYZ')
    frame = controller.matrix_world @ (Matrix.Rotation(eu.z, 4, 'Z') @ Matrix.Rotation(eu.x, 4, 'X')).inverted()
    return frame, light.matrix_parent_inverse @ light.location, eu.z, eu.x


def rig_trajectory(light: Object, segments: int = TRAJECTORY_SEGMENTS) -> tuple[list[Vector], list[Vector], Vector] | None:
    """灯光在"只改方位角"/"只改高度角"下的两条轨迹(世界坐标)与当前灯位

    - 方位轨迹 = 水平圆环: 半径 d·cos(高度角), 所在高度 d·sin(高度角)(转台模型:
      扫方位时高度角恒定); 高度角趋近 ±90° 时圆环收缩为点, 是其真实行为
    - 高度轨迹 = 当前方位的子午面大圆, 半径 d; 取整圆——高度角越过 90° 时灯从极点
      另一侧继续走, 整圆让这段在视觉上连续

    Args:
        light: 灯光物体(其父级即控制器)
        segments: 每条轨迹的分段数
    Returns:
        (方位圆环点列, 高度大圆点列, 当前灯位); 灯光无控制器返回 None;
        灯与控制器重合(距离 0)时两条点列为空列表
    """
    resolved = _trajectory_frame(light)
    if resolved is None:
        return None
    frame, offset, azimuth, elevation = resolved
    position = light.matrix_world.translation.copy()
    if offset.length <= _EPS:
        return [], [], position
    elevation_mx = Matrix.Rotation(elevation, 4, 'X')
    azimuth_mx = Matrix.Rotation(azimuth, 4, 'Z')
    steps = [2.0 * pi * index / segments for index in range(segments)]
    ring = [frame @ (Matrix.Rotation(step, 4, 'Z') @ elevation_mx) @ offset for step in steps]
    meridian = [frame @ (azimuth_mx @ Matrix.Rotation(step, 4, 'X')) @ offset for step in steps]
    return ring, meridian, position


def rig_trajectory_ticks(light: Object, step_degrees: float = 30.0) -> tuple[list[tuple[Vector, str | None]], list[tuple[Vector, str | None]]]:
    """两条轨迹上的刻度点(世界坐标)与正轴标记, 供调用方绘制实心圆点

    - 方位圆环: 按方位角等分, 强制并入 0/90/180/270 四个正轴位置(步长不整除 90 时同样存在)
    - 高度大圆: 按高度角等分, 同样并入 0/90/180/270(0/180 为水平方向, 90/270 为竖直方向)
    - 正轴标记只给这两组 0/90/180/270 处的刻度, 其余为 None(调用方据此上轴线颜色与加倍直径):
      圆环取**水平**主分量(X 或 Y, 高度角到 ±90° 圆环退化到极点时取 Z);
      大圆取**三维**主分量(极点处即 Z)

    Args:
        light: 灯光物体
        step_degrees: 相邻刻度的角度间隔(度)
    Returns:
        (方位圆环刻度, 高度大圆刻度), 每项为 [(点, 主轴), ...], 主轴为 "X"/"Y"/"Z" 或 None;
        无控制器或距离 0 时返回两个空列表
    """
    resolved = _trajectory_frame(light)
    if resolved is None:
        return [], []
    frame, offset, azimuth, elevation = resolved
    if offset.length <= _EPS:
        return [], []
    elevation_mx = Matrix.Rotation(elevation, 4, 'X')
    azimuth_mx = Matrix.Rotation(azimuth, 4, 'Z')
    ring_ticks = []
    meridian_ticks = []
    for degrees in _tick_angles(step_degrees):
        rotation = Matrix.Rotation(radians(degrees), 4, 'Z')
        point = frame @ (rotation @ elevation_mx) @ offset
        axis = _ring_tick_axis(rotation @ elevation_mx, offset) if _is_axis_angle(degrees) else None
        ring_ticks.append((point, axis))
    for degrees in _tick_angles(step_degrees):
        rotation = Matrix.Rotation(radians(degrees), 4, 'X')
        point = frame @ (azimuth_mx @ rotation) @ offset
        axis = _meridian_tick_axis(azimuth_mx @ rotation, offset) if _is_axis_angle(degrees) else None
        meridian_ticks.append((point, axis))
    return ring_ticks, meridian_ticks


def _is_axis_angle(degrees: float) -> bool:
    """是否正轴刻度(0/90/180/270 度, 容差吸收等分角的浮点误差)"""
    return any(abs(degrees - target) <= 1e-6 for target in TRAJECTORY_AXIS_ANGLES)


def _tick_angles(step_degrees: float) -> list[float]:
    """刻度的角度(度)序列: 步长等分网格并入 0/90/180/270 后升序去重

    网格按 round(360 / 步长) 均分, 步长不整除 360 时以等分角代替名义步长(如 7° →
    51 等分 ≈ 7.06°), 保证首尾相接不出现缺口.
    """
    step = max(float(step_degrees), 1.0)
    count = max(1, int(round(360.0 / step)))
    angles = {round(index * 360.0 / count, 6) for index in range(count)}
    angles.update(TRAJECTORY_AXIS_ANGLES)
    return sorted(angles)


def _ring_tick_axis(rotation: Matrix, offset: Vector) -> str:
    """方位圆环刻度所在主轴: 水平主分量为 X 或 Y; 圆环退化到极点(水平分量为零)时取 Z"""
    direction = rotation @ offset
    horizontal = Vector((direction.x, direction.y, 0.0))
    if horizontal.length <= _EPS:
        return "Z"
    return "X" if abs(horizontal.x) >= abs(horizontal.y) else "Y"


def _meridian_tick_axis(rotation: Matrix, offset: Vector) -> str:
    """高度大圆刻度所在主轴: 三维主分量(极点处竖直分量为 Z)"""
    direction = rotation @ offset
    components = (abs(direction.x), abs(direction.y), abs(direction.z))
    return ("X", "Y", "Z")[components.index(max(components))]


def sync_controllers_visibility(scene: Scene) -> int:
    """把全部控制器的视口可见位单向同步到其灯光子级, 返回改动数

    行内"在视图中禁用"开关与 +Ctrl 隔离共用此收口: 灯光藏控制器跟着藏, 灯光显
    控制器跟着显; 用户在大纲单独隐藏控制器不回写灯光(单向). 渲染位不同步
    (空物体不参与渲染).
    """
    changed = 0
    for obj in scene.objects:
        if obj.type != 'LIGHT' or obj.library is not None:
            # 链接灯的控制器指针指向库内空体, hide_viewport 只读(与 rig 侧其它功能一致拒绝链接)
            continue
        controller = rig_controller_of(obj)
        if controller is None or controller.library is not None:
            continue
        if controller.hide_viewport != obj.hide_viewport:
            controller.hide_viewport = obj.hide_viewport
            changed += 1
    return changed


# ------------------------------------------------------------
# 模态吸附的射线拾取与对齐数学
# ------------------------------------------------------------


def raycast_surface(context: Context, coords: tuple[float, float]) -> tuple[Vector, Vector] | None:
    """从鼠标位置向场景投射射线, 返回 (命中点, 朝向观察侧的法线); 未命中返回 None

    rig 自身(空物体/灯光)没有可命中几何, scene.ray_cast 不会命中, 无需排除.
    """
    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None
    depsgraph = context.evaluated_depsgraph_get()
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coords)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coords)
    hit, location, normal, _idx, _obj, _mx = context.scene.ray_cast(depsgraph, origin, direction)
    if not hit:
        return None
    normal = Vector(normal)
    if normal.dot(direction) > 0.0:
        # 命中面背对观察者(射线打穿背面)时取反, 法线恒朝向观察侧
        normal = -normal
    return location, normal.normalized()


def reflection_direction(view_point: Vector, hit: Vector, normal: Vector) -> Vector:
    """视线在命中点的镜面反射方向(从命中点指向镜像观察位置)

    反射模式语义: 控制器 +Y 轴对齐该方向后, 灯光(刚性跟随、-Z 恒指向控制器)照亮
    点击点; 入射角=反射角由本方向保证, 高光落点精度取决于灯光偏移是否恰在反射
    线上(灯光保持相对偏移, 只对齐 +Y 轴).
    """
    incident = (hit - view_point).normalized()
    reflected = incident - 2.0 * incident.dot(normal) * normal
    if reflected.length <= _EPS:
        return normal
    return reflected.normalized()


def align_controller_y(controller: Object, direction: Vector) -> None:
    """把控制器空物体的局部 +Y 轴对齐到给定世界方向(位置与缩放保持不变)

    rig 几何约定灯落在控制器局部 +Y 轴上, 法向/反射对齐因此对 Y 轴而非 Z 轴.
    """
    quat = direction.to_track_quat('Y', 'Z')
    loc, _rot, scale = controller.matrix_basis.decompose()
    controller.matrix_basis = Matrix.Translation(loc) @ quat.to_matrix().to_4x4() @ Matrix.Diagonal(scale.to_4d())
