"""
灯光资产目录扫描模块

高级设置子面板(图像/IES 档)的资源选择器后端: 扫描偏好目录下的分类子文件夹与
缩略图条目(顶层 PNG=缩略图, Textures/ 或 IES/ 子目录内同名文件=源文件),
缩略图图标走文件级预览集合(不产生图像数据块), 并负责源文件的查找与图像数据块的查重加载.

主要功能:
- list_categories / list_assets: 目录结构与条目扫描(条目须有源文件才收录)
- preview_icon_id: 缩略图预览图标(文件级预览集合; 像素由 Blender 在图标首次绘制时
  经后台任务按磁盘缩略图缓存加载, 会话内零解码起手)
- find_or_load_image: 按绝对路径查重加载图像数据块(应用真实纹理源用)
- release_previews: 释放预览集合(插件注销时调用)
- resolve_asset: 按条目键反查资产(缩略图枚举 update 回调用)
"""

import os
import time
import zlib
from pathlib import Path

import bpy
from bpy.utils import previews

# 目录约定: <根>/<分类>/ 顶层 PNG 为缩略图, 子目录内同名文件为源文件
IMAGE_SOURCE_SUBDIR = "Textures"
IES_SOURCE_SUBDIR = "IES"

# 图像源文件的候选扩展名(按序取首个命中)
_IMAGE_SOURCE_EXTS = (".jpg", ".jpeg", ".png", ".exr")

# 文件级预览集合: load 只登记路径零读取, 像素在图标首次绘制时由 Blender 后台任务
# 经磁盘缩略图缓存加载(mtime 失效自动重生成), 会话内不产生 Image 数据块;
# None = 已释放, 再取用时惰性重建(注销后绘制/热重载兜底)
_preview_collection: previews.ImagePreviewCollection | None = None

# 目录扫描缓存(绘制期每帧两次扫描的降噪): 键 = 扫描标识, 值 = (目录签名, 结果列表);
# 签名 = 目录内 (名字, mtime_ns) 元组(含源文件子目录)——增删/改写任一变化即失效重扫
_scan_cache: dict = {}
_SCAN_CACHE_MAX = 256


# 签名短窗缓存(键 = 目录路径, 值 = (单调时刻, 签名)): _cached_scan 的缓存命中路径
# 每帧仍要 2-3 趟 iterdir+stat 算签名, OneDrive 云占位/网络盘上每帧都卡 UI 线程;
# 签名在窗口内视作不变——绘制帧间隔毫秒级, 0.25s 窗口对真实改动感知不到延迟
_SIG_CACHE: dict = {}
_SIG_WINDOW_SECONDS = 0.25


def _dir_signature(directory: Path) -> tuple:
    """目录签名((名字, mtime_ns) 按名排序); 目录不存在返回 ()"""
    now = time.monotonic()
    hit = _SIG_CACHE.get(directory)
    if hit is not None and now - hit[0] <= _SIG_WINDOW_SECONDS:
        return hit[1]
    if not directory.is_dir():
        sig = ()
    else:
        try:
            sig = tuple(sorted((item.name, item.stat().st_mtime_ns) for item in directory.iterdir()))
        except OSError:
            # 目录在签名期被移走(极端竞态): 视为空, 下次绘制按空目录口径走
            sig = ()
    if len(_SIG_CACHE) >= 256:
        _SIG_CACHE.clear()
    _SIG_CACHE[directory] = (now, sig)
    return sig


def _cached_scan(cache_key: str, scan_dir: Path, sub_dirs: tuple, scan_fn) -> list:
    """带签名的扫描记忆化: 签名不变直接回缓存, 变化则重扫并更新"""
    sig = (_dir_signature(scan_dir), tuple((name, _dir_signature(scan_dir / name)) for name in sub_dirs))
    hit = _scan_cache.get(cache_key)
    if hit is not None and hit[0] == sig:
        return hit[1]
    result = scan_fn()
    if len(_scan_cache) >= _SCAN_CACHE_MAX:
        _scan_cache.clear()
    _scan_cache[cache_key] = (sig, result)
    return result


def asset_key(name: str) -> str:
    """条目稳定键(文件名 crc32 十六进制): 跨扫描稳定, 重命名文件即换键"""
    return format(zlib.crc32(name.encode("utf-8")) & 0xFFFFFFFF, "08x")


def list_categories(root: str) -> list:
    """根目录下的分类子文件夹名(排序; 根目录缺失/非目录/为空返回 [])"""
    if not root:
        return []
    root_path = Path(root)
    if not root_path.is_dir():
        # 非目录(含不存在/是文件)直接空表: iterdir 会抛 NotADirectoryError
        return []

    def _scan():
        return sorted(item.name for item in root_path.iterdir() if item.is_dir() and not item.name.startswith("."))

    return _cached_scan(("cats", _norm_path(root)), root_path, (), _scan)


def _find_source(source_dir: Path, stem: str, exts) -> str | None:
    """在源文件子目录里按主干名匹配首个存在的文件"""
    for ext in exts:
        candidate = source_dir / (stem + ext)
        if candidate.is_file():
            return str(candidate)
    return None


def list_assets(root: str, category: str, kind: str) -> list:
    """某分类下的资产条目(排序, 仅收录源文件存在的条目; 带签名记忆化, 重绘期免重复扫描)

    kind: 'IMAGE' -> Textures/ 内同名图像; 'IES' -> IES/ 内同名 .ies.
    条目为 dict: name(主干名)/key(稳定键)/thumb(缩略图绝对路径)/source(源文件绝对路径)/
    source_name(源文件名).
    """
    if not root or not category:
        return []
    cat_dir = Path(root) / category
    if not cat_dir.is_dir():
        return []
    subdir_name = IMAGE_SOURCE_SUBDIR if kind == 'IMAGE' else IES_SOURCE_SUBDIR
    exts = _IMAGE_SOURCE_EXTS if kind == 'IMAGE' else (".ies",)

    def _scan():
        assets = []
        for thumb in sorted(cat_dir.glob("*.png")):
            if not thumb.is_file():
                continue
            source = _find_source(cat_dir / subdir_name, thumb.stem, exts)
            if source is None:
                continue
            assets.append({"name": thumb.stem, "key": asset_key(thumb.stem), "thumb": str(thumb), "source": source, "source_name": Path(source).name})
        return assets

    return _cached_scan(("assets", _norm_path(root), category, kind), cat_dir, (subdir_name,), _scan)


def resolve_asset(root: str, category: str, kind: str, key: str):
    """按稳定键反查资产条目(查无返回 None)"""
    for asset in list_assets(root, category, kind):
        if asset["key"] == key:
            return asset
    return None


def _norm_path(path: str) -> str:
    """路径归一(解 // 相对前缀 + 绝对化 + 大小写归一, 供集合比对)"""
    return os.path.normcase(os.path.abspath(bpy.path.abspath(path)))


def _get_preview_collection():
    """预览集合取用(已释放则重建): 注销释放后再遇绘制不炸"""
    global _preview_collection
    if _preview_collection is None:
        _preview_collection = previews.new()
    return _preview_collection


def release_previews() -> None:
    """释放预览集合(插件注销时调用): 全部预览条目与图标归还 Blender"""
    global _preview_collection
    if _preview_collection is not None:
        previews.remove(_preview_collection)
        _preview_collection = None


def preview_icon_id(thumb_path: str) -> int:
    """缩略图的预览图标 id(文件级预览集合, 不产生图像数据块; 文件浏览器同款机制)

    键 = 规范化缩略图路径(同路径跨扫描复用同一条目); 文件缺失/不可读(含 OneDrive
    仅云占位)的像素在后台加载期失败, 图标画空位, 不提示.
    """
    if not thumb_path:
        return 0
    key = _norm_path(thumb_path)
    pcoll = _get_preview_collection()
    preview = pcoll.get(key)
    if preview is None:
        preview = pcoll.load(key, thumb_path, 'IMAGE')
    return preview.icon_id if preview is not None else 0


def find_or_load_image(source_path: str):
    """按绝对路径取图像数据块(同路径查重复用, 查重按已载入数据块)"""
    if not source_path:
        return None
    try:
        return bpy.data.images.load(source_path, check_existing=True)
    except (RuntimeError, ValueError):
        # 文件缺失/不可读(含 OneDrive 仅云占位): 按约定不提示, 保持现状
        return None
