"""
场景助手列表与面板状态模块

提供以下功能:
- SceneHelperState: 六个资源列表的快照集合与活跃索引、选区同步/0 用户开关、
  行内列显示开关、详情子面板展开态与 PBR 镜像枚举
- CameraResolutionSettings / SceneResolutionState: 相机独立分辨率(挂物体)与
  场景侧覆写状态(挂场景), 随 .blend 保存
- LightAdvancedSettings: 灯光高级设置状态(挂灯光数据块), 任一项变化统一重接
  灯光节点树的 Emission 接线(算法见 utils/blender/light_advanced.py)
- 材质 PBR 镜像枚举的 update 回调: 坐标输出重建接线 / 投影与融合统一写全部命中纹理
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载(WM 级不随 .blend 保存;
  物体/场景级随 .blend 保存)
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot

注: 单一状态组覆盖全部六个列表; 列表种类元数据见 scene_state.LIST_SPECS.
"""

from bpy.props import BoolProperty, BoolVectorProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Context, PropertyGroup

from ...common.blender.list_snapshot import ListItem, is_syncing
from .handlers import on_images_index_update, on_list_scope_update, on_sync_toggle, tag_3d_views
from .preference import resolve_library_root
from .scene_state import LIST_SPECS, panel_light, panel_material
from .utils import (
    ARRAY_MODE_RECT,
    ARRAY_MODE_RING,
    MARK_IMAGE_ARRAY,
    MARK_IMAGE_TEX,
    MARK_IES_TEX,
    apply_light_advanced_wiring,
    apply_light_isolate_world_mute,
    collection_objects_recursive,
    detect_pbr_texture_graph,
    find_advanced_node,
    find_or_load_image,
    get_pbr_texcoord_pair,
    init_camera_resolution_from_scene,
    is_light_rig_sync_suppressed,
    is_texcoord_update_suppressed,
    light_collections_isolated,
    lights_viewport_isolated,
    list_assets,
    list_categories,
    preview_icon_id,
    resolve_asset,
    rig_controller_of,
    reset_light_self_rotation,
    select_only,
    set_active_collection,
    set_controller_azimuth,
    set_controller_elevation,
    set_light_distance,
    set_light_self_rotation,
    set_texcoord_output,
    sync_active_camera_resolution,
)
from .utils._constants import CAMERA_RES_MAX, PROJECTION_OPTIONS, RIG_DEFAULT_DISTANCE, RIG_DEFAULT_ELEVATION, TEXCOORD_OPTIONS

# 自旋转镜像的默认值(0 = 无自转): 属性 default 与"恢复默认值即重新瞄准"的判据共用,
# 改一处即两处同步
_RIG_SELF_ROTATION_DEFAULT = 0.0

# "灯光&阴影链接"子面板的三模式(灯光面板详情区): 前两档编辑面板活跃灯光的链接集合,
# 第三档反查视口活动物体被哪些灯链接. 条目名为系统词条(Light/Shadow Linking 命中
# 原生面板标题)不入插件词典
LIGHT_LINKING_MODES = (
    ('LIGHT_LINKING', "Light Linking", "Edit which objects receive light from the active light of the Lights panel"),
    ('SHADOW_LINKING', "Shadow Linking", "Edit which objects cast shadows for the active light of the Lights panel"),
    ('OBJECT_LINKING', "Object Linking", "Look up which lights light-link or shadow-link the active object"),
)

# 高级设置的一级模块候选: 四项统一绘制("无"=不激活, 激活按钮已从标题栏移除),
# 灯型校验下沉到面板各档的提示行(渐变/图像=面光/聚光, IES=点光, 太阳光整块提示).
# 标签用 "Gradient Module" 反译规避: "Gradient" 命中系统 mo("梯度渐变"), 需显示"渐变";
# "None"/"Image" 为系统词条(无/图像), "IES" 为专有名词, 均不入典
ADVANCED_MODE_ITEMS = (
    ('NONE', "None", "Deactivate the advanced settings (no module drives the light)"),
    ('GRADIENT', "Gradient Module", "Drive the emission with a procedural gradient (radial, linear or softbox)"),
    ('IMAGE', "Image", "Project an image through the light"),
    ('IES', "IES", "Shape the light intensity with an IES profile"),
)


# 渐变二级模式: 三种模板节点组的候选(与 light_advanced 模板的类型串一致)
GRADIENT_TYPE_ITEMS = (
    ('RADIAL', "Radial", "Spherical falloff from the center of the light"),
    ('LINEAR', "Linear", "Linear falloff along a rotatable axis, tilable by the array factor"),
    ('SOFTBOX', "Softbox", "Crossed sine stripes like a softbox grid, tilable in X and Y"),
)

# 图像档接线目标: 颜色=彩色投影(默认), 强度=灰度图调制亮度("Color"/"Strength" 均系统词条不入典)
IMAGE_TARGET_ITEMS = (
    ('COLOR', "Color", "Texture drives the emission color"),
    ('STRENGTH', "Strength", "Texture drives the emission strength (for grayscale maps)"),
)

# 图像档阵列方式: 矩形平铺 / 环形阵列(写阵列坐标组的阵列方式插座, 见 on_image_array_mode_update)
IMAGE_ARRAY_MODE_ITEMS = (
    ('RECT', "Rect", "Rectangular tiling of the projected texture"),
    ('RING', "Ring", "Ring array of the projected texture around the center"),
)


def _pbr_textures(context: Context) -> list | None:
    """面板活动材质命中的全部 PBR 图像纹理; 不满足检测条件返回 None"""
    mat = panel_material(context)
    if mat is None:
        return None
    pbr = detect_pbr_texture_graph(mat)
    return list(pbr["tex_by_channel"].values()) if pbr["ok"] else None


def on_pbr_texcoord_update(self, context: Context):
    """坐标输出镜像枚举的 update 回调: 重建 TexCoord -> Mapping 的接线

    真值在节点连接关系里, 本枚举只是镜像; 用户改动下拉 = 换接线(不进 Undo 栈, tooltip 说明).
    面板 draw 期把连接真值写回镜像时经算法层抑制跳过本回调(否则每帧重画都会重建接线).
    """
    if is_texcoord_update_suppressed():
        return
    mat = panel_material(context)
    if mat is None:
        return
    target = get_pbr_texcoord_pair(mat)
    if target is None:
        return
    tex_coord, mapping = target
    set_texcoord_output(tex_coord, mapping, self.pbr_texcoord)


def on_pbr_projection_update(self, context: Context):
    """投影统一控制镜像枚举的 update 回调: 把新投影写进全部命中的图像纹理

    真值散在各 Image Texture 节点的 projection 上, 本枚举只是镜像; 用户改动 = 统一改写
    全部命中纹理. Blend 只在 Box 时有意义: 改到非 Box 时把 Blend 归零(与节点面板一致).
    """
    if is_texcoord_update_suppressed():
        return
    textures = _pbr_textures(context)
    if textures is None:
        return
    for tex in textures:
        tex.projection = self.pbr_projection
        if self.pbr_projection != 'BOX':
            tex.projection_blend = 0.0


def on_pbr_projection_blend_update(self, context: Context):
    """投影融合统一控制的 update 回调: 把新 Blend 写进全部命中的图像纹理"""
    if is_texcoord_update_suppressed():
        return
    textures = _pbr_textures(context)
    if textures is None:
        return
    for tex in textures:
        tex.projection_blend = self.pbr_projection_blend


def on_cameras_show_names_update(self, context: Context):
    """视图相机名称开关的 update 回调: 批量设置场景中全部相机的 show_name

    载入文件后的实况回读走护栏写入(handlers._sync_camera_names_state), 见位即跳过,
    避免回读把用户在 N 面板手动设置的个别相机 show_name 批量覆写.
    """
    if is_syncing():
        return
    for obj in context.scene.objects:
        if obj.type == 'CAMERA':
            obj.show_name = self.cameras_show_names


def on_camera_resolution_update(self, context: Context):
    """独立分辨率开关/数值的 update 回调: 开启时按需初始化, 并即时同步场景输出

    面板勾选/拖动 X/Y 逐次触发(幂等 no-op 快), 改场景相机的其它路径仍由 handlers 兜底.
    init 的护栏内写回(resolution.py 经 set_guarded)会再次进入本回调: 见位即跳过,
    否则场景输出退化时(退出期 RNA 读 0)同值写会无限递归.
    """
    if is_syncing():
        return
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    if self.use_independent:
        init_camera_resolution_from_scene(self, scene)
    sync_active_camera_resolution(scene)


def on_lights_mute_world_update(self, context: Context):
    """屏蔽世界开关的 update 回调: 灯光或灯光集合正处于隔离态时立即应用/撤除世界屏蔽

    开关只配置"隔离"按钮的行为; 非隔离态下切换不触碰世界(下次隔离生效).
    灯光隔离与集合隔离的判定各有一套(后者靠集合的 hide_viewport), 任一成立即视为隔离态,
    否则在集合隔离期间切换开关会把世界屏蔽撤掉.
    """
    scene = getattr(context, "scene", None)
    view_layer = getattr(context, "view_layer", None)
    if scene is None or view_layer is None:
        return
    isolated = lights_viewport_isolated(scene, view_layer) or light_collections_isolated(scene, view_layer)
    apply_light_isolate_world_mute(scene, isolated, self.lights_mute_world)
    # 静音连线不触发着色器重估与视口重绘, 显式刷新
    tag_3d_views()


def on_light_collections_index_update(self, context: Context):
    """灯光集合列表活跃索引回调: 点击行时联动大纲管理器

    大纲管理器的集合行选中态没有 RNA API, 可见的"高亮落到该集合"只能靠选中其内部
    灯光物体(大纲里橙色高亮显示在对应集合下), 故同时设活动层集合 + 独占选中集合内
    灯光. 程序化写入(快照重建/高亮回写)均在护栏内, 见位即跳过.
    """
    if is_syncing():
        return
    idx = self.light_collections_active_index
    if not 0 <= idx < len(self.light_collections):
        return
    # 同名本地/链接对按行标记消歧(经 resolver), 不能按名称裸查
    coll = LIST_SPECS["light_collections"].resolve(context, self.light_collections[idx])
    view_layer = getattr(context, "view_layer", None)
    if coll is None or view_layer is None:
        return
    set_active_collection(view_layer, coll)
    # 只选中灯光: 本列表承载灯光面板语义, 集合内混入的其它物体不随行点击选中(与 README 口径一致);
    # 有控制器的灯光连同其控制器空物体一并选中(rig 作为整体操作)
    lights = [obj for obj in collection_objects_recursive(coll) if obj.type == 'LIGHT']
    rig_objects: list = []
    for light in lights:
        rig_objects.append(light)
        controller = rig_controller_of(light)
        if controller is not None:
            rig_objects.append(controller)
    if rig_objects:
        select_only(context, rig_objects)
    tag_3d_views()


def _write_light_rig_prop(context: Context, write) -> None:
    """灯光方位镜像属性的统一写回收口

    镜像属性只是变换的视图, 真值在控制器空物体的旋转与灯光的局部位置上; 面板
    draw 期回读镜像经算法层抑制跳过(否则每帧重画都写一次变换), 用户改动才落到
    变换上. 无面板活跃灯光或无控制器时不写(镜像值维持原样, 属合法空态).
    """
    if is_light_rig_sync_suppressed():
        return
    light = panel_light(context)
    if light is None:
        return
    controller = rig_controller_of(light)
    if controller is None:
        return
    write(light, controller)


def on_light_rig_azimuth_update(self, context: Context):
    """方位角镜像的 update 回调: 写回控制器旋转的 Z 分量"""
    _write_light_rig_prop(context, lambda light, controller: set_controller_azimuth(controller, self.rig_azimuth))


def on_light_rig_elevation_update(self, context: Context):
    """高度角镜像的 update 回调: 写回控制器旋转的 X 分量"""
    _write_light_rig_prop(context, lambda light, controller: set_controller_elevation(controller, self.rig_elevation))


def on_light_rig_distance_update(self, context: Context):
    """距离镜像的 update 回调: 按新距离缩放灯光的局部位置(方向保持)"""
    _write_light_rig_prop(context, lambda light, controller: set_light_distance(light, self.rig_distance))


def on_light_rig_self_rotation_update(self, context: Context):
    """自旋转镜像的 update 回调: 写灯光局部旋转的 Y 分量; 归零时整体归位瞄准姿态

    不直调灯光的 rotation_euler RNA: 整组欧拉上按 Backspace 会三轴全归零(Blender
    对默认值的语义), 打破瞄准; 镜像只暴露 Y. 恢复默认值(0)时顺手把 X/Z 一并归位——镜像看不
    见被 Alt+R 之类带歪的瞄准分量, 归零这一动作正好当作“重新瞄准”的入口.
    """
    if self.rig_self_rotation == _RIG_SELF_ROTATION_DEFAULT:
        _write_light_rig_prop(context, lambda light, controller: reset_light_self_rotation(light))
        return
    _write_light_rig_prop(context, lambda light, controller: set_light_self_rotation(light, self.rig_self_rotation))


def on_light_advanced_update(self, context: Context):
    """高级设置状态的统一 update 回调: 幂等重接本灯 Emission 的插件接线

    模块与渐变模式两类变化共用一个回调(接线算法按当前状态全量重算);
    self 即挂在灯光数据块上的状态组, id_data 直接取到属主灯光, 与面板活跃项无关.
    """
    apply_light_advanced_wiring(self.id_data)


def on_image_array_mode_update(self, context: Context):
    """阵列方式胶囊的 update 回调: 把档位写进阵列坐标组实例的阵列方式插座

    Menu Switch 组写枚举项名, 旧 Mix 组(float 因子 0/1)按插座类型分派;
    同步图像纹理的扩展属性(环形=裁剪 / 其它=重复); 条件显示的参数行按插座值读真值.
    """
    node = find_advanced_node(self.id_data, MARK_IMAGE_ARRAY)
    if node is not None:
        sock = node.inputs.get("阵列方式")
        if sock is None:
            # 组实例缺座(版本不匹配/被手改): 按旧 Mix 组口径跳过, 不在 update 回调里炸
            pass
        elif sock.type == 'MENU':
            sock.default_value = ARRAY_MODE_RING if self.image_array_mode == 'RING' else ARRAY_MODE_RECT
        else:
            sock.default_value = 0.0 if self.image_array_mode == 'RECT' else 1.0
    tex = find_advanced_node(self.id_data, MARK_IMAGE_TEX)
    if tex is not None:
        tex.extension = 'CLIP' if self.image_array_mode == 'RING' else 'REPEAT'


def _adv_pick_items(root: str, category: str, kind: str) -> list:
    """缩略图枚举候选(共享实现): 标识=文件名稳定键, 图标即条目身份; 名称与悬停说明留空
    (运行期拼给动态枚举的非 ASCII 文案会经 C 层渲染成乱码, 选中名走网格下方 label 常显)"""
    items = []
    for idx, asset in enumerate(list_assets(root, category, kind)):
        items.append((asset["key"], "", "", preview_icon_id(asset["thumb"]), idx))
    return items


def _adv_state_category(root: str, state, field: str) -> str:
    """面板状态里的当前分类, 空/失效(目录改过)回落首分类, 与绘制侧显示回退恒一致;
    无分类目录返回空串(枚举即空表)"""
    categories = list_categories(root)
    category = getattr(state, field, "")
    if categories and category not in categories:
        return categories[0]
    return category


def _adv_image_pick_items(self, context):
    """图像纹理缩略图候选(根目录取选中的资产库, 分类取面板状态并回落首分类)"""
    root = resolve_library_root('IMAGE', self.adv_image_library)[0]
    return _adv_pick_items(root, _adv_state_category(root, self, "adv_image_category"), 'IMAGE')


def _adv_ies_pick_items(self, context):
    """IES 光域网缩略图候选(同上)"""
    root = resolve_library_root('IES', self.adv_ies_library)[0]
    return _adv_pick_items(root, _adv_state_category(root, self, "adv_ies_category"), 'IES')


def _apply_picked_asset(state, context: Context, kind: str) -> None:
    """缩略图选中共用落地: 把选中资产写到面板活跃灯光的插件链节点上

    外部路径优先: 灯上的外部文件路径非空时缩略图点击被跳过(清空外路径恢复).
    灯光/链节点/资产任一缺失(如模式已切走、库已改、文件失效)都静默跳过,
    与"OneDrive 云占位加载失败不提示"同口径; 图像按路径查重复用数据块.
    """
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    light = obj.data
    ext_field = "image_external" if kind == 'IMAGE' else "ies_external"
    if getattr(light.ch_advanced, ext_field, ""):
        return
    key = getattr(state, "adv_image_pick" if kind == 'IMAGE' else "adv_ies_pick", "")
    if not key:
        return
    root = resolve_library_root(kind, getattr(state, "adv_image_library" if kind == 'IMAGE' else "adv_ies_library"))[0]
    category_field = "adv_image_category" if kind == 'IMAGE' else "adv_ies_category"
    # 分类走与绘制侧/枚举回调同款的失效回退: 首开态存储值为空, 直读会查无资产静默早退
    category = _adv_state_category(root, state, category_field)
    asset = resolve_asset(root, category, kind, key)
    if asset is None:
        return
    node = find_advanced_node(light, MARK_IMAGE_TEX if kind == 'IMAGE' else MARK_IES_TEX)
    if node is None:
        return
    if kind == 'IMAGE':
        image = find_or_load_image(asset["source"])
        if image is not None:
            node.image = image
    else:
        node.filepath = asset["source"]


def on_adv_image_pick_update(self, context: Context):
    """图像纹理缩略图选中回调: 应用到面板活跃灯光"""
    _apply_picked_asset(self, context, 'IMAGE')


def on_adv_ies_pick_update(self, context: Context):
    """IES 缩略图选中回调: 写 EXTERNAL 文件路径到面板活跃灯光"""
    _apply_picked_asset(self, context, 'IES')


def on_image_external_update(self, context: Context):
    """外部图像路径回调: 非空时加载并写到面板活跃灯光的图像纹理节点"""
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    ext = self.image_external
    node = find_advanced_node(obj.data, MARK_IMAGE_TEX)
    if node is None:
        return
    if ext:
        image = find_or_load_image(ext)
        if image is not None:
            node.image = image
    elif node.image is not None:
        node.image = None


def on_ies_external_update(self, context: Context):
    """外部 IES 路径回调: 非空时写到面板活跃灯光的 IES 纹理节点"""
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    ext = self.ies_external
    node = find_advanced_node(obj.data, MARK_IES_TEX)
    if node is None:
        return
    node.filepath = ext


class LightLinkItem(PropertyGroup):
    """灯光&阴影链接列表的镜像条目(真值在灯侧链接集合, 绘制期签名比对重建)

    条目字段即行内钮的算子载荷: 行内状态切换/移除与侧列移除直接取条目组装,
    不必在绘制期再解析面板活跃灯. writable 记录重建时发射器是否可写(库链接灯整行置灰).
    物体链接反查为合并行: 一行一灯, state/direct 是灯光链接侧, shadow_state/shadow_direct
    是阴影链接侧(空串 = 该灯此侧无链接关系, 行内置灰标识), users = 共享该灯
    灯光链接集合的灯数(行尾数字, 点击独立化); subject_name/is_collection 记反查主体
    (活动物体或集合视角下的活动集合), 行内钮载荷直接取条目.
    """

    src_name: StringProperty(name="Name")  # type: ignore
    emitter_name: StringProperty()  # type: ignore
    subject_name: StringProperty()  # type: ignore
    link_type: StringProperty()  # type: ignore
    state: StringProperty()  # type: ignore
    is_collection: BoolProperty()  # type: ignore
    direct: BoolProperty()  # type: ignore
    writable: BoolProperty()  # type: ignore
    shadow_state: StringProperty()  # type: ignore
    shadow_direct: BoolProperty()  # type: ignore
    users: IntProperty(default=1)  # type: ignore


class SceneHelperState(PropertyGroup):
    """场景助手六个列表的快照与全部 UI 状态(WM 级, 不随 .blend 保存)"""

    # --- 快照与活跃索引(索引只表高亮, 不做场景联动) ---
    cameras: CollectionProperty(type=ListItem)  # type: ignore
    cameras_active_index: IntProperty(default=0)  # type: ignore
    lights: CollectionProperty(type=ListItem)  # type: ignore
    lights_active_index: IntProperty(default=0)  # type: ignore
    # 灯光集合(CLS_ 前缀)管理列表: 灯光面板主列表上方的附属列表
    light_collections: CollectionProperty(type=ListItem)  # type: ignore
    light_collections_active_index: IntProperty(default=0, update=on_light_collections_index_update)  # type: ignore
    materials: CollectionProperty(type=ListItem)  # type: ignore
    materials_active_index: IntProperty(default=0)  # type: ignore
    worlds: CollectionProperty(type=ListItem)  # type: ignore
    worlds_active_index: IntProperty(default=0)  # type: ignore
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_images_index_update)  # type: ignore

    # --- 列表范围与同步 ---
    # 选区同步(选项菜单第 1 位, 世界环境无): 四个面板共用同一个开关
    sync_selection: BoolProperty(name="Sync Selection", default=True, update=on_sync_toggle, description="Highlight the list item of the active object whenever the active object changes")  # type: ignore
    # 显示0用户(选项菜单第 2 位, 无该概念的面板不显示)
    # 材质/世界/图像默认开启: 列表默认列出全部数据块, 只有用户主动关掉时才
    # 过滤到"有使用者"的子集. 图像侧另有硬理由: 图像生成/通道捕获的产物都是 0 用户的独立数据块,
    # 默认过滤会让它们在面板里"不存在"; 且这类图像被图像编辑器显示过就带上一个临时使用者
    # (id_us_ensure_real), 点伪用户时该临时位被转正而 users 不加一, "真实使用者"口径随即判成
    # 0 用户 → 整行忽隐忽现.
    show_zero_user_materials: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list materials that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_worlds: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list worlds that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_images: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list images that have no users (orphans and fake-user only)")  # type: ignore
    # 显示库链接(材质/世界/图像三处选项共用同一开关): 是否列出经库链接引入的数据块, 默认开
    show_linked_data: BoolProperty(name="Show Linked Data", default=True, update=on_list_scope_update, description="Also list data-blocks linked from libraries (materials, worlds and images); turn off to list only data-blocks from this file")  # type: ignore

    # --- 列表内建过滤/排序开关镜像 ---
    # template_list 的漏斗开关存在 UIList 实例上, 算子拿不到; UIList.filter_items 每次绘制时
    # 镜像到这两条向量(顺序同 scene_state.LIST_KINDS), 供"上移/下移"判断显示顺序.
    filter_alpha: BoolVectorProperty(size=6, default=(False, False, False, False, False, False))  # type: ignore
    filter_reverse: BoolVectorProperty(size=6, default=(False, False, False, False, False, False))  # type: ignore

    # --- 详情子面板展开态(高级设置与灯光方位默认收缩, 灯光&阴影链接同) ---
    show_camera_details: BoolProperty(default=True)  # type: ignore
    show_light_details: BoolProperty(default=True)  # type: ignore
    show_light_advanced: BoolProperty(default=False)  # type: ignore
    show_light_rig: BoolProperty(default=False)  # type: ignore
    # 灯光&阴影链接子面板默认收缩
    show_light_linking: BoolProperty(default=False)  # type: ignore
    show_material_details: BoolProperty(default=True)  # type: ignore
    show_pbr_details: BoolProperty(default=True)  # type: ignore

    # --- 灯光&阴影链接子面板 ---
    # 三模式切换(灯光面板详情区, expand 绘制): 灯光/阴影链接编辑面板活跃灯光的
    # 链接集合, 物体链接反查视口活动物体
    light_linking_mode: EnumProperty(name="Mode", items=LIGHT_LINKING_MODES, default=0)  # type: ignore
    # 物体链接的集合视角(作者定): 激活后反查列表显示活动集合作为直接子集合条目在各灯
    # 链接集合中的状态, 取消激活则显示活动物体的链接状态
    use_collection_view: BoolProperty(name="Collection View", default=False, description="Show the active collection's link states instead of the active object's")  # type: ignore
    # 链接列表镜像(真值在灯侧链接集合, 绘制期签名比对重建; 不用 common.ListItem
    # 是因为其 name 带写穿 update, 镜像条目不可改名): 条目携带行内钮所需载荷
    link_members: CollectionProperty(type=LightLinkItem)  # type: ignore
    link_members_index: IntProperty(default=0)  # type: ignore
    link_members_signature: StringProperty()  # type: ignore
    object_light_links: CollectionProperty(type=LightLinkItem)  # type: ignore
    object_light_links_index: IntProperty(default=0)  # type: ignore
    object_link_signature: StringProperty()  # type: ignore

    # --- 行内列显示开关 ---
    cameras_show_lens: BoolProperty(name="Lens", default=False, description="Show the lens column")  # type: ignore
    cameras_show_type: BoolProperty(name="Type", default=False, description="Show the camera type column")  # type: ignore
    cameras_show_names: BoolProperty(name="View Camera Name", default=False, description="Show or hide the names of all cameras in the 3D view (writes each camera's show_name flag, saved with the .blend; the toggle state itself is re-read on file load)", update=on_cameras_show_names_update)  # type: ignore
    lights_show_color: BoolProperty(name="Color", default=False, description="Show the light color column")  # type: ignore
    lights_show_shadow: BoolProperty(name="Shadow", default=False, description="Show the shadow toggle column")  # type: ignore
    # 屏蔽世界: 灯光/灯光集合隔离时同时屏蔽世界输出节点的全部接入端连线(取消隔离恢复).
    # 灯光面板与灯光集合列表共用同一个开关, 两个选项菜单各显示一次
    lights_mute_world: BoolProperty(name="Mute World", default=False, update=on_lights_mute_world_update, description="While isolating a light or a light collection, also mute every link into the World Output node to isolate it from the world lighting (links are restored on un-isolating)")  # type: ignore
    materials_show_pass_index: BoolProperty(name="Pass Index", default=False, description="Show the pass index column")  # type: ignore
    materials_show_node_count: BoolProperty(name="Node Count", default=False, description="Show the material node count column")  # type: ignore
    worlds_show_color: BoolProperty(name="Color", default=False, description="Show the world color swatch")  # type: ignore

    # --- 材质 PBR 镜像枚举 ---
    # 坐标输出: 真值在 TexCoord->Mapping 的连接里, 绘制前读进镜像, 用户改动重建接线
    pbr_texcoord: EnumProperty(name="Texture Coordinate", items=TEXCOORD_OPTIONS, default=0, update=on_pbr_texcoord_update, description="Texture coordinate output feeding the Mapping node (edits node links, not undoable; affects all users of this material)")  # type: ignore
    # 投影统一控制: 真值在各 Image Texture 的 projection 上; 全部一致 -> 该值, 不一致时保持镜像原值
    pbr_projection: EnumProperty(name="Projection", items=PROJECTION_OPTIONS, default=0, update=on_pbr_projection_update, description="Projection for all PBR image textures (applied to every texture; not undoable)")  # type: ignore
    # 投影融合: 仅 Box 时显示, 写进全部命中纹理
    pbr_projection_blend: FloatProperty(name="Blend", default=0.0, subtype='FACTOR', min=0.0, max=1.0, update=on_pbr_projection_blend_update, description="Blend for box projection, applied to every PBR image texture (not undoable)")  # type: ignore

    # --- 灯光方位镜像属性(灯光控制器 rig, 灯光面板"Light Rig"折叠区绘制) ---
    # 真值在控制器空物体的旋转与灯光的局部位置上(方位角=控制器旋转 Z 分量, 高度角=X
    # 分量, 距离=灯光局部位置长度), 绘制前经算法层抑制读进镜像, 用户改动经 update 回调
    # 写回变换; 纯运行期镜像不落任何自定义属性, 不进"自定义属性"面板
    rig_azimuth: FloatProperty(name="Azimuth", subtype='ANGLE', default=0.0, update=on_light_rig_azimuth_update, description="Rotation of the controller empty around its Z axis (edits the controller transform, not undoable)")  # type: ignore
    rig_elevation: FloatProperty(name="Elevation", subtype='ANGLE', default=RIG_DEFAULT_ELEVATION, update=on_light_rig_elevation_update, description="Rotation of the controller empty around its X axis (edits the controller transform, not undoable)")  # type: ignore
    rig_distance: FloatProperty(name="Distance", subtype='DISTANCE', min=0.0, default=RIG_DEFAULT_DISTANCE, update=on_light_rig_distance_update, description="Distance from the light to its controller (edits the light's local location, not undoable)")  # type: ignore
    rig_self_rotation: FloatProperty(name="Self Rotation", subtype='ANGLE', default=_RIG_SELF_ROTATION_DEFAULT, update=on_light_rig_self_rotation_update, description="Self rotation of the light around its local Y axis (edits only the Y component, not undoable; resetting to 0 also restores the local rotation X -90 and Z 0)")  # type: ignore

    # --- 灯光高级设置资产选择器(图像纹理/IES 光域网) ---
    # 选中资产库(存库根目录路径, 空/失效时回落该用途首个启用的库; 库本身在偏好里管理);
    # 分类目录名(经下拉菜单选定, 显示走按钮文本不进动态枚举); 缩略图选中键为动态枚举
    # (标识=文件名键, 名称/悬停留空避开动态枚举中文乱码), 点击经 update 应用到面板活跃灯;
    # 缩略图尺寸与弹窗放大系数在偏好(asset_thumb_size / asset_thumb_popup_factor, 两选择器共用)
    adv_image_library: StringProperty(default="")  # type: ignore
    adv_ies_library: StringProperty(default="")  # type: ignore
    adv_image_category: StringProperty(default="")  # type: ignore
    adv_ies_category: StringProperty(default="")  # type: ignore
    adv_image_pick: EnumProperty(items=_adv_image_pick_items, update=on_adv_image_pick_update)  # type: ignore
    adv_ies_pick: EnumProperty(items=_adv_ies_pick_items, update=on_adv_ies_pick_update)  # type: ignore


class CameraResolutionSettings(PropertyGroup):
    """相机独立分辨率: 该相机为场景相机时覆写场景输出分辨率(挂在物体上, 随 .blend 保存)

    res_x/res_y 出厂为 0 表示"未初始化": 首次开启由属性 update 回调以场景输出初始化,
    关闭再开启保留上次数值; 数值低于有效下限视同未启用(判据见
    utils/blender/resolution.py 的 camera_resolution).
    """

    # 标签沿用词典已有词条 "Independent Resolution"
    use_independent: BoolProperty(
        name="Independent Resolution",
        description="Override the scene output resolution with this camera's own resolution while it is the scene camera",
        default=False,
        update=on_camera_resolution_update,
    )  # type: ignore
    # 标签沿用系统词条 "Resolution X/Y"(与原生输出分辨率同名, 不入典)
    res_x: IntProperty(
        name="Resolution X",
        description="Independent output width in pixels",
        default=0,
        min=0,
        max=CAMERA_RES_MAX,
        subtype='PIXEL',
        update=on_camera_resolution_update,
    )  # type: ignore
    res_y: IntProperty(
        name="Resolution Y",
        description="Independent output height in pixels",
        default=0,
        min=0,
        max=CAMERA_RES_MAX,
        subtype='PIXEL',
        update=on_camera_resolution_update,
    )  # type: ignore


class SceneResolutionState(PropertyGroup):
    """场景侧独立分辨率覆写状态: 覆写前基准与当前覆写来源(挂在场景上, 随 .blend 保存)

    纯内部记账, 不进 UI(无 name/description, 仿 ch_ai_assistant 的 lock_ratio).
    """

    # 基准是否有效(idprop 时代的"键存在"语义改为显式布尔)
    has_base: BoolProperty(default=False)  # type: ignore
    base_x: IntProperty(default=0)  # type: ignore
    base_y: IntProperty(default=0)  # type: ignore
    # 当前覆写来源相机名(空 = 未处于覆写态)
    applied_src: StringProperty(default="")  # type: ignore


class LightAdvancedSettings(PropertyGroup):
    """灯光高级设置状态(挂在灯光数据块上, 随 .blend 保存; 多物体共享数据块时同步生效)

    真值分两层: 模块(mode, "无"档即不激活)与渐变模式在此; 渐变参数与色标色值的真值在
    灯光节点树的插件实例节点上(面板直绘节点插座, 同材质基础参数区先例). 任一项变化经
    on_light_advanced_update 幂等重接 Emission; Emission 被用户手改接线时照常接管
    (重接后插件线生效, 面板画提示行).
    """

    mode: EnumProperty(
        name="Mode",
        items=ADVANCED_MODE_ITEMS,
        default='NONE',
        update=on_light_advanced_update,
        description="Which advanced module drives the light; None deactivates all modules",
    )  # type: ignore
    gradient_type: EnumProperty(
        name="Gradient Type",
        items=GRADIENT_TYPE_ITEMS,
        default='RADIAL',
        update=on_light_advanced_update,
        description="Gradient pattern applied to the light emission",
    )  # type: ignore
    # 图像档接线目标: 纹理驱动发光颜色(默认)还是强度(灰度图必须接强度才有正确照明)
    image_target: EnumProperty(
        name="Target",
        items=IMAGE_TARGET_ITEMS,
        default='COLOR',
        update=on_light_advanced_update,
        description="Which emission socket the image texture drives",
    )  # type: ignore
    # 图像档阵列方式(矩形/环形): UI 真值写阵列坐标组实例的阵列方式插座
    # (Menu Switch 组写枚举项名 / 旧 Mix 组写 0/1 因子), 条件显示的参数行按插座值读真值
    image_array_mode: EnumProperty(
        name="Array Mode",
        items=IMAGE_ARRAY_MODE_ITEMS,
        default='RECT',
        update=on_image_array_mode_update,
        description="Rectangular tiling or ring array of the projected texture",
    )  # type: ignore
    # 外部文件路径(图像/IES): 不在资产库中的文件, 非空时优先于缩略图选择
    image_external: StringProperty(
        name="External Image",
        description="Path to an external image file (overrides the asset picker when set)",
        subtype='FILE_PATH',
        update=on_image_external_update,
    )  # type: ignore
    ies_external: StringProperty(
        name="External IES",
        description="Path to an external IES file (overrides the asset picker when set)",
        subtype='FILE_PATH',
        update=on_ies_external_update,
    )  # type: ignore
