"""
材质工具模块

提供材质节点获取、材质输出节点查找与材质赋值等功能.

主要功能:
- get_material_output: 获取材质输出节点
- get_last_node: 获取连接到输出节点的最后一个节点
- assign_material: 把材质赋给一组物体的活动材质槽(无槽时追加新槽)
- MATERIAL_SLOT_TYPES: 可拥有材质槽的物体类型集合

注: 本插件的材质赋值自持一份副本(2026-10-18 起), 不再与 ch_scene_helper 共用原
common/blender/material.py(该文件已删除) —— 对方材质面板的赋值语义已分叉(+Ctrl 追加 /
+Alt 替换指定槽), 两插件各持副本. 复制/删除/选中使用者三个动作仍由 ch_scene_helper 独持.
"""

from bpy.types import Material, Node

# 可拥有材质槽的物体类型(网格/曲线/文本/曲面/融球)
MATERIAL_SLOT_TYPES = {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}


def get_material_output(mat: Material) -> Node | None:
    """
    获取材质的输出节点

    Args:
        mat: 材质对象

    Returns:
        材质输出节点, 如果不存在则返回None
    """
    output = mat.node_tree.nodes.get('Material Output')
    if output:
        return output

    for node in mat.node_tree.nodes:
        if node.type == 'OUTPUT_MATERIAL':
            return node

    return None


def get_last_node(mat: Material, skip_mix_node: bool = True) -> Node | None:
    """
    获取材质节点树的最后一个节点(连接到输出节点的节点)

    Args:
        mat: 材质对象
        skip_mix_node: 是否跳过混合着色器节点

    Returns:
        最后一个节点, 如果不存在则返回None
    """
    output = get_material_output(mat)
    if not output:
        return None

    surf = output.inputs.get("Surface")
    if not surf or not surf.links:
        return None

    node = surf.links[0].from_node

    if node.type == 'MIX_SHADER' and skip_mix_node:
        if node.inputs[1].links:
            node = node.inputs[1].links[0].from_node

    return node


def assign_material(mat: Material, objects: list) -> tuple:
    """把材质赋给一组物体的活动材质槽(无槽时追加新槽), 返回 (赋值物体数, 错误信息)

    仅处理可拥有材质槽的物体类型(MATERIAL_SLOT_TYPES), 其它类型静默跳过.

    Args:
        mat: 待赋值材质
        objects: 目标物体列表

    Returns:
        (成功赋值的物体数, 错误信息或 None)
    """
    if mat is None:
        return 0, "material is None"
    count = 0
    for obj in objects:
        if obj.type not in MATERIAL_SLOT_TYPES:
            continue
        if not obj.material_slots:
            obj.data.materials.append(mat)
        else:
            obj.material_slots[obj.active_material_index].material = mat
        count += 1
    return count, None
