"""
场景资源列表模块

灯光/相机/材质三个 UIList(类名含 _UL_ 标记, Blender 注册约定, 类名即 template_list 查找 id),
内建名称过滤与排序控件行(标准过滤行为见 common.blender.list_snapshot);
行内名称以无浮雕文本绘制, 双击可编辑并写穿到真实数据块;
行内状态(hide_select/hide_viewport/hide_render/使用者数)为 draw 期 O(1) 直读真实数据块, 不进快照
(设计依据见 docs/scene-helper-panels-design.md).
"""

import bpy
from bpy.types import Context, Object, UIList, UILayout

from .....common.blender.list_snapshot import ListItem, StandardFilterMixin

# 行内名称列占比(右侧留给状态开关/使用者数)
_NAME_FACTOR = 0.76

# 灯光类型 -> 图标
_LIGHT_ICONS = {
    'POINT': 'LIGHT_POINT',
    'SUN': 'LIGHT_SUN',
    'SPOT': 'LIGHT_SPOT',
    'AREA': 'LIGHT_AREA',
    'HEMI': 'LIGHT_HEMI',
}


def _light_icon(context: Context, name: str) -> str:
    """灯光行图标: 按灯光类型取; 自发光材质物体用材质球; 条目失效回落通用灯图标"""
    obj = context.scene.objects.get(name)
    if obj is None:
        return 'LIGHT'
    if obj.type == 'LIGHT':
        return _LIGHT_ICONS.get(obj.data.type, 'LIGHT')
    return 'MATSPHERE'


def _camera_icon(context: Context, obj: Object | None) -> str:
    """相机行图标: 场景相机用实心 VIEW_CAMERA 徽标, 其余用 OUTLINER_OB_CAMERA

    Blender 5.1 图标集已移除 CAMERA, 相机行统一走大纲相机图标.
    """
    is_scene_cam = obj is not None and context.scene.camera == obj
    return 'VIEW_CAMERA' if is_scene_cam else 'OUTLINER_OB_CAMERA'


def _draw_object_toggles(row: UILayout, obj: Object) -> None:
    """行内三开关: 禁用选中 / 视口隐藏 / 渲染排除

    均只传 _OFF 基图标: IconToggle 对 CONSECUTIVE RNA 属性(hide_select/hide_viewport/
    hide_render, 见 rna_object.cc 的 RNA_def_property_ui_icon) 会按开关态自动换到 _ON
    字形并加反色高亮(interface.cc 的 iconadd 机制); 显式传 _ON 会与自动换算叠加成错误字形.
    与系统大纲 restriction 列的显示切换保持一致.
    row 的 align 为 False(默认): 各按钮等宽居中, 灯光/相机两列表控件观感一致.
    """
    row.prop(obj, "hide_select", text="", emboss=False, icon='RESTRICT_SELECT_OFF')
    row.prop(obj, "hide_viewport", text="", emboss=False, icon='RESTRICT_VIEW_OFF')
    row.prop(obj, "hide_render", text="", emboss=False, icon='RESTRICT_RENDER_OFF')


def _draw_name_cell(layout: UILayout, item: ListItem, icon: str) -> UILayout:
    """行内名称列(无浮雕名称编辑框, 双击写穿真实数据块), 返回右侧状态列布局

    各列表把状态开关(hide_select/hide_viewport/hide_render)或使用者数小字挂到返回的布局上.
    """
    split = layout.split(factor=_NAME_FACTOR)
    split.prop(item, "name", text="", emboss=False, icon=icon)
    return split.row()


def _draw_grid_cell(layout: UILayout, icon: str) -> None:
    """GRID 视图单元: 居中图标"""
    layout.alignment = 'CENTER'
    layout.label(text="", icon=icon)


class CH_UL_lights(StandardFilterMixin, UIList):
    """灯光列表(含自发光材质物体), 行内三开关: 禁用选中 / 视口隐藏 / 渲染排除"""

    def draw_item(self, context: Context, layout: UILayout, data, item: ListItem,
                  icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            state_col = _draw_name_cell(layout, item, _light_icon(context, item.src_name))
            obj = context.scene.objects.get(item.src_name)
            if obj is not None:
                _draw_object_toggles(state_col, obj)
        elif self.layout_type == 'GRID':
            _draw_grid_cell(layout, _light_icon(context, item.src_name))


class CH_UL_cameras(StandardFilterMixin, UIList):
    """相机列表, 场景相机实心徽标, 行内三开关: 禁用选中 / 视口隐藏 / 渲染排除

    焦距显示已按作者意见移除(焦距在设置子面板调整).
    """

    def draw_item(self, context: Context, layout: UILayout, data, item: ListItem,
                  icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            obj = context.scene.objects.get(item.src_name)
            state_col = _draw_name_cell(layout, item, _camera_icon(context, obj))
            if obj is not None:
                _draw_object_toggles(state_col, obj)
        elif self.layout_type == 'GRID':
            _draw_grid_cell(layout, 'OUTLINER_OB_CAMERA')


class CH_UL_materials(StandardFilterMixin, UIList):
    """材质列表, 行内使用者数小字(假用户开关已按作者意见移除, 改在材质属性选项卡设置)"""

    def draw_item(self, context: Context, layout: UILayout, data, item: ListItem,
                  icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            state_col = _draw_name_cell(layout, item, 'MATERIAL')
            mat = bpy.data.materials.get(item.src_name)
            if mat is not None:
                state_col.label(text="x{}".format(mat.users))
        elif self.layout_type == 'GRID':
            _draw_grid_cell(layout, 'MATERIAL')
