"""
灯光工具模块

提供灯光能量批量缩放等算法(交互层算子见 operators/object/light.py).
"""


def scale_lights_energy(objects: list, factor: float) -> int:
    """把一组灯光物体的能量乘以系数(结果钳制为非负), 返回实际缩放的灯光数

    Args:
        objects: 待处理物体列表(非灯光物体自动跳过)
        factor: 能量乘数(0 清空, 1 不变)

    Returns:
        实际被缩放的灯光物体数
    """
    count = 0
    for obj in objects:
        if obj is None or obj.type != 'LIGHT':
            continue
        obj.data.energy = max(obj.data.energy * factor, 0.0)
        count += 1
    return count
