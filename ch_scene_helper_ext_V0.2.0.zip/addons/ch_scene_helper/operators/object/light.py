"""
灯光辅助操作器模块

提供以下功能:
- LightEnergyScale: 对选中灯光的能量批量乘以系数(布光收尾的整体曝光调整)
"""

from bpy.props import FloatProperty
from bpy.types import Context, Operator

from .....common.i18n.i18n import report
from ...utils import scale_lights_energy


class LightEnergyScale(Operator):
    """把全部选中灯光的能量乘以系数(F9 面板可调因子, UNDO 可撤销)"""

    bl_idname = "ch.light_energy_scale"
    bl_label = "Energy Scale"
    bl_description = "Scale the energy of all selected lights by a factor"
    bl_options = {'REGISTER', 'UNDO'}

    factor: FloatProperty(name="Factor", description="Multiplier applied to the energy of each selected light", default=1.0, min=0.0, soft_max=10.0)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and any(obj.type == 'LIGHT' for obj in context.selected_objects)

    def execute(self, context: Context):
        lights = [obj for obj in context.selected_objects if obj.type == 'LIGHT']
        count = scale_lights_energy(lights, self.factor)
        if count == 0:
            self.report({'WARNING'}, report("No lights selected"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Energy scaled: {} lights").format(count))
        return {'FINISHED'}
