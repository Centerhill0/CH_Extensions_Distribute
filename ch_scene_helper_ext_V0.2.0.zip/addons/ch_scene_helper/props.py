"""
场景资源列表状态模块

提供以下功能:
- WM 级状态属性组: 灯光/相机/材质的列表快照与各项活跃索引(索引 update 回调联动选中场景物体)
- WM 级 UI 状态属性组: 设置区各子面板的展开状态
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot
"""

from bpy.props import BoolProperty, CollectionProperty, IntProperty
from bpy.types import PropertyGroup

from ...common.blender.list_snapshot import ListItem
from .handlers import on_cameras_index_update, on_lights_index_update, on_materials_index_update


class SceneListsState(PropertyGroup):
    """场景资源的列表快照及各项活跃索引(索引 update 回调联动选中场景物体)"""
    lights: CollectionProperty(type=ListItem)  # type: ignore
    lights_active_index: IntProperty(default=0, update=on_lights_index_update)  # type: ignore
    cameras: CollectionProperty(type=ListItem)  # type: ignore
    cameras_active_index: IntProperty(default=0, update=on_cameras_index_update)  # type: ignore
    materials: CollectionProperty(type=ListItem)  # type: ignore
    materials_active_index: IntProperty(default=0, update=on_materials_index_update)  # type: ignore


class SceneListsUIState(PropertyGroup):
    """场景资源列表设置区子面板的展开状态(WM 级纯 UI 状态, 不随 .blend 保存)

    每面板一个设置子面板; 展开态无名称/描述: 绘制时 text="" 只显示三角箭头
    (见 ui/panels/scene_lists.py).
    """
    show_light_settings: BoolProperty(default=True)  # type: ignore
    show_camera_settings: BoolProperty(default=True)  # type: ignore
