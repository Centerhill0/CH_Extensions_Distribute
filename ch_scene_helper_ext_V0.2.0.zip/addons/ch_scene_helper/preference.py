"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(Scene Helper 双向选中同步 / 相机设置 / 快捷键页签)
- get_prefs: 取本插件偏好实例

面板分两个页签(照 CH Custom Tools 的既有形态):
- Settings: Scene Helper(双向选中同步) + Camera Settings(切换相机与设为场景相机时的视图对齐)
- Hotkeys: 本插件已注册快捷键列表(饼菜单在右列), 附 rna_keymap_ui 的标准改键控件
"""

from typing import Callable

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import AddonPreferences, Context, KeyConfig, UILayout
from rna_keymap_ui import draw_kmi

from .config import __addon_name__
from .keymaps import addon_keymaps


def _draw_hotkey_column(layout: UILayout, title: str, groups: list, kc: KeyConfig, footer: Callable | None = None) -> None:
    """绘制单列快捷键分组列表

    footer 保留形参以与 CH Custom Tools 的同名函数同形(便于两份实现同源同步);
    本插件无 ExpandableUi 菜单扩展, 调用方一律传 None.
    """
    col = layout.box()
    col.label(text=title)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
        row.separator(factor=1, type='LINE')
    if footer:
        footer(col)


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    # ----------Scene Helper 属性----------
    # 双向选中同步: 侧栏 Scene Helper 列表活跃索引与 3D 视图选中状态互相同步
    # (关闭后列表仍实时快照, 仅不做选中联动; 快照刷新不受影响)
    scene_lists_sync: BoolProperty(name="Two-way Selection Sync", description="Keep the list active index and the 3D view selection in sync both ways", default=True)  # type: ignore

    # ----------相机属性----------
    # 切换相机时,是否将视图对齐到相机
    is_align: BoolProperty(name="Is Align", description="Align the selected camera", default=True)  # type: ignore
    # 设置为活动相机时,是否将视图对齐到相机
    is_align_view: BoolProperty(name="Is Align View", description="Align the view to the selected camera", default=False)  # type: ignore

    # --------------属性--------------
    # 面板模块切换: 设置 / 快捷键
    settings_tab: EnumProperty(
        name="Settings",
        items=[
            ('PREFERENCES', "Settings", "Scene helper and camera settings", 'PREFERENCES', 0),
            ('HOTKEYS', "Hotkeys", "Registered hotkey list", 'KEYINGSET', 1),
        ],
        default='PREFERENCES',
    )  # type: ignore

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 模块切换按钮(从左到右: 设置 / 快捷键)
        row = layout.row()
        row.prop(self, "settings_tab", expand=True)

        if self.settings_tab == 'PREFERENCES':
            # 场景助手设置(侧栏 Scene Helper 列表与 3D 视图选中同步)
            box = layout.box()
            box.label(text="Scene Helper", icon='OUTLINER')
            box.prop(self, "scene_lists_sync")

            # 相机设置(相机饼菜单与相机面板的切换/设为场景相机共用)
            box = layout.box()
            box.label(text="Camera Settings", icon="CAMERA_DATA")
            box.prop(self, "is_align")
            box.prop(self, "is_align_view")

        else:
            # 快捷键列表(独立 Ops 在左, 饼菜单在右)
            box = layout.box()
            independent_groups = []
            pie_groups = []
            for name, items in addon_keymaps.items():
                if name.lower().endswith('pie'):
                    pie_groups.append((name, items))
                else:
                    independent_groups.append((name, items))

            columns = box.split(factor=0.5)
            _draw_hotkey_column(columns.column(), "Operators", independent_groups, kc)
            _draw_hotkey_column(columns.column(), "Pie Menus", pie_groups, kc)


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
