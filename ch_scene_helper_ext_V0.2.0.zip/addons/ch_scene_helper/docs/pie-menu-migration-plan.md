# 相机饼菜单与灯光饼菜单迁移方案（`ch_utils_tools` → `ch_scene_helper`）

> ## ✅ 已实施（2026-10-16，`ch_scene_helper` 未发布段 / `ch_utils_tools` 未发布段）
>
> 本方案已**按 §9.1 的 S0–S7 一次做完**（作者定"不分批"）。实施记录见根 `CHANGELOG.md`
> `[未发布]` 段与 `.agents/log/2026-10-16.md`。本文自此转为**实施记录**：下文"计划/预估"类
> 表述保留原样供考古；**实际结果**见文末 §13。
> **按 AGENTS「文档同步口径」：本文隔一版移入 `.agents/log/archive/`。**
>
> ---

> 状态（原始）：**计划中**。基线：`ch_utils_tools` 0.6.1、`ch_scene_helper` 0.1.1；
> `python .agents/tools/gate.py --quick` → **7/7 PASS**（本会话实测）。
>
> 作者指令：把 `ch_utils_tools` 的**相机饼菜单（`Alt + C`）**与**灯光饼菜单（`Alt + L`）**
> 全部迁入 `ch_scene_helper`；迁移后 `ch_utils_tools` **不得有任何依赖残留**。
>
> 实施完成后按 AGENTS「文档同步口径」回改成事实记录，并加「已实施于 X.Y.Z，仅考古」横幅。

---

## 0. 一句话

两个饼菜单是**纯 `Menu` 类**（无模态、无 HUD）——因此本批**不需要**任何模态/绘制基建
（这是与已放弃的"三模块"计划的关键差别，那批的 830 行基建成本本批**完全不存在**）。

但相机饼菜单带出**相机三算子**（它是这三个算子在源侧的唯一消费者），三算子又带出
**偏好两项**。故本批实际移动 **5 个文件 + 1 组偏好 + 2 组快捷键**，
并在目标侧**退役**整套跨插件机制（`has_operator` + 置灰降级）。

---

## 1. 范围

### 1.1 迁入

| # | 源 | 体量 | 目标 |
| --- | --- | --- | --- |
| M1 | `ui/pies/camera.py`（`CameraPie`） | 125 行 | `ch_scene_helper/ui/pies/camera.py` |
| M2 | `ui/pies/light.py`（`LightPie`） | 130 行 | `ch_scene_helper/ui/pies/light.py` |
| M3 | `operators/object/camera.py`（三算子） | 149 行 | `ch_scene_helper/operators/object/camera.py` |
| M4 | `preference.py` 的 `is_align` / `is_align_view` | 2 项 | `CHSceneHelperPreferences` |
| M5 | `keymaps.py` 的 `CAMERA_PIE` + `LIGHT_PIE` | 2 组 | `ch_scene_helper/keymaps.py`（新） |
| M6 | `ui/panels/scene_lists.py` 的跨插件机制 | — | **退役删除**（非迁移，见 §5.4） |

### 1.2 M3 为何在范围内（必然带出）

实测确认：`CameraPie.draw` 直接调用 `ToggleCamera` / `SetAsSceneCamera` /
`CreateAlignCamera`（3 处 `layout.operator(...)`），**是这三个算子在 `ch_utils_tools` 内的
唯一消费者**。若只迁饼菜单而留算子，源侧饼菜单没了、算子却无人使用（且目标侧要跨插件调回来）
——正是作者要求消除的"依赖残留"。故三算子随迁，源文件整删。

### 1.3 明确**不迁**

| 项 | 理由 |
| --- | --- |
| 三算子的 `bl_idname`（`ch.toggle_camera` 等）与两菜单 `bl_idname`（`VIEW3D_MT_ch_camera_pie` / `VIEW3D_MT_ch_light_pie`） | `ch.` / `VIEW3D_MT_ch_*` 已是三插件共用族；改名会连动 e2e 过滤器（`ops_cases` 的 `CH_OT_`、`pie_cases` 的 `_MT_ch_`）、`probe_undo`、用户既有配置 |
| 两菜单的 `bl_label`（`CH Camera Pie` / `CH Light Pie`） | 词典键已存在，随迁即可 |
| `modal_base.py`、`utils/drawing/**`、`utils/blender/raycast.py`、`get_material_output` / `get_last_node`、材质拾取器 | **本次不在范围**（两个饼菜单与三算子均不引用它们） |

---

## 2. 现状取证

### 2.1 五个源文件的导入（AST 实测，决定改写面）

| 文件 | 导入 | 目标层级 | 是否需改 |
| --- | --- | --- | --- |
| `ui/pies/camera.py` | `from ...operators.object.camera import ToggleCamera, SetAsSceneCamera, CreateAlignCamera` | depth 2 → depth 2 | **否** |
| | `from ...preference import get_prefs` | depth 2 → depth 2 | **否** |
| `ui/pies/light.py` | `from .....common.i18n.i18n import iface` | depth 2 → 5 点 | **否** |
| `operators/object/camera.py` | `from ...preference import get_prefs` | depth 1 → depth 1 | **否** |

> **两插件目录结构同构**（`ui/pies/`、`operators/object/` 相对插件根同为 depth 2 / 2 / 1），
> 故**五个文件可逐行零改写搬运**；`common` 引用点数（5 点）在两侧一致。
> 这是本批风险最低的一点，也是选择同构目录的原因。

### 2.2 依赖面

- `ch_scene_helper` 对 `ch_utils_tools` **无任何 `import`**——唯一耦合是
  `ui/panels/scene_lists.py` 的 3 个字符串常量 + `has_operator` 判定。
- 三个算子均为**普通 `Operator`**（`bl_options = {'REGISTER','UNDO'}`），
  **不继承 `ModalOperatorMixin`**，无 invoke 模态 / HUD / 状态栏。
- 两个 `Menu` 子类亦**无任何绘制基建依赖**。

### 2.3 体量与门禁

| 口径 | 值 |
| --- | --- |
| 迁入文件行数（3 个文件，原样搬运） | **404 行**（camera.py 149 + pies/camera.py 125 + pies/light.py 130） |
| `ch_scene_helper` 净增 | ≈ **572 行**（404 + 新 `keymaps.py` 约 130 + 偏好 8 + 词典约 30） |
| `ch_utils_tools` 净减 | ≈ **457 行**（404 + keymaps 10 + 偏好 6 + 词典 37） |
| **全仓净变化** | **≈ +115 行** |
| 门禁基线 | `--quick` 7/7 PASS（改动前实测） |
| 全量档 | 10 项；**新增目录/文件必须跑**——`ui/pies/` 缺 `__init__.py` 会让两个菜单**静默不注册** |

> **净增而非净减的原因**：`keymaps.py` 的**注册器函数体有 87 行**（含两处硬约束的幂等清理与
> `ReferenceError` 容错），新插件必须整份复制；而源侧只删掉两组配置数据（10 行）。
> 这 87 行属"基建随迁"的固有成本，不可避免——除非源侧改由 `common/` 提供注册器
> （但 `common/` 不得依赖插件偏好，且会扩大 `common/` 的扫描盲区，**本批不做**）。

---

## 3. 关键设计决策

### D1 三算子随相机饼菜单一并迁入

理由见 §1.2（唯一消费者 + 作者要求零残留）。**这不是范围扩张，是消除残留的必要条件**。

### D2 `bl_idname` / 菜单 id / 全部文案保持不变

见 §1.3。换来 e2e 过滤器、`ops_cases`、`probe_undo`、用户既有快捷键配置**全部零改动**。

### D3 跨插件机制整体退役

三算子成为本插件算子后，下列代码失去存在理由，**整块删除**：
`_TOGGLE_CAMERA` / `_SET_AS_SCENE_CAMERA` / `_CREATE_ALIGN_CAMERA` 三常量及其 7 行解释注释、
`_utils_tools_camera_available()`、`_draw_optional_op()`（7 处调用）、
`_draw_missing_utils_tools_hint()`（2 处）、`from ...utils import has_operator`、
`utils/blender/operator.py` 整文件、`utils/blender/__init__.py` 的 `has_operator` 导入与
`__all__` 条目、词典键 `(" *", "Requires CH Custom Tools")`。

替代写法（规范 §8）：面板改**类引用**调用，如
`layout.operator(CreateAlignCamera.bl_idname, text="Create Aligned", icon='VIEW_CAMERA')`。
可用性无需运行期探测——面板只在本插件启用时绘制。

> **按钮文案 / 图标 / 排布 / `toggle_next` 属性逐字保持不变**（作者多轮手工微调过布局，
> 规范 §17 要求重写前必读当前文件）。

### D4 偏好两项迁入

| 属性 | 消费者 | 处置 |
| --- | --- | --- |
| `is_align` | `ToggleCamera.execute`（切换相机后是否对齐视图） | 迁入，默认 `True` |
| `is_align_view` | **仅 `CameraPie.draw`**（决定画 `view3d.object_as_camera` 还是 `SetAsSceneCamera`） | 迁入，默认 `False` |

name / description / default **逐字不变**；`ch_utils_tools` 侧删属性 + 删 `Camera Settings` box。

### D5 快捷键基建 + 偏好 **Hotkeys 页**随迁（作者已确认要做）

`ch_scene_helper` 目前**没有** `keymaps.py`。新建并照抄 `ch_utils_tools` 的注册器，
**必须保留两处实测硬约束注释**：① 入口先清上一代条目（否则同一快捷键触发多次且无法注销）；
② 吞 `ReferenceError` 且 `addon_keymaps.clear()` 放 `finally`（否则用户在偏好删条目后
插件无法干净禁用）。`__init__.py` 接线 `register_keymaps()` / `unregister_keymaps()`。

**作者已确认补 Hotkeys 页**，故 `CHSceneHelperPreferences` 由单 box 改为双页签
（照搬 `ch_utils_tools/preference.py` 的 `settings_tab` 机制）：

```python
settings_tab: EnumProperty(
    name="Settings",
    items=[
        ('PREFERENCES', "Settings", <description>, 'PREFERENCES', 0),
        ('HOTKEYS', "Hotkeys", "Registered hotkey list", 'KEYINGSET', 1),
    ],
    default='PREFERENCES',
)
```

- `draw()` 顶部 `row.prop(self, "settings_tab", expand=True)` 切换；`PREFERENCES` 页放
  既有的 `Scene Helper` box + 迁入的 `Camera Settings` box；`HOTKEYS` 页放快捷键列表。
- 快捷键列表复用 `_draw_hotkey_column(layout, title, groups, kc, footer=None)`
  （照搬源实现，约 16 行）：按组名是否以 `pie` 结尾分流到 `Operators` / `Pie Menus` 两列。
- **`footer` 参数保留但传 `None`**：源侧用它挂 `_draw_menu_extensions`
  （`ShadingExpandPie` / `ExtrudeMenuExpand`），而**本插件没有任何 `ExpandableUi` 类**
  （实测确认），故无菜单扩展可列。保留形参是为了两个插件的 `_draw_hotkey_column`
  保持同形，便于日后同源同步。
- 需要 `from rna_keymap_ui import draw_kmi`（Blender 内置模块，与源一致）。
- `from .keymaps import addon_keymaps` —— 偏好读注册结果，**单向依赖**（`keymaps.py`
  不得反向 import 偏好）。

> **页签文案的 i18n**：实测 `Settings` / `Operators` / `Pie Menus` 均为 **Blender 系统词条**
> （已译"设置/操作项/饼菜单"）→ **不入典**；`Hotkeys` **系统未命中** → 需入典（源侧已有
> `("*", "Hotkeys")` 一条，随迁即可）。`PREFERENCES` 页的 description 另行处理（§7.2）。

---

## 4. 目标文件树

### 4.1 `ch_scene_helper`（迁移后）

```text
addons/ch_scene_helper/
├── __init__.py                 # 改: 接线 register_keymaps / unregister_keymaps
├── keymaps.py                  # 新: CAMERA_PIE + LIGHT_PIE 组 + 注册器(含两处硬约束)
├── preference.py               # 改: + settings_tab 双页签 + is_align/is_align_view
│                               #     + _draw_hotkey_column(照搬) + Camera Settings box
├── operators/object/camera.py  # 新: ToggleCamera / SetAsSceneCamera / CreateAlignCamera
├── ui/
│   ├── panels/scene_lists.py   # 改: 相机动作行改类引用, 删跨插件机制(D3)
│   └── pies/                   # 新目录(必须含 __init__.py)
│       ├── __init__.py
│       ├── camera.py           # 新: CameraPie
│       └── light.py            # 新: LightPie
├── utils/blender/
│   ├── __init__.py             # 改: 删 has_operator 导入与 __all__ 条目
│   └── operator.py             # 删: has_operator 失去唯一消费者
├── i18n/dictionary.py          # 改: + 迁入/复制词条(见 §7)
└── README.md                   # 改: 删「与 CH Custom Tools 的关系」整节
```

### 4.2 `ch_utils_tools`（迁移后删除/清理清单）

```text
operators/object/camera.py      # 删(整文件, 149 行)
ui/pies/camera.py               # 删(整文件, 125 行)
ui/pies/light.py                # 删(整文件, 130 行)
keymaps.py                      # 改: 删 CAMERA_PIE/LIGHT_PIE 组 + group_labels 两行 + docstring 两行
preference.py                   # 改: 删 is_align/is_align_view + Camera Settings box
                                #     + settings_tab 的 PREFERENCES description 改写 + 删 CameraPie 注释行
i18n/dictionary.py              # 改: 删 37 条死条目(见 §7.1)
README.md                       # 改: 删 Alt+C/Alt+L 表行 + 相机三算子表 3 行 + 偏好说明行
```

> `operators/object/` 删 `camera.py` 后仍有 `create_object.py`，目录保留；
> `ui/pies/` 删两个后仍有 13 个饼菜单，目录保留。

---

## 5. 逐文件迁移要点

### 5.1 `ui/pies/camera.py` / `ui/pies/light.py` / `operators/object/camera.py`

**逐行零改写搬运**（§2.1 已核：层级同构、无 `common` 点数变化）。
⚠️ `ch_scene_helper/ui/pies/` **必须新建 `__init__.py`**（空文件即可），否则两个菜单
经 `class_loader` **静默不注册**——无报错，`--quick` 全绿，只有全量档 `verify_blender_load` 能抓。

### 5.2 `keymaps.py`（两侧）

**目标侧（新）**：照抄注册器实现，配置表只保留：

```python
group_labels = {'CAMERA_PIE': "Camera Pie", 'LIGHT_PIE': "Light Pie"}
keymap_items = {'CAMERA_PIE': [...], 'LIGHT_PIE': [...]}   # 条目内容与源逐字一致
```

**源侧**：删两组条目 + `group_labels` 两行 + 模块 docstring 两行（描述债）。

### 5.3 `preference.py`（两侧）

目标侧新增两个 `BoolProperty` + `Camera Settings` box（图标 `CAMERA_DATA`）；
源侧删属性、删 box、删 `# ----------CameraPie属性----------` 注释行、
改 `settings_tab` 的 `PREFERENCES` description。

### 5.4 `ui/panels/scene_lists.py`（D3 改写）

| 位置 | 现状 | 改后 |
| --- | --- | --- |
| 模块 docstring 15–16 行 | "跨插件依赖: …由 ch_utils_tools 提供" | "相机三算子由本插件 `operators/object/camera.py` 提供" |
| 导入 | `from ...utils import has_operator` | **删**；增 `from ...operators.object.camera import ToggleCamera, SetAsSceneCamera, CreateAlignCamera` |
| 27–43 行 | 3 常量 + 2 段注释 + `_utils_tools_camera_available()` | **整块删** |
| 62–79 行 | `_draw_optional_op()` | **整块删** |
| `_draw_cameras_create_row()` | 形参 `available`；`row.enabled`；3 次 `_draw_optional_op` | 直接类引用调用；删 `available` 形参 |
| `_draw_cameras_actions()` | 形参 `available`；`set_row.enabled`；`_draw_optional_op(_SET_AS_SCENE_CAMERA,…)` | 改 `set_row.operator(SetAsSceneCamera.bl_idname, text="Set as Camera")`；删 `available` 形参 |
| `_draw_missing_utils_tools_hint()` | 整函数 | **整块删** |
| `CamerasPanel.draw` | `available = _utils_tools_camera_available()` + 传参 + 提示分支 | 删三处调用 |

**文案保真清单**（逐字保留）：`"Create Aligned"` / `"Set as Camera"` / `"Look Through"` /
`"Lock to View"` / 图标 `VIEW_CAMERA` / `TRIA_UP_BAR` / `TRIA_DOWN_BAR` / `toggle_next=False|True`。

---

## 6. 工具链与 E2E 同步

### 6.1 必须改

| # | 文件 | 改动 | 理由 |
| --- | --- | --- | --- |
| T1 | `.agents/e2e/cases/static.py` | `CROSS_PLUGIN_OPS` 的 `ch_scene_helper` 条目**清空**（保留表结构与登记制说明） | 三个字符串调用已改类引用；留着会掩盖"又写回字符串 id"的回归 |
| T2 | `.agents/e2e/cases/scene_helper_cases.py` | ① 删 `t_has_operator` 用例（119–126 行）；② 删面板冒烟的 `mod.has_operator` 注入与"缺失分支"断言（356、395–408 行） | 被测对象已不存在；不改则层2 报红 |
| T3 | `.agents/e2e/cases/pie_cases.py` | `KNOWN_UNREACHABLE` 里 `VIEW3D_MT_ch_light_pie` 条目**保留**（沙箱无灯光物体，仍需豁免）；`_menus()` 扫 `bpy.types` 全局 → 两菜单仍注册，`>= 25` 不变 | 已核：无需改 |
| T4 | `addons/ch_scene_helper/__init__.py` | 接线 keymaps（D5） | 否则两个快捷键完全不注册 |

### 6.2 已核对**无需改**

| 项 | 结论 |
| --- | --- |
| `ops_cases.py::t_set_camera` | 调 `ch.set_as_scene_camera`，两插件同会话启用 → 仍解析 |
| `ops_cases.py` 的 `MODAL_OPS` / `SKIP_EXEC` / `len(classes) >= 50` | id 不变、算子总数不变 |
| `modal_cases.py` | 三算子非模态，不在 `MODAL_OPS` 清单 |
| `.agents/e2e/entry.py` | `ADDONS` 已含两插件；`ch_scene_helper_utils` 别名已注入 |
| `.agents/tools/check/*` 扫描根 | 均遍历全插件 |
| `.agents/tools/verify/verify_*.py` | 针对 symmetrize / material_picker / 通道捕获，不涉相机灯光 |
| `.agents/e2e/probe_undo.py` | **建议**补 `addon_enable("ch_scene_helper")`（`ch.set_as_scene_camera` 改由它提供）；一次性探针，非门禁项 |

---

## 7. i18n（AST 实测，含"我自己的编辑也会杀键"的模拟）

### 7.1 源侧须删除的死条目 —— **37 条**

> 口径：**模拟全部编辑后**（删 3 文件 + 删 keymaps 两组 + 删偏好两项与 box +
> 改写 description）源码里不再出现的键。比"只看迁走文件"多出 10 条——因为
> `keymaps.group_labels`、`preference` 的 `Is Align` / `Camera Settings` 等键
> 是被**我自己的编辑**杀掉的，不模拟会漏。

```
("*", "Align the selected camera")            ("*", "Align the view to the selected camera")
("Operator", "All Cameras")                   ("*", "Area")
("*", "CH Camera Pie")                        ("*", "CH Light Pie")
("*", "Camera Pie")                           ("Operator", "Camera Pie")
("*", "Camera Pie Menu")                      ("*", "Camera Settings")
("Operator", "Camera View")                   ("*", "Camera and hole extrude settings")
("Operator", "Create Align Camera")           ("Operator", "Create Camera Aligned to View")
("*", "Create a camera for aligning the view") ("Operator", "Damped Track")
("Operator", "Exclude")                       ("Operator", "Include")
("*", "Is Align")                             ("*", "Is Align View")
("Operator", "Light Linking")                 ("*", "Light Pie")
("Operator", "Light Pie")                     ("*", "Light Pie Menu")
("*", "Light Settings")                       ("Operator", "Next")
("*", "No camera found in view layer")        ("Operator", "Previous")
("Operator", "Set As Scene Camera")           ("*", "Set the active object as the scene camera")
("Operator", "Shadow Linking")                ("*", "Spot")
("Operator", "Toggle Camera")                 ("*", "Toggle Next")
("*", "Toggle the camera object")             ("Operator", "Track To")
("*", "{} Settings")
```

**去向**：除下面标注的"改写/删除"外，其余**剪切到 `ch_scene_helper` 词典**
（除 `Light Linking` / `Shadow Linking`，见 §7.3）。

### 7.2 description 改写（**须连动译文**）

`settings_tab` 的 `PREFERENCES` description：
`"Camera and hole extrude settings"` → **`"Hole extrude settings"`**

实测：源词典**只有**旧键，新键两侧都不存在 → 须在源侧**新增**新键并删除旧键
（规范 §9：属性 description 改动必须连动含该词的词条原文，否则 `i18n_sweep` 报 MISS/孤儿）。
`("*", "Hole Extrude Settings")`（Title Case）是**另一个键**（偏好里孔洞挤出的 box 标题），
与本条无关，**勿混**。

### 7.3 已在目标侧存在，**必须删除而非复制** —— 2 条

`("Operator", "Light Linking")`、`("Operator", "Shadow Linking")`

实测 `ch_scene_helper` 现有词典**已有**这两条（材质/灯光面板用）。若照搬会触发
`i18n_sweep` 的**词典重复**报错 → **只从源侧删，不往目标加**。

### 7.4 目标侧需**复制**（源侧仍被别的文件引用）—— 2 条

| 键 | 源侧其余引用 |
| --- | --- |
| `("Operator", "Compositor")` | `ui/pies/open_temp_editor.py:52`（`DuplicateEditor` 按钮文案） |
| `("Operator", "Point")` | 其它饼菜单（`point` 相关条目） |

→ 源侧**保留**，目标侧**新增**（实测目标词典均无）。

### 7.5 删除

`("*", "Requires CH Custom Tools")`（D3 退役，目标侧词典亦有，两处都删）。

### 7.6 落地机制

以上是起点，最终以两道机器检查为准：① `static_audit` 的「i18n 未覆盖 / 死条目」两段；
② `i18n_check_terms.py --query "原文"`（写新词条前查系统词条，系统已有的一律不入典）。

---

## 8. 文档同步清单（穷尽枚举后逐份判定）

| 文档 | 判定 | 要点 |
| --- | --- | --- |
| `addons/ch_scene_helper/README.md` | **必改** | 删「与 CH Custom Tools 的关系」整节（82–87 行）与开头 11 行引言；「常见问题」里相机置灰问答删除；新增 `Alt+C` / `Alt+L` 两条快捷键说明 |
| `addons/ch_utils_tools/README.md` | **必改** | 删快捷键表 `Alt+C`（81 行）与 `Alt+L`（82 行）；删 252–254 行三算子表；删 266 行相机设置偏好说明 |
| `addons/ch_scene_helper/docs/scene-helper-panels-design.md` | **必改** | §12.1 边界表（三算子由"留在 ch_utils_tools"改为"迁入本插件"）；§12.2 跨插件章节加"已退役"说明（**保留考古**）；§82/167/175/178/216/293/367/385/401 行提及处补注 |
| `addons/ch_scene_helper/docs/camera-operator-migration-plan.md` | **删除** | 该文档是本批的**上一版**（范围更窄）；已被本文件取代，留存即双权威漂移 |
| `CHANGELOG.md` | **必改** | `[未发布]` 记本轮代码改动（两插件各一条） |
| `.agents/MEMORY.md` | **必改** | 状态卡覆写；「插件协同」行更新（相机动作行**不再**依赖 `ch_utils_tools`，**该协同关系整体消失**） |
| `.agents/memories/cross-plugin-operator-sharing.md` | **必改** | 该文以相机三算子为**唯一实例**；补一节"实例已随迁移消解、`has_operator` 机制退役、当前无跨插件调用"，**保留通用实测事实**（同名 `bl_idname` 双注册＝破坏性接管） |
| `.agents/memories/blender-e2e-testing.md` | **必改** | 层1「规范8 登记制」补一句：`CROSS_PLUGIN_OPS` 现为空表；另记**本批暴露的层1 覆盖盲区**（keymap/算子/菜单三项只扫 `ch_utils_tools`） |
| `.agents/memories/blender-api-pitfalls.md` | **需判定** | §12"置灰拦不住创建 / mock 必须模拟失败语义"实例指向 `_draw_optional_op`（本批删除）→ 补注"机制已退役，结论仍适用于任何跨插件算子调用" |
| `.agents/skills/blender-addon-code-style/SKILL.md` | **需判定** | §6.8 跨插件条款：规则仍有效（当前无实例），补注实例已消解，**规则本身不改** |
| `AGENTS.md` | **需判定** | 框架约定 8 提及跨插件登记制；规则保留，补注"当前无跨插件调用" |
| `.agents/tools/README.md` / `blender_manifest.toml` / `log/**`（历史）/ `tests/**` | 不改 | 不受影响 |

---

## 9. 实施方式（作者定：**一次做完，不分批**）

> 作者 2026-10-16 定：**直接一批迁移完成，不分批**。故下表的"顺序"是**同一批内的操作步骤**
> （便于出问题时二分定位），**全部完成后才跑一次全量门禁**并由作者实测一轮。

### 9.1 操作顺序（同一批内）

| 步 | 内容 | 为什么是这个顺序 |
| --- | --- | --- |
| **S0** | 基线存证：`gate.py` **全量档** + `uicheck/run_check.py` | uicheck 对比 `git HEAD`，**提交后即空转**，必须在动手前跑 |
| **S1** | `ch_utils_tools` **删源**：3 文件整删；keymaps 两组 + `group_labels` 两行 + docstring 两行；偏好两属性 + `Camera Settings` box + `CameraPie` 注释行 + description 改写；词典 37 条 | **必须先删源**——两侧同时存在同名 `bl_idname` 会触发破坏性接管（见下 §9.2） |
| **S2** | `ch_scene_helper` **落位**：3 文件（逐行搬运）+ `ui/pies/__init__.py` + `keymaps.py` + `__init__.py` 接线 | 承接 S1 腾出的 id |
| **S3** | `ch_scene_helper` 偏好改造：`settings_tab` 双页签 + `_draw_hotkey_column` + `Camera Settings` box + 两属性 + 词典迁入/复制 | D5（作者已确认补 Hotkeys 页） |
| **S4** | 面板改写（D3）：删跨插件机制、改类引用；删 `utils/blender/operator.py` 与 `__init__` 导出 | 三算子已在本插件，置灰机制失去理由 |
| **S5** | E2E/工具链：`static.py` 登记表清空、`scene_helper_cases.py` 删 `t_has_operator` 与缺失分支断言、`probe_undo.py` 补 enable | 被测对象已变 |
| **S6** | 文档与落盘（§8）+ `fix_punctuation.py` + `unittest discover -s tests` | 收尾 |
| **S7** | **一次性跑全量门禁 10/10** → 提示作者热重载实测 | 单批制下门禁只跑这一次（S0 是基线，S7 是验收） |

> **S1/S2 不可交换、也不可穿插提交**：见 §9.2。单批制下这段中间态存在于**工作区**而非提交中，
> 风险可控；但仍建议 S1+S2 连续执行完再停下来跑一次静态检查，避免把中间态留在盘上过夜。

### 9.2 为何 S1 必须在 S2 之前（R1 的技术根据）

**同名 `bl_idname` 双注册 = Blender 破坏性接管**（2026-10-15 后台探针实测，见
`.agents/memories/cross-plugin-operator-sharing.md`）：

- Blender **不报错**，而是打印
  `Info: Registering operator class: 'X', bl_idname 'ch.x' has been registered before, unregistering previous`
  —— **后注册者注册成功的同时摘掉先注册者的 RNA**；
- 先注册方随后 `unregister_class` 抛
  `RuntimeError: ... missing bl_rna attribute ... (may not be registered)`
  （`auto_load` 吞掉并记 warning，不崩）；
- 双注册后 `bpy.ops` 调用落到**后注册的那一份**；**停用后注册的插件会让该算子整体消失**，
  另一插件的按钮随之失效（热重载可自愈）。

→ 若两侧**同时存在**这三个算子类（或两个菜单类），插件启用顺序会决定谁被摘掉，
行为不确定且难排查。**故先删源、再落目标**，任何时刻只有一侧持有。

> 单批制下无需中间的"两侧都在"提交，故 §10 的 R1 由"发布约束"降级为"操作顺序约束"——
> 但**发布**时两插件仍须同批（见 §10 R1）。

---

## 10. 风险登记

| # | 风险 | 影响 | 缓解 |
| --- | --- | --- | --- |
| R1 | **同名 `bl_idname` 双注册**（仅当两侧同时持有） | 静默"破坏性接管"：摘掉先注册者 RNA；**停用一侧插件会让算子/菜单整体消失**，行为随启用顺序而变 | ① 实施按 §9.1 **先删源(S1)再落目标(S2)**；② 单批制下该中间态只存在于工作区、不进提交；③ **发布时两插件同批**（`ch_scene_helper` 0.1.2 / `ch_utils_tools` 0.6.2），README 注明须同批更新 |
| R2 | 新增 `ui/pies/` 缺 `__init__.py` | **两个菜单静默不注册**，无报错、`--quick` 全绿 | 全量档（`verify_blender_load` 唯一出口） |
| R3 | 目标侧重复添加 `Light Linking` / `Shadow Linking` | `i18n_sweep` 报**词典重复** | §7.3：只从源侧删，不往目标加 |
| R4 | 用户既有快捷键配置失联 | `Alt+C`/`Alt+L` 归属插件变化，旧条目随源插件注销而清 | 键位默认值不变；README/CHANGELOG 提示；**Hotkeys 页已随迁**（D5），用户可在新插件偏好重新查看/修改 |
| R5 | ~~偏好 Hotkeys 页条目不完整~~ | **已消解**：作者确认补 Hotkeys 页（D5） | 新页展示本插件的 `Pie Menus` 分组；`Operators` 列为空属正常（本插件无独立快捷键算子） |
| R6 | `is_align` 旧值不随迁移带过来 | 用户升级后回落默认（`True`/`False`），行为不突变但设置需重设 | 默认值与源一致；README 说明 |
| R7 | 描述债（门禁查不到） | 语法/ruff/审计/E2E 可全绿，而注释与文档仍在讲已删机制 | 实施后**拿被删机制名全树 grep**（`has_operator` / `_draw_optional_op` / `Requires CH Custom Tools` / `_utils_tools_camera_available` / `跨插件` / `CH Custom Tools 提供`），逐个改写或显式标注"已删除" |
| R8 | 单批制改动面大、回退粒度粗 | 出问题时难二分定位 | §9.1 的 S1–S6 是**批内步骤**，建议每完成 2 步跑一次 `--quick` 旁证（静态类，零成本）；S7 跑全量档 |

---

## 11. 验收清单

**机器可执行（AI 执行）**

- [ ] `python .agents/tools/gate.py` 全量档 **10/10 PASS**（S0 基线一次、S7 验收一次）
- [ ] `python .agents/tools/check/static_audit.py`：i18n 未覆盖 0 / 死条目 0 / utils 孤儿导出 0
- [ ] `python .agents/tools/check/i18n_sweep.py ch_scene_helper`：未覆盖 0 / **词典重复 0**
- [ ] `python .agents/tools/check/i18n_sweep.py ch_utils_tools`：同上
- [ ] `python .agents/e2e/run.py --layer utils` / `--layer ops`：全过且用例数不下降
- [ ] `python .agents/tools/check/fix_punctuation.py`（新增文件注释标点）
- [ ] `unittest discover -s tests` 全绿
- [ ] 描述债 grep 清单逐条闭环（R7）
- [ ] **零残留复核**：`ch_utils_tools` 内 grep `camera_pie|light_pie|toggle_camera|set_as_scene_camera|create_align_camera|has_operator|CameraPie|LightPie|is_align` → 应为空
- [ ] 全仓 `git grep -n` 复核残留（**勿用无参仓库根检索**，会跳过 `.agents/`）

**GUI 实测（作者执行，AI 只提示）**

- [ ] `Alt + C` 相机饼菜单全部条目可点（含 `Previous`/`Next`/`Set Active Object as Camera`/
      `Create Camera Aligned to View`），`Is Align` / `Is Align View` 偏好生效
- [ ] `Alt + L` 灯光饼菜单四向条目（含 Light / Shadow Linking 的 Include / Exclude）
- [ ] 相机面板：`Create Aligned` / `▲ ▼` / `Set as Camera` **不再置灰**、无"需要
      CH Custom Tools"提示行；`Look Through` / `Lock to View` 如旧
- [ ] **只启用 CH Scene Helper**（停用 CH Custom Tools）：以上全部**仍可用**（核心验证）
- [ ] 只启用 CH Custom Tools：其余功能不受影响，且**不再**出现 `Alt+C` / `Alt+L` 两个饼菜单
- [ ] 偏好面板：`Settings` / `Hotkeys` 双页签切换正常；`Settings` 页含 `Scene Helper` 与
      `Camera Settings` 两个 box；`Hotkeys` 页 `Pie Menus` 列列出 `Alt+C` / `Alt+L` 两条且可改键；
      `Operators` 列为空（本插件无独立快捷键算子，属预期）

---

## 12. 已确认事项（作者 2026-10-16）

1. **补 `ch_scene_helper` 偏好的 Hotkeys 页** → 写入 **D5**（`settings_tab` 双页签 +
   `_draw_hotkey_column` 照搬 + `footer=None`，因本插件**无 `ExpandableUi`** 可列）。
   R5 由"可见功能回退"降级为"已消解"。
2. **R1 具体说明** → 见 **§9.2**：同名 `bl_idname` 双注册＝ Blender **破坏性接管**
   （不报错但摘掉先注册者 RNA；停用一侧插件会让算子/菜单整体消失，行为随启用顺序而变）。
   故实施按 §9.1 **先删源(S1)再落目标(S2)**；**发布时两插件同批**。
3. **删除 `camera-operator-migration-plan.md`** → **已完成**（上一版方案，已被本文件取代）。
4. **一次做完，不分批** → 写入 **§9**：S0–S7 为**同一批内的操作步骤**；全量门禁在 S0（基线）
   与 S7（验收）各跑一次；**提交一次**，作者实测一轮。

> 无待确认项，按本文件执行即可。

---

## 13. 实施结果与偏差（2026-10-16 收尾回填）

### 13.1 实施清单（全部完成）

| 项 | 结果 |
| --- | --- |
| M1–M3 三个文件搬运 | 完成。`operators/object/camera.py`(149) / `ui/pies/camera.py`(125) / `ui/pies/light.py`(130) **逐字节复制**（脚本校验字节一致），源侧整文件删除 |
| `ui/pies/__init__.py` | 新建（空文件）；缺失会让两个 `Menu` 静默不注册 |
| M4 偏好两项 | `is_align` / `is_align_view` 迁入 `CHSceneHelperPreferences`（name/description/default 逐字未改） |
| M5 keymaps | 新建 `ch_scene_helper/keymaps.py`（`CAMERA_PIE` + `LIGHT_PIE` + 注册器）；源侧删两组与 `group_labels` 两行、docstring 两行 |
| D3 跨插件机制退役 | `_TOGGLE_CAMERA`/`_SET_AS_SCENE_CAMERA`/`_CREATE_ALIGN_CAMERA`、`_utils_tools_camera_available`、`_draw_optional_op`、`_draw_missing_utils_tools_hint`、`utils/blender/operator.py` 与 `__init__` 导出 **全部删除**；面板改类引用 |
| D5 Hotkeys 页 | `CHSceneHelperPreferences` 改 `Settings` / `Hotkeys` 双页签，`_draw_hotkey_column` 照搬（`footer` 保留形参、传 `None`） |
| i18n | 源侧删 36 键 + 1 键改写（`Camera and hole extrude settings` → `Hole extrude settings`）；目标侧迁入 + 复制 `Compositor` / `Point` |
| E2E/工具链 | `CROSS_PLUGIN_OPS` 清空；`scene_helper_cases.py` 删 `t_has_operator` 与跨插件缺失分支断言、改按算子类 `bl_idname` 断言；`probe_undo.py` 补 enable `ch_scene_helper` |

### 13.2 与计划的偏差（逐条）

1. **§7.3 的"必须删除而非复制"实际拦下了一次真实缺陷**：计划已判定
   `Light Linking` / `Shadow Linking` 在目标词典已存在、不可再复制。实施时我**确实误加了**
   这两条到目标词典 → `ruff` 报 `F601 Dictionary key literal repeated`（2 处）→ 已删除。
   **教训**：该判据有效，且 ruff 是这类"词典重复"的**唯一**机器出口（`static_audit` 与
   `i18n_sweep` 都查不到键重复，前者只查覆盖/死条目）。
2. **§7.1 的键数口径**：计划写"37 条"，实施后实际为 **36 条删除 + 1 条改写**（合计 37 条处理）。
   清单本身无误（35 个不同原文、其中 2 个跨 `*`/`Operator` 双语境）。
3. **新增词条（计划未预见）**：偏好双页签的 2 个 enum description
   （`Scene helper and camera settings` / `Registered hotkey list`）不在原词典里，实施时补入。
4. **`keymaps.py` 未搬运两个死函数**：源侧 `get_keymap_items` / `get_registered_keymaps`
   经全仓 grep 确认**零消费者**，按移植规范"质量债不搬运"未带入新文件（源侧亦未删，属既有死代码）。
5. **`_MockLayout.is_registered` 注入保留但改为默认 `None`**：跨插件缺失分支已无对象，
   该注入仍可用于"本插件算子未注册"的同款语义，故保留形参、仅更新注释。

### 13.3 验证事实

- `python .agents/tools/gate.py`（全量档）→ **10/10 PASS**（含 `verify_blender_load` 与层2/层3）
- `static_audit`：两插件均 **0 未覆盖 / 0 死条目 / 0 孤儿导出**
- `ch_utils_tools` 零残留复核（`git grep`）：`camera_pie|light_pie|toggle_camera|set_as_scene_camera|create_align_camera|has_operator|CameraPie|LightPie|is_align_view|CAMERA_PIE|LIGHT_PIE` → **空**
- 层3 面板 draw 冒烟：相机动作行三个算子按钮**以类引用被创建**（调用轨迹实测含
  `ch.create_align_camera` / `ch.toggle_camera` ×2 / `ch.set_as_scene_camera`）

### 13.4 本批踩到的环境坑（已入 memories）

**`addons_core` 陈旧副本遮蔽沙箱**：为验证新断言"有牙"，我故意把
`SetAsSceneCamera.bl_idname` 改成不存在的 id 跑层3——结果**仍 PASS**。排查发现
`D:\Program\blender-5.1.2-windows-x64\5.1\scripts\addons_core\ch_scene_helper\` 存在旧副本且
**优先于沙箱解析**，故用例一直跑的是陈旧代码。处置：跑
`blender --background --factory-startup --python .agents/tools/verify/verify_blender_load.py`
刷新安装副本 → 重跑 → 断言**如实报红**（`实际: ['ch.set_as_scene_camera']`）→ 撤回注入 → 复绿。
**该陷阱会让"自证有牙"的注入实验假绿，从而掩盖断言失效**——先刷新安装再判红绿。
