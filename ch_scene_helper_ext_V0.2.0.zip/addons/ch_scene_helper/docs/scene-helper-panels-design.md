# Scene Helper 三面板深化设计方案（Lights / Cameras / Materials）

> **归属：`ch_scene_helper` 插件**（2026-10-15 自 `ch_utils_tools` 分离时随功能迁入）。
>
> **状态：已实施（Stage 1 定稿，2026-10-15，未发布版本）**
>
> - **§1–§6、§10 为初版方案与三轮验证记录（考古价值）**：其中的活动项检查器条、面板头
>   `template_ID`、Add / Select All / 饼菜单入口、行内双开关、假用户盾牌等已在实施中按作者
>   意见调整或移除——**当前生效设计以 §11 定案记录为准**。
> - §7–§9 为实现期约定与风险（已按定案更新）。
> - §11 为定案记录：落位结构、迭代轮次、关键技术结论（勿回退项）、与初版方案的偏差、GUI 待实测。
> - **§12 为插件分离记录**：三面板自 `ch_utils_tools` 迁入本插件的边界、跨插件相机算子调用与
>   可用性置灰的实测依据；**跨插件部分以 §12 为准**（§11.1 的落位表已同步为分离后形态）。
>   **⚠️ §12.2 的"算子留在 ch_utils_tools"定案已于 2026-10-16 被推翻**：相机三算子与
>   相机/灯光两个饼菜单已迁入本插件，跨插件机制整体退役——见 §12.2 末的横幅。
>   （§5.1/§5.2 正文里"Light Pie ▸ / Camera Pie ▸ 呼出饼菜单"等描述属**分离前**的初版方案，
>   仅作考古。）
>
> 版本线索：v1（2026-10-13 三段密度骨架）→ v2（2026-10-14 使用频率分析重排）→
> 实施 6 轮作者意见（2026-10-14/15）→ 代码重构与文档规范化（2026-10-15）→
> 分离为独立插件 `ch_scene_helper`（2026-10-15）。
>
> 对象：本插件 `ui/panels/scene_lists.py` 的三个面板（`VIEW3D_PT_ch_lights` /
> `VIEW3D_PT_ch_cameras` / `VIEW3D_PT_ch_materials`，侧栏选项卡 `Scene Helper`）及其依赖链
> （`ui/lists/scene_lists.py`、`operators/utils/material_ops.py`、`operators/utils/scene_list_ops.py`、
> `operators/object/light.py`、`utils/blender/{material,light,list_order,scene_data,operator}.py`、
> `props.py`、`handlers.py`、`preference.py`、`common/blender/list_snapshot.py`、
> `common/blender/material.py`）。

---

## 1. 现状与问题（源码事实）

三面板当前能力 = **快照列表 + 点击反选 + 行内重命名**：

| **已有**                                                                                           | **位置**                                                        |
| ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------- |
| **WM 级快照状态（lights/cameras/materials + 各自活跃索引），depsgraph/load_post/1s 定时器三重刷新，`is_syncing` 重入护栏** | **`props.py` / `handlers.py` / `common/blender/list_snapshot.py`** |
| **名称通配过滤 + 字母排序 + 反序（UIList 基类标准行为）**                                                            | **`StandardFilterMixin`**                                     |
| **行内双击重命名，写穿真实数据块（物体/材质），失败回写**                                                                  | **`list_snapshot.on_item_name_update`**                       |
| **点击行 → 选中物体（灯/相机）或选中材质全部使用者；活动物体/活动材质回同步到活跃索引**                                                 | **`handlers.on_*_index_update` / `_sync_selection`**          |
| **灯光列表合并"灯光物体 + 自发光材质物体"（图标区分：类型灯图标 vs MATSPHERE）**                                              | **`scene_data.collect_lights`**                               |

**问题**（资深使用者视角）：

1. **看得见名字，看不见状态**。灯的能量/颜色/类型、相机哪个是场景相机、材质几个用户/是否孤儿——  
   全都要逐个选中去属性编辑器核对。
2. **没有动作**。面板只能"看"和"选"，一切操作仍要回到饼菜单/F3/属性编辑器。
3. **高频微调路径长**。调 10 个灯的能量 = 10 次（选中 → 属性编辑器 → 灯光选项卡 → 拖滑）。
4. **多相机镜头工作流断链**。场景相机切换靠 Alt+C 饼；相机与时间线标记的绑定在时间轴菜单里。
5. **批量曝光无入口**。布光收尾"整体亮度 ±20%" 要逐个灯拖能量，原生与本插件均无快捷方式。

**设计目标**：把三个面板从"可浏览的快照列表"升级为"场景资源管理工作台"——  
**状态一眼可见、微调一步到位、批量动作一键执行**，且与既有饼菜单/工具互补不重复。

---

## 2. 使用逻辑与频率分析（v2 核心修订依据）

方法：按真实工作流逐操作标注频率（高/中/低）与现有成本，只把"高频 + 现有路径长"的操作沉进面板。

### 2.1 Lights —— 布光迭代流

工作流：建灯 → 调能量/颜色 → 渲 → 微调（循环 N 次）→ 收尾整体曝光 → A/B 灯光贡献 → （复杂场景）灯光链接。

| 操作                             | 频率        | 现有成本             | 面板落点                                 |
| ------------------------------ | --------- | ---------------- | ------------------------------------ |
| 调能量                            | 高（每次迭代）   | 选中 → 属性编辑器 → 拖滑  | 检查器条第一屏                              |
| 调颜色/色温                         | 高         | 同上               | 检查器条第一屏                              |
| 建灯（4 类型）                       | 高         | Shift+A（需切焦点区域）  | 面板头 Add ▾                            |
| hide_render（A/B 灯光贡献）          | 高         | Outliner 列或属性编辑器 | 行内开关                                 |
| hide_viewport（遮挡）              | 高         | 同上               | 行内开关                                 |
| 调类型属性（radius/angle/size/shape） | 中         | 属性编辑器            | 检查器条第二屏                              |
| 阴影开关/柔化                        | 中         | 属性编辑器 / Alt+L 饼  | 检查器条第三屏                              |
| **整体曝光缩放**                     | **高（收尾）** | **逐个灯拖，无快捷方式**   | **动作行 `ch.light_energy_scale`（新算子）** |
| Select All                     | 中         | Ctrl+点击/F3       | 面板头                                  |
| 灯光链接/阴影链接                      | 低（复杂场景）   | Alt+L 饼          | 动作行按钮（入口）+ 饼深调                       |
| 自发行检查器条                        | 中         | 属性编辑器材质选项卡       | Stage 2                              |

### 2.2 Cameras —— 多机位取景流

工作流：建对齐相机 → 调 lens → 设场景相机 → Look through 取景 → （安全框构图）→ 下一机位循环；动画场景再加标记绑定。

| 操作                             | 频率          | 现有成本                        | 面板落点                                   |
| ------------------------------ | ----------- | --------------------------- | -------------------------------------- |
| 设场景相机                          | 高（每机位）      | Alt+C 饼（有 is_align_view 分支） | 动作行 + 行内场景相机徽标                         |
| Look through / 锁定视图            | 高           | 小键盘 0 / 视图锁定                | 动作行                                    |
| 建对齐相机                          | 高           | Alt+C 饼                     | 面板头                                    |
| 行内 hide_render / hide_viewport | 高（辅助机位常驻隐藏） | Outliner 列                  | 行内双开关                                  |
| 调 lens / sensor                | 中（每台一次）     | 属性编辑器                       | 检查器条第一屏                                |
| Prev/Next 循环切换                 | 中           | Alt+C 饼                     | 面板头                                    |
| DOF（focus/f-stop）              | 中           | 属性编辑器                       | 检查器条第二屏                                |
| 安全框/背景图/passepartout           | 中           | 属性编辑器                       | 检查器条第三屏                                |
| **场景相机快速换**                    | 高           | 无直接入口（饼要点两级或 Outliner）      | **面板头 `template_ID(scene, "camera")`** |
| 时间线标记绑定                        | 中（动画）       | 时间轴菜单                       | Stage 2 独立子区                           |

### 2.3 Materials —— 分配与清理流

工作流（材质侧发起）：看谁在用 → 分配/替换 → 清理孤儿/假用户 → 复制变体。

| 操作                     | 频率    | 现有成本                               | 面板落点                                                                      |
| ---------------------- | ----- | ---------------------------------- | ------------------------------------------------------------------------- |
| Select users（反查）       | 高     | 点击列表行（已有）                          | 动作行显式按钮                                                                   |
| **Assign to selected** | 高     | 无（材质拾取器 ASSIGN 是模态拾取式，非"把活动材质赋过去"） | 动作行 `ch.material_assign`（新算子）                                             |
| 使用者数                   | 高（清理） | Outliner 或 Blender 文件清理            | 行内 `×N`（`mat.users`，恒 ≥1，见下注）                                             |
| 假用户开关                  | 中     | 属性编辑器材质选项卡盾牌                       | 行内盾牌开关                                                                    |
| Duplicate              | 中     | Shift+D 复制物体再取槽 / 属性编辑器            | 动作行（新算子）                                                                  |
| Delete                 | 低     | 属性编辑器                              | 动作行（0 用户守卫）                                                               |
| 活动物体活动材质位              | 高     | 属性编辑器                              | 检查器条 `template_ID(context.object, "active_material", new="material.new")` |

> **两个"活动"必须区分**（实现易错点）：**面板活动材质**（列表活跃索引对应，Assign /  
> Select Users / Duplicate / Delete 的作用对象）vs **活动物体的活动材质槽**  
> （`context.object.active_material`）。两者可以不同；面板只操作前者（初版设计的  
> 检查器条 template_ID 已在作者意见轮 1 移除，概念区分保留在 material_ops 模块 docstring）。
>
> **孤儿材质不进本列表**（Loop 2 发现的设计缺陷修正）：`collect_scene_materials` 只收集场景物体  
> 材质槽里的材质，0 用户/仅假用户的孤儿**永远进不了快照**，v1 的"×0 孤儿警示"是死逻辑。  
> 定论：本面板只列在用材质（`×N` 恒 ≥1，徽章用于区分 1 vs 12 的使用广度）；孤儿/未用清理  
> 归 Shift+X 清理饼（已有"移除未用材质槽 + 孤儿清理"），面板不重复设入口。

---

## 3. 设计原则

1. **面板是工作台，不是大纲视图复刻**。树形/集合层级留给 Outliner。
2. **信息密度分三层**（每面板统一骨架）：
   - **面板头**：计数 + 集合级信息（场景相机 template_ID）+ 集合级动作（新建/全选/切换）；
   - **列表行**：身份与状态——图标 + 名称 + 行内开关（至多两个）+ 小字（焦距/用户数）；
   - **活动项检查器条**：活跃数据块高频属性直调，按 §2 频率排序；
   - **动作行**：作用于活动项/选集的一键动作 + 饼菜单深调入口。
3. **操作就近**：一键动作不埋两级菜单。
4. **与既有工具互补**：Alt+C / Alt+L / Alt+Shift+E 饼菜单是"深调入口"（面板放呼出按钮），  
   面板承载 80% 高频微调。复用现有算子与 utils，不复制逻辑。
5. **最小可用、分期交付**：每期独立可发布、可实测；不为偶发场景增加常驻复杂度。

---

## 4. 统一骨架

```
┌─ 面板头 ─────────────────────────────────────────────┐
│ Lights (12)        [template_ID / Add ▾] [Select All]│  ← 计数 + 集合级信息与动作
├──────────────────────────────────────────────────────┤
│ [💡] Key.Light        [👁][📷]                        │  ← 行 = 图标 + 名 + 双开关 + 小字
│ [☀] Sun               [👁][📷]                        │     （过滤顶行随 template_list，不动）
│ [▣] Area.Fill        [👁][🚫]                        │
│ …                                                  ▾ │
├──────────────────────────────────────────────────────┤
│ Active: Area.Fill                                    │  ← 活动项检查器条（按频率排序）
│ [Energy ────●] [Color ▣]                             │
│ [Radius ──●] [Shape ▾]        [Cast Shadow] [Temp ●] │
├──────────────────────────────────────────────────────┤
│ [Energy Scale ×0.8]  [Light Linking] [Light Pie ▸]   │  ← 动作行
└──────────────────────────────────────────────────────┘
```

排版惯用法沿用 `memories/blender-api-pitfalls.md §11`（作者实测定稿）：算子属性集无  
`enabled`，置灰设在布局对象上；窄侧栏多控件可去文字标签挤一行、说明走悬停。

---

## 5. 分面板设计

### 5.1 Lights（灯光）

| 层    | 内容                                                                                                                                                                                                                                          |
| ---- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 面板头  | `Lights (N)`；**Add ▾**（Point/Sun/Spot/Area，原生 `object.light_add`；**实测默认落点 = 3D 游标**（探针：游标 3,2,1 → 灯落 3,2,1），无需设 align 参数，与 Shift+A 行为一致）；**Select All**（`object.select_by_type` type='LIGHT'）                                               |
| 列表行  | 类型图标（现有 `_LIGHT_ICONS`；自发光物体 MATSPHERE）+ 名称（双击重命名，现有）+ **行内双开关**：`hide_viewport`（RESTRICT_VIEW_ON/OFF）+ `hide_render`（RESTRICT_RENDER_ON/OFF），`emboss=False` 图标开关，直接 prop 真实物体                                                              |
| 检查器条 | 第一屏：`energy` + `color`；第二屏：类型属性——POINT/SPOT `shadow_soft_size`、SUN `angle`、AREA `shape`+`size`/`size_y`、SPOT `spot_size`/`spot_blend`；第三屏：`use_temperature`+`temperature`、EEVEE `use_shadow`、Cycles `lightgroup`/`spread`。与灯光饼同一组 RNA，不复制逻辑 |
| 动作行  | **Energy Scale**（`ch.light_energy_scale`，新算子：对选中灯光 energy 乘 F9 因子，REGISTER/UNDO，默认 1.0）；**Light Linking / Shadow Linking**（原生 `object.light_linking_receivers_link`/`blockers_link`）；**Light Pie ▸**（呼出 `VIEW3D_MT_ch_light_pie`）           |

> 自发行的检查器条（材质 emission strength/color）Stage 2——检查器条双形态不前置。

### 5.2 Cameras（相机）

| 层    | 内容                                                                                                                                                                                                                                                                      |
| ---- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 面板头  | `Cameras (N)`；**场景相机 template_ID**（`layout.template_ID(scene, "camera", new="object.camera_add", open="outliner.id_open")`，一行解决"当前是谁 + 直接换"——`open` 算子运行时实证存在，源码树 grep 未中疑注册宏生成）；**Create Aligned**（复用 `CreateAlignCamera`）；**Prev / Next**（复用 `ToggleCamera`）          |
| 列表行  | 场景相机徽标（`VIEW_CAMERA` 实心 vs `OUTLINER_OB_CAMERA` 线框）+ 名称 + 焦距小字（draw 期读 `cam.lens` 取整）+ **行内双开关** `hide_viewport`/`hide_render`                                                                                                                                          |
| 检查器条 | 第一屏：`lens` / `sensor_width`；第二屏：`dof.use_dof` + **`dof.aperture_fstop`**（源码实证 5.x 属性名，4.x 旧名 `aperture_f_stop` 已不存在；5.x 新增 `aperture_blades`/`aperture_rotation`/`aperture_ratio` 不进面板，深调走属性编辑器）；第三屏：`clip_start`/`clip_end`、`show_safe_areas`/`show_background_images` |
| 动作行  | **Look Through**（`view3d.view_camera`）；**Lock to View**（`space_data.lock_camera`）；**Set as Scene Camera**（复用 `SetAsSceneCamera`）；**Align to View**（`view3d.camera_to_view`）；**Camera Pie ▸**（呼出 `VIEW3D_MT_ch_camera_pie`）                                              |

**Stage 2 子特性——时间线标记绑定**：面板尾部折叠小区，列 `scene.timeline_markers`（帧号 + 绑定相机名），动作：面板活动相机绑定到选中标记 / 新建标记并绑定 / 解绑。**实测决策**：绑定走 **RNA 直写 `marker.camera = cam_obj`**——`bpy.ops.marker.camera_bind()` 在后台 poll 失败（依赖编辑器上下文），直写无上下文依赖、任何调用路径可用；标记创建同理用 `scene.timeline_markers.new(name, frame)`（`marker.add` 算子运行时存在，但直写更稳）。

### 5.3 Materials（材质）

| 层    | 内容                                                                                                                                                                                                        |
| ---- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 面板头  | `Materials (N)`（Purge 入口不做，破坏性清理已有 Shift+X 清理饼承载）                                                                                                                                                         |
| 列表行  | 假用户盾牌（`FAKE_USER_ON/OFF`，行内开关 prop `mat.use_fake_user`）+ 名称（现有重命名）+ 使用者数（draw 期读 `mat.users`，`×N`；**实测语义**：0 用户=0、假用户 +1、按材质槽引用数涨；本列表恒 ≥1，徽章与盾牌图标并读不误解；孤儿不进本列表，见 §2.3 注）                                  |
| 检查器条 | `template_ID(context.object, "active_material", new="material.new")`——**活动物体的活动材质槽**（与"面板活动材质"两概念，见 §2.3 注）                                                                                               |
| 动作行  | **Assign to Selected**（`ch.material_assign`：面板活动材质 → 全部选中物体的活动材质槽；仅物体模式，编辑模式已有拾取器 ASSIGN）；**Select Users**（复用 `_select_material_users`）；**Duplicate**（`mat.copy()`，新算子）；**Delete**（0 用户才执行，有用户 report 警告） |

---

## 6. 数据与代码结构（对既有架构的最小侵入）

### 6.1 快照层：零改动

行级状态（`hide_viewport`/`hide_render`/`lens`/`users`/`use_fake_user`）全部 **draw 期 O(1) 直读真实  
数据块**（按 `item.src_name` 查 `scene.objects.get` / `bpy.data.materials.get`），不进快照、不加字段。  
快照重建由"名称序列差异"驱动（`rebuild_if_changed`），这些状态变化不改名称序列，进快照反而要  
自建失效机制。`common/blender/list_snapshot.py` **零改动**（ch_ai_assistant 共用，零影响）。

> 惯用法约束（`pitfalls §10`）：draw 期禁止把长用户文本交给 `label()`；行内名称走  
> `prop(item, "name")` 编辑框（有滚动条，不冻结），现状保持。

### 6.2 collect 层：签名不变

`collect_*` 的 `(names, err)` 契约不动；Stage 2 若需聚合信息以并列新函数提供。

### 6.3 新算子落位（按域分包，房规 1/2）

| 算子                                             | 落位                                         | 说明                                                              |
| ---------------------------------------------- | ------------------------------------------ | --------------------------------------------------------------- |
| `ch.material_assign`                           | `operators/utils/material_ops.py`（新文件）     | 与 `material_picker.py` 同目录同深度；物体模式 poll；REGISTER/UNDO           |
| `ch.material_duplicate` / `ch.material_delete` | 同上                                         | 0 用户守卫                                                          |
| `ch.light_energy_scale`                        | 同上（或 `operators/object/light.py`，二选一，实现时定） | FloatProperty factor（F9），对选中灯光 energy 乘系数；UNDO                  |
| 灯光/相机面板动作                                      | **不新造**                                    | 原生算子 + 现有 `CreateAlignCamera`/`SetAsSceneCamera`/`ToggleCamera` |

新文件导入写法照抄同目录 `material_picker.py` 先例：`from .....common.i18n.i18n import iface, report`、  
`from ...utils import ...`、`from ...preference import get_prefs`（e2e 层1 静态校验点数，见 §10）。

### 6.4 props / prefs / handlers

- `props.py`：MVP 不加属性。
- `preference.py`：新增 **Scene Helper** 设置盒——双向选中同步开关（默认开）；关闭时三个 index  
  update 回调与 `_sync_selection` 入口跳过。**新增 RNA 属性 ⇒ 必须跑 `gate.py` 全量档**（房规 15）。
- `handlers.py`：刷新机制不动，仅同步开关判读。

### 6.5 面板层重排

`ui/panels/scene_lists.py` 三段式重写：`_draw_list_body` 保留；新增每面板各自的  
`_draw_header` / `_draw_inspector` / `_draw_actions`。共享绘制助手按 §11 惯用法。

### 6.6 i18n / 图标 / 测试（房规合规项）

- **i18n**：新文案走 `iface()`/`report()`；写词条前 `i18n_check_terms.py --query` 查系统词  
  （系统词条不翻译，房规 4）；动态文本按模板拼（`iface("{}mm").format(v)`）。  
  **Loop 2 查典结果分流**（2026-10-14，运行时词典）：
  - 系统已有（不入插件词典，共 23）：Color / Radius / Cast Shadow / Temperature / Lens / Sensor /  
    Clip / Safe Areas / Background Images / Light Linking / Shadow Linking / Duplicate / Delete /  
    Fake User / Scene Camera / Add / Select All / Next / Lights / Cameras / Materials / Active
  - 未命中（须入插件词典，共 13）：Energy / DOF / f-stop / Assign to Selected / Select Users /  
    Look Through / Lock to View / Set as Camera / Align to View / Prev / Create Aligned / Energy Scale
- **图标**：方案引用图标写前 `icon_check.py --query` 复核（图标名绘制期才报错）。
- **测试**：新 utils 纯函数进 `tests/`；新算子进 E2E 层 2/3 后台用例；  
  **GUI 交互实测归作者**（AI 完成改动后提示测试，不自行启动 GUI 通道）。
- **README**：`ch_utils_tools/README.md` 新增「Scene Helper」小节（三面板当前在 README 完全缺失）。


## 8. 明确不做（及理由）

| 不做                    | 理由                                               |
| --------------------- | ------------------------------------------------ |
| 大纲式树/集合层级             | Outliner 已覆盖；面板保持扁平快速                            |
| 行内材质/相机预览缩略图          | 每行 preview 渲染开销 × N 栏宽度不值；仅活动项 preview 留 Stage 2 |
| 隐藏 template_list 过滤顶行 | C 层无开关（`pitfalls §10` 实证）；房规：做不到就撤回、不自造替代        |
| Purge Unused 面板入口     | 破坏性；Shift+X 清理饼已承载，不重复设入口                        |
| 批量重命名（前缀/后缀）          | 生态已有专门插件；最小可用                                    |
| Stage 3 前的多选 / 拖拽排序   | 见 §7                                             |

---

## 9. 风险与对策

| 风险                            | 对策                                                              |
| ----------------------------- | --------------------------------------------------------------- |
| draw 期逐行直读在超大树变慢              | 行内只做 O(1) 字典查找；使用者数用 `mat.users` 直读而非 O(物体×槽) 扫描                |
| 新 RNA 属性注册期错误只有真实 Blender 能暴露 | 偏好改动跑 `gate.py` 全量档（房规 15）                                      |
| 图标名版本漂移                       | 写前 `icon_check.py --query`（本机 5.1.2 运行时枚举为准）                    |
| 设置子面板与饼菜单属性漂移                  | 设置子面板只读同一组 RNA，逻辑不复制；饼菜单加属性时按同清单补                                |
| 三面板骨架发散                       | 公共混入 `_SceneListPanelMixin` 提供标题自绘与列表元信息契约；绘制 helper 统一（`_draw_list_body`/`_draw_settings_box`/`_draw_*_actions`） |
| 两个"活动材质"概念混淆                  | §2.3 注 + material_ops 模块 docstring；面板动作只操作"面板活动材质"                                    |

---

## 10. 验证记录（三轮循环回填）

> 本节由「方案 → 验证 → 修订」三轮循环填充：每轮记录验证方式、发现、修订。

| 轮次         | 验证方式                                                                    | 发现                                                                                                                                                                                                                                                                                                                        | 修订                                                               |
| ---------- | ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| Loop 2（静态） | 源码树 grep 核对 RNA/算子；icon_check / i18n_check_terms 查典                     | **抓到一个实质错误**：DOF 属性 5.x 名为 `aperture_fstop`（v1 写的 `aperture_f_stop` 是 4.x 旧名，已不存在）；`outliner.id_open` 算子源码树不存在（template_ID 的 open 参数暂不设，留 Loop 3 终审）；**一个设计缺陷**：孤儿材质进不了 collect 快照，"×0 警示"死逻辑（改为只列在用材质）；RNA 24 属性 / 8 算子全部证实存在；图标 25/25 过（LIGHTGROUP 非图标无需验）；i18n 23 系统词 + 13 入典分流                                        | `aperture_fstop` 改名；open 参数移除；孤儿语义改为归 Shift+X 清理饼；i18n 双清单入 §6.6 |
| Loop 3（行为） | 后台 Blender 5.1.2 探针（`--background --factory-startup`）实测 + gate.py 全量档基线 | **`aperture_fstop` 运行时坐实**（含 5.x 新增 blades/ratio/rotation）；**`light_add` 默认落点 = 3D 游标**（align 参数免设）；**`mat.users` 语义**（0/假用户+1/按槽涨）；**`marker.camera_bind` 算子后台 poll 失败 → 改 RNA 直写**（`marker.camera = cam` 直写可行）；**`bpy.ops.outliner.id_open` 运行时存在**（template_ID open 参数恢复）；算子 8/8 运行时在位；**gate.py 全量 10/10 PASS**（环境基线） | open 参数恢复；标记绑定改直写；users 语义入档；light_add 落点入档                      |

---

## 11. 实施记录（Stage 1 定案，2026-10-15，未发布）

> 本节为当前生效设计；逐轮过程细节另见 `CHANGELOG.md` 与 `.agents/log/2026-10-14.md`、`2026-10-15.md`。

### 11.1 落位结构

> 下表路径均为**分离后**（本插件 `addons/ch_scene_helper/`）的落位；`ch_utils_tools` 侧对应文件已移除，
> 仅相机三算子仍留在 `ch_utils_tools/operators/object/camera.py`（见 §12）。

| 层 | 文件 | 职责 |
| --- | --- | --- |
| 面板 | `ui/panels/scene_lists.py` | 三面板 + 公共混入骨架 `_SceneListPanelMixin`（标题自绘与列表元信息契约）+ 公共绘制 helper |
| 列表 | `ui/lists/scene_lists.py` | 三 UIList：名称列 + 状态列（三开关 / 使用者数），行结构经 `_draw_name_cell` 统一 |
| 算子 | `operators/utils/material_ops.py`、`scene_list_ops.py`、`operators/object/light.py` | 材质四算子 / 列表三算子（Move / Sort / ObjectDelete）/ Energy Scale |
| 算法 | `utils/blender/material.py`、`light.py`、`list_order.py`、`scene_data.py`、`operator.py`；`common/blender/material.py` | 材质三算法 / 能量缩放 / 列表顺序值 / collect 按顺序值排序 / 算子可用性判定；跨插件共用的材质赋值与槽类型常量 |
| 状态与联动 | `props.py`、`handlers.py`、`preference.py`、`__init__.py` | WM 状态组 ×2（列表快照 + 设置子面板展开态）/ 快照同步与点击反选 / 双向同步开关 / 属性挂载 |
| 文案 | `i18n/dictionary.py`、`README.md`、`CHANGELOG.md` | 查典分流入典 / 面板小节 / 变更条目 |
| 测试 | `.agents/e2e/cases/utils_cases.py`、`ops_cases.py`、`scene_helper_cases.py` | 材质算法 / 顺序值 / collect 排序 / 列表算子 / 面板 draw 冒烟 |

### 11.2 迭代轮次（作者意见 → 落定）

| 轮次 | 作者意见（摘要） | 落定 |
| --- | --- | --- |
| 1 初版实施 | 按 Stage 1 实施 | 三段式工作台 + 5 新算子 + 偏好双向同步开关；材质赋值与选中使用者算法下沉 utils 与 material_picker / handlers 共用 |
| 2 | 删减入口；列表右侧加上移 / 下移 / 按名排序 / 删除；开关图标与大纲不一致 | 删 9 处入口；列表按钮列 + `ch_scene_order` 顺序持久化；图标改只传 `_OFF` 基图标（见 11.3-2） |
| 3 | 去"活动项"行；设置合一子面板且顺序对齐原生；行内加"禁用选中" | 单一"设置"子面板（原生顺序）；行内三开关；开关行 align=False 等宽居中 |
| 4 | 标题改"标题 + 数量"；子面板加"设置"标题；动作行紧跟列表 / 创建行；去行内焦距 | 动作行位置重排；相机行与灯光行同构；排序按钮移除（算子保留 F3） |
| 5 | bug：设置子面板不显示；去"对齐到视图" | 修调用点漏改；补"面板 draw 冒烟"用例（见 11.3-3） |
| 6 | 标题"数量后又跟名称"；子面板去图标 | 标题改 `bl_label=""` + 自绘方案（见 11.3-1）；子面板头只留三角 + "设置"文本 |
| 7 重构 | 重构本轮代码 / 提升复用性 / 规范化文档 | 公共混入骨架 + helper 去重（算子场景获取、回调闸门、面板材质获取）；本文档与 CHANGELOG 收敛 |

### 11.3 关键技术结论（勿回退）

1. **标题"名称 + 计数"**：`bl_label = ""` + `draw_header` 自绘两段标签。系统补画的是空标签（不可见），
   不依赖"标签匹配 bl_label 抑制补画"——该匹配比对 `but->str` 与 `CTX_IFACE_`
   （`interface_layout.cc` 的 `layout_has_panel_label`），本地化界面下口径不一致会多画一个名称（轮 6 实证）。
2. **行内状态开关**：IconToggle 对带 `PROP_ICONS_CONSECUTIVE` 的 RNA 属性（hide_select / hide_viewport /
   hide_render）按开关态执行 `iconadd`（REVERSE 时 −1）并加反色高亮（`interface.cc`）；**只传 `_OFF` 基图标**，
   显式传 `_ON` 会叠减成错误字形（轮 2 实证）。
3. **面板 draw 是门禁盲区**：静态检查覆盖不到绘制期异常（轮 5 的 TypeError 曾漏放）。E2E 层3
   "面板 draw 冒烟"以 mock 布局（只记录不评估属性）+ `SimpleNamespace` 假 self + 未绑定调用
   `cls.draw(fake, context)` 覆盖四种灯光 / 两引擎 / 空列表全分支；已用"重引入 bug 复报"验证回归有效性
   （`Panel.__new__` 实例化被 bpy_struct 拒绝，探针实证后改走未绑定调用）。
4. **自定义属性写入不触发 depsgraph**（探针实证）：列表顺序值写完后须调 `handlers.refresh_lists()`
   主动重建快照。
5. **选中同步两个坑**（轮 1 实证）：冷启动 `active=None` 时 `select_set(True)` 静默失效 → 先设活动物体；
   迭代 `view_layer.objects` 活集合的同时 `select_set` 会令迭代器失效 → 遍历列表副本。
6. **E2E 环境事实**：手动构造的 WM 快照会被同步 handler 按场景真相重建冲掉——测试数据须先成为场景真相。
7. **static_audit 覆盖口径**：`operator.text` / `bl_label` 需 `("Operator", X)` 词典键（系统词也要，
   运行时系统 mo 优先）；RNA 属性名不写 `text=` 时其词典条目会被判死条目。

### 11.4 与初版方案（§1–§6）的偏差

1. **活动项检查器条 → 可展开"设置"子面板**（作者意见轮 2/3）：属性顺序改为对齐原生数据属性面板。
2. **Delete 语义**：不作"0 用户守卫"（面板材质恒有使用者，守卫即死按钮）——始终删除，
   Blender 自动清空材质槽，UNDO 可恢复。
3. **孤儿材质**：不进快照，清理归 Shift+X 清理饼（与初版一致）。
4. **列表顺序**：初版未规划——定案为数据块自定义属性 `ch_scene_order` 持久化 + collect 按 `order_key`
   排序（默认名称序）。
5. **无 UI 入口的算子**：`ch.light_energy_scale`、`ch.scene_list_sort` 面板已撤入口但保留
   （F3 可搜索、e2e 覆盖）——是否彻底删除由作者定夺。

### 11.5 GUI 待实测点（归作者）

- 标题中英文界面均只出现一次名称（轮 6 修法不依赖匹配，理论两语言均稳）
- 设置子面板展开 / 收起与属性顺序；行内三开关与系统大纲 restriction 列对照
- 上移 / 下移 / 删除与顺序持久化（存盘重开）；Energy Scale / Delete 的 UNDO
- 自发行（MATSPHERE）暂无设置区（Stage 2）

---

## 12. 插件分离记录（2026-10-15，本插件首发）

作者指令：把 `ch_utils_tools` 的灯光 / 材质 / 相机三面板整条功能链分离为独立插件
`ch_scene_helper`。三处实现决策与其实测依据：

### 12.1 分离边界

| 归属 | 内容 | 理由 |
| --- | --- | --- |
| **迁入本插件** | 三面板 / 三 UIList / 材质四算子 / 列表三算子 / Energy Scale / collect 与列表顺序算法 / WM 状态组 / 同步 handlers / 双向同步偏好 / 面板词典条目 / 设计文档 | 单消费者，或属面板功能本体 |
| **留在 `ch_utils_tools`** | `get_material_output` / `get_last_node`、材质拾取器 | 材质拾取器与其 utils 属 ch_utils_tools 自有功能（**已过期**：相机三算子与 `Alt+C` 相机饼菜单于 2026-10-16 迁入本插件，见 §12.2 横幅） |
| **下沉 `common/`** | `assign_material` + `MATERIAL_SLOT_TYPES`（`common/blender/material.py`） | 纯函数与常量，无注册耦合；材质拾取器 ASSIGN 与面板 Assign to Selected 为真实双消费者 |

### 12.2 跨插件相机算子：只能走字符串 id（实测依据）

曾评估把相机三算子下沉 `common/`（两插件各打包一份副本）与其引用计数方案，两次后台探针
（Blender 5.1.2 `--background --factory-startup`）结论：

1. **同名 `bl_idname` 双注册是"破坏性接管"**：后注册者注册成功的同时，Blender 会摘掉先注册者的
   RNA（`Info: Registering operator class: ..., bl_idname '...' has been registered before,
   unregistering previous`）；先注册方随后 `unregister_class` 抛
   `RuntimeError: ... missing bl_rna attribute ... (may not be registered)`，
   且停用其中一个插件会让共享算子整体消失（另一插件按钮失效）。
2. 同源 `PropertyGroup` 同名双注册是良性的（双方均成功、无提示）——现有
   `common/blender/list_snapshot.py::ListItem` 被两插件各注册一份的现状无障碍。
3. `bpy.app` **不接受任意属性**（`no __dict__ for setting new attributes`），会话级引用计数缺乏
   干净载体；`dir(bpy.ops.<模块>)` 可可靠判定某算子是否已注册。

据此定案：**算子本体留在 `ch_utils_tools`，本插件以字符串 id 调用，并在绘制期用
`utils/blender/operator.py::has_operator` 判定可用性**——提供方未安装/未启用时，相机面板的
创建/切换行整行置灰、`Set as Camera` 单独置灰，并显示一行置灰提示（原生
`Look Through` / `Lock to View` 不受影响）。

> **⚠️ 该定案已于 2026-10-16 被推翻（本节仅作考古）**：相机三算子与相机/灯光两个饼菜单已**整体迁入
> 本插件**，跨插件机制随即退役——`has_operator`、`_draw_optional_op` 置灰降级、
> `utils/blender/operator.py` 与 `CROSS_PLUGIN_OPS` 登记**全部删除**，面板改按**类引用**调用
> （规范 §8 的正常写法）。上表"留在 `ch_utils_tools`"一栏的相机三算子与 `Alt+C` 饼菜单
> 现均属本插件。迁移方案与实施记录见 [pie-menu-migration-plan.md](pie-menu-migration-plan.md)。
> **第 1 条实测事实（同名 `bl_idname` 双注册＝破坏性接管）仍然有效**，且正是本次"先删源、再落目标"
> 与"两插件同批发布"两条操作纪律的依据。

### 12.3 连带影响

> **本节记录的是 2026-10-15 分离当时的形态，其中"跨插件调用/登记/置灰降级"部分已于 2026-10-16
> 随相机三算子迁入而失效**（见 §12.2 末横幅）。下列第 1、2 条保留其**实测教训**价值；
> 当前生效形态：面板按类引用调用、无豁免登记、`CROSS_PLUGIN_OPS` 为空表。

- 层1 静态校验（`.agents/e2e/cases/static.py`）的"规范 8：UI 内禁止硬编码 `ch.*` 算子 id"
  规则本轮扩到全部插件，并为上述 4 个跨插件调用登记**显式豁免表**（不是绕过检查）。
  *（2026-10-16：该 4 条登记已删除，表本身保留为空。）*
- **降级形态（作者实测后修正）**：缺失时不能按"置灰的按钮"画——`UILayout.operator(未注册 id)`
  只打印 `unknown operator` 并**返回 `None`**，且 `enabled = False` 拦不住按钮的创建，设属性即
  `AttributeError`（首版实现如此，作者实测崩溃）。现改为按可用性**降级为同文案的置灰 `label()`
  占位**（`_draw_optional_op`），并同步加固 E2E mock：`operator()` 对未注册 id 返回 `None`，
  缺失分支断言"不创建按钮 + 画出占位标签"。教训入
  `.agents/memories/blender-api-pitfalls.md` §12。
- 顺序值键名 `ch_scene_order` 保持不变：既有 .blend 文件里的列表顺序继续生效。
- `ch_utils_tools` 必须与本次分离同步更新（它不再注册那批 `ch.*` 算子与 `ch_scene_lists`
  属性）；只装新插件而留旧 CH Custom Tools 会出现同名算子双注册。

