import bpy

from .config import __addon_name__
from .i18n.dictionary import dictionary
from ...common.class_loader import auto_load
from ...common.class_loader.auto_load import add_properties, remove_properties
from ...common.i18n.dictionary import common_dictionary
from ...common.i18n.i18n import load_dictionary
from .props import (
    AiAssistantState,
    AiCaptureParams,
    AiImageServiceState,
    AiRenderState,
    AiTextServiceState,
    AiTextureState,
    ServiceTestState,
)

# 声明式属性挂载: WM 级 AI 助手状态(脚本列表快照/输入/错误记录/纹理与效果图输入), 不随 .blend 保存;
# Scene 级通道生成参数组(随 .blend 原生保存); Image/Text 的 ch_ai_order 为**纯遮蔽注册**
# (排序值读写仍走数据块自定义属性裸通道, 与旧版同一存储; 注意 5.1.2 实测同名 RNA 与裸 idprop
# 两套存储互不互通——RNA 读恒默认值、RNA 写不落裸键, 顺序值禁走 RNA 通道读写;
# 同名运行期 RNA 仅使其不进"自定义属性"面板, 见 rna_prop_ui 对 is_runtime 同名键的 "API Defined" 过滤)
_addon_properties = {
    bpy.types.WindowManager: {
        "ch_ai_state": bpy.props.PointerProperty(type=AiAssistantState),
        "ch_ai_texture_state": bpy.props.PointerProperty(type=AiTextureState),
        "ch_ai_render_state": bpy.props.PointerProperty(type=AiRenderState),
        "ch_service_test": bpy.props.PointerProperty(type=ServiceTestState),
        "ch_ai_script_service": bpy.props.PointerProperty(type=AiTextServiceState),
        "ch_ai_chat_service": bpy.props.PointerProperty(type=AiTextServiceState),
        "ch_ai_texture_service": bpy.props.PointerProperty(type=AiImageServiceState),
        "ch_ai_render_service": bpy.props.PointerProperty(type=AiImageServiceState),
    },
    bpy.types.Scene: {
        "ch_ai_capture_params": bpy.props.PointerProperty(type=AiCaptureParams),
    },
    bpy.types.Image: {
        "ch_ai_order": bpy.props.IntProperty(),
    },
    bpy.types.Text: {
        "ch_ai_order": bpy.props.IntProperty(),
    },
}


def register():
    """
    注册插件
    """
    # Register classes
    auto_load.init()
    auto_load.register()

    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(__addon_name__))


def unregister():
    """
    注销插件
    """
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)
    # unRegister classes
    auto_load.unregister()

    remove_properties(_addon_properties)
    print("{} addon is uninstalled.".format(__addon_name__))
