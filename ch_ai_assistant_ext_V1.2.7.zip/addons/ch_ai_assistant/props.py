"""
状态属性模块

提供以下功能:
- WM 级状态属性组: 脚本列表快照, AI 输入/最近错误记录, 纯文本对话消息, 纹理与效果图输入
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot
"""

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import PropertyGroup

from ...common.blender.list_snapshot import ListItem, is_syncing
from .items import (
    CHAT_ROLE_ITEMS,
    IMAGE_LONG_EDGE,
    IMAGE_RATIOS,
    PROVIDER_MODEL_ITEMS,
    RENDER_SCALE_FACTORS,
    TEXT_PROVIDER_MODEL_ITEMS,
    TEXTURE_PRESET_LONG_EDGES,
    cryptomatte_source_items,
    depth_curve_items,
    edge_preset_items,
    generation_mode_items,
    image_size_preset_items,
    normal_convention_items,
    prefs_model_items,
    render_scale_items,
    service_mode_items,
    tex_size_preset_items,
    text_service_mode_items,
)
from .preference import (
    get_prefs,
)
from .handlers import (
    dump_image_refs,
    gallery_visible_items,
    on_chat_index_update,
    on_image_index_update,
    on_pass_index_update,
    on_ref_index_update,
    on_style_index_update,
    on_scripts_index_update,
    select_gallery_value,
    select_image_by_name,
)
from .utils.image_client import resolve_output_size, resolve_panel_image_model
from .utils.provider_registry import effective_provider, thinking_items_for


class ChatMessage(PropertyGroup):
    """单条对话消息: 角色与纯文本内容"""

    role: EnumProperty(name="Role", items=CHAT_ROLE_ITEMS, default='USER')  # type: ignore
    content: StringProperty(name="Content")  # type: ignore


class AiAssistantState(PropertyGroup):
    """AI 助手状态: 脚本列表快照与活跃索引, 描述输入, 等待进度与最近一次运行错误记录, 纯文本对话"""

    # ---- 面板级参数(脚本面板与对话面板各一份, 互不影响; 只读不写偏好, 见规范17) ----
    # 文本编辑器联动: 本面板的产物与列表中点击的条目是否自动送进文本编辑器
    use_auto_open_scripts: BoolProperty(
        name="Auto Open Scripts",
        description="Show generated, debugged and revised scripts, and the script clicked in the list, in the text editor automatically",
        default=True,
    )  # type: ignore
    use_auto_open_chat: BoolProperty(
        name="Auto Open Chat",
        description="Show the chat message clicked in the list and new replies in the text editor automatically",
        default=True,
    )  # type: ignore
    scripts: CollectionProperty(type=ListItem)  # type: ignore
    scripts_active_index: IntProperty(default=0, update=on_scripts_index_update)  # type: ignore
    prompt: StringProperty(
        name="Prompt",
        description="Describe the script you need",
    )  # type: ignore
    # ---- 每面板等待状态三件组(scope: script/chat/texture/render/test): 互斥/进度/中断按
    # scope 各自独立——同 scope 串行, 跨 scope 可并行(图像长请求不再堵住对话), 见 ai_generate
    status_script: StringProperty()  # type: ignore
    wait_script: IntProperty()  # type: ignore
    cancel_script: BoolProperty()  # type: ignore
    status_chat: StringProperty()  # type: ignore
    wait_chat: IntProperty()  # type: ignore
    cancel_chat: BoolProperty()  # type: ignore
    status_texture: StringProperty()  # type: ignore
    wait_texture: IntProperty()  # type: ignore
    cancel_texture: BoolProperty()  # type: ignore
    status_render: StringProperty()  # type: ignore
    wait_render: IntProperty()  # type: ignore
    cancel_render: BoolProperty()  # type: ignore
    status_test: StringProperty()  # type: ignore
    wait_test: IntProperty()  # type: ignore
    cancel_test: BoolProperty()  # type: ignore
    last_error_script: StringProperty()  # type: ignore
    last_error_traceback: StringProperty()  # type: ignore
    # 报错对应脚本的内容摘要: 脚本改过后不再复用旧 traceback(重捕)
    last_error_hash: StringProperty()  # type: ignore
    # 纹理与效果图面板的最近一次请求错误摘要(面板内 box 展示, 可经 ClearError 清除;
    # 记录见 ai_generate.record_request_error, <名> = 标题, <名>_detail = 错误详情)
    last_error_texture: StringProperty()  # type: ignore
    last_error_texture_detail: StringProperty()  # type: ignore
    last_error_render: StringProperty()  # type: ignore
    last_error_render_detail: StringProperty()  # type: ignore
    # 对话面板同款错误摘要(请求失败时用户消息留在历史, 面板内给一条持久的错误提示)
    last_error_chat: StringProperty()  # type: ignore
    last_error_chat_detail: StringProperty()  # type: ignore
    # 最近一次完成请求的用量(token 输入/输出计数, 形如 "1234 / 5678"), 行尾置灰展示;
    # 由 ai_generate._handle_modal 在主线程回写(记录见 format_usage). 只挂文本为主的两个面板
    # (脚本/对话)——纹理与效果图主发图像请求(无 usage), 不设该字段; 服务商不下发时为 "",
    # 面板自然跳过. 这是面板级展示值, 不随 .blend 保存
    last_usage_script: StringProperty()  # type: ignore
    last_usage_chat: StringProperty()  # type: ignore
    # 纯文本对话: 消息历史, 当前高亮消息(点击行按本面板开关转出文本编辑器)与输入框(存于 WM, 不随 .blend 保存)
    chat_messages: CollectionProperty(type=ChatMessage)  # type: ignore
    chat_active_index: IntProperty(default=0, update=on_chat_index_update)  # type: ignore
    chat_input: StringProperty(
        name="Message",
        description="What to ask the AI in plain text",
    )  # type: ignore
    # 对话下一条消息附带的脚本名(脚本列表高亮脚本, 经"附带脚本"按钮设置, 发送后清空)
    chat_script_name: StringProperty()  # type: ignore


def _on_ref_description_update(self, _context):
    """参考图描述编辑即持久化(引用列表存于 WM, 逐条描述是拼进提示词的有效载荷)"""
    if not is_syncing():
        dump_image_refs()


class AiStyleImageRef(PropertyGroup):
    """单张参考图引用(纹理面板参考图与效果图风格参考图共用): 图像数据块 + 用户描述
    (组装进提示词的职责声明); 数据块被删后按 None 处理, 描述保留"""

    image: PointerProperty(type=bpy.types.Image)  # type: ignore
    description: StringProperty(
        name="Description",
        description="What to take from this style image (colors, lighting, mood...), " "assembled into its reference role in the prompt",
        update=_on_ref_description_update,
    )  # type: ignore


def _gallery_items(self, context):
    """预览区缩略图条目: 可见条目(过滤+上限后)逐项取图像预览图标(标识 = 数据块名, 供选中回写)

    标签只放数据块名, 分辨率放悬停说明: 缩略图标签的可视宽度受缩略图宽度限制, Blender 会把
    过长标签省略号截断(实测"名 + 尺寸"拼接后长名条目只剩名称或只剩尺寸, 看起来时有时无),
    故标签保持短而完整, 分辨率走悬停提示(想整段看到名称与尺寸可把缩略图尺寸调大).
    标签与悬停说明**必须是 ASCII 且不预翻译**: 运行期拼给动态枚举的文案(含 iface/report 预翻译出的
    中文)会经 Blender 的 C 层渲染成乱码(实测 "×"/"·" 乱码,经 iface 得到的中文"分辨率"也乱码),
    故这里固定输出英文; 静态声明的枚举条目走 Blender 自己的翻译通路, 不受此限.
    预览数据块异步生成, 首帧 icon_value 为 0 时该项画空位, 下一帧重绘即出.
    """
    items = []
    for idx, item in enumerate(gallery_visible_items(self)):
        image = bpy.data.images.get(item.name)
        if image is None:
            continue
        image.preview_ensure()
        preview = image.preview
        width, height = image.size
        # 悬停说明固定英文(不翻译): 运行时拼出的动态枚举文案预翻译成中文会在 C 层渲染成乱码
        items.append((item.name, item.name, f"Resolution: {width} x {height}", preview.icon_id if preview is not None else 0, idx))
    return items


def _on_gallery_select(self, context):
    """缩略图选中某张图像: 高亮列表条目并按本面板开关切换图像编辑器(与点击列表行同款联动)"""
    if is_syncing():
        return
    select_image_by_name(context, self, self.gallery_image)


def _on_gallery_view_change(self, context):
    """过滤条件/显示上限变化: 选中值回落到可见项(护栏内写入, 不影响列表高亮与图像编辑器)

    选中项被过滤/截断掉的枚举值不在候选表内, 读回即空串(Blender 对失效动态枚举的归一化),
    缩略图选中态会悬空, 故可见项非空时回落到首项; 可见项为空(无匹配)时缩略图本就不绘制,
    保持原值, 下次过滤变化或列表同步(handlers._align_gallery_to_index)时重新回落.
    """
    visible = gallery_visible_items(self)
    if visible:
        select_gallery_value(self, visible[0].name)


def _panel_model_items(self, context):
    """面板覆盖模型下拉(按面板服务模式动态), 纹理与效果图两块下拉同规则

    Global 无服务商候选表: 给出空标识的"跟随偏好"档(动态 items 枚举不接受空串赋值,
    但空串**标识**合法), 使面板始终可解析; 覆盖模式只列该服务商候选(不接"跟随偏好"档),
    表首项即默认(枚举无 default, 取首项).
    """
    items = PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else prefs_model_items


def _reset_image_panel_models(self, _context):
    """切换图像服务模式时把覆盖模型(文生图/图像编辑两块)复位为新模式的表首项

    Global 的表只有"跟随偏好"一档, 其标识是空串而动态 items 枚举不接受空串赋值
    (赋空串必抛 TypeError), 该档下覆盖模型本就不被采用, 因此跳过赋值(见 _reset_text_panel_model).
    """
    # 两块下拉共用同一候选表(items 回调都是 _panel_model_items), 只解析一次即可;
    # 属性名仍逐一写在赋值处, 静态上照常可查"哪个字段被复位"
    items = _panel_model_items(self, _context)
    if items and items[0][0]:
        self.panel_t2i_model = items[0][0]
        self.panel_edit_model = items[0][0]


def _reset_text_panel_model(self, _context):
    """切换文本服务模式时把覆盖模型与思考档位复位到新表首项

    GLOBAL 档的表首项是"跟随偏好"哨兵(空标识), 但空标识不能赋值(动态 items 枚举不接受空串,
    赋了必抛 TypeError 且只在控制台留 traceback), 故 GLOBAL 档下跳过模型赋值 —— 该档的模型
    解析本就不看 panel_model; 覆盖模式的表首项是真实模型名, 正常赋值.
    档位标识按服务商定制且各表长度不同, 不复位会被按索引重解释到别的档(或越界读回空串导致
    档位静默不下发), 故档位仍需按新表首项复位.
    """
    provider = self.service_mode if self.service_mode != 'GLOBAL' else get_prefs().provider
    items = _panel_text_model_items(self, _context)
    if items and items[0][0]:
        self.panel_model = items[0][0]
    thinking_items = _thinking_items_for(provider)
    if thinking_items:
        self.thinking = thinking_items[0][0]


def _thinking_items_for(provider: str) -> list:
    """按服务商返回思考档位条目(DeepSeek 4 档 / GLM 3 档 / 通用 3 档), 委托注册表"""
    return list(thinking_items_for(provider))


def _text_thinking_items(self, context):
    """思考档位下拉条目: 按生效服务商(覆盖优先, 否则偏好)动态切换"""
    provider = self.service_mode if self.service_mode != 'GLOBAL' else get_prefs().provider
    return _thinking_items_for(provider)


def _panel_text_model_items(self, context):
    """文本面板覆盖模型下拉(按面板服务模式动态)

    Global 无服务商候选表: 给出空标识的"跟随偏好"档(空串**标识**合法, 空串**赋值**非法);
    覆盖模式只列该服务商候选(不接"跟随偏好"档, 与图像侧面板同规则), 表首项即默认.
    """
    items = TEXT_PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else prefs_model_items


class ServiceTestState(PropertyGroup):
    """服务连通性测试结果(最近一次, 存于 WM 供偏好面板显示)"""

    text_result: StringProperty()  # type: ignore
    text_ok: BoolProperty()  # type: ignore
    image_result: StringProperty()  # type: ignore
    image_ok: BoolProperty()  # type: ignore


class AiImageServiceState(PropertyGroup):
    """图像面板服务设置: 服务模式(全局/覆盖服务商)与覆盖模型(纹理/编辑各一)

    类定义一份, WM 上按面板各挂一个实例(ch_ai_texture_service / ch_ai_render_service),
    四个面板的服务设置互不影响.
    """

    service_mode: EnumProperty(
        name="Provider",
        description="Image service for the image assistant: Global follows the preferences, others override",
        items=service_mode_items,
        default='GLOBAL',
        update=_reset_image_panel_models,
    )  # type: ignore
    panel_t2i_model: EnumProperty(
        name="Texture & Image Generation Model",
        description="Texture generation model override",
        items=_panel_model_items,
    )  # type: ignore
    panel_edit_model: EnumProperty(
        name="Render Generation Model",
        description="Image edit model override",
        items=_panel_model_items,
    )  # type: ignore


class AiTextServiceState(PropertyGroup):
    """文本面板服务设置: 服务模式(全局/覆盖服务商)与覆盖模型

    类定义一份, WM 上按面板各挂一个实例(ch_ai_script_service / ch_ai_chat_service),
    四个面板的服务设置互不影响.
    """

    service_mode: EnumProperty(
        name="Provider",
        description="Text service for the text assistant: Global follows the preferences, others override",
        items=text_service_mode_items,
        default='GLOBAL',
        update=_reset_text_panel_model,
    )  # type: ignore
    panel_model: EnumProperty(
        name="Model",
        description="Model override for the text assistant",
        items=_panel_text_model_items,
    )  # type: ignore
    # 思考档位: 档位值即生效服务商的参数值(档位表按服务商定制)
    thinking: EnumProperty(
        name="Thinking Level",
        description="Thinking level for this panel, sent with the provider's own parameter",
        items=_text_thinking_items,
    )  # type: ignore


# 宽高联动/预设回填的递归护栏: 回填一侧宽高会触发对侧的 update, 置位期间跳过联动.
# 纹理与效果图两族 update 同为主线程回调且互不嵌套, 共用一把护栏即可
_size_syncing = False


def _size_update(fn):
    """给宽高联动 update 回调套上递归护栏(置位期间重入直接跳过, 结束必复位)"""

    def wrapper(self, context):
        global _size_syncing
        if _size_syncing:
            return
        _size_syncing = True
        try:
            fn(self, context)
        finally:
            _size_syncing = False

    return wrapper


def _tex_size_preset_items_fn(self, _context):
    """尺寸预设下拉条目: 纹理贴图模式出 1K/2K/自定义, 图像模式出常用比率/自定义"""
    return image_size_preset_items if self.generation_mode == 'PHOTO' else tex_size_preset_items


def _apply_tex_size_preset(state):
    """按当前尺寸预设回填宽高(自定义档保持现值不动)"""
    if state.generation_mode == 'TEXTURE':
        long_edge = TEXTURE_PRESET_LONG_EDGES.get(state.size_preset)
        if long_edge is not None:
            state.custom_width = long_edge
            state.custom_height = long_edge
        return
    ratio = IMAGE_RATIOS.get(state.size_preset)
    if ratio is None:
        return
    if ratio >= 1.0:
        state.custom_width = IMAGE_LONG_EDGE
        state.custom_height = max(256, min(4096, round(IMAGE_LONG_EDGE / ratio)))
    else:
        state.custom_height = IMAGE_LONG_EDGE
        state.custom_width = max(256, min(4096, round(IMAGE_LONG_EDGE * ratio)))


def _snapshot_lock_ratio(state):
    """把当前宽高比快照为锁定联动比率(锁定瞬间/预设回填后调用)"""
    state.lock_ratio = state.custom_width / max(1, state.custom_height)


@_size_update
def _on_tex_size_preset_update(self, _context):
    """切换尺寸预设: 按预设回填宽高; 比率档(非自定义)重新进入锁定态并快照比率"""
    _apply_tex_size_preset(self)
    if self.size_preset != 'CUSTOM':
        self.use_size_lock = True
    if self.use_size_lock:
        _snapshot_lock_ratio(self)


@_size_update
def _on_tex_mode_update(self, context):
    """切换生成模式(纹理贴图/图像): 尺寸预设候选表随之切换, 复位到新表首项并回到锁定态"""
    items = _tex_size_preset_items_fn(self, context)
    self.size_preset = items[0][0]
    _apply_tex_size_preset(self)
    self.use_size_lock = True
    _snapshot_lock_ratio(self)


@_size_update
def _on_tex_lock_update(self, _context):
    """切换锁定: 锁定时以当前宽高比作为联动比率; 图像模式解锁时预设档自动切到自定义"""
    if self.use_size_lock:
        _snapshot_lock_ratio(self)
    elif self.generation_mode == 'PHOTO' and self.size_preset != 'CUSTOM':
        self.size_preset = 'CUSTOM'


@_size_update
def _on_tex_width_update(self, _context):
    """手动改宽: 档位回落自定义(数值已偏离预设, 与效果图面板同款), 锁定态下高度按比率自动跟随"""
    if self.size_preset != 'CUSTOM':
        self.size_preset = 'CUSTOM'
    if self.use_size_lock and self.lock_ratio > 0:
        self.custom_height = max(256, min(4096, round(self.custom_width / self.lock_ratio)))


@_size_update
def _on_tex_height_update(self, _context):
    """手动改高: 档位回落自定义, 锁定态下宽度按比率自动跟随"""
    if self.size_preset != 'CUSTOM':
        self.size_preset = 'CUSTOM'
    if self.use_size_lock and self.lock_ratio > 0:
        self.custom_width = max(256, min(4096, round(self.custom_height * self.lock_ratio)))


# 效果图输出尺寸下限/上限(与服务商约束无关, 下发前另经 resolve_output_size 修正)
_RENDER_DIM_MIN, _RENDER_DIM_MAX = 256, 4096


def camera_ratio(context) -> float:
    """当前场景相机分辨率宽高比(场景无有效分辨率时给 1.0), 效果图比率基准"""
    rd = getattr(context.scene, "render", None) if context is not None else None
    if rd is None:
        return 1.0
    return rd.resolution_x / max(1, rd.resolution_y)


def _render_provider_model(context) -> tuple:
    """解析效果图面板当前生效的 (服务商, 编辑模型), 供缩放档回填时按服务商约束夹取

    模型取**编辑模型**(与生成操作器的 resolve_edit_model 同源同口径): 效果图走参考图
    生图, 输出尺寸约束由编辑模型决定, 取纹理模型会在两栏取值不一致时算出与实际不符的档位.
    回调期不保证窗口管理器/服务设置就绪(如后台加载), 任一步取不到即回落 ('', ''),
    此时 resolve_output_size 原样返回, 等价于不夹取(仅走本地 256-4096 兜底).
    """
    wm = getattr(context, "window_manager", None) if context is not None else None
    sstate = getattr(wm, "ch_ai_render_service", None) if wm is not None else None
    if sstate is None:
        return "", ""
    prefs = get_prefs()
    provider = effective_provider(sstate, prefs, 'image')
    model = resolve_panel_image_model(sstate, prefs, "panel_edit_model", "image_model_edit")
    return provider, model


def _apply_render_size_preset(state, context):
    """按当前分辨率档位回填宽高(自定义档保持现值不动)

    缩放档以相机分辨率长边(去百分比)为基准乘缩放倍数: 即"以相机分辨率为准, 但在其基础上缩放";
    基准长边取自 resolution_x/resolution_y(不含 resolution_percentage), 百分比只作用于输出分辨率.
    回填后**立即按服务商/模型约束夹取**(resolve_output_size), 使面板显示值即最终下发值——
    否则小档位会被服务端下限抬高(如 960x540 -> 1280x720), 大档位被上限压回(150%/200% 撞成同值),
    面板显示的宽高与实际输出对不上.
    """
    factor = RENDER_SCALE_FACTORS.get(state.size_preset)
    if factor is None:
        return
    # 缩放档换算: 相机分辨率长边(去 resolution_percentage)乘倍数, 比率取相机比率
    ratio = camera_ratio(context)
    rd = getattr(context.scene, "render", None) if context is not None else None
    long_edge = max(rd.resolution_x, rd.resolution_y) if rd is not None else 1024
    scaled = max(1, round(long_edge * factor))
    width, height = (scaled, round(scaled / ratio)) if ratio >= 1.0 else (round(scaled * ratio), scaled)
    provider, model = _render_provider_model(context)
    width, height = resolve_output_size(provider, model, width, height)
    state.custom_width = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, width))
    state.custom_height = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, height))


def _snapshot_render_lock_ratio(state, context):
    """把相机分辨率宽高比快照为锁定比率(锁定瞬间/档位回填后调用)

    比率锁定的是**相机分辨率比率**(非当前宽高之比): 缩放档只改像素不改比率,
    解锁时按当前宽高自由调整, 再锁定时重新对齐回相机比率.
    """
    state.lock_ratio = camera_ratio(context)


@_size_update
def _on_render_size_preset_update(self, context):
    """切换分辨率档位: 两种档位都按相机比率回填/对齐并保持锁定(自定义档默认也锁定)

    自定义档不再自动解锁, 而是保留锁定态并快照相机比率——用户切到自定义通常是想在
    相机比率下改像素值, 自动解锁会让宽高各自独立, 一不小心就把比率改坏.
    """
    _apply_render_size_preset(self, context)
    self.use_size_lock = True
    _snapshot_render_lock_ratio(self, context)


@_size_update
def _on_render_lock_update(self, context):
    """切换锁定: 锁定时把比率快照回相机分辨率比率; 解锁时档位自动切到自定义"""
    if self.use_size_lock:
        _snapshot_render_lock_ratio(self, context)
    elif self.size_preset != 'CUSTOM':
        self.size_preset = 'CUSTOM'


@_size_update
def _on_render_width_update(self, context):
    """手动改宽: 档位回落自定义, 锁定态下高度按相机比率自动跟随(解锁后自由调整)

    档位回落属自定义档的语义, 故先落到 CUSTOM 再把对侧按比率跟随
    (保持用户在缩放档下的数值不被回填覆盖).
    """
    if self.size_preset != 'CUSTOM':
        self.size_preset = 'CUSTOM'
    if self.use_size_lock and self.lock_ratio > 0:
        self.custom_height = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, round(self.custom_width / self.lock_ratio)))


@_size_update
def _on_render_height_update(self, context):
    """手动改高: 档位回落自定义, 锁定态下宽度按相机比率自动跟随(解锁后自由调整)"""
    if self.size_preset != 'CUSTOM':
        self.size_preset = 'CUSTOM'
    if self.use_size_lock and self.lock_ratio > 0:
        self.custom_width = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, round(self.custom_height * self.lock_ratio)))


class AiTextureState(PropertyGroup):
    """纹理生成状态: 生成模式, 提示词, 无缝平铺开关, 尺寸预设/宽高锁定, 生成张数, 参考图引用, 生成图像列表与预览区画廊开关(存于 WM, 不随 .blend 保存; 参考图引用随 AI_Image_Refs.json 文本块保存/恢复)"""

    # ---- 面板级参数(仅本面板的局部设置, 不写偏好, 见规范17) ----
    # 图像编辑器联动: 本面板的产物与列表中点击的条目是否自动送进图像编辑器
    use_auto_open_images: BoolProperty(
        name="Auto Open Images",
        description="Show the generated image and the image clicked in the list in the image editor automatically",
        default=True,
    )  # type: ignore
    # 生成模式: 纹理贴图(提示词导向材质贴图, 无缝可用) / 图像(按提示词原样生成任意图像)
    generation_mode: EnumProperty(
        name="Mode",
        description="Texture map or free image generation",
        items=generation_mode_items,
        default='TEXTURE',
        update=_on_tex_mode_update,
    )  # type: ignore
    prompt: StringProperty(
        name="Prompt",
        description="Describe the texture or image to generate",
    )  # type: ignore
    use_seamless: BoolProperty(
        name="Seamless",
        description="Make the texture tile seamlessly: stronger prompt guidance plus local edge blending",
        default=True,
    )  # type: ignore
    # 尺寸预设: 纹理贴图模式 1K/2K 方图, 图像模式常用宽高比, CUSTOM 自由输入
    size_preset: EnumProperty(
        name="Resolution",
        description="Output resolution preset: with the lock on, editing one side adjusts the other",
        items=_tex_size_preset_items_fn,
        update=_on_tex_size_preset_update,
    )  # type: ignore
    # 宽高比锁定: 锁定时调整一边另一边按锁定比率自动跟随; 解锁后自由调整
    use_size_lock: BoolProperty(
        name="Lock",
        description="Lock the width to height ratio: editing one side adjusts the other, unlock to adjust freely",
        default=True,
        update=_on_tex_lock_update,
    )  # type: ignore
    # 锁定瞬间的宽高比快照(宽/高), 锁定联动据此换算; 不入面板, 由锁定/预设回填维护
    lock_ratio: FloatProperty(
        default=1.0,
        min=1 / 16,
        max=16,
    )  # type: ignore
    # 自定义输出分辨率(像素): 下发前按服务商/模型支持的区间修正(见 image_client.resolve_output_size),
    # 实际返回分辨率以面板置灰标签为准
    custom_width: IntProperty(
        name="Width",
        description="Output width in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=256,
        max=4096,
        subtype='PIXEL',
        update=_on_tex_width_update,
    )  # type: ignore
    custom_height: IntProperty(
        name="Height",
        description="Output height in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=256,
        max=4096,
        subtype='PIXEL',
        update=_on_tex_height_update,
    )  # type: ignore
    # 一次生成的张数(逐张串行请求, 中途失败即停止), 每张单独计费
    count: IntProperty(
        name="Generation Count",
        description="How many images to generate in one run (1-5), each image is a separate billed request",
        default=1,
        min=1,
        max=5,
    )  # type: ignore
    # 批量多变体: 张数>1 时每张换一个宽高比变体与随机种, 一次产出多种构图供挑选(默认开启);
    # 随机种变体仅对支持 seed 的服务商有效, 不支持者只有比率变体(见 provider_registry.supports_seed)
    batch_variants: BoolProperty(
        name="Vary Batch",
        description="With Generation Count > 1: each image uses a different aspect-ratio variant and seed for varied compositions (seed varies only on providers that support it)",
        default=True,
    )  # type: ignore
    # 负向提示词: 描述画面中不想出现的内容(仅百炼 Qwen-Image 支持, 其余服务商置灰不下发)
    negative_prompt: StringProperty(
        name="Negative Prompt",
        description="Content to avoid in the image, sent to providers that support it (Alibaba DashScope only); more than 500 characters is truncated by the server",
    )  # type: ignore
    # 随机种: 0 = 每次随机; 非 0 可复现同一次生成(复现满意的纹理后调尺寸重出)
    seed: IntProperty(
        name="Seed",
        description="Random seed: 0 randomizes each run, a fixed value reproduces the same result",
        default=0,
        min=0,
        max=2147483647,
    )  # type: ignore
    # 生成图像列表快照(实时同步见 handlers), 点击行把图像编辑器切换到对应图像
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_image_index_update)  # type: ignore
    # ---- 参考图生成: 加载外部图片 + 描述, 随描述一起送编辑模型做参考图生图 ----
    # 引用集合存于 WM, 随 AI_Image_Refs.json 文本块保存/恢复(与效果图风格参考图同一文件)
    use_ref_images: BoolProperty(
        name="Use References",
        description="Send the loaded reference images with the prompt: reference-to-image " "generation while on, off keeps plain text-to-image",
        default=False,
    )  # type: ignore
    ref_images: CollectionProperty(type=AiStyleImageRef)  # type: ignore
    # 点击行按本面板开关把图像编辑器切换到该参考图(与效果图风格参考图迷你列表同款)
    ref_images_active_index: IntProperty(default=0, update=on_ref_index_update)  # type: ignore
    # 预览区缩略图控件: 缩略图尺寸与名称标签(画廊图标视图的显示参数)
    gallery_scale: FloatProperty(
        name="Thumbnail Size",
        description="Size of the thumbnails in the preview area",
        default=6.0,
        min=2.0,
        max=16.0,
        precision=1,
    )  # type: ignore
    gallery_labels: BoolProperty(
        name="Labels",
        description="Show the image name and pixel size under each thumbnail",
        default=True,
    )  # type: ignore
    gallery_filter: StringProperty(
        name="Name Filter",
        description="Show only thumbnails whose name contains this text",
        update=_on_gallery_view_change,
    )  # type: ignore
    gallery_limit: IntProperty(
        name="Max Shown",
        description="Maximum number of thumbnails shown, 0 shows every matching image",
        default=12,
        min=0,
        max=200,
        update=_on_gallery_view_change,
    )  # type: ignore
    # 控件子面板展开开关: 缩略图控件收在缩略图下方, 默认收起(留白给缩略图)
    use_show_controls: BoolProperty(
        name="Thumbnail Controls",
        description="Show the thumbnail size, label, filter and count controls",
        default=False,
    )  # type: ignore
    # 生成参数小节展开开关: 参数收在预览区之后的折叠小节里(原为独立子面板), 默认收起
    use_show_settings: BoolProperty(
        name="Generation Settings",
        description="Show the resolution, seed, count and seamless settings",
        default=False,
    )  # type: ignore
    gallery_image: EnumProperty(
        name="Gallery",
        description="Click a thumbnail to highlight that image in the list and show it in the image editor",
        items=_gallery_items,
        update=_on_gallery_select,
    )  # type: ignore


class AiPassPreset(PropertyGroup):
    """效果图通道组合预设: 名称 + 捕获/发送两组通道开关的快照(存于面板状态, 不写偏好)"""

    use_combined: BoolProperty(default=True)  # type: ignore
    use_depth: BoolProperty(default=True)  # type: ignore
    use_normal: BoolProperty()  # type: ignore
    use_segmentation: BoolProperty()  # type: ignore
    use_edge: BoolProperty()  # type: ignore
    use_diffuse: BoolProperty()  # type: ignore
    use_ao: BoolProperty()  # type: ignore
    use_send_combined: BoolProperty(default=True)  # type: ignore
    use_send_depth: BoolProperty(default=True)  # type: ignore
    use_send_normal: BoolProperty()  # type: ignore
    use_send_segmentation: BoolProperty()  # type: ignore
    use_send_edge: BoolProperty()  # type: ignore
    use_send_diffuse: BoolProperty()  # type: ignore
    use_send_ao: BoolProperty()  # type: ignore


def _pass_preset_items(self, _context):
    """通道组合预设下拉条目: 预设名为标识与标签(用户可在保存时命名), 空表给占位档"""
    if not self.pass_presets:
        return [('NONE', "No presets", "Save the current pass toggles as a preset first")]
    return [(p.name, p.name, "Apply this pass preset") for p in self.pass_presets]


class AiCaptureParams(PropertyGroup):
    """通道生成参数(场景级): 挂 bpy.types.Scene 的 ch_ai_capture_params, 随 .blend 原生保存

    挂场景而非 WM: 捕获参数与场景内容一一对应, 多场景文件各自独立. 同名运行期 RNA
    使底层 idprop 不出现在"自定义属性"面板(rna_prop_ui 对 is_runtime 同名键按
    "API Defined" 过滤; 开发者界面开启时仍可见但只读). 旧版存为场景自定义属性
    裸字典(枚举=字符串, 与 RNA 底层的 int 存储类型不合, 包装器不收养), 载入时经
    handlers.migrate_legacy_capture_params 读裸值经 RNA 重赋值归一.
    """

    # AO 遮蔽距离: 落在临时场景视图层的 eevee.ambient_occlusion_distance(5.1 实证属性在视图层
    # 而非场景, 控制多远内的物体参与遮蔽计算, 对 AO 通道同样生效)
    ao_distance: FloatProperty(
        name="Occlusion Distance",
        description="Distance of objects that contribute to the AO pass, in scene units",
        default=1.0,
        min=0.0,
        soft_max=100.0,
        unit='LENGTH',
    )  # type: ignore
    # 渲染采样数: 落到临时场景的 eevee.taa_render_samples(原为硬编码 16). 它直接决定
    # 抗锯齿与噪点水平(合并结果/漫射/AO 最敏感); 两组渲染都用同一个采样数, 故进两组渲染键
    render_samples: IntProperty(
        name="Samples",
        description="Render samples per pixel: higher values smooth edges and reduce noise, " "at the cost of render time",
        default=16,
        min=1,
        max=512,
        soft_max=64,
    )  # type: ignore
    # 语义分割依据: Cryptomatte 的三种 ID 通道(物体/材质/资产), 决定分割图按什么分块.
    # 属**渲染参数**(开哪条 pass 不同), 故进主组渲染键.
    # 出厂默认按物体: 名字表即场景物体名, 被渲到的物体必然命中, 不会出现"有覆盖却无名"的黑块;
    # 选**材质**分块时同材质的多个物体同色(更贴合材质语义), 代价是**没有材质的物体**匹配不到
    # 名字而保持黑色(此时有未解析占比提示). 该默认与通道捕获的 CRYPTO_SOURCE_DEFAULT 同口径
    # (utils/pass_capture/_constants.py)
    cryptomatte_source: EnumProperty(
        name="Segmentation Source",
        description="Which Cryptomatte ID channel drives the semantic segmentation map",
        items=cryptomatte_source_items,
        default='OBJECT',
    )  # type: ignore
    # Cryptomatte 落盘层数: 一层装两个对象槽位, 故 N 层可解析每像素 2N 个重叠物体.
    # 层数越多越不会在重叠处取错对象; 代价是每层一张 32bit EXR(2048² 约 67 MB), 落盘量随层数线性增长
    crypto_slots: IntProperty(
        name="Overlap Layers",
        description="How many Cryptomatte layers to write: each layer resolves two overlapping " "objects per pixel, and costs one 32-bit EXR of temporary disk space",
        default=3,
        min=1,
        max=3,
    )  # type: ignore
    # 分割边缘抗锯齿: 关闭(出厂)时每个像素取覆盖率最大对象的**纯色**, 色块边界是台阶;
    # 打开后按覆盖率把相邻对象色加权平均, 边界随之平滑 —— 代价是出现不属于任何单个对象的
    # 过渡色(与旧"材质覆盖"方案由渲染器抗锯齿得到的效果等价).
    # 属**解码参数**(只影响解码, 不影响渲染), 故**不进渲染键**: 切换它只重解码, 不会重渲.
    smooth_seg_edges: BoolProperty(
        name="Antialias Edges",
        description="Blend neighbouring object colors along segmentation boundaries instead of " "switching abruptly: smoother edges, at the cost of boundary colors that " "belong to no single object",
        default=False,
    )  # type: ignore
    # 深度映射区间(场景单位): 深度通道为米制视空间 Z(背景为相机裁剪终点), 按用户区间线性映射 近端->白 远端->黑;
    # 二元向量属性(近, 远)保证面板单行双值与参数框其它行同用 property split 机制对齐
    depth_range: FloatVectorProperty(
        name="Depth Range",
        description="Scene-space distances (near, far) that map the depth pass to white and black",
        size=2,
        subtype='XYZ_LENGTH',
        default=(1.0, 20.0),
        min=0.0,
        soft_max=1000.0,
        unit='LENGTH',
    )  # type: ignore
    # 深度 8bit 量化曲线: 反深度(视差)把灰阶向近场集中, 主体景深细节保留最多(默认档,
    # 256 级按 1/z 分布, 与 ControlNet/MiDaS 深度惯例一致); 线性均分灰阶为备选
    depth_curve: EnumProperty(
        name="Depth Curve",
        description="Mapping curve of the depth pass: inverse depth concentrates gray levels " "on the near field, linear spreads them evenly",
        items=depth_curve_items,
        default='INVERSE',
    )  # type: ignore
    # 法向约定: Blender 自身遵循 OpenGL(绿通道 Y 向上, 5.0 源码 Normal Map 节点枚举证实),
    # DirectX 约定绿通道向下, 导出时反转绿通道
    normal_convention: EnumProperty(
        name="Convention",
        description="Green channel direction of the normal map: OpenGL points up, DirectX points down",
        items=normal_convention_items,
        default='OPENGL',
    )  # type: ignore
    # 线稿宽度系数: 线宽为通道捕获侧的固定基准 radius(_EDGE_RADIUS_FALLBACK,
    # 见 utils/pass_capture/_constants.py)乘该系数
    # (标签原文带 Scale 以与"线宽"本身区分, 入典出"线宽系数")
    edge_width_scale: FloatProperty(
        name="Line Width Scale",
        description="Scale factor for the line art width",
        default=1.0,
        min=0.01,
        max=10.0,
    )  # type: ignore
    # 线稿预设: 一组线条类型开关打包成一个下拉(逐项铺开会占掉半屏).
    # 属**渲染参数**(改变线稿组渲染结果), 故进线稿组渲染键: 换档只重渲线稿组
    edge_preset: EnumProperty(
        name="Line Art Preset",
        description="Which kinds of lines the line art pass draws",
        items=edge_preset_items,
        default='STANDARD',
    )  # type: ignore
    # 线稿材质边界: 对应 Lineart 修改器的 use_material("Material Borders", 系统词条),
    # 控制材质之间是否生成笔画(默认关, 与修改器出厂默认一致)
    use_material_borders: BoolProperty(
        name="Material Borders",
        description="Generate line art strokes between different materials",
        default=False,
    )  # type: ignore


class AiRenderState(PropertyGroup):
    """效果图生成状态: 提示词, 参考通道捕获勾选与发送开关, 通道输出分辨率钳制, 输出分辨率(缩放档/自定义, 比率锁相机), 生成张数与批量多变体(存于 WM, 不随 .blend 保存; 通道生成参数存场景挂载的 RNA 组
    ch_ai_capture_params, 随 blend 原生保存, 见 AiCaptureParams)"""

    # ---- 面板级参数(仅本面板的局部设置, 不写偏好, 见规范17) ----
    # 通道组合预设(捕获/发送两组开关的命名快照)与图像编辑器联动开关
    pass_presets: CollectionProperty(type=AiPassPreset)  # type: ignore
    pass_preset_choice: EnumProperty(
        name="Pass Preset",
        description="Saved pass toggle combinations, apply one to both capture and send toggles",
        items=_pass_preset_items,
    )  # type: ignore
    use_auto_open_images: BoolProperty(
        name="Auto Open Images",
        description="Show the generated image and the image clicked in the list in the image editor automatically",
        default=True,
    )  # type: ignore
    prompt: StringProperty(
        name="Prompt",
        description="Describe the look of the concept render",
    )  # type: ignore
    # 参考通道勾选(面板顺序即需求通道序: 合并结果/深度/法向/语义分割/线稿/漫射颜色/AO);
    # 七通道一律由 EEVEE 出(合并结果/深度/法向/漫射颜色/AO 共享一帧, 语义分割与线稿各一帧),
    # 面板不再有捕获引擎选项;
    # 生成请求必须包含 Combined;
    # "Line Drawing"为避开系统词条 "Lines"(线) 的改写原文, 入典出"线稿"
    use_combined: BoolProperty(
        name="Combined Result",
        description="Capture the combined render as a reference image",
        default=True,
    )  # type: ignore
    use_depth: BoolProperty(
        name="Depth",
        description="Capture the depth pass as a reference image (foreground white, background black)",
        default=True,
    )  # type: ignore
    use_normal: BoolProperty(
        name="Normal",
        description="Capture the normal pass as a reference image",
        default=False,
    )  # type: ignore
    use_segmentation: BoolProperty(
        name="Semantic Segmentation",
        description="Capture the object segmentation pass as a reference image (a unique color per object)",
        default=False,
    )  # type: ignore
    use_edge: BoolProperty(
        name="Line Drawing",
        description="Capture the scene grease pencil line art as a reference image",
        default=False,
    )  # type: ignore
    use_diffuse: BoolProperty(
        name="Diffuse Color",
        description="Capture the diffuse color pass as a reference image",
        default=False,
    )  # type: ignore
    use_ao: BoolProperty(
        name="AO",
        description="Capture the ambient occlusion pass as a reference image",
        default=False,
    )  # type: ignore
    # 通道输出分辨率钳制(仅开关, 无输入框): 关闭时直接用 Blender 输出分辨率(乘 Resolution Scale);
    # 打开后仅在最长边超出**当前服务商**的参考图上传上限时按分辨率百分比等比下调(宽高比不变,
    # 见 utils/pass_capture/_size.py 的 resolve_capture_size), 上限取偏好设置里的参考图最长边
    use_clamp_resolution: BoolProperty(
        name="Clamp Output Resolution",
        description="Limit the captured pass resolution to the reference image limit of the current " "provider: the longest edge is scaled down proportionally only when it exceeds it",
        default=False,
    )  # type: ignore
    # 输出分辨率档位: 缩放档(相机分辨率长边乘百分比) / 自定义(自由输入宽高);
    # 宽高比率恒锁相机分辨率比率, 与纹理面板的属性名统一为 Resolution
    size_preset: EnumProperty(
        name="Resolution",
        description="Output resolution: scale of the camera resolution, or free width and height in pixels",
        items=render_scale_items,
        default='100',
        update=_on_render_size_preset_update,
    )  # type: ignore
    # 宽高比锁定: 锁定(默认)时宽高恒等于相机分辨率比率, 调整一边另一边自动跟随; 解锁后可自由调整
    use_size_lock: BoolProperty(
        name="Lock",
        description="Lock the width to height ratio to the camera resolution: editing one side adjusts the other",
        default=True,
        update=_on_render_lock_update,
    )  # type: ignore
    # 锁定瞬间的相机分辨率宽高比快照(宽/高), 锁定联动据此换算; 不入面板
    lock_ratio: FloatProperty(
        default=1.0,
        min=1 / 16,
        max=16,
    )  # type: ignore
    # 自定义输出分辨率(像素): 下发前按服务商/模型支持的区间修正(见 image_client.resolve_output_size),
    # 实际返回分辨率以面板置灰标签为准
    custom_width: IntProperty(
        name="Width",
        description="Output width in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=_RENDER_DIM_MIN,
        max=_RENDER_DIM_MAX,
        subtype='PIXEL',
        update=_on_render_width_update,
    )  # type: ignore
    custom_height: IntProperty(
        name="Height",
        description="Output height in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=_RENDER_DIM_MIN,
        max=_RENDER_DIM_MAX,
        subtype='PIXEL',
        update=_on_render_height_update,
    )  # type: ignore
    # 随机种: 0 = 每次随机; 非 0 可复现同一次生成
    seed: IntProperty(
        name="Seed",
        description="Random seed: 0 randomizes each run, a fixed value reproduces the same result",
        default=0,
        min=0,
        max=2147483647,
    )  # type: ignore
    # 一次生成的张数(逐张串行请求, 中途失败即停止), 每张单独计费
    count: IntProperty(
        name="Generation Count",
        description="How many images to generate in one run (1-5), each image is a separate billed request",
        default=1,
        min=1,
        max=5,
    )  # type: ignore
    # 批量多变体: 张数>1 时每张换一个宽高比变体与随机种, 一次产出多种构图供挑选(默认开启);
    # 随机种变体仅对支持 seed 的服务商有效, 不支持者只有比率变体(见 provider_registry.supports_seed)
    batch_variants: BoolProperty(
        name="Vary Batch",
        description="With Generation Count > 1: each image uses a different aspect-ratio variant and seed for varied compositions (seed varies only on providers that support it)",
        default=True,
    )  # type: ignore
    # 负向提示: 描述画面中不想出现的内容(仅百炼 Qwen-Image 支持, 其余服务商不下发)
    negative_prompt: StringProperty(
        name="Negative Prompt",
        description="Content to avoid in the image, sent to providers that support it (Alibaba DashScope only); more than 500 characters is truncated by the server",
    )  # type: ignore
    # ---- 发送通道开关(与捕获勾选独立): Generate Render 发送哪些已捕获的通道图 ----
    # 捕获勾选只控制"生成通道"按钮捕获哪些; 发送开关独立勾选, 支持多捕获/挑着发;
    # 出厂与捕获勾选一致(Combined/Depth 开), 勾选但未捕获的通道在生成时报"请先生成通道"
    use_send_combined: BoolProperty(
        name="Combined Result",
        description="Send the captured combined render to the AI as a reference image",
        default=True,
    )  # type: ignore
    use_send_depth: BoolProperty(
        name="Depth",
        description="Send the captured depth pass to the AI as a reference image",
        default=True,
    )  # type: ignore
    use_send_normal: BoolProperty(
        name="Normal",
        description="Send the captured normal pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_segmentation: BoolProperty(
        name="Semantic Segmentation",
        description="Send the captured segmentation pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_edge: BoolProperty(
        name="Line Drawing",
        description="Send the captured line art pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_diffuse: BoolProperty(
        name="Diffuse Color",
        description="Send the captured diffuse color pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_ao: BoolProperty(
        name="AO",
        description="Send the captured ambient occlusion pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    # 风格参考图发送开关: 关闭时风格图不发送也不占参考图名额(列表仅作暂存)
    use_send_style: BoolProperty(
        name="Use Style References",
        description="Send the style reference images to the AI as references, after the captured passes",
        default=False,
    )  # type: ignore
    # ---- 风格参考图(多张): 排在通道图之后发送, 每张占一个参考图预算名额 ----
    # 经"加载风格图"从磁盘载入(或引用 blend 里已有数据块); 存于 WM, 不随 .blend 保存
    # 风格参考图列表(手绘迷你列表, 点击行聚焦图像编辑器并切换描述行)
    style_images: CollectionProperty(type=AiStyleImageRef)  # type: ignore
    style_images_active_index: IntProperty(default=0, update=on_style_index_update)  # type: ignore
    # 捕获预览与生成结果列表快照(实时同步见 handlers), 点击行把图像编辑器切换到对应图像;
    # 主列表只含生成结果(AI Render 前缀), 通道预览图走独立的迷你列表快照(见下)
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_image_index_update)  # type: ignore
    # 通道预览迷你列表快照(固定名捕获预览 AI Ref: 前缀): 回看入口, 点击行按本面板开关聚焦图像编辑器
    pass_images: CollectionProperty(type=ListItem)  # type: ignore
    pass_images_active_index: IntProperty(default=0, update=on_pass_index_update)  # type: ignore
    # 预览区缩略图控件(同纹理状态): 生成结果与参考通道捕获图共用同一套显示参数
    gallery_scale: FloatProperty(
        name="Thumbnail Size",
        description="Size of the thumbnails in the preview area",
        default=6.0,
        min=2.0,
        max=16.0,
        precision=1,
    )  # type: ignore
    gallery_labels: BoolProperty(
        name="Labels",
        description="Show the image name and pixel size under each thumbnail",
        default=True,
    )  # type: ignore
    gallery_filter: StringProperty(
        name="Name Filter",
        description="Show only thumbnails whose name contains this text",
        update=_on_gallery_view_change,
    )  # type: ignore
    gallery_limit: IntProperty(
        name="Max Shown",
        description="Maximum number of thumbnails shown, 0 shows every matching image",
        default=12,
        min=0,
        max=200,
        update=_on_gallery_view_change,
    )  # type: ignore
    # 控件子面板展开开关: 缩略图控件收在缩略图下方, 默认收起(留白给缩略图)
    use_show_controls: BoolProperty(
        name="Thumbnail Controls",
        description="Show the thumbnail size, label, filter and count controls",
        default=False,
    )  # type: ignore
    # 生成通道小节展开开关: 通道勾选与通道参数, 生成通道按钮收在预览区之后的折叠小节里, 默认收起
    use_show_passes: BoolProperty(
        name="Passes",
        description="Show the reference pass toggles, their parameters and the capture button",
        default=False,
    )  # type: ignore
    # 生成参数小节展开开关: 输出分辨率/随机种/张数等收在预览区之后的折叠小节里, 默认收起
    use_show_settings: BoolProperty(
        name="Generation Settings",
        description="Show the resolution, seed and count settings",
        default=False,
    )  # type: ignore
    gallery_image: EnumProperty(
        name="Gallery",
        description="Click a thumbnail to highlight that image in the list and show it in the image editor",
        items=_gallery_items,
        update=_on_gallery_select,
    )  # type: ignore
