# 服务商扩展 Checklist

> **加商防遗漏底稿**。服务商知识**唯一来源**是 `utils/provider_registry.py`（每条服务商一条 dataclass
> 记录）；本文件只回答两件事：**改哪里**、**别漏什么**。字段取值以该文件为准，下表列出仅为加商时逐项对照。
> 漏任何一项的症状都是「该服务商在偏好里可选，但某个参数 / 限制 / 行为错乱」的隐性 bug。

- **图像服务商**：火山方舟（Volcengine Ark）、阿里百炼（Alibaba DashScope）、自定义（Custom）
- **文本服务商**：DeepSeek、智谱 GLM、自定义（Custom）

---

## 一、加商 = 改 2 处

### 图像服务商 X

1. `utils/provider_registry.py`：加一组 `*_items` 枚举字面量（`x_provider_item` + `x_t2i_items`，
   **必须保持 List 字面量形态**供 i18n 提取），再加一条 `ImageProvider(...)` 到 `IMAGE_PROVIDERS`
2. 若 `api_key_attr` 指向新密钥字段：`preference.py` 补一个 `StringProperty(subtype='PASSWORD')`

### 文本服务商 X

1. `utils/provider_registry.py`：加一组 `*_items` 字面量（枚举档 + 候选模型 + 思考档，均 List 形态），
   再加一条 `TextProvider(...)` 到 `TEXT_PROVIDERS`
2. 同上：新密钥字段需在 `preference.py` 声明

> 其余代码（偏好预设回填、面板覆盖下拉、生效模型兜底链、请求分发）均按注册表自动生效，不要另开分支。

## 二、字段全表

**`ImageProvider`**（`get_image_provider(key)` 取，未知回落 `CUSTOM` 不臆断限制）

| 字段 | 含义 | 方舟 | 百炼 | 自定义 |
| --- | --- | --- | --- | --- |
| `base_url` | 端点 | `https://ark.cn-beijing.volces.com/api/v3` | `https://dashscope.aliyuncs.com/api/v1` | 空（走偏好手填） |
| `api_key_attr` | 偏好密钥属性名 | `volcengine_api_key` | `dashscope_api_key` | `image_api_key` |
| `default_model_t2i` / `_edit` | 出厂默认（**两字段分离**，见坑 4） | `doubao-seedream-5-0-flash-260915` | `qwen-image-3.0` | 空 |
| `ref_count` / `ref_edge` | 参考图张数 / 最长边（0 = 不限） | 10 / 6000 | 3 / 3072 | 0 / 0 |
| `token_budget` / `token_hard` | 提示词预算 / 是否硬截断 | 600 / 否 | 800 / 是 | 0 / 否 |
| `resolve_size` | 尺寸修正回调 `(model, w, h)` | `_resolve_seedream_size`（取偶） | `_resolve_qwen_size`（对齐 16） | 原样下发 |
| `size_sep` | 尺寸串分隔符 | `x` | `*` | `x` |
| `output_limits` | 面板提醒用（**取该商最严格模型**） | Seedream 各档汇总 | Qwen 各档汇总 | `None` |
| `endpoint_path` | 请求路径后缀 | `/images/generations` | `/services/aigc/multimodal-generation/generation` | `/images/generations` |
| `build_payload` | 请求体构造（**承载自定义商的负向剔除**，见坑 1） | `_volcengine_payload` | `_dashscope_payload` | `_custom_payload` |
| `parse_response` | 响应解析 | `_extract_item_image` | `_extract_dashscope_image` | `_extract_item_image` |
| `supports_negative_prompt` | 负向提示 | 否 | **是** | 否 |
| `supports_seed` | 随机种 | 否（4.0 起移除该参数） | **是** | 否 |
| `supports_watermark` / `_response_format` | **无消费点**（仅文档性） | — | — | — |

**`TextProvider`**（`get_text_provider(key)` 取，未知返回 `None` 走通用兜底）

| 字段 | 含义 | DeepSeek | GLM | 兜底 |
| --- | --- | --- | --- | --- |
| `base_url` | 端点 | `https://api.deepseek.com` | `https://open.bigmodel.cn/api/paas/v4` | 偏好手填 |
| `default_model` | 出厂默认（轻量档） | `deepseek-flash` | `glm-5.3-flash` | — |
| `thinking_items` | 思考档位表（档位标识即下发参数值） | Off / Low / High / Highest | Low / High / Highest | `DEFAULT_THINKING_ITEMS` |
| `build_thinking_extras` | 档位 → 请求参数 | `_deepseek_thinking_extras`（off→disabled，其余 enabled） | `_glm_thinking_extras`（恒 enabled） | 仅 `reasoning_effort` |
| `script_max_tokens` | 脚本输出额度 | `None`（用服务端默认） | 65536 | 8192 |
| `test_strategy` | 连通性测试 | `balance`（查余额，免费） | `ping`（`max_tokens=16`） | `ping` |

## 三、行为差异（加商时逐项核对）

1. **接入层**：端点 / 密钥 / 默认模型 / 候选模型 / 枚举档显示名——全部落在注册表与 `items.py` 的
   `*_items` 引用上，无第二处
2. **请求体**：`response_format`（方舟、自定义有，百炼无）、`watermark`（两家有、自定义剔除）、
   `seed`（**仅百炼下发**）、`negative_prompt`（**仅百炼**，且「不下发」而非传空串）
3. **响应与下载**：百炼只回 URL（**24h 有效，必须下载**），方舟回 b64
4. **输出尺寸**：**总像素是模型级差异**（Seedream 4.0 / 4.5 / 5.0-lite / 5.0-pro 各不同），
   故 `resolve_size` 必须是回调；`qwen-image-max/plus` 只有 5 档固定值（`_QWEN_PRESETS`）
5. **参考图**：方舟**按模型分档**（5.0 pro/flash = 10，lite/4.5/4.0 = 14）；当前候选表只含 pro/flash
   故 `ref_count` 取单值 10——**纳入 lite 等档位时须照 `resolve_size` 先例改模型级回调**。
   偏好里的「参考图张数 / 最长边」填 0 = 跟随官方上限
6. **提示词预算**：百炼超预算**静默截断**（自动降精简档），方舟仅软建议不截断
7. **偏好联动**：预设回填端点与默认模型、密钥显示分支按 `api_key_attr` 查表、**切换商时参考图两项清零**
8. **面板覆盖层**：候选下拉 `props._panel_model_items`（文生图 / 图生图共用同一 `items` 回调）、
   切商复位表首项；生效模型兜底链**单一口** `image_client.resolve_panel_image_model`
   （两个薄封装只承载"读哪个字段"：纹理读 `panel_t2i_model`、效果图读 `panel_edit_model`）；
   生效服务商解析单一口 `provider_registry.effective_provider(state, prefs, kind)`

## 四、四个关键坑

1. **自定义商是「少传」不是「多传」**——`response_format` / `watermark` / `seed` 要显式剔除。
   只按「正向下发」设计必然漏掉负向剔除
2. **模型级差异不能压成服务商级**——总像素、参考图张数都有按模型分档的商；压平即丢失细分，
   故 `resolve_size` 保留为函数回调
3. **能力开关必须有消费点才生效**——`supports_negative_prompt`（请求侧 `image_common.effective_negative_prompt`
   单口 + UI 侧 `blocks.draw_negative_row`）与 `supports_seed`（面板种子行 + `image_common.effective_seed`）
   有真实读取方；`supports_watermark` / `supports_response_format` **暂无消费点**，改它们不改变请求体
   （行为硬编码在 `build_payload` 里）。加能力位时**必须同时接上消费点**，否则「改了没反应」
4. **思考档位标识必须两处一致**——`thinking_items` 的档位标识既是下拉值、又是 `reasoning_effort`
   的参数值，故两处合并在 `TextProvider` 的 `thinking_items` + `build_thinking_extras` 单字段对，
   不再各自维护分支

## 五、加商后自检

1. `python .agents/tools/gate.py`（动了 RNA 声明必须全量档）
2. `python .agents/tools/check/i18n_sweep.py ch_ai_assistant` 与 `i18n_check_terms.py`——
   新枚举档 / 候选模型的中文词条补齐，**系统词条不入典**
3. 作者热重载实测：偏好下拉可选、覆盖下拉可选、切商回填正确、负向提示与种子行按能力位显隐
