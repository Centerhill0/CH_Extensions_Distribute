"""
效果图发送集组装与通道缓存模块

两步工作流的"发送侧"基础设施, 供效果图面板的捕获与生成算子共用:
- 通道捕获缓存(发送字节的权威源)与捕获参数指纹: 捕获写入, 发送时比对(过期只提示不阻断);
  本模块是这两个模块级状态的**唯一属主**, 写入一律经 store_capture()——写作方若在别处
  用 global 重绑定, 读方将永远看到旧值(静默失效, 无报错);
- 通道标题/开关表/预览图读写/可用性判定/发送集组装(resolve_render_request, 与提示词预览
  共用同一函数保证"预览即发送")与参考图限制截断;
- 通道预览图的 "_bak" 备份清理(ClearPassBackups).

**本模块是 `_PASS_CAPTURE_CACHE` 与 `_CAPTURE_FINGERPRINT` 的唯一属主**:
外部只经 store_capture() / clear_pass_cache() 写入, 不得直接赋值.
"""

import bpy


from bpy.types import Context
from bpy.types import Operator


from ....common.i18n.i18n import report


from ..utils import AI_REF_PREFIX
from ..utils import PASS_ORDER
from ..utils import PassCaptureSession
from ..utils import api_error
from ..utils import clear_raw_cache
from .image_common import collect_ref_entries
from .image_common import count_unavailable_refs
from ..utils import estimate_prompt_tokens
from ..utils import image_to_png_bytes
from ..utils import load_image_from_bytes
from ..utils import prompt_token_budget
from .image_common import prune_image_backups
from ..utils import resolve_capture_size
from .image_common import resolve_image_service
from ..utils import resolve_ref_limits
from ..utils import resolve_render_prompt
from ..utils import scene_content_key
from ..handlers import sync_images_now

_PASS_TITLES = {
    'combined': "Combined Result",
    'depth': "Depth",
    'normal': "Normal",
    'segmentation': "Semantic Segmentation",
    'edge': "Line Drawing",
    'diffuse': "Diffuse Color",
    'ao': "AO",
}


# 通道域自检: 预览标题与捕获/发送开关两表都按 PASS_ORDER 逐通道声明,
# 加删通道时漏改会让该通道静默失去预览名(回落 capitalize)或失去开关, 故断言钉死.
def _check_pass_domain() -> None:
    """通道域自检(import 期执行一次): 预览标题必须与 PASS_ORDER 同域

    与 utils/prompts.py,utils/pass_capture/_constants.py 的两处同类自检同款
    (显式 raise 而非裸 assert: 语义更明确, 也与既有 _check_contract 先例一致).
    """
    if set(_PASS_TITLES) != set(PASS_ORDER):
        raise AssertionError(f"_PASS_TITLES 与 PASS_ORDER 键集不一致: " f"缺 {set(PASS_ORDER) - set(_PASS_TITLES)}, " f"多 {set(_PASS_TITLES) - set(PASS_ORDER)}")


_check_pass_domain()


def _pass_title(name: str) -> str:
    """通道键转预览标题, 未知键回落 capitalize 兜底"""
    return _PASS_TITLES.get(name, name.capitalize())


def _write_preview_image(op, name: str, image_bytes: bytes) -> tuple:
    """把通道图写为固定名预览图像数据块, 返回 (Image 数据块, 错误信息)

    上一轮的预览图不删除而是改名加 "_bak" 后缀保留(与"修改效果图"对原图的处理一致),
    超出偏好份数的最旧备份随即清理; 重名由 Blender 自动加序号, 新图取回原名.
    """
    datablock_name = f"AI Ref: {_pass_title(name)}"
    old = bpy.data.images.get(datablock_name)
    if old is not None:
        old.name = f"{datablock_name}_bak"
        prune_image_backups(op, datablock_name, old.name)
    return load_image_from_bytes(image_bytes, datablock_name)


def _resolve_service(sstate, prefs) -> tuple:
    """解析生效图像服务与参考图限制, 返回 (服务商, base_url, api_key, (张数上限, 最长边上限))

    服务商取自共享服务设置(Global 档跟随偏好), 与生成操作器同源;
    限制取偏好的参考图自定义值(仅对偏好中的服务商生效), 面板的"钳制输出分辨率"与
    参考图张数截断共用本结果.
    """
    provider, base_url, api_key = resolve_image_service(sstate, prefs)
    return (provider, base_url, api_key, resolve_ref_limits(provider, prefs))


def _build_capture_session(context: Context, rstate, wanted: dict, limits: tuple):
    """按面板状态组装通道捕获会话(execute 直调与 invoke 模态两条路径共用)

    通道生成参数取场景挂载的 RNA 组(ch_ai_capture_params), 面板状态组只贡献
    通道勾选与分辨率钳制开关; 全部在此一次性快照进会话, 不受等待期面板改动影响.
    """
    cstate = context.scene.ch_ai_capture_params
    return PassCaptureSession(
        context.scene,
        wanted,
        ao_distance=cstate.ao_distance,
        depth_near=cstate.depth_range[0],
        depth_far=cstate.depth_range[1],
        depth_curve=cstate.depth_curve,
        normal_convention=cstate.normal_convention,
        edge_width_scale=cstate.edge_width_scale,
        material_borders=cstate.use_material_borders,
        edge_preset=cstate.edge_preset,
        clamp_long_edge=_clamp_edge(rstate, limits[1]),
        render_samples=cstate.render_samples,
        crypto_source=cstate.cryptomatte_source,
        crypto_slots=cstate.crypto_slots,
        smooth_seg_edges=cstate.smooth_seg_edges,
    )


def _clamp_edge(rstate, limit_edge: int) -> int:
    """按钳制开关解析本次渲染的长边上限(开关关闭或上限为 0 时不钳制)"""
    return limit_edge if rstate.use_clamp_resolution else 0


_PASS_TOGGLES = tuple((f"use_{key}", key) for key in PASS_ORDER)


_SEND_TOGGLES = tuple((f"use_send_{key}", key) for key in PASS_ORDER)


def clear_pass_cache():
    """清空通道捕获缓存与指纹(捕获流程启动前的防御性重置)

    同时清掉 utils 侧的原始字节缓存: 它按「渲染组 + 渲染键」缓存上一次的落盘字节,
    换了 .blend 之后相机名与矩阵可能恰好相同, 不清就会跨文件误用上一份场景的原始字节.
    """
    _PASS_CAPTURE_CACHE.clear()
    global _CAPTURE_FINGERPRINT
    _CAPTURE_FINGERPRINT = None
    clear_raw_cache()


def clear_pass_cache_ref(name: str):
    """删除 AI Ref: 前缀预览图后联动清理缓存对应通道(保持"列表里没有 = 不会发送")"""
    if not name.startswith(AI_REF_PREFIX):
        return
    title = name[len(AI_REF_PREFIX) :]
    key = next((k for k, t in _PASS_TITLES.items() if t == title), None)
    if key is not None:
        _PASS_CAPTURE_CACHE.pop(key, None)


def capture_fingerprint(rstate, scene, clamp_edge: int) -> tuple:
    """当前捕获参数指纹: 捕获勾选/全部通道参数/钳制后的捕获尺寸/相机名与世界矩阵/场景可见内容

    相机动了或参数变了指纹即变; 捕获分辨率随场景输出分辨率变化, 也一并纳入;
    场景可见内容指纹(增删/改名/移动/隐藏/换材质/改拓扑/换帧等)与渲染键同源,
    纳入后「预览可能过期」提示不再漏报"改了场景却没重捕获"这一情况.
    字段须与 group_render_key 的参数面保持一致(两处漏字段都会造成"参数变了仍提示不过期").
    """
    cap_w, cap_h = resolve_capture_size(scene, clamp_edge)
    cam = scene.camera
    cstate = scene.ch_ai_capture_params
    return (
        tuple(getattr(rstate, attr) for attr, _ in _PASS_TOGGLES),
        cstate.ao_distance,
        tuple(cstate.depth_range),
        cstate.depth_curve,
        cstate.normal_convention,
        cstate.edge_width_scale,
        cstate.use_material_borders,
        # 采样数/分割依据与层数/线稿预设都会改出图, 漏掉会让"预览可能过期"静默失效
        cstate.render_samples,
        cstate.cryptomatte_source,
        cstate.crypto_slots,
        cstate.smooth_seg_edges,
        cstate.edge_preset,
        (cap_w, cap_h),
        cam.name if cam is not None else "",
        tuple(cam.matrix_world) if cam is not None else (),
        scene_content_key(scene),
    )


def _pass_ref_image(name: str):
    """按通道键取固定名预览图数据块(无则 None)"""
    return bpy.data.images.get(f"AI Ref: {_pass_title(name)}")


def pass_available(name: str) -> bool:
    """通道发送可用性: 发送缓存有字节, 或固定名预览图数据块仍在(可从它重编码)

    缓存(内存)与预览图数据块(随 blend)生命周期不同步——重启后缓存空而预览图还在,
    以"任一存在"为可用, 保证所见即所得(迷你列表里看得到的通道就能发送).
    """
    if name in _PASS_CAPTURE_CACHE:
        return True
    return _pass_ref_image(name) is not None


def captured_pass_count() -> int:
    """已捕获的通道**种数**(供面板摘要显示)

    必须与 pass_available 同口径逐通道判定, 不能用 len(state.pass_images):
    那个快照按 "AI Ref: " 前缀收集, 会把重新捕获时改名保留的 "_bak" 备份一并算进去
    (实测出厂备份上限下稳定虚高到 2 倍), 于是摘要数字与真正能发送的通道数对不上.
    """
    return sum(1 for key in PASS_ORDER if pass_available(key))


def _pass_send_bytes(name: str) -> tuple:
    """取通道的发送字节: 缓存命中用捕获原始字节(零重编码), 缺失时从预览图数据块重编码 PNG

    调用时机在主线程(invoke/编码均主线程); 返回 (字节, 错误信息).
    """
    data = _PASS_CAPTURE_CACHE.get(name)
    if data is not None:
        return data, None
    image = _pass_ref_image(name)
    if image is None:
        return None, api_error("The captured pass is missing, run pass generation first")
    return image_to_png_bytes(image)


def collect_send_passes(rstate, scene, limit_edge: int) -> tuple:
    """按发送开关收集可发送的通道(两步工作流的发送集), 返回 (通道键列表, 不可用键列表, 是否过期)

    通道顺序即参考优先序(PASS_ORDER), 与提示词 Image N 描述顺序一致;
    不可用 = 勾选发送但缓存与预览图数据块都缺失(生成与预览都阻断并引导"生成通道");
    过期 = 当前参数指纹与捕获时不一致(仅提示不阻断).
    limit_edge 为当前服务商的参考图最长边上限(钳制口径, 与捕获时一致).
    """
    send_names, missing = [], []
    for attr, key in _SEND_TOGGLES:
        if not getattr(rstate, attr):
            continue
        if pass_available(key):
            send_names.append(key)
        else:
            missing.append(key)
    stale = _CAPTURE_FINGERPRINT is not None and _CAPTURE_FINGERPRINT != capture_fingerprint(rstate, scene, _clamp_edge(rstate, limit_edge))
    return send_names, missing, stale


def collect_style_images(rstate) -> list:
    """收集生效的风格参考图**引用条目**(生成/预览/面板摘要共用, 单一口径)

    use_send_style 关闭时不发送(也不占参考图名额); 引用悬空或像素未加载的条目剔除.
    返回条目而非数据块: 条目上带用户输入的描述(style_descriptions 组装进提示词).
    收集口径与纹理参考图共用(collect_ref_entries).
    """
    return collect_ref_entries(rstate, "use_send_style", "style_images")


def count_unavailable_style_refs(rstate) -> int:
    """风格参考图引用中不可用的条数(引用悬空或像素未加载, 与 collect_style_images 同口径)

    不可用条目不参与发送; 面板摘要里点名提醒, 让作者知道列表里有"死引用".
    """
    return count_unavailable_refs(rstate, "style_images")


def resolve_render_request(rstate, scene, prompt: str, provider: str, limit_count: int, limit_edge: int, require_captured: bool = True) -> tuple:
    """效果图发送内容组装(GenerateRender 与 PreviewRenderPrompt 共用, 保证预览即发送)

    返回 (错误, 提示列表, 通道键列表, 风格图引用条目列表, 完整提示词):
    错误为 (级别, 消息) 或 None——非 None 时调用方 report 后取消(勾选发送的通道不可用/
    一张已捕获通道都没有/预算名额被风格图占满)——**生成与预览两档对通道存在性的判定
    完全一致**(勾选发送的通道缓存与预览图数据块都缺失即阻断); 提示为不阻断的
    (级别, 消息) 列表(参数过期/超限截断/提示词超预算); 通道顺序即参考优先序,
    风格图永远发送并占保底名额(通道截断到 上限-风格张数, 但至少给通道留一个名额);
    require_captured 只区分"一张已捕获通道都没有"时的行为: 生成档取消并引导,
    预览档继续组装纯提示词.
    """
    send_names, missing, stale = collect_send_passes(rstate, scene, limit_edge)
    style_refs = collect_style_images(rstate)
    notices = []
    if stale:
        notices.append(('WARNING', "Pass parameters changed since the capture, the previews may be outdated"))
    if missing:
        # 勾选发送的通道缓存与预览图数据块都缺失: 生成与预览一致阻断(作者定论)
        return (("WARNING", report("No captured pass for: {}, run pass generation first").format(", ".join(_pass_title(name) for name in missing))), notices, [], [], "")
    if require_captured and not send_names:
        # 一张已捕获的发送通道都没有(未勾选任何发送开关)
        return (("WARNING", "Enable at least one captured pass to send, " "run pass generation first"), notices, [], [], "")
    if 0 < limit_count < len(send_names) + len(style_refs):
        room = limit_count - len(style_refs)
        if room < 1:
            # 风格图把参考图名额占满, 一张通道图都发不下
            message = report("Provider allows {} reference images, the {} style images " "fill the budget, no room for pass images").format(limit_count, len(style_refs))
            if require_captured:
                return ("ERROR", message), notices, [], [], ""
            notices.append(('ERROR', message))
            send_names = []
        else:
            dropped = ", ".join(_pass_title(name) for name in send_names[room:])
            send_names = send_names[:room]
            notices.append(('INFO', report("Provider allows {} reference images, dropped: {}").format(limit_count, dropped)))
    style_descriptions = [ref.description for ref in style_refs]
    # 法向约定跟随面板(完整档拼进 normal 条目; 精简档省略)
    full_prompt, over_budget = resolve_render_prompt(prompt, send_names, style_descriptions, provider, normal_convention=scene.ch_ai_capture_params.normal_convention)
    if over_budget:
        budget, _hard = prompt_token_budget(provider)
        notices.append(('WARNING', report("Prompt is about {} tokens, above the {} budget, " "it may be truncated").format(estimate_prompt_tokens(full_prompt), budget)))
    return None, notices, send_names, style_refs, full_prompt


class ClearPassBackups(Operator):
    """
    清除备份通道操作器

    功能: 一键删除全部通道预览图的 "_bak" 备份副本(重新捕获时上一轮预览图改名保留的
    历史版本, 见 _write_preview_image); 当前预览图与发送缓存不受影响.
    """

    bl_idname = "ch_ai.clear_pass_backups"
    bl_label = "Clear Pass Backups"
    bl_description = "Delete all '_bak' backup copies of the pass previews"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(img.name.startswith(AI_REF_PREFIX) and "_bak" in img.name for img in bpy.data.images)

    def execute(self, context: Context):
        backups = [img for img in bpy.data.images if img.name.startswith(AI_REF_PREFIX) and "_bak" in img.name]
        for img in backups:
            bpy.data.images.remove(img)
        sync_images_now()
        self.report({'INFO'}, report("Deleted {} pass backups").format(len(backups)))
        return {'FINISHED'}


_PASS_CAPTURE_CACHE: dict = {}


_CAPTURE_FINGERPRINT: tuple | None = None


def store_capture(passes: dict, fingerprint) -> None:
    """把本次捕获的通道字节与参数指纹写入发送缓存(捕获算子的唯一写入入口)

    本函数是 `_PASS_CAPTURE_CACHE` / `_CAPTURE_FINGERPRINT` 的**唯一写入点**:
    二者是本模块的模块级状态, 若写作方在自己模块内用 `global` 重绑定, 本模块的读方
    (pass_available / collect_send_passes 等)将永远读到旧值 —— 过期提示会静默失效
    且无任何报错, 故写入一律经此函数(字典用原地变更, 指纹用本模块内赋值).
    """
    _PASS_CAPTURE_CACHE.clear()
    _PASS_CAPTURE_CACHE.update(passes)
    global _CAPTURE_FINGERPRINT
    _CAPTURE_FINGERPRINT = fingerprint
