"""
世界环境面板动作算子

世界环境面板列表下方的"背景透明/屏蔽世界/初始化 HDRI 图像"动作行与"环境设置"子面板的
模式切换; 世界数据块管理(新建/指认/解除关联)见 datablock_ops.

主要功能:
- WorldFilmTransparentToggle: 切换渲染设置的胶片透明
- WorldMuteToggle: 屏蔽/恢复世界输出节点的全部接入端连线
- WorldHDRIInitialize: 取世界树里现有的 HDRI 图像整树重建环境链
- WorldEnvModeSet: 切换场景世界的环境设置模式
- WorldEnvCleanup: 清理世界节点树里的孤立节点(含切走档的链节点; 腾空的插件 Frame 一并移除)
"""

from bpy.props import StringProperty
from bpy.types import Context, Operator

from .....common.i18n.i18n import report
from ...handlers import tag_3d_views
from ...utils import collect_world_env_orphans, ensure_world_env_chain, rebuild_world_env_from_hdri, set_world_output_muted, world_output_has_links, world_output_muted

# 环境模式合法标识(与 props.ENV_MODE_ITEMS 一一对应; 算子不导入 props, 本地声明同
# operators/object/light.py 的 _ADVANCED_MODES 先例)
_ENV_MODES = ('BASIC', 'HDRI', 'PROCEDURAL')


class WorldFilmTransparentToggle(Operator):
    """背景透明: 切换渲染设置的胶片透明"""

    bl_idname = "ch.world_film_transparent_toggle"
    bl_label = "Transparent Background"
    bl_description = "Toggle the film transparency of the render settings (renders see through the world background and output alpha instead)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        context.scene.render.film_transparent = not context.scene.render.film_transparent
        return {'FINISHED'}


class WorldMuteToggle(Operator):
    """屏蔽世界: 切换世界输出节点全部接入端连线的屏蔽位"""

    bl_idname = "ch.world_mute_toggle"
    bl_label = "Mute World"
    bl_description = "Mute or restore every link into the World Output node so the world lighting turns black (the same muting the Lights panel applies while isolating with Mute World on; light isolation restores hand-muted links too)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        world = context.scene.world
        # 按钮按"本地世界且有接入端连线"绘制期置灰, 这里兜底脚本直调路径
        if world is None or world.library is not None or not world_output_has_links(world):
            return {'CANCELLED'}
        set_world_output_muted(world, not world_output_muted(world))
        # NodeLink.is_muted 程序化翻转不触发视口重绘(pitfalls §20): 与灯光隔离路径同款显式 tag
        tag_3d_views()
        return {'FINISHED'}


class WorldHDRIInitialize(Operator):
    """初始化 HDRI 图像: 取世界节点树里的 HDRI 图像后整树重建为模板环境链

    与材质面板"初始化 PBR 材质"同逻辑: 树里没有 .hdr/.exr 时只提示、世界保持原状;
    整树重建会清空自定义拓扑(Ctrl+Z 可回), 环境模式随之落到 HDRI 档.
    """

    bl_idname = "ch.world_hdri_initialize"
    bl_label = "Initialize HDRI Image"
    bl_description = "Rebuild the world node tree with the HDRI image (.hdr or .exr) found in it, using the Environment Settings template chain (the whole node tree is replaced)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        world = context.scene.world
        # 无世界由子面板提示行挡住, 这里兜底脚本直调路径
        if world is None:
            self.report({'WARNING'}, report("No active world"))
            return {'CANCELLED'}
        result = rebuild_world_env_from_hdri(world)
        if not result["ok"]:
            # 拒绝路径: no_hdri = 树里没有 .hdr/.exr(世界不动); failed = 建链异常/属性组缺失
            # (已补最小纯色背景兜底树, 原树 Ctrl+Z 可回); no_tree = 无节点树(理论路径, 5.3 世界恒有树)
            message = {
                'linked': "Linked world data is read-only",
                'no_tree': "This world has no node tree",
                'no_hdri': "No HDRI image (.hdr or .exr) found in the world node tree",
                'failed': "Failed to rebuild the world node tree",
            }.get(result["error"], "Failed to rebuild the world node tree")
            self.report({'WARNING'}, report(message))
            return {'CANCELLED'}
        self.report({'INFO'}, report("World environment rebuilt from the HDRI image: {}").format(result["image"].name))
        return {'FINISHED'}


class WorldEnvModeSet(Operator):
    """环境设置模式切换(胶囊按钮, depress 高亮当前档)

    切换即建链: 环境链常驻节点缺失时按模式重建(幂等), 并把当前模式的输出接到
    Mix Shader 第一个着色器插槽(建链只在算子 execute 里发生, 绘制期不写数据).
    """

    bl_idname = "ch.world_env_mode_set"
    bl_label = "Set Environment Mode"
    bl_description = "Switch the environment mode of the scene world (each world remembers its own mode)"
    bl_options = {'REGISTER', 'UNDO'}

    mode: StringProperty(name="Mode", description="Target environment mode", default="BASIC", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        world = context.scene.world
        # 无世界/库链接世界由子面板提示行挡住, 这里兜底脚本直调路径
        if world is None or world.library is not None:
            return {'CANCELLED'}
        world.ch_env.mode = self.mode if self.mode in _ENV_MODES else 'BASIC'
        ensure_world_env_chain(world)
        return {'FINISHED'}


class WorldEnvCleanup(Operator):
    """环境设置折叠头挂钮: 清理世界节点树里的孤立节点(从 World Output 反向不可达)

    与灯光高级设置同口径: 只要孤立就清理(按模式生成的链切走档后即孤立, 清后重进档
    重建); 孤立节点清走后腾空的 Frame 一并移除(链重建时 Frame 随建). 经算子执行进
    撤销栈(Ctrl+Z 可回).
    """

    bl_idname = "ch.world_env_cleanup"
    bl_label = "Cleanup World Nodes"
    bl_description = "Delete nodes of the world node tree that are not connected to the World Output, and empty frames left behind (orphan chains are rebuilt on re-entering the mode)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        world = context.scene.world
        if world is None or world.library is not None:
            return {'CANCELLED'}
        if world.node_tree is None:
            return {'CANCELLED'}
        orphans = collect_world_env_orphans(world)
        if not orphans:
            self.report({'INFO'}, report("No orphan nodes in the world node tree"))
            return {'CANCELLED'}
        tree = world.node_tree
        for node in orphans:
            for child in tree.nodes:
                if child.parent == node:
                    child.parent = None
            tree.nodes.remove(node)
        # 孤立节点清走后腾空的插件 Frame 一并移除(作者定; 链按模式重建时 Frame 随建);
        # 只认带插件标记的 Frame(与灯光版清理口径一致), 用户自建的空 Frame 不碰
        for node in list(tree.nodes):
            if node.type == 'FRAME' and node.get("ch_env") is not None and not any(child.parent == node for child in tree.nodes):
                tree.nodes.remove(node)
        self.report({'INFO'}, report("Cleaned {} orphan nodes").format(len(orphans)))
        return {'FINISHED'}
