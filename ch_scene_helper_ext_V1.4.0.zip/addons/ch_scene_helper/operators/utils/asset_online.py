"""
在线资产下载操作器公共层

世界环境 HDRI 档与 PBR 材质档共用同一套在线下载交互(规格下拉 + 状态件), 本模块承载其
公共实现: 选中条目与生效规格的解析,规格菜单的已下载标识, 以及四族算子的 mixin——具体
算子类只声明 bl_idname 与资产种类(pick_kind), 绘制与执行逻辑只有一份.

主要功能:
- picked_asset / download_target: 按资产种类解析当前选中条目与生效下载规格
- downloaded_folder: 当前条目该规格已落盘文件的所在目录(单文件型=源目录, 包型=贴图目录)
- download_icon: 规格菜单项的已下载标识(该档已落盘 DOT / 未落盘 BLANK1 留位对齐)
- OnlineResolutionMixin / OnlineFormatMixin: 分辨率与格式下拉的绘制
- OnlineOptionSetMixin: 把选定的分辨率/格式写进面板状态
- OnlineDownloadMixin: 按当前选择下载并解压(8K 起先弹确认)
- OnlineCancelMixin: 取消进行中的下载
- OnlineOpenFolder: 已下载态旁的"打开所在文件夹"钮(两档共用, 走系统文件管理器)

mixin 不是 bpy 类型, 其属性注解不会被 Blender 收集: 具体算子类须自行声明载荷属性
(规格设定的 field/value), 菜单类则自行提供 bl_idname / bl_label.
"""

import os

import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from .....common.i18n.i18n import iface, report
from ...preference import online_manifest_library, resolve_library_root
from ...scene_state import ONLINE_SPEC_FIELDS, get_state, stored_pick_key
from ...utils import (
    MODE_PACK,
    archive_path,
    cancel_active_download,
    download_url,
    existing_source,
    list_manifest_assets,
    list_manifest_pbr_assets,
    list_categories,
    local_base,
    resolution_items,
    resolution_rank,
    resolve_category,
    resolve_option,
    size_text,
    spec_archive_exists,
    spec_dir,
    start_download,
)
from ._base import TranslatedDescriptionMixin

# 大档下载的确认门槛(档位值 >= 该值先弹确认: 8K 起单包可达数百 MB 至 GB 级, 误点代价高)
LARGE_DOWNLOAD_RANK = 8

# "打开所在文件夹"钮的合法资产种类(下载行两档共用)
_OPEN_FOLDER_KINDS = ('WORLD', 'PBR')

# 资产种类 -> 未选中条目时的提示文案(与各自面板的选择器措辞一致)
_PICK_HINTS = {
    'WORLD': "Pick an HDRI thumbnail above first",
    'PBR': "Pick a material thumbnail above first",
}


def indexed_assets(root: str, category: str, kind: str) -> list:
    """在线条目表(按资产种类分派: 包型 / 单文件型); 分类为空或索引无条目时返回空表"""
    if not root or not category:
        return []
    return list_manifest_pbr_assets(root, category) if kind == 'PBR' else list_manifest_assets(root, category)


def picked_asset_of(state, kind: str):
    """当前选中条目解析 (库根, 条目): 非在线库/无库/无候选/未选中时条目为 None

    分类走与绘制侧同款的失效回退(首开态存储值为空), 绘制,菜单与算子共用本函数.
    **先备候选表再读选中键**: 候选为空时读动态枚举存值会让 Blender 打
    "current value '6' matches no enum" 的告警(见 scene_state.stored_pick_key).
    """
    prefix = kind.lower()
    if not online_manifest_library(kind, getattr(state, "adv_{}_library".format(prefix))):
        return "", None
    root = resolve_library_root(kind, getattr(state, "adv_{}_library".format(prefix)))[0]
    if not root:
        return "", None
    categories = list_categories(root, online=True, kind=kind)
    category = resolve_category(categories, getattr(state, "adv_{}_category".format(prefix)))
    assets = indexed_assets(root, category, kind)
    key = stored_pick_key(state, "adv_{}_pick".format(prefix), assets)
    return root, next((asset for asset in assets if asset["key"] == key), None)


def picked_asset(context, kind: str):
    """picked_asset_of 的 context 版本(算子与菜单用; 绘制侧已有 state 时直接用后者)"""
    return picked_asset_of(get_state(context), kind)


def download_target(context, kind: str):
    """(库根, 条目, 生效规格): 未选中条目或该条目无可下载规格时规格为 None"""
    state = get_state(context)
    root, asset = picked_asset(context, kind)
    if asset is None:
        return root, None, None
    fields = ONLINE_SPEC_FIELDS[kind]
    return root, asset, resolve_option(asset, getattr(state, fields[0], ""), getattr(state, fields[1], ""))


def downloaded_folder(root: str, asset, option) -> str:
    """当前条目该规格已落盘文件的所在目录(未下载返回空串)

    单文件型 existing_source 给源文件路径 -> 取其所在目录; 包型返回该分辨率的贴图目录
    (existing_source 直接给目录). 不区分包型/单文件: 按"路径是目录"分流, 与 manifest
    侧的落盘形态解耦.
    """
    target = existing_source(root, asset, option)
    if not target:
        return ""
    return target if os.path.isdir(target) else os.path.dirname(target)


def download_icon(root: str, asset, resolution: str, fmt: str) -> str:
    """规格菜单项图标: 该 (分辨率, 格式) 组合已落盘 DOT / 未落盘 BLANK1(留位对齐)

    只在组合精确命中时判已下载; 该组合不存在(分辨率不支持此格式)一律 BLANK1,
    不拿回落档的状态冒充. 下载包仍在时同样算已下载(清理下载包后贴图仍可用).
    """
    option = resolve_option(asset, resolution, fmt)
    if option is None or option["res"] != resolution or option["fmt"] != fmt:
        return 'BLANK1'
    downloaded = existing_source(root, asset, option) or spec_archive_exists(root, asset, option)
    return 'DOT' if downloaded else 'BLANK1'


class OnlineResolutionMixin:
    """分辨率下拉的公共绘制: 子类声明 pick_kind 与 option_set(规格设定算子的 bl_idname)"""

    pick_kind = ''
    option_set = ''
    # 菜单类不走 mixin 的属性声明(非 bpy 类型), 由子类提供 bl_idname / bl_label

    def draw(self, context):
        state = get_state(context)
        root, asset = picked_asset(context, self.pick_kind)
        if asset is None:
            return
        fmt_field = ONLINE_SPEC_FIELDS[self.pick_kind][1]
        for resolution in resolution_items(asset):
            option = resolve_option(asset, resolution, getattr(state, fmt_field, ""))
            if option is None:
                continue
            size = size_text(option["size"])
            label = "{} ({})".format(resolution, size) if size else resolution
            item = self.layout.operator(self.option_set, text=label, icon=download_icon(root, asset, option["res"], option["fmt"]))
            item.field = 'RESOLUTION'
            item.value = resolution


class OnlineFormatMixin:
    """格式下拉的公共绘制(只列当前分辨率可用的格式; 图标口径与分辨率菜单相同)"""

    pick_kind = ''
    option_set = ''

    def draw(self, context):
        state = get_state(context)
        root, asset = picked_asset(context, self.pick_kind)
        if asset is None:
            return
        fields = ONLINE_SPEC_FIELDS[self.pick_kind]
        option = resolve_option(asset, getattr(state, fields[0], ""), getattr(state, fields[1], ""))
        if option is None:
            return
        current_res = option["res"]
        # 只列该分辨率真正提供的格式: 列全局格式会让选择被静默回落到别的格式
        formats = []
        for item in asset.get("downloads") or []:
            if item["res"] == current_res and item["fmt"] not in formats:
                formats.append(item["fmt"])
        for fmt in formats:
            item = self.layout.operator(self.option_set, text=fmt, icon=download_icon(root, asset, current_res, fmt))
            item.field = 'FORMAT'
            item.value = fmt


class OnlineOptionSetMixin:
    """下载规格选定: 写面板状态里的分辨率或格式(空/失效由解析回落, 无需校验取值)

    子类须声明 field / value 两个隐藏字符串属性与 pick_kind.
    """

    pick_kind = ''

    def execute(self, context):
        state = get_state(context)
        fields = ONLINE_SPEC_FIELDS[self.pick_kind]
        setattr(state, fields[1] if self.field == 'FORMAT' else fields[0], self.value)
        return {'FINISHED'}


class OnlineDownloadMixin:
    """下载执行: 按当前缩略图与规格下载资产包并解压(包保留), 8K 起先弹确认

    资产种类决定落盘形态: 单文件型解出源文件, 包型把整包贴图解到 <包目录>/<分辨率>/.
    全局单任务由下载模块保证(任务进行中面板已把其余下载钮置灰).
    子类须声明 pick_kind(留空时查表会直接报错, 免得漏声明时静默按世界档走).
    """

    pick_kind = ''

    # 确认对话框的展示载荷(纯 Python 属性, 只在 invoke 到 draw 之间使用)
    _dialog_name = ""
    _dialog_spec = ""

    def invoke(self, context, event):
        _root, asset, option = download_target(context, self.pick_kind)
        if asset is None or option is None:
            # 前置校验失败交给 execute 统一上报, 不弹对话框
            return self.execute(context)
        if resolution_rank(option["res"]) < LARGE_DOWNLOAD_RANK:
            return self.execute(context)
        self._dialog_name = asset["name"]
        self._dialog_spec = iface("Resolution {} · {}").format(option["res"], size_text(option["size"]) or "-")
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        layout = self.layout
        layout.label(text=self._dialog_name, icon='IMAGE_DATA')
        layout.label(text=self._dialog_spec)

    def execute(self, context):
        root, asset, option = download_target(context, self.pick_kind)
        if asset is None:
            self.report({'WARNING'}, report(_PICK_HINTS[self.pick_kind]))
            return {'CANCELLED'}
        if option is None:
            self.report({'WARNING'}, report("No download spec for this asset"))
            return {'CANCELLED'}
        url = download_url(asset, option)
        if not url:
            self.report({'WARNING'}, report("No download link for this asset"))
            return {'CANCELLED'}
        archive = archive_path(root, asset, option)
        # Referer 由索引 source.site 给出(cgbookcase 的 CDN 缺它即 403, 见 asset_download)
        referer = str(option.get("referer") or "")
        if self.pick_kind == 'PBR':
            target = spec_dir(root, asset, option)
            if target is None:
                self.report({'WARNING'}, report("No download spec for this asset"))
                return {'CANCELLED'}
            ok, error = start_download(url, archive, str(target), option["size"], MODE_PACK, asset["key"], option["attr"], referer)
        else:
            ok, error = start_download(url, archive, str(local_base(root, asset, option)), option["size"], referer=referer)
        if not ok and error:
            self.report({'WARNING'}, report(error))
            return {'CANCELLED'}
        return {'FINISHED'}


class OnlineCancelMixin:
    """取消下载: 置当前任务取消位(全局单任务, 面板切了规格也能取消), 未完成文件由下载模块清理"""

    def execute(self, context):
        if not cancel_active_download():
            self.report({'INFO'}, report("No download is running"))
            return {'CANCELLED'}
        return {'FINISHED'}


class OnlineOpenFolder(TranslatedDescriptionMixin, Operator):
    """打开所在文件夹: 在线库当前选中条目已落盘文件的目录(下载行完成态旁的小钮)

    目录按 downloaded_folder 解析(单文件型=源目录, 包型=该分辨率的贴图目录), 经原生
    wm.path_open 交给系统文件管理器; 未选中/无规格/未下载各画提示口径一致地拒绝.
    """

    bl_idname = "ch.online_open_folder"
    bl_label = "Open Download Folder"
    bl_description = "Open the folder where the downloaded files of the picked asset are stored"
    bl_options = {'REGISTER', 'UNDO'}

    pick_kind: StringProperty(name="Kind", description="Asset kind: WORLD or PBR", default="WORLD", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context):
        kind = self.pick_kind if self.pick_kind in _OPEN_FOLDER_KINDS else 'WORLD'
        root, asset = picked_asset(context, kind)
        if asset is None:
            self.report({'WARNING'}, report(_PICK_HINTS[kind]))
            return {'CANCELLED'}
        state = get_state(context)
        fields = ONLINE_SPEC_FIELDS[kind]
        option = resolve_option(asset, getattr(state, fields[0], ""), getattr(state, fields[1], ""))
        if option is None:
            self.report({'WARNING'}, report("No download spec for this asset"))
            return {'CANCELLED'}
        folder = downloaded_folder(root, asset, option)
        if not folder:
            self.report({'WARNING'}, report("Nothing downloaded at this resolution yet"))
            return {'CANCELLED'}
        bpy.ops.wm.path_open(filepath=folder)
        return {'FINISHED'}
