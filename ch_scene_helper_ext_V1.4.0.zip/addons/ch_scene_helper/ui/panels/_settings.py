"""
资源设置绘制模块

灯光/相机/材质设置区与 PBR 材质子面板的共享绘制实现.
抽出的目的是让折叠头/参数区/PBR 三项只有一份实现.

主要功能:
- setup_param_box: 参数子面板 box 的统一排版(property split + 去装饰)
- draw_details_section: 可折叠详情子面板的统一骨架(折叠头 + box + 内容回调)
- draw_pbr_body: 材质面板 PBR 子面板的模式体(PBR 资产选择器 + 已导入链的参数区)
- draw_light_settings / draw_camera_settings: 活动灯光/相机设置
- draw_light_advanced: 灯光高级设置子面板(四模式枚举含"无"档; 渐变三模式 + 常显色标,
  图像纹理/IES 光域网选择器 = 资产库与分类行 + 缩略图网格 + 链参数)
- draw_world_env_body: 世界环境设置子面板的模式体(基础/HDRI/程序纹理三档参数,
  HDRI 档含世界环境 HDRI 选择器,在线库下载行与调节组镜像参数)
- draw_world_replace_body: 替换背景子面板的模式体(纯色/渐变档位 + 颜色/强度)
"""

import os
import time
from functools import partial

from bpy.types import Context, UILayout

from .....common.i18n.i18n import iface, iface_ctx

from ...operators.object.light import (
    LightAssetCategoryMenuIES,
    LightAssetCategoryMenuImage,
    LightAssetCategoryMenuPBR,
    LightAssetCategoryMenuWorld,
    LightAssetLibraryMenuIES,
    LightAssetLibraryMenuImage,
    LightAssetLibraryMenuPBR,
    LightAssetLibraryMenuWorld,
    LightAdvancedCleanup,
    LightAdvancedClearExternal,
    LightAdvancedModeSet,
    LightAdvancedRefreshSource,
    LightAssetThumbCycle,
    RenderEngineSwitch,
)
from ...operators.utils.material_ops import PBRImportPack
from ...operators.object.world_asset import WorldHDRIDownload, WorldHDRIDownloadCancel, WorldHDRIFormatMenu, WorldHDRIResolutionMenu
from ...operators.utils.asset_online import OnlineOpenFolder, _PICK_HINTS, picked_asset_of
from ...operators.utils.pbr_asset import PBRMaterialDownload, PBRMaterialDownloadCancel, PBRMaterialFormatMenu, PBRMaterialResolutionMenu
from ...preference import get_prefs, online_manifest_library, resolve_library_root
from ...props import _ENV_FIELD_SOCKETS, _suppress_env_mirror, _suppress_light_adv_toggle
from ...scene_state import ONLINE_SPEC_FIELDS
from ...utils import (
    ARRAY_MODE_RING,
    MARK_IMAGE_ARRAY,
    MARK_IMAGE_HSV,
    MARK_IMAGE_TEX,
    MARK_IES_GAMMA,
    MARK_IES_TEX,
    MARK_WORLD_ENV_BG,
    MARK_WORLD_ENV_HDRI_MAP,
    MARK_WORLD_ENV_HDRI_SETTING,
    MARK_WORLD_ENV_HDRI_TEX,
    MARK_WORLD_ENV_MIX,
    MARK_WORLD_ENV_REPLACE_BG,
    MARK_WORLD_ENV_REPLACE_COLOR,
    MARK_WORLD_ENV_REPLACE_RAMP,
    MARK_WORLD_ENV_REPLACE_SWITCH,
    MARK_WORLD_ENV_SKY_TEX,
    archive_path,
    collect_orphan_nodes,
    collect_world_env_orphans,
    download_state,
    emission_occupied,
    error_kind,
    existing_source,
    find_advanced_node,
    find_advanced_ramp,
    find_pbr_nodes,
    find_world_env_node,
    get_pbr_uv_output,
    has_active_download,
    list_assets,
    list_categories,
    manifest_state,
    resolve_category,
    resolve_option,
    size_text,
    suppress_pbr_mirror_updates,
)
from ...utils._constants import TEXCOORD_OPTIONS

# 纹理坐标下拉的合法标识集合(绘制期判真值是否落在候选项内)
_UV_IDS = frozenset(option[0] for option in TEXCOORD_OPTIONS)

# 下载失败的可见短句(键 = utils.asset_download.error_kind 的归类; 原始异常名附在括号里便于排查)
_DOWNLOAD_ERROR_TEXTS = {
    'NO_SOURCE': "No source file in the archive",
    'TIMEOUT': "Download timed out",
    'NETWORK': "Network error, check the connection",
    'DISK': "Cannot write the file, check free space and permissions",
    'OTHER': "Download failed",
}

# 高级设置模式胶囊(算子按钮, depress 高亮当前档): 标签走 Operator 语境查翻译;
# "无"档移出胶囊由折叠头行尾的激活开关承担(与世界环境"启用替换背景"对齐, 作者定)
_ADVANCED_MODE_PILLS = (
    ('GRADIENT', "Gradient Module"),
    ('IMAGE', "Image"),
    ('IES', "IES"),
)


def setup_param_box(box: UILayout) -> None:
    """参数子面板 box 的统一排版口径

    - use_property_split: 属性名进左列,控件进右列, 与原生属性面板同观感
    - use_property_decorate = False: 去掉行尾的动画/覆盖等装饰点
    """
    box.use_property_split = True
    box.use_property_decorate = False


# 清理钮置灰态的短窗缓存(键 = 灯名): draw 期逐帧全树可达性遍历只为一个置灰态,
# 0.25s 窗口内重复求值直接回缓存; 节点增删/改线后的陈旧窗口不超窗长, 视觉无感
_ORPHAN_CACHE: dict = {}

# 世界孤立节点置灰态的短窗缓存(灯版同款: 键 = 世界名, 持有世界数据块引用防死引用)
_WORLD_ORPHAN_CACHE: dict = {}


def _cached_exists(cache: dict, block, compute) -> bool:
    """0.25s 短窗缓存的置灰态求值(键 = 数据块名, 持数据块引用防死引用)

    缓存持有数据块引用: undo(memfile 重分配)/删除后旧引用成死 StructRNA, 身份比对
    须捕获 ReferenceError 视为未命中重算, 不得让绘制帧抛错.
    """
    now = time.monotonic()
    hit = cache.get(block.name)
    if hit is not None and now - hit[0] <= 0.25:
        try:
            if hit[1].original is block:
                return hit[2]
        except ReferenceError:
            pass
    result = bool(compute())
    cache[block.name] = (now, block, result)
    return result


def _orphan_exists(light) -> bool:
    """该灯的节点树上是否存在孤立插件节点(0.25s 短窗缓存包裹 collect_orphan_nodes)"""
    return _cached_exists(_ORPHAN_CACHE, light, lambda: collect_orphan_nodes(light))


def _world_orphan_exists(world) -> bool:
    """该世界的节点树上是否存在孤立节点(0.25s 短窗缓存包裹 collect_world_env_orphans)"""
    return _cached_exists(_WORLD_ORPHAN_CACHE, world, lambda: collect_world_env_orphans(world))


def draw_subpanel_header(layout: UILayout, state, prop_name: str, title: str, tail=None) -> bool:
    """无框折叠头(三角箭头 + 标题文本), 返回是否展开

    口径: prop(text="", emboss=False) 只画三角, 标题用 label 紧跟其后(靠左);
    展开态存面板状态组(SceneHelperState). tail 可选: 标题行尾的附加控件
    (如灯光方位折叠头的模态唤起按钮), 画在标题行内,标题文本之后.
    曾试过"标题并入 prop(text=title) 整行可点"(TRIA_* 与 DISCLOSURE_TRI_* 两种图标):
    bool+icon+text 均渲染为全宽按钮致标题居中(2026-11-06/07 两轮实测), 与靠左的
    折叠头惯例冲突——定论: 放弃标题可点, 回退本口径, 勿再尝试.
    """
    opened = getattr(state, prop_name)
    header = layout.row()
    header.prop(state, prop_name, text="", emboss=False, icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
    header.label(text=title)
    if tail is not None:
        tail(header)
    return opened


def draw_details_section(layout: UILayout, state, prop_name: str, title: str, draw_body, header_tail=None) -> None:
    """可折叠详情子面板: 未展开直接返回; 展开时画 box 并交给 draw_body"""
    if not draw_subpanel_header(layout, state, prop_name, title, header_tail):
        return
    draw_body(layout.box())


def draw_pbr_body(box: UILayout, state, mat) -> None:
    """PBR 材质子面板的模式体: 资产选择器(应用钮 = 导入资产包) + 已导入链的参数区

    选择器复用四档共用实现(离线库条目 = 分类顶层的资产包目录, 在线库条目按索引的 package
    字段定位), 在线库在网格下方追加下载行(分辨率/格式/下载状态), 无可用资产库时下方
    分隔横线不画. 参数区从上到下只画条件满足的行: 基础色调节(Hue/Saturation/Value 三行)
    -> AO + 系数 -> 法向 + 强度, 法向开启时其下再画朝向档位(OpenGL/DirectX) -> 凹凸 +
    强度与距离(与法向互斥) -> 置换 + 中间值与缩放 -> 纹理坐标(链在) -> 投影统一切换(链内
    有任一贴图, Box 档追加 Blend); 开关关闭时同行参数置灰. 未导入任何包(无链)时参数区不画
    也不画提示. 调用方已排除无活动材质/库链接两种空态.
    开关与系数的真值在链节点上, 经 WM 镜像字段绘制: 绘制前把真值读进镜像(抑制器跳过
    update), 用户改动经回调统一写回链节点(直接编辑节点不进撤销栈, tooltip 说明); 强度/
    距离/中间值/缩放与基础色三行直绘节点插座, 标签用节点插座原名(Strength 走 Amount 语境
    预译, 规避系统默认语境的"强度/力度"双译); Value 另用 "HSV Value" 作源串避开系统 Value
    语境, 词典译"明度". 法线朝向画成两枚胶囊(节点自带的 convention 档位), 画在法向行下方
    且仅法向开启时出现.
    """
    setup_param_box(box)
    col = box.column()
    if _draw_asset_picker(col, state, 'PBR', partial(_draw_online_download_row, state=state, kind='PBR'), apply_op=PBRImportPack):
        col.separator(type='LINE')
    nodes = find_pbr_nodes(mat)
    if "BSDF" not in nodes:
        return
    # 基础色调色: 链内 Hue/Saturation/Value 节点的三个插座(基础色链首段, 常显)
    hsv = nodes.get("HSV:base")
    if hsv is not None:
        col.prop(hsv.inputs["Hue"], "default_value", text="Hue")
        col.prop(hsv.inputs["Saturation"], "default_value", text="Saturation")
        col.prop(hsv.inputs["Value"], "default_value", text="HSV Value")
    # AO: 链末 Switch 决定叠加与否, Mix 的 Factor(VALUE)套在 inputs[0] 为系数
    ao_switch = nodes.get("SWITCH_AO")
    mix = nodes.get("MIX:ao")
    if ao_switch is not None and mix is not None:
        with suppress_pbr_mirror_updates():
            state.pbr_ao_enabled = ao_switch.inputs["Switch"].default_value
            state.pbr_ao_factor = mix.inputs[0].default_value
        row = col.row(align=True, heading="AO")
        row.prop(state, "pbr_ao_enabled", text="")
        sub = row.row(align=True)
        sub.active = state.pbr_ao_enabled
        sub.prop(state, "pbr_ao_factor", text="Factor")
    # 法向: 链末 Switch + Normal Map 强度(与凹凸互斥); 朝向是节点自带的档位, 画在下一行
    normal_switch = nodes.get("SWITCH_NORMAL")
    nmap = nodes.get("NMAP")
    if normal_switch is not None and nmap is not None:
        with suppress_pbr_mirror_updates():
            state.pbr_normal_enabled = normal_switch.inputs["Switch"].default_value
            state.pbr_normal_convention = nmap.convention
        row = col.row(align=True, heading="Normal")
        row.prop(state, "pbr_normal_enabled", text="")
        sub = row.row(align=True)
        sub.active = state.pbr_normal_enabled
        sub.prop(nmap.inputs["Strength"], "default_value", text=iface_ctx("Strength", "Amount"))
        if state.pbr_normal_enabled:
            col.row(align=True).prop(state, "pbr_normal_convention", expand=True)
    # 凹凸: 链末 Switch + Bump 强度与距离(与法向互斥)
    bump_switch = nodes.get("SWITCH_BUMP")
    bump = nodes.get("BUMP")
    if bump_switch is not None and bump is not None:
        with suppress_pbr_mirror_updates():
            state.pbr_bump_enabled = bump_switch.inputs["Switch"].default_value
        row = col.row(align=True, heading="Bump")
        row.prop(state, "pbr_bump_enabled", text="")
        sub = row.row(align=True)
        sub.active = state.pbr_bump_enabled
        sub.prop(bump.inputs["Strength"], "default_value", text=iface_ctx("Strength", "Amount"))
        sub.prop(bump.inputs["Distance"], "default_value", text="Distance")
    # 置换: 链末 Switch + Displacement 中间值与缩放
    disp_switch = nodes.get("SWITCH_DISP")
    if disp_switch is not None:
        with suppress_pbr_mirror_updates():
            state.pbr_displacement = disp_switch.inputs["Switch"].default_value
        row = col.row(align=True, heading="Displacement")
        row.prop(state, "pbr_displacement", text="")
        disp = nodes.get("DISP")
        if disp is not None:
            sub = row.row(align=True)
            sub.active = state.pbr_displacement
            sub.prop(disp.inputs["Midlevel"], "default_value", text="Midlevel")
            sub.prop(disp.inputs["Scale"], "default_value", text="Scale")
    coord = nodes.get("UV:coord")
    mapping = nodes.get("UV:mapping")
    if coord is not None and mapping is not None:
        current = get_pbr_uv_output(mat)
        if current not in _UV_IDS:
            # 真值不在三项候选内(手线接到别的输出口): 画置灰只读行, 不声称枚举真值
            row = col.row()
            row.enabled = False
            row.alignment = 'RIGHT'
            row.label(text="Texture Coordinate", icon='NODE_SOCKET_COLLECTION')
            row.label(text=current or "-")
        else:
            with suppress_pbr_mirror_updates():
                state.pbr_uv_output = current
            col.prop(state, "pbr_uv_output")
    textures = [node for marker, node in nodes.items() if marker.startswith("TEX:")]
    if textures:
        values = {tex.projection for tex in textures}
        if len(values) == 1:
            with suppress_pbr_mirror_updates():
                state.pbr_projection = values.pop()
        col.prop(state, "pbr_projection")
        if state.pbr_projection == 'BOX':
            with suppress_pbr_mirror_updates():
                state.pbr_projection_blend = textures[0].projection_blend
            col.prop(state, "pbr_projection_blend")


def draw_light_settings(box: UILayout, obj, context: Context) -> None:
    """灯光设置(传灯光物体, 因为 Cycles 的 lightgroup/spread 挂在物体与数据块两处)

    结构顺序固定: Temperature -> Color -> Power -> 类型属性 -> 阴影/引擎项.
    可见性五钮已移至灯光面板动作行(设置控制器行下一行, 作者定).
    """

    light = obj.data
    setup_param_box(box)
    col = box.column()
    row = col.row(align=True, heading="Temperature")
    row.prop(light, "use_temperature", text="")
    sub = row.row()
    sub.active = light.use_temperature
    sub.prop(light, "temperature", text="")

    col.prop(light, "color", text="Color" if not light.use_temperature else "Tint")
    row = col.row(align=True)
    row.prop(light, "energy")
    row.prop(light, "normalize", text="")
    col.prop(light, "exposure")

    if light.type in {'POINT', 'SPOT'}:
        row = col.row(align=True)
        row.prop(light, "shadow_soft_size", text="Radius")
        row.prop(light, "use_soft_falloff", text="")
        if light.type == 'SPOT':
            sub_row = col.row(align=True)
            sub_row.prop(light, "spot_size", text="Beam Shape")
            sub_row.prop(light, "spot_blend", text="", slider=True)
            sub_row.prop(light, "show_cone", text="", icon='LIGHT_SPOT')
    elif light.type == 'SUN':
        col.prop(light, "angle")
    elif light.type == 'AREA':
        col.prop(light, "shape")
        row = col.row(align=True)
        if light.shape in {'SQUARE', 'DISK'}:
            row.prop(light, "size")
        elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
            row.prop(light, "size", text="Size")
            row.prop(light, "size_y", text="Size")
        if context.scene.render.engine == 'CYCLES':
            col.prop(light, "spread")

    if light.type in {'POINT', 'SPOT', 'AREA'}:
        row = col.row(align=True, heading="Custom Distance")
        row.prop(light, "use_custom_distance", text="")
        sub_row = row.row()
        sub_row.active = light.use_custom_distance
        sub_row.prop(light, "cutoff_distance", text="")

    col.prop(light, "use_shadow", text="Cast Shadow")
    if context.scene.render.engine == 'CYCLES':
        col.prop_search(obj, "lightgroup", context.view_layer, "lightgroups", text="Light Group")


def draw_light_advanced(layout: UILayout, context: Context, state, obj) -> None:
    """灯光高级设置子面板(灯光设置与灯光方位之间)

    折叠头为标准折叠样式(三角 + 标题); "无"档由折叠头行尾的激活开关承担(清理钮
    左侧, 绘制按钮背景, 与世界环境"启用替换背景"对齐)——未激活时模式体只画
    需激活提示行(模式胶囊与参数区都不画); 胶囊只画三档(渐变/图像/IES), 激活态才
    出现. 提示替代 UI: 库链接灯 / 引擎非 Cycles / 太阳光时整块只画一行提示
    (与灯光方位无控制器提示同款), 不画任何控件(引擎提示行尾带一键切换引擎钮);
    渐变/图像档仅面光/聚光出控件, IES 档仅点光出控件, 灯型不符同样只画提示. 各
    模式参数的真值在灯光节点树的插件实例节点上, 面板直绘节点插座(同材质基础参数区
    先例); Emission 被用户手改接线时只画提示行不置灰(触碰任一控件即恢复插件线).
    """

    def header_tail(header: UILayout) -> None:
        """标题行尾: 激活开关 + 清理钮(无孤立节点时置灰), 二者紧凑排布中间半间隔

        开关是 WM 镜像布尔的 toggle prop(绘制按钮背景, 作者定), 模式真值在灯数据块
        的 ch_advanced.mode, 直接画在 align 行上保证紧凑; 清理钮因置灰需子 layout
        包裹(子 row 自 operator 起排, 空白落在右侧不影响左侧紧凑); 无灯时画置灰
        图标占位, 库链接灯开关置灰(镜像只读).
        """
        tail_row = header.row(align=True)
        has_local = obj is not None and obj.library is None
        if has_local:
            with _suppress_light_adv_toggle():
                state.advanced_enabled = light.ch_advanced.mode != 'NONE'
            tail_row.prop(state, "advanced_enabled", text="", icon='CHECKBOX_HLT' if state.advanced_enabled else 'CHECKBOX_DEHLT', toggle=True)
        else:
            tail_row.label(text="", icon='CHECKBOX_DEHLT')
        tail_row.separator(factor=0.5)
        cleanup_row = tail_row.row(align=True)
        # 显式分支而非 and 短路: 空态下 light 尚未绑定, 全靠短路躲开 UnboundLocalError
        # 属脆弱写法(重排即炸)
        cleanup_row.enabled = _orphan_exists(light) if has_local else False
        cleanup_row.operator(LightAdvancedCleanup.bl_idname, text="", icon='TRACKING_CLEAR_BACKWARDS')

    if obj is None:
        # 空态也画折叠头+占位提示(与灯光设置/灯光方位/灯光&阴影链接口径一致,
        # 且选灯前可预展开; 此前连头都不画, 违背面板模块"无活动项画占位"约定)
        if not draw_subpanel_header(layout, state, "show_light_advanced", "Advanced Settings", header_tail):
            return
        layout.box().label(text=iface("No active light"), icon='INFO')
        return
    light = obj.data
    settings = light.ch_advanced

    if not draw_subpanel_header(layout, state, "show_light_advanced", "Advanced Settings", header_tail):
        return

    body = layout.box()

    if obj.library is not None:
        # 库链接灯只读: 任何引擎下都只画这一行提示(检查先于 mode 行与引擎判断)
        setup_param_box(body)
        col = body.column()
        col.label(text="Linked light data is read-only", icon='LIBRARY_DATA_DIRECT')
        return

    if context.scene.render.engine != 'CYCLES':
        # 提示行尾内联"切换引擎"小钮(目标引擎按本节要求取 Cycles); 置灰只落提示标签,
        # 不牵连按钮——按钮包进独立的 align 子行
        hint = body.row(align=True)
        label_row = hint.row()
        label_row.enabled = False
        label_row.label(text="Switch the render engine to Cycles", icon='INFO')
        hint.operator(RenderEngineSwitch.bl_idname, text="", icon='FILE_REFRESH').engine = 'CYCLES'
        return
    if light.type == 'SUN':
        hint = body.row()
        hint.enabled = False
        hint.label(text="Sun lights are not supported", icon='INFO')
        return

    if settings.mode == 'NONE':
        # 未激活: 不画模式胶囊与参数区, 只画需激活提示(作者定)
        hint = body.row()
        hint.enabled = False
        hint.label(text="Toggle the switch above to use the advanced settings", icon='INFO')
        return

    # 激活态: 模式胶囊行(画在参数区上方) + 参数区
    header_row = body.row(align=True)
    header_row.scale_y = 1.2
    for mode_value, label in _ADVANCED_MODE_PILLS:
        pill = header_row.operator(LightAdvancedModeSet.bl_idname, text=label, depress=settings.mode == mode_value)
        pill.mode = mode_value

    setup_param_box(body)
    col = body.column()
    module = col
    if emission_occupied(light):
        # 用户手动接线不阻断接管(触碰任一控件即恢复插件线), 面板只提示
        warning = col.row()
        warning.enabled = False
        warning.label(text="Hand wiring detected on the Emission node", icon='INFO')
    if settings.mode == 'GRADIENT':
        if light.type not in {'AREA', 'SPOT'}:
            module.label(text="Switch the light to an area or spot light", icon='INFO')
            return
        _draw_gradient_controls(module, settings, light)
    elif settings.mode == 'IMAGE':
        if light.type not in {'AREA', 'SPOT'}:
            module.label(text="Switch the light to an area or spot light", icon='INFO')
            return
        _draw_image_controls(module, state, light)
    elif settings.mode == 'IES':
        if light.type != 'POINT':
            module.label(text="Switch the light to a point light", icon='INFO')
            return
        _draw_ies_controls(module, state, light)


def _draw_gradient_controls(controls: UILayout, settings, light) -> None:
    """渐变档: 渐变调节区(模式行下方常显, 默认全白) + 分隔线 + 渐变类型(单行) + 组实例参数

    着色开关已取消: 色标恒接 Emission.Color, 每档色标独立常驻(切换不丢).
    """
    ramp = find_advanced_ramp(light, settings.gradient_type)
    if ramp is not None:
        controls.template_color_ramp(ramp, "color_ramp")
    controls.separator(type='LINE')
    type_row = controls.row(align=True)
    type_row.prop(settings, "gradient_type", expand=True)
    group_node = find_advanced_node(light, settings.gradient_type)
    if group_node is not None:
        params = controls.column()
        for socket in group_node.inputs:
            params.prop(socket, "default_value", text=socket.name)


def _draw_external_path_row(controls: UILayout, settings, pick_kind: str) -> None:
    """外部文件路径行: 全宽绘制(不设 use_property_split)+ 清除按钮(常驻, 无路径时置灰)"""
    field = "image_external" if pick_kind == 'IMAGE' else "ies_external"
    row = controls.row(align=True)
    row.use_property_split = False
    row.prop(settings, field, text="")
    clear_col = row.column(align=True)
    clear_col.enabled = bool(getattr(settings, field))
    clear = clear_col.operator(LightAdvancedClearExternal.bl_idname, text="", icon='X')
    clear.pick_kind = pick_kind


def _draw_image_controls(controls: UILayout, state, light) -> None:
    """图像档: 外部文件路径(全宽+清除) + 纹理选择器 + 接线目标胶囊 + 阵列参数 + HSV

    资产未载入(链上图像纹理节点无图)时参数区整体不画: 接线目标/阵列/HSV 在无图时
    无可调对象, 载入后即出现. 无可用资产库时选择器只画提示行, 下方分隔横线也不画.
    """
    settings = light.ch_advanced
    _draw_external_path_row(controls, settings, 'IMAGE')
    if _draw_asset_picker(controls, state, 'IMAGE', external=settings.image_external):
        controls.separator(type='LINE')
    tex = find_advanced_node(light, MARK_IMAGE_TEX)
    if tex is None or tex.image is None:
        return
    target_row = controls.row(align=True)
    target_row.prop(settings, "image_target", expand=True)
    array_group = find_advanced_node(light, MARK_IMAGE_ARRAY)
    if array_group is not None:
        mode_sock = array_group.inputs.get("阵列方式")
        if mode_sock is not None:
            # 组实例缺座(版本不匹配/被手改)按 .get 守卫跳过整组, 与 update 侧同口径不在绘制帧炸
            target_row = controls.row(align=True)
            target_row.prop(settings, "image_array_mode", expand=True)
            params = controls.column()
            # Menu Switch 组按枚举项名读档位, 旧 Mix 组(float 因子)按 0/1 读
            ring = mode_sock.default_value == ARRAY_MODE_RING if mode_sock.type == 'MENU' else mode_sock.default_value > 0.5
            shown = ("阵列数量", "缩放", "半径", "自旋转") if ring else ("阵列X", "阵列Y")
            for socket_name in shown:
                sock = array_group.inputs.get(socket_name)
                if sock is not None:
                    params.prop(sock, "default_value", text=socket_name)
    hsv = find_advanced_node(light, MARK_IMAGE_HSV)
    if hsv is not None and settings.image_target == 'COLOR':
        params = controls.column()
        for socket_name in ("Hue", "Saturation", "Value"):
            sock = hsv.inputs.get(socket_name)
            if sock is None:
                continue
            # 接强度档时图像只作亮度调制, HSV 调节不再需要, 整组不画;
            # Value 的界面文案换系统不持有的原文再自译"明度"(系统 mo 同键优先, 插件词条不生效)
            params.prop(sock, "default_value", text="HSV Value" if socket_name == "Value" else socket_name)


def _draw_ies_controls(controls: UILayout, state, light) -> None:
    """IES 档: 外部文件路径(全宽+清除) + 光域网选择器 + 伽玛参数

    资产未载入(链上 IES 纹理节点无路径)时不画伽玛参数. 无可用资产库时选择器只画
    提示行, 下方分隔横线也不画.
    """
    settings = light.ch_advanced
    _draw_external_path_row(controls, settings, 'IES')
    if _draw_asset_picker(controls, state, 'IES', external=settings.ies_external):
        controls.separator(type='LINE')
    tex = find_advanced_node(light, MARK_IES_TEX)
    if tex is None or not tex.filepath:
        return
    gamma = find_advanced_node(light, MARK_IES_GAMMA)
    if gamma is not None:
        controls.prop(gamma.inputs["Gamma"], "default_value", text="Gamma")


def draw_world_env_body(box: UILayout, context: Context, state) -> None:
    """世界环境设置的模式体: 三档参数(基础/HDRI/程序纹理)

    真值在世界节点树的插件链节点上(面板直绘节点插座, 同灯光高级设置先例); 链未建
    (从未点过模式胶囊, 节点树未被插件接管)时画提示行, 不画参数. 调用方已排除
    无世界/库链接世界两种空态.
    """
    world = context.scene.world
    if find_world_env_node(world, MARK_WORLD_ENV_MIX) is None:
        hint = box.row()
        hint.enabled = False
        hint.label(text="Pick a mode button above to build the environment nodes", icon='INFO')
        return
    setup_param_box(box)
    col = box.column()
    mode = world.ch_env.mode
    if mode == 'BASIC':
        _draw_basic_env_controls(col, world)
    elif mode == 'HDRI':
        _draw_hdri_env_controls(col, state, world)
    elif mode == 'PROCEDURAL':
        _draw_procedural_env_controls(col, world)


def _draw_basic_env_controls(col: UILayout, world) -> None:
    """基础档: 统一背景节点的颜色与强度(直绘节点插座; 强度三档共用同一节点)"""
    bg = find_world_env_node(world, MARK_WORLD_ENV_BG)
    if bg is not None:
        col.prop(bg.inputs["Color"], "default_value", text="Color")
        col.prop(bg.inputs["Strength"], "default_value", text="Strength")


def _draw_world_external_row(controls: UILayout, world) -> None:
    """世界环境的外部图像路径行(全宽绘制 + 清除按钮, 与灯光图像档同口径)"""
    settings = world.ch_env
    row = controls.row(align=True)
    row.use_property_split = False
    row.prop(settings, "env_image_external", text="")
    clear_col = row.column(align=True)
    clear_col.enabled = bool(settings.env_image_external)
    clear = clear_col.operator(LightAdvancedClearExternal.bl_idname, text="", icon='X')
    clear.pick_kind = 'WORLD'


def _world_download_name(asset, root, state) -> str:
    """在线库 HDRI 档的名称行文案: 已下载 = 右侧钮将要载入的文件名, 未下载 = 缩略图名

    文案随分辨率/格式选择实时变化(按选择解析, 不等载入动作), 故与右侧钮的实际载入目标恒一致;
    未下载时回落索引里的缩略图展示名, 不虚报文件名.
    """
    option = resolve_option(asset, state.adv_world_resolution, state.adv_world_format)
    source = existing_source(root, asset, option)
    return os.path.basename(source) if source else asset["name"]


def _draw_hdri_env_controls(col: UILayout, state, world) -> None:
    """HDRI 档: 外部图像路径(全宽+清除) + HDRI 纹理选择器(+ 在线库的下载行) +
    背景强度(第一位) + 环境调节组镜像参数 + 朝向映射旋转

    调节组的 Color 输入被 HDRI 纹理接线接管(颜色来源恒为选中纹理), 不画; 其余接口
    的组实例插座 RNA 不带接口子类型/范围(着色强度等滑条会退化成裸数字), 经 WM 状态
    组的镜像字段绘制: 绘制前把插座真值读进镜像, 改动经 update 统一写回插座(同 PBR
    镜像先例, 直接编辑节点插座语义不进撤销栈); 镜像不挂世界数据块——draw 语境禁写
    ID 类数据块的 idprop(第 29 条实测坑). 资产未载入(链上环境纹理节点无图)时参数区
    整体不画(强度/调节组/旋转在无图时无可调对象), 载入后即出现; 无可用资产库时选择器
    只画提示行, 下方分隔横线也不画.
    """
    _draw_world_external_row(col, world)
    # 在线库把下载行插在缩略图网格与名称标签行之间(作者定), 离线库无附加行;
    # 名称行改显示实际载入的环境纹理文件名(同资产多分辨率时看得出载入的是哪一档)
    online = online_manifest_library('WORLD', state.adv_world_library)
    # 下载行自身按索引三态决定画不画(离线不画,索引损坏画提示); 名称行仅在在线库下换成文件名
    if _draw_asset_picker(col, state, 'WORLD', partial(_draw_world_download_row, state=state), partial(_world_download_name, state=state) if online else None, external=world.ch_env.env_image_external):
        col.separator(type='LINE')
    hdri_tex = find_world_env_node(world, MARK_WORLD_ENV_HDRI_TEX)
    if hdri_tex is None or hdri_tex.image is None:
        return
    bg = find_world_env_node(world, MARK_WORLD_ENV_BG)
    if bg is not None:
        col.prop(bg.inputs["Strength"], "default_value", text="Strength")
    setting = find_world_env_node(world, MARK_WORLD_ENV_HDRI_SETTING)
    if setting is not None:
        with _suppress_env_mirror():
            for field, socket_name in _ENV_FIELD_SOCKETS:
                sock = setting.inputs.get(socket_name)
                if sock is not None:
                    setattr(state, field, sock.default_value)
        for field, socket_name in _ENV_FIELD_SOCKETS:
            col.prop(state, field, text=socket_name)
    mapping = find_world_env_node(world, MARK_WORLD_ENV_HDRI_MAP)
    if mapping is not None:
        # 欧拉插座(NodeSocketVectorEuler)直绘自带角度单位; 欧拉整控在 property-split
        # 下会拆成三竖行, 改三分量 index prop 组合行(首个 prop 带标签占左列, 三滑条
        # 在右列横排一行, 同相机设置的 Clip 行机制)
        rot_row = col.row(align=True)
        rot_row.prop(mapping.inputs["Rotation"], "default_value", text="Rotation", index=0)
        rot_row.prop(mapping.inputs["Rotation"], "default_value", text="", index=1)
        rot_row.prop(mapping.inputs["Rotation"], "default_value", text="", index=2)


def _draw_procedural_env_controls(col: UILayout, world) -> None:
    """程序纹理档: 背景强度(第一位) + 天空纹理参数(按类型分组, 与原生节点面板同口径)"""
    bg = find_world_env_node(world, MARK_WORLD_ENV_BG)
    if bg is not None:
        col.prop(bg.inputs["Strength"], "default_value", text="Strength")
    sky = find_world_env_node(world, MARK_WORLD_ENV_SKY_TEX)
    if sky is not None:
        col.prop(sky, "sky_type")
        if sky.sky_type in {'SINGLE_SCATTERING', 'MULTIPLE_SCATTERING'}:
            col.prop(sky, "sun_disc")
            if sky.sun_disc:
                col.prop(sky, "sun_size")
                col.prop(sky, "sun_intensity")
            col.prop(sky, "sun_elevation")
            col.prop(sky, "sun_rotation")
            col.prop(sky, "altitude")
            col.prop(sky, "air_density")
            col.prop(sky, "aerosol_density")
            col.prop(sky, "ozone_density")
        else:
            col.prop(sky, "sun_direction")
            col.prop(sky, "turbidity")
            if sky.sky_type == 'HOSEK_WILKIE':
                col.prop(sky, "ground_albedo")


def draw_world_replace_body(box: UILayout, context: Context, state) -> None:
    """替换背景子面板的模式体: 纯色/渐变档位 + 颜色参数 + 替换背景强度

    开关未激活(链未建或分流 Switch 为关)时只画需激活提示行, 不画参数 UI(作者定);
    档位真值双写(镜像枚举 + SWITCH_RepMode 切换接口), 颜色真值在节点上直绘
    (纯色 = Color RGB 节点, 渐变 = Color Ramp 两端色标), 强度两档共用同一节点.
    """
    world = context.scene.world
    bg_switch = find_world_env_node(world, MARK_WORLD_ENV_REPLACE_SWITCH)
    if bg_switch is None or not bool(bg_switch.inputs["Switch"].default_value):
        hint = box.row()
        hint.enabled = False
        hint.label(text="Toggle the switch above to enable the replacement background", icon='INFO')
        return
    setup_param_box(box)
    col = box.column()
    settings = world.ch_env
    # 纯色/渐变两枚胶囊(独立 row 包裹保证横排一行; 直进 use_property_split 的列会
    # 被左列标签挤压竖排)
    pill_row = col.row(align=True)
    pill_row.prop(settings, "replace_mode", expand=True)
    if settings.replace_mode == 'SOLID':
        solid = find_world_env_node(world, MARK_WORLD_ENV_REPLACE_COLOR)
        if solid is not None:
            col.prop(solid.outputs[0], "default_value", text="Color")
    else:
        ramp = find_world_env_node(world, MARK_WORLD_ENV_REPLACE_RAMP)
        if ramp is not None and len(ramp.color_ramp.elements) >= 2:
            col.prop(ramp.color_ramp.elements[0], "color", text="Ground Color")
            col.prop(ramp.color_ramp.elements[1], "color", text="Sky Color")
    replace_bg = find_world_env_node(world, MARK_WORLD_ENV_REPLACE_BG)
    if replace_bg is not None:
        col.prop(replace_bg.inputs["Strength"], "default_value", text="Strength")


# 资产选择器四档(图像纹理/IES/世界环境 HDRI/PBR 材质)的共用映射
_PICKER_STATE_PREFIXES = {'IMAGE': 'image', 'IES': 'ies', 'WORLD': 'world', 'PBR': 'pbr'}
_PICKER_LIBRARY_MENUS = {'IMAGE': LightAssetLibraryMenuImage, 'IES': LightAssetLibraryMenuIES, 'WORLD': LightAssetLibraryMenuWorld, 'PBR': LightAssetLibraryMenuPBR}
_PICKER_CATEGORY_MENUS = {'IMAGE': LightAssetCategoryMenuImage, 'IES': LightAssetCategoryMenuIES, 'WORLD': LightAssetCategoryMenuWorld, 'PBR': LightAssetCategoryMenuPBR}


# 在线库下载行的分档配置: 规格菜单 / 下载与取消算子 / 未选中提示(文案单源 = asset_online._PICK_HINTS)
_ONLINE_ROW_SPECS = {
    'WORLD': {
        "resolution_menu": WorldHDRIResolutionMenu,
        "format_menu": WorldHDRIFormatMenu,
        "download": WorldHDRIDownload,
        "cancel": WorldHDRIDownloadCancel,
        "pick_hint": _PICK_HINTS['WORLD'],
    },
    'PBR': {
        "resolution_menu": PBRMaterialResolutionMenu,
        "format_menu": PBRMaterialFormatMenu,
        "download": PBRMaterialDownload,
        "cancel": PBRMaterialDownloadCancel,
        "pick_hint": _PICK_HINTS['PBR'],
    },
}


def _draw_world_download_row(col: UILayout, state) -> None:
    """世界环境 HDRI 档的下载行(实现在 _draw_online_download_row, 保留入口供面板与用例取用)"""
    _draw_online_download_row(col, state, 'WORLD')


def _draw_online_download_row(col: UILayout, state, kind: str) -> None:
    """在线库下载行: 分辨率下拉 + 格式下拉 + 状态件

    第三件只承担状态与下载触发(加载由缩略图名称行右侧钮完成, 作者定): 未下载 = 下载钮,
    下载中 = 进度与取消钮, 已下载 = DOWNLOAD_DONE 置灰钮 + 打开所在文件夹小钮; 失败在下方画错误行.
    无索引/未选中缩略图/无下载规格各画提示行. 世界环境 HDRI 档与 PBR 材质档共用本实现,
    差异只在规格菜单与算子(见 _ONLINE_ROW_SPECS).
    """
    spec = _ONLINE_ROW_SPECS[kind]
    prefix = kind.lower()
    root = resolve_library_root(kind, getattr(state, "adv_{}_library".format(prefix)))[0]
    if not root:
        return
    index_state = manifest_state(root)
    if index_state == 'OFFLINE':
        return
    if index_state == 'BROKEN':
        hint = col.row()
        hint.enabled = False
        hint.label(text="The asset library index is broken, check manifest.json", icon='ERROR')
        return
    # 条目解析走共用实现(先备候选表再读选中键, 空候选不读动态枚举)
    _, asset = picked_asset_of(state, kind)
    if asset is None:
        hint = col.row()
        hint.enabled = False
        hint.label(text=spec["pick_hint"], icon='INFO')
        return
    fields = ONLINE_SPEC_FIELDS[kind]
    option = resolve_option(asset, getattr(state, fields[0], ""), getattr(state, fields[1], ""))
    if option is None:
        hint = col.row()
        hint.enabled = False
        hint.label(text="No download spec for this asset", icon='ERROR')
        return
    row = col.row(align=True)
    size = size_text(option["size"])
    row.menu(spec["resolution_menu"].bl_idname, text="{} ({})".format(option["res"], size) if size else option["res"])
    row.menu(spec["format_menu"].bl_idname, text=option["fmt"])
    job = download_state(archive_path(root, asset, option))
    phase = job["phase"] if job else ""
    if phase in ('DOWNLOAD', 'EXTRACT'):
        _draw_download_progress(row, job, spec["cancel"])
    elif existing_source(root, asset, option):
        done = row.row(align=True)
        done.enabled = False
        done.operator(spec["download"].bl_idname, text="", icon='DOWNLOAD_DONE')
        # 已下载态旁的"打开所在文件夹"钮(单文件型=源目录, 包型=该分辨率的贴图目录)
        row.operator(OnlineOpenFolder.bl_idname, text="", icon='FILE_FOLDER').pick_kind = kind
    else:
        # 全局单任务: 其它目标下载中时本钮置灰(不排队); 索引缺链接时也不可点
        busy = has_active_download()
        sub = row.row(align=True)
        sub.enabled = not busy and bool(option.get("url"))
        sub.operator(spec["download"].bl_idname, text="", icon='DOWNLOAD')
        if busy:
            # 切了规格后当前档查不到任务: 留一个取消入口(全局单任务, 取消的就是进行中的那个)
            row.operator(spec["cancel"].bl_idname, text="", icon='X')
    if phase == 'ERROR' and job["error"]:
        error_row = col.row()
        error_row.alert = True
        error_row.label(text="{} ({})".format(iface(_DOWNLOAD_ERROR_TEXTS.get(error_kind(job["error"]), "Download failed")), job["error"][:64]), icon='ERROR')


def _draw_download_progress(row: UILayout, job, cancel_op=WorldHDRIDownloadCancel) -> None:
    """下载进度件: 进度条 + 取消钮"""
    factor = job["factor"]
    if job["phase"] == 'EXTRACT':
        text = iface("Extracting")
    else:
        text = iface("Downloading {}").format("{:.0f}%".format(factor * 100.0))
    # UILayout.progress 自 3.5 起存在, 5.3 最低版本下恒可用(旧回落分支已随版本基线清零)
    row.progress(text=text, factor=factor)
    row.operator(cancel_op.bl_idname, text="", icon='X')


def _draw_asset_picker(col: UILayout, state, pick_kind: str, extra_row=None, label_of=None, external: str = "", apply_op=None) -> bool:
    """资产选择器(图像纹理/IES/世界环境/PBR 材质四档共用): 资产库与分类行(两枚下拉菜单 +
    行尾两枚共用开关) + 缩略图行(左右钮循环应用 + 图标网格) + 附加行 + 选中名标签;
    返回是否有可用资产库——无库时只画一行提示, 调用方据此跳过下方的分隔横线

    根目录取面板选中的资产库(偏好里按用途启用), 选中失效时回落该用途首个可用库.
    库名与分类名都是运行期才知道的中文: 走菜单钮文本(翻译链安全), 网格条目名称不进动态枚举
    (非 ASCII 会乱码, 图标即条目身份; 悬停说明留空).
    行尾开关: 自动应用(关闭时点选/循环只改选中项, 落地走名称行右侧钮)与仅显示现有源文件
    (关闭时源缺失的缩略图也入列, 选中后名称标红且右侧钮置灰——外部路径非空时该钮仍可点,
    见 external; 在线库按"该资产已有规格落盘"判定, 便于只看已下载过的条目).
    extra_row: 网格与名称行之间的附加行(在线库的下载行; 接收布局的回调, 无则跳过).
    label_of: 名称行文案回调(接收条目与库根; 无则按"源文件名, 缺源用条目名").
    external: 当前档的外部文件路径(图像/IES/世界环境三档同口径; PBR 材质档为资产包目录,
    无单文件外部路径语义, 恒传空串). 非空时刷新钮恒可点——它按"外部路径优先"
    重载该文件, 与缩略图源是否存在无关; 缺了这条判据会把这个唯一的手动入口置灰.
    apply_op: 名称行右侧应用钮的算子类(无则用来源刷新算子; PBR 材质档传导入资产包算子).
    缩略图尺寸与放大镜弹窗的放大系数取偏好(asset_thumb_size / asset_thumb_popup_factor,
    两选择器共用). 无可用库/无分类/无缩略图各画提示行.
    """
    prefix = _PICKER_STATE_PREFIXES[pick_kind]
    root, library_name = resolve_library_root(pick_kind, getattr(state, f"adv_{prefix}_library"))
    if not root:
        hint = col.row()
        hint.enabled = False
        hint.label(text="Add an asset library in the addon preferences", icon='PREFERENCES')
        return False
    online = online_manifest_library(pick_kind, getattr(state, f"adv_{prefix}_library"))
    # 资产库钮恒先画(库内无分类时仍可切到别的库), 分类钮在其右侧
    row = col.row(align=True)
    library_menu = _PICKER_LIBRARY_MENUS[pick_kind]
    row.menu(library_menu.bl_idname, text=library_name, icon='FILE_FOLDER')
    categories = list_categories(root, online, pick_kind)
    current = resolve_category(categories, getattr(state, f"adv_{prefix}_category", ""))
    if categories:
        category_menu = _PICKER_CATEGORY_MENUS[pick_kind]
        row.menu(category_menu.bl_idname, text=current)
    # 行尾两枚共用开关(三选择器同一份状态): 自动应用 / 仅显示现有源文件
    toggles = row.row(align=True)
    toggles.prop(state, "adv_auto_apply", text="", icon='UV_SYNC_SELECT', toggle=True)
    toggles.prop(state, "adv_hide_missing_source", text="", icon='DISK_DRIVE', toggle=True)
    if not categories:
        hint = col.row()
        hint.enabled = False
        hint.label(text="No category folders in this asset library", icon='INFO')
        return True

    assets = list_assets(root, current, pick_kind, state.adv_hide_missing_source, online)
    if not assets:
        hint = col.row()
        hint.enabled = False
        hint.label(text="No thumbnails in this category", icon='IMAGE_DATA')
        return True
    prefs = get_prefs()
    scale = prefs.asset_thumb_size
    thumb_row = col.row(align=True)
    # 循环钮包进同系数拉伸的列, 与缩略图网格绘制高度一致(系数同源偏好尺寸)
    left_col = thumb_row.column(align=True)
    left_col.scale_y = scale
    op = left_col.operator(LightAssetThumbCycle.bl_idname, text="", icon='TRIA_LEFT')
    op.pick_kind = pick_kind
    op.is_next = False
    # 放大镜弹窗的格子 = 行内格子 x 偏好放大系数(两选择器共用)
    thumb_row.template_icon_view(state, f"adv_{prefix}_pick", show_labels=False, scale=scale, scale_popup=scale * prefs.asset_thumb_popup_factor)
    right_col = thumb_row.column(align=True)
    right_col.scale_y = scale
    op = right_col.operator(LightAssetThumbCycle.bl_idname, text="", icon='TRIA_RIGHT')
    op.pick_kind = pick_kind
    op.is_next = True
    # 网格与名称行之间的附加行(世界环境在线库的下载行)
    if extra_row is not None:
        extra_row(col)
    picked_key = getattr(state, f"adv_{prefix}_pick", "")
    picked_asset = next((asset for asset in assets if asset["key"] == picked_key), None)
    if picked_asset is not None:
        if online:
            # 在线库条目 source 恒空: 可按当前分辨率/格式已落盘的源文件(或贴图目录)应用,
            # 未下载则只作选中(下载行显示状态); 未下载不算异常, 名称不标红. 规格字段按
            # 资产种类映射取(见 scene_state.ONLINE_SPEC_FIELDS)
            fields = ONLINE_SPEC_FIELDS.get(pick_kind)
            option = resolve_option(picked_asset, getattr(state, fields[0], ""), getattr(state, fields[1], "")) if fields else None
            has_source = bool(existing_source(root, picked_asset, option))
        else:
            has_source = bool(picked_asset["source"])
        # 源缺失条目不能应用: 名称标红, 右侧钮置灰(自动应用开关关闭时这就是唯一落地入口);
        # 外部路径非空时该钮仍可点(执行侧按外部路径优先重载, 不看缩略图源)
        label_row = col.row(align=True)
        label_row.alert = not has_source and not online
        label_row.label(text=label_of(picked_asset, root) if label_of is not None else (picked_asset["source_name"] or picked_asset["name"]))
        apply_col = label_row.column(align=True)
        apply_col.enabled = has_source or bool(external)
        refresh = apply_col.operator((apply_op or LightAdvancedRefreshSource).bl_idname, text="", icon='FILE_REFRESH')
        refresh.pick_kind = pick_kind
    return True


def draw_camera_settings(box: UILayout, obj, context: Context) -> None:
    """相机设置: Independent Resolution -> Lens -> Clip -> Sensor -> Safe Areas -> Background Images -> DOF

    传物体而非相机数据: 独立分辨率属性组挂在物体上(随 .blend 保存).
    """
    cam = obj.data
    setup_param_box(box)
    # 独立分辨率: 每相机独立的输出分辨率, 该相机为场景相机时覆写场景输出(镜头行上方);
    # 开关用 prop 绘制以参与 use_property_split 两列布局(operator 按钮会占满整行),
    # 开启时的初始化与即时同步走属性 update 回调(props.on_camera_resolution_update)
    col = box.column()
    settings = obj.ch_resolution
    row = col.row(heading="Independent Resolution")
    row.prop(settings, "use_independent", text="")
    sub_col = row.column(align=True)
    sub_col.active = settings.use_independent
    sub_col.prop(settings, "res_x", text="X")
    sub_col.prop(settings, "res_y", text="Y")

    row = col.row(align=True)
    row.prop(cam, "lens_unit")
    if cam.lens_unit == 'MILLIMETERS':
        row.prop(cam, "lens")
    else:
        row.prop(cam, "angle")

    row = col.row(align=True)
    row.prop(cam, "clip_start", text="Clip")
    row.prop(cam, "clip_end", text="")

    col = col.column()
    col.prop(cam, "sensor_width", text="Sensor")
    col.prop(cam, "show_safe_areas", text="Safe Areas")
    col.prop(cam, "show_background_images", text="Background Images")

    col.prop(cam.dof, "use_dof", text="DOF")
    if cam.dof.use_dof:
        col.row().prop(cam.dof, "focus_object")
        row = col.row()
        row.active = cam.dof.focus_object is None
        row.prop(cam.dof, "focus_distance")
        # 取景器算子的路径以 context.scene.camera 为落点: 面板活动相机不是场景相机时
        # 画出来会改到另一台相机的焦点距离, 故只在两者一致时提供.
        scene_camera = context.scene.camera
        if scene_camera is not None and scene_camera.data == cam:
            op = row.operator("ui.eyedropper_depth", icon='EYEDROPPER', text="")
            op.prop_data_path = 'scene.camera.data.dof.focus_distance'
        col.row().prop(cam.dof, "aperture_fstop")
