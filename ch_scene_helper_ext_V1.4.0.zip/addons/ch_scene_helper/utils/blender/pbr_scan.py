"""
PBR 材质扫描模块

把"普通 PBR 材质"识别成模板可用的通道表: **扫全树的图像纹理节点**, 按**图像数据块名称**
反查通道组(作者定口径: 不看文件路径与后缀, 也不分词——名称与别名都压掉分隔符后做子串匹配,
见 pbr_convention.match_alias_in_name), 之后由 pbr_material.rebuild_channels 整树重建.

为什么不追接口: 模板本身覆盖 16 个通道, 全树扫描能把发光/Alpha/IOR/透射/次表面等一并按名
重建(比"只认 5 个接口"更完整), 且不必处理分支/节点组/上游歧义; 代价是"这张图接在哪"这层
约束没有了, 故用两条规则兜底:
- **输出没连线的图也收**(作者的 AO 图常只接 Vector,Color 不接), 但**同通道内已连线的图优先**占位
- **同一通道多张图时只取一张**, 其余在 duplicates 里列名, 由调用方提示

主要功能:
- scan_material: 全树扫描 + 名称归组 + 冲突裁决 + 法线朝向 + 取回原置换节点参数

未连接(output 无连线)但按名称纳入的图记在 loose 里(供调用方与用例核对); 它们只在没有已连线
同通道图时才会占位. 名称未命中任何别名(含 ORM 整词)的图记在 unmatched 里(初始化拒绝时
列给用户, 便于按名改判定).
"""

from .pbr_convention import _name_tokens, match_alias_in_name, normal_direction_in_name

# 合并通道图的整词标记(ORM / MRAO / ARM / MR): 这类图通常不含"金属/粗糙"别名,
# 按作者定作为金属度与粗糙度的共同来源(模板会把整图分别喂进两条链);
# 只按整词命中, 词内巧合(platform / warm / armchair)不算
ORM_TOKENS = ("orm", "mrao", "arm", "mr")

# 冲突裁决(与资产包导入同口径): 同义通道同在时只留前一个
_EXCLUSIVE = (("roughness", "glossiness"), ("normal", "bump"))


def _connected(node) -> bool:
    """图像节点是否有任何输出连线: 有连线者优先占位(未连线的仍按名称纳入, 见 scan_material)"""
    return any(socket.is_linked for socket in node.outputs)


def scan_material(mat) -> dict:
    """扫描材质节点树, 返回通道表与可报告项

    Returns:
        {
          "channels": {组键: {"image": Image, "node": 图像节点, "alias": 命中别名, "name": 数据块名}},
          "duplicates": [数据块名],          # 同通道的第 2..n 张图(未采用)
          "loose": [数据块名],               # 按名称纳入,但 output 没连线的图(常见: AO 只接 Vector)
          "dropped": [数据块名],             # 识别到了但配对不成立而剔除(如 AO 无基础色)
          "unmatched": [数据块名],           # 名称未命中任何别名(含 ORM 整词)的图
          "normal_direction": "DX" | "GL",   # 法线朝向(按名称关键字判定, 无关键字按 GL)
          "displacement": {"midlevel", "scale"} | None,   # 原置换节点参数(重建后沿用)
        }
    无节点树/无可用贴图时 channels 为空, 由调用方按"无法重建"提示.
    """
    result = {"channels": {}, "duplicates": [], "loose": [], "dropped": [], "unmatched": [], "displacement": None, "normal_direction": "GL"}
    tree = None if mat is None else mat.node_tree
    if tree is None:
        return result

    candidates = []
    for node in tree.nodes:
        if node.type == 'TEX_IMAGE':
            image = node.image
            if image is None:
                continue
            group, alias = match_alias_in_name(image.name)
            if group is None:
                # 合并通道图: 名称里要有独立的 orm/mrao/arm/mr 词(与别名匹配同口径),
                # 同时作为金属度与粗糙度的来源(两条链各自吃整图)
                groups = ["metallic", "roughness"] if set(_name_tokens(image.name)) & set(ORM_TOKENS) else []
                alias = "orm"
            else:
                groups = [group]
            if not groups:
                # 未命中任何别名(含 ORM 整词): 记名供拒绝提示, 让用户知道改哪张图的名字
                if image.name not in result["unmatched"]:
                    result["unmatched"].append(image.name)
                continue
            candidates.append(
                {
                    "image": image,
                    "node": node,
                    "alias": alias,
                    "name": image.name,
                    "groups": groups,
                    "connected": _connected(node),
                }
            )
        elif node.type == 'DISPLACEMENT' and result["displacement"] is None:
            # 整树重建会清掉原置换节点: 先把中间值/缩放记下来, 重建后按这两值恢复观感
            result["displacement"] = {
                "midlevel": float(node.inputs["Midlevel"].default_value),
                "scale": float(node.inputs["Scale"].default_value),
            }

    # 已连线的图先占位(output 有连线说明它真在供数据), 未连线的(常见: AO 只接 Vector)再补空位
    for entry in sorted(candidates, key=lambda candidate: not candidate["connected"]):
        for key in entry["groups"]:
            if key in result["channels"]:
                if entry["name"] not in result["duplicates"]:
                    result["duplicates"].append(entry["name"])
                continue
            result["channels"][key] = {"image": entry["image"], "node": entry["node"], "alias": entry["alias"], "name": entry["name"]}
            if not entry["connected"] and entry["name"] not in result["loose"]:
                result["loose"].append(entry["name"])

    # 冲突裁决: roughness 优先于 glossiness, normal 优先于 bump
    for keep, drop in _EXCLUSIVE:
        if keep in result["channels"]:
            result["channels"].pop(drop, None)
    # AO 是"乘进基础色"的支路: 没有基础色时链建了也没效果(混算 A 默认黑会吞掉颜色), 与导入侧同口径剔除
    if "ao" in result["channels"] and "base_color" not in result["channels"]:
        result["dropped"].append(result["channels"].pop("ao")["name"])
    # 法线朝向: 按法线图名称里的 dx/directx/gl/opengl 关键字判定, 没有关键字按 OpenGL(不翻转)
    normal = result["channels"].get("normal")
    if normal is not None:
        result["normal_direction"] = normal_direction_in_name(normal["name"])
    return result
