"""
布尔修改器操作模块

为活动对象添加布尔修改器,支持多种布尔方法和求解器.

操作流程:
1. 选择活动对象和切割对象
2. 调用操作器
3. 调整布尔方法和求解器
4. 确认或取消操作

支持的选项:
- Method: 布尔方法 (DIFFERENCE/UNION/INTERSECT/SPLIT)
- Solver: 求解器 (FLOAT/EXACT/MANIFOLD)

快捷键:
- 滚轮: 切换布尔方法
- S: 切换求解器
- LMB/SPACE/RET/NUMPAD_ENTER: 完成操作
"""

__all__ = ["AddBooleanMod", "ApplyBooleanMod"]

import bpy
import logging
from bpy.props import EnumProperty, BoolProperty, StringProperty
from bpy.types import Operator, Context, Event, Object
from uuid import uuid4

from .....common.i18n.i18n import iface, report

from ...items import boolean_method_items, boolean_solver_items, mod_apply_mode_items
from ...utils import (
    draw_status_item,
    navigation_passthrough,
    scroll,
    scroll_up,
    step_enum,
    force_ui_update,
    get_collection,
    add_boolean_modifier,
    add_displace_modifier,
    remove_modifier,
    set_object_parent,
    clear_object_parent,
)
from ...modal_base import ModalOperatorMixin

_logger = logging.getLogger(__name__)

# F9 重做会用**新实例**再次 execute, 实例内列表(boolean_modifiers 等)已丢失;
# 故在目标物体上记录本次 run_id 与创建的修改器名, 重做时按记录先清掉上一次结果.
_BOOLEAN_RUN_PROP = "ch_boolean_run"
_BOOLEAN_MODS_PROP = "ch_boolean_mods"
_BOOLEAN_TEMP_PROP = "ch_boolean_temp"


def _remove_run_temporaries(act_obj: Object, run_id: str) -> None:
    """移除同一 run_id 上一次执行留下的修改器与临时对象(F9 重做前调用)

    只处理带本算子记录的数据块: 新建一次布尔(新 run_id)不会动到上一次操作的结果.
    Modifier 不是 ID 类型(不支持自定义属性), 故修改器名记在目标物体的自定义属性里.
    """
    if act_obj.get(_BOOLEAN_RUN_PROP) == run_id:
        names = {name for name in str(act_obj.get(_BOOLEAN_MODS_PROP, "")).split("\n") if name}
        for mod in list(act_obj.modifiers):
            if mod.name not in names:
                continue
            cutter = mod.object
            remove_modifier(mod)
            if cutter is not None and cutter.name in bpy.data.objects:
                clear_object_parent(cutter)
                cutter.display_type = 'TEXTURED'

    for obj in list(bpy.data.objects):
        if obj.get(_BOOLEAN_TEMP_PROP) == run_id:
            bpy.data.objects.remove(obj, do_unlink=True)


# ============================================================
# 添加布尔修改器操作器
# ============================================================
class AddBooleanMod(Operator, ModalOperatorMixin):
    """
    布尔修改器操作器

    功能: 为活动对象添加布尔修改器
    - 支持多种布尔方法 (DIFFERENCE/UNION/INTERSECT/SPLIT)
    - 支持多种求解器 (FLOAT/EXACT/MANIFOLD)

    要求: 物体模式下有活动网格对象和至少一个选中的切割对象
    """

    bl_idname = "ch.add_boolean_mod"
    bl_label = "Add Boolean Modifier"
    bl_description = "Add Boolean Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    method: EnumProperty(name="Method", items=boolean_method_items, default='DIFFERENCE', description="Boolean operation applied to the operands")  # type: ignore
    solver: EnumProperty(name="Solver", items=boolean_solver_items, default='FLOAT', description="Boolean solver implementation")  # type: ignore
    set_parent: BoolProperty(name="Set Parent", default=True, description="Parent the result to the active object")  # type: ignore

    # 本次运行标识: invoke 生成, F9 重做沿用同一值; 用于识别并替换上一次执行的结果
    run_id: StringProperty(options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'OBJECT':
            return

        act_obj = context.active_object
        if not act_obj or act_obj.type != 'MESH':
            return

        return any(obj != act_obj and obj.type == 'MESH' for obj in context.selected_objects)

    def invoke(self, context: Context, event: Event):
        self.boolean_modifiers = []
        self.created_objects = []
        self.intersect_objs = []
        self.boolean_objs = []
        self.run_id = uuid4().hex

        self.execute(context)

        self.init_status(context, func=_draw_boolean_status(self))
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 最小收敛并退出, 否则每个后续事件都抛 AttributeError 且模态永不收敛
            self._abort_without_area(context)
            return {'CANCELLED'}

        try:
            return self._modal_impl(context, event)
        except Exception:
            # 模态中途中断(如 undo 释放修改器后 remove_modifier 抛 ReferenceError):
            # 只收敛状态栏与处理器, 避免被残留回调永久占据; 数据残留交给撤销
            _logger.exception("Boolean modal failed")
            self._cleanup(context)
            return {'CANCELLED'}

    def _modal_impl(self, context: Context, event: Event):
        context.area.tag_redraw()

        if scroll(event):
            direction = 1 if scroll_up(event) else -1
            self.method = step_enum(self.method, boolean_method_items, direction)
            self._cleanup_previous()
            self._apply_boolean(context)

        elif event.type == 'S' and event.value == "PRESS":
            self.solver = step_enum(self.solver, boolean_solver_items)
            self._cleanup_previous()
            self._apply_boolean(context)

        elif navigation_passthrough(event):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            return self._complete_and_link(context)

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            # 必须限定 PRESS: Alt+RMB 导航穿透后松开(RMB RELEASE)不得误触取消
            return self._cancel(context)

        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        if not hasattr(self, 'boolean_modifiers'):
            self.boolean_modifiers = []
            self.created_objects = []
            self.intersect_objs = []
            self.boolean_objs = []
        else:
            # invoke -> execute 同实例续跑: 先回收本次已建对象(与模态改参数同路径)
            self._cleanup_previous()

        context.view_layer.update()
        self.act_obj = context.active_object
        # 直调(EXEC_DEFAULT)没有 invoke 生成标识, 视为一次全新的操作
        if not self.run_id:
            self.run_id = uuid4().hex
        # F9 重做: 同一 run_id 上一次的结果先移除, 否则新旧两套修改器/拆分对象同时存在
        _remove_run_temporaries(self.act_obj, self.run_id)
        self.sel_objs = [obj for obj in context.selected_objects if obj != self.act_obj and obj.type == 'MESH']
        self.sel_objs_count = len(self.sel_objs)

        self._apply_boolean(context)
        # 记录本次结果, 供 F9 重做时识别并替换(见 _remove_run_temporaries).
        # 库链接物体不可写自定义属性(RuntimeError), 且 run_id 无法持久化到 .blend,
        # 对它们跳过标记: F9 重做识别本就不适用, 但不能让标记失败中断一次已完成的布尔.
        if getattr(self.act_obj, "library", None) is None:
            self.act_obj[_BOOLEAN_RUN_PROP] = self.run_id
            self.act_obj[_BOOLEAN_MODS_PROP] = "\n".join(mod.name for mod in self.boolean_modifiers)

        return {'FINISHED'}

    def _cleanup_previous(self):
        """清理之前的布尔操作"""
        for mod in self.boolean_modifiers:
            remove_modifier(mod)
        self.boolean_modifiers.clear()

        for obj in self.created_objects:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        self.created_objects.clear()
        self.intersect_objs.clear()
        self.boolean_objs.clear()

        for obj in getattr(self, 'sel_objs', ()):
            if obj.name not in bpy.data.objects:
                continue
            obj.display_type = 'TEXTURED'
            clear_object_parent(obj)

    def _apply_boolean(self, context: Context):
        """应用布尔操作"""
        method_handlers = {
            'INTERSECT': self._intersect,
            'UNION': self._union,
            'DIFFERENCE': self._difference,
            'SPLIT': self._split,
        }
        method_handlers[self.method](context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "method", expand=True)
        layout.prop(self, "solver", expand=True)
        layout.prop(self, "set_parent")

    def _setup_boolean_cutter(self, target_obj: Object, cutter_obj: Object, method: str, mod_name: str):
        """
        设置布尔切割对象

        Args:
            target_obj: 目标对象(布尔操作的主体)
            cutter_obj: 切割对象
            method: 布尔方法
            mod_name: 修改器名称
        """
        boolean_mod = add_boolean_modifier(target_obj, cutter_obj, method=method, solver=self.solver)
        boolean_mod.name = mod_name
        self.boolean_modifiers.append(boolean_mod)
        cutter_obj.display_type = 'WIRE'

        if self.set_parent:
            set_object_parent(cutter_obj, target_obj)

    def _duplicate_object(self, obj: Object, name: str, parent: Object | None = None) -> Object:
        """
        复制对象并设置基本属性

        Args:
            obj: 源对象
            name: 新对象名称
            parent: 父级对象(可选)

        Returns:
            复制的新对象
        """
        new_obj = bpy.data.objects.new(name, obj.data)
        obj.users_collection[0].objects.link(new_obj)
        new_obj[_BOOLEAN_TEMP_PROP] = self.run_id

        if parent:
            set_object_parent(new_obj, parent)
        new_obj.matrix_world = obj.matrix_world

        self.created_objects.append(new_obj)
        return new_obj

    def _intersect(self, context: Context):
        """交集操作"""
        self.boolean_objs = [self.act_obj]

        if self.sel_objs_count > 1:
            for i in range(self.sel_objs_count - 1):
                act_obj_dup = self._duplicate_object(self.act_obj, f"{self.act_obj.name}_dup_{i+1}", self.act_obj.parent)
                self.boolean_objs.append(act_obj_dup)

        for i, (target, cutter) in enumerate(zip(self.boolean_objs, self.sel_objs)):
            self._setup_boolean_cutter(target, cutter, 'INTERSECT', f"Intersect_{i+1}")

    def _union(self, context: Context):
        """并集操作"""
        for i, cutter in enumerate(self.sel_objs):
            self._setup_boolean_cutter(self.act_obj, cutter, 'UNION', f"Union_{i+1}")

    def _difference(self, context: Context):
        """差集操作"""
        for i, cutter in enumerate(self.sel_objs):
            self._setup_boolean_cutter(self.act_obj, cutter, 'DIFFERENCE', f"Difference_{i+1}")

    def _split(self, context: Context):
        """分割操作"""
        for i, cutter in enumerate(self.sel_objs):
            self._setup_boolean_cutter(self.act_obj, cutter, 'DIFFERENCE', f"Difference_{i+1}")

        for i, cutter in enumerate(self.sel_objs):
            act_obj_intersect = self._duplicate_object(self.act_obj, f"{self.act_obj.name}_dup_{i+1}", self.act_obj.parent)

            sel_obj_intersect = self._duplicate_object(cutter, f"{cutter.name}_intersect_{i+1}", act_obj_intersect if self.set_parent else None)

            add_displace_modifier(sel_obj_intersect)
            self.intersect_objs.append(sel_obj_intersect)

            self._setup_boolean_cutter(act_obj_intersect, sel_obj_intersect, 'INTERSECT', f"Intersect_{i+1}")

    def _complete_and_link(self, context: Context) -> set:
        """完成操作(收尾清理 + 把结果物体挂回集合)并返回状态集合.

        注意: 本方法不是约定 10 的 finish 阶段方法(后者只做状态栏/模态处理器/头部文本收敛);
        本算子的 finish 阶段收敛在 _cleanup() 内, 由本方法与 _cancel() 共同调用.
        """
        self._cleanup(context)
        self._link_to_collection(context, self.sel_objs)
        if self.intersect_objs:
            self._link_to_collection(context, self.intersect_objs)
        return {'FINISHED'}

    def _cancel(self, context: Context) -> set:
        """取消操作: 收敛模态 + 回收本次创建, 结果标记一并清除(取消后无重做)"""
        self._cleanup(context)
        self._cleanup_previous()

        act_obj = getattr(self, 'act_obj', None)
        if act_obj is not None and act_obj.name in bpy.data.objects and getattr(act_obj, "library", None) is None:
            for prop in (_BOOLEAN_RUN_PROP, _BOOLEAN_MODS_PROP):
                if act_obj.get(prop) is not None:
                    del act_obj[prop]

        return {'CANCELLED'}

    def _cleanup(self, context: Context):
        """清理资源

        调过 finish_status 者 force_ui_update 必须存在且收尾: 本算子的收敛
        藏在 _cleanup 而非名为 finish 的方法, 漏掉会让取消/异常路径的状态栏停帧
        (hole_extrude 同款实测).
        """
        self.finish_status()
        self.finish_modal_handlers()
        force_ui_update(context)

    def _link_to_collection(self, context: Context, cutters: list[Object]):
        """
        将切割对象链接到布尔集合

        Args:
            context: Blender上下文
            cutters: 切割对象列表
        """
        bcol = get_collection(context, "Boolean_Cutters")

        for obj in cutters:
            if obj.name not in bcol.objects:
                bcol.objects.link(obj)


def _draw_boolean_status(op):
    """返回 Boolean 操作的状态栏绘制回调函数"""

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='MMB_SCROLL', prop=iface(op.method.title()))
        draw_status_item(row, key='S', prop=iface(op.solver.title()))

    return draw


# ============================================================
# 移除或应用布尔修改器操作器
# ============================================================
class ApplyBooleanMod(Operator):
    """
    应用布尔修改器操作器

    功能: 自动应用或移除布尔修改器
    - 支持两种应用模式: 应用/移除
    - 应用模式: 应用布尔修改器, 可选删除切割物体
    - 移除模式: 移除布尔修改器并恢复原始状态, 删除创建的对象, 可选删除切割物体

    要求: 物体模式下有选中物体且存在布尔修改器
    """

    bl_idname = "ch.apply_boolean_mod"
    bl_label = "Apply Boolean Modifier"
    bl_description = "Automatically apply the boolean modifier"
    bl_options = {'REGISTER', 'UNDO'}

    apply_mode: EnumProperty(name="Apply Mode", description="The mode to apply the boolean modifier", items=mod_apply_mode_items, default='APPLY')  # type: ignore
    is_delete_cutter: BoolProperty(name="Delete Cutters", description="Whether to delete the cutter after applying the boolean operation", default=False)  # type: ignore
    is_clear_parent: BoolProperty(name="Clear Parent", description="Whether to clear parent relationship when not deleting cutter", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'OBJECT':
            return

        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for mod in obj.modifiers:
                    if mod.type == 'BOOLEAN':
                        return True

    def execute(self, context: Context):
        context.view_layer.update()

        self.valid_objs = [obj for obj in context.selected_objects if obj.type == 'MESH' and any(mod.type == 'BOOLEAN' and mod.object is not None for mod in obj.modifiers)]
        if not self.valid_objs:
            self.report({'INFO'}, report("No valid objects selected"))
            return {'CANCELLED'}

        mode_handlers = {
            'APPLY': self._apply_boolean_modifiers,
            'REMOVE': self._remove_boolean_modifiers,
        }
        mode_handlers[self.apply_mode](context)

        # 结果已落地(应用/移除), F9 重做标记随之失效, 清除避免永久残留进 .blend
        for obj in self.valid_objs:
            if getattr(obj, "library", None) is None:
                for prop in (_BOOLEAN_RUN_PROP, _BOOLEAN_MODS_PROP):
                    if obj.get(prop) is not None:
                        del obj[prop]

        return {'FINISHED'}

    def _apply_boolean_modifiers(self, context: Context):
        """应用布尔修改器"""
        cutter_objs = []

        for obj in self.valid_objs:
            if obj.data.users > 1:
                obj.data = obj.data.copy()

            # 复制修改器列表, 避免在迭代时修改列表
            boolean_mods = [mod for mod in obj.modifiers if mod.type == 'BOOLEAN' and mod.object is not None]

            for mod in boolean_mods:
                cutter_objs.append(mod.object)
                with context.temp_override(object=obj):
                    bpy.ops.object.modifier_apply(modifier=mod.name)

        self._process_cutters(context, cutter_objs, restore_display=False)

    def _remove_boolean_modifiers(self, context: Context):
        """移除布尔修改器并恢复原始状态"""
        cutter_objs = []
        created_objs = []

        for obj in self.valid_objs:
            boolean_mods = [mod for mod in obj.modifiers if mod.type == 'BOOLEAN' and mod.object is not None]

            for mod in boolean_mods:
                cutter_objs.append(mod.object)
                remove_modifier(mod)

            if self._is_created_object(obj):
                created_objs.append(obj)

        self._delete_created_objects(created_objs)
        self._process_cutters(context, cutter_objs, restore_display=True)

    def _is_created_object(self, obj: Object) -> bool:
        """检查对象是否为布尔操作创建的对象

        以创建时写入的临时标记(_BOOLEAN_TEMP_PROP)为准;
        不再按名字模式兜底——用户物体恰好命名为 *dup_* / *intersect_* 时会被永久误删
        """
        return obj.get(_BOOLEAN_TEMP_PROP) is not None

    def _delete_created_objects(self, created_objs: list[Object]):
        """删除布尔操作创建的对象"""
        for obj in created_objs:
            if obj.name in bpy.data.objects:
                bpy.data.objects.remove(obj, do_unlink=True)

    def _process_cutters(self, context: Context, cutter_objs: list[Object], restore_display: bool):
        """
        处理切割对象

        Args:
            context: Blender上下文
            cutter_objs: 切割对象列表
            restore_display: 是否恢复显示类型为TEXTURED
        """
        if not cutter_objs:
            return

        for cutter in set(cutter_objs):
            if cutter.name not in bpy.data.objects:
                continue

            if self._is_created_object(cutter) or self.is_delete_cutter:
                bpy.data.objects.remove(cutter, do_unlink=True)
            else:
                if restore_display:
                    cutter.display_type = 'TEXTURED'

                if self.is_clear_parent:
                    clear_object_parent(cutter)

                bcol = get_collection(context, "Boolean_Cutters")
                if bcol and cutter.name in bcol.objects:
                    bcol.objects.unlink(cutter)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "apply_mode", expand=True)
        layout.prop(self, "is_delete_cutter")

        col = layout.column()
        col.enabled = not self.is_delete_cutter
        col.prop(self, "is_clear_parent")
