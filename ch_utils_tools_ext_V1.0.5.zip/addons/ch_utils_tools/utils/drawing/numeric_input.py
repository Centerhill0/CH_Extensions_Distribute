"""模态数字输入: 起始判定与缓冲区推进(纯逻辑, 不依赖 bpy)

为三处模态工具(边长/偏移边/孔洞挤出)收口同一套"数字键累加 + 退格 + 小数点"逻辑,
差异只在起始集合是否含 COMMA 与随后如何应用数值. 本模块承载缓冲区操作, 应用侧只保留
"解析数值 -> 调各自 apply"的分支.

数字键事件表以 DIGIT_EVENT_CHARS 定义于本模块, mappings.input_mappings 的数字条目仅此处
消费; 非数字条目(BACK_SPACE/DELETE/PERIOD/COMMA/MINUS 等)无消费方, 不入表 —— 退格与
小数点在下方逻辑中显式处理.

约定:
- numeric_start_value: 事件可作为数字输入起点时返回初始缓冲字符, 否则 None
- feed_numeric: 返回 (新缓冲, 动作), 动作为
  - 'ignore': 非数字按键/非按下事件, 调用方应继续走其它分支
  - 'update': 缓冲已更新(或小数点重复但事件仍应被消费), 调用方解析并应用
  - 'cancel': 退格删到空, 调用方退出数字输入态
"""

# 数字键事件 -> 字符 映射(含小键盘), 原 mappings.input_mappings 的数字子集
DIGIT_EVENT_CHARS = {
    'ONE': "1",
    'TWO': "2",
    'THREE': "3",
    'FOUR': "4",
    'FIVE': "5",
    'SIX': "6",
    'SEVEN': "7",
    'EIGHT': "8",
    'NINE': "9",
    'ZERO': "0",
    'NUMPAD_1': "1",
    'NUMPAD_2': "2",
    'NUMPAD_3': "3",
    'NUMPAD_4': "4",
    'NUMPAD_5': "5",
    'NUMPAD_6': "6",
    'NUMPAD_7': "7",
    'NUMPAD_8': "8",
    'NUMPAD_9': "9",
    'NUMPAD_0': "0",
}
# 基础小数键(边长/偏移边)
DECIMAL_EVENTS = frozenset({'PERIOD', 'NUMPAD_PERIOD'})
# 扩展小数键(孔洞挤出额外接受逗号键, 与部分键盘布局/小键盘一致)
DECIMAL_EVENTS_EXT = frozenset({'PERIOD', 'COMMA', 'NUMPAD_PERIOD', 'NUMPAD_COMMA'})


def numeric_start_value(event, decimal_events=DECIMAL_EVENTS) -> str | None:
    """事件是数字输入起点时返回初始缓冲(数字本身或小数点), 否则 None"""
    if event.value != 'PRESS':
        return None
    if event.type in DIGIT_EVENT_CHARS:
        return DIGIT_EVENT_CHARS[event.type]
    if event.type in decimal_events:
        return "."
    return None


def feed_numeric(buffer: str, event, decimal_events=DECIMAL_EVENTS) -> tuple[str, str]:
    """把事件推进到数字缓冲, 返回 (新缓冲, 动作)

    动作语义见模块 docstring; 非 PRESS 事件一律 'ignore', 避免按键释放重复触发.
    """
    if event.value != 'PRESS':
        return buffer, 'ignore'
    if event.type == 'BACK_SPACE':
        if len(buffer) > 1:
            return buffer[:-1], 'update'
        return buffer, 'cancel'
    if event.type in DIGIT_EVENT_CHARS:
        return buffer + DIGIT_EVENT_CHARS[event.type], 'update'
    if event.type in decimal_events:
        if '.' not in buffer:
            return buffer + '.', 'update'
        # 已有小数点: 不改变缓冲, 但事件仍属数字输入, 调用方照常解析(保持旧行为)
        return buffer, 'update'
    return buffer, 'ignore'
