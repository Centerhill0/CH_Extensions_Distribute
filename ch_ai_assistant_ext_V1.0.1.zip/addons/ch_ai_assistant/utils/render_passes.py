"""
相机视图参考通道提取工具模块(EEVEE 单引擎 · 临时文件中转管线)

以 EEVEE 在一个临时场景中,分三帧渲染场景相机视图, 提取七种参考通道:
- 帧 A(用户世界): 合并结果(Combined)/深度(Depth)/法向(Normal)/漫射颜色(Diffuse Color)/
  AO(Ambient Occlusion), 共享用户世界与相机, 合并结果套用用户色彩管理;
- 帧 B(视层覆盖): 语义分割——新建覆盖材质(Object Info.Random -> White Noise(1D).W ->
  Color -> Material Output.Surface)挂到视图层 Override 的材质覆盖, 并以纯黑世界做世界覆盖,
  输出 Combined 即为每对象一色的分割图;
- 帧 C(场景线条画): 场景级蜡笔(LINEART_SCENE)开启视图层蜡笔通道, **原样**输出 Grease
  Pencil 通道, 白底黑线在 Python 内按 1-alpha 映射(合成器内做算术不可信, 见 _build_capture_group).

落盘机制(5.1.2 实证要点, 详见 memories/blender-compositor-5x-file-output.md):
File Output 节点的 format.media_type 默认是 MULTI_LAYER_IMAGE, 该档下 file_format 被锁死为
OPEN_EXR_MULTILAYER,所有输入并被合并进同一个 .exr; 必须先设 media_type='IMAGE' 才能
逐通道独立指定格式.故本模块"一个通道一个 File Output 节点", 逐通道落盘到
%TEMP%/ch_ai_assistant_pass_capture/<本次唯一目录>/, 读入内存后立即删除:
- 合并结果/漫射颜色 -> JPEG(体积小, 走 Blender 编码), AO/语义分割 -> PNG 8bit,
  这四种通道直接取渲染写出的文件字节;
- 深度/法向 -> 单层 EXR 16bit(需回读原始浮点: 深度背景为 camera.clip_end 远超 1,
  法向是**带符号原始向量**而非 (n+1)/2, 写 LDR 会被钳成 0), 回读后在 numpy 内完成
  映射与编码(深度按用户近/远区间映射为灰阶, 法向按 (n+1)/2 编码, DIRECTX 约定反绿通道);
- 线稿 -> PNG 8bit, 但渲染写出的像素 RGB 恒为 0,笔画信息**全在 alpha**, 故回读 alpha 后
  按 1-alpha 映射为黑线白底再自编码 PNG.
渲染自身不写静帧(write_still=False): 通道文件由 File Output 节点落盘, 与静帧写盘无关,
故一次捕获只产出 7 份通道文件(实测).

用户场景零修改: 临时场景只关联(引用)用户集合/相机/世界, 全部覆写都落在临时场景与临时
视图层上; 语义分割改用材质覆盖后**不再写用户物体的 obj.color**(相对旧实现的净改进);
蜡笔对象经上下文覆写在临时场景内创建并在 finally 中回收, 用户侧的集合成员,选中集与
活动物体均不被改动.

临时文件生命周期(用户 2026-10-10 定论): 每次捕获前先清扫本插件自有临时根目录下的旧目录,
捕获中"渲染写出 -> 读入内存/打包 -> 立即删除", 删除一律尽力而为(Windows 上刚写出的图片
常被杀软实时扫描/索引器/缩略图预览瞬时占用而抛 WinError 32, 短延时重试一次, 仍失败即放弃,
绝不允许打断捕获流程); 只动自家目录, 不碰 %TEMP% 中他人的文件.

主要功能:
- capture_camera_passes: 渲染相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)
- sample_visible_depth: 按相机视锥几何投射采样可见深度, 返回 (近端, 远端, 命中数, 错误信息),
  供面板「深度拾取」一键回填深度范围(不渲染)
"""

import os
import shutil
import struct
import tempfile
import time
import zlib

import numpy as np

import bpy

from .errors import api_error

# 草稿渲染采样(AO 通道 EEVEE 5.1 实证可出数据, 无需切 Cycles)
_EEVEE_SAMPLES = 16
# 钳制长边的防御性硬上限(实际钳制值由偏好里当前服务商的参考图上限决定)
_CLAMP_EDGE_MAX = 8192
# 目标分辨率提醒阈值(公开): 长边超过该值时面板打提醒标签——通道图可能另作他用, 不禁止只提醒
WARN_EDGE_PX = 2048
# 本插件自有临时根目录名(清扫只针对该目录, 绝不触碰 %TEMP% 中他人文件)
_TMP_ROOT_NAME = "ch_ai_assistant_pass_capture"
# JPEG 输出质量(参考图用途, 90 在体积与细节间平衡)
_JPEG_QUALITY = 90
# 自编码 PNG 的 zlib 压缩等级(深度/法向/线稿三个回读通道走自编码)
_PNG_COMPRESS = 6
# 蜡笔线稿基准宽度(世界单位 radius, 作者定标 0.01), 线稿宽度缩放系数乘在其上;
# 自适应换算(按分辨率/视野目标 1.5px)实测产出过细的头发丝线, 作者判定观感倒退已废弃
_EDGE_RADIUS_FALLBACK = 0.01
# 蜡笔 Lineart 修改器 radius 的钳制区间(避免极端场景下线过粗/过细)
_EDGE_RADIUS_MIN = 0.001
_EDGE_RADIUS_MAX = 0.1

# 深度拾取的采样网格(列, 行): 向相机视锥投网格射线取命中深度的分位数作区间锚点(不渲染)
_DEPTH_PICK_GRID = (64, 48)
# 深度拾取的分位锚点(%): 近端 2%,远端 98%——两端各钳掉 2% 极值, 保住主体层次
_DEPTH_PICK_NEAR_PCT = 2.0
_DEPTH_PICK_FAR_PCT = 98.0
# 深度拾取的最少命中数: 低于该值认为没框到几何(如相机对空), 不出区间只报提示
_DEPTH_PICK_MIN_HITS = 8

# 通道参考优先序(与面板排序,提示词通道描述一致; 公开导出供生成期截断与发送顺序共用)
PASS_ORDER = ('combined', 'depth', 'normal', 'segmentation', 'edge', 'diffuse', 'ao')

# 通道落盘规格: 通道键 -> (文件格式, 位深, 是否套用场景色彩管理的 view transform)
#   只有合并结果套 view transform(遵循用户色彩管理, 作者 2026-10-10 定案 A4);
#   其余一律不套: 深度/法向是数据通道(套 view transform 会被压色), 语义分割是必须原值落盘的
#   语义色块, 漫射颜色/AO 是给 AI 看的色彩底图(套用户 look 会整体偏色).
#   注意该标志**必须同时写到 File Output 节点与其 item 上**——item 打开 override_node_format
#   后以 item 自己的 save_as_render 为准(默认 True), 只写节点级会被无视, 见 _add_output_node.
_PASS_FORMATS = {
    'combined': ('JPEG', '8', True),
    'depth': ('OPEN_EXR', '16', False),
    'normal': ('OPEN_EXR', '16', False),
    'diffuse': ('JPEG', '8', False),
    'ao': ('PNG', '8', False),
    'segmentation': ('PNG', '8', False),
    'edge': ('PNG', '8', False),
}

# 文件格式 -> 扩展名(File Output 按 node format 补扩展名, 读回时据此拼路径)
_EXTENSIONS = {'JPEG': '.jpg', 'PNG': '.png', 'OPEN_EXR': '.exr'}

# 帧 A 的通道与来源出线(RLayers 输出名)
_FRAME_A_OUTPUTS = (
    ('combined', 'Image'),
    ('depth', 'Depth'),
    ('normal', 'Normal'),
    ('diffuse', 'Diffuse Color'),
    ('ao', 'Ambient Occlusion'),
)
# 帧 B(语义分割)与帧 C(线稿)的来源出线
_FRAME_B_OUTPUTS = (('segmentation', 'Image'),)
_FRAME_C_OUTPUTS = (('edge', 'Grease Pencil'),)


def _eevee_engine_id() -> str | None:
    """EEVEE 草稿引擎 id: 4.2+ 为 BLENDER_EEVEE_NEXT, 旧版为 BLENDER_EEVEE, 均无则 None

    注意: RenderSettings.engine 的枚举表是惰性维护的(后台加载时只列举当前档),
    故这里不能靠 enum_items 判定可用性, 改为直接尝试赋值探测(见 _is_engine_usable).
    """
    for engine_id in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        if _is_engine_usable(engine_id):
            return engine_id
    return None


def _is_engine_usable(engine_id: str) -> bool:
    """探测引擎在本构建是否可用: 往一个临时场景的 RenderSettings 上尝试赋值

    enum_items 惰性(后台只列举当前档), 故不能靠枚举表判定; 赋值失败必然不可用,
    赋值成功即认为可用(真正的渲染失败仍由捕获期异常兜底转成错误信息).
    """
    tmp = None
    try:
        tmp = bpy.data.scenes.new("CH_AI_EngineProbe")
        tmp.render.engine = engine_id
        return tmp.render.engine == engine_id
    except (TypeError, ValueError):
        return False
    except Exception:  # noqa: BLE001 - 探测场景建不出来等异常一律按不可用处理
        return False
    finally:
        if tmp is not None:
            bpy.data.scenes.remove(tmp)


# ---------------------------------------------------------------- 临时目录

def _tmp_root() -> str:
    """本插件自有临时根目录(所有捕获目录都建在其下, 便于只清扫自家的残留)"""
    return os.path.join(tempfile.gettempdir(), _TMP_ROOT_NAME)


def _drop_path(path) -> None:
    """尽力而为地删除文件/目录: 失败即放弃, 绝不影响捕获流程

    Windows 上刚写出的图片常被杀软实时扫描/索引器/缩略图预览瞬时占用,
    os.remove/rmtree 会抛 PermissionError(WinError 32); 短延时重试一次, 仍失败静默放弃.
    宿主系统是否会自动清理 %TEMP% 不可依赖(存储感知默认多在磁盘不足时触发且可关闭,
    %TEMP% 也没有"保留 N 天自动删除"的默认策略), 故主动收口.
    """
    if not path:
        return
    for attempt in (0, 1):
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            return
        except FileNotFoundError:
            return
        except OSError:
            if attempt == 0:
                time.sleep(0.05)
    return


def _sweep_tmp_root() -> None:
    """清扫本插件临时根目录下上一次捕获遗留的子目录(只动自家目录)

    删除失败/进程崩溃留下的残骸不允许跨次累积: 每次捕获开头先清一遍,
    即便上一次因占用没删干净, 也不会被本次捕获读到(每次捕获用全新唯一子目录).
    """
    root = _tmp_root()
    try:
        names = os.listdir(root)
    except OSError:
        return
    for name in names:
        _drop_path(os.path.join(root, name))


def _new_tmp_dir() -> str:
    """建本次捕获的唯一临时子目录(唯一目录可杜绝读到上一次残留的陈旧文件)"""
    root = _tmp_root()
    os.makedirs(root, exist_ok=True)
    return tempfile.mkdtemp(prefix="cap_", dir=root)


# ---------------------------------------------------------------- 分辨率

def _render_size(rd) -> tuple:
    """实际渲染像素尺寸(分辨率乘百分比)"""
    scale = rd.resolution_percentage / 100.0
    return max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale))


def _clamped_percentage(rd, clamp_long_edge: int) -> int:
    """分辨率百分比: 钳制开启且长边超上限时等比下调, 否则沿用原值

    未开启钳制时直接用 Blender 输出属性(resolution_x/y 乘 resolution_percentage);
    开启后只在**超过上限**时钳制, 且经百分比等比缩放保证宽高比不变
    (渲染只支持整数百分比, 故结果可能略小于上限, 不会超过).
    """
    percentage = rd.resolution_percentage
    if clamp_long_edge <= 0:
        return percentage
    long_edge = max(rd.resolution_x, rd.resolution_y)
    if long_edge <= 0 or long_edge * percentage / 100.0 <= clamp_long_edge:
        return percentage
    return max(1, min(percentage, int(clamp_long_edge * 100 / long_edge)))


def _sane_clamp(clamp_long_edge) -> int:
    """规范化钳制上限: 非法值按不钳制, 并夹到防御性硬上限"""
    try:
        value = int(clamp_long_edge)
    except (TypeError, ValueError):
        return 0
    return min(max(value, 0), _CLAMP_EDGE_MAX)


def resolve_capture_size(scene, clamp_long_edge) -> tuple:
    """本次捕获会实际渲染的像素尺寸(宽, 高)

    面板标签与真实输出同口径: 未开启钳制时即 Blender 输出分辨率乘 resolution_percentage,
    开启后仅在超出上限时经百分比等比下调. 场景不可用时回落 (0, 0).
    """
    rd = getattr(scene, "render", None)
    if rd is None:
        return (0, 0)
    percentage = _clamped_percentage(rd, _sane_clamp(clamp_long_edge))
    scale = percentage / 100.0
    return (max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale)))


def estimate_capture_bytes(size, keys) -> int:
    """估算所选通道落盘总体积(字节), 仅用于面板提示, 非精确值

    依据各通道的落盘规格估算每像素字节数: EXR 未压缩(实测 format.compression 对输出体积
    无影响)按 RGBA 四位深算, PNG/JPEG 为实测经验系数(通道图多为平涂/线稿, 压缩率较高);
    真实体积随画面复杂度浮动, 故面板文案标为估算.
    """
    width, height = size if size else (0, 0)
    pixels = max(0, int(width) * int(height))
    if not pixels:
        return 0
    total = 0.0
    for key in keys:
        spec = _PASS_FORMATS.get(key)
        if spec is None:
            continue
        image_format, color_depth, _save_as_render = spec
        if image_format == 'OPEN_EXR':
            total += pixels * (8.0 if color_depth == '16' else 16.0)
        elif image_format == 'JPEG':
            total += pixels * 0.3
        else:
            total += pixels * 1.0
    return int(total)


# ---------------------------------------------------------------- 临时场景

def _link_user_scene(tmp, scene) -> None:
    """把用户场景的集合与主集合物体关联进临时场景(引用共享, 不复制)"""
    for col in scene.collection.children:
        tmp.collection.children.link(col)
    for obj in scene.collection.objects:
        tmp.collection.objects.link(obj)


def _copy_render_common(tmp, scene, clamp_long_edge: int) -> None:
    """拷贝渲染公共项: 分辨率(按钳制上限等比下调百分比)/帧/胶片/水印

    帧必须跟随原场景: 临时场景默认停在第 1 帧, 不拷则动场景(关键帧/驱动/约束)捕获到的是首帧画面.
    """
    rd, src = tmp.render, scene.render
    rd.resolution_x = src.resolution_x
    rd.resolution_y = src.resolution_y
    rd.resolution_percentage = _clamped_percentage(src, clamp_long_edge)
    rd.film_transparent = False
    rd.use_stamp = False
    tmp.frame_start = scene.frame_start
    tmp.frame_end = scene.frame_end
    tmp.frame_current = scene.frame_current


def _copy_color_management(tmp, scene) -> None:
    """把用户场景的色彩管理拷到临时场景(只有合并结果会套用)

    合并结果走 File Output 的 save_as_render=True, 套的是**临时场景**的 view transform,
    故必须把用户设置搬过来, 否则会落到临时场景的出厂默认(AgX).
    其余通道靠 item 级 save_as_render=False 跳过色彩管理(见 _add_output_node), 不受影响.
    """
    try:
        vs_src, vs_dst = scene.view_settings, tmp.view_settings
        vs_dst.view_transform = vs_src.view_transform
        try:
            vs_dst.look = vs_src.look
        except TypeError:
            pass  # 个别 look 枚举缺档时保留默认
        vs_dst.exposure = vs_src.exposure
        vs_dst.gamma = vs_src.gamma
    except Exception:  # noqa: BLE001 - 老构建缺属性时退回临时场景默认色彩管理
        pass


def _reset_color_management(tmp) -> None:
    """把临时场景的色彩管理压回中立档(Standard / Look None / 无曝光无 gamma)

    帧 B(语义分割)与帧 C(线稿)里没有任何通道需要用户色彩管理, 整帧压到中立档后,
    即便某条落盘路径仍然过一遍色彩管理, 中立档下也等价于"不套 view transform" ——
    比只依赖 save_as_render=False 更硬(实测该标志一度被 item 默认值吃掉, 见 _add_output_node).
    """
    try:
        vs = tmp.view_settings
        vs.view_transform = 'Standard'
        try:
            vs.look = 'None'
        except TypeError:
            pass
        vs.exposure = 0.0
        vs.gamma = 1.0
    except Exception:  # noqa: BLE001 - 老构建缺属性时保留临时场景默认
        pass


def _enable_passes(vl, wanted: dict, ao_distance: float) -> None:
    """按需开启视图层渲染通道(AO 遮蔽距离落在视图层而非场景, 5.1 实证)"""
    vl.use_pass_combined = True
    if wanted['depth']:
        vl.use_pass_z = True
    if wanted['normal']:
        vl.use_pass_normal = True
    if wanted['diffuse']:
        vl.use_pass_diffuse_color = True
    if wanted['ao']:
        try:
            vl.use_pass_ambient_occlusion = True
            vl.eevee.ambient_occlusion_distance = ao_distance
        except AttributeError:
            pass  # 引擎注册表无该 RNA 属性时跳过, 通道缺失在提取期兜底
    if wanted['edge']:
        try:
            vl.use_pass_grease_pencil = True
        except AttributeError:
            pass


# ---------------------------------------------------------------- 合成节点

def _add_output_node(ng, tmp_dir: str, key: str):
    """建一个通道落盘节点(一个通道一个节点, 逐通道独立格式)

    必须先设 format.media_type='IMAGE': 默认档 MULTI_LAYER_IMAGE 会把 file_format
    锁死为 OPEN_EXR_MULTILAYER 并把所有输入并进同一个 .exr;
    EXR 位深只在**节点级**设置(item 级 color_depth 实测被忽略).

    save_as_render 则相反, **必须写到 item 上**: item 打开 override_node_format 后,
    落盘时的颜色管理以 item 自己的 save_as_render 为准(其默认值是 True), 节点上那个被
    完全无视 —— 这正是"除合并结果外其余通道仍被套上用户 view transform"的成因
    (实测: 同一场景把用户 view transform 在 Standard/AgX/Filmic 间切换, 分割图统计随
    之变化 0.6658/0.5934/0.6204, 而它本应恒等). 节点级保留为显式意图声明, item 级才生效.
    """
    image_format, color_depth, save_as_render = _PASS_FORMATS[key]
    fo = ng.nodes.new("CompositorNodeOutputFile")
    fo.directory = tmp_dir
    fo.file_name = ""  # 文件名只取区间名, 避免与节点名拼接成 combined_combined
    fo.save_as_render = save_as_render
    fo.format.media_type = 'IMAGE'
    fo.format.file_format = image_format
    try:
        fo.format.color_depth = color_depth
    except TypeError:
        pass  # 该格式不支持该位深时用默认档
    if image_format == 'JPEG':
        try:
            fo.format.quality = _JPEG_QUALITY
        except Exception:  # noqa: BLE001 - 老构建无 quality 时用默认质量
            pass
    # 落点通过节点的 inputs 建(它就是 items 列表), item 对象没有 socket 属性
    it = fo.file_output_items.new('RGBA', key)
    it.override_node_format = True
    it.save_as_render = save_as_render  # ← 实际生效的那一份(见上)
    it.format.media_type = 'IMAGE'
    it.format.file_format = image_format
    try:
        it.format.color_depth = color_depth
    except (TypeError, AttributeError):
        pass
    return fo


def _build_capture_group(tmp, tmp_dir: str, entries: tuple) -> tuple:
    """构建一帧的合成节点组: RLayers -> 每通道一个 File Output

    返回 (节点组, 缺失通道提示列表); 出线在当前引擎不存在时跳过该通道并记提示,
    不打断整次捕获. 树根仍需一个 NodeGroupOutput 让渲染正常产出合成结果(它是节点树
    必需的输出接口), 但渲染自身不写盘(见 _render_frame), 一次捕获只产出通道文件.
    合成器里**不做任何数学**: 需要变形的通道(深度/法向/线稿)一律原样落盘后在 Python 内
    处理——实测本管线的 AlphaOver 会把纯白底洗成 0.769 灰, 且不同连线给出逐字节相同的
    结果, 节点内做算术不可信.
    提示用 api_error 的"常量标题 + 动态通道键"形态(utils 内不做翻译查询, 由交互层
    describe_error 翻译标题后拼接通道键, 见 errors 模块头注释).
    """
    ng = bpy.data.node_groups.new("CH_AI_PassCapture", 'CompositorNodeTree')
    tmp.compositing_node_group = ng
    ng.interface.new_socket(name="Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    rl = ng.nodes.new("CompositorNodeRLayers")
    rl.scene = tmp
    go = ng.nodes.new("NodeGroupOutput")
    ng.links.new(rl.outputs["Image"], go.inputs[0])
    missing = []
    for key, socket_name in entries:
        sock = rl.outputs.get(socket_name)
        if sock is None:
            missing.append((key, api_error("The pass is not available from this engine, it was skipped",
                                           key)))
            continue
        fo = _add_output_node(ng, tmp_dir, key)
        ng.links.new(sock, fo.inputs[0])
    return ng, missing


def _drop_node_group(ng) -> None:
    """回收本帧的合成节点组(用完即释放: 临时场景虽会整体回收, 但提前删掉更干净)

    失败一律静默: 节点组已随场景回收,或本帧根本没建起来, 都不该影响捕获流程.
    """
    if ng is None:
        return
    try:
        bpy.data.node_groups.remove(ng)
    except Exception:  # noqa: BLE001 - 已随场景回收时忽略
        pass


def _render_frame(tmp, vl, tmp_dir: str) -> tuple:
    """渲染一帧, 返回错误信息

    write_still=False: 通道文件由合成器的 File Output 节点落盘, 与静帧写盘无关(实测),
    故不写静帧——省掉每帧一次整幅 PNG 编码与落盘(一次捕获原本要多写 3 次 render_still.png).
    filepath 仍指向本次临时目录: 万一将来这里改回要写静帧, 落点也不会外泄到用户工程目录.
    """
    tmp.render.filepath = os.path.join(tmp_dir, "render_still")
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=vl):
            bpy.ops.render.render(write_still=False)
    except RuntimeError as e:
        return api_error("Render failed", e)
    return None


def _pass_file(tmp_dir: str, key: str, image_format: str):
    """定位通道落盘文件(扩展名由节点格式决定; 找不到精确名时按前缀兜底)"""
    ext = _EXTENSIONS.get(image_format, '.png')
    exact = os.path.join(tmp_dir, key + ext)
    if os.path.isfile(exact):
        return exact
    try:
        names = os.listdir(tmp_dir)
    except OSError:
        return None
    for name in names:
        if name.startswith(key) and name != "render_still.png":
            return os.path.join(tmp_dir, name)
    return None


# ---------------------------------------------------------------- 像素读取与编码

def _read_bytes(path: str) -> tuple:
    """读文件字节(通道图的最终产出即该文件的字节)"""
    try:
        with open(path, "rb") as f:
            return f.read(), None
    except OSError as e:
        return None, api_error("Failed to read the captured pass", e)


def _read_pass_pixels(path: str) -> tuple:
    """把通道文件(单层 EXR 或 PNG)读回 HxWxC float32 数组, 返回 (数组, 错误信息)

    深度/法向/线稿三个通道需要像素级后处理, 故回读原始值:
    深度背景为 camera.clip_end(远超 1, 写 LDR 会被钳), 法向是带符号原始向量(写 LDR
    负数被钳成 0 会整张全黑), 线稿的信息全在 alpha(见 _edge_bytes).
    色彩空间设 Non-Color 以取回文件里的原值(不做线性->sRGB 往返; alpha 不受色彩空间影响).
    """
    try:
        img = bpy.data.images.load(path, check_existing=False)
    except RuntimeError as e:
        return None, api_error("Failed to load the captured pass", e)
    try:
        try:
            img.colorspace_settings.name = 'Non-Color'
        except Exception:  # noqa: BLE001 - 老构建无该色彩空间时按默认读回
            pass
        width, height = img.size
        if width == 0 or height == 0:
            return None, api_error("Captured pass is empty")
        buf = np.empty(width * height * img.channels, dtype=np.float32)
        img.pixels.foreach_get(buf)
        return buf.reshape(height, width, img.channels), None
    finally:
        try:
            bpy.data.images.remove(img)
        except Exception:  # noqa: BLE001 - 数据块已被外部清理时忽略
            pass


def _quantize(arr: np.ndarray) -> np.ndarray:
    """0-1 浮点数组四舍五入量化为 uint8"""
    return (np.clip(arr, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def _encode_png(rows: np.ndarray) -> bytes:
    """HxWx3/4 uint8 数组编码为内存 PNG 字节(纯 zlib, 不落盘)

    深度/法向是回读 EXR 后在 numpy 内映射出来的, 没有现成文件可读, 故按 PNG 规范手工组块:
    IHDR(8bit RGB/RGBA) + IDAT(逐行前置过滤字节 0 的 zlib 流) + IEND.
    Blender 像素缓冲行序自下而上(原点左下), PNG 行序自上而下, 编码前须上下翻转,
    否则成图整体倒置(实测); 两通道共用本编码器, 翻转一次即全体修正.
    """
    height, width = rows.shape[:2]
    channels = rows.shape[2]
    color_type = 2 if channels == 3 else 6
    rows = rows[::-1]
    raw = b"".join(b"\x00" + rows[y].tobytes() for y in range(height))

    def chunk(tag: bytes, payload: bytes) -> bytes:
        return (struct.pack(">I", len(payload)) + tag + payload
                + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", width, height, 8, color_type, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", zlib.compress(raw, _PNG_COMPRESS))
            + chunk(b"IEND", b""))


def _gray_to_rgb(gray01: np.ndarray) -> np.ndarray:
    """0-1 灰度(HxW)展开为 HxWx3"""
    return np.repeat(gray01[..., None], 3, axis=2)


def _depth_gray(pixels: np.ndarray, near: float, far: float, curve: str = 'LINEAR',
                background: float | None = None) -> np.ndarray:
    """EEVEE 深度(视空间 Z 米制, 背景 = camera.clip_end)按用户区间映射: 近端->1 远端->0

    线性曲线: 区间均分 256 级灰阶; 反深度曲线(INVERSE): 按 1/z(视差)在近端/远端锚定后
    线性化, 灰阶级数向近场集中(近处每米分到的级数远多于远景), 主体景深细节保留最多,
    与 ControlNet/MiDaS 等深度惯例一致; 深度值是米制距离, 背景像素(>= clip_end)置 0;
    近于近端的物体全部钳为 1, 远于远端的全部钳为 0(远端填 0 即"前景为 1 背景为 0"的目标语义);
    区间倒置时自动对调, 过窄/过近按 1e-6 兜底避免除零.
    """
    z = pixels[..., 0]
    if far < near:
        near, far = far, near
    if curve == 'INVERSE':
        near_safe = max(near, 1e-6)
        far_safe = max(far, near_safe + 1e-6)
        denom = 1.0 / near_safe - 1.0 / far_safe
        disp = 1.0 / np.maximum(z, 1e-6)
        depth = (disp - 1.0 / far_safe) / denom
    else:
        span = max(far - near, 1e-6)
        depth = 1.0 - (z - near) / span
    if background and background > 0:
        # EEVEE 的深度背景恒为 camera.clip_end(实测 clip_end=1000 -> 1000.55),
        # 几何体不会超出 clip_end, 故 >= 该值即为背景(留 0.1% 容差吸收浮点误差)
        depth = np.where(z >= background * 0.999, 0.0, depth)
    return np.clip(depth, 0.0, 1.0)


def _normal_bytes(pixels: np.ndarray, convention: str) -> bytes:
    """法向通道: 原始带符号向量 -> (n+1)/2 标准法线编码(背景法向 0 编码后为中灰)"""
    n = np.clip(pixels[..., :3], -1.0, 1.0).astype(np.float32, copy=True)
    if convention == 'DIRECTX':
        # DirectX 约定绿通道向下: 反转 G 后再做 (n+1)/2
        # (与 Blender 法向贴图节点对 DirectX 的处理一致, 即反转绿通道)
        n[..., 1] = -n[..., 1]
    return _encode_png(_quantize(n * 0.5 + 0.5))


def _edge_bytes(pixels: np.ndarray) -> bytes:
    """线稿通道: 笔画信息全在 alpha -> 按 1-alpha 映射为黑线白底

    实测本管线渲染写出的 Grease Pencil 通道像素 RGB 恒为 0,笔画信息全在 alpha
    (alpha 峰值 0.667, 抗锯齿边缘介于 0 与峰值之间); 故"白底黑线" = 灰阶 1-alpha:
    无笔画处 alpha=0 -> 纯白, 笔画核心处 alpha 最大 -> 最暗, 线性映射天然带抗锯齿.
    极少数构建若只回读 RGB(无 alpha 通道), 退化为按亮度取反(此时信息已在亮度里).
    """
    if pixels.shape[2] >= 4:
        line = 1.0 - pixels[..., 3]
    else:
        line = 1.0 - pixels[..., :3].mean(axis=2)
    return _encode_png(_gray_to_rgb(_quantize(line)))


def _decode_raw(key: str, raw: bytes, *, depth_near: float, depth_far: float,
                depth_curve: str, normal_convention: str,
                depth_background: float | None) -> tuple:
    """把通道的**原始落盘字节**转成最终参考图字节, 返回 (字节, 错误信息)

    深度/法向/线稿需要像素级后处理(原始字节写临时文件回读像素后在 numpy 内映射):
    深度按用户近/远区间映射灰阶, 法向按 (n+1)/2 编码, 线稿按 1-alpha 映射白底黑线;
    其余通道的原始字节即最终字节(直接返回).
    """
    if key not in ('depth', 'normal', 'edge'):
        return raw, None
    fd, tmp_path = tempfile.mkstemp(suffix=_EXTENSIONS[_PASS_FORMATS[key][0]],
                                    prefix="ch_ai_redecode_")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as f:
            f.write(raw)
        pixels, err = _read_pass_pixels(tmp_path)
        if err is not None:
            return None, err
        if key == 'depth':
            gray = _quantize(_depth_gray(pixels, depth_near, depth_far, depth_curve,
                                         depth_background))
            return _encode_png(_gray_to_rgb(gray)), None
        if key == 'normal':
            return _normal_bytes(pixels, normal_convention), None
        return _edge_bytes(pixels), None
    finally:
        _drop_path(tmp_path)


def _decode_pass(key: str, path: str, *, depth_near: float, depth_far: float,
                 depth_curve: str, normal_convention: str,
                 depth_background: float | None) -> tuple:
    """把某通道的落盘文件转成最终参考图字节, 返回 (原始落盘字节, 最终字节, 错误信息)

    原始字节供增量捕获缓存(解码参数变化时免渲染重解码, 见 recapture_from_raw);
    色彩空间设 Non-Color 取回文件原值(见 _read_pass_pixels).
    """
    raw, err = _read_bytes(path)
    if err is not None:
        return None, None, err
    final, err = _decode_raw(key, raw, depth_near=depth_near, depth_far=depth_far,
                             depth_curve=depth_curve,
                             normal_convention=normal_convention,
                             depth_background=depth_background)
    return raw, final, err


def _collect_frame(tmp_dir: str, entries: tuple, missing: list, passes: dict,
                   decode_kwargs: dict, passes_raw: dict | None = None) -> list:
    """把一帧落盘的通道文件读成最终参考图字节写入 passes, 返回本帧提示消息列表

    entries 为 (通道键, 出线名) 表; missing 为本帧节点组已报出的缺失通道(不重复报告);
    逐通道的任何一步失败都只跳过该通道并追加提示, 不打断整次捕获;
    passes_raw 不为 None 时同步记录各通道的**原始落盘字节**(增量捕获缓存用,
    解码参数变化时免渲染重解码, 见 recapture_from_raw).
    """
    notices = []
    for key, _socket in entries:
        if any(key == skipped for skipped, _ in missing):
            continue
        path = _pass_file(tmp_dir, key, _PASS_FORMATS[key][0])
        if path is None:
            notices.append(api_error("The pass was not written by the render, it was skipped", key))
            continue
        raw, data, err = _decode_pass(key, path, **decode_kwargs)
        if err is not None:
            notices.append(api_error("The captured pass could not be read, it was skipped", key))
            continue
        passes[key] = data
        if passes_raw is not None and raw is not None:
            passes_raw[key] = raw
    return notices


# ---------------------------------------------------------------- 蜡笔线稿

def _add_edge_gp(tmp, width_scale: float, material_borders: bool) -> tuple:
    """添加场景级蜡笔(LINEART_SCENE)并设置线宽, 返回 (GP 对象, 提示消息或 None)

    线宽基准取 _EDGE_RADIUS_FALLBACK(固定 0.01 世界单位 radius), 再乘用户的宽度缩放系数;
    材质边界开关落在 Lineart 修改器 use_material(控制材质之间是否生成笔画,
    默认关与修改器出厂默认一致).

    用户场景零修改(含选择态): 添加操作器默认把蜡笔链到**当前活动集合**并夺走选中集与
    活动物体(属用户场景侧, 实测确认), 故用 temp_override 把 scene/view_layer/collection
    三件套都指向临时场景——落点直接进临时场景主集合, 用户侧的选择态与活动物体原样保留.
    下方解绑/链接仍保留为兜底: 覆写未被操作器采纳的构建上依旧落回用户集合, 需要搬移.
    落点固定为原点: 场景级线稿的笔画经物体变换补偿(实测两种落点的**世界坐标完全一致**),
    落点与出图无关, 不再沿用探测期遗留的视口坐标.
    """
    known = set(bpy.data.objects)
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=tmp.view_layers[0],
                                       collection=tmp.collection):
            bpy.ops.object.grease_pencil_add(type='LINEART_SCENE', align='WORLD',
                                             location=(0.0, 0.0, 0.0), scale=(1, 1, 1))
    except Exception:  # noqa: BLE001 - 物体上下文不可用(编辑模式等)时跳过边缘通道
        return None, "Failed to add the line art grease pencil, the edge pass was skipped"
    # 按对象增量取新建的蜡笔: 覆写下活动物体落在临时场景视图层, 走全局 active 取不到
    gp = next((obj for obj in bpy.data.objects if obj not in known), None)
    if gp is None:
        return None, "The line art grease pencil was not created, the edge pass was skipped"
    for col in list(gp.users_collection):
        col.objects.unlink(gp)
    tmp.collection.objects.link(gp)
    mod = gp.modifiers.get("Lineart")
    if mod is not None:
        # 固定基准线宽(0.01 世界单位)乘用户缩放系数, 钳到安全区间
        if hasattr(mod, "radius"):
            mod.radius = float(np.clip(_EDGE_RADIUS_FALLBACK * width_scale,
                                       _EDGE_RADIUS_MIN, _EDGE_RADIUS_MAX))
        # 材质边界: 材质之间是否生成笔画(开关缺失的旧构建按修改器默认)
        try:
            mod.use_material = bool(material_borders)
        except AttributeError:
            pass
    return gp, None


def _remove_gp(gp) -> None:
    """回收蜡笔对象,数据块, 以及线条画自动挂上的材质

    实测 bpy.data.grease_pencils.remove() **不清材质**: 场景线条画会给蜡笔数据挂一个名为
    Black 的材质, 只删对象与数据块会在 bpy.data.materials 里留下 Black / Black.001 ...
    残骸(每次捕获 +1), 故先按材质槽快照, 删完数据块后再回收用户数归零的那些.
    只回收本次新建且已无人引用的材质, 绝不触碰用户材质(users > 0 一律跳过).
    """
    if gp is None:
        return
    data = gp.data
    mats = list(getattr(data, "materials", ()) or ()) if data is not None else []
    try:
        bpy.data.objects.remove(gp, do_unlink=True)
    except Exception:  # noqa: BLE001 - 对象已不存在时忽略
        pass
    if data is not None:
        try:
            bpy.data.grease_pencils.remove(data)
        except Exception:  # noqa: BLE001 - 数据块已被连带删除时忽略
            pass
    for mat in mats:
        if mat is None:
            continue
        try:
            if mat.users == 0:
                bpy.data.materials.remove(mat)
        except Exception:  # noqa: BLE001 - 材质已被连带回收时忽略
            pass


# ---------------------------------------------------------------- 语义分割覆盖

def _make_seg_material():
    """语义分割覆盖材质: Object Info.Random -> White Noise(1D).W -> Color -> Material Output

    作者实测该链路每对象输出稳定的随机色(不相邻对象也不会撞色), 优于旧实现给用户对象
    写 obj.color 的做法: 全程不触碰用户数据(旧实现需渲染后逐个还原对象色).
    """
    mat = bpy.data.materials.new("CH_AI_SegOverride")
    mat.use_nodes = True
    tree = mat.node_tree
    for node in list(tree.nodes):
        tree.nodes.remove(node)
    out = tree.nodes.new("ShaderNodeOutputMaterial")
    info = tree.nodes.new("ShaderNodeObjectInfo")
    noise = tree.nodes.new("ShaderNodeTexWhiteNoise")
    noise.noise_dimensions = '1D'
    tree.links.new(info.outputs["Random"], noise.inputs["W"])
    tree.links.new(noise.outputs["Color"], out.inputs["Surface"])
    return mat


def _make_black_world():
    """语义分割用的纯黑世界(作为视图层世界覆盖, 保证分割图背景为纯黑)

    实测 5.1 里 bpy.data.worlds.new() 出来的世界 **use_nodes 默认 True**, 其 Background
    节点的颜色为 0.05 灰, 此时 world.color 被完全忽略(分割图背景实测 byte 58 恰为 0.05),
    故必须改写 Background 节点的颜色; 节点树缺失(老构建/被清空)时退回关掉节点开关,
    让 world.color 生效.
    """
    world = bpy.data.worlds.new("CH_AI_SegBlackWorld")
    world.color = (0.0, 0.0, 0.0)
    tree = getattr(world, "node_tree", None)
    bg = None
    if tree is not None:
        bg = next((node for node in tree.nodes if node.type == 'BACKGROUND'), None)
    if bg is not None:
        try:
            bg.inputs[0].default_value = (0.0, 0.0, 0.0, 1.0)
        except Exception:  # noqa: BLE001 - 节点结构异常时退回 world.color
            world.use_nodes = False
    else:
        world.use_nodes = False
    return world


# ---------------------------------------------------------------- 深度拾取

def sample_visible_depth(scene, grid: tuple = _DEPTH_PICK_GRID) -> tuple:
    """按相机视锥网格采样可见表面的视空间深度, 返回 (近端, 远端, 命中数, 错误信息)

    只做几何投射(复用 depsgraph 的求值场景与 BVH), **不渲染**, 故可一键"取景":
    取命中深度的 2%/98% 分位数作区间锚点, 两端各钳掉 2% 的极值, 避免个别极近/极远像素
    把区间拉爆,主体层次反被压扁(反深度曲线对 near 尤其敏感: near 偏小会把整幅画压到灰阶底端).

    深度口径与深度通道严格一致——**相机视空间 Z(米制)**而非到相机的欧氏距离, 二者在画面
    边角差异明显; 相机裁剪范围外的几何不参与(裁剪掉的东西不会出现在通道图里).
    仅支持透视相机: 正交/全景相机的视锥语义不同, 直接报错交由用户手填, 不做半对的猜测.

    取景结果只写到面板的深度范围属性上, 之后仍可手工修改; 采样网格与分位数见模块常量.
    """
    camera = getattr(scene, "camera", None)
    cam_data = getattr(camera, "data", None)
    if camera is None or cam_data is None or camera.type != 'CAMERA':
        return None, None, 0, api_error("The scene has no active camera")
    if getattr(cam_data, "type", 'PERSP') != 'PERSP':
        return None, None, 0, api_error("Depth picking supports perspective cameras only")
    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        frame = cam_data.view_frame(scene=scene)
    except Exception as e:  # noqa: BLE001 - 取景面/求值场景不可得时转成提示
        return None, None, 0, api_error("Failed to pick the depth range", e)
    columns, rows = max(2, int(grid[0])), max(2, int(grid[1]))
    mw = camera.matrix_world
    mw_inv = mw.inverted()
    origin = mw.translation
    clip_start = float(getattr(cam_data, "clip_start", 0.0))
    clip_end = float(getattr(cam_data, "clip_end", 0.0))
    depths = []
    for iy in range(rows):
        v = (iy + 0.5) / rows
        for ix in range(columns):
            u = (ix + 0.5) / columns
            # 视景面四角双线性插值取本根射线的目标点(view_frame 已含 sensor_fit/shift)
            target = (frame[0] * (1.0 - u) * (1.0 - v) + frame[1] * u * (1.0 - v)
                      + frame[2] * u * v + frame[3] * (1.0 - u) * v)
            to_target = (mw @ target) - origin
            if to_target.length_squared == 0.0:
                continue
            # ray_cast 返回 6 元组, 前两项即 (是否命中, 命中点世界坐标)
            hit, location = scene.ray_cast(depsgraph, origin, to_target.normalized())[:2]
            if not hit:
                continue
            depth = -(mw_inv @ location).z
            if depth <= 0.0 or depth < clip_start or (clip_end > 0.0 and depth > clip_end):
                continue
            depths.append(depth)
    if len(depths) < _DEPTH_PICK_MIN_HITS:
        return None, None, len(depths), api_error("No geometry was found inside the camera view")
    arr = np.asarray(depths, dtype=np.float64)
    near = float(np.percentile(arr, _DEPTH_PICK_NEAR_PCT))
    far = float(np.percentile(arr, _DEPTH_PICK_FAR_PCT))
    if far - near < 1e-4:
        # 极浅场景(单层平面/几何深度几乎一致): 撑开一点跨度, 否则映射退化成一片同色
        pad = max(near * 0.01, 1e-3)
        near, far = max(near - pad, 0.0), far + pad
    return round(near, 3), round(far, 3), len(depths), None


# ---------------------------------------------------------------- 主入口

class PassCaptureSession:
    """相机通道捕获会话(可分帧驱动): open 建临时场景 -> render_next_frame 逐帧渲染收集 -> close 回收

    供 CaptureViewRefs 的模态算子按帧驱动(帧与帧之间让出主线程更新等待进度);
    capture_camera_passes 是一次性薄封装(open + 逐帧 + close 一口气跑完, 供脚本与测试直调).
    帧序列: 帧 A(合并结果/深度/法向/漫射颜色/AO, 用户世界) -> 帧 B(语义分割, 材质覆盖+黑世界)
    -> 帧 C(线稿, 场景线条画); 单帧渲染仍是同步阻塞的, 会话只把帧与帧之间交还给调用方.
    wanted 为通道键 -> 是否捕获; 其余参数与 capture_camera_passes 同名同义.
    """

    def __init__(self, scene, wanted: dict, *, ao_distance: float = 1.0,
                 depth_near: float = 1.0, depth_far: float = 20.0,
                 depth_curve: str = 'LINEAR', normal_convention: str = 'OPENGL',
                 edge_width_scale: float = 1.0, material_borders: bool = False,
                 clamp_long_edge: int = 0):
        self._scene = scene
        self._wanted = dict(wanted)
        self._ao_distance = ao_distance
        self._depth_near, self._depth_far = depth_near, depth_far
        self._depth_curve = depth_curve
        self._normal_convention = normal_convention
        self._edge_width_scale = edge_width_scale
        self._material_borders = material_borders
        self._clamp_long_edge = _sane_clamp(clamp_long_edge)
        # 生命周期状态: pending 帧序列(只含需要渲染的帧), 已收集通道与提示
        self._pending = []
        self.passes: dict = {}
        self.passes_raw: dict = {}
        self.notices: list = []
        self.size = None
        self._tmp = None
        self._ng = None
        self._gp = None
        self._seg_mat = None
        self._black_world = None
        self._tmp_dir = None
        self._decode_kwargs = None
        self._vl = None
        self._opened = False
        self._closed = False

    def open(self):
        """建立临时场景与公共渲染设置, 返回错误信息(None 成功; 失败时已自行回收)"""
        if self._opened or self._closed:
            return api_error("The capture session has already been started")
        scene = self._scene
        if scene.camera is None:
            return api_error("The scene has no active camera")
        engine_id = _eevee_engine_id()
        if engine_id is None:
            return api_error("The EEVEE engine is not available in this build")
        try:
            _sweep_tmp_root()
            self._tmp_dir = _new_tmp_dir()
            tmp = bpy.data.scenes.new("CH_AI_PassCapture")
            self._tmp = tmp
            _link_user_scene(tmp, scene)
            tmp.world = scene.world
            tmp.camera = scene.camera
            _copy_render_common(tmp, scene, self._clamp_long_edge)
            _copy_color_management(tmp, scene)
            tmp.render.engine = engine_id
            try:
                tmp.eevee.taa_render_samples = _EEVEE_SAMPLES
            except AttributeError:
                pass  # 引擎注册表无该属性时用默认采样
            tmp.render.image_settings.file_format = 'PNG'
            vl = tmp.view_layers[0]
            self._vl = vl
            _enable_passes(vl, self._wanted, self._ao_distance)
            self.size = _render_size(tmp.render)
            depth_background = None
            cam_data = getattr(scene.camera, "data", None)
            if cam_data is not None and hasattr(cam_data, "clip_end"):
                depth_background = float(cam_data.clip_end)
            # 解码参数: 只有深度用区间/曲线, 只有法向用约定, 线稿只按 alpha 映射(其余通道直接取字节)
            self._decode_kwargs = dict(depth_near=self._depth_near, depth_far=self._depth_far,
                                       depth_curve=self._depth_curve,
                                       normal_convention=self._normal_convention,
                                       depth_background=depth_background)
            frame_a = tuple(item for item in _FRAME_A_OUTPUTS if self._wanted.get(item[0]))
            frame_b = _FRAME_B_OUTPUTS if self._wanted.get('segmentation') else ()
            frame_c = _FRAME_C_OUTPUTS if self._wanted.get('edge') else ()
            self._pending = [('A', frame_a), ('B', frame_b), ('C', frame_c)]
            self._pending = [(key, entries) for key, entries in self._pending if entries]
            self._opened = True
        except Exception as e:  # noqa: BLE001 - 建场任一步的意外异常统一转成错误信息
            self.close()
            return api_error("Failed to prepare the pass capture", e)
        return None

    def _render_entries(self, tmp, vl, tmp_dir, entries):
        """构建捕获组并渲染收集一帧, 返回错误信息(None 成功); 组随帧建随帧收

        帧 A/B/C 公共段: 失败时节点组留在 self._ng 上, 由 close() 兜底回收.
        """
        self._ng, missing = _build_capture_group(tmp, tmp_dir, entries)
        self.notices.extend(msg for _, msg in missing)
        err = _render_frame(tmp, vl, tmp_dir)
        if err is not None:
            return err
        self.notices.extend(_collect_frame(tmp_dir, entries, missing, self.passes,
                                           self._decode_kwargs, self.passes_raw))
        _drop_node_group(self._ng)
        self._ng = None
        return None

    def render_next_frame(self) -> tuple:
        """渲染下一帧并收集其通道, 返回 (本帧新增提示, 错误信息, 是否全部完成)

        单帧内部同步阻塞; 错误时调用方应 close 放弃(已完成的帧不 commit).
        """
        if not self._opened or self._closed:
            return [], api_error("The capture session is not open"), True
        if not self._pending:
            return [], None, True
        key, entries = self._pending.pop(0)
        tmp, vl, tmp_dir = self._tmp, self._vl, self._tmp_dir
        err = None
        try:
            if key == 'A':
                err = self._render_entries(tmp, vl, tmp_dir, entries)
            else:
                # 帧 B/C 公共: 色彩管理压回中立档(这两个帧里没有任何通道需要用户色彩管理,
                # 分割是语义色块, 线稿走 alpha; 帧 A 不能这样压, 见帧 A 注释);
                # 每帧调用一次, 幂等
                _reset_color_management(tmp)
                if key == 'B':
                    self._seg_mat = _make_seg_material()
                    self._black_world = _make_black_world()
                    vl.material_override = self._seg_mat
                    vl.world_override = self._black_world
                    err = self._render_entries(tmp, vl, tmp_dir, entries)
                    vl.material_override = None
                    vl.world_override = None
                else:
                    self._gp, gp_notice = _add_edge_gp(tmp, self._edge_width_scale,
                                                       self._material_borders)
                    if gp_notice is not None:
                        self.notices.append(gp_notice)
                    else:
                        err = self._render_entries(tmp, vl, tmp_dir, entries)
        except Exception as e:  # noqa: BLE001 - 渲染/收集任一步的意外异常统一转成错误信息
            return [], api_error("Failed to capture the camera passes", e), False
        if err is not None:
            return [], err, False
        return [], None, not self._pending

    def collect(self) -> tuple:
        """收集最终通道字典(按参考优先序排列), 返回 (通道字典, 参考图尺寸)"""
        ordered = {key: self.passes[key] for key in PASS_ORDER if key in self.passes}
        return ordered, self.size

    def close(self):
        """回收临时场景/蜡笔/覆盖材质/临时目录(幂等, 用户场景零残留)"""
        if self._closed:
            return
        self._closed = True
        _drop_node_group(self._ng)
        self._ng = None
        tmp = self._tmp
        if tmp is not None:
            try:
                if self._black_world is not None:
                    tmp.view_layers[0].world_override = None
                tmp.view_layers[0].material_override = None
            except Exception:  # noqa: BLE001 - 视图层已随场景失效时忽略
                pass
            try:
                bpy.data.scenes.remove(tmp)
            except Exception:  # noqa: BLE001 - 已回收时忽略
                pass
        self._tmp = None
        _remove_gp(self._gp)
        self._gp = None
        for block, remover in ((self._seg_mat, bpy.data.materials.remove),
                               (self._black_world, bpy.data.worlds.remove)):
            if block is not None:
                try:
                    remover(block)
                except Exception:  # noqa: BLE001 - 数据块已被连带回收时忽略
                    pass
        self._seg_mat = None
        self._black_world = None
        _drop_path(self._tmp_dir)
        self._tmp_dir = None


# ---- 增量捕获缓存(解码参数变化时免渲染重解码) ----
# 渲染成功后缓存各通道的**原始落盘字节**与渲染键(勾选集/AO 距离/线稿参数/钳制后尺寸/
# 相机名与矩阵——**不含**深度范围/曲线/法线约定等纯解码参数); 再次捕获时渲染键一致且
# 新勾选 ⊆ 已产出通道, 就跳过渲染直接按当前解码参数重解码(秒级, 见 recapture_from_raw).
_PASS_RAW_CACHE: dict | None = None


def capture_render_key(scene, wanted: dict, ao_distance: float, edge_width_scale: float,
                       material_borders: bool, clamp_long_edge: int) -> tuple:
    """捕获的**渲染键**: 决定"是否需要重新渲染"的参数集(解码参数不在此列)"""
    cap_w, cap_h = resolve_capture_size(scene, _sane_clamp(clamp_long_edge))
    cam = scene.camera
    return (
        frozenset(key for key, on in wanted.items() if on),
        ao_distance, edge_width_scale, material_borders, (cap_w, cap_h),
        cam.name if cam is not None else "",
        tuple(cam.matrix_world) if cam is not None else (),
    )


def store_raw_cache(render_key: tuple, wanted: dict, passes_raw: dict, size: tuple,
                     notices: list):
    """渲染成功后更新增量缓存(整体替换; 无原始字节产出时清缓存)"""
    global _PASS_RAW_CACHE
    if not passes_raw:
        _PASS_RAW_CACHE = None
        return
    _PASS_RAW_CACHE = {"render_key": render_key, "wanted": frozenset(wanted),
                       "raw": dict(passes_raw), "size": size,
                       "notices": list(notices)}


def recapture_from_raw(scene, wanted: dict, *, depth_near: float, depth_far: float,
                       depth_curve: str, normal_convention: str,
                       ao_distance: float, edge_width_scale: float,
                       material_borders: bool, clamp_long_edge: int):
    """增量捕获: 渲染键命中且新勾选 ⊆ 缓存产出时, 按当前解码参数重解码, 免渲染

    返回 (按参考优先序的通道字典, 尺寸, 提示列表, 错误信息) 或 None(缓存未命中,
    调用方回落全量渲染). 深度背景取自相机 clip_end(与渲染时同源).
    """
    if _PASS_RAW_CACHE is None:
        return None
    key = capture_render_key(scene, wanted, ao_distance, edge_width_scale,
                             material_borders, clamp_long_edge)
    if key != _PASS_RAW_CACHE["render_key"]:
        return None
    cache_raw = _PASS_RAW_CACHE["raw"]
    if not set(key[0]) <= set(cache_raw):
        return None
    wanted_on = frozenset(k for k, on in wanted.items() if on)
    cam = scene.camera
    cam_data = getattr(cam, "data", None) if cam is not None else None
    depth_background = (float(cam_data.clip_end)
                        if cam_data is not None and hasattr(cam_data, "clip_end") else None)
    decode_kwargs = dict(depth_near=depth_near, depth_far=depth_far, depth_curve=depth_curve,
                         normal_convention=normal_convention, depth_background=depth_background)
    passes = {}
    notices = list(_PASS_RAW_CACHE["notices"])
    for key_name in PASS_ORDER:
        if key_name not in wanted_on:
            continue
        final, err = _decode_raw(key_name, cache_raw[key_name], **decode_kwargs)
        if err is not None:
            notices.append(api_error("The captured pass could not be read, it was skipped", key_name))
            continue
        passes[key_name] = final
    if not passes:
        return None
    ordered = {k: passes[k] for k in PASS_ORDER if k in passes}
    return ordered, _PASS_RAW_CACHE["size"], notices, None


def capture_camera_passes(context, use_combined: bool, use_depth: bool, use_normal: bool,
                          use_segmentation: bool, use_edge: bool, use_diffuse: bool,
                          use_ao: bool, *, ao_distance: float = 1.0,
                          depth_near: float = 1.0, depth_far: float = 20.0,
                          depth_curve: str = 'LINEAR',
                          normal_convention: str = 'OPENGL', edge_width_scale: float = 1.0,
                          material_borders: bool = False,
                          clamp_long_edge: int = 0) -> tuple:
    """渲染场景相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)

    PassCaptureSession 的一次性薄封装: open + 逐帧渲染 + close 一口气跑完
    (供脚本与测试直调; 模态算子改用会话分帧驱动以在帧间更新进度).
    通道字典按参考优先序排列: {'combined': 字节, 'depth': 字节, 'normal': 字节,
    'segmentation': 字节, 'edge': 字节, 'diffuse': 字节, 'ao': 字节};
    size 为 (宽, 高) 即本次渲染的实际像素尺寸(各通道一致);
    提示消息为 api_error 对象(常量标题 + 动态通道键), 由交互层 describe_error 翻译后上报.
    全部通道由 EEVEE 出: 合并结果/深度/法向/漫射颜色/AO 一帧(用户世界), 语义分割一帧
    (视层材质覆盖 + 黑世界覆盖), 线稿一帧(场景线条画); 引擎不可用或通道缺失时跳过并写提示消息.
    通道参数: ao_distance 为 AO 遮蔽计算距离; depth_near/depth_far 为深度图白/黑映射区间
    (场景单位), depth_curve 选线性/反深度量化曲线(反深度把 8bit 灰阶向近端集中, 主体景深
    细节保留最多); normal_convention 选 OpenGL/DirectX(差异在绿通道方向); edge_width_scale
    为线稿宽度缩放系数, material_borders 控制线稿的材质之间是否生成笔画;
    clamp_long_edge 为输出长边钳制上限(<=0 表示不钳制, 直接用 Blender 输出分辨率乘百分比).
    """
    wanted = {'combined': use_combined, 'depth': use_depth, 'normal': use_normal,
              'diffuse': use_diffuse, 'ao': use_ao,
              'segmentation': use_segmentation, 'edge': use_edge}
    session = PassCaptureSession(
        context.scene, wanted,
        ao_distance=ao_distance, depth_near=depth_near, depth_far=depth_far,
        depth_curve=depth_curve, normal_convention=normal_convention,
        edge_width_scale=edge_width_scale, material_borders=material_borders,
        clamp_long_edge=clamp_long_edge)
    err = session.open()
    if err is not None:
        session.close()
        return {}, None, session.notices, err
    while True:
        _frame_notices, frame_err, done = session.render_next_frame()
        if frame_err is not None:
            session.close()
            return {}, session.size, session.notices, frame_err
        if done:
            break
    ordered, size = session.collect()
    session.close()
    store_raw_cache(
        capture_render_key(context.scene, wanted, ao_distance, edge_width_scale,
                           material_borders, clamp_long_edge),
        wanted, session.passes_raw, size, session.notices)
    return ordered, size, session.notices, None
