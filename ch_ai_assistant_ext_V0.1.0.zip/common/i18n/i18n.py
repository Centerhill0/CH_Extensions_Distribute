import bpy

from .dictionary import common_dictionary

__dictionary__ = common_dictionary


def _get_language_code():
    return bpy.context.preferences.view.language


__language_code__ = _get_language_code()


def refresh_language():
    global __language_code__
    __language_code__ = _get_language_code()


# Dictionary for translation: https://docs.blender.org/api/current/bpy.app.translations.html
# {
#     "en_US": {
#         ("*", code1): "translation1",
#         ("Operator", code2): "translation2",
#     },
#     "zh_CN": {
#         ("*", key): "翻译",
#         ("*, key2): "翻译2"
#     }
# }

# NOTE: __dictionary__ 与 common_dictionary 是同一个对象(别名引用).
# load_dictionary/set_dictionary 必须原地 update, 不能用 " __dictionary__ = 新字典 " 重新赋值:
# bpy.app.translations.register 注册的是 common_dictionary 这个对象, 重新赋值后
# 新增条目不会出现在已注册的字典里, 翻译会静默失效.
# 插件侧也应保证先调用 load_dictionary 合并词条, 再调用 translations.register.

# Set a new dictionary for translation
def set_dictionary(new_dictionary: dict[str, dict[tuple, str]]):
    global __dictionary__
    __dictionary__ = new_dictionary


# Load additional dictionary for translation
def load_dictionary(additional_dictionary: dict[str, dict[tuple, str]]):
    global __dictionary__
    for key in additional_dictionary:
        if key in __dictionary__:
            __dictionary__[key].update(additional_dictionary[key])
        else:
            __dictionary__[key] = {}
            __dictionary__[key].update(additional_dictionary[key])


# 在需要拼接字符串的地方使用i18n函数
def i18n(content: str) -> str:
    global __language_code__, __dictionary__
    current_lang = _get_language_code()
    if current_lang != __language_code__:
        __language_code__ = current_lang
    if __language_code__ not in __dictionary__:
        return content
    tuple_contents = [("*", content), ("Operator", content)]
    for tuple_content in tuple_contents:
        if tuple_content in __dictionary__[__language_code__]:
            return __dictionary__[__language_code__][tuple_content]
    for key in __dictionary__[__language_code__]:
        if key[1] == content:
            return __dictionary__[__language_code__][key]
    return content


# Tooltip 翻译助手: 供算子 def description(cls, context, properties) 动态回调内自查翻译.
# Blender 对静态 bl_description 经 TIP_ 宏翻译(RNA_struct_ui_description), 但对动态回调
# 的返回值直接透传不翻译(WM_operatortype_description), 因此回调内必须自行查询.
# pgettext_tip 与 TIP_ 同口径, 跟随 use_translate_tooltips 开关; 字典键为 ("*", 原文).
def tip(content: str) -> str:
    try:
        translated = bpy.app.translations.pgettext_tip(content)
    except Exception:
        return content
    return translated if translated else content


# 界面文案翻译助手: 供 blf 绘制的 HUD 文本使用——Blender 仅翻译 UILayout 文本与 RNA 名称,
# blf.draw 的字符串原样输出, 故 HUD 文案必须自查(与界面文案同口径: use_translate_interface
# 开关 + 默认语境, 字典键为 ("*", 原文)); 拼接式文案用 "英文模板 + 变量" 后 .format() 拼接.
def iface(content: str) -> str:
    try:
        translated = bpy.app.translations.pgettext_iface(content)
    except Exception:
        return content
    return translated if translated else content


# 动态 report 翻译助手: f-string report 须拆成 "英文模板 + 变量"——模板经本函数查询后
# .format() 拼接变量(字典键为模板原文, 如 ("*", "Aligned {} objects")).
# pgettext_rpt 即 Blender RPT_ 宏的 Python 对应(RPT_ = BLT_translate_do_report,
# 跟随 use_translate_reports 开关, 开启时经 pgettext 主链查询——系统 mo 优先, 插件词典兜底);
# 纯变量无常量部分的文案无法翻译, 保持原样. 常在异常兜底路径调用, 查询失败一律回落原文不放大故障.
def report(content: str) -> str:
    try:
        translated = bpy.app.translations.pgettext_rpt(content)
    except Exception:
        return content
    return translated if translated else content
