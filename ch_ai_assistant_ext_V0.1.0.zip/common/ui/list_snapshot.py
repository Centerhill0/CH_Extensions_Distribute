"""
UI 列表快照共享模块

提供以下功能:
- ListItem: 列表条目属性组(name 双击可编辑并写穿到真实数据块, src_name 记录快照时真名, kind 标注数据块类型)
- rebuild_if_changed: 列表快照按名称序列差异重建, 活跃索引压回有效范围
- rename_datablock / on_item_name_update: 条目名编辑写穿到真实数据块(材质/文本/图像/物体; 失败回写旧名)
- set_index / is_syncing: 重入护栏(处理器驱动的索引/条目名写入期间, 列表的 update 回调见位即跳过)
- StandardFilterMixin / standard_filter: UIList 内建名称过滤与排序控件行为

供 ch_utils_tools(灯光/相机/材质列表)与 ch_ai_assistant(脚本列表)共用;
ListItem 为 PropertyGroup, 经各插件包内的 class_loader 自动注册.
"""

import bpy
from bpy.props import StringProperty
from bpy.types import Context, PropertyGroup

# 重入护栏: 处理器驱动的索引/条目名写入期间置位, 列表的 update 回调见位即跳过.
# 只有用户点击列表行或编辑条目名才联动选中/重命名, 避免同步 -> 选中 -> 再同步的循环,
# 以及快照重建把索引压回时误选无关物体
_syncing = False


def is_syncing() -> bool:
    """是否处于护栏内的程序化写入期间(列表 update 回调据此跳过联动)"""
    return _syncing


def set_guarded(state, attr_name: str, value):
    """护栏内写入状态属性(该属性的 update 联动回调见位即跳过)"""
    global _syncing
    _syncing = True
    try:
        setattr(state, attr_name, value)
    finally:
        _syncing = False


def set_index(state, index_name: str, value: int):
    """护栏内写入列表活跃索引(不触发列表的选中回调)"""
    set_guarded(state, index_name, value)


def rebuild_if_changed(state, coll_name: str, index_name: str, kind: str, names: list):
    """快照名称序列与目标不一致时整体重建, 并把活跃索引压回有效范围(护栏内写入)

    Args:
        state: 列表快照状态组实例(含 <coll_name> 集合与 <index_name> 活跃索引属性)
        coll_name: 集合属性名(如 "lights")
        index_name: 活跃索引属性名
        kind: 条目对应的数据块类型标签(OBJECT/MATERIAL/TEXT)
        names: 数据块名称列表
    """
    global _syncing
    col = getattr(state, coll_name)
    # 比较真实名快照(src_name)而非显示名: 条目名可被用户编辑, 显示名一致不代表快照对齐
    if [item.src_name for item in col] == names:
        return
    _syncing = True
    try:
        col.clear()
        for name in names:
            item = col.add()
            item.name = name
            item.src_name = name
            item.kind = kind
        set_index(state, index_name, min(getattr(state, index_name), max(len(col) - 1, 0)))
    finally:
        _syncing = False


def rename_datablock(kind: str, old: str, new: str) -> tuple:
    """把旧名数据块重命名为新名(OBJECT 按场景物体解析), 返回 (是否成功, 错误信息)

    同名冲突由 Blender 自动追加 .001 后缀, 不算失败; 空名拒绝.
    """
    if not new.strip():
        return False, "empty name"
    if kind == 'MATERIAL':
        datablock = bpy.data.materials.get(old)
    elif kind == 'TEXT':
        datablock = bpy.data.texts.get(old)
    elif kind == 'IMAGE':
        datablock = bpy.data.images.get(old)
    else:
        datablock = bpy.context.scene.objects.get(old)
    if datablock is None:
        return False, "datablock not found"
    try:
        datablock.name = new
    except (RuntimeError, ValueError) as e:
        return False, str(e)
    return True, None


def on_item_name_update(self, context: Context):
    """列表条目名编辑回调(双击行内名称): 写穿到真实数据块, 失败回写旧名"""
    global _syncing
    if _syncing:
        return
    old = self.src_name
    new = self.name
    if new == old or not old:
        return
    ok, _err = rename_datablock(self.kind, old, new)
    if ok:
        # 数据块重命名不触发 depsgraph, 立即对齐真实名快照, 否则下次重命名会拿旧名检索失败
        self.src_name = new
    else:
        _syncing = True
        try:
            self.name = old
        finally:
            _syncing = False


class ListItem(PropertyGroup):
    """列表条目: name 双击可编辑并写穿到真实数据块, src_name 记录快照时真名, kind 标注数据块类型"""

    name: StringProperty(name="Name", update=on_item_name_update)  # type: ignore
    src_name: StringProperty()  # type: ignore
    kind: StringProperty()  # type: ignore


def standard_filter(self, data, propname: str) -> tuple:
    """标准过滤/排序: 名称通配过滤 + 按名字母序 + 反序, 返回 (标志列表, 顺序列表)"""
    helper = bpy.types.UI_UL_list
    items = getattr(data, propname)
    # 5.1 的 filter_items_by_name 直接收条目集合(第三参), 空模板返回空标志即不过滤
    flt_flags = helper.filter_items_by_name(self.filter_name, self.bitflag_filter_item, items)
    flt_neworder = []
    if self.use_filter_sort_alpha:
        flt_neworder = helper.sort_items_helper([(idx, item.name) for idx, item in enumerate(items)], lambda e: e[1].lower(), self.use_filter_sort_reverse)
    elif self.use_filter_sort_reverse:
        flt_neworder = helper.sort_items_helper([(idx, idx) for idx in range(len(items))], lambda e: e[1], True)
    return flt_flags, flt_neworder


class StandardFilterMixin:
    """UIList 内建过滤/排序控件行为(过滤行默认收起, 点漏斗图标展开)

    标准过滤属性(filter_name/use_filter_show/use_filter_sort_alpha/use_filter_sort_reverse)
    由 UIList 基类自带, 此处只需提供 filter_items 行为, 自声明同名属性会被基类遮蔽.
    """

    def filter_items(self, context: Context, data, propname: str):
        return standard_filter(self, data, propname)
