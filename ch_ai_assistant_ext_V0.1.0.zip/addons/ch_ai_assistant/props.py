"""
状态属性模块

提供以下功能:
- WM 级状态属性组: 脚本列表快照, AI 输入/最近错误记录, 纯文本对话消息, 纹理与效果图输入
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.ui.list_snapshot
"""

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import PropertyGroup

from ...common.ui.list_snapshot import ListItem, is_syncing
from .preference import (
    PROVIDER_MODEL_ITEMS,
    TEXT_PROVIDER_MODEL_ITEMS,
    _prefs_model_items,
    get_prefs,
)
from .handlers import (
    gallery_visible_items,
    on_chat_index_update,
    on_image_index_update,
    on_scripts_index_update,
    select_gallery_value,
    select_image_by_name,
)

# 对话消息角色条目("User"为 Blender 系统词条, 不入插件词典)
_CHAT_ROLE_ITEMS = [
    ('USER', "User", ""),
    ('ASSISTANT', "AI", ""),
]

# 输出尺寸档位条目(长边像素, 方图直接取值, 非方图按参考图比率缩放)
_size_items = [
    ('1K', "1K", "Long edge 1024 px"),
    ('2K', "2K", "Long edge 2048 px"),
]


class ChatMessage(PropertyGroup):
    """单条对话消息: 角色与纯文本内容"""
    role: EnumProperty(name="Role", items=_CHAT_ROLE_ITEMS, default='USER')  # type: ignore
    content: StringProperty(name="Content")  # type: ignore


class AiAssistantState(PropertyGroup):
    """AI 助手状态: 脚本列表快照与活跃索引, 描述输入, 等待进度与最近一次运行错误记录, 纯文本对话"""
    scripts: CollectionProperty(type=ListItem)  # type: ignore
    scripts_active_index: IntProperty(default=0, update=on_scripts_index_update)  # type: ignore
    prompt: StringProperty(
        name="Prompt",
        description="Describe the script you need",
    )  # type: ignore
    # 请求等待期间的面板进度文案(完成后清空)
    status: StringProperty()  # type: ignore
    # 运行中请求所属面板('script'/'chat'/'texture'/'render'), 各面板只显示自己的进度(完成后清空)
    status_scope: StringProperty()  # type: ignore
    # 已等待秒数
    wait_seconds: IntProperty()  # type: ignore
    # 中断请求标志: 中断按钮置位, 等待模态在下一拍清理等待并放弃结果(与 Esc 等效)
    cancel_requested: BoolProperty()  # type: ignore
    last_error_script: StringProperty()  # type: ignore
    last_error_traceback: StringProperty()  # type: ignore
    # 报错对应脚本的内容摘要: 脚本改过后不再复用旧 traceback(重捕)
    last_error_hash: StringProperty()  # type: ignore
    # 纯文本对话: 消息历史, 当前高亮消息(点击行按偏好转出文本编辑器)与输入框(存于 WM, 不随 .blend 保存)
    chat_messages: CollectionProperty(type=ChatMessage)  # type: ignore
    chat_active_index: IntProperty(default=0, update=on_chat_index_update)  # type: ignore
    chat_input: StringProperty(
        name="Message",
        description="What to ask the AI in plain text",
    )  # type: ignore
    # 对话下一条消息附带的脚本名(脚本列表高亮脚本, 经"附带脚本"按钮设置, 发送后清空)
    chat_script_name: StringProperty()  # type: ignore




def _gallery_items(self, context):
    """预览区缩略图条目: 可见条目(过滤+上限后)逐项取图像预览图标(标识 = 数据块名, 供选中回写)

    标签只放数据块名, 分辨率放悬停说明: 缩略图标签的可视宽度受缩略图宽度限制, Blender 会把
    过长标签省略号截断(实测"名 + 尺寸"拼接后长名条目只剩名称或只剩尺寸, 看起来时有时无),
    故标签保持短而完整, 分辨率走悬停提示(想整段看到名称与尺寸可把缩略图尺寸调大).
    标签与悬停说明**必须是 ASCII 且不预翻译**: 运行期拼给动态枚举的文案(含 iface/report 预翻译出的
    中文)会经 Blender 的 C 层渲染成乱码(实测 "×"/"·" 乱码,经 iface 得到的中文"分辨率"也乱码),
    故这里固定输出英文; 静态声明的枚举条目走 Blender 自己的翻译通路, 不受此限.
    预览数据块异步生成, 首帧 icon_value 为 0 时该项画空位, 下一帧重绘即出.
    """
    items = []
    for idx, item in enumerate(gallery_visible_items(self)):
        image = bpy.data.images.get(item.name)
        if image is None:
            continue
        image.preview_ensure()
        preview = image.preview
        width, height = image.size
        # 悬停说明固定英文(不翻译): 运行时拼出的动态枚举文案预翻译成中文会在 C 层渲染成乱码
        items.append((item.name, item.name, f"Resolution: {width} x {height}",
                      preview.icon_id if preview is not None else 0, idx))
    return items


def _on_gallery_select(self, context):
    """缩略图选中某张图像: 高亮列表条目并按偏好切换图像编辑器(与点击列表行同款联动)"""
    if is_syncing():
        return
    select_image_by_name(context, self, self.gallery_image)


def _on_gallery_view_change(self, context):
    """过滤条件/显示上限变化: 选中值回落到可见项(护栏内写入, 不影响列表高亮与图像编辑器)

    选中项被过滤/截断掉的枚举值不在候选表内, 读回即空串(Blender 对失效动态枚举的归一化),
    缩略图选中态会悬空, 故可见项非空时回落到首项; 可见项为空(无匹配)时缩略图本就不绘制,
    保持原值, 下次过滤变化或列表同步(handlers._align_gallery_to_index)时重新回落.
    """
    visible = gallery_visible_items(self)
    if visible:
        select_gallery_value(self, visible[0].name)


_service_mode_items = [
    ('GLOBAL', "Global", "Use the image service configured in the preferences"),
    ('VOLCENGINE', "Volcengine Ark", "Override with the Volcengine Ark service"),
    ('DASHSCOPE', "Alibaba DashScope", "Override with the Alibaba DashScope service"),
]


def _panel_t2i_model_items(self, context):
    """纹理覆盖模型下拉(按面板服务模式动态)

    Global/Custom 无服务商候选表: 给出空标识的"跟随偏好"档(动态 items 枚举不接受空串赋值,
    但空串**标识**合法), 使面板始终可解析; 其余模式表首项即默认(枚举无 default, 取首项).
    """
    items = PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else _prefs_model_items


def _panel_edit_model_items(self, context):
    """效果图覆盖模型下拉(按面板服务模式动态), 与纹理下拉同规则"""
    items = PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else _prefs_model_items


_text_service_mode_items = [
    ('GLOBAL', "Global", "Use the text service configured in the preferences"),
    ('DEEPSEEK', "DeepSeek", "Override with the DeepSeek service"),
    ('GLM', "Zhipu GLM", "Override with the Zhipu GLM service"),
]


def _reset_image_panel_models(self, _context):
    """切换图像服务模式时把覆盖模型复位为新模式的表首项

    Global/Custom 的表只有"跟随偏好"一档, 其标识是空串而动态 items 枚举不接受空串赋值
    (赋空串必抛 TypeError), 该档下覆盖模型本就不被采用, 因此跳过赋值(见 _reset_text_panel_model).
    """
    items = _panel_t2i_model_items(self, _context)
    if items and items[0][0]:
        self.panel_t2i_model = items[0][0]
    items = _panel_edit_model_items(self, _context)
    if items and items[0][0]:
        self.panel_edit_model = items[0][0]


def _reset_text_panel_model(self, _context):
    """切换文本服务模式时把覆盖模型与思考档位复位到新表首项

    模型表首项是"跟随偏好"哨兵(空标识), 正好表达"该面板不覆盖模型"; 但空标识不能赋值
    (动态 items 枚举不接受空串, 赋了必抛 TypeError 且只在控制台留 traceback), 故 GLOBAL/Custom
    档下跳过模型赋值 —— 这些档位的模型解析本就不看 panel_model.
    档位标识按服务商定制且各表长度不同, 不复位会被按索引重解释到别的档(或越界读回空串导致
    档位静默不下发), 故档位仍需按新表首项复位.
    """
    provider = self.service_mode if self.service_mode != 'GLOBAL' else get_prefs().provider
    items = _panel_text_model_items(self, _context)
    if items and items[0][0]:
        self.panel_model = items[0][0]
    thinking_items = _thinking_items_for(provider)
    if thinking_items:
        self.thinking = thinking_items[0][0]


# 思考档位表(档位标识即该服务商的参数值): 按生效服务商定制, 表首项即默认档(枚举无 default, 取首项)
# DeepSeek 默认关闭思考; GLM 默认低档(其思考不可关闭, 低档最省); 其余兼容服务商默认低档
_deepseek_thinking_items = [
    ('off', "Off", "Disable thinking, the default: fastest and cheapest"),
    ('low', "Low", "Low reasoning effort"),
    ('high', "High", "High reasoning effort"),
    ('max', "Highest", "Maximum reasoning effort"),
]
_glm_thinking_items = [
    ('low', "Low", "Light reasoning, the default: classification, extraction, quick answers"),
    ('high', "High", "Enhanced reasoning: regular coding and drafts"),
    ('max', "Highest", "Deep reasoning: for complex tasks"),
]
_default_thinking_items = [
    ('low', "Low", "Low reasoning effort, the default"),
    ('medium', "Medium", "Medium reasoning effort"),
    ('high', "High", "High reasoning effort"),
]


def _thinking_items_for(provider: str) -> list:
    """按服务商返回思考档位条目(DeepSeek 三档 / GLM 开关 / 其余 low-medium-high)"""
    if provider == 'DEEPSEEK':
        return _deepseek_thinking_items
    if provider == 'GLM':
        return _glm_thinking_items
    return _default_thinking_items


def _text_thinking_items(self, context):
    """思考档位下拉条目: 按生效服务商(覆盖优先, 否则偏好)动态切换"""
    provider = self.service_mode if self.service_mode != 'GLOBAL' else get_prefs().provider
    return _thinking_items_for(provider)


def _panel_text_model_items(self, context):
    """文本面板覆盖模型下拉(按面板服务模式动态)

    Global 无服务商候选表: 给出空标识的"跟随偏好"档(空串**标识**合法, 空串**赋值**非法);
    覆盖模式表首项(Flash 轻量档)即默认.
    """
    items = TEXT_PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else _prefs_model_items


class ServiceTestState(PropertyGroup):
    """服务连通性测试结果(最近一次, 存于 WM 供偏好面板显示)"""
    text_result: StringProperty()  # type: ignore
    text_ok: BoolProperty()  # type: ignore
    image_result: StringProperty()  # type: ignore
    image_ok: BoolProperty()  # type: ignore


class AiImageServiceState(PropertyGroup):
    """图像面板服务设置: 服务模式(全局/覆盖服务商)与覆盖模型(纹理/编辑各一)

    类定义一份, WM 上按面板各挂一个实例(ch_ai_texture_service / ch_ai_render_service),
    四个面板的服务设置互不影响.
    """
    service_mode: EnumProperty(
        name="Provider",
        description="Image service for the image assistant: Global follows the preferences, others override",
        items=_service_mode_items,
        default='GLOBAL',
        update=_reset_image_panel_models,
    )  # type: ignore
    panel_t2i_model: EnumProperty(
        name="Texture Model",
        description="Texture generation model override",
        items=_panel_t2i_model_items,
    )  # type: ignore
    panel_edit_model: EnumProperty(
        name="Edit Model",
        description="Image edit model override",
        items=_panel_edit_model_items,
    )  # type: ignore


class AiTextServiceState(PropertyGroup):
    """文本面板服务设置: 服务模式(全局/覆盖服务商)与覆盖模型

    类定义一份, WM 上按面板各挂一个实例(ch_ai_script_service / ch_ai_chat_service),
    四个面板的服务设置互不影响.
    """
    service_mode: EnumProperty(
        name="Provider",
        description="Text service for the text assistant: Global follows the preferences, others override",
        items=_text_service_mode_items,
        default='GLOBAL',
        update=_reset_text_panel_model,
    )  # type: ignore
    panel_model: EnumProperty(
        name="Model",
        description="Model override for the text assistant",
        items=_panel_text_model_items,
    )  # type: ignore
    # 思考档位: 档位值即生效服务商的参数值(档位表按服务商定制)
    thinking: EnumProperty(
        name="Thinking Level",
        description="Thinking level for this panel, sent with the provider's own parameter",
        items=_text_thinking_items,
    )  # type: ignore


class AiTextureState(PropertyGroup):
    """纹理生成状态: 提示词, 无缝平铺开关, 输出尺寸, 生成图像列表与预览区画廊开关(存于 WM, 不随 .blend 保存)"""
    prompt: StringProperty(
        name="Prompt",
        description="Describe the material texture to generate",
    )  # type: ignore
    use_seamless: BoolProperty(
        name="Seamless",
        description="Make the texture tile seamlessly: stronger prompt guidance plus local edge blending",
        default=True,
    )  # type: ignore
    size: EnumProperty(
        name="Size",
        description="Output image resolution of the generated texture",
        items=_size_items,
        default='2K',
    )  # type: ignore
    # 随机种: 0 = 每次随机; 非 0 可复现同一次生成(复现满意的纹理后调尺寸重出)
    seed: IntProperty(
        name="Seed",
        description="Random seed: 0 randomizes each run, a fixed value reproduces the same result",
        default=0,
        min=0,
        max=2147483647,
    )  # type: ignore
    # 生成图像列表快照(实时同步见 handlers), 点击行把图像编辑器切换到对应图像
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_image_index_update)  # type: ignore
    # 预览区缩略图控件: 缩略图尺寸与名称标签(画廊图标视图的显示参数)
    gallery_scale: FloatProperty(
        name="Thumbnail Size",
        description="Size of the thumbnails in the preview area",
        default=6.0,
        min=2.0,
        max=16.0,
        precision=1,
    )  # type: ignore
    gallery_labels: BoolProperty(
        name="Labels",
        description="Show the image name and pixel size under each thumbnail",
        default=True,
    )  # type: ignore
    gallery_filter: StringProperty(
        name="Name Filter",
        description="Show only thumbnails whose name contains this text",
        update=_on_gallery_view_change,
    )  # type: ignore
    gallery_limit: IntProperty(
        name="Max Shown",
        description="Maximum number of thumbnails shown, 0 shows every matching image",
        default=12,
        min=0,
        max=200,
        update=_on_gallery_view_change,
    )  # type: ignore
    # 控件子面板展开开关: 缩略图控件收在缩略图下方, 默认收起(留白给缩略图)
    use_show_controls: BoolProperty(
        name="Thumbnail Controls",
        description="Show the thumbnail size, label, filter and count controls",
        default=False,
    )  # type: ignore
    gallery_image: EnumProperty(
        name="Gallery",
        description="Click a thumbnail to highlight that image in the list and show it in the image editor",
        items=_gallery_items,
        update=_on_gallery_select,
    )  # type: ignore


class AiRenderState(PropertyGroup):
    """效果图生成状态: 提示词, 参考通道勾选, 捕获引擎与输出尺寸(存于 WM, 不随 .blend 保存)"""
    prompt: StringProperty(
        name="Prompt",
        description="Describe the look of the concept render",
    )  # type: ignore
    # 参考通道勾选: 生成请求必须包含 Color
    use_color: BoolProperty(
        name="Color",
        description="Capture the color render as a reference image (required for generation)",
        default=True,
    )  # type: ignore
    use_depth: BoolProperty(
        name="Depth",
        description="Capture the depth pass as a reference image",
        default=True,
    )  # type: ignore
    use_normal: BoolProperty(
        name="Normal",
        description="Capture the world-space normal pass as a reference image",
        default=False,
    )  # type: ignore
    use_lines: BoolProperty(
        name="Lines",
        description="Capture a line drawing derived from the depth pass",
        default=False,
    )  # type: ignore
    use_ao: BoolProperty(
        name="AO",
        description="Capture the ambient occlusion pass as a reference image",
        default=False,
    )  # type: ignore
    use_current_engine: BoolProperty(
        name="Current Engine",
        description="Capture references with the scene render engine and samples instead of a fast draft",
        default=False,
    )  # type: ignore
    # 输出尺寸档位: 长边像素, 宽高按参考图比率等比计算
    size: EnumProperty(
        name="Size",
        description="Output image resolution: long edge in pixels, aspect ratio follows the color reference",
        items=_size_items,
        default='2K',
    )  # type: ignore
    # 随机种: 0 = 每次随机; 非 0 可复现同一次生成
    seed: IntProperty(
        name="Seed",
        description="Random seed: 0 randomizes each run, a fixed value reproduces the same result",
        default=0,
        min=0,
        max=2147483647,
    )  # type: ignore
    # 捕获预览与生成结果列表快照(实时同步见 handlers), 点击行把图像编辑器切换到对应图像
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_image_index_update)  # type: ignore
    # 预览区缩略图控件(同纹理状态): 生成结果与参考通道捕获图共用同一套显示参数
    gallery_scale: FloatProperty(
        name="Thumbnail Size",
        description="Size of the thumbnails in the preview area",
        default=6.0,
        min=2.0,
        max=16.0,
        precision=1,
    )  # type: ignore
    gallery_labels: BoolProperty(
        name="Labels",
        description="Show the image name and pixel size under each thumbnail",
        default=True,
    )  # type: ignore
    gallery_filter: StringProperty(
        name="Name Filter",
        description="Show only thumbnails whose name contains this text",
        update=_on_gallery_view_change,
    )  # type: ignore
    gallery_limit: IntProperty(
        name="Max Shown",
        description="Maximum number of thumbnails shown, 0 shows every matching image",
        default=12,
        min=0,
        max=200,
        update=_on_gallery_view_change,
    )  # type: ignore
    # 控件子面板展开开关: 缩略图控件收在缩略图下方, 默认收起(留白给缩略图)
    use_show_controls: BoolProperty(
        name="Thumbnail Controls",
        description="Show the thumbnail size, label, filter and count controls",
        default=False,
    )  # type: ignore
    gallery_image: EnumProperty(
        name="Gallery",
        description="Click a thumbnail to highlight that image in the list and show it in the image editor",
        items=_gallery_items,
        update=_on_gallery_select,
    )  # type: ignore
