"""
客户端错误文案模块

后台请求线程与图像/渲染工具层只描述"出了什么错", 不做翻译查询
(blender.mo 与应用词典的查询不是线程安全的, 且 utils 内禁止 report()):
常量部分包成 ClientError 并进 ch_ai_assistant 词典, 变量部分放 detail 原样透出,
交互层(主线程)用 describe_error 翻译后 report / 写入面板状态.

主要功能:
- api_error: 组装 (可翻译文案, 动态细节) 错误对象
- describe_error: 主线程把错误对象翻译为可显示文本
"""


class ClientError:
    """客户端错误: message 为英文原句(词典键), detail 为动态内容(不翻译)"""

    def __init__(self, message: str, detail: str = "") -> None:
        self.message = message
        self.detail = detail

    def __str__(self) -> str:
        return f"{self.message}: {self.detail}" if self.detail else self.message


def api_error(message: str, detail: str = "") -> ClientError:
    """组装错误对象: message 为可翻译英文原句, detail 为服务端/系统返回的动态内容"""
    return ClientError(message, str(detail))


def describe_error(err) -> str:
    """把错误对象翻译为可显示文本(主线程调用); 普通字符串原样返回

    翻译查询须在主线程(面板绘制/模态回调)内进行, 故后台线程一律只回错误对象.
    """
    from ....common.i18n.i18n import iface

    if isinstance(err, ClientError):
        text = iface(err.message)
        return f"{text}: {err.detail}" if err.detail else text
    return str(err)
