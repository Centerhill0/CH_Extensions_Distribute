"""
文本块 IO 工具模块

脚本文本块的执行捕获, 写入命名与文本编辑器聚焦.

主要功能:
- run_text_block: 独立命名空间执行脚本并捕获 traceback
- write_text_block: 按名写入文本块(存在则清空重写)
- next_script_name: 生成不冲突的 AI 脚本回落名(script_001.py 递增)
- ai_script_name: 给脚本名加 "AI " 前缀(列表过滤标识, 无前缀时添加)
- ai_texture_name / ai_render_name: 生成图像的数据块名(列表前缀过滤共用同一常量)
- ensure_unique_name: 数据块重名时追加序号保证唯一
- focus_text_editors: 把所有文本编辑器区域聚焦到指定文本块
"""

import traceback

import bpy
from bpy.types import Context, Text

# AI 生成脚本的前缀标识(脚本列表仅显示此前缀的文本块)
AI_SCRIPT_PREFIX = "AI "

# 生成图像的数据块名前缀(纹理/效果图两个图像列表按此前缀过滤):
# 前缀带尾随分隔符, 但无英文词提示词的回落名是纯前缀本身(见 ai_texture_name/ai_render_name),
# 故过滤必须用 startswith(前缀) 而非 startswith(前缀 + " "), 否则该产物不进列表
AI_TEXTURE_PREFIX = "AI Tex"
AI_RENDER_PREFIX = "AI Render"
# 效果图面板的相机参考通道预览图也进该列表
AI_REF_PREFIX = "AI Ref: "


def run_text_block(code: str, source_name: str) -> tuple:
    """以独立命名空间执行脚本并捕获异常, 返回 (是否成功, traceback 文本或 None)

    命名空间按文本编辑器运行约定注入 __name__ 为 '__main__',
    脚本需自行 import bpy; 脚本内部调用 bpy.ops 报错走 Blender 自身 report, 不会抛异常.
    """
    namespace = {'__name__': '__main__'}
    try:
        exec(compile(code, source_name, 'exec'), namespace)
        return True, None
    except Exception:
        return False, traceback.format_exc()


def write_text_block(name: str, code: str) -> tuple:
    """按名写入文本块(存在则清空重写), 返回 (Text 块, 错误信息)"""
    text = bpy.data.texts.get(name)
    if text is None:
        text = bpy.data.texts.new(name)
    else:
        text.clear()
    text.write(code)
    return text, None


def next_script_name(prefix: str = "script") -> tuple:
    """生成不冲突的脚本回落名(编号递增, 调用方再经 ai_script_name 加前缀), 返回 (名称, 错误信息)"""
    idx = 1
    while True:
        name = f"{prefix}_{idx:03d}.py"
        if name not in bpy.data.texts:
            return name, None
        idx += 1


def ai_script_name(name: str) -> str:
    """给脚本名加 AI 前缀(列表过滤标识), 已带前缀时原样返回"""
    if name.startswith(AI_SCRIPT_PREFIX):
        return name
    return f"{AI_SCRIPT_PREFIX}{name}"


def ai_texture_name(stem: str) -> str:
    """纹理图像数据块名: 提示词短名非空时接在前缀后, 为空则用纯前缀(仍能被前缀过滤命中)"""
    return f"{AI_TEXTURE_PREFIX} {stem}" if stem else AI_TEXTURE_PREFIX


def ai_render_name(stem: str) -> str:
    """效果图数据块名: 提示词短名非空时接在前缀后, 为空则用纯前缀(仍能被前缀过滤命中)"""
    return f"{AI_RENDER_PREFIX} {stem}" if stem else AI_RENDER_PREFIX


def ensure_unique_name(name: str) -> str:
    """数据块重名时追加序号保证唯一, 返回最终名"""
    if name not in bpy.data.texts:
        return name
    stem = name[:-3] if name.endswith(".py") else name
    idx = 2
    while f"{stem}_{idx}.py" in bpy.data.texts:
        idx += 1
    return f"{stem}_{idx}.py"


# AI 长文描述专用文本块名(不属脚本, 列表快照时排除)
AI_PROMPT_TEXT_NAME = "AI_Prompt.txt"

# AI 纹理长文描述专用文本块名(与脚本描述分开, 两个面板互不覆盖对方的描述)
AI_TEXTURE_PROMPT_TEXT_NAME = "AI_Texture_Prompt.txt"

# AI 效果图长文描述专用文本块名(同上, 三个面板各用各的描述块)
AI_RENDER_PROMPT_TEXT_NAME = "AI_Render_Prompt.txt"

# AI 对话查看专用文本块名(长回复转出到文本编辑器阅读, 不属脚本, 列表快照时排除)
AI_CHAT_TEXT_NAME = "AI_Chat.txt"

# 对话代码提取专用文本块名(带 AI 前缀进脚本列表, 每次提取同名覆盖)
AI_CHAT_CODE_NAME = "AI Chat_Code.py"


def focus_text_editors(context: Context, text: Text) -> tuple:
    """把所有文本编辑器区域的活动文本设为指定文本块, 返回 (聚焦区域数, 错误信息)"""
    focused = 0
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'TEXT_EDITOR':
                area.spaces.active.text = text
                focused += 1
    return focused, None
