"""
AI 图像服务客户端工具模块

文生图与参考图生图的单次请求(火山方舟 Seedream 与阿里百炼千问双适配), 提示词模板组装.

主要功能:
- build_texture_prompt: 纹理提示词模板(无缝平铺引导可选)
- build_render_prompt: 相机效果图提示词模板(说明各参考图含义, 要求保持构图)
- request_image: urllib 单次图像请求(含可选随机种), 统一返回图片字节(文生图/参考图生图共用)
- ref_image_limit: 服务商参考图张数上限(超出由调用方按既定优先序截断)
- resolve_image_endpoint: 按服务商解析 (base_url, api_key)(预设服务商取固定端点, CUSTOM 取偏好配置)
"""

import base64
import json
import urllib.error
import urllib.request

from .ai_client import _http_error_text
from .errors import api_error

# 各服务商参考图张数上限(千问多图编辑上限 3, 方舟参考图数组上限 10), CUSTOM 放宽到 10 由服务端裁决
REF_IMAGE_LIMITS = {'VOLCENGINE': 10, 'DASHSCOPE': 3}
_DEFAULT_REF_LIMIT = 10

# 预设服务商的固定端点(base_url 不暴露为偏好字段, 由服务商决定)
PROVIDER_ENDPOINTS = {
    'VOLCENGINE': "https://ark.cn-beijing.volces.com/api/v3",
    'DASHSCOPE': "https://dashscope.aliyuncs.com/api/v1",
}

# 各服务商的预设默认模型(面板覆盖选 Default 时使用; 与偏好 _IMAGE_PRESETS 单一来源对齐)
PROVIDER_DEFAULT_MODELS = {
    'VOLCENGINE': "doubao-seedream-5-0-pro-260628",
    'DASHSCOPE': "qwen-image-3.0-pro",
}


def resolve_image_endpoint(provider: str, prefs) -> tuple:
    """按生效服务商解析 (base_url, api_key): 预设服务商端点固定, 密钥各存一把, CUSTOM 取偏好通用配置"""
    if provider == 'VOLCENGINE':
        return PROVIDER_ENDPOINTS['VOLCENGINE'], prefs.volcengine_api_key
    if provider == 'DASHSCOPE':
        return PROVIDER_ENDPOINTS['DASHSCOPE'], prefs.dashscope_api_key
    return prefs.image_base_url, prefs.image_api_key

# 输出尺寸档位 -> 长边像素(方图直接取该值, 非方图按参考图比率等比缩放)
SIZE_LONG_EDGES = {'1K': 1024, '2K': 2048}

# 无缝平铺引导后缀: 平铺无接缝/受光均匀/正交顶视/边缘到边缘的重复图案
_TEXTURE_SEAMLESS_SUFFIX = (
    ", seamless tileable texture, flat even lighting, no shadows, "
    "top-down orthographic view, edge-to-edge repeating pattern"
)

# 基础纹理引导后缀(非平铺): 满幅材质纹理/受光均匀/正交顶视
_TEXTURE_BASE_SUFFIX = ", full-frame material texture, flat even lighting, top-down orthographic view"

# 通道键 -> 参考图说明(组装进效果图提示词, 顺序与参考图数组一致)
_PASS_ROLES = {
    'color': "the color render of the scene",
    'depth': "the depth map of the same view",
    'normal': "the world-space normal map of the same view",
    'lines': "the line drawing of the same view",
    'ao': "the ambient occlusion map of the same view",
}


def build_texture_prompt(prompt: str, seamless: bool) -> str:
    """纹理生成提示词: 追加平铺/视角/光照引导模板, seamless 开启时要求可无缝平铺"""
    suffix = _TEXTURE_SEAMLESS_SUFFIX if seamless else _TEXTURE_BASE_SUFFIX
    return f"{prompt.strip().rstrip(',.，。')}{suffix}"


def build_render_prompt(prompt: str, pass_names: list) -> str:
    """效果图提示词: 说明各参考图含义并要求保持相机构图

    pass_names 为有序通道键列表('color'/'depth'/'lines'/'ao'),
    顺序必须与请求携带的参考图数组一致.
    """
    described = ", ".join(
        f"Image {idx} is {_PASS_ROLES.get(name, name)}" for idx, name in enumerate(pass_names, 1))
    return (
        f"{prompt.strip()}\n\n"
        f"Reference images: {described}. "
        "Keep the camera composition and object placement of the color render, "
        "restyle it as described above."
    )


def ref_image_limit(provider: str) -> int:
    """服务商参考图张数上限, 未知服务商取默认上限由服务端裁决"""
    return REF_IMAGE_LIMITS.get(provider, _DEFAULT_REF_LIMIT)


def format_size(provider: str, width: int, height: int) -> str:
    """输出宽高转服务商尺寸字符串(方舟 x 分隔, 百炼 * 分隔)"""
    sep = '*' if provider == 'DASHSCOPE' else 'x'
    return f"{width}{sep}{height}"


def fit_size(width: int, height: int, long_edge: int) -> tuple:
    """按参考图比率等比缩放到指定长边, 宽高取偶(服务端多要求偶数), 返回 (宽, 高)"""
    if width >= height:
        out_w = long_edge
        out_h = max(2, round(height * long_edge / width))
    else:
        out_h = long_edge
        out_w = max(2, round(width * long_edge / height))
    return out_w - out_w % 2, out_h - out_h % 2


def _data_uri(image_bytes: bytes) -> str:
    """图片字节编码为 data-URI(两家服务均接受 base64 内嵌参考图, 格式小写)"""
    encoded = base64.b64encode(image_bytes).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"


def _volcengine_payload(model: str, prompt: str, size: str | None, ref_images: list | None,
                        seed: int) -> dict:
    """火山方舟(OpenAI images 风格)请求体: 文生图/参考图生图共用, 响应要求 b64 内嵌"""
    payload = {
        "model": model,
        "prompt": prompt,
        "response_format": "b64_json",
        "watermark": False,
    }
    if size:
        payload["size"] = size
    if seed:
        payload["seed"] = seed
    if ref_images:
        payload["image"] = [_data_uri(data) for data in ref_images]
    return payload


def _dashscope_payload(model: str, prompt: str, size: str | None, ref_images: list | None,
                       seed: int) -> dict:
    """阿里百炼 multimodal-generation 请求体: 参考图与文本按序放进同一条 user 消息"""
    content = [{"image": _data_uri(data)} for data in (ref_images or [])]
    content.append({"text": prompt})
    payload = {
        "model": model,
        "input": {"messages": [{"role": "user", "content": content}]},
        "parameters": {"watermark": False, "n": 1},
    }
    if size:
        payload["parameters"]["size"] = size
    if seed:
        payload["parameters"]["seed"] = seed
    return payload


def _inline_error(data: dict):
    """从 200 响应体内提取服务端错误描述(部分服务把错误放响应体而非 HTTP 状态码)

    返回错误对象或 None; 服务端返回的 code/message 属动态内容, 放 detail 原样透出.
    """
    err = data.get("error")
    if isinstance(err, dict) and (err.get("code") or err.get("message")):
        return api_error("API error", f"{err.get('code', '')} {err.get('message', '')}".strip())
    if isinstance(err, str) and err.strip():
        return api_error("API error", err.strip())
    if data.get("code") and data.get("message"):
        return api_error("API error", f"{data['code']} {data['message']}")
    return None


def _download(url: str, timeout: int) -> tuple:
    """下载图片 URL 为字节(千问只回 URL 且 24 小时有效, 须随即取回), 返回 (图片字节, 错误信息)"""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = resp.read()
    except urllib.error.URLError as e:
        return None, api_error("Failed to download the generated image", e.reason)
    except OSError as e:
        return None, api_error("Failed to download the generated image", e)
    if not data:
        return None, api_error("Downloaded image is empty")
    return data, None


def _extract_item_image(data: dict, timeout: int) -> tuple:
    """OpenAI images 风格响应取图: b64_json 优先, 其次 URL 下载; 返回 (图片字节, 错误信息)"""
    try:
        item = data["data"][0]
    except (KeyError, IndexError, TypeError):
        return None, api_error("Unexpected API response format")
    if not isinstance(item, dict):
        return None, api_error("Unexpected API response format")
    if item.get("b64_json"):
        try:
            return base64.b64decode(item["b64_json"]), None
        except (ValueError, TypeError):
            return None, api_error("API returned invalid base64 image data")
    if item.get("url"):
        return _download(item["url"], timeout)
    return None, api_error("API response contains no image")


def _extract_dashscope_image(data: dict, timeout: int) -> tuple:
    """百炼响应取图: content 内首个带 image 的条目即结果图(仅 URL); 返回 (图片字节, 错误信息)"""
    try:
        content = data["output"]["choices"][0]["message"]["content"]
        url = next(entry["image"] for entry in content
                   if isinstance(entry, dict) and entry.get("image"))
    except (KeyError, IndexError, TypeError, StopIteration):
        return None, api_error("Unexpected API response format")
    return _download(url, timeout)


def request_image(base_url: str, api_key: str, model: str, prompt: str, timeout: int,
                  provider: str = 'CUSTOM', size: str | None = None,
                  ref_images: list | None = None, seed: int = 0) -> tuple:
    """单次图像生成请求(文生图或参考图生图), 不自动重试; 返回 (图片字节, 错误信息)

    provider 决定请求体格式与取图路径: DASHSCOPE 走 multimodal-generation,
    其余(含 VOLCENGINE/CUSTOM)走 OpenAI images/generations 风格(CUSTOM 不下发
    watermark/response_format/seed 等额外参数, 兼容严格的 OpenAI 端点);
    size 格式由调用方按服务商拼接(方舟 x 分隔, 百炼 * 分隔);
    ref_images 为 JPEG/PNG 字节列表, 顺序即参考优先序, 张数上限由调用方截断;
    seed 为随机种(0 = 每次随机, 非 0 可复现同一次生成).
    """
    if provider == 'DASHSCOPE':
        url = base_url.rstrip('/') + "/services/aigc/multimodal-generation/generation"
        payload = _dashscope_payload(model, prompt, size, ref_images, seed)
    elif provider == 'VOLCENGINE':
        url = base_url.rstrip('/') + "/images/generations"
        payload = _volcengine_payload(model, prompt, size, ref_images, seed)
    else:
        url = base_url.rstrip('/') + "/images/generations"
        payload = _volcengine_payload(model, prompt, size, ref_images, seed)
        payload.pop("response_format")
        payload.pop("watermark")
        payload.pop("seed", None)
    body = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return None, _http_error_text(e)
    except TimeoutError:
        # 超过偏好 Timeout 的专门文案(TimeoutError 是 OSError 子类, 须先于 OSError 分支)
        return None, api_error("Request timed out")
    except urllib.error.URLError as e:
        # 连接握手阶段的超时会被包进 URLError.reason, 单独识别
        if isinstance(e.reason, TimeoutError):
            return None, api_error("Request timed out")
        return None, api_error("Request failed", e.reason)
    except OSError as e:
        # 其余网络层错误(连接重置/远端断开等不是 URLError 的形态)
        return None, api_error("Connection error", e)
    except json.JSONDecodeError:
        return None, api_error("API returned invalid JSON")

    if not isinstance(data, dict):
        return None, api_error("Unexpected API response format")
    inline = _inline_error(data)
    if inline is not None:
        return None, inline
    if provider == 'DASHSCOPE':
        return _extract_dashscope_image(data, timeout)
    return _extract_item_image(data, timeout)
