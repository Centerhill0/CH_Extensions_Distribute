"""
相机视图参考通道提取工具模块

在临时场景中多次渲染场景相机视图, 把所选通道经合成节点组路由到渲染输出写成 PNG,
通道图再编码为 sRGB JPEG 字节供 AI 参考图上传. 临时场景方案关联同一套集合/相机/世界,
只覆写捕获所需设置, 用户渲染设置零污染; 逐 pass 落盘是因为渲染结果像素与多层 EXR
在后台均不可经 Python 读取, 而 PNG 加载像素可读(Blender 5.1.2 实证).

主要功能:
- capture_camera_passes: 渲染相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)
"""

import os
import tempfile

import bpy
import numpy as np

from .errors import api_error

# 草稿渲染采样(AO 通道 EEVEE Next 5.1 实证可出数据, 无需切 Cycles)
_EEVEE_SAMPLES = 16
# 参考图长边上限(方舟参考图分辨率上限 4096, 千问建议 384-3072, 取 2048 控体积)
_MAX_EDGE_PX = 2048
# Sobel 线稿梯度增益: 归一化梯度乘以该系数后截断, 越大保留的线越少
_EDGE_GAIN = 3.0
# 通道数据有效性下限: 拉伸前后动态范围低于该值视为引擎未产出该通道
_EMPTY_RANGE = 1e-4


def _eevee_engine_id() -> str | None:
    """EEVEE 草稿引擎 id: 4.2+ 为 BLENDER_EEVEE_NEXT, 旧版为 BLENDER_EEVEE, 均无则 None"""
    engines = [item.identifier for item in bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items]
    for engine_id in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        if engine_id in engines:
            return engine_id
    return None


def _capped_percentage(rd) -> int:
    """分辨率百分比: 长边超上限时等比下调, 否则沿用原值"""
    long_edge = max(rd.resolution_x, rd.resolution_y)
    if long_edge * rd.resolution_percentage / 100 <= _MAX_EDGE_PX:
        return rd.resolution_percentage
    return max(1, int(_MAX_EDGE_PX * 100 / long_edge))


def _render_size(rd) -> tuple:
    """实际渲染像素尺寸(分辨率乘百分比)"""
    scale = rd.resolution_percentage / 100.0
    return max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale))


def _build_capture_scene(scene, engine_id: str, use_mist: bool, use_normal: bool, use_ao: bool) -> tuple:
    """构建临时捕获场景(关联集合/相机/世界, 拷贝分辨率/帧/色彩管理), 返回 (临时场景, 错误信息)

    新场景视图层全集合参与渲染, 原场景的逐视图层集合排除不生效(属可接受的边缘差异);
    任一步失败即回收临时场景, 不留残块.
    """
    tmp = bpy.data.scenes.new("CH_AI_PassCapture")
    try:
        for col in scene.collection.children:
            tmp.collection.children.link(col)
        for obj in scene.collection.objects:
            tmp.collection.objects.link(obj)

        tmp.world = scene.world
        tmp.camera = scene.camera

        rd, src = tmp.render, scene.render
        rd.engine = engine_id
        rd.resolution_x = src.resolution_x
        rd.resolution_y = src.resolution_y
        rd.resolution_percentage = _capped_percentage(src)
        rd.film_transparent = False
        rd.use_stamp = False

        # 帧必须跟随原场景: 临时场景默认停在第 1 帧, 不拷则动场景(关键帧/驱动/约束)捕获到的是首帧画面
        tmp.frame_start = scene.frame_start
        tmp.frame_end = scene.frame_end
        tmp.frame_current = scene.frame_current

        # 色彩管理跟随原场景(color 通道观感与用户渲染一致), 数据通道渲染时再切 Standard
        vs_src, vs_dst = scene.view_settings, tmp.view_settings
        vs_dst.view_transform = vs_src.view_transform
        vs_dst.look = vs_src.look
        vs_dst.exposure = vs_src.exposure
        vs_dst.gamma = vs_src.gamma

        if engine_id == 'CYCLES':
            tmp.cycles.samples = _EEVEE_SAMPLES
            tmp.cycles.use_denoising = False
        else:
            tmp.eevee.taa_render_samples = _EEVEE_SAMPLES

        vl = tmp.view_layers[0]
        if use_mist:
            vl.use_pass_mist = True
        if use_normal:
            vl.use_pass_normal = True
        if use_ao:
            try:
                vl.use_pass_ambient_occlusion = True
            except AttributeError:
                pass  # 引擎注册表无该 RNA 属性时跳过, 通道缺失在提取期兜底
    except Exception as e:  # noqa: BLE001 - 建场任一步失败都要回收临时场景并转成错误信息
        bpy.data.scenes.remove(tmp)
        return None, api_error("Failed to build the capture scene", e)
    return tmp, None


def _build_capture_group(tmp) -> tuple:
    """构建捕获合成节点组(RLayers -> GroupOutput), 返回 (节点组, RLayers 节点, GroupOutput 节点)

    节点组先挂到临时场景再建节点(RLayers 输出列表按其场景视图层的 pass 开关生成),
    RLayers 节点再显式指向临时场景.
    """
    ng = bpy.data.node_groups.new("CH_AI_PassCapture", 'CompositorNodeTree')
    tmp.compositing_node_group = ng
    ng.interface.new_socket(name="Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    rl = ng.nodes.new("CompositorNodeRLayers")
    rl.scene = tmp
    go = ng.nodes.new("NodeGroupOutput")
    ng.links.new(rl.outputs["Image"], go.inputs[0])
    try:
        tmp.use_nodes = True
    except AttributeError:
        pass  # Blender 6.0 移除 use_nodes, 届时仅 compositing_node_group 即生效
    return ng, rl, go


def _route_output(ng, go, from_socket) -> None:
    """把 GroupOutput 的输入切换到指定来源 socket(重建唯一入链)"""
    for link in list(go.inputs[0].links):
        ng.links.remove(link)
    ng.links.new(from_socket, go.inputs[0])


def _render_png(tmp, vl, stem: str) -> tuple:
    """渲染临时场景并写 PNG, 返回 (文件路径, 错误信息)"""
    path = os.path.join(tempfile.gettempdir(), f"ch_ai_pass_{stem}.png")
    tmp.render.filepath = path
    tmp.render.image_settings.file_format = 'PNG'
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=vl):
            bpy.ops.render.render(write_still=True)
    except RuntimeError as e:
        return None, api_error("Render failed", e)
    if not os.path.exists(path):
        return None, api_error("Render produced no image file")
    return path, None


def _load_pixels(path: str) -> tuple:
    """加载 PNG 为线性像素数组, 返回 (HxWx4 float32 数组, 错误信息); 用后即弃数据块"""
    try:
        image = bpy.data.images.load(path)
    except RuntimeError as e:
        return None, api_error("Failed to load the captured image", e)
    try:
        width, height = image.size
        if width == 0 or height == 0:
            return None, api_error("Captured image is empty")
        buf = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(buf)
        return buf.reshape(height, width, 4), None
    finally:
        bpy.data.images.remove(image)


def _stretch(gray: np.ndarray) -> np.ndarray:
    """灰度图按帧内最小最大拉伸到 0-1(Mist 距离范围随世界雾设置漂移, 拉伸后对比度稳定)"""
    lo = float(gray.min())
    hi = float(gray.max())
    if hi - lo < _EMPTY_RANGE:
        return np.zeros_like(gray)
    return (gray - lo) / (hi - lo)


def _is_empty(gray: np.ndarray) -> bool:
    """帧内动态范围过低视为通道无数据(引擎未产出)"""
    return float(gray.max()) - float(gray.min()) < _EMPTY_RANGE


def _lines_from_depth(gray: np.ndarray) -> np.ndarray:
    """拉伸后的深度灰度经 Sobel 梯度生成线稿(黑线白底, 深度不连续处成线)"""
    gx = np.zeros_like(gray)
    gy = np.zeros_like(gray)
    gx[:, 1:-1] = gray[:, 2:] - gray[:, :-2]
    gy[1:-1, :] = gray[:-2, :] - gray[2:, :]
    mag = np.hypot(gx, gy)
    peak = float(mag.max())
    if peak > 1e-6:
        mag = mag / peak
    return 1.0 - np.clip(mag * _EDGE_GAIN, 0.0, 1.0)


def _encode_jpeg(rgb_linear: np.ndarray, stem: str) -> tuple:
    """0-1 线性 RGB(HxWx3)经临时图像与编码场景存为 JPEG 字节, 返回 (图片字节, 错误信息)

    生成图像的 file_format 赋值被 Blender 静默忽略(save() 恒写 PNG, 实证),
    故走 save_render + 专用编码场景: image_settings 定 JPEG q90,
    view_transform=Standard 把线性值单次编码为 sRGB, colorspace 用 Non-Color 防二次转换.
    """
    height, width = rgb_linear.shape[:2]
    image = bpy.data.images.new(f"CH_AI_Encode_{stem}", width, height, alpha=False)
    enc_scene = bpy.data.scenes.new("CH_AI_Encode")
    fd, path = tempfile.mkstemp(suffix=".jpg", prefix="ch_ai_")
    os.close(fd)
    try:
        image.colorspace_settings.name = 'Non-Color'
        enc_scene.render.image_settings.file_format = 'JPEG'
        enc_scene.render.image_settings.quality = 90
        enc_scene.view_settings.view_transform = 'Standard'
        try:
            enc_scene.view_settings.look = 'None'
            enc_scene.view_settings.exposure = 0.0
            enc_scene.view_settings.gamma = 1.0
        except TypeError:
            pass  # 个别 look 枚举缺 None 档, 保留默认
        # pixels 恒为 4 通道 RGBA, 透明通道置 1
        rgba = np.ones((height, width, 4), dtype=np.float32)
        rgba[..., :3] = rgb_linear
        image.pixels.foreach_set(rgba.ravel())
        image.save_render(path, scene=enc_scene)
        with open(path, "rb") as f:
            return f.read(), None
    except (OSError, RuntimeError) as e:
        return None, api_error("Failed to encode the captured pass", f"{stem}: {e}")
    finally:
        bpy.data.images.remove(image)
        bpy.data.scenes.remove(enc_scene)
        try:
            os.remove(path)
        except OSError:
            pass


def _encode_gray(gray_linear: np.ndarray, stem: str) -> tuple:
    """0-1 线性灰度(深度/线稿/AO 观感已就绪)编码为 JPEG 字节"""
    return _encode_jpeg(np.repeat(gray_linear[..., None], 3, axis=2), stem)


def capture_camera_passes(context, use_color: bool, use_depth: bool, use_normal: bool,
                          use_lines: bool, use_ao: bool, use_current_engine: bool) -> tuple:
    """渲染场景相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)

    通道字典按参考优先序排列: {'color': 字节, 'depth': 字节, 'normal': 字节,
    'lines': 字节, 'ao': 字节}; size 为 (宽, 高) 即本次渲染的实际像素尺寸(各通道一致);
    引擎不支持的通道跳过并写入提示消息. 默认走 EEVEE 草稿档快速捕获,
    勾选 Current Engine 时用场景当前引擎与采样; 数据通道以 Standard 变换单独渲染,
    色彩通道用原场景观感变换.
    """
    scene = context.scene
    if scene.camera is None:
        return {}, None, [], "The scene has no active camera"

    notices = []
    engine_id = scene.render.engine if use_current_engine else _eevee_engine_id()
    if engine_id is None:
        # 无 EEVEE 引擎可用的极端环境(精简构建): 回落用户引擎保证功能可用
        engine_id = scene.render.engine
    want_mist = use_depth or use_lines

    tmp, err = _build_capture_scene(scene, engine_id, want_mist, use_normal, use_ao)
    if err is not None:
        return {}, None, notices, err
    # ng 前置声明为 None: 建组失败时 finally 不得引用未绑定的名字(否则异常被 UnboundLocalError 顶掉且临时场景泄漏)
    ng = None
    try:
        ng, rl, go = _build_capture_group(tmp)
        vl = tmp.view_layers[0]
        size = _render_size(tmp.render)
        passes = {}
        # 线稿由深度渲染派生, 但插入序须排在法线之后: 先算后放, 用本变量暂存
        lines_data = None

        # 通道可用性先判定(socket 名随引擎不同): 缺失时跳过并提示, 不进入渲染
        mist_socket = rl.outputs.get("Mist") if want_mist else None
        if want_mist and mist_socket is None:
            use_depth = use_lines = False
            notices.append("The depth pass is not available with this engine, depth and lines were skipped")
        normal_socket = rl.outputs.get("Normal") if use_normal else None
        if use_normal and normal_socket is None:
            use_normal = False
            notices.append("The normal pass is not available from this engine, it was skipped")
        ao_socket = rl.outputs.get("Ambient Occlusion") if use_ao else None
        if use_ao and ao_socket is None:
            use_ao = False
            notices.append("The AO pass is not available from this engine, it was skipped")

        # 色彩通道: Image -> GroupOutput, 原场景观感变换
        if use_color:
            path, err = _render_png(tmp, vl, "color")
            if err is not None:
                return {}, size, notices, err
            pixels, err = _load_pixels(path)
            os.remove(path)
            if err is not None:
                return {}, size, notices, err
            data, err = _encode_jpeg(pixels[..., :3], 'color')
            if err is not None:
                return {}, size, notices, err
            passes['color'] = data

        # 数据通道切 Standard 变换并中和观感曲线/曝光/伽马(数值即线性, 8bit 截断不削信息);
        # 仅切 view_transform 不够: 原场景的 exposure/gamma/look 会继续作用于深度与线稿
        tmp.view_settings.view_transform = 'Standard'
        try:
            tmp.view_settings.look = 'None'
        except TypeError:
            pass  # 个别 look 枚举缺 None 档, 保留默认
        tmp.view_settings.exposure = 0.0
        tmp.view_settings.gamma = 1.0

        # 字典插入序即参考图优先序(调用方按序截断超服务商上限), 须与 docstring/README 一致:
        # color > depth > normal > lines > ao
        if mist_socket is not None:
            _route_output(ng, go, mist_socket)
            path, err = _render_png(tmp, vl, "mist")
            if err is not None:
                return {}, size, notices, err
            pixels, err = _load_pixels(path)
            os.remove(path)
            if err is not None:
                return {}, size, notices, err
            gray = _stretch(pixels[..., 0])
            if _is_empty(gray):
                use_depth = use_lines = False
                notices.append("The depth pass is not available, depth and lines were skipped")
            else:
                # 深度与线稿同源(线稿由深度梯度生成), 复用同一次渲染
                if use_depth:
                    data, err = _encode_gray(gray, 'depth')
                    if err is not None:
                        return {}, size, notices, err
                    passes['depth'] = data
                lines_data = None
                if use_lines:
                    lines_data, err = _encode_gray(_lines_from_depth(gray), 'lines')
                    if err is not None:
                        return {}, size, notices, err
        if normal_socket is not None:
            _route_output(ng, go, normal_socket)
            path, err = _render_png(tmp, vl, "normal")
            if err is not None:
                return {}, size, notices, err
            pixels, err = _load_pixels(path)
            os.remove(path)
            if err is not None:
                return {}, size, notices, err
            # 法线为 (n+1)/2 的 XYZ 三通道编码, 拉伸会破坏编码, RGB 直出即标准法线图观感
            data, err = _encode_jpeg(pixels[..., :3], 'normal')
            if err is not None:
                return {}, size, notices, err
            passes['normal'] = data

        if lines_data is not None:
            passes['lines'] = lines_data

        if ao_socket is not None:
            _route_output(ng, go, ao_socket)
            path, err = _render_png(tmp, vl, "ao")
            if err is not None:
                return {}, size, notices, err
            pixels, err = _load_pixels(path)
            os.remove(path)
            if err is not None:
                return {}, size, notices, err
            ao_gray = _stretch(pixels[..., 0])
            # AO 语义: 值越大越少遮蔽(缝隙暗), 直接输出即标准观感; 全平数据视为引擎未产出
            if _is_empty(ao_gray):
                notices.append("The AO pass is not available from this engine, it was skipped")
            else:
                data, err = _encode_gray(ao_gray, 'ao')
                if err is not None:
                    return {}, size, notices, err
                passes['ao'] = data
        return passes, size, notices, None
    finally:
        if ng is not None:
            bpy.data.node_groups.remove(ng)
        bpy.data.scenes.remove(tmp)
