"""
AI 服务客户端工具模块

OpenAI 兼容 chat 接口的单次请求, 生成/调试/修改消息组装与响应清洗.

主要功能:
- build_context_info: 场景上下文摘要(Blender 版本/场景/选中与活动物体)
- build_system_prompt: 按注释语言组装脚本周的系统提示词
- build_generation_messages: 脚本生成请求的消息组装
- build_debug_messages: 脚本调试请求的消息组装(原脚本 + 报错)
- build_revise_messages: 对话修改请求的消息组装(原脚本 + 修改要求, 变更行头附修改说明)
- build_chat_messages: 纯文本对话请求的消息组装(带最近历史)
- build_thinking_extras: 按服务商把思考级别映射为请求附加参数
- request_chat: urllib 单次 POST 请求(默认 60s 超时, 不自动重试)
- ping_chat: 最小请求验证文本服务连通与密钥(max_tokens=16)
- fetch_deepseek_balance: 查询 DeepSeek 账户余额
- strip_code_fences: 剥掉响应中的 markdown 代码围栏
- validate_script: compile 语法校验
"""

import json
import re
import urllib.error
import urllib.request

import bpy
from bpy.types import Context

from .errors import api_error

# 系统提示词正文: 要求模型先输出 script-name 命名行, 再输出完整可直接运行的 bpy 脚本;
# Blender 版本由 build_system_prompt 按当前场景动态注入, 注释语言同样按偏好拼接
_SYSTEM_PROMPT_BODY = (
    "Write a complete, self-contained Python script using the bpy API. "
    "Prefer APIs available in this Blender version and avoid APIs removed before it. "
    "Your response must start with a single comment line in the exact form "
    "'# script-name: <short_name>.py', where <short_name> is a short snake_case name "
    "describing what the script does. After that line, output the complete script, "
    "starting with a short module docstring (one or two lines) briefly describing "
    "the script's purpose: "
    "no explanations, no markdown code fences. "
    "The script must import bpy by itself and run directly in Blender's text editor. "
    "Prefer simple and robust code, with short comments for key steps."
)

# 注释语言指令: 按偏好键取用, 未知值回落英文
_COMMENT_LANGUAGE_DIRECTIVES = {
    'CHINESE': "Write all code comments in Chinese.",
    'ENGLISH': "Write all code comments in English.",
}

# 纯文本对话系统提示词: 不生成脚本文件, 按提问语言作答
_CHAT_SYSTEM_PROMPT = (
    "You are a helpful Blender assistant. "
    "Answer in plain text, concise and accurate. "
    "Reply in the same language as the user's message. "
    "Only include short code snippets when they are explicitly asked for."
)

# 提示词优化系统提示词: 把粗略需求改写成清晰完整的需求描述, 只输出优化后的描述本身.
# 按优化目标分派: 文本面板改写成"需求描述"(给脚本生成用), 图像面板改写成"画面描述"
# (给文生图/图生图用) —— 二者语义不同, 用同一个脚本口吻的系统提示词会把纹理描述
# 改写成"编写一个脚本生成..."的脚本需求(实测缺陷).
_PROMPT_OPTIMIZE_SYSTEM = (
    "You are a Blender scripting assistant. "
    "Rewrite the user's request into a clear, complete and unambiguous description "
    "of the script they need: expected behaviour, objects and data involved, and any "
    "useful details. Output ONLY the optimized description text, "
    "no explanations, no markdown. Reply in the same language as the user's message."
)

# 纹理提示词优化: 产出给文生图模型用的材质贴图画面描述(不涉及脚本/场景物体)
_TEXTURE_PROMPT_OPTIMIZE_SYSTEM = (
    "You are an assistant that writes prompts for a text-to-image model. "
    "The image to produce is a material texture (albedo map) for 3D rendering, "
    "not a rendered scene: describe the surface itself - material type, color, pattern, "
    "grain, wear and fine detail - so it fills the whole frame as a flat texture. "
    "Never mention cameras, lights, scenes, objects, code, scripts or file formats. "
    "Rewrite the user's request into such a prompt: clear, complete and unambiguous. "
    "Output ONLY the optimized description text, no explanations, no markdown. "
    "Reply in the same language as the user's message."
)

# 效果图提示词优化: 产出给图生图模型用的风格描述(构图由参考图决定, 不重复描述物体摆放)
_RENDER_PROMPT_OPTIMIZE_SYSTEM = (
    "You are an assistant that writes prompts for an image editing model that restyles "
    "a reference render of a 3D scene. The camera composition and object placement come "
    "from the reference image, so describe only the desired look: art style, mood, "
    "lighting, color treatment, materials and level of detail. "
    "Never mention code, scripts, file formats or how to implement it in Blender. "
    "Rewrite the user's request into such a prompt: clear, complete and unambiguous. "
    "Output ONLY the optimized description text, no explanations, no markdown. "
    "Reply in the same language as the user's message."
)

# 优化目标 -> 系统提示词(标识与 OptimizePrompt 的 target 枚举一致)
_OPTIMIZE_SYSTEMS = {
    'SCRIPT': _PROMPT_OPTIMIZE_SYSTEM,
    'TEXTURE': _TEXTURE_PROMPT_OPTIMIZE_SYSTEM,
    'RENDER': _RENDER_PROMPT_OPTIMIZE_SYSTEM,
}

# markdown 代码围栏(允许语言标注), 取围栏内部内容
_FENCE_RE = re.compile(r"```[a-zA-Z0-9_+-]*[ \t]*\r?\n(.*?)```", re.DOTALL)

# 响应首行命名行 '# script-name: xxx.py'
_NAME_LINE_RE = re.compile(r"^#\s*script-name:\s*(\S.*?)\s*$", re.IGNORECASE)

# 纯文本对话默认回带的历史消息条数(旧消息截断, 控制请求体大小); 实际取偏好设置
_CHAT_HISTORY_LIMIT = 20

# 文本服务商固定端点与预设默认模型(偏好 _PRESETS 与面板覆盖解析共用单一来源)
CHAT_PROVIDER_ENDPOINTS = {
    'DEEPSEEK': "https://api.deepseek.com",
    'GLM': "https://open.bigmodel.cn/api/paas/v4",
}
CHAT_PROVIDER_DEFAULT_MODELS = {
    'DEEPSEEK': "deepseek-flash",
    'GLM': "glm-5.3",
}


def resolve_chat_endpoint(provider: str, prefs) -> tuple:
    """按生效文本服务商解析 (base_url, api_key): 预设服务商端点固定, 密钥各存一把, CUSTOM 取通用配置"""
    if provider == 'DEEPSEEK':
        return CHAT_PROVIDER_ENDPOINTS['DEEPSEEK'], prefs.deepseek_api_key
    if provider == 'GLM':
        return CHAT_PROVIDER_ENDPOINTS['GLM'], prefs.glm_api_key
    return prefs.base_url, prefs.api_key

# 思考档位由各面板下拉给出档位标识, 按服务商组装参数(props 的档位表按服务商定制):
# GLM: thinking.type 恒 enabled + reasoning_effort(low/high/max);
# DeepSeek: off 经 thinking.type=disabled 关闭(其 reasoning_effort 合法值仅 low/high/max),
# 其余档 thinking.type=enabled + reasoning_effort; 通用服务商: reasoning_effort(low/medium/high)


def _blender_version_line() -> str:
    """当前场景的 Blender 版本行(随 bpy.app.version 动态取, 不写死)"""
    return f"Blender version: {bpy.app.version_string}"


def build_system_prompt(comment_language: str) -> str:
    """按当前 Blender 版本与注释语言组装脚本周系统提示词, 未知语言值回落英文"""
    version = "Blender {}.{}".format(*bpy.app.version[:2])
    directive = _COMMENT_LANGUAGE_DIRECTIVES.get(comment_language, _COMMENT_LANGUAGE_DIRECTIVES['ENGLISH'])
    return f"You are a Blender scripting assistant for {version}. {_SYSTEM_PROMPT_BODY} {directive}"


def build_thinking_extras(provider: str, thinking: str) -> dict:
    """把思考档位组装为该服务商的请求参数, 空值或 DEFAULT 时返回空 dict(用服务商默认)

    thinking 为档位值本身(即该服务商的参数值, 面板下拉按服务商定制):
    GLM 的档位是 thinking.type 取值, 其余服务商是 reasoning_effort 取值.
    """
    if not thinking or thinking == 'DEFAULT':
        return {}
    if provider == 'GLM':
        # GLM-5.3 始终思考且 thinking.type 仅接受 enabled, 思考深度经 reasoning_effort 控制
        return {"thinking": {"type": "enabled"}, "reasoning_effort": thinking}
    if provider == 'DEEPSEEK':
        # DeepSeek 的 reasoning_effort 合法值为 low/high/max, 关闭思考经 thinking.type
        if thinking == 'off':
            return {"thinking": {"type": "disabled"}}
        return {"thinking": {"type": "enabled"}, "reasoning_effort": thinking}
    return {"reasoning_effort": thinking}


def _sanitize_script_name(raw: str) -> str | None:
    """清洗模型给出的脚本名: 非法字符转下划线, 限长, 保证 .py 后缀; 无效返回 None"""
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", raw.removesuffix(".py").strip())
    stem = stem.strip("_")
    if not stem:
        return None
    return f"{stem[:32]}.py"


def extract_script_name(text: str) -> tuple:
    """剥离并解析首行 '# script-name: xxx' 命名行, 返回 (清洗后的脚本名或 None, 其余文本)"""
    lines = text.split("\n", 1)
    match = _NAME_LINE_RE.match(lines[0].strip()) if lines else None
    if not match:
        return None, text
    name = _sanitize_script_name(match.group(1))
    rest = lines[1] if len(lines) > 1 else ""
    return name, rest.lstrip("\r\n")


def build_context_info(context: Context) -> tuple:
    """汇总场景上下文摘要, 返回 (摘要文本, 错误信息)"""
    sel_names = ", ".join(obj.name for obj in context.selected_objects)
    act_obj = context.active_object
    lines = [
        f"Blender version: {bpy.app.version_string}",
        f"Scene: {context.scene.name}",
        f"Objects in scene: {len(context.scene.objects)}",
        f"Selected objects ({len(context.selected_objects)}): {sel_names or 'None'}",
        f"Active object: {act_obj.name if act_obj else 'None'}",
    ]
    return "\n".join(lines), None


def _with_version(content: str, context_info: str | None) -> str:
    """描述与可选场景上下文拼装后强制附 Blender 版本行(与 use_context 开关解耦)"""
    if context_info:
        return f"{content}\n\n--- Scene context ---\n{context_info}"
    return f"{content}\n\n--- Scene context ---\n{_blender_version_line()}"


def build_generation_messages(prompt: str, context_info: str | None, comment_language: str = 'ENGLISH') -> tuple:
    """组装脚本生成请求的消息列表, 返回 (messages, 错误信息)"""
    content = _with_version(prompt, context_info)
    messages = [
        {"role": "system", "content": build_system_prompt(comment_language)},
        {"role": "user", "content": content},
    ]
    return messages, None


def build_debug_messages(script: str, error_text: str, context_info: str | None,
                         comment_language: str = 'ENGLISH') -> tuple:
    """组装脚本调试请求的消息列表(原脚本 + 报错 + 可选上下文), 返回 (messages, 错误信息)"""
    content = _with_version(
        (
            "The Blender Python script below failed. "
            "Find the bug and output ONLY the corrected complete script: "
            "no explanations, no markdown code fences.\n\n"
            f"--- Script ---\n{script}\n\n"
            f"--- Error ---\n{error_text}"
        ),
        context_info,
    )
    messages = [
        {"role": "system", "content": build_system_prompt(comment_language)},
        {"role": "user", "content": content},
    ]
    return messages, None


def build_revise_messages(script: str, request: str, context_info: str | None,
                          comment_language: str = 'ENGLISH') -> tuple:
    """组装对话修改请求的消息列表(当前脚本 + 修改要求 + 可选上下文), 返回 (messages, 错误信息)

    要求模型在每个修改/新增的行或块头部写一条简短 '# Changed: ...' 说明,
    并只改动与修改要求相关的部分, 其余代码逐字保持原样(压重写漂移);
    说明语言跟随系统提示词的注释语言指令.
    """
    content = _with_version(
        (
            "Modify the Blender Python script below according to the modification request. "
            "Modify ONLY the parts related to the modification request and keep every other "
            "line exactly as it is. "
            "For every modified or added line or block, put a brief comment at its head "
            "in the form '# Changed: what was modified', so the changes can be spotted at a glance. "
            "Output ONLY the name line and the complete modified script: "
            "no explanations, no markdown code fences.\n\n"
            f"--- Script ---\n{script}\n\n"
            f"--- Modification request ---\n{request}"
        ),
        context_info,
    )
    messages = [
        {"role": "system", "content": build_system_prompt(comment_language)},
        {"role": "user", "content": content},
    ]
    return messages, None


def build_chat_messages(history: list, message: str, history_limit: int = _CHAT_HISTORY_LIMIT) -> tuple:
    """组装纯文本对话请求的消息列表, 返回 (messages, 错误信息)

    history 为 (role, content) 元组列表, role 取 'user'/'assistant';
    随请求发送最近 history_limit 条历史(0 表示只发本次消息), 新消息始终保留.
    """
    messages = [{"role": "system", "content": _CHAT_SYSTEM_PROMPT}]
    if history_limit > 0:
        for role, content in history[-history_limit:]:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": message})
    return messages, None


def build_optimize_messages(prompt: str, target: str = 'SCRIPT') -> tuple:
    """组装提示词优化请求的消息列表, 返回 (messages, 错误信息)

    target 为优化目标('SCRIPT'/'TEXTURE'/'RENDER'): 决定系统提示词的口吻,
    未知值回落脚本口吻.
    """
    messages = [
        {"role": "system", "content": _OPTIMIZE_SYSTEMS.get(target, _PROMPT_OPTIMIZE_SYSTEM)},
        {"role": "user", "content": prompt},
    ]
    return messages, None


# 自动命名系统提示词: 由提示词给出简短英文 snake_case 名(数据块名/列表/缩略图标签都要 ASCII,
# 非 ASCII 会在缩略图标签上乱码, 故只接受 ASCII 字母数字下划线)
_AUTO_NAME_SYSTEM = (
    "You name images for a Blender asset library. "
    "Given the user's description of an image, reply with ONLY a short English snake_case name "
    "describing it, at most four words (for example: light_oak_wood_planks). "
    "Use ASCII letters, digits and underscores only: no quotes, no punctuation, no explanation."
)

# 命名结果里常见的前缀标记(如 "name: xxx"), 清洗前先去掉
_NAME_PREFIX_RE = re.compile(r"(?i)^\s*(name|texture|render|image|answer)\s*[:\-]\s*")


def build_auto_name_messages(prompt: str) -> tuple:
    """组装自动命名请求的消息列表(提示词 -> 简短英文 snake_case 名), 返回 (messages, 错误信息)"""
    messages = [
        {"role": "system", "content": _AUTO_NAME_SYSTEM},
        {"role": "user", "content": prompt},
    ]
    return messages, None


def sanitize_auto_name(text: str) -> str:
    """把命名结果清洗为 ASCII snake_case 名(去前缀标记/非法字符转下划线, 取前四个词, 总长封顶 40)

    返回空串表示结果不可用(调用方保留原名).
    """
    stripped = _NAME_PREFIX_RE.sub("", (text or "").strip())
    words = re.sub(r"[^A-Za-z0-9_ ]+", " ", stripped).split()
    if not words:
        return ""
    name = "_".join(words[:4])[:40].strip("_").lower()
    return name if any(c.isalpha() for c in name) else ""


def _http_error_text(e: urllib.error.HTTPError):
    """HTTP 错误转错误对象(消息可翻译, 服务端错误码与消息作 detail 原样透出)"""
    detail = ""
    try:
        body = json.loads(e.read().decode("utf-8"))
        err = body.get("error", body)
        code = err.get("code", "")
        message = err.get("message", "")
        if code or message:
            detail = f"{code} {message}".strip()
    except Exception:
        pass
    return api_error("HTTP request failed", f"{e.code} {e.reason} {detail}".strip())


# 脚本类请求(生成/调试/修改/优化)的输出额度: 思考模型需为思考链与正文都留出空间,
# 不下发时服务端默认额度可能被思考耗尽导致正文为空(GLM-5.3 实测)
SCRIPT_MAX_TOKENS = 8192
# GLM 的思考链更长(5.3 强制思考且默认高档), 额度不足以覆盖思考+脚本, 单独提高
# (65536 为智谱官方 glm-5.3 编码场景示例值)
SCRIPT_MAX_TOKENS_GLM = 65536

# 脚本类请求的超时下限(秒): 非流式请求需等完整响应, 思考模型+长脚本生成耗时远超
# 对话级超时(GLM-5.3 生成脚本在 60s 超时下限内必超, 作者实测); 取偏好与下限的较大者
SCRIPT_TIMEOUT_MIN = 300


def request_chat(base_url: str, api_key: str, model: str, temperature: float, timeout: int, messages: list,
                 provider: str = 'CUSTOM', thinking: str = "", max_tokens: int | None = None,
                 allow_empty_content: bool = False) -> tuple:
    """单次请求 OpenAI 兼容 chat 接口, 不自动重试; 返回 (回复文本, 错误信息)

    provider 与 thinking 用于按服务商拼接思考级别附加参数, 见 build_thinking_extras;
    max_tokens 限回复总长度(含思考), None 不下发; allow_empty_content 供连通性测试使用
    (思考模型在额度不足时正文为空但服务本身正常).
    """
    url = base_url.rstrip('/') + "/chat/completions"
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
    }
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    payload.update(build_thinking_extras(provider, thinking))
    body = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return None, _http_error_text(e)
    except TimeoutError:
        # 超过偏好 Timeout 的专门文案(TimeoutError 是 OSError 子类, 须先于 OSError 分支)
        return None, api_error("Request timed out")
    except urllib.error.URLError as e:
        # 连接握手阶段的超时会被包进 URLError.reason, 单独识别
        if isinstance(e.reason, TimeoutError):
            return None, api_error("Request timed out")
        return None, api_error("Request failed", e.reason)
    except OSError as e:
        # 其余网络层错误(连接重置/远端断开等不是 URLError 的形态)
        return None, api_error("Connection error", e)
    except json.JSONDecodeError:
        return None, api_error("API returned invalid JSON")

    try:
        message = data["choices"][0]["message"]
        content = message["content"]
    except (KeyError, IndexError, TypeError):
        return None, api_error("Unexpected API response format")
    if not isinstance(content, str) or not content.strip():
        if allow_empty_content:
            return "", None
        # 思考模型(如 GLM-5.3 强制思考)在额度不足时只出思考链, 正文为空: 给出可诊断的文案
        reasoning = message.get("reasoning_content")
        if isinstance(reasoning, str) and reasoning.strip():
            return None, api_error("The model returned only thinking output without an answer, "
                                   "the response may have been cut off by the output token limit")
        return None, api_error("API returned empty content")
    return content, None


def ping_chat(base_url: str, api_key: str, model: str, timeout: int, provider: str = 'CUSTOM') -> tuple:
    """最小请求验证文本服务连通与密钥, 返回 (响应描述, 错误信息)

    思考模型(如 GLM-5.3)的小额度请求可能只返回思考链, 正文为空, 属服务正常;
    以 HTTP 成功且响应结构合法为连通判据(allow_empty_content).
    """
    _content, err = request_chat(base_url, api_key, model, 0, timeout,
                                 [{"role": "user", "content": "ping"}],
                                 provider=provider, max_tokens=16, allow_empty_content=True)
    if err is None:
        return api_error("Chat OK, the model responded"), None
    return None, err


def _find_value(obj, keys):
    """在响应 JSON 中递归查找首个命中的键值(结构未确证时的自适应解析)"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in keys and isinstance(v, (str, int, float)):
                return str(v)
        for v in obj.values():
            found = _find_value(v, keys)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for v in obj:
            found = _find_value(v, keys)
            if found is not None:
                return found
    return None


def fetch_deepseek_balance(base_url: str, api_key: str, timeout: int) -> tuple:
    """查询 DeepSeek 账户余额(官方 user/balance 接口), 返回 (余额描述, 错误信息)

    预期响应含 balance_information.total_balance/currency; 实际结构不符时
    把原始响应截断展示(便于按真实结构修正解析).
    """
    url = base_url.rstrip('/') + "/user/balance"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {api_key}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            data = json.loads(raw)
    except TimeoutError:
        return None, api_error("Request timed out")
    except urllib.error.HTTPError as e:
        return None, _http_error_text(e)
    except (urllib.error.URLError, OSError) as e:
        return None, api_error("Request failed", e)
    except json.JSONDecodeError:
        return None, api_error("API returned invalid JSON")
    total = _find_value(data, ("total_balance", "balance"))
    currency = _find_value(data, ("currency",)) or ""
    if total is None:
        return api_error("Balance query succeeded but the response was unexpected", raw[:200]), None
    return api_error("Account balance", f"{total} {currency}".strip()), None


def strip_code_fences(text: str) -> str:
    """剥掉 markdown 代码围栏; 有围栏取围栏内容(多块拼接), 无围栏取原文收尾去白"""
    blocks = [block.strip() for block in _FENCE_RE.findall(text) if block.strip()]
    if blocks:
        return "\n\n".join(blocks)
    return text.strip()


def extract_code_blocks(text: str) -> tuple:
    """提取消息中的代码围栏内容与围栏外说明文本, 返回 (代码, 说明文本, 是否存在围栏)"""
    blocks = [block.strip() for block in _FENCE_RE.findall(text) if block.strip()]
    description = _FENCE_RE.sub("", text).strip()
    if not blocks:
        return "", description, False
    return "\n\n".join(blocks), description, True


def validate_script(code: str) -> tuple:
    """语法校验脚本文本, 返回 (compile 产物或 None, 语法错误信息或 None)"""
    try:
        return compile(code, "<ai_script>", 'exec'), None
    except SyntaxError as e:
        return None, api_error("The script has a syntax error", f"line {e.lineno}: {e.msg}")
