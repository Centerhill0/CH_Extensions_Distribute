"""
图像 IO 工具模块

生成图片字节的加载, 无缝化处理, 命名, 存盘与图像编辑器聚焦.

主要功能:
- load_image_from_bytes: 图片字节经临时文件加载为图像数据块(随即打包并删临时文件)
- save_image_file: 图像数据块另存为 PNG 到指定目录
- make_seamless: 边缘羽化镜像混合, 把图片字节处理为像素级可平铺的无缝图(尺寸不变)
- prompt_stem: 提示词转短名(英文词组), 无英文词回落空串
- unique_ai_name: 生成图像数据块的不冲突名(冲突加 .00N 序号)
- focus_image_editors: 把所有图像编辑器区域聚焦到指定图像
- has_uv_layers: 判断物体数据是否已有 UV 贴图层(纹理显示提示用)
"""

import os
import re
import tempfile

import bpy
import numpy as np
from bpy.types import Context, Image, Object

from .errors import api_error

# 无缝化羽化带占单边宽/高的比例(两端各一条, 带宽保底 1 像素, 上限为单边的 1/4)
_SEAMLESS_FEATHER = 0.15


def _image_suffix(image_bytes: bytes) -> str:
    """按魔数嗅探图片格式后缀(PNG/JPEG), 未知回落 .png"""
    if image_bytes.startswith(b"\x89PNG"):
        return ".png"
    if image_bytes.startswith(b"\xff\xd8"):
        return ".jpg"
    return ".png"


def load_image_from_bytes(image_bytes: bytes, name: str) -> tuple:
    """把图片字节写入临时文件并加载为图像数据块, 返回 (Image 数据块, 错误信息)

    载入后打包进 blend 并删除临时文件(数据块自包含, 跨机不丢图);
    重名时 Blender 自动追加 .001 序号, 调用方以返回的 image.name 为准.
    """
    if not image_bytes:
        return None, api_error("Image data is empty")
    fd, path = tempfile.mkstemp(suffix=_image_suffix(image_bytes), prefix="ch_ai_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(image_bytes)
        image = bpy.data.images.load(path)
    except (OSError, RuntimeError) as e:
        try:
            os.remove(path)
        except OSError:
            pass
        return None, api_error("Generated image data is invalid", e)
    # 非图片字节(错误页/截断下载体)会被 Blender 静默载成 0x0 空块而不抛异常,
    # 不校验就会当成功返回, 调用方随后报"已创建"却得到空图
    width, height = image.size
    if not image.has_data or width == 0 or height == 0:
        bpy.data.images.remove(image)
        try:
            os.remove(path)
        except OSError:
            pass
        return None, api_error("Generated image data could not be decoded")
    image.name = name
    image.pack()
    try:
        os.remove(path)
    except OSError:
        pass  # 临时文件删除失败无害(位于系统临时目录)
    return image, None


def save_image_file(image: Image, directory: str) -> tuple:
    """把图像数据块存为 PNG 到指定目录, 返回 (文件路径, 错误信息)

    文件名取图像数据块名(非法字符转下划线), 重名时覆盖.
    """
    try:
        os.makedirs(directory, exist_ok=True)
        stem = re.sub(r"[^A-Za-z0-9_-]+", "_", image.name).strip("_") or "ai_image"
        path = os.path.join(directory, f"{stem}.png")
        image.filepath_raw = path
        image.file_format = 'PNG'
        image.save()
    except (OSError, RuntimeError) as e:
        return None, api_error("Failed to save image", e)
    return path, None


def _edge_feather_alpha(length: int) -> np.ndarray:
    """平铺羽化权重(0-1, 长度 length): 两端各 FEATHER_RATIO 带内线性过渡, 中段恒 1

    中段保持 1 意味着只把两端各一条窄带替换为滚转内容(接缝处必然连续),
    原图主体不被重影; 带宽按尺寸比例取整并保底 1 像素.
    """
    alpha = np.ones(length, dtype=np.float32)
    band = max(1, min(length // 4, int(round(length * _SEAMLESS_FEATHER))))
    ramp = np.linspace(0.0, 1.0, band + 1, dtype=np.float32)[:-1]
    alpha[:band] = ramp
    alpha[length - band:] = ramp[::-1]
    return alpha


def make_seamless(image_bytes: bytes) -> tuple:
    """把图片字节做边缘羽化无缝化, 输出像素级可平铺的图(尺寸不变), 返回 (图片字节, 错误信息)

    原理: 两端各一条窄带(总宽约 2*FEATHER_RATIO)与半宽滚转内容按线性权重混合, 中段原样保留;
    平铺边界两侧恰为原图中部相邻内容, 必然连续; 代价是窄带内出现中部内容的滚转呼应.
    提示词引导无法保证服务端真出无缝图, 本地处理兜底保证可平铺.
    """
    fd, path = tempfile.mkstemp(suffix=_image_suffix(image_bytes), prefix="ch_ai_src_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(image_bytes)
        image = bpy.data.images.load(path)
    except (OSError, RuntimeError) as e:
        return None, api_error("Generated image data is invalid", e)

    out_img = None
    fd2, path2 = tempfile.mkstemp(suffix=".png", prefix="ch_ai_seam_")
    os.close(fd2)
    try:
        width, height = image.size
        buf = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(buf)
        rgb = buf.reshape(height, width, 4)[..., :3].copy()
        # 水平方向: 两端羽化带取半宽滚转内容, 中段保留原图
        wx = _edge_feather_alpha(width)
        rgb = rgb * wx[None, :, None] + np.roll(rgb, width // 2, axis=1) * (1.0 - wx)[None, :, None]
        # 垂直方向同法
        wy = _edge_feather_alpha(height)
        rgb = rgb * wy[:, None, None] + np.roll(rgb, height // 2, axis=0) * (1.0 - wy)[:, None, None]
        out = np.ones((height, width, 4), dtype=np.float32)
        out[..., :3] = rgb

        out_img = bpy.data.images.new("CH_AI_Seamless", width, height, alpha=False)
        # colorspace sRGB: 像素(线性)编码落盘, 与 load 的默认识别一致, 往返还原线性值
        out_img.colorspace_settings.name = 'sRGB'
        out_img.filepath_raw = path2
        out_img.file_format = 'PNG'
        out_img.pixels.foreach_set(out.ravel())
        out_img.save()
        with open(path2, "rb") as f:
            return f.read(), None
    except (OSError, RuntimeError, ValueError) as e:
        return None, api_error("Failed to make the image seamless", e)
    finally:
        bpy.data.images.remove(image)
        if out_img is not None:
            bpy.data.images.remove(out_img)
        for p in (path, path2):
            try:
                os.remove(p)
            except OSError:
                pass


def prompt_stem(prompt: str, words: int = 8) -> str:
    """提示词转短名(取前 words 个英文词, 非法字符转下划线), 无英文词回落空串由调用方取默认名"""
    filtered = re.sub(r"[^A-Za-z0-9_ -]+", " ", prompt).split()
    if not filtered:
        return ""
    return "_".join(filtered[:words])[:48]


def unique_ai_name(base: str) -> str:
    """图像数据块不冲突名: 同名时追加 .00N 序号(与 Blender 自动去重同格式)"""
    if base not in bpy.data.images:
        return base
    idx = 1
    while f"{base}.{idx:03d}" in bpy.data.images:
        idx += 1
    return f"{base}.{idx:03d}"


def focus_image_editors(context: Context, image: Image) -> tuple:
    """把所有图像编辑器区域的活动图像设为指定图像, 返回 (聚焦区域数, 错误信息)"""
    focused = 0
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = image
                focused += 1
    return focused, None


def has_uv_layers(obj: Object) -> bool:
    """物体数据是否已有 UV 贴图层(无 UV 时纹理按 Generated 坐标映射, 显示异常)"""
    uv_layers = getattr(getattr(obj, "data", None), "uv_layers", None)
    return uv_layers is not None and len(uv_layers) > 0
