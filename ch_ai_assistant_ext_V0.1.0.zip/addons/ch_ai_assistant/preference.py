"""
偏好设置模块

面板为左右两列, 按服务划分: 左列文本服务(接入配置 + 文本生成参数含编辑器联动),
右列图像服务(接入配置 + 图像生成参数含图像编辑器联动)

提供以下功能:
- AI 服务接入配置: 服务商预设(DeepSeek/智谱/自定义), API 地址, 密钥, 模型, 温度, 超时
- 文本生成参数: 脚本注释语言, 对话上下文条数, 脚本输出上限, 场景上下文开关
- 图像服务接入配置: 服务商预设(火山方舟/阿里百炼/自定义), API 地址, 密钥, 文生图/图生图模型, 超时, 产物存盘目录
- 文本编辑器联动: 自动在文本编辑器打开脚本产物/对话消息的开关(面板内亦有快捷开关)
- 图像编辑器联动: 自动在图像编辑器打开列表图像的开关(面板内亦有快捷开关)
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Context

from .config import __addon_name__
from .utils.ai_client import CHAT_PROVIDER_DEFAULT_MODELS, CHAT_PROVIDER_ENDPOINTS
from .utils.image_client import PROVIDER_DEFAULT_MODELS, PROVIDER_ENDPOINTS

# 文本服务商候选模型(标识即模型名; 面板覆盖下拉与偏好共用单一来源)
# 首项空标识 = 跟随偏好设置中的模型名: 动态 items 枚举不接受空串**赋值**, 但空串**标识**合法,
# 故用"跟随偏好"哨兵档占位(文本与图像两侧的面板下拉共用它, 见 props 的 *_model_items)
_prefs_model_items = [
    ('', "Follow preferences", "Use the model configured in the preferences"),
]
_text_deepseek_model_items = [
    ('deepseek-flash', "DeepSeek Flash", "DeepSeek V4.1 Flash model, fast and inexpensive"),
    ('deepseek-v4-pro', "DeepSeek V4 Pro", "DeepSeek V4 Pro model, strongest reasoning"),
]
_text_glm_model_items = [
    ('glm-5.3-flash', "GLM-5.3 Flash", "Zhipu GLM-5.3 Flash model, fast and inexpensive"),
    ('glm-5.3', "GLM-5.3", "Zhipu GLM-5.3 flagship model"),
]
TEXT_PROVIDER_MODEL_ITEMS = {
    'DEEPSEEK': _text_deepseek_model_items + _prefs_model_items,
    'GLM': _text_glm_model_items + _prefs_model_items,
}

# 服务商预设: 条目标识 -> (base_url, 默认模型); CUSTOM 不回填, 由用户手动填写
_PRESETS = {
    'DEEPSEEK': (CHAT_PROVIDER_ENDPOINTS['DEEPSEEK'], CHAT_PROVIDER_DEFAULT_MODELS['DEEPSEEK']),
    'GLM': (CHAT_PROVIDER_ENDPOINTS['GLM'], CHAT_PROVIDER_DEFAULT_MODELS['GLM']),
}

provider_items = [
    ('DEEPSEEK', "DeepSeek", "DeepSeek OpenAI-compatible API"),
    ('GLM', "Zhipu GLM", "Zhipu AI OpenAI-compatible API"),
    ('CUSTOM', "Custom", "Manually fill in base URL and model"),
]

# 图像服务商预设: 条目标识 -> (base_url, 文生图默认模型, 图生图默认模型); CUSTOM 不回填
# qwen-image-3.0-pro 统一文生图与参考图生图, 两栏同填
_IMAGE_PRESETS = {
    'VOLCENGINE': (PROVIDER_ENDPOINTS['VOLCENGINE'], PROVIDER_DEFAULT_MODELS['VOLCENGINE'], PROVIDER_DEFAULT_MODELS['VOLCENGINE']),
    'DASHSCOPE': (PROVIDER_ENDPOINTS['DASHSCOPE'], PROVIDER_DEFAULT_MODELS['DASHSCOPE'], PROVIDER_DEFAULT_MODELS['DASHSCOPE']),
}

# 连通性测试算子的 bl_idname 常量: 偏好 draw 与算子类共用(偏好→算子会循环导入, 以常量单向引用)
TEST_TEXT_OP = "ch_ai.test_text_service"
TEST_IMAGE_OP = "ch_ai.test_image_service"

image_provider_items = [
    ('VOLCENGINE', "Volcengine Ark", "Volcengine Ark image API (Doubao Seedream)"),
    ('DASHSCOPE', "Alibaba DashScope", "Alibaba Model Studio image API (Qwen-Image)"),
    ('CUSTOM', "Custom", "Manually fill in base URL and models"),
]

# 纹理/编辑模型下拉条目(标识即模型名, 下拉下方备注行显示具体名称, 见 draw):
# 按图像服务商动态选择(见 _t2i_model_items_fn); 列表命名保持 *_items 结尾供 i18n 提取
_volcengine_t2i_items = [
    ('doubao-seedream-5-0-flash-260915', "Seedream 5.0 Flash", "Doubao Seedream 5.0 Flash image model, lighter and faster"),
    ('doubao-seedream-5-0-pro-260628', "Seedream 5.0 Pro", "Doubao Seedream 5.0 Pro image model"),
]
_dashscope_t2i_items = [
    ('qwen-image-3.0', "Qwen-Image 3.0", "Alibaba Qwen-Image 3.0 image model"),
    ('qwen-image-3.0-pro', "Qwen-Image 3.0 Pro", "Alibaba Qwen-Image 3.0 Pro image model"),
]
_volcengine_edit_items = _volcengine_t2i_items
_dashscope_edit_items = _dashscope_t2i_items

# 每服务商的模型候选字典(标识即模型名): 供偏好动态下拉与面板覆盖下拉共用(单一来源)
PROVIDER_MODEL_ITEMS = {
    'VOLCENGINE': _volcengine_t2i_items,
    'DASHSCOPE': _dashscope_t2i_items,
}


def _t2i_model_items_fn(self, context):
    """纹理模型下拉条目按图像服务商动态切换"""
    return PROVIDER_MODEL_ITEMS.get(self.image_provider, _volcengine_t2i_items)


def _edit_model_items_fn(self, context):
    """编辑模型下拉条目按图像服务商动态切换"""
    return PROVIDER_MODEL_ITEMS.get(self.image_provider, _volcengine_edit_items)


comment_language_items = [
    ('CHINESE', "Chinese", "Write script comments in Chinese"),
    ('ENGLISH', "English", "Write script comments in English"),
]


def _text_model_choice_items_fn(self, context):
    """文本模型偏好下拉条目按文本服务商动态切换(CUSTOM 无候选, 用输入框)"""
    return TEXT_PROVIDER_MODEL_ITEMS.get(self.provider, [])


def _apply_preset(self, _context):
    """切换服务商预设时回填 API 地址与模型, 并对齐模型选择器(预设模型名须在条目内)"""
    preset = _PRESETS.get(self.provider)
    if preset is not None:
        self.base_url, self.model = preset
        self.model_choice = self.model


def _apply_model_choice(self, _context):
    """下拉选择模型: 回填实际模型名"""
    self.model = self.model_choice


def _apply_image_preset(self, _context):
    """切换图像服务商预设时回填 API 地址与文生图/图生图模型, 并对齐两个模型选择器
    (预设模型名须在下拉条目内, 否则 RNA 赋值报错)"""
    preset = _IMAGE_PRESETS.get(self.image_provider)
    if preset is not None:
        self.image_base_url, self.image_model_t2i, self.image_model_edit = preset
        self.image_t2i_choice = self.image_model_t2i
        self.image_edit_choice = self.image_model_edit


def _apply_t2i_choice(self, _context):
    """下拉选择纹理模型: 回填实际模型名"""
    self.image_model_t2i = self.image_t2i_choice


def _apply_edit_choice(self, _context):
    """下拉选择编辑模型: 回填实际模型名"""
    self.image_model_edit = self.image_edit_choice


def _draw_service_test(layout, op_idname: str, result: str, ok: bool):
    """绘制服务连通性测试行: 左对齐的测试按钮 + 结果提示(结果为空时不画)

    result/ok 取自 ch_service_test 状态属性(文本与图像各有一对)
    """
    # property_split 下 operator 会拉伸满行, 左对齐行让其收缩为内容宽度
    btn_row = layout.row()
    btn_row.alignment = 'LEFT'
    btn_row.operator(op_idname, text="Test", icon='PLAY')
    if result:
        res_row = btn_row.row(align=True)
        res_row.enabled = False
        res_row.label(text=result, icon='CHECKMARK' if ok else 'ERROR')


class AiAssistantPreferences(AddonPreferences):
    """AI 助手偏好设置(左列文本服务, 右列图像服务)"""

    # 必须与 __addon_name__ 一致, Blender 据此定位偏好面板
    bl_idname = __addon_name__

    provider: EnumProperty(name="Provider", items=provider_items, default='DEEPSEEK', update=_apply_preset)  # type: ignore
    # OpenAI 兼容接口基地址, 请求时拼接 /chat/completions
    base_url: StringProperty(
        name="API Base URL",
        description="OpenAI-compatible API endpoint, e.g. https://api.deepseek.com",
        default="https://api.deepseek.com",
    )  # type: ignore
    api_key: StringProperty(
        name="API Key",
        description="Secret key for the custom text service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    deepseek_api_key: StringProperty(
        name="DeepSeek API Key",
        description="Secret key of the DeepSeek service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    glm_api_key: StringProperty(
        name="GLM API Key",
        description="Secret key of the Zhipu GLM service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    # 模型选择器: 预设服务商下为下拉(动态候选), CUSTOM 下隐藏改用下方输入框(见 draw)
    model_choice: EnumProperty(
        name="Model",
        description="Select the chat model",
        items=_text_model_choice_items_fn,
        update=_apply_model_choice,
    )  # type: ignore
    model: StringProperty(
        name="Model",
        description="Chat model name, e.g. deepseek-flash",
        default="deepseek-flash",
    )  # type: ignore
    temperature: FloatProperty(
        # 用 "Sampling Temperature" 而非常见词 "Temperature": 避开 Blender 自带翻译对常见词的遮蔽
        name="Sampling Temperature",
        description="Sampling randomness: 0 is the most deterministic, higher is more creative. 0-0.3 recommended for scripts",
        default=0.0,
        min=0.0,
        max=2.0,
        precision=1,
    )  # type: ignore
    comment_language: EnumProperty(
        name="Comment Language",
        description="Language of the comments written in generated and modified scripts",
        items=comment_language_items,
        default='CHINESE',
    )  # type: ignore
    # 文本请求单次超时秒数, 请求失败不自动重试
    timeout: IntProperty(
        name="Timeout",
        description="Request timeout in seconds for chat and other short requests; script requests automatically use at least 300 seconds because thinking models need longer to generate a full script",
        default=60,
        min=5,
        max=600,
    )  # type: ignore
    # 脚本类请求输出上限(含思考链): 0 = 按服务商自动策略(DeepSeek 省略用服务端默认, GLM 65536, 其余 8192)
    script_max_tokens: IntProperty(
        name="Script Output Limit",
        description="Upper limit of output tokens (not characters) for script requests, thinking output included. 0 uses the per-provider automatic strategy: omitted for DeepSeek (server default), 65536 for GLM and 8192 for the other providers. Setting a larger value is safe because billing follows actual usage; too small a value may cut the answer off",
        default=0,
        min=0,
        max=131072,
    )  # type: ignore
    # 对话上下文条数: 随每次发送携带的最近历史消息数(0 表示只发当前消息), 会话存 WM 不随 blend 保存
    chat_history_limit: IntProperty(
        name="Chat History Limit",
        description="Number of recent chat messages sent to the AI as conversation context, 0 sends only the current message",
        default=20,
        min=0,
        max=200,
    )  # type: ignore
    use_context: BoolProperty(
        name="Include Scene Context",
        description="Send Blender version and selection info with AI requests",
        default=True,
    )  # type: ignore
    # 编辑器联动开关(侧栏面板内亦有快捷开关): 是否自动把产物/所选条目送入文本编辑器
    use_auto_open_scripts: BoolProperty(
        name="Auto Open Scripts",
        description="Show generated, debugged and revised scripts, and the script clicked in the list, in the text editor automatically",
        default=True,
    )  # type: ignore
    use_auto_open_chat: BoolProperty(
        name="Auto Open Chat",
        description="Show the chat message clicked in the list and new replies in the text editor automatically",
        default=True,
    )  # type: ignore
    # 图像编辑器联动开关(纹理/效果图两面板内亦有快捷开关): 是否自动把列表点击的图像送入图像编辑器
    use_auto_open_images: BoolProperty(
        name="Auto Open Images",
        description="Show the texture or render clicked in the list in the image editor automatically",
        default=True,
    )  # type: ignore

    # ---- 图像服务偏好(右列; 与文本服务分开配置密钥, 互不影响) ----
    image_provider: EnumProperty(
        name="Provider",
        description="Provider of the AI image service",
        items=image_provider_items,
        default='VOLCENGINE',
        update=_apply_image_preset,
    )  # type: ignore
    image_base_url: StringProperty(
        name="API Base URL",
        description="Base URL of the image API, e.g. https://ark.cn-beijing.volces.com/api/v3",
        default="https://ark.cn-beijing.volces.com/api/v3",
    )  # type: ignore
    image_api_key: StringProperty(
        name="API Key",
        description="Secret key for the custom image service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    volcengine_api_key: StringProperty(
        name="Volcengine API Key",
        description="Secret key of the Volcengine Ark image service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    dashscope_api_key: StringProperty(
        name="DashScope API Key",
        description="Secret key of the Alibaba DashScope image service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    # 纹理模型: 预设服务商下为模型下拉(标识即模型名), Custom 服务商下为输入框(见 draw)
    image_t2i_choice: EnumProperty(
        name="Texture Model",
        description="Select the texture generation model",
        items=_t2i_model_items_fn,
        update=_apply_t2i_choice,
    )  # type: ignore
    image_model_t2i: StringProperty(
        name="Texture Model",
        description="Image model name used for text-to-image texture generation",
        default="doubao-seedream-5-0-pro-260628",
    )  # type: ignore
    # 编辑模型: 预设服务商下为模型下拉, Custom 服务商下为输入框(见 draw)
    image_edit_choice: EnumProperty(
        name="Edit Model",
        description="Select the image edit model",
        items=_edit_model_items_fn,
        update=_apply_edit_choice,
    )  # type: ignore
    image_model_edit: StringProperty(
        name="Edit Model",
        description="Image model name used for reference-image concept renders",
        default="doubao-seedream-5-0-pro-260628",
    )  # type: ignore
    # 图像请求单次超时秒数(生图比对话慢, 默认放宽), 请求失败不自动重试
    image_timeout: IntProperty(
        name="Timeout",
        description="Request timeout in seconds for image generation requests",
        default=180,
        min=5,
        max=600,
    )  # type: ignore
    # 自动命名: 提示词取不出英文短名(如纯中文提示词)时, 用全局文本服务起一个简短英文名
    use_auto_name: BoolProperty(
        name="Auto Name",
        description="When a prompt has no English words (so the generated name falls back to the generic one), ask the global text service for a short English name and rename the new image with it; failures keep the generic name",
        default=True,
    )  # type: ignore
    # 生成图片的存盘目录: 留空时图片仅打包进 blend 文件
    image_save_dir: StringProperty(
        name="Image Save Directory",
        description="Directory to save generated images as files, empty keeps them packed in the blend only",
        subtype='DIR_PATH',
    )  # type: ignore

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.alignment = 'CENTER'

        # 左右两列按服务划分: 文本与图像各自的服务接入与生成参数(编辑器联动并入生成盒内),
        # 避免按功能分列时图像专属参数与文本参数混排
        split = layout.split()
        col_text = split.column()
        col_image = split.column()

        # ---- 左列 文本服务 ----
        box = col_text.box()
        box.label(text="Text Service", icon="PREFERENCES")
        box.prop(self, "provider")
        if self.provider == 'CUSTOM':
            box.prop(self, "base_url")
            box.prop(self, "api_key")
            box.prop(self, "model")
        else:
            key_attr = "deepseek_api_key" if self.provider == 'DEEPSEEK' else "glm_api_key"
            box.prop(self, key_attr)
            # 下拉与模型 ID 备注紧贴成对(align 列消除对间空距)
            pair = box.column(align=True)
            pair.prop(self, "model_choice")
            note = pair.row()
            note.enabled = False
            note.prop(self, "model", text=" ", emboss=False)
        # 连通性测试: DeepSeek 附带余额查询, 其余发 max_tokens=1 的 ping
        ts = context.window_manager.ch_service_test
        _draw_service_test(box, TEST_TEXT_OP, ts.text_result, ts.text_ok)

        box = col_text.box()
        box.label(text="Text Generation", icon="SETTINGS")
        box.prop(self, "temperature")
        box.prop(self, "comment_language")
        box.prop(self, "chat_history_limit")
        box.prop(self, "script_max_tokens")
        box.prop(self, "timeout")
        box.prop(self, "use_context")
        # 编辑器联动开关并入本盒, 以分隔行与生成参数区隔
        box.prop(self, "use_auto_open_scripts")
        box.prop(self, "use_auto_open_chat")

        # ---- 右列 图像服务 ----
        # 模型控件按服务商切换: 预设服务商显示模型下拉(下方禁用文本行备注实际模型名, 与下拉同列对齐),
        # Custom 显示手输名输入框
        box = col_image.box()
        box.label(text="Image Service", icon="IMAGE_DATA")
        box.prop(self, "image_provider")
        if self.image_provider == 'CUSTOM':
            box.prop(self, "image_base_url")
            box.prop(self, "image_api_key")
            box.prop(self, "image_model_t2i")
            box.prop(self, "image_model_edit")
        else:
            key_attr = "volcengine_api_key" if self.image_provider == 'VOLCENGINE' else "dashscope_api_key"
            box.prop(self, key_attr)
            # 下拉与模型 ID 备注紧贴成对(align 列消除对间空距)
            pair = box.column(align=True)
            pair.prop(self, "image_t2i_choice")
            note = pair.row()
            note.enabled = False
            note.prop(self, "image_model_t2i", text=" ", emboss=False)
            pair = box.column(align=True)
            pair.prop(self, "image_edit_choice")
            note = pair.row()
            note.enabled = False
            note.prop(self, "image_model_edit", text=" ", emboss=False)
        # 连通性测试: 发一次最小尺寸(1K)生成, 产生一次生成费用(见算子悬停说明)
        _draw_service_test(box, TEST_IMAGE_OP, ts.image_result, ts.image_ok)

        box = col_image.box()
        box.label(text="Image Generation", icon="SETTINGS")
        box.prop(self, "image_timeout")
        box.prop(self, "image_save_dir")
        box.prop(self, "use_auto_name")
        # 图像编辑器联动开关并入本盒, 以分隔行与生成参数区隔
        box.prop(self, "use_auto_open_images")


def get_prefs() -> AiAssistantPreferences:
    """获取插件偏好设置实例"""
    return bpy.context.preferences.addons[__addon_name__].preferences
