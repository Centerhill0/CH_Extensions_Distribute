"""
文本助手服务设置面板模块

提供以下功能:
- 文本助手 Tab 顶部的服务设置(默认折叠): 脚本生成器与对话两组的独立服务设置
- 每组: 服务模式(全局/覆盖服务商)与覆盖模型; Global 跟随偏好设置
- 覆盖时端点/密钥取对应服务商的偏好配置; 任一模式缺密钥面板内警示
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...preference import get_prefs

# 文本服务商 -> 偏好密钥字段名(Global 按偏好当前服务商检查, 覆盖按覆盖服务商检查)
_KEY_ATTRS = {'DEEPSEEK': "deepseek_api_key", "GLM": "glm_api_key", "CUSTOM": "api_key"}


def _draw_key_warning(col, provider: str):
    """该服务商密钥未配置时在面板内警示(右对齐置灰)"""
    key_attr = _KEY_ATTRS.get(provider)
    if key_attr and not getattr(get_prefs(), key_attr):
        row = col.row(align=True)
        row.alignment = 'RIGHT'
        row.enabled = False
        row.label(text="No API key for this service in the preferences", icon='ERROR')


def _draw_text_group(layout, state, title: str, icon: str):
    """绘制一个文本面板的服务设置组(服务商 + 覆盖模型)"""
    box = layout.box()
    box.label(text=title, icon=icon)
    col = box.column(align=False)
    col.prop(state, "service_mode", text="Provider")
    if state.service_mode == 'GLOBAL':
        _draw_key_warning(col, get_prefs().provider)
    else:
        _draw_key_warning(col, state.service_mode)
        col.prop(state, "panel_model", text="Model")
    # 思考档位: 档位表按生效服务商定制(DeepSeek 三档 / GLM 开关 / 其余 low-medium-high)
    col.prop(state, "thinking", text="Thinking Level")


@reg_order(1)
class AiTextServicePanel(Panel):
    """文本助手服务设置面板"""

    bl_label = "Text Service"
    bl_idname = "VIEW3D_PT_ch_ai_text_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与脚本生成器/对话面板共用)
    bl_category = "Text Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        layout = self.layout
        wm = context.window_manager

        # 脚本生成器与对话各自独立的服务设置
        _draw_text_group(layout, wm.ch_ai_script_service, "Script Generator", 'CONSOLE')
        _draw_text_group(layout, wm.ch_ai_chat_service, "Chat", 'COMMUNITY')
