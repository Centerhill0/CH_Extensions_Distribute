"""
AI 效果图面板模块

提供以下功能:
- 图像助手选项卡下的图像列表(空也常驻, 行数随内容自适应; 点击行按偏好切换图像编辑器,
  上移/下移排序)
- 列表右侧: "自动打开图像"开关(存于偏好设置)与排序按钮
- 预览区(常驻, 见 ui/panels/preview): 当前高亮图像的大图预览, 画廊开关展开后改为
  列表内全部图像(生成结果与参考通道捕获图)的缩略图图标视图
- 参考通道开关行(Color/Depth/Normal/Lines/AO; 关闭 Color 时面板警示, 生成需要 Color)
- 捕获引擎选择与输出尺寸档位, 提示词输入(长文描述块优先), 编辑描述与优化提示词按钮,
  捕获预览与生成效果图按钮
- 请求等待进度(仅显示效果图流程), 进度后跟终止按钮
"""

import bpy
from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import CancelRequest, ClearPrompt, EditPrompt, OptimizePrompt
from ...operators.ai_render import CaptureViewRefs, GenerateRender
from ...operators.list_ops import DeleteImage, MoveListItem
from ...preference import get_prefs
from ...utils import AI_RENDER_PROMPT_TEXT_NAME
from ..lists.images import CH_UL_ai_images
from .preview import draw_preview_box

# 图像列表显示行数下限(空列表的矮框高度, 与其余列表的实测定值一致)
_IMAGE_ROWS_MIN = 3

# 图像列表显示行数上限(行数随内容增长到该值)
_IMAGE_ROWS = 4


@reg_order(3)
class AiRenderPanel(Panel):
    """AI 相机效果图面板"""

    bl_label = "Render"
    bl_idname = "VIEW3D_PT_ch_ai_render"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与 AI 纹理生成器面板共用)
    bl_category = "Image Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_render_state
        layout = self.layout

        # 图像列表(空也常驻, 行数随内容从下限到上限; 快照由 handlers 实时刷新)
        # 右侧竖列: 自动在图像编辑器打开的开关 + 上移/下移排序
        row = layout.row(align=True)
        row.template_list(CH_UL_ai_images.__name__, "ch_ai_render_images", state, "images",
                          state, "images_active_index",
                          rows=max(_IMAGE_ROWS_MIN, min(len(state.images), _IMAGE_ROWS)))
        col = row.column(align=True)
        col.prop(get_prefs(), "use_auto_open_images", text="", icon='IMAGE_DATA', toggle=True)
        # 排序按钮常驻, 列表为空时置灰(operator() 返回算子属性集无 enabled, 单按钮置灰须包布局行)
        can_reorder = len(state.images) > 0
        up_row = col.row(align=True)
        up_row.enabled = can_reorder
        op = up_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_UP')
        op.target, op.direction = 'RENDER', 'UP'
        down_row = col.row(align=True)
        down_row.enabled = can_reorder
        op = down_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_DOWN')
        op.target, op.direction = 'RENDER', 'DOWN'
        del_row = col.row(align=True)
        del_row.enabled = can_reorder
        op = del_row.operator(DeleteImage.bl_idname, text="", icon='X')
        op.target = 'RENDER'

        # 预览区(常驻): 大图预览 + 画廊开关(展开为列表内图像的图标视图)
        draw_preview_box(layout, state, iface("No render generated yet"))

        # 参考通道开关行; Color 为生成请求所必需, 关闭时警示
        layout.separator()
        col = layout.column(align=True)
        row = col.row(align=True)
        row.label(text="Passes", icon='RENDERLAYERS')
        row.prop(state, "use_color", text="Color", toggle=True)
        row.prop(state, "use_depth", text="Depth", toggle=True)
        row.prop(state, "use_normal", text="Normal", toggle=True)
        row.prop(state, "use_lines", text="Lines", toggle=True)
        row.prop(state, "use_ao", text="AO", toggle=True)
        if not state.use_color:
            col.label(text="Color pass is required for generation", icon='ERROR')
        col.prop(state, "use_current_engine")

        # 描述输入(长文描述块优先)与操作行: 捕获预览(本地, 免费) / 生成效果图(调用 AI 服务)
        layout.separator()
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(state, "prompt", text="Prompt")
        row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE').target = 'RENDER'
        prompt_text = bpy.data.texts.get(AI_RENDER_PROMPT_TEXT_NAME)
        if prompt_text is not None and prompt_text.as_string().strip():
            # 长文描述提示: 右对齐置灰, 不挤占描述输入行
            note = col.row(align=True)
            note.alignment = 'RIGHT'
            note.enabled = False
            note.label(text="Using the long description from the text editor", icon='INFO')
        row = col.row(align=False)
        op = row.operator(EditPrompt.bl_idname, icon='TEXT')
        op.target = 'RENDER'
        # 优化提示词: 效果图面板同样直接走偏好全局文本服务(不读文本助手面板的服务覆盖)
        op = row.operator(OptimizePrompt.bl_idname, icon='SHADERFX')
        op.target = 'RENDER'
        col.prop(state, "size", text="Size")
        col.prop(state, "seed")
        row = col.row(align=True)
        row.operator(CaptureViewRefs.bl_idname, icon='RENDERLAYERS')
        row.operator(GenerateRender.bl_idname, icon='RENDER_RESULT')

        # 等待进度: 面板最下方, 只显示本面板的效果图流程, 完成后自动消失;
        # 进度后跟终止按钮(放弃等待, 后台请求不中断)
        ai_state = wm.ch_ai_state
        if ai_state.status and ai_state.status_scope == 'render':
            box = layout.box()
            row = box.row()
            row.label(text=ai_state.status, icon='TIME')
            if ai_state.wait_seconds > 0:
                row.label(text=f"{ai_state.wait_seconds}s")
            row.operator(CancelRequest.bl_idname, text="", icon='CANCEL')
