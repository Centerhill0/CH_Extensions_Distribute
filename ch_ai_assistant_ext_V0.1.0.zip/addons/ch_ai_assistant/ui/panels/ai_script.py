"""
AI 脚本生成器面板模块

提供以下功能:
- 文本助手选项卡下的脚本列表(空也常驻, 行数随内容自适应; 点击行按偏好聚焦编辑器,
  运行/一键调试/删除, 上移/下移排序)
- 列表右侧: "自动打开脚本"开关(存于偏好设置)与排序按钮
- 需求输入与生成按钮(列表之后)
- 最近一次运行错误摘要与清除按钮
"""

import bpy
from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import (
    CancelRequest,
    ClearPrompt,
    EditPrompt,
    GenerateScript,
    OptimizePrompt,
)
from ...operators.list_ops import MoveListItem
from ...operators.script_actions import (
    ClearError,
    DebugScript,
    DeleteScript,
    ReviseScript,
    RunScript,
)
from ...preference import get_prefs
from ...utils import AI_PROMPT_TEXT_NAME
from ..lists.scripts import CH_AI_UL_scripts


@reg_order(2)
class AiScriptPanel(Panel):
    """AI 脚本生成器面板"""

    bl_label = "Script Generator"
    bl_idname = "VIEW3D_PT_ch_ai_script"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与 AI 对话面板共用)
    bl_category = "Text Assistant"

    # 错误摘要最多显示的 traceback 行数(取末尾异常段)
    _ERROR_LINES = 4

    # 脚本列表显示行数下限(空列表的矮框高度, 作者实测定为 3)
    _SCRIPT_ROWS_MIN = 3

    # 脚本列表显示行数上限(行数随内容增长到该值)
    _SCRIPT_ROWS = 5

    def draw(self, context: Context):
        state = context.window_manager.ch_ai_state
        layout = self.layout

        # 脚本列表(空也常驻, 行数随内容从下限到上限; 快照由 handlers 实时刷新)
        # 右侧竖列: 自动在文本编辑器打开的开关 + 上移/下移排序 + 删除
        # 依赖高亮条目的按钮常驻, 无条目时置灰(operator() 返回算子属性集无 enabled, 单按钮置灰须包布局行)
        has_items = len(state.scripts) > 0
        row = layout.row(align=True)
        row.template_list(CH_AI_UL_scripts.__name__, "ch_ai_scripts", state, "scripts", state, "scripts_active_index", rows=max(self._SCRIPT_ROWS_MIN, min(len(state.scripts), self._SCRIPT_ROWS)))
        col = row.column(align=True)
        col.prop(get_prefs(), "use_auto_open_scripts", text="", icon='TEXT', toggle=True)
        up_row = col.row(align=True)
        up_row.enabled = has_items
        op = up_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_UP')
        op.target, op.direction = 'SCRIPT', 'UP'
        down_row = col.row(align=True)
        down_row.enabled = has_items
        op = down_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_DOWN')
        op.target, op.direction = 'SCRIPT', 'DOWN'
        del_row = col.row(align=True)
        del_row.enabled = has_items
        op = del_row.operator(DeleteScript.bl_idname, text="", icon='X')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""

        # 点击行即聚焦文本编辑器(scripts_active_index 的 update 回调), 无需打开按钮
        row = layout.row(align=False)
        row.enabled = has_items
        op = row.operator(RunScript.bl_idname, text="Run", icon='PLAY')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""
        op = row.operator(DebugScript.bl_idname, text="Debug", icon='ERROR')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""

        # 描述输入: 长文描述块优先, 为空时采用单行输入; 行尾清除按钮
        layout.separator()
        col = layout.column(align=False)
        row = col.row(align=True)
        row.prop(state, "prompt", text="Prompt")
        row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE')
        prompt_text = bpy.data.texts.get(AI_PROMPT_TEXT_NAME)
        if prompt_text is not None and prompt_text.as_string().strip():
            # 长文描述提示: 右对齐置灰, 不挤占描述输入行
            note = col.row(align=True)
            note.alignment = 'RIGHT'
            note.enabled = False
            note.label(text="Using the long description from the text editor", icon='INFO')
        # 编辑描述 / 优化提示词 / 生成脚本 / 修改脚本(修改要求与生成共用描述来源, 作用于当前高亮脚本)
        row = col.row(align=False)
        row.operator(EditPrompt.bl_idname, icon='TEXT')
        row.operator(OptimizePrompt.bl_idname, icon='SHADERFX')
        row = col.row(align=False)
        revise_row = row.row(align=False)
        revise_row.enabled = has_items
        op = revise_row.operator(ReviseScript.bl_idname, icon='GREASEPENCIL')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""
        row.operator(GenerateScript.bl_idname, icon='EVENT_RETURN')

        # 最近错误摘要(末尾异常段), 右侧清除按钮; 拼接式标签经 iface() 自查翻译
        if state.last_error_traceback:
            box = layout.box()
            header = box.row()
            header.label(text=iface("Last error: {}").format(state.last_error_script), icon='ERROR')
            header.operator(ClearError.bl_idname, text="", icon='X')
            error_lines = state.last_error_traceback.strip().splitlines()
            for line in error_lines[-self._ERROR_LINES :]:
                box.label(text=line)

        # 等待进度: 面板最下方, 只显示本面板的流程(生成/调试/修改), 完成后自动消失;
        # 进度后跟中断按钮(放弃等待, 后台请求不中断)
        if state.status and state.status_scope == 'script':
            box = layout.box()
            row = box.row()
            row.label(text=state.status, icon='TIME')
            if state.wait_seconds > 0:
                row.label(text=f"{state.wait_seconds}s")
            row.operator(CancelRequest.bl_idname, text="", icon='CANCEL')
