"""
图像助手服务设置面板模块

提供以下功能:
- 图像助手 Tab 顶部的服务设置(默认折叠): 纹理生成器与效果图两组的独立服务设置
- 每组: 服务模式(全局/覆盖服务商)与覆盖模型; Global 跟随偏好设置
- 覆盖时端点/密钥取对应服务商的偏好配置; 任一模式缺密钥面板内警示
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...preference import get_prefs

# 图像服务商 -> 偏好密钥字段名(Global 按偏好当前服务商检查, 覆盖按覆盖服务商检查)
_KEY_ATTRS = {'VOLCENGINE': "volcengine_api_key", "DASHSCOPE": "dashscope_api_key",
              "CUSTOM": "image_api_key"}


def _draw_key_warning(col, provider: str):
    """该服务商密钥未配置时在面板内警示(右对齐置灰)"""
    key_attr = _KEY_ATTRS.get(provider)
    if key_attr and not getattr(get_prefs(), key_attr):
        row = col.row(align=True)
        row.alignment = 'RIGHT'
        row.enabled = False
        row.label(text="No API key for this service in the preferences", icon='ERROR')


def _draw_image_group(layout, state, title: str, icon: str, model_attr: str):
    """绘制一个图像面板的服务设置组(服务商 + 覆盖模型)"""
    box = layout.box()
    box.label(text=title, icon=icon)
    col = box.column(align=False)
    col.prop(state, "service_mode", text="Provider")
    if state.service_mode == 'GLOBAL':
        _draw_key_warning(col, get_prefs().image_provider)
    else:
        _draw_key_warning(col, state.service_mode)
        col.prop(state, model_attr, text="Model")


@reg_order(1)
class AiImageServicePanel(Panel):
    """图像助手服务设置面板"""

    bl_label = "Image Service"
    bl_idname = "VIEW3D_PT_ch_ai_image_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与纹理/效果图面板共用)
    bl_category = "Image Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        layout = self.layout
        wm = context.window_manager

        # 纹理生成器(纹理模型)与效果图(编辑模型)各自独立的服务设置
        _draw_image_group(layout, wm.ch_ai_texture_service, "Texture Generator", 'TEXTURE',
                          "panel_t2i_model")
        _draw_image_group(layout, wm.ch_ai_render_service, "Render", 'RENDER_RESULT',
                          "panel_edit_model")
