"""
AI 纹理生成器面板模块

提供以下功能:
- 图像助手选项卡下的生成图像列表(空也常驻, 行数随内容自适应; 点击行按偏好切换图像编辑器,
  上移/下移排序)
- 列表右侧: "自动打开图像"开关(存于偏好设置)与排序按钮
- 预览区(常驻, 见 ui/panels/preview): 当前高亮纹理的大图预览, 画廊开关展开后改为
  纹理产物的缩略图图标视图(条目来自纹理列表快照, 已按纹理前缀过滤)
- 描述输入(长文描述块优先), 编辑描述与优化提示词的入口按钮(优化走全局文本服务),
  无缝平铺开关, 输出尺寸与生成按钮
- 请求等待进度(仅显示纹理流程), 进度后跟终止按钮
"""

import bpy
from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import CancelRequest, ClearPrompt, EditPrompt, OptimizePrompt
from ...operators.ai_texture import GenerateTexture
from ...operators.list_ops import DeleteImage, MoveListItem
from ...preference import get_prefs
from ...utils import AI_TEXTURE_PROMPT_TEXT_NAME
from ..lists.images import CH_UL_ai_images
from .preview import draw_preview_box

# 图像列表显示行数下限(空列表的矮框高度, 与其余列表的实测定值一致)
_IMAGE_ROWS_MIN = 3

# 图像列表显示行数上限(行数随内容增长到该值)
_IMAGE_ROWS = 4


@reg_order(2)
class AiTexturePanel(Panel):
    """AI 纹理生成器面板"""

    bl_label = "Texture Generator"
    bl_idname = "VIEW3D_PT_ch_ai_texture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与 AI 效果图面板共用)
    bl_category = "Image Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_texture_state
        layout = self.layout

        # 生成图像列表(空也常驻, 行数随内容从下限到上限; 快照由 handlers 实时刷新)
        # 右侧竖列: 自动在图像编辑器打开的开关 + 上移/下移排序
        row = layout.row(align=True)
        row.template_list(CH_UL_ai_images.__name__, "ch_ai_tex_images", state, "images",
                          state, "images_active_index",
                          rows=max(_IMAGE_ROWS_MIN, min(len(state.images), _IMAGE_ROWS)))
        col = row.column(align=True)
        col.prop(get_prefs(), "use_auto_open_images", text="", icon='IMAGE_DATA', toggle=True)
        # 排序按钮常驻, 列表为空时置灰(operator() 返回算子属性集无 enabled, 单按钮置灰须包布局行)
        can_reorder = len(state.images) > 0
        up_row = col.row(align=True)
        up_row.enabled = can_reorder
        op = up_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_UP')
        op.target, op.direction = 'TEXTURE', 'UP'
        down_row = col.row(align=True)
        down_row.enabled = can_reorder
        op = down_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_DOWN')
        op.target, op.direction = 'TEXTURE', 'DOWN'
        del_row = col.row(align=True)
        del_row.enabled = can_reorder
        op = del_row.operator(DeleteImage.bl_idname, text="", icon='X')
        op.target = 'TEXTURE'

        # 预览区(常驻): 大图预览 + 画廊开关(展开为纹理缩略图的图标视图)
        draw_preview_box(layout, state, iface("No texture generated yet"))

        # 描述输入与生成选项: 描述可走文本编辑器的长文描述块(编辑/优化按钮在本行下方),
        # 无缝平铺开关(默认开) + 输出尺寸
        layout.separator()
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(state, "prompt", text="Prompt")
        row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE').target = 'TEXTURE'
        prompt_text = bpy.data.texts.get(AI_TEXTURE_PROMPT_TEXT_NAME)
        if prompt_text is not None and prompt_text.as_string().strip():
            # 长文描述提示: 右对齐置灰, 不挤占描述输入行
            note = col.row(align=True)
            note.alignment = 'RIGHT'
            note.enabled = False
            note.label(text="Using the long description from the text editor", icon='INFO')
        row = col.row(align=False)
        op = row.operator(EditPrompt.bl_idname, icon='TEXT')
        op.target = 'TEXTURE'
        # 优化提示词: 纹理面板直接走偏好全局文本服务(不读文本助手面板的服务覆盖)
        op = row.operator(OptimizePrompt.bl_idname, icon='SHADERFX')
        op.target = 'TEXTURE'
        row = col.row(align=True)
        row.prop(state, "use_seamless", text="Seamless", toggle=True)
        row.prop(state, "size", text="")
        col.prop(state, "seed")
        col.operator(GenerateTexture.bl_idname, icon='TEXTURE')

        # 等待进度: 面板最下方, 只显示本面板的纹理流程, 完成后自动消失;
        # 进度后跟终止按钮(放弃等待, 后台请求不中断)
        ai_state = wm.ch_ai_state
        if ai_state.status and ai_state.status_scope == 'texture':
            box = layout.box()
            row = box.row()
            row.label(text=ai_state.status, icon='TIME')
            if ai_state.wait_seconds > 0:
                row.label(text=f"{ai_state.wait_seconds}s")
            row.operator(CancelRequest.bl_idname, text="", icon='CANCEL')
