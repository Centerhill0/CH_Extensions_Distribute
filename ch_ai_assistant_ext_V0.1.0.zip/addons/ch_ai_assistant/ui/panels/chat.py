"""
AI 对话面板模块

提供以下功能:
- 文本助手选项卡下的消息历史列表(空也常驻, 行数随内容自适应; 点击行按偏好转出到文本编辑器阅读长回复)
- 列表右侧: "自动打开对话"开关(存于偏好设置)与删除选定消息按钮
- 查看/提取代码/清空按钮(无消息时置灰)
- 输入框(行尾清除按钮), 附带脚本按钮(脚本列表高亮脚本拼进下一条消息)与发送按钮
- 请求等待进度(仅显示对话流程)
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import CancelRequest
from ...operators.chat import (
    ChatAttachScript,
    ChatClear,
    ChatClearInput,
    ChatDeleteMessage,
    ChatExtractCode,
    ChatSend,
    ChatViewMessage,
)
from ...preference import get_prefs
from ..lists.chat import CH_AI_UL_chat


@reg_order(3)
class AiChatPanel(Panel):
    """AI 纯文本对话面板"""

    bl_label = "Chat"
    bl_idname = "VIEW3D_PT_ch_ai_chat"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与 AI 脚本生成器面板共用)
    bl_category = "Text Assistant"

    # 消息列表显示行数下限(空列表的矮框高度, 与其余列表的实测定值一致)
    _CHAT_ROWS_MIN = 3

    # 消息列表显示行数上限(行数随内容增长到该值)
    _CHAT_ROWS = 6

    def draw(self, context: Context):
        state = context.window_manager.ch_ai_state
        layout = self.layout

        # 消息历史列表(空也常驻, 行数随内容从下限到上限; 发送/回复即入列,
        # 点击行按偏好转出到文本编辑器阅读); 右侧竖列: 自动在文本编辑器打开的开关 + 删除选定消息
        has_messages = len(state.chat_messages) > 0
        row = layout.row(align=True)
        row.template_list(CH_AI_UL_chat.__name__, "ch_ai_chat", state, "chat_messages", state, "chat_active_index", rows=max(self._CHAT_ROWS_MIN, min(len(state.chat_messages), self._CHAT_ROWS)))
        col = row.column(align=True)
        col.prop(get_prefs(), "use_auto_open_chat", text="", icon='TEXT', toggle=True)
        del_row = col.row(align=True)
        del_row.enabled = has_messages
        del_row.operator(ChatDeleteMessage.bl_idname, text="", icon='X')

        # 查看/提取/清空按钮常驻, 无消息时置灰
        row = layout.row(align=False)
        row.enabled = has_messages
        row.operator(ChatViewMessage.bl_idname, icon='TEXT')
        row.operator(ChatExtractCode.bl_idname, icon='CONSOLE')
        row.operator(ChatClear.bl_idname, icon='TRASH')

        # 输入框(行尾清除按钮, 只清输入不动历史); 附带脚本与发送同行
        # 附带脚本: 把脚本列表当前高亮脚本拼进下一条消息头部, 再次点击取消, 发送后自动清空
        layout.separator()
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(state, "chat_input", text="Message")
        row.operator(ChatClearInput.bl_idname, text="", icon='CANCEL_LARGE')
        # 附带脚本与发送同行但独立置灰: 仅附带依赖脚本列表, 发送恒可用(operator() 返回值无
        # enabled, 单按钮独立控制须各自包嵌套行)
        script_state = context.window_manager.ch_ai_state
        row = col.row(align=False)
        attach = row.row(align=False)
        attach.enabled = len(script_state.scripts) > 0
        attach.operator(ChatAttachScript.bl_idname, icon='TEXT')
        row.operator(ChatSend.bl_idname, icon='EVENT_RETURN')
        # 附件状态行置灰显示
        if state.chat_script_name:
            note_row = col.row(align=True)
            note_row.enabled = False
            note_row.label(text=iface("Attached: {}").format(state.chat_script_name), icon='PINNED')

        # 等待进度: 面板最下方, 只显示本面板的对话流程, 完成后自动消失;
        # 进度后跟中断按钮(放弃等待, 后台请求不中断)
        if state.status and state.status_scope == 'chat':
            box = layout.box()
            row = box.row()
            row.label(text=state.status, icon='TIME')
            if state.wait_seconds > 0:
                row.label(text=f"{state.wait_seconds}s")
            row.operator(CancelRequest.bl_idname, text="", icon='CANCEL')
