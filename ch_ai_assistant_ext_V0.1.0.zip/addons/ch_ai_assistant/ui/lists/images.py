"""
AI 图像列表 UIList 模块

纹理与效果图两面板共用的图像条目列表, 行内名称可双击编辑(写穿到图像数据块, 见
common.ui.list_snapshot 的 rename_datablock), 点击行走活跃索引回调
(handlers.on_image_index_update)切换图像编辑器; 与脚本列表同款带内建名称过滤与排序控件行.

注意: 两列表按前缀过滤, 把名字改掉前缀(如 "AI Tex"/"AI Render")会让该图退出对应列表
(与脚本列表改掉 "AI " 前缀同理), 只是不再出现在列表与缩略图里, 数据块本身仍在.
"""

from bpy.types import Context, UIList

from .....common.ui.list_snapshot import StandardFilterMixin


class CH_UL_ai_images(StandardFilterMixin, UIList):
    """AI 生成图像条目列表(纹理/效果图面板共用, 经 template_list 的 list_id 区分实例)"""

    def draw_item(self, context: Context, layout, data, item, icon, active_data,
                  active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            icon_id = 'TEXTURE' if item.name.startswith("AI Tex ") else 'IMAGE_DATA'
            layout.prop(item, "name", text="", emboss=False, icon=icon_id)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')
