"""
对话消息列表模块

纯文本对话消息的 UIList(类名含 _UL_ 标记, Blender 注册约定, 类名即 template_list 查找 id),
用户与 AI 消息以图标区分, 行内显示消息首行(长内容经"查看消息"在文本编辑器阅读).
"""

from bpy.types import Context, UIList, UILayout

from ...props import ChatMessage


class CH_AI_UL_chat(UIList):
    """对话消息列表"""

    def draw_item(self, context: Context, layout: UILayout, data, item: ChatMessage,
                  icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row_icon = 'USER' if item.role == 'USER' else 'COMMUNITY'
            # 只取首行显示, 长回复经"查看消息"在文本编辑器阅读
            first_line = item.content.split("\n", 1)[0]
            # translate=False: 消息内容是用户/AI 文本, 不参与翻译查询
            layout.label(text=first_line, icon=row_icon, translate=False)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='USER')
