"""
实时同步处理器模块

提供以下功能:
- sync_scripts_now: 脚本列表快照立即刷新(供脚本写入后调用)
- sync_images_now: 纹理/效果图两个图像列表快照立即刷新(供图像生成后调用)
- move_list_item: 列表高亮条目上移/下移(排序写进数据块自定义属性, 持久且跨机)
- activate_script_top: 生成/提取/写回后置顶该脚本并同步快照, 按偏好聚焦并高亮
- activate_image: 图像生成/捕获预览后同步快照, 把图像列表高亮指向该图并聚焦图像编辑器
  (top=True 时先把新产物置顶到列表第一位, 纹理与效果图生成共用)
- select_image_by_name: 按数据块名选中图像(预览区缩略图选中联动, 与点击列表行同款)
- gallery_visible_items / select_gallery_value: 缩略图可见项(过滤+上限)与选中值回写(仅写可见项)
- 脚本/对话/图像列表活跃索引 update 回调: 点击行按偏好聚焦编辑器或切换图像编辑器
- open_chat_message: 按偏好把当前高亮对话消息转出到 AI_Chat.txt 并聚焦文本编辑器
- load_post 处理器: 快照存于 WM 跨文件保留, 载入后立即对齐
- 周期计时器: 兜底刷新(文本块/图像数据块增删改不触发 depsgraph)
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接
- 快照重建与重入护栏机制见 common.ui.list_snapshot
"""

import bpy
from bpy.types import Context

from ...common.ui.list_snapshot import is_syncing, rebuild_if_changed, set_guarded, set_index
from .preference import get_prefs
from .utils import (
    AI_CHAT_TEXT_NAME,
    AI_REF_PREFIX,
    AI_RENDER_PREFIX,
    AI_SCRIPT_PREFIX,
    AI_TEXTURE_PREFIX,
    focus_image_editors,
    focus_text_editors,
    write_text_block,
)

# 脚本列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0

# 列表排序键的数据块自定义属性名(随 blend 保存, 跨机一致)
_ORDER_KEY = "ch_ai_order"


def _datablock(names_kind: str, name: str):
    """按列表种类取条目对应的真实数据块"""
    if names_kind == 'TEXT':
        return bpy.data.texts.get(name)
    return bpy.data.images.get(name)


def _sorted_names(names: list, names_kind: str) -> list:
    """按数据块自定义属性 ch_ai_order 排序(未排序条目按名序排后, 稳定)"""
    def key(name: str):
        block = _datablock(names_kind, name)
        order = block.get(_ORDER_KEY) if block is not None else None
        return (0, order, name) if order is not None else (1, 0, name)
    return sorted(names, key=key)


def _script_names() -> list:
    """脚本列表名称序列(仅 AI 前缀脚本; 长文描述块与对话查看块无此前缀, 天然排除)"""
    names = [t.name for t in bpy.data.texts if t.name.startswith(AI_SCRIPT_PREFIX)]
    return _sorted_names(names, 'TEXT')


def _texture_image_names() -> list:
    """纹理面板图像列表的名称序列(生成贴图前缀过滤; 前缀含尾随分隔符, 回落名是纯前缀本身)"""
    names = [i.name for i in bpy.data.images if i.name.startswith(AI_TEXTURE_PREFIX)]
    return _sorted_names(names, 'IMAGE')


def _render_image_names() -> list:
    """效果图面板图像列表的名称序列(生成结果与捕获预览前缀过滤)"""
    names = [i.name for i in bpy.data.images
             if i.name.startswith(AI_RENDER_PREFIX) or i.name.startswith(AI_REF_PREFIX)]
    return _sorted_names(names, 'IMAGE')


def move_list_item(target: str, direction: str) -> bool:
    """列表高亮条目与相邻条目交换排序位置, 返回是否移动

    target: 'SCRIPT'/'TEXTURE'/'RENDER'(与算子枚举标识一致); direction: 'UP'/'DOWN'.
    首次移动时把当前顺序全量写入数据块自定义属性(此后移动为纯交换),
    快照顺序随 _sorted_names 反映, 排序持久且不随快照重建丢失.
    """
    wm = bpy.context.window_manager
    if target == 'SCRIPT':
        state, idx_name, kind, names = wm.ch_ai_state, "scripts_active_index", 'TEXT', _script_names()
        getter = lambda n: bpy.data.texts.get(n)
    elif target == 'TEXTURE':
        state, idx_name, kind, names = wm.ch_ai_texture_state, "images_active_index", 'IMAGE', _texture_image_names()
        getter = lambda n: bpy.data.images.get(n)
    elif target == 'RENDER':
        state, idx_name, kind, names = wm.ch_ai_render_state, "images_active_index", 'IMAGE', _render_image_names()
        getter = lambda n: bpy.data.images.get(n)
    else:
        return False

    idx = getattr(state, idx_name)
    j = idx - 1 if direction == 'UP' else idx + 1
    if not (0 <= idx < len(names)) or not (0 <= j < len(names)):
        return False
    blocks = [getter(n) for n in names]
    if any(b is None for b in blocks):
        return False
    # 首次移动: 全量分配显式排序号(缺省用当前显示位置), 之后移动即纯交换
    for pos, block in enumerate(blocks):
        if block.get(_ORDER_KEY) is None:
            block[_ORDER_KEY] = pos
    a, b = blocks[idx], blocks[j]
    a[_ORDER_KEY], b[_ORDER_KEY] = b[_ORDER_KEY], a[_ORDER_KEY]
    # 立即重建快照反映新顺序(不等计时器节拍), 高亮跟随移动后的条目(护栏内写入, 不触发点击回调)
    if kind == 'TEXT':
        sync_scripts_now()
    else:
        sync_images_now()
    set_index(state, idx_name, j)
    return True


def reset_wait_state(state):
    """清空 AI 请求等待标志(面板进度/作用域/已等待秒数/中断标志)

    status 只由等待模态清理, 而模态按窗口持有: 等待期间载入 .blend 或关闭承载窗口会让模态
    被丢弃, 标志却留在 WM(全局)里 → 之后所有请求都被"已有请求在跑"永久拒绝, 只能重启 Blender.
    故 load_post 与模态挂载失败时都调用本函数回收.
    """
    state.status = ""
    state.status_scope = ""
    state.wait_seconds = 0
    state.cancel_requested = False


def sync_scripts_now():
    """立即重建脚本列表快照(生成/调试写入文本块后调用, 不等计时器节拍)"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())


def sync_images_now():
    """立即重建纹理与效果图两个图像列表快照(图像生成/捕获预览后调用, 不等计时器节拍)

    重建后把缩略图选中值对齐到当前高亮项: 条目被删除/改名导致快照变化时,
    缩略图的选中态不会停在已不存在的名字上.
    """
    wm = bpy.context.window_manager
    rebuild_if_changed(wm.ch_ai_texture_state, "images", "images_active_index",
                       'IMAGE', _texture_image_names())
    rebuild_if_changed(wm.ch_ai_render_state, "images", "images_active_index",
                       'IMAGE', _render_image_names())
    for state_attr in ("ch_ai_texture_state", "ch_ai_render_state"):
        _align_gallery_to_index(getattr(wm, state_attr))


def _align_gallery_to_index(state):
    """把缩略图选中值对齐到列表当前高亮项(护栏内写入, 不触发缩略图回调)"""
    idx = state.images_active_index
    if not 0 <= idx < len(state.images):
        return
    select_gallery_value(state, state.images[idx].name)


def gallery_visible_items(state) -> list:
    """预览区缩略图当前可见的列表条目: 按名称过滤(不区分大小写) + 显示条数上限截断

    顺序即列表快照顺序(生成置顶后新产物在前), 故上限截断保留的是列表前若干项.
    """
    pattern = state.gallery_filter.strip().lower()
    limit = state.gallery_limit
    visible = []
    for item in state.images:
        if pattern and pattern not in item.name.lower():
            continue
        visible.append(item)
        if limit > 0 and len(visible) >= limit:
            break
    return visible


def select_gallery_value(state, name: str) -> bool:
    """把缩略图选中值指向该图像(仅当它在当前过滤/上限下可见; 护栏内写入, 不触发回调)

    不在候选表内的标识写进动态枚举会抛 TypeError(控制台留 traceback), 故先判可见性;
    返回是否写入(未写入表示该图当前在缩略图视野外, 选中态保持原样, 不影响列表高亮).
    """
    if state.gallery_image == name:
        return False
    if not any(item.name == name for item in gallery_visible_items(state)):
        return False
    set_guarded(state, "gallery_image", name)
    return True


def _highlight_image(state, name: str) -> bool:
    """把图像列表高亮与预览区画廊选中值指向该图(护栏内写入, 不触发点击联动), 返回是否命中"""
    idx = next((i for i, item in enumerate(state.images) if item.name == name), None)
    if idx is None:
        return False
    set_index(state, "images_active_index", idx)
    # 缩略图选中值与列表高亮保持同步(被过滤/上限挡住时不写, 见 select_gallery_value)
    select_gallery_value(state, name)
    return True


def select_image_by_name(context: Context, state, name: str) -> bool:
    """按数据块名选中图像: 高亮列表条目并按偏好切换图像编辑器, 返回是否命中

    供预览区画廊的选中回调调用(与点击列表行同款联动, 只是来源是画廊缩略图).
    """
    if not _highlight_image(state, name):
        return False
    if get_prefs().use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focus_image_editors(context, image)
    return True


def activate_image(context: Context, name: str, top: bool = False) -> int:
    """图像生成/捕获预览后: 同步快照, 把图像列表高亮指向该图并聚焦图像编辑器

    top=True 时先置顶(排序号取当前最小减一, 与脚本列表同款: 新产物排列表第一位,
    不随名称序下沉); 返回聚焦到的图像编辑器区域数(0 表示没有打开的图像编辑器, 由调用方提示).
    """
    if top:
        image = bpy.data.images.get(name)
        if image is not None:
            orders = [i.get(_ORDER_KEY) for i in bpy.data.images if i.get(_ORDER_KEY) is not None]
            image[_ORDER_KEY] = (min(orders) - 1) if orders else 0
    sync_images_now()
    image = bpy.data.images.get(name)
    focused = 0
    if image is not None:
        focused, _ = focus_image_editors(context, image)
    for state_attr in ("ch_ai_texture_state", "ch_ai_render_state"):
        _highlight_image(getattr(context.window_manager, state_attr), name)
    return focused


def activate_script_top(context: Context, name: str):
    """提取代码落块后: 置顶(排序号设为当前最小减一), 同步快照, 按偏好聚焦并高亮该脚本"""
    block = bpy.data.texts.get(name)
    if block is None:
        return
    orders = [b.get(_ORDER_KEY) for b in bpy.data.texts if b.get(_ORDER_KEY) is not None]
    block[_ORDER_KEY] = (min(orders) - 1) if orders else 0
    sync_scripts_now()
    if get_prefs().use_auto_open_scripts:
        focus_text_editors(context, block)
    state = context.window_manager.ch_ai_state
    for idx, item in enumerate(state.scripts):
        if item.name == name:
            set_index(state, "scripts_active_index", idx)
            return


def on_scripts_index_update(self, context: Context):
    """脚本列表活跃索引回调: 开关开启时, 用户点击行把文本编辑器聚焦到该脚本"""
    if not get_prefs().use_auto_open_scripts:
        return
    if is_syncing() or not 0 <= self.scripts_active_index < len(self.scripts):
        return
    text = bpy.data.texts.get(self.scripts[self.scripts_active_index].name)
    if text is not None:
        focus_text_editors(context, text)


def open_chat_message(context: Context, state):
    """按偏好把当前高亮对话消息写入 AI_Chat.txt 并聚焦文本编辑器

    供对话活跃索引 update 回调(点击列表行)与回复写入后的联动调用;
    转出后完整内容在文本编辑器阅读, 列表行内仅显示首行.
    """
    if not get_prefs().use_auto_open_chat:
        return
    idx = state.chat_active_index
    if not 0 <= idx < len(state.chat_messages):
        return
    text, _ = write_text_block(AI_CHAT_TEXT_NAME, state.chat_messages[idx].content)
    focus_text_editors(context, text)


def on_chat_index_update(self, context: Context):
    """对话消息活跃索引回调: 开关开启时, 用户点击行把该消息转出到文本编辑器"""
    open_chat_message(context, self)


def on_image_index_update(self, context: Context):
    """纹理/效果图图像列表活跃索引回调: 用户点击行时同步缩略图选中态, 并按偏好切换图像编辑器

    缩略图选中值与"自动打开图像"偏好无关(列表切换后缩略图的选中态必须跟着走),
    编辑器切换才受偏好控制.
    """
    if is_syncing() or not 0 <= self.images_active_index < len(self.images):
        return
    name = self.images[self.images_active_index].name
    # 缩略图选中态跟到点击的条目(护栏内写入, 不触发缩略图回调造成二次聚焦)
    select_gallery_value(self, name)
    if get_prefs().use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focus_image_editors(context, image)


# ------------------------------------------------------------
# 文件 -> 列表同步
# ------------------------------------------------------------


def _sync_all():
    """全量同步: 有变化才重建脚本与两个图像列表快照"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())
    sync_images_now()


def _on_load_post(*_args):
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐; 等待标志一并回收(模态已失效)"""
    try:
        reset_wait_state(bpy.context.window_manager.ch_ai_state)
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _sync_timer():
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register():
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister():
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
