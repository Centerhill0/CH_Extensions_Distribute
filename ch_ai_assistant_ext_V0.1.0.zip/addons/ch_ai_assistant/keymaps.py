"""
快捷键管理模块

提供以下功能:
- 定义插件的快捷键配置
- 注册和注销快捷键映射

快捷键在 keymap_items 中以数据表形式声明, 分组名按功能命名,
同一分组可包含多个上下文的条目(label 标注所属上下文, 如 Object / Edit_Mesh).

快捷键分组:

(暂无, 快捷键表为空)
"""

import bpy
from typing import Dict, List, Tuple, Any

from bpy.types import KeyMap, KeyMapItem


# ============================================================
# 快捷键配置数据
# ============================================================
keymap_items: Dict[str, List[Dict[str, Any]]] = {}

# 已注册的快捷键存储字典
# 格式: {分组名: [(显示标签, KeyMap, KeyMapItem), ...]}
addon_keymaps: Dict[str, List[Tuple[str, KeyMap, KeyMapItem]]] = {}


# ============================================================
# 快捷键注册/注销函数
# ============================================================


def register_keymaps() -> None:
    """
    注册插件的快捷键

    遍历 keymap_items 配置, 为每个条目创建键映射和键映射项,
    并存储到 addon_keymaps 字典中以便后续注销.

    幂等: 入口先清掉上一代条目. addon_keymaps 按分组名覆盖写入,
    若不清上一代, 旧 KeyMapItem 会失去句柄但仍在 keyconfigs.addon 中继续生效,
    造成同一快捷键触发多次且再也无法注销.
    """
    unregister_keymaps()

    kc = bpy.context.window_manager.keyconfigs.addon
    if not kc:
        return

    for km_name, km_entries in keymap_items.items():
        entries: List[Tuple[str, KeyMap, KeyMapItem]] = []

        for entry in km_entries:
            # 创建键映射
            km = kc.keymaps.new(name=entry['keymaps_name'], space_type=entry.get('space_type', 'EMPTY'))

            # 创建键映射项
            kmi = km.keymap_items.new(
                idname=entry['id_name'],
                type=entry['type'],
                value=entry['value'],
                shift=entry.get('shift', False),
                ctrl=entry.get('ctrl', False),
                alt=entry.get('alt', False),
            )

            # 设置操作属性(如菜单名称)
            if 'properties' in entry:
                for prop, value in entry['properties'].items():
                    setattr(kmi.properties, prop, value)

            # 格式化显示标签(添加缩进用于 UI 显示)
            display_label = ' ' * 6 + entry['label']
            entries.append((display_label, km, kmi))

        # 格式化分组名称并存储
        formatted_name = km_name.capitalize().replace('_', ' ')
        addon_keymaps[formatted_name] = entries


def unregister_keymaps() -> None:
    """
    注销插件的快捷键

    遍历 addon_keymaps 字典, 移除所有已注册的键映射项,
    并清空存储字典.

    注意: KeyMapItem/KeyMap 被移除后再访问会抛 ReferenceError(而非 RuntimeError/KeyError),
    用户在偏好"快捷键"页删掉任一条目后即产生这种失效句柄; 必须一并吞掉该异常,
    且 addon_keymaps.clear() 放在 finally 中 (否则字典残留失效句柄,
    之后每次禁用都在同一条目再次抛错, 插件再也无法干净禁用.
    """
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        if not kc:
            return

        for km_name, entries in addon_keymaps.items():
            for _, km, kmi in entries:
                try:
                    km.keymap_items.remove(kmi)
                except (RuntimeError, KeyError, ReferenceError):
                    pass
    finally:
        # 清空存储字典(无论移除是否成功, 都不能留下失效句柄)
        addon_keymaps.clear()
