"""
AI 相机效果图操作模块

场景相机视图渲染提取参考通道(Color/Depth/Normal/Lines/AO 按勾选), 连提示词送 AI 图像服务参考图生图.

操作流程:
1. 预览通道: 本地渲染相机视图并提取所选通道, 以固定名图像数据块在图像编辑器预览(不产生 API 费用)
2. 生成效果图: 描述取长文描述块(AI_Render_Prompt.txt)优先, 为空时取单行输入框;
   invoke 内先同步提取通道(RNA 渲染须主线程), 校验 Color 必选,
   输出尺寸按档位长边与参考图比率等比计算, 参考图按服务商上限截断后启动后台请求进入模态等待
3. 响应处理: 结果图加载为图像数据块(打包) -> 按偏好目录另存
   -> 产物置顶到图像列表第一位并聚焦图像编辑器

支持的选项:
- Color/Depth/Normal/Lines/AO: 参考通道开关, 参考优先序 Color > Depth > Normal > Lines > AO
- Current Engine: 用场景当前引擎与采样捕获参考(默认关, 走 EEVEE 草稿档)
- Size: 输出长边档位(1K/2K), 宽高比率跟随参考图
"""

import bpy
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ..handlers import activate_image
from ..preference import get_prefs
from ..utils import (
    AI_RENDER_PREFIX,
    AI_RENDER_PROMPT_TEXT_NAME,
    SIZE_LONG_EDGES,
    ai_render_name,
    api_error,
    build_render_prompt,
    capture_camera_passes,
    describe_error,
    fit_size,
    format_size,
    load_image_from_bytes,
    prompt_stem,
    ref_image_limit,
    request_image,
    save_image_file,
    unique_ai_name,
)
from .ai_generate import AiRequestMixin, maybe_auto_name_image, resolve_prompt
from .ai_texture import check_image_service, resolve_edit_model, resolve_image_service

# 通道键 -> 预览数据块标题(AO 不能走 capitalize, 否则成 "Ao")
_PASS_TITLES = {
    'color': "Color",
    'depth': "Depth",
    'normal': "Normal",
    'lines': "Lines",
    'ao': "AO",
}


def _write_preview_image(name: str, image_bytes: bytes) -> tuple:
    """把通道图写为固定名预览图像数据块(先删旧块防堆积), 返回 (Image 数据块, 错误信息)"""
    datablock_name = f"AI Ref: {_PASS_TITLES.get(name, name.capitalize())}"
    old = bpy.data.images.get(datablock_name)
    if old is not None:
        bpy.data.images.remove(old)
    return load_image_from_bytes(image_bytes, datablock_name)


def render_request_worker(op, request_args, model, prompt, ref_images, size, seed):
    """效果图请求后台线程入口(op 模拟 self): 参考图生图请求并把结果写入 op._result, 线程内兜底一切异常

    request_args 是主线程快照的偏好值元组(RNA 属性不支持跨线程读取):
    (base_url, api_key, timeout, provider); size 为按参考图比率计算的服务商尺寸字符串
    """
    try:
        base_url, api_key, timeout, provider = request_args
        image_bytes, err = request_image(
            base_url, api_key, model, prompt, timeout, provider=provider,
            size=size, ref_images=ref_images, seed=seed)
        op._result = (image_bytes, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


class CaptureViewRefs(Operator):
    """
    捕获预览操作器

    功能: 本地渲染场景相机视图, 提取所选参考通道并以固定名图像数据块
    在图像编辑器预览; 不调用 AI 服务, 不产生 API 费用.
    """

    bl_idname = "ch_ai.capture_view_refs"
    bl_label = "Capture Preview"
    bl_description = "Render the camera view passes locally and preview them in the image editor (no API cost)"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        if context.scene.camera is None:
            self.report({'WARNING'}, "The scene has no active camera")
            return {'CANCELLED'}
        rstate = context.window_manager.ch_ai_render_state
        passes, _size, notices, err = capture_camera_passes(
            context, rstate.use_color, rstate.use_depth, rstate.use_normal,
            rstate.use_lines, rstate.use_ao, rstate.use_current_engine)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if not passes:
            self.report({'WARNING'}, "No passes captured, enable at least one pass")
            return {'CANCELLED'}

        last_image = None
        for name, data in passes.items():
            image, img_err = _write_preview_image(name, data)
            if img_err is not None:
                self.report({'WARNING'}, img_err)
            elif image is not None:
                last_image = image
        if last_image is not None:
            activate_image(context, last_image.name)
        for notice in notices:
            self.report({'INFO'}, report(notice))
        self.report({'INFO'}, report("Captured {} reference passes").format(len(passes)))
        return {'FINISHED'}


class GenerateRender(Operator, AiRequestMixin):
    """
    生成效果图操作器

    功能: 渲染场景相机视图提取参考通道(Color 必选, Depth/Normal/Lines/AO 按勾选),
    连提示词发 AI 图像服务参考图生图, 输出尺寸按档位长边与参考图比率计算,
    结果图在图像编辑器展示并按偏好目录存盘.

    要求: 场景有活动相机; Color 通道开启; 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.generate_render"
    bl_label = "Generate Render"
    bl_description = "Render the camera view, send the passes with your prompt to the AI image service"
    bl_options = {'REGISTER'}

    status_text = "Generating render... (Esc to cancel)"
    status_scope = 'render'

    def invoke(self, context: Context, event: Event):
        if context.scene.camera is None:
            self.report({'WARNING'}, "The scene has no active camera")
            return {'CANCELLED'}
        rstate = context.window_manager.ch_ai_render_state
        prompt = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, rstate.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the look you want in the prompt field first")
            return {'CANCELLED'}
        if not rstate.use_color:
            self.report({'WARNING'}, "Include the color pass, it is required for generation")
            return {'CANCELLED'}
        if not check_image_service(self, context.window_manager.ch_ai_render_service):
            return {'CANCELLED'}
        # 命名短名随请求一并快照: 等待期间描述被改动时产物名仍与请求内容一致
        self._stem = prompt_stem(prompt)
        self._prompt = prompt

        # 参考通道提取须在主线程(RNA 渲染), 模态等待前同步完成; 状态栏同步提示
        context.workspace.status_text_set("Capturing camera view passes...")
        try:
            passes, ref_size, notices, err = capture_camera_passes(
                context, rstate.use_color, rstate.use_depth, rstate.use_normal,
                rstate.use_lines, rstate.use_ao, rstate.use_current_engine)
        finally:
            context.workspace.status_text_set(None)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if 'color' not in passes:
            self.report({'ERROR'}, "The color reference pass is missing, generation aborted")
            return {'CANCELLED'}
        for notice in notices:
            self.report({'INFO'}, report(notice))

        prefs = get_prefs()
        sstate = context.window_manager.ch_ai_render_service
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        edit_model = resolve_edit_model(sstate, prefs)
        # capture 返回的通道按参考优先序排列(Color 首位), 超服务商上限截断
        items = list(passes.items())
        limit = ref_image_limit(provider)
        if len(items) > limit:
            dropped = ", ".join(name.capitalize() for name, _ in items[limit:])
            items = items[:limit]
            self.report({'INFO'}, report("Provider allows {} reference images, dropped: {}").format(limit, dropped))
        full_prompt = build_render_prompt(prompt, [name for name, _ in items])

        # 输出尺寸: 档位长边 + 参考图比率等比取偶
        out_w, out_h = fit_size(ref_size[0], ref_size[1], SIZE_LONG_EDGES[rstate.size])
        size_str = format_size(provider, out_w, out_h)

        args = ((base_url, api_key, prefs.image_timeout, provider),
                edit_model, full_prompt, [data for _, data in items], size_str, rstate.seed)
        if not self._start_request(context, render_request_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, image_bytes, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        image, err = load_image_from_bytes(image_bytes, unique_ai_name(ai_render_name(self._stem)))
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        prefs = get_prefs()
        if prefs.image_save_dir:
            path, save_err = save_image_file(image, prefs.image_save_dir)
            if save_err is not None:
                self.report({'WARNING'}, save_err)
            else:
                self.report({'INFO'}, report("Image saved to {}").format(path))
        # 产物置顶到图像列表第一位并聚焦图像编辑器(返回值供"无编辑器区域"提示)
        focused = activate_image(context, image.name, top=True)
        if focused == 0:
            self.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
        # 提示词无英文词(名字落到兜底档)时, 异步用全局文本服务取一个英文名
        maybe_auto_name_image(image.name, self._prompt, AI_RENDER_PREFIX)
        return {'FINISHED'}
