"""
AI 纹理生成操作模块

提示词送 AI 图像服务文生图, 产物无缝化处理(可选)后加载为贴图打包, 不进材质.

操作流程:
1. 描述来源: 纹理长文描述块(AI_Texture_Prompt.txt)优先, 为空时取单行输入框
2. invoke: 校验提示词与图像服务配置, 组装纹理提示词模板(无缝平铺引导可选)后启动后台请求线程进入模态等待
3. modal: 计时器轮询线程结果并刷新面板等待进度, Esc 放弃等待(底层请求不中断, 结果丢弃)
4. 响应处理: Seamless 开启时字节先做本地边缘羽化混合无缝化 -> 加载为图像数据块(打包)
   -> 按偏好目录另存 -> 产物置顶到图像列表第一位并聚焦图像编辑器, 活动物体无 UV 时提示

支持的选项:
- Seamless: 提示词追加无缝平铺引导 + 产物本地边缘羽化混合保证可平铺(默认开)
- Size: 1K/2K 方图输出
"""

from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ..handlers import activate_image
from ..preference import get_prefs
from ..utils import (
    AI_TEXTURE_PREFIX,
    AI_TEXTURE_PROMPT_TEXT_NAME,
    PROVIDER_DEFAULT_MODELS,
    SIZE_LONG_EDGES,
    ai_texture_name,
    api_error,
    build_texture_prompt,
    describe_error,
    format_size,
    has_uv_layers,
    load_image_from_bytes,
    make_seamless,
    prompt_stem,
    request_image,
    resolve_image_endpoint,
    save_image_file,
    unique_ai_name,
)
from .ai_generate import AiRequestMixin, maybe_auto_name_image, resolve_prompt


def resolve_image_service(state, prefs) -> tuple:
    """按共享服务设置解析生效图像服务, 返回 (服务商, base_url, api_key)

    state 为图像助手的共享服务设置(AiImageServiceState); Global 跟随偏好服务商,
    覆盖模式端点/密钥取对应服务商的偏好配置.
    """
    provider = prefs.image_provider if state.service_mode == 'GLOBAL' else state.service_mode
    base_url, api_key = resolve_image_endpoint(provider, prefs)
    return provider, base_url, api_key


def resolve_texture_model(state, prefs) -> str:
    """解析生效纹理模型: Global/面板"跟随偏好"档取偏好模型, 覆盖服务商取面板下拉(空 = 该服务商预设默认)"""
    if state.service_mode == 'GLOBAL':
        return prefs.image_model_t2i
    return state.panel_t2i_model or PROVIDER_DEFAULT_MODELS.get(state.service_mode) or prefs.image_model_t2i


def resolve_edit_model(state, prefs) -> str:
    """解析生效编辑模型: Global/面板"跟随偏好"档取偏好模型, 覆盖服务商取面板下拉(空 = 该服务商预设默认)"""
    if state.service_mode == 'GLOBAL':
        return prefs.image_model_edit
    return state.panel_edit_model or PROVIDER_DEFAULT_MODELS.get(state.service_mode) or prefs.image_model_edit


def check_image_service(op, state=None) -> bool:
    """校验生效图像服务已配置(地址与密钥), 未配置时经 op 上报并返回 False

    state 非空时按共享服务设置(含覆盖)检查, 为空时按偏好全局配置检查.
    """
    prefs = get_prefs()
    if state is None:
        provider, base_url, api_key = (prefs.image_provider,) + resolve_image_endpoint(prefs.image_provider, prefs)
    else:
        provider, base_url, api_key = resolve_image_service(state, prefs)
    if not base_url or not api_key:
        op.report({'WARNING'}, "Set the API key of the selected image service in addon preferences first")
        return False
    return True


def snapshot_image_prefs() -> tuple:
    """主线程按全局默认服务商快照图像服务配置为纯 Python 值元组, 供后台线程使用"""
    prefs = get_prefs()
    base_url, api_key = resolve_image_endpoint(prefs.image_provider, prefs)
    return (base_url, api_key, prefs.image_timeout, prefs.image_provider)


def texture_request_worker(op, request_args, model, prompt, size, seed):
    """纹理请求后台线程入口(op 模拟 self): 文生图请求并把结果写入 op._result, 线程内兜底一切异常

    request_args 是主线程快照的偏好值元组(RNA 属性不支持跨线程读取):
    (base_url, api_key, timeout, provider)
    """
    try:
        base_url, api_key, timeout, provider = request_args
        image_bytes, err = request_image(
            base_url, api_key, model, prompt, timeout, provider=provider, size=size, seed=seed)
        op._result = (image_bytes, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


class GenerateTexture(Operator, AiRequestMixin):
    """
    生成纹理操作器

    功能: 把纹理描述发给 AI 图像服务, 产物无缝化处理(可选)后加载为贴图打包,
    不创建材质不赋物体; 需要使用时在着色器中新建图像纹理节点选择该贴图.

    要求: 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.generate_texture"
    bl_label = "Generate Texture"
    bl_description = "Ask the AI image service to generate a texture image and pack it into the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Generating texture... (Esc to cancel)"
    status_scope = 'texture'

    def invoke(self, context: Context, event: Event):
        tex_state = context.window_manager.ch_ai_texture_state
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, tex_state.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the texture in the prompt field first")
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_texture_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}

        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        model = resolve_texture_model(sstate, prefs)
        full_prompt = build_texture_prompt(prompt, tex_state.use_seamless)
        px = SIZE_LONG_EDGES[tex_state.size]
        size = format_size(provider, px, px)
        # 命名短名随请求一并快照: 等待期间描述被改动时产物名仍与请求内容一致
        self._stem = prompt_stem(prompt)
        self._prompt = prompt
        args = ((base_url, api_key, prefs.image_timeout, provider), model, full_prompt, size, tex_state.seed)
        if not self._start_request(context, texture_request_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, image_bytes, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if context.window_manager.ch_ai_texture_state.use_seamless:
            # 已计费的生成结果不能因本地后处理失败而丢弃: 失败时沿用原图并提示
            seamless_bytes, seamless_err = make_seamless(image_bytes)
            if seamless_err is not None:
                self.report({'WARNING'}, seamless_err)
            else:
                image_bytes = seamless_bytes
        name = unique_ai_name(ai_texture_name(self._stem))
        image, err = load_image_from_bytes(image_bytes, name)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        prefs = get_prefs()
        if prefs.image_save_dir:
            path, save_err = save_image_file(image, prefs.image_save_dir)
            if save_err is not None:
                self.report({'WARNING'}, save_err)
            else:
                self.report({'INFO'}, report("Image saved to {}").format(path))
        # 产物置顶到图像列表第一位并聚焦图像编辑器(返回值供"无编辑器区域"提示)
        focused = activate_image(context, image.name, top=True)
        if focused == 0:
            self.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
        # 提示词无英文词(名字落到兜底档)时, 异步用全局文本服务取一个英文名
        maybe_auto_name_image(image.name, self._prompt, AI_TEXTURE_PREFIX)
        for obj in (context.selected_objects or []):
            if not has_uv_layers(obj):
                self.report({'WARNING'}, report("'{}' has no UV map, unwrap it before using the texture").format(obj.name))
                break
        self.report({'INFO'}, report("Texture '{}' created").format(image.name))
        return {'FINISHED'}
