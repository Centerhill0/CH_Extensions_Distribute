"""
服务连通性测试操作模块

偏好设置中文本服务与图像服务的连通性测试, 结果写入 WM 状态供偏好面板常驻显示.

操作流程:
1. 文本服务: DeepSeek 走官方余额接口(不产生费用, 顺带显示账户余额);
   其余服务商发 max_tokens=1 的 ping 请求
2. 图像服务: 发一次最小尺寸(1K)的文生图请求——会产生一次生成费用(按钮悬停说明)
3. invoke: 校验对应服务配置与联网权限, 启动后台测试线程进入模态等待
4. modal: 计时器轮询线程结果, Esc 放弃等待
5. 响应处理: 结果(成功描述或错误文本)写入 ch_service_test 状态并 report
"""

from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ..preference import TEST_IMAGE_OP, TEST_TEXT_OP, get_prefs
from ..utils import (
    api_error,
    describe_error,
    fetch_deepseek_balance,
    format_size,
    ping_chat,
    request_image,
)
from .ai_generate import AiRequestMixin, check_chat_service, snapshot_chat_prefs
from .ai_texture import check_image_service, snapshot_image_prefs


def _text_test_worker(op, chat_args):
    """文本服务测试后台线程入口: DeepSeek 查余额, 其余发 ping, 结果写入 op._result"""
    base_url, api_key, model, timeout, provider = (chat_args[i] for i in (0, 1, 2, 4, 5))
    try:
        if provider == 'DEEPSEEK':
            result, err = fetch_deepseek_balance(base_url, api_key, timeout)
        else:
            result, err = ping_chat(base_url, api_key, model, timeout, provider)
        op._result = (result, err)
    except Exception as e:
        op._result = (None, api_error("The test thread crashed", e))


def _image_test_worker(op, image_args, model, prompt):
    """图像服务测试后台线程入口: 发一次最小尺寸生成请求, 结果写入 op._result"""
    base_url, api_key, timeout, provider, size = image_args
    try:
        image_bytes, err = request_image(base_url, api_key, model, prompt, timeout,
                                         provider=provider, size=size)
        if err is None:
            op._result = ("OK (one minimal image was generated, a generation fee applies)", None)
        else:
            op._result = (None, err)
    except Exception as e:
        op._result = (None, api_error("The test thread crashed", e))


class TestTextService(Operator, AiRequestMixin):
    """
    测试文本服务操作器

    功能: 验证对话服务连通与密钥(DeepSeek 查询账户余额, 其余服务商发
    max_tokens=16 的 ping 请求); 结果写入面板状态并 report.
    """

    bl_idname = TEST_TEXT_OP
    bl_label = "Test Text Service"
    bl_description = "Test the text service: query the DeepSeek balance or send a minimal ping"
    bl_options = {'REGISTER'}

    status_text = "Testing text service... (Esc to cancel)"
    status_scope = 'test'

    def invoke(self, context: Context, event: Event):
        if not check_chat_service(self):
            return {'CANCELLED'}
        chat_args = snapshot_chat_prefs()
        if not self._start_request(context, _text_test_worker, chat_args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        ts = context.window_manager.ch_service_test
        ts.text_ok = err is None
        ts.text_result = describe_error(content) if err is None else describe_error(err)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Service test passed: {}").format(content))
        return {'FINISHED'}


class TestImageService(Operator, AiRequestMixin):
    """
    测试图像服务操作器

    功能: 验证图像服务连通与密钥(发一次最小尺寸(1K)的文生图请求,
    产生一次生成费用); 结果写入面板状态并 report.
    """

    bl_idname = TEST_IMAGE_OP
    bl_label = "Test Image Service"
    bl_description = ("Test the image service with one minimal 1K generation "
                      "(a generation fee applies)")
    bl_options = {'REGISTER'}

    status_text = "Testing image service... (Esc to cancel)"
    status_scope = 'test'

    def invoke(self, context: Context, event: Event):
        if not check_image_service(self):
            return {'CANCELLED'}
        base_url, api_key, timeout, provider = snapshot_image_prefs()
        model = get_prefs().image_model_t2i
        size = format_size(provider, 1024, 1024)
        args = (base_url, api_key, timeout, provider, size)
        if not self._start_request(context, _image_test_worker, args,
                                   model, "a simple neutral gray square, minimal connectivity test"):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        ts = context.window_manager.ch_service_test
        ts.image_ok = err is None
        ts.image_result = describe_error(content) if err is None else describe_error(err)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Service test passed: {}").format(content))
        return {'FINISHED'}
