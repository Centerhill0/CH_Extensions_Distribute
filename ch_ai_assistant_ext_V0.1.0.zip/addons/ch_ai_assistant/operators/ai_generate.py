"""
AI 生成脚本操作模块

需求文本送 AI 服务生成 Blender 脚本, 产物写入文本编辑器并聚焦.
提示词优化与描述编辑对本插件的多个面板通用(脚本生成器 / 纹理生成器按 target 区分).

操作流程:
1. 描述来源: 文本编辑器长文描述块优先(脚本用 AI_Prompt.txt, 纹理用 AI_Texture_Prompt.txt),
   为空时取单行输入框
2. invoke: 校验描述与偏好配置, 组装消息(注释语言取偏好)后启动后台请求线程进入模态等待
3. modal: 计时器轮询线程结果并刷新面板等待进度, Esc 放弃等待(底层请求不中断, 结果丢弃)
4. 响应处理: 剥围栏 -> 解析 script-name 命名行(清洗/加 AI 前缀/重名加序号, 缺失回落递增名)
   -> 语法校验 -> 写入文本编辑器 -> 高亮列表并聚焦
"""

import os
import threading
import time

import bpy
from bpy.props import EnumProperty
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ..handlers import activate_script_top, reset_wait_state, sync_images_now
from ..preference import get_prefs
from ..utils import (
    AI_PROMPT_TEXT_NAME,
    AI_RENDER_PROMPT_TEXT_NAME,
    AI_TEXTURE_PROMPT_TEXT_NAME,
    CHAT_PROVIDER_DEFAULT_MODELS,
    SCRIPT_MAX_TOKENS,
    SCRIPT_MAX_TOKENS_GLM,
    SCRIPT_TIMEOUT_MIN,
    ai_script_name,
    api_error,
    build_auto_name_messages,
    build_context_info,
    build_generation_messages,
    build_optimize_messages,
    describe_error,
    ensure_unique_name,
    extract_script_name,
    focus_text_editors,
    next_script_name,
    prompt_stem,
    request_chat,
    resolve_chat_endpoint,
    sanitize_auto_name,
    strip_code_fences,
    validate_script,
    write_text_block,
)

# 描述面板候选(提示词优化与描述编辑共用; 条目标识与两个算子共用一份声明)
_prompt_target_items = [
    ('SCRIPT', "Script", "The script generator panel"),
    ('TEXTURE', "Texture", "The texture generator panel"),
    ('RENDER', "Render", "The render panel"),
]


def _prompt_source(wm, target: str) -> tuple:
    """按目标取 (单行描述, 长文描述块名, 等待进度作用域)

    脚本生成器用文本助手状态与脚本描述块; 纹理/效果图面板各用自己状态与描述块.
    """
    if target == 'TEXTURE':
        return wm.ch_ai_texture_state.prompt, AI_TEXTURE_PROMPT_TEXT_NAME, 'texture'
    if target == 'RENDER':
        return wm.ch_ai_render_state.prompt, AI_RENDER_PROMPT_TEXT_NAME, 'render'
    return wm.ch_ai_state.prompt, AI_PROMPT_TEXT_NAME, 'script'


def resolve_prompt(text_name: str, inline_prompt: str) -> str:
    """生成/修改用描述: 长文描述块优先, 为空时取单行输入框, 返回清洗后的文本

    各面板用各自的长文描述块(脚本 AI_Prompt.txt / 纹理 AI_Texture_Prompt.txt), 互不覆盖.
    """
    text = bpy.data.texts.get(text_name)
    if text is not None:
        content = text.as_string().strip()
        if content:
            return content
    return inline_prompt.strip()


def resolve_text_service(state, prefs) -> tuple:
    """按共享服务设置解析生效文本服务与模型, 返回 (服务商, base_url, api_key, 模型)

    state 为文本助手的共享服务设置(AiTextServiceState); Global 跟随偏好服务商与模型,
    覆盖模式端点/密钥取对应服务商的偏好配置, 模型取面板下拉(空 = 该服务商预设默认).
    """
    provider = prefs.provider if state.service_mode == 'GLOBAL' else state.service_mode
    base_url, api_key = resolve_chat_endpoint(provider, prefs)
    if state.service_mode == 'GLOBAL':
        model = prefs.model
    else:
        # 面板"跟随偏好"档(空标识)与偏好模型兜底: 覆盖服务商无预设默认时取偏好模型
        model = state.panel_model or CHAT_PROVIDER_DEFAULT_MODELS.get(provider) or prefs.model
    return provider, base_url, api_key, model


def check_chat_service(op, state=None) -> bool:
    """校验生效文本服务已配置(地址与密钥), 未配置时经 op 上报并返回 False

    state 非空时按共享服务设置(含覆盖)检查, 为空时按偏好全局配置检查.
    """
    prefs = get_prefs()
    if state is None:
        base_url, api_key = resolve_chat_endpoint(prefs.provider, prefs)
    else:
        _provider, base_url, api_key, _model = resolve_text_service(state, prefs)
    if not base_url or not api_key:
        op.report({'WARNING'}, "Set the API key of the selected text service in addon preferences first")
        return False
    return True


def chat_request_worker(op, request_args, messages, max_tokens=None):
    """对话请求后台线程入口(op 模拟 self): 单次请求并把结果写入 op._result, 线程内兜底一切异常

    request_args 是主线程快照的偏好值元组(RNA 属性不支持跨线程读取):
    (base_url, api_key, model, temperature, timeout, provider, thinking);
    max_tokens 为输出额度(脚本类请求传 SCRIPT_MAX_TOKENS, 对话/短输出请求不传).
    """
    try:
        base_url, api_key, model, temperature, timeout, provider, thinking = request_args
        content, err = request_chat(
            base_url, api_key, model, temperature, timeout, messages,
            provider=provider, thinking=thinking, max_tokens=max_tokens,
        )
        op._result = (content, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


def _script_max_tokens(provider: str):
    """文本类请求的输出额度: 偏好 Script Output Limit > 0 时优先(用户显式控制), 否则按服务商策略

    DeepSeek 省略 max_tokens(用服务端默认输出上限, 官方推荐不设);
    其余服务商下发 SCRIPT_MAX_TOKENS(思考模型需为思考链与正文留足空间), GLM 另有更大档位.
    """
    limit = get_prefs().script_max_tokens
    if limit > 0:
        return limit
    if provider == 'DEEPSEEK':
        return None
    return SCRIPT_MAX_TOKENS_GLM if provider == 'GLM' else SCRIPT_MAX_TOKENS


def start_script_request(op, context: Context, messages: list) -> bool:
    """脚本类请求统一启动: 取脚本面板服务设置, 超时抬到脚本下限, 输出额度按偏好或服务商策略

    超时: 取偏好超时与 SCRIPT_TIMEOUT_MIN 的较大者(思考模型长脚本生成远超对话级超时).
    """
    chat_args = list(snapshot_chat_prefs(context.window_manager.ch_ai_script_service))
    chat_args[4] = max(chat_args[4], SCRIPT_TIMEOUT_MIN)
    return op._start_request(context, chat_request_worker, tuple(chat_args),
                             messages, _script_max_tokens(chat_args[5]))


def start_global_text_request(op, context: Context, messages: list) -> bool:
    """全局文本服务(偏好设置)发起的文本请求: 纹理面板的提示词优化走此路

    与 start_script_request 的区别只在服务设置来源: 这里一律取偏好全局配置,
    不读文本助手面板的服务覆盖(需求: 纹理面板直接调用全局文本服务设置).
    """
    chat_args = list(snapshot_chat_prefs(None))
    chat_args[4] = max(chat_args[4], SCRIPT_TIMEOUT_MIN)
    return op._start_request(context, chat_request_worker, tuple(chat_args),
                             messages, _script_max_tokens(chat_args[5]))


def snapshot_chat_prefs(state=None) -> tuple:
    """主线程快照生效文本服务配置为纯 Python 值元组, 供后台线程使用

    state 非空时按面板服务设置(含覆盖)解析服务商/端点/密钥/模型与思考档位,
    为空时按偏好全局配置(测试用, 不下发思考档位).
    """
    prefs = get_prefs()
    if state is None:
        provider, base_url, api_key, model = (
            prefs.provider,) + resolve_chat_endpoint(prefs.provider, prefs) + (prefs.model,)
        thinking = ""
    else:
        provider, base_url, api_key, model = resolve_text_service(state, prefs)
        thinking = state.thinking
    return (base_url, api_key, model, prefs.temperature, prefs.timeout, provider, thinking)


# 自动命名等待表: {图像数据块名: {"result": (内容, 错误信息) 或 None}}
# 命名请求在后台线程跑, 结果由一秒节拍在主线程落成改名(改 RNA 必须在主线程, 且不能嵌套第二个等待模态)
_auto_name_pending = {}


def _auto_name_worker(holder: dict, chat_args: tuple, prompt: str, max_tokens) -> None:
    """自动命名后台线程: 请求文本服务给出简短英文名, 结果写入 holder(线程内兜底一切异常)"""
    try:
        base_url, api_key, model, temperature, timeout, provider, thinking = chat_args
        messages, _ = build_auto_name_messages(prompt)
        content, err = request_chat(
            base_url, api_key, model, temperature, timeout, messages,
            provider=provider, thinking=thinking, max_tokens=max_tokens)
        holder["result"] = (content, err)
    except Exception as e:
        holder["result"] = (None, api_error("The request thread crashed", e))


def _rename_image_and_file(image, new_name: str) -> None:
    """改名图像数据块, 并同步改名已存盘文件(重名由 Blender 自动加序号; 文件改名失败保持旧文件)"""
    path = image.filepath_raw
    image.name = new_name
    if not path or not os.path.isfile(path):
        return
    directory, _old_file = os.path.split(path)
    new_path = os.path.join(directory, f"{image.name}.png")
    if os.path.normpath(new_path) == os.path.normpath(path):
        return
    try:
        os.rename(path, new_path)   # 目标已存在时失败(不覆盖他人文件), 保留旧文件即可
    except OSError:
        return
    image.filepath_raw = new_path


def _auto_name_tick():
    """自动命名结果节拍: 把到期的命名结果在主线程落成改名, 无待办时自我注销"""
    for old_name, holder in list(_auto_name_pending.items()):
        if holder["result"] is None:
            continue
        content, err = holder["result"]
        del _auto_name_pending[old_name]
        stem = sanitize_auto_name(content) if err is None else ""
        image = bpy.data.images.get(old_name)
        # 命名不可用,数据块已删,或等待期间已被用户改名: 一律保持现状, 不打扰用户
        if not stem or image is None or image.name != old_name:
            continue
        # 名字必须保留产物前缀: 两个图像列表按前缀过滤, 丢掉前缀会让该图退出列表与缩略图
        _rename_image_and_file(image, f"{holder['prefix']} {stem}")
        sync_images_now()
    return 0.5 if _auto_name_pending else None


def maybe_auto_name_image(image_name: str, prompt: str, prefix: str) -> None:
    """提示词取不出英文短名时, 为刚生成的图像异步取一个英文名(结果由 _auto_name_tick 落地)

    触发条件: 偏好开关开启 + 名字落到兜底档(提示词无英文词, 如 "AI Tex"/"AI Render") +
    全局文本服务已配置; 命名请求失败或结果不可用时保留原名(静默, 不打扰用户).
    prefix 为产物前缀(如 "AI Tex"), 改名时拼回名字头部以留在对应图像列表内.
    """
    prefs = get_prefs()
    if not prefs.use_auto_name or prompt_stem(prompt):
        return
    chat_args = list(snapshot_chat_prefs(None))
    if not chat_args[0] or not chat_args[1]:
        return
    holder = {"result": None, "prefix": prefix}
    _auto_name_pending[image_name] = holder
    threading.Thread(target=_auto_name_worker,
                     args=(holder, tuple(chat_args), prompt, _script_max_tokens(chat_args[5])),
                     daemon=True).start()
    if not bpy.app.timers.is_registered(_auto_name_tick):
        bpy.app.timers.register(_auto_name_tick, first_interval=1.0)


class AiRequestMixin:
    """
    AI 请求模态等待 Mixin

    后台单次请求 + 计时器轮询模态等待: 状态栏提示等待中, Esc 放弃等待.
    脚本/对话/纹理/效果图各类 AI 算子共用; 子类在 invoke 中校验服务配置并组装
    纯 Python 参数后调用 _start_request, 并实现 _on_response 处理响应.
    """

    # 等待期间的状态栏文案与进度作用域, 子类按场景覆盖
    status_text = "Waiting for AI response... (Esc to cancel)"
    # 进度所属面板作用域('script'/'chat'/'texture'/'render'): 面板据此只显示自己的等待进度
    status_scope = 'script'

    _thread = None
    _timer = None
    _result = None

    def _start_request(self, context: Context, worker, *worker_args) -> bool:
        """校验联网与请求互斥后启动后台请求线程, 进入模态等待; 校验失败上报并返回 False

        worker 为线程入口(op 模拟 self, worker_args 透传), 须把 (结果, 错误信息) 写入 op._result;
        服务配置校验由调用方在 invoke 中先完成(worker_args 须为纯 Python 值,
        RNA 属性不支持跨线程读取).
        """
        if not bpy.app.online_access:
            self.report({'WARNING'}, "Online access is disabled, allow it in Blender system preferences")
            return False
        if context.window_manager.ch_ai_state.status:
            self.report({'WARNING'}, "An AI request is already running, wait for it to finish first")
            return False

        self._thread = threading.Thread(target=worker, args=(self, *worker_args), daemon=True)
        self._result = None
        self._timer = None
        self._thread.start()

        ai_state = context.window_manager.ch_ai_state
        ai_state.status = self.status_text
        ai_state.status_scope = self.status_scope
        ai_state.wait_seconds = 0
        ai_state.cancel_requested = False
        self._start_monotonic = time.monotonic()
        context.workspace.status_text_set(self.status_text)
        try:
            self._timer = context.window_manager.event_timer_add(0.25, window=context.window)
            context.window_manager.modal_handler_add(self)
        except Exception:
            # 计时器/模态挂载失败必须回滚已置位的等待标志, 否则 status 无清零点会永久堵住后续请求
            reset_wait_state(ai_state)
            context.workspace.status_text_set(None)
            raise
        if context.area is not None:
            context.area.tag_redraw()
        return True

    def modal(self, context: Context, event: Event):
        # 整体兜底: 模态内任何异常都清理等待状态并退出, 避免计时器/模态栈残留拖住界面
        try:
            return self._handle_modal(context, event)
        except Exception as e:
            try:
                self._finish_wait(context)
            except Exception:
                pass
            self.report({'ERROR'}, report("AI request failed unexpectedly: {}").format(e))
            return {'CANCELLED'}

    def _handle_modal(self, context: Context, event: Event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._finish_wait(context)
            self.report({'INFO'}, "AI request cancelled, the background request is abandoned")
            return {'CANCELLED'}
        if event.type == 'TIMER':
            ai_state = context.window_manager.ch_ai_state
            # 中断按钮置位优先处理: 用户意图放弃, 与 Esc 等效(后台请求不中断)
            if ai_state.cancel_requested:
                ai_state.cancel_requested = False
                self._finish_wait(context)
                self.report({'INFO'}, "AI request cancelled, the background request is abandoned")
                return {'CANCELLED'}
            if self._thread is not None and not self._thread.is_alive():
                result = self._result
                self._finish_wait(context)
                # 线程结果缺失(异常路径)时防御: 不崩模态栈
                if not (isinstance(result, tuple) and len(result) == 2):
                    self.report({'ERROR'}, "AI request finished without a result")
                    return {'CANCELLED'}
                content, err = result
                return self._on_response(context, content, err)
            # 等待中刷新已等待秒数与面板
            ai_state.wait_seconds = int(time.monotonic() - self._start_monotonic)
            if context.area is not None:
                context.area.tag_redraw()
        return {'PASS_THROUGH'}

    def _finish_wait(self, context: Context):
        """结束等待: 移除计时器, 清空状态栏与面板进度"""
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.workspace.status_text_set(None)
        ai_state = context.window_manager.ch_ai_state
        ai_state.status = ""
        ai_state.status_scope = ""
        ai_state.wait_seconds = 0
        if context.area is not None:
            context.area.tag_redraw()

    def _on_response(self, context: Context, content, err):
        """响应处理钩子, 子类必须实现并返回结果集"""
        raise NotImplementedError


class ClearPrompt(Operator):
    """
    清除提示词操作器

    功能: 清空对应面板的描述输入框(文本编辑器中的长文描述块不受影响).

    支持的目标:
    - SCRIPT: 脚本生成器
    - TEXTURE: 纹理生成器
    - RENDER: 效果图
    """

    bl_idname = "ch_ai.clear_prompt"
    bl_label = "Clear Prompt"
    bl_description = "Clear the prompt input field"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which panel's prompt to clear",
        items=[
            ('SCRIPT', "Script", "The script generator panel"),
            ('TEXTURE', "Texture", "The texture generator panel"),
            ('RENDER', "Render", "The render panel"),
        ],
        default='SCRIPT',
    )  # type: ignore

    def execute(self, context: Context):
        wm = context.window_manager
        if self.target == 'SCRIPT':
            wm.ch_ai_state.prompt = ""
        elif self.target == 'TEXTURE':
            wm.ch_ai_texture_state.prompt = ""
        else:
            wm.ch_ai_render_state.prompt = ""
        return {'FINISHED'}


class CancelRequest(Operator):
    """
    中断等待操作器

    功能: 中断等待中的 AI 请求(置取消标志, 等待模态在下一拍清理等待并放弃结果);
    后台请求不中断(与 Esc 放弃等待等效), 结果到时丢弃.
    """

    bl_idname = "ch_ai.cancel_request"
    bl_label = "Cancel"
    bl_description = "Cancel waiting for the running AI request, the background request is abandoned"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        context.window_manager.ch_ai_state.cancel_requested = True
        return {'FINISHED'}


class OptimizePrompt(Operator, AiRequestMixin):
    """
    优化提示词操作器

    功能: 把描述输入框的需求发给 AI 服务改写成清晰完整的描述,
    结果写入对应面板的长文描述块并聚焦文本编辑器.

    支持的目标:
    - SCRIPT: 脚本生成器, 走文本助手面板的服务设置, 改写成脚本需求描述, 结果写 AI_Prompt.txt
    - TEXTURE: 纹理生成器, 直接走偏好全局文本服务, 改写成材质贴图画面描述,
      结果写 AI_Texture_Prompt.txt
    - RENDER: 效果图面板, 同样走偏好全局文本服务, 改写成风格描述, 结果写 AI_Render_Prompt.txt
    """

    bl_idname = "ch_ai.optimize_prompt"
    bl_label = "Optimize Prompt"
    bl_description = "Rewrite the prompt with the AI service into a clearer description and put it in the text editor"
    bl_options = {'REGISTER'}

    target: EnumProperty(
        name="Target",
        description="Which panel's prompt to optimize",
        items=_prompt_target_items,
        default='SCRIPT',
    )  # type: ignore

    status_text = "Optimizing prompt... (Esc to cancel)"

    def invoke(self, context: Context, event: Event):
        wm = context.window_manager
        prompt, self._text_name, self.status_scope = _prompt_source(wm, self.target)
        prompt = prompt.strip()
        if not prompt:
            self.report({'WARNING'}, "Type the request to optimize in the prompt field first")
            return {'CANCELLED'}
        if self.target == 'SCRIPT':
            if not check_chat_service(self, wm.ch_ai_script_service):
                return {'CANCELLED'}
            starter = start_script_request
        else:
            # 图像侧两个面板按需求直接调用全局文本服务设置(偏好), 不读文本助手面板的服务覆盖
            if not check_chat_service(self, None):
                return {'CANCELLED'}
            starter = start_global_text_request
        # 优化口吻按目标分派: 脚本需求描述 / 材质贴图画面描述 / 效果图风格描述
        messages, _ = build_optimize_messages(prompt, self.target)
        if not starter(self, context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        text, _ = write_text_block(self._text_name, content.strip())
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        self.report({'INFO'}, report("Optimized prompt written to the '{}' text block").format(self._text_name))
        return {'FINISHED'}


class GenerateScript(Operator, AiRequestMixin):
    """
    生成脚本操作器

    功能: 把需求文本与可选场景上下文发给 AI 服务,
    产物清洗校验后写入文本编辑器新建脚本块并聚焦, 不自动执行.
    """

    bl_idname = "ch_ai.generate_script"
    bl_label = "Generate Script"
    bl_description = "Ask the AI service to write a script and put it in the text editor"
    bl_options = {'REGISTER'}

    status_text = "Generating script... (Esc to cancel)"

    def invoke(self, context: Context, event: Event):
        prompt = resolve_prompt(AI_PROMPT_TEXT_NAME, context.window_manager.ch_ai_state.prompt)
        if not prompt:
            self.report({'WARNING'}, "Type what script you need in the prompt field or the long description text first")
            return {'CANCELLED'}
        if not check_chat_service(self, context.window_manager.ch_ai_script_service):
            return {'CANCELLED'}
        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_generation_messages(prompt, context_info, get_prefs().comment_language)
        if not start_script_request(self, context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        # 命名行可能在围栏外或围栏内首行, 两段各解析一次(幂等)
        name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        name_in_code, code = extract_script_name(code)
        if name_in_code is not None:
            name = name_in_code
        # 统一加 AI 前缀(脚本列表的过滤标识)后保证唯一
        name = ensure_unique_name(ai_script_name(name if name is not None else next_script_name()[0]))
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(name, code)
        # 新生成的脚本置顶到列表第一位(不按名称排序), 并按偏好聚焦
        activate_script_top(context, name)
        if syntax_err is not None:
            self.report({'WARNING'}, report("Script saved but has syntax errors: {}").format(describe_error(syntax_err)))
        else:
            self.report({'INFO'}, report("Script '{}' created in the text editor").format(name))
        return {'FINISHED'}


class EditPrompt(Operator):
    """
    编辑描述操作器

    功能: 在文本编辑器中打开长文描述块(多行, 可自动换行),
    该面板的单行描述框为空时生成请求自动采用其内容.

    支持的目标:
    - SCRIPT: 脚本生成器(AI_Prompt.txt)
    - TEXTURE: 纹理生成器(AI_Texture_Prompt.txt)
    - RENDER: 效果图面板(AI_Render_Prompt.txt)
    (三块分开互不覆盖, 避免一个面板的长文描述被另一个面板的生成请求采用)
    """

    bl_idname = "ch_ai.edit_prompt"
    bl_label = "Edit Description"
    bl_description = "Edit a multi-line description in the text editor, used when the inline prompt is empty"
    bl_options = {'REGISTER'}

    target: EnumProperty(
        name="Target",
        description="Which panel's description to edit",
        items=_prompt_target_items,
        default='SCRIPT',
    )  # type: ignore

    def execute(self, context: Context):
        text_name = _prompt_source(context.window_manager, self.target)[1]
        text = bpy.data.texts.get(text_name)
        if text is None:
            text = bpy.data.texts.new(text_name)
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        return {'FINISHED'}
