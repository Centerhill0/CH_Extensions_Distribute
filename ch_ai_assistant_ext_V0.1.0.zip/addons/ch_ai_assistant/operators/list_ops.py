"""
列表条目排序操作模块

脚本/纹理图像/效果图图像三个列表的高亮条目上移与下移, 以及图像列表的条目删除;
排序写进数据块自定义属性(handlers.move_list_item), 对话列表无排序.
"""

import bpy
from bpy.props import EnumProperty
from bpy.types import Context, Operator

from ....common.ui.list_snapshot import set_index
from ..handlers import move_list_item, sync_images_now

# 排序目标与方向条目(模块级 *_items 供 i18n 提取, "Script/Texture/Render/Up/Down"为系统词条不入典)
_target_items = [
    ('SCRIPT', "Script", "The script list"),
    ('TEXTURE', "Texture", "The texture image list"),
    ('RENDER', "Render", "The render image list"),
]
_direction_items = [
    ('UP', "Up", "Move the item up"),
    ('DOWN', "Down", "Move the item down"),
]


class MoveListItem(Operator):
    """
    移动列表条目操作器

    功能: 把列表当前高亮条目与相邻条目交换排序位置(到顶/底时不动),
    排序持久存于数据块, 列表快照随之反映.

    支持的目标:
    - SCRIPT: 脚本列表(文本块)
    - TEXTURE: 纹理图像列表(贴图数据块)
    - RENDER: 效果图图像列表(图像数据块)
    """

    bl_idname = "ch_ai.move_list_item"
    bl_label = "Move List Item"
    bl_description = "Move the selected list item up or down"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which list to reorder",
        items=_target_items,
        default='SCRIPT',
    )  # type: ignore
    direction: EnumProperty(
        name="Direction",
        description="Move direction",
        items=_direction_items,
        default='UP',
    )  # type: ignore

    def execute(self, context: Context):
        moved = move_list_item(self.target, self.direction)
        if not moved:
            # 到顶/底或条目缺失: 静默不动(按钮本就无可用动作)
            return {'CANCELLED'}
        return {'FINISHED'}


class DeleteImage(Operator):
    """
    删除图像操作器

    功能: 删除纹理/效果图图像列表当前高亮的图像数据块(不可撤销), 高亮压回有效范围.

    支持的目标:
    - TEXTURE: 纹理图像列表(贴图数据块)
    - RENDER: 效果图图像列表(图像数据块)
    """

    bl_idname = "ch_ai.delete_image"
    bl_label = "Delete Image"
    bl_description = "Delete the selected image from the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=[
            ('TEXTURE', "Texture", "The texture image list"),
            ('RENDER', "Render", "The render image list"),
        ],
        default='TEXTURE',
    )  # type: ignore

    def execute(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_texture_state if self.target == 'TEXTURE' else wm.ch_ai_render_state
        idx = state.images_active_index
        # 负索引会取到末项(RNA 集合语义), 与"未选中"的意图相反, 故一并挡下
        if not 0 <= idx < len(state.images):
            self.report({'WARNING'}, "No image selected")
            return {'CANCELLED'}
        image = bpy.data.images.get(state.images[idx].name)
        if image is None:
            self.report({'WARNING'}, "Image no longer exists")
            return {'CANCELLED'}
        bpy.data.images.remove(image)
        # 立即重建两个图像列表快照, 高亮压回有效范围(护栏内写入, 不触发切换回调)
        sync_images_now()
        set_index(state, "images_active_index",
                  min(idx, len(state.images) - 1) if len(state.images) else 0)
        return {'FINISHED'}
