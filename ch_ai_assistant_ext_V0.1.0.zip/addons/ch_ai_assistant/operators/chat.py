"""
纯文本对话操作模块

与 AI 服务进行纯文本问答, 不生成/修改脚本, 不附带场景上下文.

操作流程:
1. 发送消息: 输入框内容入列消息历史, 连同最近历史(上限截断)送 AI, 回复追加到消息历史;
   已附带脚本时把脚本全文拼进消息头部, 发送后附件自动清空; 请求启动失败时回退刚入列的用户消息
2. 附带脚本: 把脚本列表当前高亮脚本标记为下一条消息的附件(再次点击取消)
3. 查看消息: 把当前高亮消息转出到文本编辑器专用文本块, 便于阅读长回复
4. 提取代码: 把当前高亮消息中的代码围栏内容提取到按功能命名的文本块并置顶高亮
5. 删除消息: 删除当前高亮的消息条目
6. 清除输入: 清空消息输入框
7. 清空对话: 清空全部消息历史
"""

import re

import bpy
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ....common.ui.list_snapshot import set_index
from ..handlers import activate_script_top
from ..preference import get_prefs
from ..utils import (
    AI_CHAT_CODE_NAME,
    AI_CHAT_TEXT_NAME,
    build_chat_messages,
    describe_error,
    ensure_unique_name,
    extract_code_blocks,
    focus_text_editors,
    prompt_stem,
    write_text_block,
)
from .ai_generate import AiRequestMixin, check_chat_service, chat_request_worker, snapshot_chat_prefs

# 代码内顶层函数/类定义名(只取无缩进的顶层定义, 类方法不算; 提取块按功能命名的首选来源)
_DEF_RE = re.compile(r"^(?:def|class)\s+([A-Za-z_]\w*)", re.MULTILINE)


def _chat_code_name(code: str, description: str) -> str:
    """提取代码按功能命名: 顶层 def/class 名优先(跳过下划线私有名, main 降级到最后),
    回落说明文本关键词, 再回落 Chat_Code"""
    candidates = [n for n in _DEF_RE.findall(code) if not n.startswith("_")]
    chosen = next((n for n in candidates if n != "main"), None)
    if chosen is None and candidates:
        chosen = candidates[0]
    if chosen:
        return f"AI Chat_{chosen}.py"
    stem = prompt_stem(description, words=4)
    if stem:
        return f"AI Chat_{stem}.py"
    return AI_CHAT_CODE_NAME


class ChatSend(Operator, AiRequestMixin):
    """
    发送对话消息操作器

    功能: 把输入框消息与最近对话历史发给 AI 服务,
    回复追加到消息历史, 输入框随即清空; 已附带脚本时脚本全文拼进消息头部.
    """

    bl_idname = "ch_ai.chat_send"
    bl_label = "Send Message"
    bl_description = "Send the message to the AI service and append the reply to the conversation"
    bl_options = {'REGISTER'}

    status_text = "Chatting with AI... (Esc to cancel)"
    # 进度显示在对话面板
    status_scope = 'chat'

    def invoke(self, context: Context, event: Event):
        message = context.window_manager.ch_ai_state.chat_input.strip()
        if not message:
            self.report({'WARNING'}, "Type a message first")
            return {'CANCELLED'}
        if not check_chat_service(self, context.window_manager.ch_ai_chat_service):
            return {'CANCELLED'}

        state = context.window_manager.ch_ai_state
        # 已附带脚本: 全文拼进消息头部; 附件标志在请求真正启动后才清空(启动失败要保住附件)
        attached_name = state.chat_script_name
        if attached_name:
            block = bpy.data.texts.get(attached_name)
            if block is not None:
                message = f"--- Attached script: {block.name} ---\n{block.as_string()}\n--- End of script ---\n\n{message}"
            else:
                self.report({'WARNING'}, report("Attached script '{}' no longer exists, sending without it").format(attached_name))
        item = state.chat_messages.add()
        item.role = 'USER'
        item.content = message
        state.chat_active_index = len(state.chat_messages) - 1
        history = [("user" if m.role == 'USER' else "assistant", m.content)
                   for m in state.chat_messages[:-1]]
        messages, _ = build_chat_messages(history, message, get_prefs().chat_history_limit)
        if not self._start_request(context, chat_request_worker, snapshot_chat_prefs(context.window_manager.ch_ai_chat_service), messages):
            # 请求未启动: 回退刚才入列的用户消息, 附件标志与消息一并保留供重发
            state.chat_messages.remove(len(state.chat_messages) - 1)
            state.chat_active_index = max(0, len(state.chat_messages) - 1)
            return {'CANCELLED'}
        state.chat_script_name = ""
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        state = context.window_manager.ch_ai_state
        item = state.chat_messages.add()
        item.role = 'ASSISTANT'
        item.content = content
        state.chat_active_index = len(state.chat_messages) - 1
        state.chat_input = ""
        return {'FINISHED'}


class ChatAttachScript(Operator):
    """
    附带脚本操作器

    功能: 把脚本列表当前高亮脚本标记为下一条消息的附件(再次点击同一脚本取消),
    发送时脚本全文拼进消息头部, 发送后附件自动清空.
    """

    bl_idname = "ch_ai.chat_attach_script"
    bl_label = "Attach Script"
    bl_description = "Pin the selected script from the script list to the next message"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        idx = state.scripts_active_index
        if idx >= len(state.scripts):
            return {'CANCELLED'}
        name = state.scripts[idx].name
        state.chat_script_name = "" if state.chat_script_name == name else name
        return {'FINISHED'}


class ChatViewMessage(Operator):
    """
    查看对话消息操作器

    功能: 把当前高亮消息写入对话专用文本块并聚焦文本编辑器,
    便于阅读被列表截断的长回复.
    """

    bl_idname = "ch_ai.chat_view_message"
    bl_label = "View Message"
    bl_description = "Open the selected message in the text editor to read long replies"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        if state.chat_active_index >= len(state.chat_messages):
            self.report({'WARNING'}, "No message selected")
            return {'CANCELLED'}
        content = state.chat_messages[state.chat_active_index].content
        text, _ = write_text_block(AI_CHAT_TEXT_NAME, content)
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        return {'FINISHED'}


class ChatExtractCode(Operator):
    """
    提取代码操作器

    功能: 把当前高亮消息中的代码围栏内容提取到 AI_Chat_Code.py 文本块并聚焦;
    多个代码块按出现顺序拼接, 消息中无代码块时报错.
    """

    bl_idname = "ch_ai.chat_extract_code"
    bl_label = "Extract Code"
    bl_description = "Extract the code blocks from the selected message into a text block"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        if not 0 <= state.chat_active_index < len(state.chat_messages):
            self.report({'WARNING'}, "No message selected")
            return {'CANCELLED'}
        code, description, has_blocks = extract_code_blocks(
            state.chat_messages[state.chat_active_index].content)
        if not has_blocks:
            self.report({'WARNING'}, "No code block in the selected message")
            return {'CANCELLED'}
        name = ensure_unique_name(_chat_code_name(code, description))
        text, _ = write_text_block(name, code)
        # 置顶到脚本列表第一位并高亮
        activate_script_top(context, text.name)
        self.report({'INFO'}, report("Code extracted to '{}'").format(text.name))
        return {'FINISHED'}


class ChatDeleteMessage(Operator):
    """
    删除对话消息操作器

    功能: 删除当前高亮的对话消息条目(不可撤销), 高亮压回有效范围.
    """

    bl_idname = "ch_ai.chat_delete_message"
    bl_label = "Delete Message"
    bl_description = "Delete the selected chat message"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        idx = state.chat_active_index
        if idx >= len(state.chat_messages):
            self.report({'WARNING'}, "No message selected")
            return {'CANCELLED'}
        state.chat_messages.remove(idx)
        # 高亮压回有效范围(护栏内写入, 不触发转出回调)
        set_index(state, "chat_active_index",
                  min(idx, len(state.chat_messages) - 1) if state.chat_messages else 0)
        return {'FINISHED'}


class ChatClearInput(Operator):
    """
    清除输入操作器

    功能: 清空消息输入框(消息历史不受影响).
    """

    bl_idname = "ch_ai.chat_clear_input"
    bl_label = "Clear Input"
    bl_description = "Clear the message input field"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        context.window_manager.ch_ai_state.chat_input = ""
        return {'FINISHED'}


class ChatClear(Operator):
    """
    清空对话操作器

    功能: 清空全部对话消息历史(不可撤销).
    """

    bl_idname = "ch_ai.chat_clear"
    bl_label = "Clear Chat"
    bl_description = "Delete the whole chat history"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        state.chat_messages.clear()
        state.chat_active_index = 0
        return {'FINISHED'}
