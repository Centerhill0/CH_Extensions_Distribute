"""
脚本操作模块

文本编辑器脚本的运行捕获, 一键 AI 调试, 对话修改, 删除与错误记录清理.

操作流程:
1. 运行脚本: 独立命名空间执行所选文本块, traceback 写入面板状态
2. 一键调试: 无该脚本已捕获错误时先代跑捕获, 脚本 + 报错送 AI, 修复稿写回原脚本并清错误记录
3. 对话修改: 脚本 + 修改要求送 AI, 修改稿写回原脚本, 修改/新增行头带简短修改说明;
   不满意可继续追加要求迭代(每次都以当前脚本为基准, 无需历史对话)
4. 删除脚本: 确认后删除文本块并同步列表快照
5. 清除错误: 清空面板的错误摘要
"""

import hashlib

import bpy
from bpy.props import StringProperty
from bpy.types import Context, Event, Operator, Text

from ....common.i18n.i18n import report
from ..handlers import activate_script_top, sync_scripts_now
from ..preference import get_prefs
from ..utils import (
    AI_PROMPT_TEXT_NAME,
    build_context_info,
    build_debug_messages,
    build_revise_messages,
    describe_error,
    extract_script_name,
    run_text_block,
    strip_code_fences,
    validate_script,
    write_text_block,
)
from .ai_generate import AiRequestMixin, check_chat_service, resolve_prompt, start_script_request


def _content_hash(content: str) -> str:
    """脚本内容摘要: 已捕获报错只对同一份内容复用, 内容变过则重捕(防旧 traceback 配新代码)"""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _record_error(ai_state, script_name: str, error_text: str | None, content: str):
    """把一次运行捕获的报错与内容摘要写入面板状态"""
    ai_state.last_error_script = script_name
    ai_state.last_error_traceback = error_text or ""
    ai_state.last_error_hash = _content_hash(content)


def _clear_error(ai_state):
    """清空面板错误记录(写回修复稿/删除脚本/手动清除共用)"""
    ai_state.last_error_script = ""
    ai_state.last_error_traceback = ""
    ai_state.last_error_hash = ""


class RunScript(Operator):
    """
    运行脚本操作器

    功能: 在独立命名空间中执行所选文本块,
    traceback 写入面板状态, 供一键调试与错误摘要显示使用.
    """

    bl_idname = "ch_ai.run_script"
    bl_label = "Run Script"
    bl_description = "Run the selected script and capture its error"
    bl_options = {'REGISTER'}

    script_name: StringProperty()  # type: ignore

    def execute(self, context: Context):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        content = text.as_string()
        ok, error_text = run_text_block(content, text.name)
        ai_state = context.window_manager.ch_ai_state
        _record_error(ai_state, text.name, error_text, content)
        if ok:
            self.report({'INFO'}, "Script ran without errors")
        else:
            last_line = error_text.strip().splitlines()[-1]
            self.report({'ERROR'}, report("Script failed: {}").format(last_line))
        return {'FINISHED'}


class DebugScript(Operator, AiRequestMixin):
    """
    一键调试操作器

    功能: 该脚本无已捕获错误时先代跑捕获报错,
    再把脚本全文与报错发给 AI 服务, 修复稿直接写回原脚本并清错误记录.
    """

    bl_idname = "ch_ai.debug_script"
    bl_label = "Debug Script"
    bl_description = "Send the script and its error to the AI service and fix it in place"
    bl_options = {'REGISTER'}

    status_text = "Debugging script with AI... (Esc to cancel)"

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}

        ai_state = context.window_manager.ch_ai_state
        error_text = self._capture_error(text, ai_state)
        if error_text is None:
            self.report({'INFO'}, "Script runs without errors, nothing to debug")
            return {'CANCELLED'}

        if not check_chat_service(self, context.window_manager.ch_ai_script_service):
            return {'CANCELLED'}
        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_debug_messages(
            text.as_string(), error_text, context_info, get_prefs().comment_language)
        if not start_script_request(self, context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _capture_error(self, text: Text, ai_state) -> str | None:
        """取该脚本的报错文本

        Args:
            text: 目标文本块
            ai_state: WM 级 AiState, 记录/复用已捕获的错误
        Returns:
            报错 traceback 文本; 脚本运行正常时返回 None
        """
        content = text.as_string()
        # 复用仅限"同一脚本 + 同一份内容": 脚本改过就代跑重捕, 避免旧 traceback 配新代码送 AI
        if (ai_state.last_error_script == text.name and ai_state.last_error_traceback
                and ai_state.last_error_hash == _content_hash(content)):
            return ai_state.last_error_traceback
        ok, captured = run_text_block(content, text.name)
        _record_error(ai_state, text.name, captured, content)
        if ok:
            return None
        return captured

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        # 等待期脚本可能已被删除: 写回前复查, 否则 write_text_block 会静默重建"复活"它
        if bpy.data.texts.get(self.script_name) is None:
            self.report({'WARNING'}, report("Script '{}' was deleted while waiting, result discarded").format(self.script_name))
            return {'CANCELLED'}
        # 修复稿写回原脚本, 不采用命名行(有则剥掉)
        _name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(self.script_name, code)
        # 写回后置顶到列表第一位(与生成/提取同规则)
        activate_script_top(context, self.script_name)
        # 修复稿已写回, 旧报错不再成立
        _clear_error(context.window_manager.ch_ai_state)
        if syntax_err is not None:
            self.report({'WARNING'}, report("Fix has syntax errors, written back to '{}'").format(self.script_name))
        else:
            self.report({'INFO'}, report("Fix written back to '{}', review and run it").format(self.script_name))
        return {'FINISHED'}


class ReviseScript(Operator, AiRequestMixin):
    """
    对话修改脚本操作器

    功能: 把所选脚本全文与修改要求发给 AI 服务, 修改稿直接写回原脚本并清错误记录;
    效果不满意可继续追加修改要求迭代(每次都以当前脚本为基准).
    """

    bl_idname = "ch_ai.revise_script"
    bl_label = "Revise Script"
    bl_description = "Send the script and your change request to the AI service and update it in place"
    bl_options = {'REGISTER'}

    status_text = "Revising script with AI... (Esc to cancel)"

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        # 修改要求与生成共用描述来源(长文描述块优先, 为空时取单行输入框)
        request = resolve_prompt(AI_PROMPT_TEXT_NAME, context.window_manager.ch_ai_state.prompt)
        if not request:
            self.report({'WARNING'}, "Type the change request in the prompt field first")
            return {'CANCELLED'}

        if not check_chat_service(self, context.window_manager.ch_ai_script_service):
            return {'CANCELLED'}
        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_revise_messages(
            text.as_string(), request, context_info, get_prefs().comment_language)
        if not start_script_request(self, context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        # 等待期脚本可能已被删除: 写回前复查, 否则 write_text_block 会静默重建"复活"它
        if bpy.data.texts.get(self.script_name) is None:
            self.report({'WARNING'}, report("Script '{}' was deleted while waiting, result discarded").format(self.script_name))
            return {'CANCELLED'}
        # 写回前把原稿更名为 <原名>_bak.py(腾出原名给修改稿; 同名旧备份先删, 每脚本只留最新一份)
        bak_name = self.script_name.removesuffix(".py") + "_bak.py"
        old_bak = bpy.data.texts.get(bak_name)
        if old_bak is not None:
            bpy.data.texts.remove(old_bak)
        bpy.data.texts[self.script_name].name = bak_name
        backup_name = bak_name
        # 修改稿写回原脚本, 不采用命名行(有则剥掉)
        _name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(self.script_name, code)
        # 写回后置顶到列表第一位(与生成/提取同规则)
        activate_script_top(context, self.script_name)
        # 写回后旧报错不再成立
        _clear_error(context.window_manager.ch_ai_state)
        self.report({'INFO'}, report("Original script backed up to '{}'").format(backup_name))
        if syntax_err is not None:
            self.report({'WARNING'}, report("Revision has syntax errors, written back to '{}'").format(self.script_name))
        else:
            self.report({'INFO'}, report("Revision written back to '{}', review and run it").format(self.script_name))
        return {'FINISHED'}


class DeleteScript(Operator):
    """
    删除脚本操作器

    功能: 确认后删除所选文本块并同步列表快照,
    错误记录指向它时一并清除(删除文本块不可撤销).
    """

    bl_idname = "ch_ai.delete_script"
    bl_label = "Delete Script"
    bl_description = "Delete the selected script from the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: Context):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        bpy.data.texts.remove(text)
        ai_state = context.window_manager.ch_ai_state
        if ai_state.last_error_script == self.script_name:
            _clear_error(ai_state)
        sync_scripts_now()
        self.report({'INFO'}, report("Script '{}' deleted").format(self.script_name))
        return {'FINISHED'}


class ClearError(Operator):
    """
    清除错误记录操作器

    功能: 清空面板错误摘要(最近一次运行捕获的 traceback).
    """

    bl_idname = "ch_ai.clear_error"
    bl_label = "Clear Error"
    bl_description = "Clear the last captured error"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        _clear_error(context.window_manager.ch_ai_state)
        return {'FINISHED'}
