"""
脚本操作模块

文本编辑器脚本的运行捕获, 一键 AI 调试, 对话修改, 删除与错误记录清理.

操作流程:
1. 运行脚本: 先做危险调用预检(命中高风险调用须确认), 再在独立命名空间执行所选文本块,
   traceback 写入面板状态
2. 一键调试: 无该脚本已捕获错误时先代跑捕获(代跑同样执行脚本, 故与运行共用危险调用预检),
   脚本 + 报错送 AI, 修复稿写回原脚本并清错误记录
3. 对话修改: 脚本 + 修改要求送 AI, 修改稿写回原脚本, 修改/新增行头带简短修改说明;
   原稿按偏好上限保留 "_bak" 备份环(超出移除最旧);
   不满意可继续追加要求迭代(每次都以当前脚本为基准, 无需历史对话)
4. 删除脚本: 确认后删除文本块并同步列表快照
5. 清除错误: 清空面板的错误摘要
6. 复制错误: 把面板错误摘要(标题 + 详情)复制到系统剪贴板, 便于反馈时整段粘贴
"""

import hashlib

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Context, Event, Operator, Text

from ....common.i18n.i18n import iface, report
from ..handlers import activate_script_top, sync_scripts_now
from ..items import panel_target_items
from ..preference import get_prefs
from ..utils import (
    AI_PROMPT_TEXT_NAME,
    build_context_info,
    build_debug_messages,
    build_revise_messages,
    describe_error,
    extract_script_name,
    run_text_block,
    scan_dangerous,
    strip_code_fences,
    validate_script,
    write_text_block,
)
from ..utils._backup import expired_backups
from .ai_generate import AiRequestMixin, check_chat_service, resolve_prompt, start_script_request


def _content_hash(content: str) -> str:
    """脚本内容摘要: 已捕获报错只对同一份内容复用, 内容变过则重捕(防旧 traceback 配新代码)"""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _prune_script_backups(op, base: str, keep_name: str) -> None:
    """按偏好上限清理同一脚本的旧 "_bak" 备份(与图像侧同语义)

    base 为脚本名干(未带 .py), keep_name 为刚改名的最新备份(必保留);
    挑选算法与备份名解析见 utils._backup.expired_backups, 兼容旧版带 .py 的备份名.
    """
    expired, _err = expired_backups(bpy.data.texts, base, keep_name, get_prefs().revise_backup_limit - 1)
    for text in expired:
        op.report({'INFO'}, report("Old script backup '{}' removed").format(text.name))
        bpy.data.texts.remove(text)


def _record_error(ai_state, script_name: str, error_text: str | None, content: str):
    """把一次运行捕获的报错与内容摘要写入面板状态; 运行成功(无报错)时清空旧错误记录"""
    if not error_text:
        _clear_error(ai_state)
        return
    ai_state.last_error_script = script_name
    ai_state.last_error_traceback = error_text
    ai_state.last_error_hash = _content_hash(content)


def _clear_error(ai_state):
    """清空面板错误记录(写回修复稿/删除脚本/手动清除共用)"""
    ai_state.last_error_script = ""
    ai_state.last_error_traceback = ""
    ai_state.last_error_hash = ""


# 面板错误摘要字段表: target -> (标题字段, 详情字段)
# 脚本档字段名与其余面板不同(last_error_script / last_error_traceback),
# 且多一个内容摘要字段(last_error_hash), 故清空走 _clear_error
_ERROR_FIELDS = {
    'SCRIPT': ("last_error_script", "last_error_traceback"),
    'CHAT': ("last_error_chat", "last_error_chat_detail"),
    'TEXTURE': ("last_error_texture", "last_error_texture_detail"),
    'RENDER': ("last_error_render", "last_error_render_detail"),
}


def error_field_names(target: str) -> tuple:
    """按目标面板取错误摘要的 (标题字段, 详情字段)(未登记的 target 回落脚本档)"""
    return _ERROR_FIELDS.get(target, _ERROR_FIELDS['SCRIPT'])


def clear_error_fields(ai_state, target: str) -> None:
    """按目标面板清空错误摘要

    脚本档(及任何未登记的 target)走 _clear_error: 它多清一个内容摘要字段
    (last_error_hash), 且与旧实现的 else 分支同口径; 其余面板清标题与详情两字段.
    """
    if target == 'SCRIPT' or target not in _ERROR_FIELDS:
        _clear_error(ai_state)
        return
    title_attr, detail_attr = _ERROR_FIELDS[target]
    setattr(ai_state, title_attr, "")
    setattr(ai_state, detail_attr, "")


def _risky_confirm(op, context: Context, event: Event, code: str):
    """脚本含高风险调用时列出命中项并弹确认框, 返回模态结果集; 无命中返回 None(调用方继续执行)

    RunScript 与 DebugScript 共用——两者都会执行脚本(前者直接运行, 后者无已捕获错误时代跑),
    故都须在"执行前"这一处收口. 命中项经 iface() 逐条翻译后拼进提示(拼接式标签须自查翻译).
    """
    hits = scan_dangerous(code)
    if not hits:
        return None
    op.report({'WARNING'}, report("Script calls destructive operations ({}), confirm to run").format(", ".join(iface(h) for h in hits)))
    return context.window_manager.invoke_confirm(op, event)


class RunScript(Operator):
    """
    运行脚本操作器

    功能: 在独立命名空间中执行所选文本块,
    traceback 写入面板状态, 供一键调试与错误摘要显示使用.
    运行前做危险调用预检: 命中高风险调用(quit_blender/save_mainfile/rmtree/os.remove 等)
    时先弹确认框并列出命中项, 用户确认后才真正执行(见 utils.safety.scan_dangerous).
    """

    bl_idname = "ch_ai.run_script"
    bl_label = "Run Script"
    bl_description = "Run the selected script and capture its error"
    bl_options = {'REGISTER'}

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        # 脚本不存在时交给 execute 报错(报错文案与执行路径保持单一出口)
        if text is None:
            return self.execute(context)
        blocked = _risky_confirm(self, context, event, text.as_string())
        if blocked is not None:
            return blocked
        return self.execute(context)

    def execute(self, context: Context):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        content = text.as_string()
        ok, error_text = run_text_block(content, text.name)
        ai_state = context.window_manager.ch_ai_state
        _record_error(ai_state, text.name, error_text, content)
        if ok:
            self.report({'INFO'}, "Script ran without errors")
        else:
            last_line = error_text.strip().splitlines()[-1]
            self.report({'ERROR'}, report("Script failed: {}").format(last_line))
        return {'FINISHED'}


class DebugScript(Operator, AiRequestMixin):
    """
    一键调试操作器

    功能: 该脚本无已捕获错误时先代跑捕获报错,
    再把脚本全文与报错发给 AI 服务, 修复稿直接写回原脚本并清错误记录.
    代跑同样会执行脚本, 故与 RunScript 共用运行前的危险调用预检(见 _risky_confirm).
    """

    bl_idname = "ch_ai.debug_script"
    bl_label = "Debug Script"
    bl_description = "Send the script and its error to the AI service and fix it in place"
    bl_options = {'REGISTER'}

    status_text = "Debugging script with AI... (Esc to cancel)"

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        # 代跑会执行脚本, 故与 RunScript 同款预检: 命中高危调用先确认再继续
        blocked = _risky_confirm(self, context, event, text.as_string())
        if blocked is not None:
            return blocked
        return self._start_debug(context, text)

    def execute(self, context: Context):
        """预检确认后经此续跑(invoke_confirm 确认时回调 execute);
        直调(EXEC_DEFAULT)时等价于跳过预检直接调试, 与 RunScript.execute 同口径.
        """
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        return self._start_debug(context, text)

    def _start_debug(self, context: Context, text: Text):
        """代跑捕获(或复用)报错, 组装消息并发送 AI 调试请求; 返回结果集"""
        ai_state = context.window_manager.ch_ai_state
        error_text = self._capture_error(text, ai_state)
        if error_text is None:
            self.report({'INFO'}, "Script runs without errors, nothing to debug")
            return {'CANCELLED'}

        if not check_chat_service(self, context.window_manager.ch_ai_script_service):
            return {'CANCELLED'}
        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_debug_messages(text.as_string(), error_text, context_info, get_prefs().comment_language)
        if not start_script_request(self, context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _capture_error(self, text: Text, ai_state) -> str | None:
        """取该脚本的报错文本

        Args:
            text: 目标文本块
            ai_state: WM 级 AiState, 记录/复用已捕获的错误
        Returns:
            报错 traceback 文本; 脚本运行正常时返回 None
        """
        content = text.as_string()
        # 复用仅限"同一脚本 + 同一份内容": 脚本改过就代跑重捕, 避免旧 traceback 配新代码送 AI
        if ai_state.last_error_script == text.name and ai_state.last_error_traceback and ai_state.last_error_hash == _content_hash(content):
            return ai_state.last_error_traceback
        ok, captured = run_text_block(content, text.name)
        _record_error(ai_state, text.name, captured, content)
        if ok:
            return None
        return captured

    def _backup_source(self) -> str:
        """把原稿改名为 <原名>_bak 备份并清理旧备份, 返回备份名

        先备份再写回: 模型输出异常时原稿仍可恢复(与 ReviseScript 同语义).
        脚本在等待期被改名/删除时返回 None, 由调用方放弃写回, 不用下标访问抛 KeyError.
        """
        base = self.script_name.removesuffix(".py")
        source = bpy.data.texts.get(self.script_name)
        if source is None:
            return None
        source.name = f"{base}_bak"
        backup_name = source.name
        _prune_script_backups(self, base, backup_name)
        return backup_name

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        # 等待期脚本可能已被删除: 写回前复查, 否则 write_text_block 会静默重建"复活"它
        if bpy.data.texts.get(self.script_name) is None:
            self.report({'WARNING'}, report("Script '{}' was deleted while waiting, result discarded").format(self.script_name))
            return {'CANCELLED'}
        # 修复稿写回原脚本, 不采用命名行(有则剥掉)
        _name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        if not code.strip():
            # 输出被截断时可能只剩命名行: 空稿编译"成功", 直接写回会清空可用脚本
            self.report({'ERROR'}, report("AI returned an empty fix, original script kept"))
            return {'CANCELLED'}
        _, syntax_err = validate_script(code)
        if syntax_err is not None:
            # 语法错误的修复稿不覆盖原稿: 另存为草稿供检查, 原脚本保持可运行
            draft_name = f"{self.script_name.removesuffix('.py')}_draft"
            write_text_block(draft_name, code)
            self.report({'WARNING'}, report("Fix has syntax errors, saved as draft '{}'").format(draft_name))
            return {'CANCELLED'}
        backup_name = self._backup_source()
        if backup_name is None:
            self.report({'WARNING'}, report("Script '{}' was deleted while waiting, result discarded").format(self.script_name))
            return {'CANCELLED'}
        write_text_block(self.script_name, code)
        # 写回后置顶到列表第一位(与生成/提取同规则)
        activate_script_top(context, self.script_name)
        # 修复稿已写回, 旧报错不再成立
        _clear_error(context.window_manager.ch_ai_state)
        self.report({'INFO'}, report("Original script backed up to '{}'").format(backup_name))
        self.report({'INFO'}, report("Fix written back to '{}', review and run it").format(self.script_name))
        return {'FINISHED'}


class ReviseScript(Operator, AiRequestMixin):
    """
    对话修改脚本操作器

    功能: 把所选脚本全文与修改要求发给 AI 服务, 修改稿直接写回原脚本并清错误记录;
    效果不满意可继续追加修改要求迭代(每次都以当前脚本为基准).
    """

    bl_idname = "ch_ai.revise_script"
    bl_label = "Revise Script"
    bl_description = "Send the script and your change request to the AI service and update it in place"
    bl_options = {'REGISTER'}

    status_text = "Revising script with AI... (Esc to cancel)"

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        # 修改要求与生成共用描述来源(长文描述块优先, 为空时取单行输入框)
        request = resolve_prompt(AI_PROMPT_TEXT_NAME, context.window_manager.ch_ai_state.prompt)
        if not request:
            self.report({'WARNING'}, "Type the change request in the prompt field first")
            return {'CANCELLED'}

        if not check_chat_service(self, context.window_manager.ch_ai_script_service):
            return {'CANCELLED'}
        context_info = None
        if get_prefs().use_context:
            context_info, _ = build_context_info(context)
        messages, _ = build_revise_messages(text.as_string(), request, context_info, get_prefs().comment_language)
        if not start_script_request(self, context, messages):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        # 等待期脚本可能已被删除: 写回前复查, 否则 write_text_block 会静默重建"复活"它
        if bpy.data.texts.get(self.script_name) is None:
            self.report({'WARNING'}, report("Script '{}' was deleted while waiting, result discarded").format(self.script_name))
            return {'CANCELLED'}
        # 写回前把原稿更名为 <原名>_bak 备份(腾出原名给修改稿; 重名由 Blender 自动加序号),
        # 备份环按偏好上限保留(与图像侧 Edit Backups per Image 同语义), 超出移除最旧;
        # 备份名不带 .py(碰撞序号 .001/.002 干净递增, 旧带 .py 的备份按最旧清出)
        base = self.script_name.removesuffix(".py")
        source = bpy.data.texts[self.script_name]
        source.name = f"{base}_bak"
        backup_name = source.name
        _prune_script_backups(self, base, backup_name)
        # 修改稿写回原脚本, 不采用命名行(有则剥掉)
        _name, rest = extract_script_name(content)
        code = strip_code_fences(rest)
        _, syntax_err = validate_script(code)
        text, _ = write_text_block(self.script_name, code)
        # 写回后置顶到列表第一位(与生成/提取同规则)
        activate_script_top(context, self.script_name)
        # 写回后旧报错不再成立
        _clear_error(context.window_manager.ch_ai_state)
        self.report({'INFO'}, report("Original script backed up to '{}'").format(backup_name))
        if syntax_err is not None:
            self.report({'WARNING'}, report("Revision has syntax errors, written back to '{}'").format(self.script_name))
        else:
            self.report({'INFO'}, report("Revision written back to '{}', review and run it").format(self.script_name))
        return {'FINISHED'}


class DeleteScript(Operator):
    """
    删除脚本操作器

    功能: 确认后删除所选文本块并同步列表快照,
    错误记录指向它时一并清除(删除文本块不可撤销).
    """

    bl_idname = "ch_ai.delete_script"
    bl_label = "Delete Script"
    bl_description = "Delete the selected script from the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    script_name: StringProperty()  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: Context):
        text = bpy.data.texts.get(self.script_name)
        if text is None:
            self.report({'WARNING'}, "Script no longer exists")
            return {'CANCELLED'}
        bpy.data.texts.remove(text)
        ai_state = context.window_manager.ch_ai_state
        if ai_state.last_error_script == self.script_name:
            _clear_error(ai_state)
        sync_scripts_now()
        self.report({'INFO'}, report("Script '{}' deleted").format(self.script_name))
        return {'FINISHED'}


class ClearError(Operator):
    """
    清除错误记录操作器

    功能: 清空面板错误摘要(最近一次运行捕获的 traceback).
    """

    bl_idname = "ch_ai.clear_error"
    bl_label = "Clear Error"
    bl_description = "Clear the last captured error"
    bl_options = {'REGISTER'}

    # 清除对象面板: 脚本(运行错误) / 对话 / 纹理与图像 / 效果图(各自的请求错误摘要)
    target: EnumProperty(
        name="Target",
        description="Which panel's error record to clear",
        items=panel_target_items,
        default='SCRIPT',
    )  # type: ignore

    def execute(self, context: Context):
        clear_error_fields(context.window_manager.ch_ai_state, self.target)
        return {'FINISHED'}


class CopyError(Operator):
    """
    复制错误操作器

    功能: 把面板错误摘要(标题 + 详情)复制到系统剪贴板, 便于反馈时整段粘贴;
    脚本面板存的是 last_error_script/traceback, 其余面板是 last_error_<scope>/_detail.
    """

    bl_idname = "ch_ai.copy_error"
    bl_label = "Copy Error"
    bl_description = "Copy the last captured error to the clipboard"
    bl_options = {'REGISTER'}

    # 复制对象面板: 脚本(运行错误) / 对话 / 纹理与图像 / 效果图(各自的请求错误摘要)
    target: EnumProperty(
        name="Target",
        description="Which panel's error record to copy",
        items=panel_target_items,
        default='SCRIPT',
    )  # type: ignore

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        title_attr, detail_attr = error_field_names(self.target)
        title = getattr(state, title_attr)
        detail = getattr(state, detail_attr)
        if not title and not detail:
            self.report({'WARNING'}, "No error to copy")
            return {'CANCELLED'}
        context.window_manager.clipboard = f"{title}\n{detail}".strip() if detail else title
        self.report({'INFO'}, report("Error copied to the clipboard"))
        return {'FINISHED'}
