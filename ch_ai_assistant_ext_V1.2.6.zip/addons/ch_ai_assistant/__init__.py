import bpy

from .config import __addon_name__
from .i18n.dictionary import dictionary
from ...common.class_loader import auto_load
from ...common.class_loader.auto_load import add_properties, remove_properties
from ...common.i18n.dictionary import common_dictionary
from ...common.i18n.i18n import load_dictionary
from .props import (
    AiAssistantState,
    AiImageServiceState,
    AiRenderState,
    AiTextServiceState,
    AiTextureState,
    ServiceTestState,
)

# 声明式属性挂载: WM 级 AI 助手状态(脚本列表快照/输入/错误记录/纹理与效果图输入), 不随 .blend 保存
_addon_properties = {
    bpy.types.WindowManager: {
        "ch_ai_state": bpy.props.PointerProperty(type=AiAssistantState),
        "ch_ai_texture_state": bpy.props.PointerProperty(type=AiTextureState),
        "ch_ai_render_state": bpy.props.PointerProperty(type=AiRenderState),
        "ch_service_test": bpy.props.PointerProperty(type=ServiceTestState),
        "ch_ai_script_service": bpy.props.PointerProperty(type=AiTextServiceState),
        "ch_ai_chat_service": bpy.props.PointerProperty(type=AiTextServiceState),
        "ch_ai_texture_service": bpy.props.PointerProperty(type=AiImageServiceState),
        "ch_ai_render_service": bpy.props.PointerProperty(type=AiImageServiceState),
    },
}


def register():
    """
    注册插件
    """
    # Register classes
    auto_load.init()
    auto_load.register()

    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(__addon_name__))


def unregister():
    """
    注销插件
    """
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)
    # unRegister classes
    auto_load.unregister()

    remove_properties(_addon_properties)
    print("{} addon is uninstalled.".format(__addon_name__))
