"""
AI 纹理与图像生成器面板模块

图像助手选项卡下的纹理与图像生成器面板:
- 生成图像列表(空也常驻, 行数随内容自适应; 右侧竖列为自动打开开关 + 排序 + 删除,
  见 blocks.draw_image_list_row)
- 预览区(常驻, 见 preview.draw_preview_box): 标题行最右侧为保存按钮, 下方大图预览,
  画廊开关展开后改为缩略图图标视图
- 生成参数小节(内联可折叠, 默认收起, 紧跟预览区): 首行为生成模式(纹理贴图 / 图像),
  其后为分辨率/宽高/实际输出/随机种/张数/多变体, 末尾为无缝贴图与参考图开关
- 描述输入(长文描述块优先) + 负向提示(仅支持该参数的服务商显示) + 编辑描述/优化提示词/
  完整提示词 + 修改图像与生成(名称随模式切换)
- 最近请求错误摘要与请求等待进度(末尾, 与其余面板同款)
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt
from ...operators.ai_texture import (
    GenerateTexture,
    ModifyImage,
    PreviewTexturePrompt,
    resolve_texture_model,
)
from ...preference import get_prefs
from ...utils import AI_TEXTURE_PROMPT_TEXT_NAME
from ...utils.provider_registry import effective_provider
from .blocks import (
    draw_operator,
    draw_error_box,
    draw_fold_header,
    draw_image_list_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_output_settings,
    draw_reference_list,
    draw_save_tail,
    draw_wait_box,
)
from .preview import draw_preview_box


def _draw_settings(layout, state, sstate, prefs) -> None:
    """生成参数小节(内联可折叠, 默认收起, 整体包在一个 box 中)

    与效果图面板的 Settings 同为内联可折叠小节(而非 bl_parent_id 子面板: 后者位置由
    Blender 决定, 无法插进主面板 draw 的中段), 使"预览 -> 参数 -> 描述/生成"的次序可控.
    展开后属性分栏排版, 生成模式在首位且与分辨率/张数等设置项同栏, 每项独占一行.
    """
    box = layout.box()
    draw_fold_header(box, state, "use_show_settings", "Settings")
    if not state.use_show_settings:
        return
    provider = effective_provider(sstate, prefs, 'image')
    model = resolve_texture_model(sstate, prefs)

    # 属性分栏列: 生成模式与分辨率/实际输出/随机种/张数/变体等生成参数共用同一栏
    # (分栏只作用于本小节内容, 不影响小节标题)
    sub = box.column()
    sub.use_property_split = True

    # 生成模式(本小节首位, 位于分辨率之前): 参与属性分栏——标签入左栏与其余设置项对齐,
    # 值列以 expand 并排两个模式按钮(显式 text 给左栏标签, 不依赖 RNA name)
    sub.row(align=True).prop(state, "generation_mode", text="Generation Mode", expand=True)

    # 分辨率/实际输出/随机种/张数/变体: 与效果图面板共用 blocks.draw_output_settings
    # (两图像面板同款; 仅置灰条件与随机化目标不同)
    lockable = state.generation_mode == 'PHOTO' or state.size_preset == 'CUSTOM'
    draw_output_settings(sub, state, provider, model, 'TEXTURE', editable=lockable, lock_enabled=lockable)

    # 无缝贴图: 常驻显示, 仅纹理贴图模式下可用(图像模式不参与无缝处理)
    seamless_row = sub.row()
    seamless_row.enabled = state.generation_mode == 'TEXTURE'
    seamless_row.prop(state, "use_seamless")

    # 使用参考图(紧贴无缝贴图下方): 开启后显示参考图引用迷你列表与描述行
    sub.prop(state, "use_ref_images")
    if state.use_ref_images:
        draw_reference_list(sub, state, 'TEXTURE')


@reg_order(2)
class AiTexturePanel(Panel):
    """AI 纹理与图像生成器面板"""

    bl_label = "Texture & Image Generator"
    bl_idname = "VIEW3D_PT_ch_ai_texture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与 AI 效果图面板共用)
    bl_category = "Image Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_texture_state
        layout = self.layout
        prefs = get_prefs()

        # 生成图像列表(空也常驻, 固定 4 行高; 快照由 handlers 实时刷新)
        draw_image_list_row(layout, state, "images", "images_active_index", "ch_ai_tex_images", 'TEXTURE')

        # 预览区(常驻): 标题行右侧为保存按钮, 大图预览 + 画廊开关
        draw_preview_box(layout, state, iface("No texture generated yet"), label_tail=lambda tail, s: draw_save_tail(tail, s, 'TEXTURE'))

        # 生效服务商(负向提示行的显隐判断; Global 档跟随偏好)
        sstate = wm.ch_ai_texture_service
        provider = effective_provider(sstate, prefs, 'image')

        # 生成参数小节: 紧跟预览区, 位于描述/操作行之前
        _draw_settings(layout, state, sstate, prefs)

        # ---- 描述输入与操作行 ----
        layout.separator(type='LINE')
        col = layout.column(align=False)
        prompt_row = col.row(align=True)
        prompt_row.prop(state, "prompt", text="Prompt")
        draw_operator(prompt_row, ClearPrompt.bl_idname, 'TEXTURE', 'CANCEL_LARGE', text="")
        # 负向提示: 仅支持该参数的服务商显示(简短输入, 行尾清除按钮)
        draw_negative_row(col, state, provider, 'TEXTURE')
        draw_long_desc_hint(col, AI_TEXTURE_PROMPT_TEXT_NAME)
        # 编辑描述 / 优化提示词(走偏好全局文本服务) / 完整提示词(与发送逐字一致)
        row = col.row(align=True)
        draw_operator(row, EditPrompt.bl_idname, 'TEXTURE', 'TEXT')
        row.separator(factor=0.5)
        draw_operator(row, OptimizePrompt.bl_idname, 'TEXTURE', 'SHADERFX')
        row.separator(factor=0.5)
        draw_operator(row, PreviewTexturePrompt.bl_idname, None, 'WORDWRAP_ON')
        # 修改图像在左(以高亮图像为参考图), 生成在右(名称随模式动态显示)
        # (文案直接写在调用处而非先取变量: 按钮文字是用户可见元素, 静态上应可查)
        row = col.row(align=True)
        draw_operator(row, ModifyImage.bl_idname, None, 'GREASEPENCIL')
        row.separator(factor=0.5)
        draw_operator(row, GenerateTexture.bl_idname, None, 'KEY_RETURN', text="Generate Texture" if state.generation_mode == 'TEXTURE' else "Generate Image")

        # ---- 末尾两段: 错误摘要 / 等待进度 ----
        draw_error_box(layout, wm, 'TEXTURE')
        draw_wait_box(layout, wm.ch_ai_state, 'texture')
