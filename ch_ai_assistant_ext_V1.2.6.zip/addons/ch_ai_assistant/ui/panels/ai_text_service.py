"""
文本助手服务设置面板模块

文本助手 Tab 顶部的服务设置(默认折叠): 脚本生成器与对话两组独立设置.
每组: 服务模式(全局/覆盖服务商)与覆盖模型 + 思考档位; Global 档置灰显示生效模型,
任一模式缺密钥在面板内警示.绘制逻辑见 blocks.draw_service_group(与图像侧同款).
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...preference import get_prefs
from ...utils.provider_registry import effective_provider, get_text_provider
from .blocks import draw_service_group

# 本面板的两个服务组: (状态属性名, 标题, 图标)
_GROUPS = (
    ("ch_ai_script_service", "Script Generator", 'CONSOLE'),
    ("ch_ai_chat_service", "Chat", 'COMMUNITY'),
)


def _key_attr(provider: str) -> str:
    """按文本服务商取偏好密钥字段名: 预设商查注册表, CUSTOM/未知回落通用 api_key 字段"""
    p = get_text_provider(provider)
    return p.api_key_attr if p is not None else "api_key"


def _draw_group(layout, state, title: str, icon: str) -> None:
    """绘制一个文本面板的服务设置组(服务商 + 覆盖模型 + 思考档位)"""
    prefs = get_prefs()
    provider = effective_provider(state, prefs, 'text')
    col = draw_service_group(layout, state, title, icon, _key_attr(provider), "panel_model", prefs.model)
    # 思考档位: 档位表按生效服务商定制(DeepSeek 4 档 / GLM 3 档 / 通用 3 档)
    col.prop(state, "thinking", text="Thinking Level")


@reg_order(1)
class AiTextServicePanel(Panel):
    """文本助手服务设置面板"""

    bl_label = "Text Service"
    bl_idname = "VIEW3D_PT_ch_ai_text_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与脚本生成器/对话面板共用)
    bl_category = "Text Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        wm = context.window_manager
        for attr, title, icon in _GROUPS:
            _draw_group(self.layout, getattr(wm, attr), title, icon)
