"""
图像助手服务设置面板模块

图像助手 Tab 顶部的服务设置(默认折叠): 纹理与图像生成器与效果图生成器两组独立设置.
每组: 服务模式(全局/覆盖服务商)与覆盖模型; Global 档置灰显示生效模型, 任一模式缺密钥
在面板内警示.绘制逻辑见 blocks.draw_service_group(与文本侧同款).
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...preference import get_prefs
from ...utils.provider_registry import effective_provider, get_image_provider
from .blocks import draw_service_group

# 本面板的两个服务组: (状态属性名, 标题, 图标, 覆盖模型属性名, 偏好侧的生效模型字段)
_GROUPS = (
    ("ch_ai_texture_service", "Texture & Image Generator", 'TEXTURE', "panel_t2i_model", "image_model_t2i"),
    ("ch_ai_render_service", "Render Generator", 'RENDER_RESULT', "panel_edit_model", "image_model_edit"),
)


def _draw_group(layout, state, title: str, icon: str, model_attr: str, effective_model: str) -> None:
    """绘制一个图像面板的服务设置组(密钥字段按生效服务商从注册表查表, 不硬编码)"""
    provider = effective_provider(state, get_prefs(), 'image')
    key_attr = get_image_provider(provider).api_key_attr
    draw_service_group(layout, state, title, icon, key_attr, model_attr, effective_model)


@reg_order(1)
class AiImageServicePanel(Panel):
    """图像助手服务设置面板"""

    bl_label = "Image Service"
    bl_idname = "VIEW3D_PT_ch_ai_image_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与纹理/效果图面板共用)
    bl_category = "Image Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        wm = context.window_manager
        prefs = get_prefs()
        for attr, title, icon, model_attr, effective_attr in _GROUPS:
            _draw_group(self.layout, getattr(wm, attr), title, icon, model_attr, getattr(prefs, effective_attr))
