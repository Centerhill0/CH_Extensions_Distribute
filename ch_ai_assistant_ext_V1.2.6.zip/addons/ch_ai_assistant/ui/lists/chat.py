"""
对话消息列表模块

文本助手选项卡下对话面板的 UIList(类名含 _UL_ 标记: Blender 注册约定, 类名即
template_list 的查找 id).用户与 AI 消息以图标区分, 行内只显示消息首行并截断
(长内容走面板的"查看消息"在文本编辑器阅读); 附带过脚本的消息跳过附件标记块,
显示实际消息首行.
"""

from bpy.types import Context, UIList, UILayout

from ...props import ChatMessage
from ...utils import chat_display_line

# 行内展示的长度上限(与 blocks.draw_long_desc_hint 同款惯用法):
# 列表行不截断时, 一条几千字符的单行回复会**每帧全文布局**, 界面直接冻结(实测).
# 完整内容走"查看消息"在文本编辑器阅读, 故此处只留预览.
_ROW_MAX_CHARS = 64


class CH_AI_UL_chat(UIList):
    """对话消息列表"""

    def draw_item(self, context: Context, layout: UILayout, data, item: ChatMessage, icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row_icon = 'USER' if item.role == 'USER' else 'COMMUNITY'
            # 只取首行显示; 附带消息取附件块之后的实际问题
            first_line, _attached = chat_display_line(item.content)
            if len(first_line) > _ROW_MAX_CHARS:
                first_line = first_line[:_ROW_MAX_CHARS] + "..."
            # translate=False: 消息内容是用户/AI 文本, 不参与翻译查询
            layout.label(text=first_line, icon=row_icon, translate=False)
        else:  # GRID: 图标视图下只画一个占位图标
            layout.alignment = 'CENTER'
            layout.label(text="", icon='USER')
