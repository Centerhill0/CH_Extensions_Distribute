"""
AI 图像列表 UIList 模块

两类列表共用本模块:
- CH_UL_ai_images: 纹理/效果图面板的图像条目列表(快照集合, 带内建名称过滤与排序控件行);
  行内名称可双击编辑(写穿到图像数据块, 见 common.blender.list_snapshot 的 rename_datablock),
  点击行走活跃索引回调(handlers.on_image_index_update)切换图像编辑器.
- CH_UL_ai_style_refs: 两面板的参考图引用列表(条目是引用组而非快照, 无过滤控件).

注意: 图像列表按前缀过滤, 把名字改掉前缀(如 "AI Tex"/"AI Render")会让该图退出对应列表
(与脚本列表改掉 "AI " 前缀同理), 只是不再出现在列表与缩略图里, 数据块本身仍在.
"""

from bpy.types import Context, UIList, UILayout

from .....common.i18n.i18n import iface
from .....common.blender.list_snapshot import StandardFilterMixin
from ...utils import AI_TEXTURE_PREFIX


class CH_UL_ai_images(StandardFilterMixin, UIList):
    """AI 生成图像条目列表(纹理/效果图面板共用, 经 template_list 的 list_id 区分实例)"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # 兜底名是纯前缀本身(无尾随空格, 见 utils.script_io._prefixed), 必须按常量整体匹配
            icon_id = 'TEXTURE' if item.name.startswith(AI_TEXTURE_PREFIX) else 'IMAGE_DATA'
            layout.prop(item, "name", text="", emboss=False, icon=icon_id)
        else:  # GRID: 图标视图下只画一个占位图标(名称在缩略图标签里)
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')


class CH_UL_ai_style_refs(UIList):
    """参考图引用列表(纹理参考图 / 效果图风格参考图; 非快照集合, 选中即高亮, 无内建过滤)"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            name = item.image.name if item.image is not None else iface("<missing>")
            layout.label(text=name, icon='IMAGE_DATA')
        else:  # GRID: 图标视图下只画一个占位图标
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')
