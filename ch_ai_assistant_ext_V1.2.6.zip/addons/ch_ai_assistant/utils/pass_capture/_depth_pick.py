"""按相机视锥几何投射采样可见深度(不渲染, 供面板一键回填深度范围)"""

import bpy
import numpy as np


from ..errors import api_error


from ._constants import _DEPTH_PICK_FAR_PCT, _DEPTH_PICK_GRID, _DEPTH_PICK_MIN_HITS, _DEPTH_PICK_NEAR_PCT


def sample_visible_depth(scene, grid: tuple = _DEPTH_PICK_GRID) -> tuple:
    """按相机视锥网格采样可见表面的视空间深度, 返回 (近端, 远端, 命中数, 错误信息)

    只做几何投射(复用 depsgraph 的求值场景与 BVH), **不渲染**, 故可一键"取景":
    取命中深度的 2%/98% 分位数作区间锚点, 两端各钳掉 2% 的极值, 避免个别极近/极远像素
    把区间拉爆,主体层次反被压扁(反深度曲线对 near 尤其敏感: near 偏小会把整幅画压到灰阶底端).

    深度口径与深度通道严格一致——**相机视空间 Z(米制)**而非到相机的欧氏距离, 二者在画面
    边角差异明显; 相机裁剪范围外的几何不参与(裁剪掉的东西不会出现在通道图里).
    仅支持透视相机: 正交/全景相机的视锥语义不同, 直接报错交由用户手填, 不做半对的猜测.

    取景结果只写到面板的深度范围属性上, 之后仍可手工修改; 采样网格与分位数见模块常量.
    """
    camera = getattr(scene, "camera", None)
    cam_data = getattr(camera, "data", None)
    if camera is None or cam_data is None or camera.type != 'CAMERA':
        return None, None, 0, api_error("The scene has no active camera")
    if getattr(cam_data, "type", 'PERSP') != 'PERSP':
        return None, None, 0, api_error("Depth picking supports perspective cameras only")
    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        frame = cam_data.view_frame(scene=scene)
    except Exception as e:  # noqa: BLE001 - 取景面/求值场景不可得时转成提示
        return None, None, 0, api_error("Failed to pick the depth range", e)
    columns, rows = max(2, int(grid[0])), max(2, int(grid[1]))
    mw = camera.matrix_world
    mw_inv = mw.inverted()
    origin = mw.translation
    clip_start = float(getattr(cam_data, "clip_start", 0.0))
    clip_end = float(getattr(cam_data, "clip_end", 0.0))
    depths = []
    for iy in range(rows):
        v = (iy + 0.5) / rows
        for ix in range(columns):
            u = (ix + 0.5) / columns
            # 视景面四角双线性插值取本根射线的目标点(view_frame 已含 sensor_fit/shift)
            target = frame[0] * (1.0 - u) * (1.0 - v) + frame[1] * u * (1.0 - v) + frame[2] * u * v + frame[3] * (1.0 - u) * v
            to_target = (mw @ target) - origin
            if to_target.length_squared == 0.0:
                continue
            # ray_cast 返回 6 元组, 前两项即 (是否命中, 命中点世界坐标)
            hit, location = scene.ray_cast(depsgraph, origin, to_target.normalized())[:2]
            if not hit:
                continue
            depth = -(mw_inv @ location).z
            if depth <= 0.0 or depth < clip_start or (clip_end > 0.0 and depth > clip_end):
                continue
            depths.append(depth)
    if len(depths) < _DEPTH_PICK_MIN_HITS:
        return None, None, len(depths), api_error("No geometry was found inside the camera view")
    arr = np.asarray(depths, dtype=np.float64)
    near = float(np.percentile(arr, _DEPTH_PICK_NEAR_PCT))
    far = float(np.percentile(arr, _DEPTH_PICK_FAR_PCT))
    if far - near < 1e-4:
        # 极浅场景(单层平面/几何深度几乎一致): 撑开一点跨度, 否则映射退化成一片同色
        pad = max(near * 0.01, 1e-3)
        near, far = max(near - pad, 0.0), far + pad
    return round(near, 3), round(far, 3), len(depths), None
