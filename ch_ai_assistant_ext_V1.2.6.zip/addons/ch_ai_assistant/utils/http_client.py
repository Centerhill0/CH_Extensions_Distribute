"""共享 HTTP 层(纯标准库, 不 import bpy, 可独立测试/复用)

文本与图像客户端共用的请求/错误阶梯:
- post_json: POST JSON 并解析响应, 统一超时/HTTP/连接/非 JSON 错误
- http_error_text: HTTP 错误体提取(只读前若干字节)

响应体设上限: 图像接口的 base64 响应可能很大, 但不能无上限读入内存.

错误文案走 api_error(可翻译 message + 动态 detail), 由交互层统一翻译.
"""

import http.client
import json
import urllib.error
import urllib.request

from .errors import api_error

# 响应体上限(字节)
_MAX_RESPONSE_BYTES = 128 * 1024 * 1024
# 错误响应只用于提取 message, 读前 64 KB 足够
_MAX_ERROR_BODY_BYTES = 64 * 1024


def http_error_text(e: urllib.error.HTTPError):
    """HTTP 错误转错误对象(消息可翻译, 服务端错误码与消息作 detail 原样透出)"""
    detail = ""
    try:
        body = json.loads(e.read(_MAX_ERROR_BODY_BYTES).decode("utf-8"))
        err = body.get("error", body) if isinstance(body, dict) else body
        if isinstance(err, dict):
            code = err.get("code", "")
            message = err.get("message", "")
            if code or message:
                detail = f"{code} {message}".strip()
    except Exception:
        pass
    return api_error("HTTP request failed", f"{e.code} {e.reason} {detail}".strip())


def post_json(url: str, body: bytes, api_key: str, timeout: int) -> tuple:
    """POST JSON 并解析响应, 返回 (响应 dict, 错误信息)

    错误阶梯: HTTP 状态 -> 超时(TimeoutError 先于 OSError) -> URLError -> 传输中断/解码
    -> 其它 OSError -> 非法 JSON. 不自动重试.
    """
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            length = resp.headers.get("Content-Length")
            if length is not None and length.isdigit() and int(length) > _MAX_RESPONSE_BYTES:
                return None, api_error("API response is too large")
            raw = resp.read(_MAX_RESPONSE_BYTES + 1)
        if len(raw) > _MAX_RESPONSE_BYTES:
            return None, api_error("API response is too large")
        return json.loads(raw.decode("utf-8")), None
    except urllib.error.HTTPError as e:
        return None, http_error_text(e)
    except TimeoutError:
        # 超过偏好 Timeout 的专门文案(TimeoutError 是 OSError 子类, 须先于 OSError 分支)
        return None, api_error("Request timed out")
    except urllib.error.URLError as e:
        # 连接握手阶段的超时会被包进 URLError.reason, 单独识别
        if isinstance(e.reason, TimeoutError):
            return None, api_error("Request timed out")
        return None, api_error("Request failed", e.reason)
    except (http.client.HTTPException, UnicodeDecodeError):
        # 传输中断/编码不是 UTF-8: 与"非法 JSON"同口径
        return None, api_error("API returned invalid JSON")
    except OSError as e:
        # 其余网络层错误(连接重置/远端断开等不是 URLError 的形态)
        return None, api_error("Connection error", e)
    except json.JSONDecodeError:
        return None, api_error("API returned invalid JSON")
