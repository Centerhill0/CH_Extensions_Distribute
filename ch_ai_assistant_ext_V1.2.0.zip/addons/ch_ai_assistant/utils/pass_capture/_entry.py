"""一次性捕获入口(会话的薄封装, 供脚本与测试直调)
"""


from ._constants import CRYPTO_SLOT_COUNT, CRYPTO_SOURCE_DEFAULT, EDGE_PRESET_DEFAULT, _EEVEE_SAMPLES


from ._session import PassCaptureSession


def capture_camera_passes(context, use_combined: bool, use_depth: bool, use_normal: bool,
                          use_segmentation: bool, use_edge: bool, use_diffuse: bool,
                          use_ao: bool, *, ao_distance: float = 1.0,
                          depth_near: float = 1.0, depth_far: float = 20.0,
                          depth_curve: str = 'LINEAR',
                          normal_convention: str = 'OPENGL', edge_width_scale: float = 1.0,
                          material_borders: bool = False,
                          edge_preset: str = EDGE_PRESET_DEFAULT,
                          clamp_long_edge: int = 0, render_samples: int = _EEVEE_SAMPLES,
                          crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                          crypto_slots: int = CRYPTO_SLOT_COUNT,
                          smooth_seg_edges: bool = False) -> tuple:
    """渲染场景相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)

    PassCaptureSession 的一次性薄封装: open + 逐批渲染 + close 一口气跑完
    (供脚本与测试直调; 模态算子改用会话按批驱动, 在批间更新进度).
    通道字典按参考优先序排列: {'combined': 字节, 'depth': 字节, 'normal': 字节,
    'segmentation': 字节, 'edge': 字节, 'diffuse': 字节, 'ao': 字节};
    size 为 (宽, 高) 即本次渲染的实际像素尺寸(各通道一致);
    提示消息为 api_error 对象(常量标题 + 动态通道键), 由交互层 describe_error 翻译后上报.
    全部通道由 EEVEE 出: 合并结果/深度/法向/漫射颜色/AO 一帧(用户世界), 语义分割一帧
    由 Cryptomatte 解码得到), 线稿一帧(场景线条画); 引擎不可用或通道缺失时跳过并写提示消息.
    通道参数: ao_distance 为 AO 遮蔽计算距离; depth_near/depth_far 为深度图白/黑映射区间
    (场景单位), depth_curve 选线性/反深度量化曲线(反深度把 8bit 灰阶向近端集中, 主体景深
    细节保留最多); normal_convention 选 OpenGL/DirectX(差异在绿通道方向); edge_width_scale
    为线稿宽度缩放系数, material_borders 控制线稿的材质之间是否生成笔画;
    clamp_long_edge 为输出长边钳制上限(<=0 表示不钳制, 直接用 Blender 输出分辨率乘百分比).
    """
    wanted = {'combined': use_combined, 'depth': use_depth, 'normal': use_normal,
              'diffuse': use_diffuse, 'ao': use_ao,
              'segmentation': use_segmentation, 'edge': use_edge}
    session = PassCaptureSession(
        context.scene, wanted,
        ao_distance=ao_distance, depth_near=depth_near, depth_far=depth_far,
        depth_curve=depth_curve, normal_convention=normal_convention,
        edge_width_scale=edge_width_scale, material_borders=material_borders,
        edge_preset=edge_preset,
        clamp_long_edge=clamp_long_edge, render_samples=render_samples,
        crypto_source=crypto_source, crypto_slots=crypto_slots,
        smooth_seg_edges=smooth_seg_edges)
    err = session.open()
    if err is not None:
        session.close()
        return {}, None, session.notices, err
    while session.has_pending():
        _frame_notices, frame_err, done = session.render_next_frame()
        if frame_err is not None:
            session.close()
            return {}, session.size, session.notices, frame_err
        if done:
            break
    ordered, size = session.collect()
    session.commit_cache()
    session.close()
    return ordered, size, session.notices, None
