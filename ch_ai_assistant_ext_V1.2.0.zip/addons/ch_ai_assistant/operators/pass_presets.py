"""
通道组合预设操作模块

把效果图面板的捕获/发送两组通道开关存为偏好里的命名快照(跨会话), 提供应用/保存/删除三个算子.
预设名清洗为 ASCII: 下拉是动态枚举, 非 ASCII 条目在 Blender C 层会渲染成乱码.
"""


import re


from bpy.types import Context
from bpy.types import Operator
from bpy.props import StringProperty


from ..preference import get_prefs


from .render_send import _PASS_TOGGLES, _SEND_TOGGLES


_PRESET_TOGGLES = tuple(attr for attr, _key in _PASS_TOGGLES) + tuple(attr for attr, _key in _SEND_TOGGLES)


def _sanitize_preset_name(name: str) -> str:
    """预设名清洗为 ASCII: 动态枚举下拉条目经 Blender C 层绘制, 非 ASCII 实测渲染成乱码

    非 ASCII 可打印字符的连续段折叠为单下划线并去掉首尾的 "_"/空格;
    清洗后为空(如纯中文名)返回空串, 由调用方回落序号自动命名.
    """
    return re.sub(r"[^\x20-\x7e]+", "_", name).strip("_ ")


class ApplyPassPreset(Operator):
    """
    应用通道组合预设操作器

    功能: 把偏好下拉中选中的通道组合预设写回面板的捕获/发送两组通道开关;
    预设存于偏好(跨会话), 由 SavePassPreset 保存, DeletePassPreset 删除.
    """

    bl_idname = "ch_ai.apply_pass_preset"
    bl_label = "Apply Pass Preset"
    bl_description = "Apply the selected pass preset to the capture and send toggles"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return len(get_prefs().pass_presets) > 0

    def execute(self, context: Context):
        prefs = get_prefs()
        preset = next((p for p in prefs.pass_presets if p.name == prefs.pass_preset_choice), None)
        if preset is None:
            self.report({'WARNING'}, "No pass preset selected")
            return {'CANCELLED'}
        rstate = context.window_manager.ch_ai_render_state
        for attr in _PRESET_TOGGLES:
            setattr(rstate, attr, getattr(preset, attr))
        return {'FINISHED'}


class SavePassPreset(Operator):
    """
    保存通道组合预设操作器

    功能: 把面板当前的捕获/发送两组通道开关快照存为偏好预设;
    名称留空时按序号自动命名("Preset N"), 重名即覆盖(更新已有预设);
    名称清洗为 ASCII(下拉是动态枚举, 非 ASCII 条目 C 层乱码), 清洗后为空按序号命名;
    保存后下拉自动选中该预设.
    """

    bl_idname = "ch_ai.save_pass_preset"
    bl_label = "Save Pass Preset"
    bl_description = "Save the current capture and send toggles as a named pass preset in the preferences"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(
        name="Name",
        description="Preset name, empty names it automatically, non-ASCII characters fold to underscores",
    )  # type: ignore

    def execute(self, context: Context):
        prefs = get_prefs()
        rstate = context.window_manager.ch_ai_render_state
        name = _sanitize_preset_name(self.name) or f"Preset {len(prefs.pass_presets) + 1}"
        preset = next((p for p in prefs.pass_presets if p.name == name), None)
        if preset is None:
            preset = prefs.pass_presets.add()
        preset.name = name
        for attr in _PRESET_TOGGLES:
            setattr(preset, attr, getattr(rstate, attr))
        prefs.pass_preset_choice = name
        return {'FINISHED'}


class DeletePassPreset(Operator):
    """
    删除通道组合预设操作器

    功能: 从偏好中删除下拉当前选中的通道组合预设(不可恢复); 删除后下拉回落.
    """

    bl_idname = "ch_ai.delete_pass_preset"
    bl_label = "Delete Pass Preset"
    bl_description = "Delete the selected pass preset from the preferences"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return len(get_prefs().pass_presets) > 0

    def execute(self, context: Context):
        prefs = get_prefs()
        idx = next((i for i, p in enumerate(prefs.pass_presets)
                    if p.name == prefs.pass_preset_choice), None)
        if idx is None:
            self.report({'WARNING'}, "No pass preset selected")
            return {'CANCELLED'}
        prefs.pass_presets.remove(idx)
        # 下拉选中值回落: 原条目已随删除消失(动态枚举失效值读回空串), 显式写回首项或占位档
        prefs.pass_preset_choice = prefs.pass_presets[0].name if len(prefs.pass_presets) else 'NONE'
        return {'FINISHED'}
