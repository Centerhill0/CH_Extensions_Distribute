"""
AI 纹理与图像生成器面板模块

提供以下功能:
- 图像助手选项卡下的生成图像列表(空也常驻, 行数随内容自适应; 点击行按偏好切换图像编辑器,
  上移/下移排序), 列表右侧: "自动打开图像"开关(存于偏好设置)与排序/删除按钮(排序对紧凑;
  列表行绘制见 ui/panels/blocks)
- 预览区(常驻, 见 ui/panels/preview): 标题行最右侧为保存全部图像与保存高亮图像两个按钮,
  下方为当前高亮纹理的大图预览, 画廊开关展开后改为纹理产物的缩略图图标视图
- 生成参数小节(内联可折叠, 默认收起, **紧跟预览区之后**; 属性分栏排版,
  每个设置项独占一行, **首位**为生成模式[行首"生成模式:"标签 + expand 展开的"纹理贴图/图像"枚举,
  与其余设置项**同属属性分栏**]: 分辨率预设[纹理 1K/2K 方图, 图像常用比率, 行尾锁定按钮] +
  宽高各一行[1K/2K 置灰; 实际输出标签行与高度行紧凑成组, 右对齐置灰] + 随机种与生成数量各一行 +
  批量多变体勾选[常驻, 仅张数>1 可用; 不支持 seed 的服务商只有比率变体] + 无缝贴图勾选[常驻, 仅纹理贴图模式可用] +
  "使用参考图"开关[无缝贴图下方, 开启后显示参考图引用迷你列表与描述行;
  参考图随生成发送, 走参考图生图, 模型同纯文生图]),
  描述输入(长文描述块优先), 负向提示(简短输入, 仅支持该参数的服务商显示, 行尾清除按钮),
  编辑描述与优化提示词与查看完整提示词的入口按钮(优化按生成模式选择贴图口吻或通用图像口吻,
  走全局文本服务), 修改图像与生成按钮(名称随模式切换)
- 请求等待进度(仅显示纹理流程), 进度后跟终止按钮
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt
from ...operators.ai_texture import (
    GenerateTexture,
    ModifyImage,
    PreviewTexturePrompt,
    resolve_texture_model,
)
from ...preference import get_prefs
from ...utils.provider_registry import effective_provider
from ...utils import AI_TEXTURE_PROMPT_TEXT_NAME
from .blocks import (
    draw_error_box,
    draw_image_list_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_output_settings,
    draw_ref_image_list,
    draw_save_tail,
    draw_wait_box,
)
from .preview import draw_preview_box


def _draw_settings(layout, state, sstate, prefs):
    """生成参数小节(内联可折叠, 默认收起, 整体包在一个 box 中)

    原为挂在主面板下的独立子面板(bl_parent_id), 其位置由 Blender 决定, 无法插进主面板 draw 的中段,
    故改为与预览区缩略图控件同款的内联可折叠小节, 使"预览 -> 参数 -> 描述/生成"的次序可控;
    展开后属性分栏排版(生成模式在首位, 与分辨率/张数等设置项**同栏**, 每个设置项独占一行);
    整体包 box 与预览区同族.
    """
    box = layout.box()
    header = box.row()
    header.prop(state, "use_show_settings", text="", emboss=False, icon='TRIA_DOWN' if state.use_show_settings else 'TRIA_RIGHT')
    header.label(text="Settings")
    if not state.use_show_settings:
        return
    provider = effective_provider(sstate, prefs, 'image')
    model = resolve_texture_model(sstate, prefs)

    # 属性分栏列: 生成模式与分辨率/实际输出/随机种/张数/变体等生成参数共用同一栏
    # (分栏只作用于本小节内容, 不影响小节标题)
    sub = box.column()
    sub.use_property_split = True

    # 生成模式(本小节首位, 位于分辨率之前): **参与属性分栏**——行首"生成模式"标签入左栏,
    # 与分辨率等设置项对齐, 值列 expand 并排模式按钮(纹理贴图 / 图像);
    # 显式 text 给左栏标签(不依赖 RNA name, 与词典键 "Generation Mode" 一致)
    row = sub.row(align=True)
    row.prop(state, "generation_mode", text="Generation Mode", expand=True)

    # 分辨率/实际输出/随机种/张数/变体: 与效果图面板共用 blocks.draw_output_settings
    # (两图像面板同款; 仅置灰条件与随机化目标不同)
    draw_output_settings(sub, state, provider, model, 'TEXTURE', editable=state.generation_mode == 'PHOTO' or state.size_preset == 'CUSTOM', lock_enabled=state.generation_mode == 'PHOTO' or state.size_preset == 'CUSTOM')
    # 无缝贴图: 常驻显示, 仅纹理贴图模式下可用(图像模式不参与无缝处理)
    seamless_row = sub.row()
    seamless_row.enabled = state.generation_mode == 'TEXTURE'
    seamless_row.prop(state, "use_seamless")
    # 使用参考图(紧贴无缝贴图下方): 开启后显示参考图引用迷你列表与描述行
    sub.prop(state, "use_ref_images")
    if state.use_ref_images:
        draw_ref_image_list(sub, state, 'TEXTURE')


@reg_order(2)
class AiTexturePanel(Panel):
    """AI 纹理与图像生成器面板"""

    bl_label = "Texture & Image Generator"
    bl_idname = "VIEW3D_PT_ch_ai_texture"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与 AI 效果图面板共用)
    bl_category = "Image Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_texture_state
        layout = self.layout

        # 生成图像列表(空也常驻, 固定 4 行高; 快照由 handlers 实时刷新)
        draw_image_list_row(layout, state, "images", "images_active_index", "ch_ai_tex_images", 'TEXTURE')

        # 预览区(常驻): 标题行右侧为保存图像按钮, 大图预览 + 画廊开关(展开为纹理缩略图的图标视图)
        draw_preview_box(layout, state, iface("No texture generated yet"), label_tail=lambda tail, s: draw_save_tail(tail, s, 'TEXTURE'))

        # 生效服务商(负向提示行的显隐判断; Global 跟随偏好服务商)与偏好, 参数小节与负向提示都要用
        sstate = wm.ch_ai_texture_service
        prefs = get_prefs()
        provider = effective_provider(sstate, prefs, 'image')

        # 生成参数小节: 紧跟预览区(首位生成模式, 后接尺寸/种/张数/无缝/参考图等), 位于描述/操作行之前
        _draw_settings(layout, state, sstate, prefs)

        # 描述输入与生成选项: 描述可走文本编辑器的长文描述块(编辑/优化按钮在本行下方)
        # (生成模式已移至上方设置小节首位, 本区仅描述 / 负向提示 / 操作行)
        # layout.separator()
        col = layout.column(align=False)
        col.separator()
        row = col.row(align=True)
        row.prop(state, "prompt", text="Prompt")
        row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE').target = 'TEXTURE'
        # 负向提示: 仅支持该参数的服务商(当前为百炼)显示, 简短输入设计, 行尾清除按钮
        draw_negative_row(col, state, provider, 'TEXTURE')
        draw_long_desc_hint(col, AI_TEXTURE_PROMPT_TEXT_NAME)
        row = col.row(align=False)
        op = row.operator(EditPrompt.bl_idname, icon='TEXT')
        op.target = 'TEXTURE'
        # 优化提示词: 纹理面板直接走偏好全局文本服务(不读文本助手面板的服务覆盖)
        op = row.operator(OptimizePrompt.bl_idname, icon='SHADERFX')
        op.target = 'TEXTURE'
        # 查看完整提示词: 文本编辑器查看实际发送的完整提示词(与生成请求逐字一致)
        row.operator(PreviewTexturePrompt.bl_idname, icon='WORDWRAP_ON')
        # 修改图像在左(以高亮图像为参考图做 AI 修改), 生成按钮在右,
        # 名称按生成模式动态显示(生成纹理/生成图像), 图标 RETURN
        btn_row = col.row(align=False)
        btn_row.operator(ModifyImage.bl_idname, icon='GREASEPENCIL')
        btn_row.operator(GenerateTexture.bl_idname, text="Generate Texture" if state.generation_mode == 'TEXTURE' else "Generate Image", icon='KEY_RETURN')

        # 最近请求错误摘要(末尾异常段), 右侧清除按钮
        draw_error_box(layout, wm, 'TEXTURE')

        # 等待进度: 面板最下方, 只显示本面板的纹理流程, 完成后自动消失;
        # 进度后跟终止按钮(放弃等待, 后台请求不中断)
        draw_wait_box(layout, wm.ch_ai_state, 'texture')
