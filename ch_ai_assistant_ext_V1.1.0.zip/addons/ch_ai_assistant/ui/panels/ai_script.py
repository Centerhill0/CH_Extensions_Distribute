"""
AI 脚本生成器面板模块

提供以下功能:
- 文本助手选项卡下的脚本列表(空也常驻, 行数随内容自适应; 点击行按偏好聚焦编辑器,
  运行/一键调试/删除, 上移/下移排序)
- 列表右侧: "自动打开脚本"开关(存于偏好设置)与排序按钮
- 需求输入与生成按钮(列表之后); 查看完整提示词按钮(生成请求的发送快照)
- 最近一次运行错误摘要与清除按钮
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...operators.ai_generate import (
    ClearPrompt,
    EditPrompt,
    GenerateScript,
    OptimizePrompt,
    ViewFullPrompt,
)
from ...operators.list_ops import MoveListItem
from ...operators.script_actions import (
    DebugScript,
    DeleteScript,
    ReviseScript,
    RunScript,
)
from ...preference import get_prefs
from ...utils import AI_PROMPT_TEXT_NAME
from ..lists.scripts import CH_AI_UL_scripts
from .blocks import draw_error_box, draw_long_desc_hint, draw_usage_hint, draw_wait_box


@reg_order(2)
class AiScriptPanel(Panel):
    """AI 脚本生成器面板"""

    bl_label = "Script Generator"
    bl_idname = "VIEW3D_PT_ch_ai_script"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与 AI 对话面板共用; 脚本生成器为主工作流在上, 对话面板在其下)
    bl_category = "Text Assistant"

    # 脚本列表显示行数下限(空列表的矮框高度, 与其余列表的实测定值一致)
    _SCRIPT_ROWS_MIN = 4

    # 脚本列表显示行数上限(行数随内容增长到该值)
    _SCRIPT_ROWS = 5

    def draw(self, context: Context):
        state = context.window_manager.ch_ai_state
        layout = self.layout

        # 脚本列表(空也常驻, 行数随内容从下限到上限; 快照由 handlers 实时刷新)
        # 右侧竖列: 自动打开开关 + 上移/下移排序(两键之间紧凑) + 删除;
        # 仅排序对紧凑(嵌套 align=True 列), 其余按钮保持默认间距, 依赖条目的按钮空列表时置灰
        has_items = len(state.scripts) > 0
        row = layout.row(align=True)
        row.template_list(CH_AI_UL_scripts.__name__, "ch_ai_scripts", state, "scripts", state, "scripts_active_index", rows=max(self._SCRIPT_ROWS_MIN, min(len(state.scripts), self._SCRIPT_ROWS)))
        col = row.column(align=False)
        col.prop(get_prefs(), "use_auto_open_scripts", text="", icon='TEXT', toggle=True)
        reorder = col.column(align=True)
        up_row = reorder.row(align=True)
        up_row.enabled = has_items
        op = up_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_UP')
        op.target, op.direction = 'SCRIPT', 'UP'
        down_row = reorder.row(align=True)
        down_row.enabled = has_items
        op = down_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_DOWN')
        op.target, op.direction = 'SCRIPT', 'DOWN'
        del_row = col.row(align=True)
        del_row.enabled = has_items
        op = del_row.operator(DeleteScript.bl_idname, text="", icon='X')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""

        # 点击行即聚焦文本编辑器(scripts_active_index 的 update 回调), 无需打开按钮
        row = layout.row(align=False)
        row.enabled = has_items
        op = row.operator(DebugScript.bl_idname, text="Debug", icon='ERROR')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""
        op = row.operator(RunScript.bl_idname, text="Run", icon='PLAY')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""

        # 描述输入: 长文描述块优先, 为空时采用单行输入; 行尾清除按钮
        layout.separator()
        col = layout.column(align=False)
        row = col.row(align=True)
        row.prop(state, "prompt", text="Prompt")
        row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE')
        # 长文描述提示: 右对齐置灰, 顺带展示内容首行(绘制见 ui/panels/blocks)
        draw_long_desc_hint(col, AI_PROMPT_TEXT_NAME)
        # 编辑描述 / 优化提示词 / 查看完整提示词(与生成请求逐字一致的发送快照)
        row = col.row(align=False)
        row.operator(EditPrompt.bl_idname, icon='TEXT')
        row.operator(OptimizePrompt.bl_idname, icon='SHADERFX')
        row.operator(ViewFullPrompt.bl_idname, icon='WORDWRAP_ON')
        row = col.row(align=False)
        revise_row = row.row(align=False)
        revise_row.enabled = has_items
        op = revise_row.operator(ReviseScript.bl_idname, icon='GREASEPENCIL')
        op.script_name = state.scripts[state.scripts_active_index].name if has_items else ""
        row.operator(GenerateScript.bl_idname, icon='KEY_RETURN')

        # 最近错误摘要(末尾异常段), 右侧清除/复制按钮; 脚本面板的运行错误字段与其余面板不同
        draw_error_box(layout, context.window_manager, 'SCRIPT', title_attr="last_error_script", detail_attr="last_error_traceback")

        # 最近请求用量(token 计数, 右对齐置灰): 生成/调试/修改完成后的消耗提示
        draw_usage_hint(layout, state, 'script')

        # 等待进度: 面板最下方, 只显示本面板的流程(生成/调试/修改), 完成后自动消失;
        # 进度后跟中断按钮(放弃等待, 后台请求不中断)
        draw_wait_box(layout, state, 'script')
