"""
AI 对话面板模块

提供以下功能:
- 文本助手选项卡下的消息历史列表(空也常驻, 行数随内容自适应; 点击行按偏好转出到文本编辑器阅读长回复;
  附带过脚本的消息跳过附件标记显示实际问题首行)
- 列表右侧: "自动打开对话"开关(存于偏好设置)与删除选定消息按钮
- 所选消息操作: 查看/提取代码/复制; 会话操作: 归档(转出文本块并开新对话)/清空(带确认)
- 输入框(行尾清除按钮), 重用/附带脚本/查看完整提示词/重新生成按钮与发送按钮
  (重新生成=摘掉最后一轮问答后, 输入框为空则重发摘掉的用户消息, 有内容则改发输入框内容)
- 请求等待进度与最近请求错误摘要(仅显示对话流程)
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.chat import (
    ChatArchive,
    ChatAttachScript,
    ChatClear,
    ChatClearInput,
    ChatCopyMessage,
    ChatDeleteMessage,
    ChatExtractCode,
    ChatRegenerate,
    ChatReuseMessage,
    ChatSend,
    ChatViewMessage,
    ChatViewPrompt,
)
from ...preference import get_prefs
from ..lists.chat import CH_AI_UL_chat
from .blocks import draw_error_box, draw_usage_hint, draw_wait_box


@reg_order(3)
class AiChatPanel(Panel):
    """AI 纯文本对话面板"""

    bl_label = "Chat"
    bl_idname = "VIEW3D_PT_ch_ai_chat"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与 AI 脚本生成器面板共用; 脚本生成器在上, 附带脚本向下取其列表高亮)
    bl_category = "Text Assistant"

    # 消息列表显示行数下限(空列表的矮框高度, 与其余列表的实测定值一致)
    _CHAT_ROWS_MIN = 4

    # 消息列表显示行数上限(行数随内容增长到该值)
    _CHAT_ROWS = 6

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_state
        layout = self.layout

        # 消息历史列表(空也常驻, 行数随内容从下限到上限; 发送/回复即入列,
        # 点击行按偏好转出到文本编辑器阅读); 右侧竖列: 自动打开开关 + 删除选定消息
        has_messages = len(state.chat_messages) > 0
        row = layout.row(align=True)
        row.template_list(CH_AI_UL_chat.__name__, "ch_ai_chat", state, "chat_messages", state, "chat_active_index", rows=max(self._CHAT_ROWS_MIN, min(len(state.chat_messages), self._CHAT_ROWS)))
        col = row.column(align=False)
        col.prop(get_prefs(), "use_auto_open_chat", text="", icon='TEXT', toggle=True)
        del_row = col.row(align=True)
        del_row.enabled = has_messages
        del_row.operator(ChatDeleteMessage.bl_idname, text="", icon='X')

        # 所选消息操作: 查看 / 提取代码 / 复制到剪贴板(无消息时置灰)
        col = layout.column(align=False)
        row = col.row(align=False)
        row.enabled = has_messages
        row.operator(ChatViewMessage.bl_idname, icon='TEXT')
        row.operator(ChatExtractCode.bl_idname, icon='CONSOLE')
        row.operator(ChatCopyMessage.bl_idname, icon='COPYDOWN')
        # 会话操作: 归档(全部消息转出文本块并开新对话) / 清空(带确认, 与删除脚本同款)
        row = col.row(align=False)
        row.enabled = has_messages
        row.operator(ChatArchive.bl_idname, icon='PACKAGE')
        row.operator(ChatClear.bl_idname, icon='TRASH')

        # 输入框(行尾清除按钮, 只清输入不动历史); 重用/附带脚本/查看完整提示词与发送同行
        # 各按钮独立置灰: 重用依赖消息, 附带依赖脚本列表, 查看完整提示词与发送恒可用;
        # 重新生成另起一行, 还需末条为 AI 回复才可点
        # (operator() 返回值无 enabled, 单按钮独立控制须各自包嵌套行)
        layout.separator()
        col = layout.column(align=False)
        row = col.row(align=True)
        row.prop(state, "chat_input", text="Message")
        row.operator(ChatClearInput.bl_idname, text="", icon='CANCEL_LARGE')
        script_state = context.window_manager.ch_ai_state
        last_is_reply = has_messages and state.chat_messages[len(state.chat_messages) - 1].role == 'ASSISTANT'

        row = col.row(align=False)
        reuse = row.row(align=False)
        reuse.enabled = has_messages
        reuse.operator(ChatReuseMessage.bl_idname, icon='LOOP_BACK')
        attach = row.row(align=False)
        attach.enabled = len(script_state.scripts) > 0
        attach.operator(ChatAttachScript.bl_idname, icon='TEXT')
        # 查看完整提示词: 文本编辑器查看下一次实际发送的完整消息列表(系统 + 历史 + 输入框,
        # 已附带脚本时含附件; 与发送逐字一致), 与其余文本/图像面板同款按钮同位
        row.operator(ChatViewPrompt.bl_idname, icon='WORDWRAP_ON')

        row = col.row(align=False)
        regen = row.row(align=False)
        regen.enabled = last_is_reply
        regen.operator(ChatRegenerate.bl_idname, icon='FILE_REFRESH')
        row.operator(ChatSend.bl_idname, icon='KEY_RETURN')
        # 附件状态行置灰显示
        if state.chat_script_name:
            note_row = col.row(align=True)
            note_row.enabled = False
            note_row.label(text=iface("Attached: {}").format(state.chat_script_name), icon='PINNED')

        # 最近请求错误摘要(与脚本/纹理/效果图面板同款), 右侧清除按钮;
        # 失败的用户消息留在历史且附件标志已找回, 面板内给一条持久的错误提示
        draw_error_box(layout, wm, 'CHAT')

        # 最近请求用量(token 计数, 右对齐置灰): 对话完成后的消耗提示
        draw_usage_hint(layout, state, 'chat')

        # 等待进度: 面板最下方, 只显示本面板的对话流程, 完成后自动消失;
        # 进度后跟中断按钮(放弃等待, 后台请求不中断)
        draw_wait_box(layout, state, 'chat')
