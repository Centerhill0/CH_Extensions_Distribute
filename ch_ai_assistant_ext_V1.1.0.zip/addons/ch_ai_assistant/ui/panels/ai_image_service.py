"""
图像助手服务设置面板模块

提供以下功能:
- 图像助手 Tab 顶部的服务设置(默认折叠): 纹理与图像生成器与效果图生成器两组的独立服务设置
- 每组: 服务模式(全局/覆盖服务商)与覆盖模型; Global 跟随偏好设置
- Global 档下置灰显示生效模型(取偏好对应字段, 与文本侧同款)
- 覆盖时端点/密钥取对应服务商的偏好配置; 任一模式缺密钥面板内警示
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...preference import get_prefs
from ...utils.provider_registry import effective_provider, get_image_provider
from .blocks import draw_service_group


def _draw_image_group(layout, state, title: str, icon: str, model_attr: str, effective_model: str):
    """绘制一个图像面板的服务设置组(服务商 + 覆盖模型)

    effective_model 为 Global 档的生效模型(取偏好对应字段), 置灰明示——面板里看不到
    偏好当前配的是哪个模型, 覆盖档没有这个问题(下拉即生效值); 与文本侧同款.
    密钥字段名按服务商从注册表查表(api_key_attr), 不再本地硬编码.
    """
    provider = effective_provider(state, get_prefs(), 'image')
    key_attr = get_image_provider(provider).api_key_attr
    draw_service_group(layout, state, title, icon, key_attr, model_attr, effective_model)


@reg_order(1)
class AiImageServicePanel(Panel):
    """图像助手服务设置面板"""

    bl_label = "Image Service"
    bl_idname = "VIEW3D_PT_ch_ai_image_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与纹理/效果图面板共用)
    bl_category = "Image Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        layout = self.layout
        wm = context.window_manager

        # 纹理与图像生成器(纹理模型)与效果图生成器(编辑模型)各自独立的服务设置
        _draw_image_group(layout, wm.ch_ai_texture_service, "Texture & Image Generator", 'TEXTURE',
                          "panel_t2i_model", get_prefs().image_model_t2i)
        _draw_image_group(layout, wm.ch_ai_render_service, "Render Generator", 'RENDER_RESULT',
                          "panel_edit_model", get_prefs().image_model_edit)
