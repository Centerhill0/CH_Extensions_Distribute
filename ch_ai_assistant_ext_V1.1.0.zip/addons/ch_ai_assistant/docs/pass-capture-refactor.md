# 效果图「通道生成」改造方案

> 本文是 `ch_ai_assistant` 通道生成管线的改造设计与实施记录。
> 全部技术前提均已**实机验证**（Blender 5.1.2，真实渲染 + 逐像素比对），验证清单见 §7；
> 涉及 Blender C 源码处只读本机 `D:\Development\BlenderProject\blender`。

---

## 0. 决策记录

| # | 决策 | 日期 |
| --- | --- | --- |
| D1 | 合并三项改动：**想法1**（视图层分帧 + 集合排除）、**想法3**（Cryptomatte 免覆盖分割）、**缓存粒度对齐渲染边界** | 本次 |
| D2 | 本方案文档移入 `addons/ch_ai_assistant/docs/` | 本次 |
| D3 | 线稿类型组合**做成「线稿预设」下拉**，不做成一组独立布尔开关 | 本次 |
| D4 | 不采用**想法2**（色彩空间改用 Convert 节点）—— 实测证明它不是 `save_as_render` 的等价替代 | 本次 |
| D5 | **本批（B1–B4）只做结构改造，不新增任何面向用户的参数**；需要穿透哪些参数待本批结束后另行确认 | 本次 |
| D6 | 实施按 B1–B4 四批推进，每批独立可测、可回退 | 本次 |
| D7 | 参数穿透批次实现 **3 项**：`cryptomatte_source`（物体/材质/资产）、`render_samples`（采样数）、`crypto_slots`（重叠层数） | 本次 |
| D8 | 后续再实现 **2 项**：`smooth_seg_edges`（分割边缘抗锯齿，默认锯齿）与 `edge_preset`（线稿预设下拉，兑现 D3）。**第二/第三梯队参数一律不做**（见 §4.6 的收口说明） | 本次 |
| D9 | **删除 B3 暂留的回退路径**（`GROUP_SEG` / `_make_seg_material` / `_make_black_world` / 视图层覆盖），并同步清理全部陈旧描述 | 本次 |

> **D5 的范围界定**：本批交付的是承载参数所需的**结构**（视图层分组、Cryptomatte 解码能力、
> 分组缓存），参数的 UI 入口与默认值待结构稳定后再加——避免"结构还没稳就先把面板铺满"。
> 该边界已在 D7/D8 两批兑现。

---

## 1. 一句话

把「**三帧渲染 + 材质/世界覆盖**」改成「**按渲染组划分的 1–2 次渲染 + Cryptomatte 免覆盖分割**」，
并让增量缓存的粒度与渲染组的边界对齐。

---

## 2. 现状与目标

### 2.1 现状（**改造前**的基线，留档对照）

| 帧 | 内容 | 场景态要求 |
| --- | --- | --- |
| A | Combined / Depth / Normal / Diffuse / AO | 用户世界 + 用户色彩管理 |
| B | Segmentation | 视层材质覆盖 + 纯黑世界覆盖 + 整场色彩管理压中立 |
| C | Line Drawing | 场景级蜡笔对象（会叠加进 Combined，故必须独立） |

- 渲染调用：3 次（模态每 0.1s 一拍渲一帧）
- 缓存：**一把扁平渲染键**管三帧（勾选集 / AO 距离 / 线宽 / 边界 / 尺寸 / 相机）
- 分割：`Object Info.Random → White Noise(1D).W` 覆盖材质，只能得到「每对象一色」

### 2.2 目标与实际落地（**已全部达成**）

| 组 | 内容 | 场景态要求 |
| --- | --- | --- |
| **M**（Main） | Combined / Depth / Normal / Diffuse / AO / **Cryptomatte** | 用户世界，**零覆盖** |
| **L**（LineArt） | Line Drawing | 蜡笔集合，**仅该组**包含 |

- 渲染调用：**1 次**（两组都失效时合成一次渲染调用；只失效一组时**只渲该组**；全命中则 0 次）
- 缓存：**每组一把键**，各自独立失效；「本次要哪些通道」不入键，由子集判定负责
- 分割：Cryptomatte 解码 → **物体 / 材质 / 资产** 三种粒度（D7 已开入口，出厂按材质）

---

## 3. 新架构

### 3.1 视图层与集合排除

```
tmp.view_layers[0]            → "VL_Main"     （默认层，改名）
tmp.view_layers.new("VL_LineArt")
```

蜡笔对象放进专用集合 `CH_AI_LineArt`，然后**按视图层排除**：

```python
vl_main.layer_collection.children["CH_AI_LineArt"].exclude = True   # 主组看不到蜡笔
vl_la.layer_collection.children["CH_AI_LineArt"].exclude = False    # 线稿组看得到
```

> **实测 V3/V4**：这样得到的 Combined 与现状帧 A **逐像素一致**（max|Δ| = 0.000000）——
> 集合排除确实把蜡笔从合并结果里摘干净了，帧 C 不再需要独立渲染。

### 3.2 通行证开关

```python
# VL_Main —— 按勾选开
vl_main.use_pass_combined | use_pass_z | use_pass_normal |
use_pass_diffuse_color | use_pass_ambient_occlusion
vl_main.eevee.ambient_occlusion_distance = ao_distance
vl_main.use_pass_cryptomatte_object  / _material / _asset   # 择一
vl_main.use_pass_cryptomatte_accurate = crypto_accurate

# VL_LineArt
vl_la.use_pass_grease_pencil = True
```

### 3.3 合成器

一个节点组，两个 `CompositorNodeRLayers`（各指向一个视图层）→ 各自的 File Output：

```
CompositorNodeRLayers(layer="VL_Main")     → combined / depth / normal / diffuse / ao / crypto{NN}
CompositorNodeRLayers(layer="VL_LineArt")  → edge
NodeGroupOutput ← VL_Main.Image            （树必需的输出接口）
```

**只渲一组时**，节点组里只建该组的 RLayers——配合 §3.5 的 `layer=` 参数即可只渲单层。

### 3.4 渲染组与键

```python
GROUP_MAIN = "main"
GROUP_LINEART = "lineart"

def main_key(...):
    return (frozenset(main_channels),         # 本次需要的 M 组通道
            ao_distance,
            cryptomatte_source,               # OBJECT / MATERIAL / ASSET（本批恒为 OBJECT）
            cryptomatte_accurate,
            crypto_slots,                     # 写几层 cryptomatte（1–3）
            (cap_w, cap_h), cam.name, tuple(cam.matrix_world))

def lineart_key(...):
    return (edge_width_scale, material_borders, lineart_options,
            (cap_w, cap_h), cam.name, tuple(cam.matrix_world))
```

> **解码参数不入键**：`depth_range` / `depth_curve` / `normal_convention`
> 以及**分割的覆盖率处理方式**都只在解码期生效，改它们不触发任何渲染。

### 3.5 捕获流程

```
open()  建临时场景 + 视图层（+ 蜡笔，仅需 L 组时）
  ↓
判定 hit_M / hit_L   （各自的键 + 本次所需通道 ⊆ 该组已产出通道）
  ↓
├─ 两组都命中        → 纯解码，0 次渲染
├─ 仅一组未命中      → 只渲该组：build 单组节点组 + render(layer=<该组视图层>)
└─ 两组都未命中      → 一次渲染调用渲两个视图层
  ↓
解码（§3.6）→ 写缓存（按组）→ 提交
```

> **实测 V5**：`bpy.ops.render.render(layer="VL_Main")` 只写出 VL_Main 的文件，
> 另一个视图层的 File Output **不写**——这是「两组独立失效」得以成立的关键。

### 3.6 解码

| 通道 | 处理 |
| --- | --- |
| combined / diffuse / ao | 原始字节即最终字节（不变） |
| depth / normal | EXR 回读 + 映射（不变） |
| edge | PNG 回读 alpha → `1-alpha`（不变） |
| **segmentation** | **新**：Cryptomatte EXR 回读 → 哈希反查 → 着色 |

Cryptomatte 解码（**实测 V8 精确命中**）：

```python
# 1) 逐位复刻 Blender 的哈希（cryptomatte.cc:353 + BKE_cryptomatte.hh:79）
h = mm3_x86_32(object_name.encode("utf-8"), seed=0)   # 名字不带 "OB" 前缀（cryptomatte.cc:566）
fe = float_encoded(h)      # mantissa/exponent(clamp 1..254)/sign 按位重解释为 float32

# 2) 每层 EXR 装两个对象：R=hash1, G=coverage1, B=hash2, A=coverage2
for slot_file in crypto_files:
    arr = read_exr(slot_file)                 # 必须 32bit float，不可经任何有损环节
    for name, color in palette.items():
        fe = float_encoded(mm3(name))
        mask = (arr[..., 0] == fe) | (arr[..., 2] == fe)
        img[mask] = color
```

- 物体名从 `scene.objects` 取（`add_ID` 用的是 `id.name[2:]`，即**去掉两字符类型前缀的裸名**）
- 覆盖率在 G/A 通道：实测 318 个不同取值、1.85% 为中间值 → **可用于抗锯齿边缘**（V10）
- 物体多到一层装不下时按覆盖率取前 N 个（`crypto_slots` 控制写几层）

---

## 4. 参数穿透（**已实现 5 项** — 见 D7 / D8；其余候选一律不做）

### 4.1 分割依据（已实现）

`cryptomatte_source`（枚举，默认 OBJECT）：

| 标识 | 面板文案 | 含义 | 实现 |
| --- | --- | --- | --- |
| `OBJECT` | Object | 每个物体一个 ID（等价原实现） | `use_pass_cryptomatte_object` |
| `MATERIAL` | Material | 按材质分块（同材质物体同色） | `use_pass_cryptomatte_material` |
| `ASSET` | Asset | 按资产根（父级链顶端）分块 | `use_pass_cryptomatte_asset` |

> **归属**：**渲染参数**（决定开哪条 pass），进主组渲染键。不做成"免费切换"——
> 三条 pass 全开全写会让 cryptomatte EXR 的落盘量翻三倍。
> 名字表由 `_segmentation_names` 按依据给出：MATERIAL 取全部材质名、ASSET 沿父级链走到顶
> （与 `cryptomatte.cc:255` 同款算法），OBJECT 取场景物体名。
> **实测**：共用材质的两个立方体在 MATERIAL 档下合并同色（11248 + 6698 → 17446 像素）。

### 4.2 采样数（已实现）

`render_samples`（IntProperty，默认 16，范围 1–512）：落到临时场景的
`eevee.taa_render_samples`（原为硬编码常量 `_EEVEE_SAMPLES = 16`）。
它直接决定抗锯齿与噪点水平（合并结果 / 漫射 / AO 最敏感），**两组共享**同一档，
故进两组渲染键。面板位置：通道设置 box 内、与钳制开关同区（常驻）。

### 4.3 重叠层数（已实现）

`crypto_slots`（IntProperty，默认 3，范围 1–3）：Cryptomatte 落盘层数。
一层装两个对象槽位，故 N 层可解析每像素 2N 个重叠物体。面板仅在勾选语义分割时显示。

> **默认取 3（不是 1）的理由**：原实现（材质覆盖）对每像素重叠对象数**没有上限**，
> 层数不足会让重叠处**静默取到错误对象**——这是难察觉的正确性缺陷，而落盘量只是成本。
> 故默认保正确性，让在意临时 I/O 的用户自行下调（面板的体积估算会同步反映）。
> 这与 §8.2 当初"默认只写 1 层"的建议相反：那条建议的前提是**当时没有用户可调项**。

### 4.4 分割边缘抗锯齿（已实现，出厂关闭 = 锯齿）

`smooth_seg_edges`（BoolProperty，默认 **False**）：

| 档 | 边界行为 | 代价 |
| --- | --- | --- |
| 关（出厂） | 每像素取覆盖率最大对象的**纯色**，色块边界是台阶 | 无 |
| 开 | 按覆盖率把相邻对象色**加权平均**，边界平滑 | 出现不属于任何单个对象的过渡色 |

> **是解码参数，不进渲染键**：切换它只重解码。实测锯齿档 4 种唯一色 → 抗锯齿档 433 种，
> 来回切换 4 次**全部 0 次渲染**（约 55–67 ms）。
> 抗锯齿只按**已匹配对象**的覆盖率归一化：未匹配的覆盖率不当黑色混进来，
> 免得整幅被压暗。
> 源码原文用 `Antialias Edges` 而非 `Smooth Edges`——后者是系统词条
> （Operator 语境译"平滑边"），换原文以免词典与系统打架。

### 4.5 线稿预设（已实现，下拉）

`edge_preset`（EnumProperty，默认 Standard）：把 Lineart 修改器的七个线条类型开关打包成一个下拉。

| 档 | 线条类型 | 实测深色像素(320px 测试场景) |
| --- | --- | --- |
| **Standard**（出厂，= 修改器出厂状态） | 轮廓 + 折痕 + 边标记 + 孤立边 + 相交线 | 85 |
| Contour Only | 仅轮廓 | **7** |
| With Shading | Standard + 投影线 + 光源轮廓线 | 85 |
| Hard Surface | 轮廓 + 折痕 + 相交线（去孤立边与边标记） | 85 |

> **Standard 明写全部出厂默认值**，与改造前的行为**逐位一致**（旧实现根本不碰这些开关）。
> 出厂值实测：`use_contour` / `use_loose` / `use_crease` / `use_edge_mark` / `use_intersection`
> 为 True，`use_shadow` / `use_light_contour` 为 False。
> 属**渲染参数**、进线稿组渲染键：实测换档**只重渲线稿组**。
> 测试场景没有边标记也没有孤立边，故 Hard Surface 与 Standard 出图相同（这是场景性质，不是缺陷）；
> 断言只锁 Contour Only 严格更少这条稳定关系。

### 4.6 其余候选（**经作者定论：一律不做** — 见 D8）

下列候选曾按价值排序备查。作者已定论**后续梯队不做**，故本节只作**决策留档**（记录"评估过
且为何不做"），不再是待办清单。各参数归属栏保留，便于日后若要重启评估时不必重新调研。

**第二梯队（观感明显、成本低）— 不做**

| 参数 | 默认 | 影响 | 归属 |
| --- | --- | --- | --- |
| `cryptomatte_accurate` | False | 多层面片 / 透明材质的 ID 正确性 | 渲染(主组) |
| `use_fuzzy_intersections` 模糊相交 | False | 相交处线爆时平滑掉 | 渲染(线稿组) |
| `thickness` 线厚度 | — | 与 `radius` 不同的另一宽度维度 | 渲染(线稿组) |
| `use_back_face_culling` 背面剔除 | False | 减少穿透到物体背面的线 | 渲染(线稿组) |

**第三梯队（场景级取舍）— 不做**

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `film_transparent` | False（现强制） | 打开则 Combined 背景透明 —— AI 参考图通常要白/黑底，慎用 |
| 深度拾取分位锚点 | 2% / 98%（现硬编码） | 极端景深场景下 2% 可能仍被极值拉偏 |

**不建议穿透**（会污染用户的正常渲染，属 Blender 场景级设置）：
`eevee.use_raytracing` / `use_shadows` / `use_volumetric_shadows` / `render.filter_size`；
以及 Lineart 的顶点组、材质掩码、层级（`use_material_mask`、`level_start/end`、
`use_output_vertex_group_match_by_name`）——过于专业且极少使用。

> **系统词条口径**：`Object` / `Material` / `Asset` / `Samples` / `Standard` 均为 Blender
> 系统词条（实测 `i18n_check_terms` 分别译"物体/材质/资产/采样/标准"），故**词汇本体不入典**，
> 只入插件自撰的说明与属性名（D7+D8 两批共补 18 条，`i18n_sweep` 未覆盖 0）。

---

## 5. 逐文件改动

### 5.1 改动面（B1–B4 + D7/D8 参数 + D9 清理，合并后的最终状态）

| 文件 | 改动 |
| --- | --- |
| `utils/cryptomatte.py`（**新增**） | `mm3_x86_32` / `float_encoded` / `name_hash` / `encoded_name_hash` / `palette_color` / `decode_segmentation`（含 `antialias`）。纯函数，不 import bpy |
| `utils/render_passes.py` | 视图层分组、Cryptomatte 解码接入、**删除覆盖机制（D9）**、分组增量缓存、线稿预设、`render_samples`、体积估算跟随层数、缓存上限 |
| `utils/__init__.py` | 导出增删（`capture_render_key` / `store_raw_cache` / `recapture_from_raw` 撤出，`clear_raw_cache` 加入） |
| `props.py` / `items.py` / `ui/panels/ai_render.py` / `i18n/dictionary.py` | D7/D8 的 5 个新参数（分割依据、落盘层数、边缘抗锯齿、采样数、线稿预设）的 RNA、枚举项、面板行、词条 |
| `operators/ai_render.py` | 缓存查询下沉后 `execute` / `invoke` 两条路径统一；新参数透传；陈旧描述修正 |
| `tests/test_ch_ai_cryptomatte.py`（**新增**） | 哈希、编码、解码、抗锯齿的纯 Python 单测 |
| `.zcode/test_capture_passes.py` | 回归断言按新语义重写并扩写（见 §5.3） |
| `.zcode/fix_punctuation.py` | 扫描根补 `tests/`（原缺，测试文件逃过规则 9） |

### 5.2 `utils/render_passes.py` 细目

> **实施记录**：下表为**最终落地状态**（B1–B4 与 D9 清理之后）。
> B2 期有两处与初版设计出入，以此为准 ——
> ① `_enable_passes` **保留原名**、改为按组版本，而不是拆成两个函数；
> ② `_reset_color_management` 在 **B2 即删除**：「多视图层同批渲染」共用同一个场景，
> 而色彩管理是**场景级**设置，压中立档会连带把合并结果的用户色彩管理也压掉。
> 实测非合并通道本就靠 item 级 `save_as_render=False` 与色彩管理隔离，该重置纯属冗余（V13）。

| 改动 | 说明 | 状态 |
| --- | --- | --- |
| 删 `_reset_color_management` | 场景级设置，与同批渲染互斥；通道隔离已由 item 级标志保证 | B2 |
| 删 `GROUP_SEG` / `_make_seg_material` / `_make_black_world` / 视图层覆盖 | Cryptomatte 免覆盖后无用；回退期已过，全树残留引用 **0 处** | D9 |
| `_FRAME_*_OUTPUTS` → `GROUP_*_OUTPUTS` + `_group_entries` | 按组声明；主组按勾选过滤，勾选分割时追加 cryptomatte 各层 | B2 / B3 |
| 新增 `_ensure_view_layers` / `_move_to_lineart_collection` | 建视图层 + 集合排除 | B2 |
| `_enable_passes` 增 `group` / `crypto_source` 形参 | 各组只开自己需要的通道与 pass | B2 / B3 |
| `_build_capture_group` 改为多视图层入参 | 每组一个 RLayers，一次渲染全落盘 | B2 |
| `_render_frame` 增 `layer=` 形参 | 只渲单层（实测其它层的 File Output 不写） | B2 |
| `PassCaptureSession._pending` → `_batches` / `_pending`（下标） | 批 = 一次渲染调用 | B2 |
| `render_next_frame` → `_prepare_batch` + 按批渲染 | 视图层按批按需创建 | B2 |
| 新增 `_read_crypto_slot` / `_segmentation_names` / `_decode_segmentation` | 分割改由 Cryptomatte 解码 | B3 |
| 新增 `CRYPTO_SOURCE_*` / `_crypto_slots_used` / `EDGE_PRESETS` | 分割依据、落盘层数、线稿预设的参数化 | D7 / D8 |
| `capture_render_key` → `group_render_key(group, ...)` | 按组出键；主组含色彩管理与分割参数，线稿组含线宽、材质边界与预设 | B4 / D7 / D8 |
| `store_raw_cache` / `recapture_from_raw` → `store_group_cache` / `lookup_group_cache` / `_decode_collected` | 按组存取 + 逐组子集判定；缓存查询**下沉进会话** | B4 |
| `PassCaptureSession` 增 `has_pending` / `commit_cache` | 全部命中缓存时可免渲染直接提交 | B4 |
| 删 `close()` 里逐个清视图层覆盖的循环 | 已无覆盖可清 | D9 |
| `estimate_capture_bytes` 增 `crypto_slots` 形参 | 体积估算跟随落盘层数（原恒定按 3 层） | D7 补 |
| 新增 `_RAW_CACHE_MAX_BYTES` | 缓存原始字节总量上限，超限整体丢弃 | D7 补 |

### 5.3 测试

**`tests/test_ch_ai_cryptomatte.py`**（纯 Python，无需 bpy，**32 例**）
- `mm3_x86_32` 的实机黄金向量；`float_encoded` 的指数 clamp 边界、尾数与符号位、绝不产出 NaN/Inf
- 调色板的确定性、可区分性与明度下限
- `decode_segmentation` 的槽位映射、多层合并、覆盖率择优、未解析统计、错误分支
- **空槽判据**（`hash=0` 且 `coverage=1` 不得算作「有覆盖」）及其对照用例
- `antialias` 两种模式的差异与「只按已匹配覆盖率归一化」的口径

**`.zcode/test_capture_passes.py`**（Blender 后台，逐项断言）
- 一次渲染出两组（渲染次数 == 1）、落盘文件集含 cryptomatte 层、不写渲染静帧、零临时残留
- 通道格式与像素语义；视图层集合隔离（分割图不被线稿污染）
- 分割依据（按物体的主色块数 **>** 按材质）、落盘层数、边缘抗锯齿（色数更多且**切换不重渲**）
- 线稿预设（换档只重渲线稿组 + Contour Only 线条严格更少）
- 色彩管理隔离（主导对象色不随 view transform 变化；合并结果随其变化）
- 用户场景零残留（场景/世界/蜡笔/节点组/选择态/对象色）

---

## 6. 实施顺序

| 批 | 内容 | 验证 | 状态 |
| --- | --- | --- | --- |
| **B1** | 新增 `utils/cryptomatte.py` 纯函数 + 单测（**不动管线**） | `tests/test_ch_ai_cryptomatte.py` 全绿 | **已完成** |
| **B2** | 视图层机制；帧 A + 帧 B 合并为一次渲染（分割仍用材质覆盖） | Combined/分割与旧实现逐像素一致 | **已完成** |
| **B3** | 分割切到 Cryptomatte；覆盖机制移出调度 | 分割图可用；用户场景无残留 | **已完成** |
| **B4** | 缓存改为按组；未失效的组不再重渲 | 分组缓存行为逐项实测 | **已完成** |
| **D7** | 参数穿透 3 项（分割依据 / 落盘层数 / 采样数）+ 未解析占比提示 | 三项各自的可观测效果实测 | **已完成** |
| **D8** | 参数穿透 2 项（分割边缘抗锯齿 / 线稿预设）；其余梯队**不做** | 抗锯齿切换零渲染；换档只重渲线稿组 | **已完成** |
| **D9** | 删除回退路径 + 清理全部陈旧描述 | 全树残留引用 0 处；门禁与回归全绿 | **已完成** |

### B1 验证记录

- `tests/test_ch_ai_cryptomatte.py`：全绿（`mm3` 黄金向量 / 指数 clamp 边界 /
  调色板稳定性与可区分性 / 解码映射与错误分支；D7/D8 追加抗锯齿与空槽判据用例后共 **32 例**）
- 全仓单测 `unittest discover -s tests`：**75 例 OK**（起点 43 例）
- 黄金向量取自实机验证过的哈希（"Monkey"/"CubeA"/"CubeB"/"CubeC" 已与 Blender
  渲染像素精确命中），实现一旦漂移即报警

> B1 期间修正了一处设计缺陷：重叠像素原先按**遍历顺序**决定归属，现改为按
> **覆盖率最大者**胜出（新增 `test_higher_coverage_wins_regardless_of_slot`）。

### B2 验证记录

- `.zcode/test_capture_passes.py`：**RESULT: PASS**（含七通道键序 / 落盘文件齐全 /
  通道语义 / 色彩管理隔离 / 用户场景零残留 / 临时目录零残留）
- 回归结论：分割与「色彩管理隔离」两项断言全绿 —— 说明去掉场景级色彩管理重置后，
  `save_as_render=False` 的通道仍不随用户 view transform 变化（**V13**）

### B3 验证记录

- 分割改由 Cryptomatte 解码（`utils/cryptomatte.decode_segmentation`），落盘由
  「一张 segmentation.png」变为「3 层 `crypto_NN.exr`（32bit）」，最终 PNG 在解码期内存内合成
- `.zcode/test_capture_passes.py`：**RESULT: PASS**（对象色 / 背景纯黑 / 主色块 /
  用户场景零残留 全绿）
- **一处断言按语义收紧后重写**：原「分割通道不随 view transform 变化（maxΔ ≤ 3/255）」
  改为「主导对象色完全一致 + 翻转像素占比 ≤ 2%」。原因是实测发现 cryptomatte 的**边缘
  覆盖率在两次渲染间不可复现**——同一 view transform 连渲两次与 AgX-vs-Standard 的
  差异量级**相同**（ch1 约 3100 vs 2900 个像素），故属渲染抖动而非色彩管理泄漏。
  色彩管理若真泄漏改变的是**全局**配色，新断言仍能抓住。
- 剩余 3 个立方体的场景下唯一色数由材质覆盖时代的「≥6（含抗锯齿过渡色）」变为
  「4（3 对象 + 黑底）」—— 解码是**硬边**分配，不再有渲染抗锯齿产生的中间色，
  阈值随语义下调（主色块断言仍要求 ≥ 3）。

### B4 验证记录

`.zcode/tmp/probe_b4.py` 逐步只改一个量，逐项验证（渲染次数与参与渲染的视图层均可观测）：

| 场景 | 渲染次数 | 参与渲染的视图层 |
| --- | --- | --- |
| ① 冷启动 | **1**（原实现为 3） | VL_Main + VL_LineArt 同批 |
| ② 参数不变 | 0（31 ms，纯解码） | — |
| ③ 只改线宽 | 1 | **仅 VL_LineArt**（主组复用） |
| ⑤ 只改 AO 距离 | 1 | **仅 VL_Main**（线稿组复用） |
| ⑦ 取消 edge（子集命中） | **0** | — |
| ⑨ 只改深度范围（解码参数） | 0 | — |
| ⑩ 追加 normal | 1 | 仅 VL_Main（线稿组仍复用） |

> ⑦ 是两轮前识别的「子集检查被精确相等判定挡成死代码」的修复效果：旧实现里取消一个通道
> 会重渲整轮，现在真正走子集判定、一次都不渲。

#### B4 期间被测试抓出的一个真缺陷

把缓存查询下沉进会话后，`capture_camera_passes` 也开始吃缓存 —— 于是
「改 view transform 再捕获」命中了缓存，**合并结果不再跟着变**。
根因是主组渲染键漏了色彩管理项。已修：`_color_management_key` 纳入主组键
（只有合并结果通道遵循用户色彩管理，故只进主组，不进线稿组）。

> 这个缺陷在旧实现里被掩盖了：旧 `capture_camera_passes` **从不查缓存**（只在末尾写缓存），
> 只有 `invoke` 走缓存路径。缓存下沉后两条路径行为一致，缺陷才暴露出来 ——
> 也说明**两条路径行为不一致本身就是风险**。

### 门禁说明（本机环境）

`python .zcode/gate.py --quick` 在本机会报 **ruff 一项 FAIL**，原因是当前会话使用的
解释器（DSH 运行时 Python）未安装 `ruff` 模块；其余 5 项全 PASS。
已用 PATH 上的 `ruff` 二进制按门禁**相同参数与范围**复跑：**All checks passed**。
若要门禁该步转绿，需把 `ruff` 装进运行 gate 的那个解释器。

每批收尾跑 `python .zcode/gate.py`；**涉及 RNA 属性改动必须走全量档**
（`--quick` 不含 `verify_blender_load`，注册期错误只在真实 Blender 暴露）。
本批（B1–B4）按 D5 不新增 RNA 属性，故 `--quick` 档足够。

---

## 7. 已验证的前提（本方案的全部事实依据）

| 编号 | 结论 | 证据 |
| --- | --- | --- |
| V1 | `CompositorNodeRLayers.layer` 存在（ENUM），可指视图层 | 探针 |
| V2 | 一次渲染写出多个视图层的 File Output | `combined.jpg` + `segmentation.png` 同时产出 |
| V3 | 视图层集合排除让 Combined 不被线稿污染 | max\|Δ\| = 0.000000 vs 现状帧 A |
| V4 | 帧 C 并入后线稿与现状一致 | 1-alpha 后 max\|Δ\| = 0.000000，笔画像素 23936 vs 23936 |
| V5 | `render.render(layer=...)` 可只渲单层 | 指定后 `edge.png` **未**写出 |
| V6 | Cryptomatte pass 存在（object/material/asset） | 三条开关均 True，RLayers 暴露 Crypto\*00-02 |
| V7 | Cryptomatte 单层 EXR 可落盘并可回读 | 16.18 B/像素 = 4 通道 × 4B |
| V8 | **解码可精确复现** | 复刻 `mm3`+`float_encoded` 后与像素精确命中 |
| V9 | Cryptomatte 零覆盖下 ID 正确，且**不扰动其它通道** | 4 物体命中；combined/depth max\|Δ\| = 0 |
| V10 | 覆盖率可用于抗锯齿 | G 通道 318 个取值、1.85% 中间值 |
| V11 | `ConvertToDisplay`/`ConvertColorSpace` **不是** `save_as_render` 的等价替代 | 三组对照差 39/255 与 81/255 → **不采用想法2（D4）** |
| V12 | 无 `cryptomatte_levels` 属性 | 层数固定 3；写几层由建几个 File Output 决定 |
| V14 | `view_transform` / `look` / `exposure` / `gamma` 必须进**主组**渲染键 | B4 把缓存查询下沉进会话后，「改 view transform 再捕获」曾命中缓存、合并结果不跟着变；`test_capture_passes` 的「合并结果随 view transform 变化」断言抓出。旧实现因 `capture_camera_passes` 从不查缓存而掩盖了该缺陷 |
| V13 | `save_as_render=False` 的通道**无需**场景级色彩管理重置即与 CM 隔离 | B2 删掉 `_reset_color_management` 后，`test_capture_passes.py` 的「diffuse/ao/segmentation 不随 view transform 变化」三项断言仍全绿（maxΔ = 0.0/255） |

---

## 8. 收益与成本

### 8.1 收益（实机实测，1024²）

| 项 | 现状 | 改造后 | 依据 |
| --- | --- | --- | --- |
| 渲染调用 | 3 帧 | **1 次** | 两个视图层在同一次调用里各自落盘（B4 实测） |
| 帧 B（分割）成本 | 316 ms | 0（并入主组，crypto 增量 76 ms） | 实测 |
| 分割依据 | 无此能力 | 物体/材质/资产（三档均可选，出厂按材质） | 三条 pass 均存在，解码精确命中 |
| 材质/世界覆盖 | 建材质 + 黑世界 + 来回切换 | **已整体删除**（D9；零覆盖下 ID 正确，实测） | — |
| 整场色彩管理重置 | 帧 B/C 需要 | 不再需要 | 帧 B 消失；B2 实测通道仍隔离 |
| 缓存失效粒度 | 一把键管三帧 | **两组各自失效 + 子集判定** | B4 逐项实测（见下） |
| 改线宽 | 三帧全重渲 | **仅渲线稿组** | B4 ⑤③ |
| 改 AO 距离 | 三帧全重渲 | **仅渲主组** | B4 ⑤ |
| 取消一个通道 | 三帧全重渲 | **0 次渲染** | B4 ⑦ |
| 改解码参数 | 0 次渲染 | 0 次渲染（不变） | B4 ⑨ |
| 输出内容 | — | **完全一致** | combined/diffuse/ao max\|Δ\|=0；edge 完全一致 |
| 端到端（含解码，公平口径） | 972 ms | ≈803 ms | **省约 17%** |

> **⚠ 必须说明的测量陷阱**：若只比「渲染+落盘」不算解码，会得到 2252 → 557 ms（省 75%）——
> 那是拿现状的「三帧渲染+全部解码」比新路径的「一次渲染+仅落盘」，口径不对等。
> **诚实的数字是约 17%。**

### 8.2 成本

| 项 | 量级 | 说明与缓解 |
| --- | --- | --- |
| **Cryptomatte EXR I/O** | 每层 16.8 MB @1024²、67 MB @2048² | 32bit float × RGBA。**出厂写满 3 层**（可解析 6 个重叠物体/像素）；`crypto_slots` 可降到 1–2 换更少的临时写盘。增量缓存另有 512 MB 上限 |
| 解码复杂度 | 新增约 60 行纯函数 | 需逐位复刻 `mm3` + `float_encoded`，已写出可用实现并验证命中 |
| 耦合 Blender 内部实现 | 哈希算法 | Cryptomatte 规范稳定；需固化回归测试锁住 |
| **取消颗粒度** | 3 帧 → **1 批** | 两组默认合成**一次**渲染调用，故一次捕获通常只有 1 个批间取消点（单次渲染本身同步阻塞）。要更多取消点可把两组拆回两批，代价是多一次渲染调用 |
| 覆盖率边缘处理 | 解码期新增 | 已实现为 `smooth_seg_edges`（出厂关 = 硬边）：实测锯齿档 4 色 → 抗锯齿档 433 色，切换**零渲染** |
| 迁移面 | 3 个源文件 + 2 个测试 | 中等规模；核心逻辑集中在 `render_passes.py` |

**I/O 权衡算例（2048²）**

| 方案 | 临时写盘 | 对比 |
| --- | --- | --- |
| 现状（depth EXR + normal EXR + seg PNG） | 67 MB + 0.5 MB ≈ 68 MB | 基准 |
| 改造后（+ 1 层 crypto） | 68 + 67 = 135 MB | +67 MB ≈ +100–200 ms I/O |
| 改造后（+ 3 层 crypto） | 68 + 201 = 269 MB | +201 MB ≈ +300–600 ms I/O |

> 帧 B 在 2048² 下省的渲染约 1.2 s，因此**即使写 3 层仍然净赚**（出厂即 3 层）；
> 若临时盘空间紧张，把 `crypto_slots` 降到 1 层可把增量压回 +67 MB。

### 8.3 净判断

**时间收益约 17%（1024²）**，但真正的价值是三件结构性的事：

1. **移除了一整套机制**：材质覆盖 + 黑世界 + 覆盖来回切换 + 整场色彩管理重置
   （含它们各自的坑：`use_nodes` 默认 True 让 `world.color` 失效、`save_as_render`
   必须写 item 级等）
2. **分割能力从 1 种变 3 种**（物体/材质/资产），并可按覆盖率做抗锯齿边缘
   （`smooth_seg_edges`，属解码参数、切换零渲染）
3. **缓存粒度与渲染边界对齐**：修掉了此前「改一处参数就重渲三帧」的浪费
   （改线宽只重渲 L 组、改 AO 距离只重渲 M 组、取消通道走子集判定不重渲）

---

## 9. 风险与回退

| 风险 | 影响 | 处置 |
| --- | --- | --- |
| 重叠物体 > 2N 个/像素 | 超出层数的对象并入覆盖率更高者 | `crypto_slots` 可加到 3（出厂即 3）；解码期算出的**未解析占比**超 1% 即写提示（已实现） |
| 物体没有材质（出厂按材质分割） | 这些像素保持黑色 | 未解析占比提示会报出来，不会静默通过；改用「按物体」档即可 |
| Blender 改动哈希实现 | 解码全部失效 | `tests/test_ch_ai_cryptomatte.py` 的黄金向量锁住（取自实机渲染像素精确命中） |
| 2048² + 3 层 crypto 的 I/O | 临时写盘 ~280 MB | 面板体积估算已跟随 `crypto_slots`；增量缓存有 512 MB 上限，超限整体丢弃 |
| 视图层集合排除与他人脚本冲突 | 极少见 | 全部操作都在临时场景内，用户场景零改动 |
| **取消颗粒度下降** | 一次捕获通常只有**一批**，可中断点变少（单次渲染本身同步阻塞） | 这是「两组一次渲完」换来的必然代价；Esc / 终止按钮在批间生效。若此体验不可接受，可把两组拆回两批（各成一个取消点），代价是多一次渲染调用 |
| cryptomatte 边缘覆盖率不可复现 | 边界约 4% 像素归属会翻转 | 对象色与背景不受影响；测试按「主导色一致 + 翻转占比 ≤ 2%」断言 |

**回退策略**：本轮改造落在**单个提交**（`5db671d`），故代码级回退是整批的。
B3 期间暂留的覆盖材质回退路径已按 **D9 删除**——暂留的前提是"新方案还没经过独立实测"，
而 B4 之后又走了一轮实测与全量门禁，该前提已消失。真要只回退分割方案：
解码实现集中在 `utils/cryptomatte.py` 一个纯函数模块，重建面很小（本方案 §3.6 即其规格）。
