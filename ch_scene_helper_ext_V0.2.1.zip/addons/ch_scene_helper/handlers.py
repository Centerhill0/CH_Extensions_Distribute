"""
实时同步处理器模块

提供以下功能:
- depsgraph_update_post / load_post 处理器: 场景资源列表实时刷新与 3D 视图选中同步
- refresh_lists: 公开的"立即重建快照"入口(供不触发 depsgraph 的算子主动调用)
- 列表活跃索引 update 回调: 用户点击列表行时反向选中场景物体
- 周期计时器: 兜底刷新
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接
- 快照重建与重入护栏机制见 common.blender.list_snapshot

注: 材质侧回写对"无使用者材质"让位(见 _material_sync_blocked), 否则点击 0 用户材质行
后活跃索引会被活动物体的活动材质立刻覆盖, 表现为该行无法高亮(2026-10-17 作者实测修复).
"""

import bpy
from bpy.types import Context

from ...common.blender.list_snapshot import is_syncing, rebuild_if_changed, set_index
from .utils import collect_cameras, collect_lights, collect_scene_materials, select_material_users

# 列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0


def _select_object_by_name(context: Context, name: str) -> bool:
    """取消现有选择, 选中并激活指定物体; 物体不存在时返回 False

    先设活动物体再改选中: 后台实测 active 为 None 时 select_set(True) 静默失效
    (同 utils.select_material_users 注; GUI 常规有活动物体不受影响).
    """
    obj = context.scene.objects.get(name)
    if obj is None:
        return False
    context.view_layer.objects.active = obj
    for sel_obj in list(context.selected_objects):
        if sel_obj.name != obj.name:
            sel_obj.select_set(False)
    obj.select_set(True)
    return True


# ------------------------------------------------------------
# 列表点击 -> 场景选中(update 回调, 由 props.py 的活跃索引属性挂接)
# ------------------------------------------------------------


def _index_update_blocked(state, coll_name: str, index_name: str, sync_name: str) -> bool:
    """列表点击回调的统一闸门: 快照重建中 / 活跃索引越界 / 该列表的双向选中同步关闭"""
    if is_syncing():
        return True
    if getattr(state, index_name) >= len(getattr(state, coll_name)):
        return True
    return not getattr(bpy.context.window_manager.ch_scene_lists_ui, sync_name)


def on_lights_index_update(self, context: Context):
    """灯光列表活跃索引回调: 用户点击行时选中对应物体(灯或自发光材质物体)"""
    if _index_update_blocked(self, "lights", "lights_active_index", "lights_sync"):
        return
    _select_object_by_name(context, self.lights[self.lights_active_index].src_name)


def on_cameras_index_update(self, context: Context):
    """相机列表活跃索引回调: 用户点击行时选中对应物体"""
    if _index_update_blocked(self, "cameras", "cameras_active_index", "cameras_sync"):
        return
    _select_object_by_name(context, self.cameras[self.cameras_active_index].src_name)


def on_materials_index_update(self, context: Context):
    """材质列表活跃索引回调: 点击行时选中全部使用者物体(算法下沉 utils.select_material_users)

    0 用户材质(孤儿/仅假用户)没有使用者可选, 场景选中不变 —— 若仍让 _sync_selection
    把"活动物体的活动材质"回写本索引, 用户刚点的那一行会被立刻改回去(表现为 0 用户材质
    行无法高亮, 2026-10-17 作者实测). 材质侧回写故须让位于"当前活跃项本身就是无使用者
    材质"的情形, 判据见 _material_sync_blocked.
    """
    if _index_update_blocked(self, "materials", "materials_active_index", "materials_sync"):
        return
    mat = bpy.data.materials.get(self.materials[self.materials_active_index].src_name)
    if mat is not None:
        select_material_users(context, mat)


def on_zero_user_materials_update(self, context: Context):
    """ "显示 0 用户材质"开关回调: 立即重建材质快照(开关只改收集范围, 不触发 depsgraph)"""
    refresh_lists()


# ------------------------------------------------------------
# 场景 -> 列表同步
# ------------------------------------------------------------


def _sync_index_to_name(state, coll_name: str, index_name: str, name: str):
    """列表快照中存在同名条目时把活跃索引指向它(护栏内写入)"""
    col = getattr(state, coll_name)
    for idx, item in enumerate(col):
        if item.name == name:
            if getattr(state, index_name) != idx:
                set_index(state, index_name, idx)
            return


def _material_sync_blocked(state) -> bool:
    """材质侧回写是否应让位: 当前活跃项是否为"无使用者材质"

    点击 0 用户材质(孤儿/仅假用户)行时, select_material_users 无可选物体, 场景选中不变;
    此时若仍按"活动物体的活动材质"回写活跃索引, 刚点亮的行会被立刻覆盖 -> 表现为该行
    无法高亮(2026-10-17 作者实测). 判据取"活跃项材质当前确无使用者"这一稳定事实
    (而非一次性标记): 只要用户停在这样一行上, 就不该把索引挪走; 一旦用户另选了他行
    (该行材质有使用者)或场景里该材质有了使用者, 回写自然恢复.

    Args:
        state: 材质列表快照状态组(SceneListsState)

    Returns:
        True 表示本轮跳过材质侧回写
    """
    idx = state.materials_active_index
    if not 0 <= idx < len(state.materials):
        return False
    mat = bpy.data.materials.get(state.materials[idx].src_name)
    if mat is None:
        return False
    return not any(slot.material is mat for obj in bpy.context.scene.objects for slot in obj.material_slots)


def _sync_selection(state):
    """把活动物体/活动材质同步到对应列表的活跃索引

    灯光列表含自发光材质物体, 按活动物体名直接匹配(不在列表则无操作).
    各列表的双向选中同步开关关闭时跳过(场景选中不回写该列表).
    材质侧另受 _material_sync_blocked 约束(0 用户材质行的高亮保护).
    """
    ui_state = bpy.context.window_manager.ch_scene_lists_ui
    act_obj = bpy.context.view_layer.objects.active
    if act_obj is None:
        return
    if ui_state.lights_sync:
        _sync_index_to_name(state, "lights", "lights_active_index", act_obj.name)
    if ui_state.cameras_sync:
        _sync_index_to_name(state, "cameras", "cameras_active_index", act_obj.name)
    if ui_state.materials_sync and not _material_sync_blocked(state) and act_obj.active_material is not None:
        _sync_index_to_name(state, "materials", "materials_active_index", act_obj.active_material.name)


def _sync_all():
    """全量同步: 有变化才重建三个列表快照, 然后做选中同步"""
    state = bpy.context.window_manager.ch_scene_lists
    scene = bpy.context.scene
    # 材质列表是否纳入 0 用户材质由按钮列开关决定(默认只列在用材质)
    include_zero_user = bpy.context.window_manager.ch_scene_lists_ui.show_zero_user_materials
    rebuild_if_changed(state, "lights", "lights_active_index", 'OBJECT', collect_lights(scene)[0])
    rebuild_if_changed(state, "cameras", "cameras_active_index", 'OBJECT', collect_cameras(scene)[0])
    rebuild_if_changed(state, "materials", "materials_active_index", 'MATERIAL', collect_scene_materials(scene, include_zero_user)[0])
    _sync_selection(state)


def _sync_all_safe() -> None:
    """全量同步, 吞掉"插件注销窗口期 WM 属性已摘除"类异常(各入口共用)"""
    try:
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _on_depsgraph_update(*_args):
    """depsgraph 更新回调: 场景/选中变化时实时刷新"""
    _sync_all_safe()


def _on_load_post(*_args):
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐新场景"""
    _sync_all_safe()


def refresh_lists() -> None:
    """立即重建列表快照并同步选中

    供"写自定义属性(不触发 depsgraph, 5.1.2 实测)"的算子主动调用, 如列表排序值写入.
    """
    _sync_all_safe()


def _sync_timer():
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register():
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister():
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
