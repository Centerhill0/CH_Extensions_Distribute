import bpy

from .config import __addon_name__
from .i18n.dictionary import dictionary
from ...common.class_loader import auto_load
from ...common.class_loader.auto_load import add_properties, remove_properties
from ...common.i18n.dictionary import common_dictionary
from ...common.i18n.i18n import load_dictionary
from .props import SceneListsState, SceneListsUIState
from .keymaps import register_keymaps, unregister_keymaps

# You may declare properties like following, framework will automatically add and remove them.
# Do not define your own property group class in the __init__.py file. Define it in a separate file and import it here.
# 注意不要在__init__.py文件中自定义PropertyGroup类.请在单独的文件中定义它们并在此处导入.
_addon_properties = {
    # WM 级场景资源列表快照(灯光/相机/材质), 不随 .blend 保存
    bpy.types.WindowManager: {
        "ch_scene_lists": bpy.props.PointerProperty(type=SceneListsState),
        # WM 级场景资源列表设置区子面板展开状态(纯 UI 状态), 不随 .blend 保存
        "ch_scene_lists_ui": bpy.props.PointerProperty(type=SceneListsUIState),
    },
}


def register():
    """
    注册插件
    """
    # Register classes
    auto_load.init()
    auto_load.register()

    register_keymaps()

    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(__addon_name__))


def unregister():
    """
    注销插件
    """
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)
    # unRegister classes
    auto_load.unregister()

    unregister_keymaps()

    remove_properties(_addon_properties)
    print("{} addon is uninstalled.".format(__addon_name__))
