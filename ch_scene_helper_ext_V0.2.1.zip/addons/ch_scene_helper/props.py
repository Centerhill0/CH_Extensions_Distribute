"""
场景资源列表状态模块

提供以下功能:
- WM 级 UI 状态属性组: 三个列表各自的"双向选中同步"开关 + 设置区子面板展开态
  + 材质列表的"显示 0 用户材质"开关
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot

注: 双向选中同步开关自偏好设置迁入列表按钮列(2026-10-17 作者定), 三个列表各持一份,
互不影响; 状态为 WM 级纯 UI 状态, 不随 .blend 保存.
"""

from bpy.props import BoolProperty, CollectionProperty, IntProperty
from bpy.types import PropertyGroup

from ...common.blender.list_snapshot import ListItem
from .handlers import on_cameras_index_update, on_lights_index_update, on_materials_index_update, on_zero_user_materials_update


class SceneListsState(PropertyGroup):
    """场景资源的列表快照及各项活跃索引(索引 update 回调联动选中场景物体)"""

    lights: CollectionProperty(type=ListItem)  # type: ignore
    lights_active_index: IntProperty(default=0, update=on_lights_index_update)  # type: ignore
    cameras: CollectionProperty(type=ListItem)  # type: ignore
    cameras_active_index: IntProperty(default=0, update=on_cameras_index_update)  # type: ignore
    materials: CollectionProperty(type=ListItem)  # type: ignore
    materials_active_index: IntProperty(default=0, update=on_materials_index_update)  # type: ignore


class SceneListsUIState(PropertyGroup):
    """场景资源列表的按钮列开关与设置区展开状态(WM 级纯 UI 状态, 不随 .blend 保存)

    - 三个同步开关: 各自控制该列表的活跃索引与 3D 视图选中是否双向联动
      (关闭后列表仍实时快照, 仅不做选中联动)
    - show_zero_user_materials: 材质列表是否把 0 用户材质(孤儿/仅假用户)也纳入快照
    - 每面板一个设置子面板; 展开态无名称/描述: 绘制时 text="" 只显示三角箭头
      (见 ui/panels/scene_lists.py)
    """

    lights_sync: BoolProperty(name="Sync Selection", default=True, description="Sync the Lights list active index with the 3D view selection")  # type: ignore
    cameras_sync: BoolProperty(name="Sync Selection", default=True, description="Sync the Cameras list active index with the 3D view selection")  # type: ignore
    materials_sync: BoolProperty(name="Sync Selection", default=True, description="Sync the Materials list active index with the 3D view selection")  # type: ignore
    show_zero_user_materials: BoolProperty(name="Show Zero User Materials", default=False, update=on_zero_user_materials_update, description="Also list materials that have no users (orphans and fake-user only)")  # type: ignore
    show_light_settings: BoolProperty(default=True)  # type: ignore
    show_camera_settings: BoolProperty(default=True)  # type: ignore
