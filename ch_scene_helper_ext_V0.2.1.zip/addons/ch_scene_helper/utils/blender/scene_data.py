"""
场景数据收集工具模块

收集场景中的灯光(含自发光材质物体)/相机/材质名称供列表快照使用;
收集结果按列表顺序值排序(顺序值挂数据块自定义属性, 见 utils.blender.list_order):
有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序).

主要功能:
- collect_lights: 灯光物体与自发光材质物体名枚举(统一按顺序值排序, 不再分簇)
- collect_cameras: 相机物体名枚举
- collect_scene_materials: 材质名枚举(默认只收场景实际使用的, 可选纳入 0 用户材质)
"""

import bpy
from bpy.types import Material, Scene

from .list_order import order_key


def _has_emission(mat: Material) -> bool:
    """材质是否自发光: 存在 Emission 节点, 或 Principled 的 Emission Strength 大于 0/被驱动"""
    if mat is None or not mat.use_nodes or mat.node_tree is None:
        return False
    for node in mat.node_tree.nodes:
        if node.type == 'EMISSION':
            return True
        if node.type == 'BSDF_PRINCIPLED':
            inlet = node.inputs.get('Emission Strength')
            if inlet is not None and (inlet.default_value > 0.0 or inlet.is_linked):
                return True
    return False


def collect_lights(scene: Scene) -> tuple:
    """收集场景中的发光项: 灯光物体 + 使用自发光材质的物体(去重), 按列表顺序值排序, 返回 (名称列表, 错误信息)"""
    blocks = []
    seen = set()
    for obj in scene.objects:
        if obj.name in seen:
            continue
        if obj.type == 'LIGHT' or any(_has_emission(slot.material) for slot in obj.material_slots):
            seen.add(obj.name)
            blocks.append(obj)
    blocks.sort(key=order_key)
    return [obj.name for obj in blocks], None


def collect_cameras(scene: Scene) -> tuple:
    """收集场景中的相机物体名, 按列表顺序值排序, 返回 (名称列表, 错误信息)"""
    blocks = [obj for obj in scene.objects if obj.type == 'CAMERA']
    blocks.sort(key=order_key)
    return [obj.name for obj in blocks], None


def collect_scene_materials(scene: Scene, include_zero_user: bool = False) -> tuple:
    """收集材质名并按列表顺序值排序, 返回 (名称列表, 错误信息)

    默认只收集当前场景物体材质槽里实际使用的材质(按首次出现去重, 排除空槽).
    include_zero_user 为真时改为收集 bpy.data.materials 全量材质数据块,
    即把 0 用户材质(从未赋给任何物体, 含仅假用户的孤儿)也纳入列表.

    Args:
        scene: 目标场景
        include_zero_user: 是否把 0 用户材质也纳入列表

    Returns:
        (材质名称列表, 错误信息或 None)
    """
    if include_zero_user:
        blocks = list(bpy.data.materials)
    else:
        blocks = []
        seen = set()
        for obj in scene.objects:
            for slot in obj.material_slots:
                mat = slot.material
                if mat is None or mat.name in seen:
                    continue
                seen.add(mat.name)
                blocks.append(mat)
    blocks.sort(key=order_key)
    return [mat.name for mat in blocks], None
