"""
场景资源面板材质动作算法模块

提供以下功能:
- duplicate_material: 复制材质数据块
- delete_material: 删除材质数据块
- unlink_material: 解除材质与场景物体的全部材质槽关联(不删除数据块)
- select_material_users: 选中材质的全部使用者物体

注: 跨插件共用的 assign_material 与 MATERIAL_SLOT_TYPES 见 common/blender/material.py
(材质拾取器 ASSIGN 与本插件材质面板 Assign to Selected 为真实双消费者).
"""

import bpy
from bpy.types import Context, Material, Scene


def duplicate_material(mat: Material) -> Material | None:
    """复制材质数据块(含节点树), 继承假用户设置; 入参无效返回 None

    副本不与任何物体关联(用户数为 0), 由调用方决定是否再赋给物体.

    Args:
        mat: 待复制材质

    Returns:
        新材质副本, 入参无效时返回 None
    """
    if mat is None:
        return None
    new_mat = mat.copy()
    new_mat.use_fake_user = mat.use_fake_user
    return new_mat


def delete_material(mat: Material) -> tuple:
    """删除材质数据块(在用材质由 Blender 自动清空其材质槽, 可 UNDO 恢复), 返回 (是否成功, 错误信息)

    Args:
        mat: 待删除材质

    Returns:
        (是否成功, 错误信息或 None)
    """
    if mat is None:
        return False, "material is None"
    bpy.data.materials.remove(mat)
    return True, None


def unlink_material(scene: Scene, mat: Material) -> tuple:
    """解除材质与场景物体材质槽的全部关联(不删除材质数据块), 返回 (清空的槽数, 错误信息)

    只清空槽里的材质引用, 槽位本身保留(与 Blender 属性编辑器"取消关联"一致).
    清空后材质可能变为 0 用户, 由调用方决定是否进一步删除.

    Args:
        scene: 目标场景
        mat: 待解除关联的材质

    Returns:
        (清空的槽数, 错误信息或 None)
    """
    if mat is None:
        return 0, "material is None"
    count = 0
    for obj in scene.objects:
        for slot in obj.material_slots:
            if slot.material == mat:
                slot.material = None
                count += 1
    return count, None


def select_material_users(context: Context, mat: Material) -> bool:
    """选中材质的全部使用者物体, 首个使用者设为活动物体并定位到该材质槽; 失败返回 False

    由 ch_utils_tools/handlers.py 原值下沉(算法与交互分离), 行为不变.

    Args:
        context: Blender 上下文
        mat: 目标材质

    Returns:
        是否找到并选中了使用者物体
    """
    if mat is None:
        return False
    user_objs = [obj for obj in context.scene.objects if any(slot.material == mat for slot in obj.material_slots)]
    if not user_objs:
        return False
    user_names = {obj.name for obj in user_objs}
    first_obj = user_objs[0]
    # 先设活动物体再遍历选中: 后台实测 active 为 None 时 select_set(True) 静默失效
    # (5.1.2 探针: 冷启动直接选 -> 选中落空; 先设 active -> 正常; GUI 常规有活动物体不受影响)
    # 必须遍历列表副本: 迭代 view_layer.objects 活集合的同时 select_set 会令迭代器失效
    # 用名称做成员判定, 规避不同获取路径的包装器身份问题;
    # 场景中被排除集合的物体没有 base, 不出现在 view_layer.objects 中, 天然不会被误选
    context.view_layer.objects.active = first_obj
    for obj in list(context.view_layer.objects):
        if obj is None:
            continue
        obj.select_set(obj.name in user_names)
    for idx, slot in enumerate(first_obj.material_slots):
        if slot.material == mat:
            first_obj.active_material_index = idx
            break
    return True
