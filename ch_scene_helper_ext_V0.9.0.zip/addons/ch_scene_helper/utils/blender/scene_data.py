"""
场景数据收集工具模块

收集场景中的灯光/相机/材质/图像/世界环境名称供列表快照使用;
收集结果按列表顺序值排序(顺序值挂数据块自定义属性, 算法见 common.blender.list_order):
有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序).
相机/灯光/灯光集合三个列表按**视图层**收集: 被排除(exclude)的集合内的物体与集合本身不列.

主要功能:
- collect_scene_material_blocks: 场景物体材质槽里实际使用的材质块(去重, 顺序稳定)
- collect_lights: 灯光物体名枚举(视图层内)
- collect_cameras: 相机物体名枚举(视图层内)
- visible_objects: 视图层内未被排除集合中的物体(相机/灯光列表的共同口径)
- collect_scene_materials: 材质名枚举(默认只收场景实际使用的, 可选纳入 0 用户材质; 可选排除库链接)
- collect_images: 图像名枚举(默认只收有使用者的, 可选纳入 0 用户/排除库链接;
  运行期图像始终在列并钉前两位)
- collect_light_collections: CLS_ 前缀集合名枚举(灯光集合管理列表, 视图层内)
- collect_worlds: 世界环境名枚举(可选纳入 0 用户/排除库链接)
- visible_collection_names: 视图层内未被排除的集合名(集合列表与隔离兄弟判定的统一口径)
- collect_stray_lights: 视图层内位于全部灯光集合之外的灯光物体(灯光整理算子用)
- create_light_collection: 新建编号灯光集合(CLS_NN_)并挂到 Lights 下
- ensure_scene_collection: 取/建场景集合根下的同名子集合(可带颜色标)
- collect_visible_cameras: 视图层内的全部相机物体(相机整理算子用)
- move_objects_to_collection: 把物体真移动(解除原挂载)到目标集合
"""

import re

import bpy
from bpy.types import Scene

from .....common.blender.list_order import order_key


def collect_scene_material_blocks(scene: Scene) -> list:
    """收集场景物体材质槽里实际使用的材质块(按首次出现去重, 排除空槽)"""
    seen = set()
    blocks = []
    for obj in scene.objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or mat.name in seen:
                continue
            seen.add(mat.name)
            blocks.append(mat)
    return blocks


def _sorted_names(blocks: list) -> list:
    """按列表顺序值排序并取名称"""
    return [block.name for block in _sorted_blocks(blocks)]


def _sorted_blocks(blocks: list) -> list:
    """按列表顺序值排序数据块(块级收集函数的公共收口, 供快照逐块携带库链接标记)"""
    return sorted(blocks, key=order_key)


def visible_objects(scene: Scene, view_layer) -> list:
    """场景内位于视图层**未被排除集合**中的物体

    按集合归属判定而非遍历 view_layer.objects: 后者是视图层求值结果, 新建物体或刚切
    排除标记后要等下一帧才齐, 而列表重建常发生在同一次操作里(实测后台立即读为空).
    """
    visible = visible_collection_names(view_layer.layer_collection)
    return [obj for obj in scene.objects if any(coll.name in visible for coll in obj.users_collection)]


def collect_camera_blocks(scene: Scene, view_layer) -> list:
    """收集视图层内的相机物体数据块(相机列表快照的单一来源, collect_cameras 是其名称视图)

    被排除集合内的相机不列; 本地与链接物体允许同名(复制链接物体即产生), 故返回数据块.
    """
    return _sorted_blocks([obj for obj in visible_objects(scene, view_layer) if obj.type == 'CAMERA'])


def collect_cameras(scene: Scene, view_layer) -> list:
    """收集视图层内的相机物体名, 按列表顺序值排序(collect_camera_blocks 的名称视图)"""
    return [obj.name for obj in collect_camera_blocks(scene, view_layer)]


def collect_light_blocks(scene: Scene, view_layer) -> list:
    """收集视图层内的灯光物体数据块(灯光列表快照的单一来源, collect_lights 是其名称视图)

    口径同 collect_camera_blocks: 被排除集合内的灯光不列; 本地与链接物体允许同名, 故返回数据块.
    """
    return _sorted_blocks([obj for obj in visible_objects(scene, view_layer) if obj.type == 'LIGHT'])


def collect_lights(scene: Scene, view_layer) -> list:
    """收集视图层内的灯光物体名(只含灯光物体), 按列表顺序值排序(collect_light_blocks 的名称视图)"""
    return [obj.name for obj in collect_light_blocks(scene, view_layer)]


def collect_material_blocks(scene: Scene, include_zero_user: bool = False, used_materials: list | None = None, include_linked: bool = True) -> list:
    """收集材质数据块(材质列表快照的单一来源, collect_scene_materials 是其名称视图)

    本地与链接数据块允许同名(复制链接资源即产生), 快照须逐块携带"是否库链接"标记,
    故返回数据块而非名称.
    """
    if include_zero_user:
        blocks = list(bpy.data.materials)
    elif used_materials is not None:
        blocks = used_materials
    else:
        blocks = collect_scene_material_blocks(scene)
    if not include_linked:
        blocks = [block for block in blocks if block.library is None]
    return _sorted_blocks(blocks)


def collect_scene_materials(scene: Scene, include_zero_user: bool = False, used_materials: list | None = None, include_linked: bool = True) -> list:
    """收集材质名并按列表顺序值排序(collect_material_blocks 的名称视图)"""
    return _sorted_names(collect_material_blocks(scene, include_zero_user, used_materials, include_linked))


# 运行期图像(渲染结果/合成 Viewer)的类型值: 这类图像恒带 1 个**内置**使用者, 且伪用户开关
# 不会让 users 加一(5.1.2 实测), 按"真实使用者"(users - 伪用户)口径会在点击伪用户按钮后判成
# 0 用户, 整行从图像列表消失. 它们不随存盘丢失, 没有"孤儿"语义,
# 故不参与 0 用户过滤, 也不参与列表排序, 恒钉在列表前两位(见 _pin_runtime_images).
# 合成类型枚举值跨版本改名: 5.1/5.2 为 COMPOSITING, 5.3/5.4 为 COMPOSITE(DNA_image_types.h)
RUNTIME_IMAGE_TYPES = {'RENDER_RESULT', 'COMPOSITING', 'COMPOSITE'}


def is_runtime_image(image) -> bool:
    """是否运行期图像(渲染结果/合成 Viewer): 恒有内置使用者, 不参与 0 用户过滤与列表排序"""
    return getattr(image, "type", "") in RUNTIME_IMAGE_TYPES


def real_user_count(datablock) -> int:
    """数据块的真实使用者数量(扣除假用户)

    users 会把假用户算进去, 故删除确认与"仅列有使用者"都按本函数判断.
    运行期图像是例外: 内置使用者与伪用户无关, 照常扣减会误判成 0 用户(见 RUNTIME_IMAGE_TYPES),
    故原样返回.
    """
    if is_runtime_image(datablock):
        return datablock.users
    return datablock.users - (1 if datablock.use_fake_user else 0)


def _find_layer_collection(layer_coll, coll):
    """在层集合树里找到包裹目标集合的 LayerCollection, 找不到返回 None"""
    if layer_coll.collection is coll:
        return layer_coll
    for child in layer_coll.children:
        found = _find_layer_collection(child, coll)
        if found is not None:
            return found
    return None


def set_active_collection(view_layer, coll) -> bool:
    """把集合设为视图层的活动层集合(大纲管理器随之高亮该集合), 不在视图层中返回 False

    大纲管理器的集合选中态没有 RNA API, 活动层集合是唯一可编程的"选中"通道.
    """
    found = _find_layer_collection(view_layer.layer_collection, coll)
    if found is None:
        return False
    view_layer.active_layer_collection = found
    return True


def relink_collection_contents(coll, fallback) -> int:
    """把集合(含子集合)内"删除后将失去全部场景挂载"的物体改挂到 fallback, 返回改挂数

    默认删除集合时保证灯光等内部物体在场景中仍可见(只删集合数据块, 物体不孤儿化);
    在删除子树之外仍有挂载的物体不动, 库链接物体同样可改挂(链接操作不受只读限制).
    """
    collections_out: list = []
    objects_out: list = []
    _collect_hierarchy(coll, collections_out, objects_out)
    subtree_ids = {c.name for c in collections_out}
    fallback_name = fallback.name
    relinked = 0
    seen: set = set()
    for obj in objects_out:
        if obj.name in seen:
            continue
        seen.add(obj.name)
        outside = [c for c in obj.users_collection if c.name not in subtree_ids and c.name != fallback_name]
        if not outside and fallback_name not in {c.name for c in obj.users_collection}:
            fallback.objects.link(obj)
            relinked += 1
    return relinked


def _collect_hierarchy(coll, collections_out: list, objects_out: list) -> None:
    """递归收集集合自身、全部子集合与物体(子级在前, 供删除时先深后浅)"""
    for child in list(coll.children):
        _collect_hierarchy(child, collections_out, objects_out)
    collections_out.append(coll)
    objects_out.extend(coll.objects)


def remove_collection_hierarchy(coll) -> int:
    """删除集合及其内部全部物体与子集合(大纲"删除层级"语义), 返回删除的物体数

    仅删可写数据: 库链接的物体/集合跳过; 物体挂在多个集合时按 Blender 物体语义
    整体删除, 去重避免同一物体被二次移除.
    """
    collections_out: list = []
    objects_out: list = []
    _collect_hierarchy(coll, collections_out, objects_out)
    removed_names: set = set()
    count = 0
    for obj in objects_out:
        if obj.library is None and obj.name not in removed_names:
            removed_names.add(obj.name)
            bpy.data.objects.remove(obj)
            count += 1
    for child_coll in collections_out:
        if child_coll.library is None:
            bpy.data.collections.remove(child_coll)
    return count


def _has_real_users(datablock) -> bool:
    """数据块是否有真实使用者"""
    return real_user_count(datablock) > 0


def collect_image_blocks(include_zero_user: bool = False, include_linked: bool = True) -> list:
    """收集图像数据块(图像列表快照的单一来源, collect_images 是其名称视图)

    include_zero_user 为假(默认)时只收有真实使用者的图像; 为真时把 0 用户图像也纳入.
    include_linked 为假时不收库链接图像(显示库链接开关).
    运行期图像始终在列并钉在快照前两位(见 RUNTIME_IMAGE_TYPES 与 _pin_runtime_images).
    本地与链接数据块允许同名, 故返回数据块.
    """
    return _pin_runtime_images(_sorted_blocks([img for img in bpy.data.images if (include_zero_user or _has_real_users(img)) and (include_linked or img.library is None)]))


def _pin_runtime_images(blocks: list) -> list:
    """运行期图像(Render Result/合成 Viewer)钉在列表前两位, 其余行保持顺序值序

    运行期图像不参与顺序值物化(all_blocks_for 排除), 恒无顺序值会按名称混排——大写
    文件名(如 AI 产物)会插到它们前面, 按名称排序物化后更是沉底, 故恒居前两位. Render Result 在前, Viewer Node 在后(与 bpy.data 默认次序一致).
    """
    pinned = [img for img in blocks if is_runtime_image(img)]
    if not pinned:
        return blocks
    pinned.sort(key=lambda img: 0 if img.type == 'RENDER_RESULT' else 1)
    return pinned + [img for img in blocks if not is_runtime_image(img)]


def collect_images(include_zero_user: bool = False, include_linked: bool = True) -> list:
    """收集图像名并按列表顺序值排序(collect_image_blocks 的名称视图)"""
    return _sorted_names(collect_image_blocks(include_zero_user, include_linked))


def collect_ies_filepaths(scene: Scene) -> list:
    """收集灯光节点树(含节点组)里 IES 纹理节点引用的资源标识, 排序去重

    IES 光域网不是图像数据块(无 bpy.data.images 条目), 5.x 有两种载体:
    EXTERNAL 模式挂节点 filepath 字符串, INTERNAL 模式指向 bpy.data.texts 的 Text 块.
    返回 src_name 列表(外部=路径, 内部=Text 名), 显示名由绘制层取末段;
    灯光在 5.x 默认带节点树(实测), 无需 use_nodes 判定.
    """
    entries: set = set()
    walked: set = set()

    def walk(tree):
        if tree is None or tree in walked:
            return
        walked.add(tree)
        for node in tree.nodes:
            if node.type == 'GROUP':
                walk(getattr(node, "node_tree", None))
            elif node.type == 'TEX_IES':
                if node.mode == 'EXTERNAL':
                    if node.filepath:
                        entries.add(node.filepath)
                elif node.ies is not None:
                    entries.add(node.ies.name)

    for obj in scene.objects:
        if obj.type == 'LIGHT':
            walk(obj.data.node_tree)
    return sorted(entries)


def find_ies_lights(scene: Scene, src_name: str) -> list:
    """场景中 IES 节点引用了给定资源标识(外部路径或 Text 名)的灯光物体列表

    与 collect_ies_filepaths 同一套遍历口径, src_name 需与收集时的标识逐字符一致;
    一盏灯只记一次; 灯光数据块可共享节点树, 故按灯逐棵走(共享组树会重复走, 代价可忽略).
    """
    users = []

    def walk(obj, tree, walked):
        if tree is None or tree in walked:
            return
        walked.add(tree)
        for node in tree.nodes:
            if node.type == 'GROUP':
                walk(obj, getattr(node, "node_tree", None), walked)
            elif node.type == 'TEX_IES':
                external_hit = node.mode == 'EXTERNAL' and node.filepath == src_name
                internal_hit = node.mode == 'INTERNAL' and node.ies is not None and node.ies.name == src_name
                if external_hit or internal_hit:
                    users.append(obj)
                    return

    for obj in scene.objects:
        if obj.type == 'LIGHT':
            walk(obj, obj.data.node_tree, set())
    return users


# 灯光集合的命名前缀(灯光集合管理列表只收该前缀的集合)
LIGHT_COLLECTION_PREFIX = "CLS_"

# 灯光集合的父集合名(CollectionNew 自动创建/挂靠, DatablockDelete 默认改挂回退)
LIGHTS_COLLECTION_NAME = "Lights"

# 相机整理的目标集合名(Organize Cameras 自动创建, 颜色标 COLOR_06)
CAMERAS_COLLECTION_NAME = "Cameras"


def scene_collection_names(root) -> set:
    """集合树里可达的全部集合名(从给定根集合递归下钻; 传场景集合即大纲可达集)"""
    names: set = set()

    def walk(coll):
        names.add(coll.name)
        for child in coll.children:
            walk(child)

    walk(root)
    return names


def visible_collection_names(layer_coll) -> set:
    """视图层里未被排除的集合名(从给定 LayerCollection 递归; 排除的集合连同子树整体跳过)

    传 view_layer.layer_collection 即"大纲里勾掉排除的集合"口径: exclude 为真的集合
    其内部物体不在 view_layer.objects 里, 集合本身也不应进灯光集合列表.
    """
    names: set = set()

    def walk(lc):
        if lc.exclude:
            return
        names.add(lc.collection.name)
        for child in lc.children:
            walk(child)

    walk(layer_coll)
    return names


def light_collections(view_layer) -> list:
    """视图层内 CLS_ 前缀的集合数据块(未排序, 被排除的集合不列)"""
    visible = visible_collection_names(view_layer.layer_collection)
    return [coll for coll in bpy.data.collections if coll.name.startswith(LIGHT_COLLECTION_PREFIX) and coll.name in visible]


def collect_light_collection_blocks(view_layer) -> list:
    """收集视图层内 CLS_ 前缀的集合数据块(灯光集合列表快照的单一来源)

    口径同 collect_light_collections; 本地与链接集合允许同名, 故返回数据块.
    """
    return _sorted_blocks(light_collections(view_layer))


def collect_light_collections(view_layer) -> list:
    """收集视图层内 CLS_ 前缀的集合名(灯光集合管理列表), 按列表顺序值排序

    只收大纲管理器可达且未被排除的集合: 数据块存在但未链接进场景的不列,
    被视图层排除的集合同样不列(否则点行联动选中会落在不可选中的集合上).
    """
    return [coll.name for coll in collect_light_collection_blocks(view_layer)]


def light_collection_tree_names(scene: Scene) -> set:
    """场景内全部灯光集合(CLS_ 前缀)及其子集合的名称集合

    口径是"大纲可达"而非视图层可见: 灯光整理只按数据归属判断物体在不在灯光集合里,
    不随视图层的排除/隐藏变化.
    """
    reachable = scene_collection_names(scene.collection)
    names: set = set()
    for coll in bpy.data.collections:
        if coll.name.startswith(LIGHT_COLLECTION_PREFIX) and coll.name in reachable:
            names |= scene_collection_names(coll)
    return names


def newest_light_collection(scene: Scene):
    """序号最大的灯光集合(CLS_NN_ 中 NN 最大即最后创建), 没有返回 None

    只认大纲可达的集合: 未链接进场景的数据块挂不进去, 移进去的物体会直接消失.
    不带序号的自定义命名集合(如 CLS_主光)不参与"最新"判定.
    """
    reachable = scene_collection_names(scene.collection)
    newest = None
    newest_num = -1
    for coll in bpy.data.collections:
        if coll.name not in reachable:
            continue
        matched = re.match(re.escape(LIGHT_COLLECTION_PREFIX) + r"(\d+)", coll.name)
        if matched is None:
            continue
        number = int(matched.group(1))
        if number > newest_num:
            newest = coll
            newest_num = number
    return newest


def ensure_scene_collection(scene: Scene, name: str, color_tag: str = 'NONE'):
    """取场景集合根下的同名子集合, 没有则新建并设颜色标, 返回该集合

    已存在但没上色(color_tag 为 NONE)时补标, 不覆写用户显式选过的颜色.
    """
    coll = scene.collection.children.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
        if color_tag != 'NONE':
            coll.color_tag = color_tag
        scene.collection.children.link(coll)
    elif color_tag != 'NONE' and coll.color_tag == 'NONE':
        coll.color_tag = color_tag
    return coll


def create_light_collection(scene: Scene):
    """新建编号灯光集合(CLS_NN_ 两位序号, 取现存最大 +1)并挂到 Lights 集合下

    序号检测只看 bpy.data.collections 的名字(与视图层可见性无关); Lights 父集合经
    ensure_scene_collection 创建/取用(标 COLOR_03).
    """
    numbers = []
    for coll in bpy.data.collections:
        matched = re.match(re.escape(LIGHT_COLLECTION_PREFIX) + r"(\d+)", coll.name)
        if matched is not None:
            numbers.append(int(matched.group(1)))
    new_coll = bpy.data.collections.new("{}{:02d}_".format(LIGHT_COLLECTION_PREFIX, max(numbers, default=0) + 1))
    ensure_scene_collection(scene, LIGHTS_COLLECTION_NAME, 'COLOR_03').children.link(new_coll)
    return new_coll


def collect_stray_lights(scene: Scene, view_layer) -> list:
    """收集位于全部灯光集合(CLS_ 前缀集合及其子集合)之外的灯光物体

    与列表同口径按视图层收集: 被排除(exclude)集合内的灯光不参与整理,
    否则整理会把用户明确排除掉的灯光又收进灯光集合并让它们重新出现在渲染里.
    库链接物体不可改挂, 不计入(移动方 move_objects_to_collection 同样跳过).
    """
    inside = light_collection_tree_names(scene)
    return [obj for obj in visible_objects(scene, view_layer) if obj.type == 'LIGHT' and obj.library is None and not any(coll.name in inside for coll in obj.users_collection)]


def collect_visible_cameras(scene: Scene, view_layer) -> list:
    """收集视图层内的全部相机物体(相机整理用)

    口径同列表: 被排除集合内的相机不参与整理(排除就等于用户不想让它们出现).
    库链接物体不可改挂, 不计入.
    """
    return [obj for obj in visible_objects(scene, view_layer) if obj.type == 'CAMERA' and obj.library is None]


def move_objects_to_collection(objects: list, target) -> int:
    """把物体真移动到目标集合(先从原先所属的其它集合全部解除挂载), 返回移动数

    库链接物体只读, 跳过; 已只在目标集合里的物体不重复挂载也不计数.
    """
    count = 0
    for obj in objects:
        if obj is None or obj.library is not None:
            continue
        others = [coll for coll in obj.users_collection if coll is not target]
        if not others:
            continue
        for coll in others:
            coll.objects.unlink(obj)
        if target not in list(obj.users_collection):
            target.objects.link(obj)
        count += 1
    return count


def collection_objects_recursive(coll) -> list:
    """集合及其子集合内的全部物体(去重, 保持层级序)"""
    collections_out: list = []
    objects_out: list = []
    _collect_hierarchy(coll, collections_out, objects_out)
    seen: set = set()
    result = []
    for obj in objects_out:
        if obj.name not in seen:
            seen.add(obj.name)
            result.append(obj)
    return result


def collect_world_blocks(include_zero_user: bool = True, include_linked: bool = True) -> list:
    """收集世界环境数据块(世界列表快照的单一来源, collect_worlds 是其名称视图)

    include_zero_user 为假时只收有真实使用者的世界(挂到某场景的世界; 由世界列表自己的“显示0用户”开关控制); include_linked 为假时不收库链接世界
    (显示库链接开关, 材质/图像/世界三列表共用). 本地与链接数据块允许同名, 故返回数据块.
    """
    return _sorted_blocks([world for world in bpy.data.worlds if (include_zero_user or real_user_count(world) > 0) and (include_linked or world.library is None)])


def collect_worlds(include_zero_user: bool = True, include_linked: bool = True) -> list:
    """收集世界环境名并按列表顺序值排序(collect_world_blocks 的名称视图)"""
    return _sorted_names(collect_world_blocks(include_zero_user, include_linked))
