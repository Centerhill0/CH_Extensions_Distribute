"""
灯光饼菜单模块

提供灯光模式下的操作饼菜单.
包含添加/删除灯光, 灯光复制与控制器操作, 灯光设置, 可见性, 灯光链接/阴影链接.
无活动灯光时也可打开, 灯光专属区随活动灯光显隐; 六个操作钮对选中集筛选出的
灯光批量起作用(控制器空体映射到其灯), 面板入口仍跟灯光面板活跃行.
"""

from bpy.types import Menu, Context, UILayout

from ...operators.object.light_rig import (
    LightAdd,
    LightCopy,
    LightInstanceCopy,
    LightControllerSet,
    LightControllerRemove,
    LightRigAdjust,
    LightRigParamsReset,
)
from ...operators.utils.list_ops import ObjectDelete
from ...utils import filter_batch_lights, rig_controller_of


def _pie_operator(row: UILayout, operator_cls, **kwargs) -> None:
    """饼菜单按钮: 显式标记"对选中集筛选出的灯光批量起作用"

    算子缺省跟灯光面板的活跃行(面板入口口径); 饼菜单六钮以选中集为操作对象批量执行,
    两套口径由入口显式声明. 按钮沿用 UILayout 默认的 operator_context(INVOKE_DEFAULT)
    ——模态类算子靠它进入交互, 不要改成 EXEC_DEFAULT(那会触发算子的"需在 3D 视图
    交互执行"守卫).
    """
    props = row.operator(operator_cls.bl_idname, **kwargs)
    props.use_selection_batch = True


class LightPie(Menu):
    """
    灯光饼菜单

    功能: 添加/删除灯光, 复制/实例复制, 控制器绑定与摘除, 模态调整与参数重置,
    灯光设置/可见性开关, 灯光链接/阴影链接.
    要求: 物体模式且非 Workbench; 无活动灯光也可打开, 灯光专属区随活动灯光显隐.
    """

    bl_idname = "VIEW3D_MT_ch_light_pie"
    bl_label = "CH Light Pie"
    bl_description = "Light Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and context.scene.render.engine != 'BLENDER_WORKBENCH'

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()
        obj = context.active_object
        light = obj.data if obj is not None and obj.type == 'LIGHT' else None
        # 批量目标绘制期现算: 六钮的可用性按选中集判定(poll 是"面板行或选中集"的联合
        # 判定, 拿不到入口标记), 按钮精度由这里保证; 选中集无合格灯光时六钮置灰
        batch_lights, _linked = filter_batch_lights(context.selected_objects, require_controller=False)
        has_batch_light = bool(batch_lights)
        has_batch_rig = any(rig_controller_of(batch_light) is not None for batch_light in batch_lights)

        # 左:添加/删除 + 灯光的操作(六钮批量, 与面板入口的"面板活跃行"口径区分)
        col = pie.column()
        row = col.row(align=True)
        # 添加/删除不传 text: 与 bl_label 同名, 经系统 Operator 语境自动翻译(显式 text 同按 Operator 语境查找)
        row.operator(LightAdd.bl_idname, icon='ADD')
        row.separator(factor=0.3)
        del_col = row.row()
        del_col.enabled = has_batch_rig
        # 显式 text: 批量口径只删灯光物体, 沿用算子标签"删除物体"会有歧义(作者定)
        del_props = del_col.operator(ObjectDelete.bl_idname, text="Delete Light", icon='REMOVE')
        del_props.use_selection_batch = True
        del_props.list_kind = 'lights'
        row = col.row(align=True)
        row.enabled = has_batch_rig
        _pie_operator(row, LightCopy, text="Copy Light", icon='DUPLICATE')
        row.separator(factor=0.3)
        _pie_operator(row, LightInstanceCopy, text="Instance Copy", icon='SEQ_STRIP_DUPLICATE')
        row = col.row(align=True)
        set_col = row.row()
        set_col.enabled = has_batch_light
        _pie_operator(set_col, LightControllerSet, text="Set Controller", icon='LIGHTPROBE_PLANE')
        row.separator(factor=0.3)
        rem_col = row.row()
        rem_col.enabled = has_batch_rig
        _pie_operator(rem_col, LightControllerRemove, text="Remove Controller", icon='UNLINKED')
        row = col.row(align=True)
        # 灯光控制不批量: 走"选区优先 + 面板回退"的模态解析, 可用性由 poll 判定
        row.operator(LightRigAdjust.bl_idname, icon='ORIENTATION_GIMBAL')
        row.separator(factor=0.3)
        reset_col = row.row()
        reset_col.enabled = has_batch_rig
        _pie_operator(reset_col, LightRigParamsReset, icon='FILE_REFRESH')

        # 右:
        pie.separator()

        # 下:灯光开关(容器恒占位以固定象限方位, 内容仅在有活动灯光时绘制)
        col = pie.column()
        col.ui_units_x = 11
        if light is not None:
            row = col.row()
            row.label(text="Light Settings")
            sub_col = row.box().column(align=False)

            sub_row = sub_col.row(align=True)
            sub_row.prop(light, "normalize")
            if light.type in {'POINT', 'SPOT'}:
                sub_row.prop(light, "use_soft_falloff")
            sub_col.prop(light, "use_shadow", text="Cast Shadow")

            row = col.row()
            row.label(text="Visibility")
            sub_col = row.box().column(align=False)

            row = sub_col.row(align=True)
            row.prop(obj, "visible_camera", text="Camera")
            row.prop(obj, "visible_volume_scatter", text="Volume Scatter")
            row = sub_col.row(align=True)
            row.prop(obj, "visible_diffuse", text="Diffuse")
            row.prop(obj, "visible_glossy", text="Glossy")
            row.prop(obj, "visible_transmission", text="Transmission")

        # 上:灯光链接/阴影链接(原生算子 poll 不查物体类型, 活动物体非灯光时整区置灰防误挂)
        col = pie.column()
        col.ui_units_x = 11
        col.enabled = light is not None

        row = col.row()
        row.label(text="Light Linking")
        sub = row.box().row(align=False)
        sub.operator("object.light_linking_receivers_link", text="Include").link_state = 'INCLUDE'
        sub.operator("object.light_linking_receivers_link", text="Exclude").link_state = 'EXCLUDE'

        row = col.row()
        row.label(text="Shadow Linking")
        sub = row.box().row(align=False)
        sub.operator("object.light_linking_blockers_link", text="Include").link_state = 'INCLUDE'
        sub.operator("object.light_linking_blockers_link", text="Exclude").link_state = 'EXCLUDE'
