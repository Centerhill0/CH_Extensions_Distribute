"""
场景助手列表与面板状态模块

提供以下功能:
- SceneHelperState: 六个资源列表的快照集合与活跃索引、选区同步/0 用户开关、
  行内列显示开关、详情子面板展开态与 PBR 镜像枚举
- CameraResolutionSettings / SceneResolutionState: 相机独立分辨率(挂物体)与
  场景侧覆写状态(挂场景), 随 .blend 保存
- 材质 PBR 镜像枚举的 update 回调: 坐标输出重建接线 / 投影与融合统一写全部命中纹理
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载(WM 级不随 .blend 保存;
  物体/场景级随 .blend 保存)
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot

注: 单一状态组覆盖全部六个列表; 列表种类元数据见 scene_state.LIST_SPECS.
"""

from bpy.props import BoolProperty, BoolVectorProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import Context, PropertyGroup

from ...common.blender.list_snapshot import ListItem, is_syncing
from .handlers import on_images_index_update, on_list_scope_update, on_sync_toggle, tag_3d_views
from .scene_state import LIST_SPECS, active_block, panel_material
from .utils import (
    apply_light_isolate_world_mute,
    collection_objects_recursive,
    detect_pbr_texture_graph,
    get_pbr_texcoord_pair,
    init_camera_resolution_from_scene,
    is_light_rig_sync_suppressed,
    is_texcoord_update_suppressed,
    light_collections_isolated,
    lights_viewport_isolated,
    rig_controller_of,
    reset_light_self_rotation,
    select_only,
    set_active_collection,
    set_controller_azimuth,
    set_controller_elevation,
    set_light_distance,
    set_light_self_rotation,
    set_texcoord_output,
    sync_active_camera_resolution,
)
from .utils._constants import CAMERA_RES_MAX, PROJECTION_OPTIONS, RIG_DEFAULT_DISTANCE, RIG_DEFAULT_ELEVATION, TEXCOORD_OPTIONS

# 自旋转镜像的默认值(0 = 无自转): 属性 default 与"恢复默认值即重新瞄准"的判据共用,
# 改一处即两处同步
_RIG_SELF_ROTATION_DEFAULT = 0.0


def _pbr_textures(context: Context) -> list | None:
    """面板活动材质命中的全部 PBR 图像纹理; 不满足检测条件返回 None"""
    mat = panel_material(context)
    if mat is None:
        return None
    pbr = detect_pbr_texture_graph(mat)
    return list(pbr["tex_by_channel"].values()) if pbr["ok"] else None


def on_pbr_texcoord_update(self, context: Context):
    """坐标输出镜像枚举的 update 回调: 重建 TexCoord -> Mapping 的接线

    真值在节点连接关系里, 本枚举只是镜像; 用户改动下拉 = 换接线(不进 Undo 栈, tooltip 说明).
    面板 draw 期把连接真值写回镜像时经算法层抑制跳过本回调(否则每帧重画都会重建接线).
    """
    if is_texcoord_update_suppressed():
        return
    mat = panel_material(context)
    if mat is None:
        return
    target = get_pbr_texcoord_pair(mat)
    if target is None:
        return
    tex_coord, mapping = target
    set_texcoord_output(tex_coord, mapping, self.pbr_texcoord)


def on_pbr_projection_update(self, context: Context):
    """投影统一控制镜像枚举的 update 回调: 把新投影写进全部命中的图像纹理

    真值散在各 Image Texture 节点的 projection 上, 本枚举只是镜像; 用户改动 = 统一改写
    全部命中纹理. Blend 只在 Box 时有意义: 改到非 Box 时把 Blend 归零(与节点面板一致).
    """
    if is_texcoord_update_suppressed():
        return
    textures = _pbr_textures(context)
    if textures is None:
        return
    for tex in textures:
        tex.projection = self.pbr_projection
        if self.pbr_projection != 'BOX':
            tex.projection_blend = 0.0


def on_pbr_projection_blend_update(self, context: Context):
    """投影融合统一控制的 update 回调: 把新 Blend 写进全部命中的图像纹理"""
    if is_texcoord_update_suppressed():
        return
    textures = _pbr_textures(context)
    if textures is None:
        return
    for tex in textures:
        tex.projection_blend = self.pbr_projection_blend


def on_cameras_show_names_update(self, context: Context):
    """视图相机名称开关的 update 回调: 批量设置场景中全部相机的 show_name

    载入文件后的实况回读走护栏写入(handlers._sync_camera_names_state), 见位即跳过,
    避免回读把用户在 N 面板手动设置的个别相机 show_name 批量覆写.
    """
    if is_syncing():
        return
    for obj in context.scene.objects:
        if obj.type == 'CAMERA':
            obj.show_name = self.cameras_show_names


def on_camera_resolution_update(self, context: Context):
    """独立分辨率开关/数值的 update 回调: 开启时按需初始化, 并即时同步场景输出

    面板勾选/拖动 X/Y 逐次触发(幂等 no-op 快), 改场景相机的其它路径仍由 handlers 兜底.
    init 的护栏内写回(resolution.py 经 set_guarded)会再次进入本回调: 见位即跳过,
    否则场景输出退化时(退出期 RNA 读 0)同值写会无限递归.
    """
    if is_syncing():
        return
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    if self.use_independent:
        init_camera_resolution_from_scene(self, scene)
    sync_active_camera_resolution(scene)


def on_lights_mute_world_update(self, context: Context):
    """屏蔽世界开关的 update 回调: 灯光或灯光集合正处于隔离态时立即应用/撤除世界屏蔽

    开关只配置"隔离"按钮的行为; 非隔离态下切换不触碰世界(下次隔离生效).
    灯光隔离与集合隔离的判定各有一套(后者靠集合的 hide_viewport), 任一成立即视为隔离态,
    否则在集合隔离期间切换开关会把世界屏蔽撤掉.
    """
    scene = getattr(context, "scene", None)
    view_layer = getattr(context, "view_layer", None)
    if scene is None or view_layer is None:
        return
    isolated = lights_viewport_isolated(scene, view_layer) or light_collections_isolated(scene, view_layer)
    apply_light_isolate_world_mute(scene, isolated, self.lights_mute_world)
    # 静音连线不触发着色器重估与视口重绘, 显式刷新
    tag_3d_views()


def on_light_collections_index_update(self, context: Context):
    """灯光集合列表活跃索引回调: 点击行时联动大纲管理器

    大纲管理器的集合行选中态没有 RNA API, 可见的"高亮落到该集合"只能靠选中其内部
    灯光物体(大纲里橙色高亮显示在对应集合下), 故同时设活动层集合 + 独占选中集合内
    灯光. 程序化写入(快照重建/高亮回写)均在护栏内, 见位即跳过.
    """
    if is_syncing():
        return
    idx = self.light_collections_active_index
    if not 0 <= idx < len(self.light_collections):
        return
    # 同名本地/链接对按行标记消歧(经 resolver), 不能按名称裸查
    coll = LIST_SPECS["light_collections"].resolve(context, self.light_collections[idx])
    view_layer = getattr(context, "view_layer", None)
    if coll is None or view_layer is None:
        return
    set_active_collection(view_layer, coll)
    # 只选中灯光: 本列表承载灯光面板语义, 集合内混入的其它物体不随行点击选中(与 README 口径一致);
    # 有控制器的灯光连同其控制器空物体一并选中(rig 作为整体操作)
    lights = [obj for obj in collection_objects_recursive(coll) if obj.type == 'LIGHT']
    rig_objects: list = []
    for light in lights:
        rig_objects.append(light)
        controller = rig_controller_of(light)
        if controller is not None:
            rig_objects.append(controller)
    if rig_objects:
        select_only(context, rig_objects)
    tag_3d_views()


def _panel_active_light(context: Context):
    """灯光面板活跃条目对应的灯光物体; 无有效条目/类型不符返回 None"""
    obj = active_block(context, "lights")
    return obj if obj is not None and obj.type == 'LIGHT' else None


def _write_light_rig_prop(context: Context, write) -> None:
    """灯光方位镜像属性的统一写回收口

    镜像属性只是变换的视图, 真值在控制器空物体的旋转与灯光的局部位置上; 面板
    draw 期回读镜像经算法层抑制跳过(否则每帧重画都写一次变换), 用户改动才落到
    变换上. 无面板活跃灯光或无控制器时不写(镜像值维持原样, 属合法空态).
    """
    if is_light_rig_sync_suppressed():
        return
    light = _panel_active_light(context)
    if light is None:
        return
    controller = rig_controller_of(light)
    if controller is None:
        return
    write(light, controller)


def on_light_rig_azimuth_update(self, context: Context):
    """方位角镜像的 update 回调: 写回控制器旋转的 Z 分量"""
    _write_light_rig_prop(context, lambda light, controller: set_controller_azimuth(controller, self.rig_azimuth))


def on_light_rig_elevation_update(self, context: Context):
    """高度角镜像的 update 回调: 写回控制器旋转的 X 分量"""
    _write_light_rig_prop(context, lambda light, controller: set_controller_elevation(controller, self.rig_elevation))


def on_light_rig_distance_update(self, context: Context):
    """距离镜像的 update 回调: 按新距离缩放灯光的局部位置(方向保持)"""
    _write_light_rig_prop(context, lambda light, controller: set_light_distance(light, self.rig_distance))


def on_light_rig_self_rotation_update(self, context: Context):
    """自旋转镜像的 update 回调: 写灯光局部旋转的 Y 分量; 归零时整体归位瞄准姿态

    不直调灯光的 rotation_euler RNA: 整组欧拉上按 Backspace 会三轴全归零(Blender
    对默认值的语义), 打破瞄准; 镜像只暴露 Y. 恢复默认值(0)时顺手把 X/Z 一并归位——镜像看不
    见被 Alt+R 之类带歪的瞄准分量, 归零这一动作正好当作“重新瞄准”的入口.
    """
    if self.rig_self_rotation == _RIG_SELF_ROTATION_DEFAULT:
        _write_light_rig_prop(context, lambda light, controller: reset_light_self_rotation(light))
        return
    _write_light_rig_prop(context, lambda light, controller: set_light_self_rotation(light, self.rig_self_rotation))


class SceneHelperState(PropertyGroup):
    """场景助手六个列表的快照与全部 UI 状态(WM 级, 不随 .blend 保存)"""

    # --- 快照与活跃索引(索引只表高亮, 不做场景联动) ---
    cameras: CollectionProperty(type=ListItem)  # type: ignore
    cameras_active_index: IntProperty(default=0)  # type: ignore
    lights: CollectionProperty(type=ListItem)  # type: ignore
    lights_active_index: IntProperty(default=0)  # type: ignore
    # 灯光集合(CLS_ 前缀)管理列表: 灯光面板主列表上方的附属列表
    light_collections: CollectionProperty(type=ListItem)  # type: ignore
    light_collections_active_index: IntProperty(default=0, update=on_light_collections_index_update)  # type: ignore
    materials: CollectionProperty(type=ListItem)  # type: ignore
    materials_active_index: IntProperty(default=0)  # type: ignore
    worlds: CollectionProperty(type=ListItem)  # type: ignore
    worlds_active_index: IntProperty(default=0)  # type: ignore
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_images_index_update)  # type: ignore

    # --- 列表范围与同步 ---
    # 选区同步(选项菜单第 1 位, 世界环境无): 四个面板共用同一个开关
    sync_selection: BoolProperty(name="Sync Selection", default=True, update=on_sync_toggle, description="Highlight the list item of the active object whenever the active object changes")  # type: ignore
    # 显示0用户(选项菜单第 2 位, 无该概念的面板不显示)
    # 材质/世界/图像默认开启: 列表默认列出全部数据块, 只有用户主动关掉时才
    # 过滤到"有使用者"的子集. 图像侧另有硬理由: 图像生成/通道捕获的产物都是 0 用户的独立数据块,
    # 默认过滤会让它们在面板里"不存在"; 且这类图像被图像编辑器显示过就带上一个临时使用者
    # (id_us_ensure_real), 点伪用户时该临时位被转正而 users 不加一, "真实使用者"口径随即判成
    # 0 用户 → 整行忽隐忽现.
    show_zero_user_materials: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list materials that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_worlds: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list worlds that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_images: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list images that have no users (orphans and fake-user only)")  # type: ignore
    # 显示库链接(材质/世界/图像三处选项共用同一开关): 是否列出经库链接引入的数据块, 默认开
    show_linked_data: BoolProperty(name="Show Linked Data", default=True, update=on_list_scope_update, description="Also list data-blocks linked from libraries (materials, worlds and images); turn off to list only data-blocks from this file")  # type: ignore

    # --- 列表内建过滤/排序开关镜像 ---
    # template_list 的漏斗开关存在 UIList 实例上, 算子拿不到; UIList.filter_items 每次绘制时
    # 镜像到这两条向量(顺序同 scene_state.LIST_KINDS), 供"上移/下移"判断显示顺序.
    filter_alpha: BoolVectorProperty(size=6, default=(False, False, False, False, False, False))  # type: ignore
    filter_reverse: BoolVectorProperty(size=6, default=(False, False, False, False, False, False))  # type: ignore

    # --- 详情子面板展开态 ---
    show_camera_details: BoolProperty(default=True)  # type: ignore
    show_light_details: BoolProperty(default=True)  # type: ignore
    show_light_rig: BoolProperty(default=True)  # type: ignore
    show_material_details: BoolProperty(default=True)  # type: ignore
    show_pbr_details: BoolProperty(default=True)  # type: ignore

    # --- 行内列显示开关 ---
    cameras_show_lens: BoolProperty(name="Lens", default=False, description="Show the lens column")  # type: ignore
    cameras_show_type: BoolProperty(name="Type", default=False, description="Show the camera type column")  # type: ignore
    cameras_show_names: BoolProperty(name="View Camera Name", default=False, description="Show or hide the names of all cameras in the 3D view (writes each camera's show_name flag, saved with the .blend; the toggle state itself is re-read on file load)", update=on_cameras_show_names_update)  # type: ignore
    lights_show_color: BoolProperty(name="Color", default=True, description="Show the light color column")  # type: ignore
    lights_show_shadow: BoolProperty(name="Shadow", default=False, description="Show the shadow toggle column")  # type: ignore
    # 屏蔽世界: 灯光/灯光集合隔离时同时屏蔽世界输出节点的全部接入端连线(取消隔离恢复).
    # 灯光面板与灯光集合列表共用同一个开关, 两个选项菜单各显示一次
    lights_mute_world: BoolProperty(name="Mute World", default=False, update=on_lights_mute_world_update, description="While isolating a light or a light collection, also mute every link into the World Output node to isolate it from the world lighting (links are restored on un-isolating)")  # type: ignore
    materials_show_pass_index: BoolProperty(name="Pass Index", default=False, description="Show the pass index column")  # type: ignore
    materials_show_node_count: BoolProperty(name="Node Count", default=False, description="Show the material node count column")  # type: ignore
    worlds_show_color: BoolProperty(name="Color", default=False, description="Show the world color swatch")  # type: ignore

    # --- 材质 PBR 镜像枚举 ---
    # 坐标输出: 真值在 TexCoord->Mapping 的连接里, 绘制前读进镜像, 用户改动重建接线
    pbr_texcoord: EnumProperty(name="Texture Coordinate", items=TEXCOORD_OPTIONS, default=0, update=on_pbr_texcoord_update, description="Texture coordinate output feeding the Mapping node (edits node links, not undoable; affects all users of this material)")  # type: ignore
    # 投影统一控制: 真值在各 Image Texture 的 projection 上; 全部一致 -> 该值, 不一致时保持镜像原值
    pbr_projection: EnumProperty(name="Projection", items=PROJECTION_OPTIONS, default=0, update=on_pbr_projection_update, description="Projection for all PBR image textures (applied to every texture; not undoable)")  # type: ignore
    # 投影融合: 仅 Box 时显示, 写进全部命中纹理
    pbr_projection_blend: FloatProperty(name="Blend", default=0.0, subtype='FACTOR', min=0.0, max=1.0, update=on_pbr_projection_blend_update, description="Blend for box projection, applied to every PBR image texture (not undoable)")  # type: ignore

    # --- 灯光方位镜像属性(灯光控制器 rig, 灯光面板"Light Rig"折叠区绘制) ---
    # 真值在控制器空物体的旋转与灯光的局部位置上(方位角=控制器旋转 Z 分量, 高度角=X
    # 分量, 距离=灯光局部位置长度), 绘制前经算法层抑制读进镜像, 用户改动经 update 回调
    # 写回变换; 纯运行期镜像不落任何自定义属性, 不进"自定义属性"面板
    rig_azimuth: FloatProperty(name="Azimuth", subtype='ANGLE', default=0.0, update=on_light_rig_azimuth_update, description="Rotation of the controller empty around its Z axis (edits the controller transform, not undoable)")  # type: ignore
    rig_elevation: FloatProperty(name="Elevation", subtype='ANGLE', default=RIG_DEFAULT_ELEVATION, update=on_light_rig_elevation_update, description="Rotation of the controller empty around its X axis (edits the controller transform, not undoable)")  # type: ignore
    rig_distance: FloatProperty(name="Distance", subtype='DISTANCE', min=0.0, default=RIG_DEFAULT_DISTANCE, update=on_light_rig_distance_update, description="Distance from the light to its controller (edits the light's local location, not undoable)")  # type: ignore
    rig_self_rotation: FloatProperty(name="Self Rotation", subtype='ANGLE', default=_RIG_SELF_ROTATION_DEFAULT, update=on_light_rig_self_rotation_update, description="Self rotation of the light around its local Y axis (edits only the Y component, not undoable; resetting to 0 also restores the local rotation X -90 and Z 0)")  # type: ignore


class CameraResolutionSettings(PropertyGroup):
    """相机独立分辨率: 该相机为场景相机时覆写场景输出分辨率(挂在物体上, 随 .blend 保存)

    res_x/res_y 出厂为 0 表示"未初始化": 首次开启由属性 update 回调以场景输出初始化,
    关闭再开启保留上次数值; 数值低于有效下限视同未启用(判据见
    utils/blender/resolution.py 的 camera_resolution).
    """

    # 标签沿用词典已有词条 "Independent Resolution"
    use_independent: BoolProperty(
        name="Independent Resolution",
        description="Override the scene output resolution with this camera's own resolution while it is the scene camera",
        default=False,
        update=on_camera_resolution_update,
    )  # type: ignore
    # 标签沿用系统词条 "Resolution X/Y"(与原生输出分辨率同名, 不入典)
    res_x: IntProperty(
        name="Resolution X",
        description="Independent output width in pixels",
        default=0,
        min=0,
        max=CAMERA_RES_MAX,
        subtype='PIXEL',
        update=on_camera_resolution_update,
    )  # type: ignore
    res_y: IntProperty(
        name="Resolution Y",
        description="Independent output height in pixels",
        default=0,
        min=0,
        max=CAMERA_RES_MAX,
        subtype='PIXEL',
        update=on_camera_resolution_update,
    )  # type: ignore


class SceneResolutionState(PropertyGroup):
    """场景侧独立分辨率覆写状态: 覆写前基准与当前覆写来源(挂在场景上, 随 .blend 保存)

    纯内部记账, 不进 UI(无 name/description, 仿 ch_ai_assistant 的 lock_ratio).
    """

    # 基准是否有效(idprop 时代的"键存在"语义改为显式布尔)
    has_base: BoolProperty(default=False)  # type: ignore
    base_x: IntProperty(default=0)  # type: ignore
    base_y: IntProperty(default=0)  # type: ignore
    # 当前覆写来源相机名(空 = 未处于覆写态)
    applied_src: StringProperty(default="")  # type: ignore
