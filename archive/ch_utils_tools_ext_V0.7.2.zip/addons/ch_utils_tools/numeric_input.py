"""模态数字输入: 起始判定与缓冲区推进(纯逻辑, 不依赖 bpy)

三处模态工具(边长/偏移边/孔洞挤出)原先各自实现同一套"数字键累加 + 退格 + 小数点"逻辑,
差异只在起始集合是否含 COMMA 与随后如何应用数值. 这里收口缓冲区操作, 应用侧只保留
"解析数值 -> 调各自 apply"的分支.

放在插件根(而非 utils)是因为需要 `mappings.input_mappings`, 而 utils 不允许反向依赖
插件顶层模块(静态审计规则).

约定:
- numeric_start_value: 事件可作为数字输入起点时返回初始缓冲字符, 否则 None
- feed_numeric: 返回 (新缓冲, 动作), 动作为
  - 'ignore': 非数字按键/非按下事件, 调用方应继续走其它分支
  - 'update': 缓冲已更新(或小数点重复但事件仍应被消费), 调用方解析并应用
  - 'cancel': 退格删到空, 调用方退出数字输入态
"""

from .mappings import input_mappings

# `numbers`(= input_mappings 键集)实际含 BACK_SPACE/DELETE/PERIOD/MINUS, 不能直接当数字键用:
# 旧实现把退格当空串追加(退格失效)、把小数点重复追加(出现 "1..")。这里按映射值筛出真正的数字键。
DIGIT_EVENTS = frozenset(key for key, value in input_mappings.items() if value.isdigit())
# 基础小数键(边长/偏移边)
DECIMAL_EVENTS = frozenset({'PERIOD', 'NUMPAD_PERIOD'})
# 扩展小数键(孔洞挤出额外接受逗号键, 与部分键盘布局/小键盘一致)
DECIMAL_EVENTS_EXT = frozenset({'PERIOD', 'COMMA', 'NUMPAD_PERIOD', 'NUMPAD_COMMA'})


def numeric_start_value(event, decimal_events=DECIMAL_EVENTS) -> str | None:
    """事件是数字输入起点时返回初始缓冲(数字本身或小数点), 否则 None"""
    if event.value != 'PRESS':
        return None
    if event.type in DIGIT_EVENTS:
        return input_mappings[event.type]
    if event.type in decimal_events:
        return "."
    return None


def feed_numeric(buffer: str, event, decimal_events=DECIMAL_EVENTS) -> tuple[str, str]:
    """把事件推进到数字缓冲, 返回 (新缓冲, 动作)

    动作语义见模块 docstring; 非 PRESS 事件一律 'ignore', 避免按键释放重复触发.
    """
    if event.value != 'PRESS':
        return buffer, 'ignore'
    if event.type == 'BACK_SPACE':
        if len(buffer) > 1:
            return buffer[:-1], 'update'
        return buffer, 'cancel'
    if event.type in DIGIT_EVENTS:
        return buffer + input_mappings[event.type], 'update'
    if event.type in decimal_events:
        if '.' not in buffer:
            return buffer + '.', 'update'
        # 已有小数点: 不改变缓冲, 但事件仍属数字输入, 调用方照常解析(保持旧行为)
        return buffer, 'update'
    return buffer, 'ignore'
