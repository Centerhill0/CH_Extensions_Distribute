"""
文本块 IO 工具模块

脚本文本块的执行捕获, 写入命名与文本编辑器聚焦.

主要功能:
- run_text_block: 独立命名空间执行脚本并捕获 traceback
- write_text_block: 按名写入文本块(存在则清空重写)
- next_script_name: 生成不冲突的 AI 脚本回落名(script_001.py 递增)
- ai_script_name: 给脚本名加 "AI " 前缀(列表过滤标识, 无前缀时添加)
- ai_texture_name / ai_render_name: 生成图像的数据块名(列表前缀过滤共用同一常量)
- ensure_unique_name: 数据块重名时追加序号保证唯一
- focus_text_editors: 把所有文本编辑器区域聚焦到指定文本块
- chat_attachment_message / chat_display_line: 对话消息的附带脚本拼装与列表展示行解析
- serialize_chat_history / parse_chat_history: 对话历史 JSON 持久化(随 blend 保存, 载入恢复)
"""

import json
import re
import traceback

import bpy
from bpy.types import Context, Text

# AI 生成脚本的前缀标识(脚本列表仅显示此前缀的文本块)
AI_SCRIPT_PREFIX = "AI "

# 生成图像的数据块名前缀(主图像列表按此前缀过滤, 三模式产物同列):
# 前缀带尾随分隔符, 但无英文词提示词的回落名是纯前缀本身(见 ai_texture_name/ai_render_name),
# 故过滤必须用 startswith(前缀) 而非 startswith(前缀 + " "), 否则该产物不进列表
AI_TEXTURE_PREFIX = "AI Tex"
AI_RENDER_PREFIX = "AI Render"
# 图像模式产物的数据块名前缀(与纹理贴图同列, 便于按名区分来源)
AI_IMAGE_PREFIX = "AI Bmp"
# 效果图模式的相机参考通道预览图前缀(走独立迷你列表, 不进主列表与画廊)
AI_REF_PREFIX = "AI Ref: "


def run_text_block(code: str, source_name: str) -> tuple:
    """以独立命名空间执行脚本并捕获异常, 返回 (是否成功, traceback 文本或 None)

    命名空间按文本编辑器运行约定注入 __name__ 为 '__main__',
    脚本需自行 import bpy; 脚本内部调用 bpy.ops 报错走 Blender 自身 report, 不会抛异常.
    """
    namespace = {'__name__': '__main__'}
    try:
        exec(compile(code, source_name, 'exec'), namespace)
        return True, None
    except Exception:
        return False, traceback.format_exc()


def write_text_block(name: str, code: str) -> tuple:
    """按名写入文本块(存在则清空重写), 返回 (Text 块, 错误信息)"""
    text = bpy.data.texts.get(name)
    if text is None:
        text = bpy.data.texts.new(name)
    else:
        text.clear()
    text.write(code)
    return text, None


def next_script_name(prefix: str = "script") -> tuple:
    """生成不冲突的脚本回落名(编号递增, 调用方再经 ai_script_name 加前缀), 返回 (名称, 错误信息)"""
    idx = 1
    while True:
        name = f"{prefix}_{idx:03d}.py"
        if name not in bpy.data.texts:
            return name, None
        idx += 1


def ai_script_name(name: str) -> str:
    """给脚本名加 AI 前缀(列表过滤标识), 已带前缀时原样返回"""
    if name.startswith(AI_SCRIPT_PREFIX):
        return name
    return f"{AI_SCRIPT_PREFIX}{name}"


def _prefixed(prefix: str, stem: str) -> str:
    """前缀名拼装: 短名非空时接在前缀后, 为空则用纯前缀(仍能被前缀过滤命中)"""
    return f"{prefix} {stem}" if stem else prefix


def ai_texture_name(stem: str) -> str:
    """纹理图像数据块名"""
    return _prefixed(AI_TEXTURE_PREFIX, stem)


def ai_image_name(stem: str) -> str:
    """图像模式产物的数据块名(与纹理同列, 便于按名区分来源)"""
    return _prefixed(AI_IMAGE_PREFIX, stem)


def ai_render_name(stem: str) -> str:
    """效果图数据块名"""
    return _prefixed(AI_RENDER_PREFIX, stem)


def render_version_suffix(name: str) -> str:
    """取效果图名的版本序号后缀(" 2"/" 3"... 首版为空串), 供自动命名改名时保留序号

    按尾部数字段识别(极小概率把 stem 恰为数字的首版误判为序号, 接受).
    """
    match = re.match(rf"^{re.escape(AI_RENDER_PREFIX)} .* (\d+)$", name)
    return f" {match.group(1)}" if match else ""


def render_version_stem(name: str) -> str | None:
    """解析效果图名到版本链 stem(非 AI Render 前缀返回 None)

    依次剥旧 _bak 方案的重名尾 ".NNN" 与 "_bak" 后缀(旧备份图按主名归入版本链),
    再剥本方案的 " N" 版本序号(与 render_version_suffix 同一取舍: stem 恰以
    数字结尾的首版名会把尾段误判为序号, 极小概率, 接受).
    """
    if not name.startswith(AI_RENDER_PREFIX):
        return None
    rest = name[len(AI_RENDER_PREFIX) :]
    match = re.search(r"\.\d{3}$", rest)
    if match:
        rest = rest[: match.start()]
    if rest.endswith("_bak"):
        rest = rest[:-4]
    match = re.match(r"^(.*) (\d+)$", rest)
    if match:
        rest = match.group(1)
    return rest.strip()


def next_render_version_name(stem: str) -> str:
    """效果图版本链的下一版本名: 首版 "AI Render <stem>", 之后按创建顺序追加 " 2"/" 3"...

    生成与修改共用一条链(同名 stem 计数), 被修改的版本不改名, 旧 _bak 备份图按主名
    归入版本链; stem 为空(提示词无英文词的回落名)时返回纯前缀, 唯一性交给
    unique_ai_name(见调用方)——纯前缀名自动命名后即脱离版本链计数, 属预期.
    """
    base = ai_render_name(stem)
    if not stem:
        # 空 stem 不过版本链扫描: 非 AI Render 图像的 render_version_stem 恒为 None,
        # 与 (stem or None) 比较会把它们全误计为"已存在", 首张就出 "AI Render 2"
        return base
    exists = False
    max_n = 1
    for image in bpy.data.images:
        if render_version_stem(image.name) != (stem or None):
            continue
        suffix = render_version_suffix(image.name)
        exists = True
        if suffix:
            max_n = max(max_n, int(suffix[1:]))
    if not exists:
        return base
    return f"{base} {max_n + 1}"


def ensure_unique_name(name: str) -> str:
    """数据块重名时追加序号保证唯一, 返回最终名"""
    if name not in bpy.data.texts:
        return name
    stem = name[:-3] if name.endswith(".py") else name
    idx = 2
    while f"{stem}_{idx}.py" in bpy.data.texts:
        idx += 1
    return f"{stem}_{idx}.py"


# AI 长文描述专用文本块名(不属脚本, 列表快照时排除)
AI_PROMPT_TEXT_NAME = "AI_Prompt.txt"

# AI 纹理长文描述专用文本块名(与脚本描述分开, 两个面板互不覆盖对方的描述)
AI_TEXTURE_PROMPT_TEXT_NAME = "AI_Texture_Prompt.txt"

# AI 效果图长文描述专用文本块名(同上, 三个面板各用各的描述块)
AI_RENDER_PROMPT_TEXT_NAME = "AI_Render_Prompt.txt"

# AI 效果图最终发送提示词查看块名(预览算子每次点击整块重写, 供文本编辑器核对发送内容)
AI_RENDER_FINAL_PROMPT_TEXT_NAME = "AI_Render_Final_Prompt.txt"

# AI 脚本最终发送提示词查看块名(完整提示词算子每次点击整块重写, 供文本编辑器核对发送内容)
AI_SCRIPT_FINAL_PROMPT_TEXT_NAME = "AI_Script_Final_Prompt.txt"

# AI 对话查看专用文本块名(长回复转出到文本编辑器阅读, 不属脚本, 列表快照时排除)
AI_CHAT_TEXT_NAME = "AI_Chat.txt"

# 对话代码提取专用文本块名(带 AI 前缀进脚本列表, 每次提取同名覆盖)
AI_CHAT_CODE_NAME = "AI Chat_Code.py"

# AI 对话最终发送提示词查看块名(完整提示词算子每次点击整块重写, 供文本编辑器核对发送内容)
AI_CHAT_FINAL_PROMPT_TEXT_NAME = "AI_Chat_Final_Prompt.txt"

# 对话历史持久化文本块名(JSON, 随 blend 保存; 载入时恢复, 见 handlers)
AI_CHAT_HISTORY_NAME = "AI_Chat_History.json"

# AI 纹理最终发送提示词查看块名(完整提示词算子每次点击整块重写, 供文本编辑器核对发送内容)
AI_TEXTURE_FINAL_PROMPT_TEXT_NAME = "AI_Texture_Final_Prompt.txt"

# 对话消息的附带脚本标记(拼装与展示解析共用同一对常量, 见 operators/chat.py 与 ui/lists/chat.py)
_CHAT_ATTACH_HEAD = "--- Attached script: "
_CHAT_ATTACH_TAIL = "--- End of script ---"


def chat_attachment_message(message: str, script_name: str, script_text: str) -> str:
    """把附带脚本全文拼进消息头部(标记行 + 脚本 + 结束标记 + 空行 + 原消息)"""
    return f"{_CHAT_ATTACH_HEAD}{script_name} ---\n{script_text}\n{_CHAT_ATTACH_TAIL}\n\n{message}"


def chat_display_line(content: str) -> tuple:
    """对话消息的列表展示行, 返回 (首行文本, 是否附带脚本)

    附带脚本的消息头部是附件标记块, 直接取首行会让列表里所有附带消息都显示同一个
    附件头: 跳过标记块取其后第一条实际消息文字; 普通消息取首行原样.
    """
    if content.startswith(_CHAT_ATTACH_HEAD) and _CHAT_ATTACH_TAIL in content:
        body = content.split(_CHAT_ATTACH_TAIL, 1)[1].lstrip("\r\n")
        line = body.split("\n", 1)[0]
        if line.strip():
            return line, True
    return content.split("\n", 1)[0], False


def serialize_chat_history(messages: list, active_index: int) -> str:
    """对话历史序列化为 JSON 文本(写入 AI_Chat_History.json 文本块随 blend 保存)

    messages 为 (role, content) 元组列表, role 取 'USER'/'ASSISTANT'.
    """
    return json.dumps(
        {"messages": [{"role": role, "content": content} for role, content in messages], "active": active_index},
        ensure_ascii=False,
    )


def parse_chat_history(raw: str) -> tuple | None:
    """解析持久化的对话历史, 返回 ((role, content) 元组列表, 活跃索引); 无效内容返回 None

    逐条校验 role 与 content 类型, 非法条目丢弃; 活跃索引越界时回落末条.
    """
    try:
        data = json.loads(raw)
        items = data["messages"]
        if not isinstance(items, list):
            return None
        messages = [(item["role"], item["content"]) for item in items if isinstance(item, dict) and item.get("role") in ("USER", "ASSISTANT") and isinstance(item.get("content"), str)]
        active = data.get("active")
        if not isinstance(active, int) or not 0 <= active < max(1, len(messages)):
            active = max(0, len(messages) - 1)
        return messages, active
    except (json.JSONDecodeError, KeyError, TypeError):
        return None


def focus_text_editors(context: Context, text: Text) -> tuple:
    """把所有文本编辑器区域的活动文本设为指定文本块, 返回 (聚焦区域数, 错误信息)"""
    focused = 0
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'TEXT_EDITOR':
                area.spaces.active.text = text
                focused += 1
    return focused, None
