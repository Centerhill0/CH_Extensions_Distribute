"""
AI 图像列表 UIList 模块

两类列表共用本模块:
- CH_UL_ai_images: 图像生成器主图像列表的条目(三模式产物同列, 靠前缀区分; 快照集合,
  带内建名称过滤与排序控件行); 同一类也承载生成通道的预览迷你列表("AI Ref: " 前缀条目,
  不参与过滤控件之外的主列表逻辑), 通道行行首有发送勾选框(与参考图列表同款, 读写该通道
  的发送开关, 见 items.pass_send_attr);
  行内名称可双击编辑(写穿到图像数据块, 见 common.blender.list_snapshot 的 rename_datablock),
  点击行走活跃索引回调(handlers.on_image_index_update / on_pass_index_update)切换图像编辑器.
- CH_UL_ai_style_refs: 参考图引用列表(条目是引用组而非快照, 无过滤控件); 行首勾选框切换
  "当前模式下是否随请求发送"(三模式各自记忆, 见 items.REF_ACTIVE_KEYS).

注意: 图像列表按前缀过滤, 把名字改掉前缀(如 "AI Tex"/"AI Render")会让该图退出对应列表
(与脚本列表改掉 "AI " 前缀同理), 只是不再出现在列表与缩略图里, 数据块本身仍在.
"""

from bpy.types import Context, UIList, UILayout

from .....common.i18n.i18n import iface
from .....common.blender.list_snapshot import StandardFilterMixin
from ...items import REF_ACTIVE_KEYS, pass_send_attr
from ...utils import AI_TEXTURE_PREFIX


class CH_UL_ai_images(StandardFilterMixin, UIList):
    """AI 生成图像条目列表(三模式产物同列, 经 template_list 的 list_id 指定列表实例)"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            # 通道预览行("AI Ref: " 前缀)行首为发送勾选框: 勾选 = 该通道随生成请求发送,
            # 备份行(_bak)解析回同一通道与当前行同开同关(备份副本本身不参与发送)
            send_attr = pass_send_attr(item.name)
            if send_attr is not None:
                row.prop(data, send_attr, text="", emboss=False, icon='CHECKBOX_HLT' if getattr(data, send_attr) else 'CHECKBOX_DEHLT')
            # 兜底名是纯前缀本身(无尾随空格, 见 utils.script_io._prefixed), 必须按常量整体匹配
            icon_id = 'TEXTURE' if item.name.startswith(AI_TEXTURE_PREFIX) else 'IMAGE_DATA'
            row.prop(item, "name", text="", emboss=False, icon=icon_id)
        else:  # GRID: 图标视图下只画一个占位图标(名称在缩略图标签里)
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')


class CH_UL_ai_style_refs(UIList):
    """参考图引用列表(三模式共用一份; 非快照集合, 选中即高亮, 无内建过滤)

    行首为"当前模式是否发送"的勾选框: 读写当前生成模式对应的标志(三模式各自记忆),
    关掉的条目仍留在列表里, 只是不参与该模式的发送与参考图预算.
    """

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            active_attr = REF_ACTIVE_KEYS[data.mode]
            row.prop(item, active_attr, text="", emboss=False, icon='CHECKBOX_HLT' if getattr(item, active_attr) else 'CHECKBOX_DEHLT')
            name = item.image.name if item.image is not None else iface("<missing>")
            row.label(text=name, icon='IMAGE_DATA')
        else:  # GRID: 图标视图下只画一个占位图标
            layout.alignment = 'CENTER'
            layout.label(text="", icon='IMAGE_DATA')
