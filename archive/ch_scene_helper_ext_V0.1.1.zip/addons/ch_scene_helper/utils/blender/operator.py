"""
算子可用性查询模块

提供以下功能:
- has_operator: 判定某个 bl_idname 的算子当前是否已注册

用途: 跨插件调用前的可用性判定. 相机面板的创建/切换/设为场景相机按钮由
ch_utils_tools 提供(CH Custom Tools 插件), 本插件只能以字符串 id 调用 ——
导入对方模块会被打包器沿 import 连带复制源码, 产出第二份同名 bl_idname 的算子类,
实测 Blender 会用后注册者摘掉先注册者的 RNA(Info: ... has been registered before,
unregistering previous), 故跨插件一律走字符串 id + 本模块的可用性判定:
对方未安装/未启用时整组按钮置灰(见 ui/panels/scene_lists.py).
"""

import bpy


def has_operator(idname: str) -> bool:
    """该 bl_idname 的算子当前是否已注册(提供方插件未安装或未启用时为 False)

    Args:
        idname: 算子标识(形如 "ch.toggle_camera")

    Returns:
        已注册返回 True, 否则 False
    """
    mod_name, _, op_name = idname.partition(".")
    if not mod_name or not op_name:
        return False
    op_module = getattr(bpy.ops, mod_name, None)
    return op_module is not None and op_name in dir(op_module)
