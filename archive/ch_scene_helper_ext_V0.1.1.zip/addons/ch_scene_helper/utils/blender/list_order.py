"""
列表顺序状态模块

列表排序值以自定义属性挂在数据块上(随 blend 持久, 跨机同步), 键名统一 ORDER_PROP;
collect 按 order_key 排序: 有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序).

注: 顺序值键名沿用 "ch_scene_order"(面板由 ch_utils_tools 迁入本插件时保持不变),
既有 .blend 文件里已写入的顺序值继续生效.
"""

ORDER_PROP = "ch_scene_order"


def get_order(datablock) -> int | None:
    """取数据块的列表顺序值, 未设置或非整数返回 None

    Args:
        datablock: 物体或材质等 ID 数据块

    Returns:
        顺序值, 未设置返回 None
    """
    value = datablock.get(ORDER_PROP)
    return value if isinstance(value, int) else None


def set_order(datablock, value: int) -> None:
    """写入数据块的列表顺序值"""
    datablock[ORDER_PROP] = value


def order_key(datablock) -> tuple:
    """排序键: 有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序)

    Args:
        datablock: 物体或材质等 ID 数据块

    Returns:
        可直接用于 sorted(key=...) 的元组
    """
    value = get_order(datablock)
    if value is None:
        return (1, 0, datablock.name)
    return (0, value, datablock.name)


def materialize_orders(blocks: list) -> None:
    """按给定顺序给全部数据块写入 0..N-1 的顺序值(忽略已有值)

    把"当前显示序"固化为持久顺序: 移动条目后调用, 保证顺序值与快照序一致.

    Args:
        blocks: 按目标顺序排列的数据块列表
    """
    for idx, block in enumerate(blocks):
        set_order(block, idx)


def swap_orders(first, second) -> None:
    """交换两个数据块的顺序值(调用方须先 materialize_orders 保证双方都有值)"""
    first_value, second_value = get_order(first), get_order(second)
    set_order(first, second_value)
    set_order(second, first_value)
