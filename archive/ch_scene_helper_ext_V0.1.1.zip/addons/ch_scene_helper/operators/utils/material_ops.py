"""
场景资源面板材质动作算子模块

提供以下功能:
- MaterialAssign: 把面板活动材质赋给全部选中物体的活动材质槽
- MaterialSelectUsers: 选中面板活动材质的全部使用者物体
- MaterialDuplicate: 复制面板活动材质
- MaterialDelete: 删除面板活动材质(在用材质由 Blender 自动清空其材质槽, 可 UNDO 恢复)

注: "面板活动材质"指材质列表活跃索引对应的数据块(按 src_name 真实名检索),
即材质赋值的目标, 与"活动物体自身的活动材质槽"无关.
"""

import bpy
from bpy.types import Context, Operator

from .....common.blender.material import assign_material
from .....common.i18n.i18n import report
from ...utils import delete_material, duplicate_material, select_material_users


def _get_panel_material(context: Context):
    """取面板活动材质(列表活跃索引对应数据块), 无有效条目返回 None

    按 src_name(真实名快照)检索: 条目名处于重命名编辑态时与真实数据块名暂时不一致.
    """
    state = context.window_manager.ch_scene_lists
    idx = state.materials_active_index
    if 0 <= idx < len(state.materials):
        return bpy.data.materials.get(state.materials[idx].src_name)
    return None


def _require_panel_material(op: Operator, context: Context):
    """取面板活动材质; 无有效条目时报告警告并返回 None(调用方返回 CANCELLED)"""
    mat = _get_panel_material(context)
    if mat is None:
        op.report({'WARNING'}, report("No material selected"))
    return mat


class MaterialAssign(Operator):
    """把面板活动材质赋给全部选中物体的活动材质槽(无槽时追加新槽)"""

    bl_idname = "ch.material_assign"
    bl_label = "Assign to Selected"
    bl_description = "Assign the active material of the Materials panel to the active slot of all selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'OBJECT' or not context.selected_objects:
            return False
        return _get_panel_material(context) is not None

    def execute(self, context: Context):
        mat = _require_panel_material(self, context)
        if mat is None:
            return {'CANCELLED'}
        count, err = assign_material(mat, context.selected_objects)
        if err is not None or count == 0:
            self.report({'WARNING'}, report("No objects selected"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Material assigned: {} objects").format(count))
        return {'FINISHED'}


class MaterialSelectUsers(Operator):
    """选中面板活动材质的全部使用者物体(与点击列表行同能力, 供不点列表时使用)"""

    bl_idname = "ch.material_select_users"
    bl_label = "Select Users"
    bl_description = "Select all objects that use the active material of the Materials panel"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode != 'OBJECT':
            return False
        return _get_panel_material(context) is not None

    def execute(self, context: Context):
        mat = _require_panel_material(self, context)
        if mat is None:
            return {'CANCELLED'}
        if not select_material_users(context, mat):
            self.report({'WARNING'}, report("No objects use this material"))
            return {'CANCELLED'}
        return {'FINISHED'}


class MaterialDuplicate(Operator):
    """复制面板活动材质(含节点树, 继承假用户设置)"""

    bl_idname = "ch.material_duplicate"
    bl_label = "Duplicate Material"
    bl_description = "Duplicate the active material of the Materials panel"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return _get_panel_material(context) is not None

    def execute(self, context: Context):
        mat = _require_panel_material(self, context)
        if mat is None:
            return {'CANCELLED'}
        if duplicate_material(mat) is None:
            self.report({'ERROR'}, report("Material not found"))
            return {'CANCELLED'}
        return {'FINISHED'}


class MaterialDelete(Operator):
    """删除面板活动材质(在用材质将清空其材质槽, Ctrl+Z 可撤销)"""

    bl_idname = "ch.material_delete"
    bl_label = "Delete Material"
    bl_description = "Delete the active material of the Materials panel (materials in use will have their slots cleared, undo with Ctrl+Z)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return _get_panel_material(context) is not None

    def execute(self, context: Context):
        mat = _require_panel_material(self, context)
        if mat is None:
            return {'CANCELLED'}
        ok, err = delete_material(mat)
        if not ok:
            self.report({'ERROR'}, report("Material not found"))
            return {'CANCELLED'}
        return {'FINISHED'}
