"""
场景资源列表动作算子模块

提供以下功能:
- SceneListMove: 上移/下移列表活跃项(顺序值写数据块自定义属性, 随 blend 持久)
- SceneListSort: 一键按名称排序(顺序值写数据块自定义属性; 面板按钮已按作者意见移除, F3 可搜索)
- SceneObjectDelete: 删除列表活跃项对应的物体(灯光/相机列表; 材质列表的删除走 MaterialDelete)

列表顺序值见 utils.blender.list_order: 挂数据块自定义属性 ch_scene_order,
collect 按 order_key 排序; 移动/排序只改写顺序值, 由 refresh_lists 立即重建快照
(自定义属性写入不触发 depsgraph, 5.1.2 实测).
"""

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Context, Operator

from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...utils import materialize_orders, swap_orders

# 列表种类 -> (快照集合属性名, 活跃索引属性名)
_LIST_FIELDS = {
    'LIGHTS': ("lights", "lights_active_index"),
    'CAMERAS': ("cameras", "cameras_active_index"),
    'MATERIALS': ("materials", "materials_active_index"),
}

_LIST_ITEMS = [
    ('LIGHTS', "Lights", ""),
    ('CAMERAS', "Cameras", ""),
    ('MATERIALS', "Materials", ""),
]

_OBJECT_LIST_ITEMS = [
    ('LIGHTS', "Lights", ""),
    ('CAMERAS', "Cameras", ""),
]


def _list_snapshot(context: Context, list_kind: str) -> tuple:
    """取列表快照与活跃索引: (集合, 活跃索引)"""
    coll_name, index_name = _LIST_FIELDS[list_kind]
    state = context.window_manager.ch_scene_lists
    return getattr(state, coll_name), getattr(state, index_name)


def _resolve_blocks(context: Context, list_kind: str) -> list:
    """取快照条目对应的数据块列表(条目失效处为 None)"""
    state = context.window_manager.ch_scene_lists
    coll_name, _ = _LIST_FIELDS[list_kind]
    if list_kind == 'MATERIALS':
        return [bpy.data.materials.get(item.src_name) for item in getattr(state, coll_name)]
    return [context.scene.objects.get(item.src_name) for item in getattr(state, coll_name)]


def _cancel_stale(op: Operator) -> set:
    """列表条目已失效: 报告后返回取消结果"""
    op.report({'WARNING'}, report("List item is no longer in the scene"))
    return {'CANCELLED'}


class SceneListMove(Operator):
    """上移/下移列表活跃项(交换相邻项的顺序值, 顺序随 blend 文件持久)"""

    bl_idname = "ch.scene_list_move"
    bl_label = "Move List Item"
    bl_description = "Move the active list item up or down (order saved in the blend file)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_LIST_ITEMS, default='LIGHTS')  # type: ignore
    move_down: BoolProperty(name="Move Down", default=False)  # type: ignore

    def execute(self, context: Context):
        coll, idx = _list_snapshot(context, self.list_kind)
        target = idx + 1 if self.move_down else idx - 1
        if not coll or not 0 <= idx < len(coll) or not 0 <= target < len(coll):
            return {'CANCELLED'}
        blocks = _resolve_blocks(context, self.list_kind)
        if blocks[idx] is None or blocks[target] is None:
            return _cancel_stale(self)
        # 先物质化当前快照序(补齐缺失顺序值), 再交换相邻两个
        materialize_orders(blocks)
        swap_orders(blocks[idx], blocks[target])
        refresh_lists()
        return {'FINISHED'}


class SceneListSort(Operator):
    """一键按名称排序列表(顺序值写数据块自定义属性, 随 blend 文件持久)"""

    bl_idname = "ch.scene_list_sort"
    bl_label = "Sort by Name"
    bl_description = "Sort the list by name (order saved in the blend file)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_LIST_ITEMS, default='LIGHTS')  # type: ignore

    def execute(self, context: Context):
        coll, _ = _list_snapshot(context, self.list_kind)
        if not coll:
            return {'CANCELLED'}
        blocks = _resolve_blocks(context, self.list_kind)
        if any(block is None for block in blocks):
            return _cancel_stale(self)
        materialize_orders(sorted(blocks, key=lambda block: block.name))
        refresh_lists()
        return {'FINISHED'}


class SceneObjectDelete(Operator):
    """删除列表活跃项对应的物体(灯光/相机列表; 子物体保留, Ctrl+Z 可撤销)"""

    bl_idname = "ch.scene_object_delete"
    bl_label = "Delete Object"
    bl_description = "Delete the active object of the list"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_OBJECT_LIST_ITEMS, default='LIGHTS')  # type: ignore

    def execute(self, context: Context):
        coll, idx = _list_snapshot(context, self.list_kind)
        if not coll or not 0 <= idx < len(coll):
            return {'CANCELLED'}
        obj = _resolve_blocks(context, self.list_kind)[idx]
        if obj is None:
            return _cancel_stale(self)
        bpy.data.objects.remove(obj)
        # 物体移除虽触发 depsgraph, 仍主动重建保证快照立即可见(后台通道尤甚)
        refresh_lists()
        return {'FINISHED'}
