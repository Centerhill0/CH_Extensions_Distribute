# CH Scene Helper（ch_scene_helper）

面向 Blender 5.1+ 的**场景资源工作台**扩展：在 3D 视图侧边栏（`N` 键）的 **Scene Helper** 选项卡里，把场景中的灯光、相机、材质各自汇总成一个可浏览、可微调、可批量操作的列表。

- **扩展 ID**：`ch_scene_helper`
- **版本**：见 [blender_manifest.toml](blender_manifest.toml) 的 `version` 字段
- **最低版本要求**：Blender 5.1.0
- **许可证**：GPL-3.0-or-later
- **维护者**：Centerhill

> 本插件由 `ch_utils_tools`（CH Custom Tools）的 Scene Helper 三面板分离而来：**相机面板的创建/切换/设为场景相机三个功能仍由 CH Custom Tools 提供**——未安装该插件时，这些按钮会自动置灰（见「与 CH Custom Tools 的关系」）。

---

## 目录

- [安装](#安装)
- [三个面板](#三个面板)
- [与 CH Custom Tools 的关系](#与-ch-custom-tools-的关系)
- [偏好设置](#偏好设置)
- [常见问题](#常见问题)
- [开发者说明](#开发者说明)

---

## 安装

### 方式一：开发框架热重载（推荐开发者使用）

本插件基于本仓库的 Blender 插件开发框架，支持文件变更自动热重载：

```bash
# 1. 在 config.ini 中配置 blender.exe 路径，并把 addon 指定为 ch_scene_helper
# 2. 启动热重载测试
python test.py
```

### 方式二：安装打包产物

```bash
python release.py             # 产出扩展 zip（发布目录见 config.ini 的 release_dir）
```

在 Blender 中 `编辑 → 偏好设置 → 插件 → 从磁盘安装`，选择产出的 zip 即可。

---

## 三个面板

三个面板默认收起，点击标题展开；列表上方漏斗图标提供名称过滤与排序。列表快照实时刷新，数量显示在面板标题后（如 `Lights (12)`）；点击列表行反向选中场景物体，场景选中也会高亮对应行（双向同步可在偏好设置中关闭）。

列表默认按名称排序，**列表右侧按钮列**负责顺序维护与删除：

- **上移 / 下移**（`▲` `▼`）：移动当前列表项，到顶/到底时自动置灰；顺序随 .blend 文件保存
- **删除**（`X`）：删除当前列表项——灯/相机删除对应物体（子物体保留），材质删除数据块（在用材质会清空其材质槽，`Ctrl + Z` 可撤销）

灯/相机的列表行右侧有三个状态开关（与系统大纲 restriction 列一致）：**禁用选中**、**在视图禁用**、**在渲染禁用**。

### Lights（灯光）

- 场景内全部灯光与自发光材质物体一屏可见；双击行内名称重命名（写穿真实数据块）
- 列表下方：**Light Linking / Shadow Linking** 快速建立包含链接
- **设置**子面板（三角箭头展开/收起，沉底）：属性顺序与原生灯光属性面板一致——色温 → 颜色 → 能量 → 类型属性（半径、角度、形状与尺寸、聚光尺寸与融合）→ 投影（EEVEE）/ 灯光组与扩散（Cycles）

### Cameras（相机）

- 场景相机所在行以实心相机图标徽标
- 列表下方依次为：**Create Aligned** 创建对齐当前视角的相机 + `▲ ▼` 循环切换；**Look Through** 进入活动相机视角 / **Lock to View** 锁定相机到视图 / **Set as Camera** 设为场景相机
- **设置**子面板（沉底）：属性顺序与原生相机属性面板一致——焦距 → 裁剪起始/终点 → 传感器 → 景深（开关与光圈）→ 安全区、背景图

### Materials（材质）

- 场景在用材质列表：行内显示使用者数，双击行内名称重命名
- 点击列表行选中该材质的全部使用者物体
- 动作行：**Assign to Selected** 把面板活动材质赋给全部选中物体的活动材质槽
- 未使用 / 孤儿数据块的清理请用 CH Custom Tools 的 `Shift + X` 清理饼（Purge Unused Data / Remove Unused Material Slots）

---

## 与 CH Custom Tools 的关系

相机面板的 **Create Aligned**、`▲ ▼`（上一/下一相机）、**Set as Camera** 三个功能由 [ch_utils_tools](../ch_utils_tools/README.md)（CH Custom Tools）提供——它们与 `Alt + C` 相机饼菜单共用同一套算子，因此：

- **已安装并启用 CH Custom Tools**：按钮正常工作；切换相机是否自动对齐视图，沿用 CH Custom Tools 偏好设置里的「Is Align」。
- **未安装或未启用 CH Custom Tools**：这几个按钮自动置灰，并在下方显示一行提示；面板的其余功能（列表、过滤排序、行内开关、相机设置子面板）不受影响。

（跨插件调用只能经算子 id 字符串进行，因此本插件不导入对方的模块；可用性由 `utils/blender/operator.py` 的 `has_operator` 在绘制期判定。）

---

## 偏好设置

`编辑 → 偏好设置 → 插件 → CH Scene Helper`：

- **Two-way Selection Sync（双向选中同步）**：列表活跃索引与 3D 视图选中状态互相同步。关闭后列表仍实时快照，只是不再联动选中。

---

## 常见问题

**Q：相机面板为什么有几个按钮是灰的？**
未安装/未启用 CH Custom Tools 时会置灰（见「与 CH Custom Tools 的关系」）；安装并启用该插件后即可恢复。

**Q：列表里看不到某个材质？**
材质列表只列**场景中正在使用**的材质（有材质槽引用）；孤儿/未使用材质请用 CH Custom Tools 的 `Shift + X` 清理饼处理。

**Q：删除材质后物体的材质槽怎么办？**
Blender 会自动清空对应材质槽，`Ctrl + Z` 可撤销。

**Q：界面是英文，如何切换中文？**
在偏好设置 → 界面中把语言设为简体中文（工具提示翻译需保持开启）。

---

## 开发者说明

- 本插件基于仓库根目录的开发框架构建：Operator 无需手写 `register()/unregister()`，框架通过 `common/class_loader` 自动发现并注册；打包时自动转换相对导入（仅支持 `from X.Y import Z` 形式的绝对导入，`import X.Y.Z` 不支持转换）。
- 目录结构：`ui/panels/scene_lists.py`（三面板 + 公共骨架 `_SceneListPanelMixin`）、`ui/lists/scene_lists.py`（三 UIList）、`operators/`（材质四算子 / 列表三算子 / 灯光能量缩放）、`utils/blender/`（材质动作、灯光、列表顺序、场景数据收集、算子可用性）、`props.py` + `handlers.py`（WM 级快照与同步）、`i18n/dictionary.py`（翻译）。
- 列表顺序值挂在数据块自定义属性 `ch_scene_order` 上（随 .blend 持久）——键名自 CH Custom Tools 迁入时保持不变，既有文件里的顺序继续生效。
- 设计与验证记录见 [docs/scene-helper-panels-design.md](docs/scene-helper-panels-design.md)。
- 开发与测试：`python test.py`（热重载）；打包发布：`python release.py`（版本发布流程见根 README「远程分发」）。
- 框架级开发规范见仓库根目录 [AGENTS.md](../../AGENTS.md)。
