"""
场景资源面板模块

提供以下功能:
- 灯光/相机/材质三个列表面板(同属 Scene Helper 选项卡, 互不附属), 公共骨架见 _SceneListPanelMixin
- 列表: WM 级快照 + 行内三状态开关 + 右侧动作按钮列(上移/下移/删除)
- 设置: 一个可展开子面板(标题"设置"), 属性顺序对齐 Blender 原生数据属性面板
  (灯光 Temperature->Color->Power->类型属性->阴影引擎项;
   相机 Lens->Clip->Sensor->DOF->Safe Areas->Background Images)
- 布局顺序: 列表 -> 链接/创建/动作行 -> 设置子面板(沉底)
- 快照由 handlers 实时刷新; 点击列表行反向选中场景物体, 场景选中回写高亮
- 行内开关与设置区属性均为 draw 期 O(1) 直读真实数据块, 不进快照
- 设计与验证记录见 docs/scene-helper-panels-design.md

跨插件依赖: 相机面板的"创建对齐相机/上一下一相机/设为场景相机"三个功能由
ch_utils_tools(CH Custom Tools)提供, 见 _utils_tools_camera_available.
"""

from bpy.types import Context, Panel, UILayout

from .....common.i18n.i18n import iface
from ...operators.utils.material_ops import MaterialAssign, MaterialDelete
from ...operators.utils.scene_list_ops import SceneListMove, SceneObjectDelete
from ...utils import has_operator
from ..lists.scene_lists import CH_UL_cameras, CH_UL_lights, CH_UL_materials

# ------------------------------------------------------------
# 跨插件相机算子(ch_utils_tools / CH Custom Tools 提供)
# ------------------------------------------------------------
# 只能以字符串 id 调用: 导入对方模块会被打包器沿 import 连带复制其源码, 产出第二份同名
# bl_idname 的算子类, 实测 Blender 会用后注册者摘掉先注册者的 RNA
# (Info: ... bl_idname '...' has been registered before, unregistering previous),
# 故一律走字符串 id, 并在绘制期用 has_operator 判定可用性: 对方未安装/未启用时整组置灰
# 并降级为同文案占位标签(未注册算子的 operator() 返回 None, 不能按按钮画, 见 _draw_optional_op).
_TOGGLE_CAMERA = "ch.toggle_camera"
_SET_AS_SCENE_CAMERA = "ch.set_as_scene_camera"
_CREATE_ALIGN_CAMERA = "ch.create_align_camera"


def _utils_tools_camera_available() -> bool:
    """CH Custom Tools 的相机算子是否全部可用(未安装/未启用时相机动作行整组置灰降级)"""
    return all(has_operator(idname) for idname in
               (_TOGGLE_CAMERA, _SET_AS_SCENE_CAMERA, _CREATE_ALIGN_CAMERA))


# ------------------------------------------------------------
# 公共绘制 helper
# ------------------------------------------------------------

def _add_kind_op(layout: UILayout, op_id: str, icon: str, list_kind: str, **props):
    """放置一个带 list_kind 的图标按钮(可附加其它算子属性), 返回算子属性集或 None"""
    op = layout.operator(op_id, text="", icon=icon)
    if op is None:
        # 算子未注册时 Blender 只打印 "unknown operator" 并返回 None, 不抛错
        return None
    op.list_kind = list_kind
    for name, value in props.items():
        setattr(op, name, value)
    return op


def _draw_optional_op(layout: UILayout, available: bool, op_id: str, *, text: str, icon: str = 'NONE',
                      **props) -> None:
    """画一个"可能不可用"的跨插件算子按钮

    不可用(提供方插件未安装/未启用)时**改画同文案的置灰标签**, 而不是"置灰的算子按钮":
    目标算子未注册时 `UILayout.operator()` 返回 None(只打印 "unknown operator"), 给它设属性会
    AttributeError; 且 `enabled = False` 只影响可用性, 拦不住按钮的创建(2026-10-15 作者实测崩溃).
    调用方把外层布局的 enabled 置 False 即得到置灰观感(见 pitfalls §11).
    """
    if not available:
        layout.label(text=text, icon=icon)
        return
    op = layout.operator(op_id, text=text, icon=icon)
    if op is None:
        # 注册被摘除的窗口期(热重载/停用瞬间): 与不可用同款降级, 不抛错
        return
    for name, value in props.items():
        setattr(op, name, value)


def _draw_list_buttons(btn_col: UILayout, coll, idx: int, list_kind: str) -> None:
    """列表右侧动作按钮列: 上移 / 下移(到边界置灰) / 删除

    上移/下移各自嵌套子 row 以便单独置灰(见 pitfalls §11).
    """
    up_row = btn_col.row(align=True)
    up_row.enabled = idx > 0
    _add_kind_op(up_row, SceneListMove.bl_idname, 'TRIA_UP', list_kind, move_down=False)
    down_row = btn_col.row(align=True)
    down_row.enabled = idx < len(coll) - 1
    _add_kind_op(down_row, SceneListMove.bl_idname, 'TRIA_DOWN', list_kind, move_down=True)
    if list_kind == 'MATERIALS':
        # 材质删除读面板活动材质(= 列表活跃项), 直接复用 MaterialDelete
        btn_col.operator(MaterialDelete.bl_idname, text="", icon='X')
    else:
        _add_kind_op(btn_col, SceneObjectDelete.bl_idname, 'X', list_kind)


def _draw_list_body(layout: UILayout, state, panel) -> None:
    """绘制列表主体: 空态提示 或 template_list + 右侧按钮列

    panel: 面板实例, 按 _SceneListPanelMixin 的属性契约读取列表元信息.
    """
    coll = getattr(state, panel._coll_name)
    if not coll:
        layout.label(text=iface(panel._empty_text), icon='INFO')
        return
    row = layout.row(align=True)
    row.template_list(panel._ul_id, panel._list_id, state, panel._coll_name,
                      state, panel._index_name, rows=4)
    _draw_list_buttons(row.column(align=True), coll, getattr(state, panel._index_name),
                       panel._list_kind)


def _draw_settings_box(layout: UILayout, ui_state, prop_name: str):
    """"设置"子面板标题行(三角箭头 + 文本, 无图标); 展开时返回内容 box, 收起返回 None

    展开态存 WM 级 SceneListsUIState; 三角用 text="" 只画箭头(作者偏好, 见 pitfalls §11).
    """
    opened = getattr(ui_state, prop_name)
    header = layout.row()
    header.prop(ui_state, prop_name, text="", emboss=False,
                icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
    header.label(text=iface("Settings"))
    return layout.box() if opened else None


def _active_scene_object(context: Context, state, coll_name: str, index_name: str, obj_type: str):
    """取列表活跃项对应的场景物体; 索引越界/条目失效/类型不符时返回 None"""
    coll = getattr(state, coll_name)
    idx = getattr(state, index_name)
    if not 0 <= idx < len(coll):
        return None
    obj = context.scene.objects.get(coll[idx].src_name)
    if obj is None or obj.type != obj_type:
        return None
    return obj


# ------------------------------------------------------------
# 面板公共骨架
# ------------------------------------------------------------

class _SceneListPanelMixin:
    """场景资源列表面板的公共骨架(普通混入类, 非 bpy 类型故不参与自动注册)

    子类须提供:
    - bl_idname: 面板标识
    - _title / _title_icon: 标题文本(经 iface 翻译)与标题图标
    - _coll_name / _index_name: 快照集合与活跃索引属性名
    - _ul_id / _list_id: UIList 类名与 template_list 状态标识(过滤/排序状态按后者持久)
    - _empty_text / _list_kind: 空态提示文案与右侧按钮列的算子分派种类
    """

    # 标题 = 名称 + 计数: bl_label 置空后系统补画的是空标签(不可见), 名称与计数由
    # draw_header 自绘——不走"标签匹配 bl_label 抑制补画"路线(本地化界面下匹配不稳定,
    # 会多画一个名称; 作者意见轮 6)
    bl_label = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 侧边栏选项卡名称
    bl_category = "Scene Helper"
    # 默认收起, 点击标题展开/收缩
    bl_options = {'DEFAULT_CLOSED'}

    _title = ""
    _title_icon = 'NONE'
    _coll_name = ""
    _index_name = ""
    # UIList 类名经导入引用, 类重命名时此处的 template_list id 自动跟随
    _ul_id = ""
    _list_id = ""
    _empty_text = ""
    _list_kind = ""

    def draw_header(self, context: Context):
        state = context.window_manager.ch_scene_lists
        self.layout.label(text=iface(self._title), icon=self._title_icon)
        self.layout.label(text="({})".format(len(getattr(state, self._coll_name))))


# ------------------------------------------------------------
# Lights 面板
# ------------------------------------------------------------

def _draw_lights_settings(layout: UILayout, context: Context, state, ui_state) -> None:
    """活动灯光设置子面板: 属性顺序对齐原生灯光数据面板

    自发光材质物体(非 LIGHT 类型行)无此设置区, 材质侧调节为 Stage 2.
    """
    obj = _active_scene_object(context, state, "lights", "lights_active_index", 'LIGHT')
    if obj is None:
        return
    box = _draw_settings_box(layout, ui_state, "show_light_settings")
    if box is None:
        return
    light = obj.data
    # Temperature -> Color -> Power -> 类型属性 -> 阴影/引擎项(原生顺序)
    row = box.row(align=True, heading="Temperature")
    row.prop(light, "use_temperature", text="")
    sub = row.row()
    sub.active = light.use_temperature
    sub.prop(light, "temperature", text="")
    row = box.row(align=True)
    row.prop(light, "color")
    row.prop(light, "energy", text="Energy")
    if light.type in {'POINT', 'SPOT'}:
        row = box.row(align=True)
        row.prop(light, "shadow_soft_size", text="Radius")
        if light.type == 'SPOT':
            row.prop(light, "spot_size", text="Spot Size")
            row.prop(light, "spot_blend")
    elif light.type == 'SUN':
        box.prop(light, "angle")
    elif light.type == 'AREA':
        row = box.row(align=True)
        row.prop(light, "shape")
        if light.shape in {'SQUARE', 'DISK'}:
            row.prop(light, "size")
        elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
            row.prop(light, "size", text="Size X")
            row.prop(light, "size_y")
    if context.scene.render.engine == 'BLENDER_EEVEE':
        box.prop(light, "use_shadow", text="Cast Shadow")
    elif context.scene.render.engine == 'CYCLES':
        row = box.row(align=True)
        row.prop(obj, "lightgroup", text="")
        if light.type == 'AREA':
            row.prop(light, "spread")


def _draw_lights_actions(layout: UILayout) -> None:
    """灯光链接动作行(紧跟列表)"""
    row = layout.row(align=True)
    row.operator("object.light_linking_receivers_link", text="Light Linking").link_state = 'INCLUDE'
    row.operator("object.light_linking_blockers_link", text="Shadow Linking").link_state = 'INCLUDE'


class LightsPanel(_SceneListPanelMixin, Panel):
    """灯光列表面板"""

    bl_idname = "VIEW3D_PT_ch_lights"
    _title = "Lights"
    _title_icon = 'LIGHT'
    _coll_name = "lights"
    _index_name = "lights_active_index"
    _ul_id = CH_UL_lights.__name__
    _list_id = "ch_lights"
    _empty_text = "No lights in the scene"
    _list_kind = 'LIGHTS'

    def draw(self, context: Context):
        state = context.window_manager.ch_scene_lists
        ui_state = context.window_manager.ch_scene_lists_ui
        col = self.layout.column()
        _draw_list_body(col, state, self)
        # 链接按钮紧跟列表, 设置子面板沉底(作者意见)
        _draw_lights_actions(col)
        _draw_lights_settings(col, context, state, ui_state)


# ------------------------------------------------------------
# Cameras 面板
# ------------------------------------------------------------

def _draw_cameras_create_row(layout: UILayout, available: bool) -> None:
    """创建/切换行(自面板头移至列表下方, 作者意见)

    本行三个按钮均由 CH Custom Tools 提供; 该插件未安装/未启用时整行置灰, 按钮降级为
    同文案占位标签(见 _draw_optional_op).
    """
    row = layout.row(align=True)
    row.enabled = available
    _draw_optional_op(row, available, _CREATE_ALIGN_CAMERA, text="Create Aligned", icon='VIEW_CAMERA')
    sub = row.row(align=True)
    _draw_optional_op(sub, available, _TOGGLE_CAMERA, text="", icon='TRIA_UP_BAR', toggle_next=False)
    _draw_optional_op(sub, available, _TOGGLE_CAMERA, text="", icon='TRIA_DOWN_BAR', toggle_next=True)


def _draw_cameras_actions(layout: UILayout, context: Context, available: bool) -> None:
    """"相机视角"动作行(紧跟创建行)

    Look Through / Lock to View 为 Blender 原生能力(始终可用); Set as Camera 由
    CH Custom Tools 提供, 该插件未安装/未启用时单独置灰并降级为占位标签.
    "对齐到视图"(view3d.camera_to_view)已按作者意见移除, Alt+C 相机饼菜单仍保留该功能.
    """
    row = layout.row(align=True)
    row.operator("view3d.view_camera", text="Look Through", icon='VIEW_CAMERA')
    row.prop(context.space_data, "lock_camera", text="Lock to View")
    set_row = row.row(align=True)
    set_row.enabled = available
    _draw_optional_op(set_row, available, _SET_AS_SCENE_CAMERA, text="Set as Camera")


def _draw_missing_utils_tools_hint(layout: UILayout) -> None:
    """CH Custom Tools 缺失时的置灰提示行(仅该插件未安装/未启用时绘制)"""
    hint = layout.row()
    hint.enabled = False
    hint.label(text=iface("Requires CH Custom Tools"), icon='INFO')


def _draw_cameras_settings(layout: UILayout, context: Context, state, ui_state) -> None:
    """活动相机设置子面板: 属性顺序对齐原生相机数据面板"""
    obj = _active_scene_object(context, state, "cameras", "cameras_active_index", 'CAMERA')
    if obj is None:
        return
    box = _draw_settings_box(layout, ui_state, "show_camera_settings")
    if box is None:
        return
    cam = obj.data
    # Lens -> Clip -> Sensor -> DOF -> Safe Areas -> Background Images(原生顺序)
    box.prop(cam, "lens", text="Lens")
    row = box.row(align=True)
    row.prop(cam, "clip_start")
    row.prop(cam, "clip_end")
    box.prop(cam, "sensor_width", text="Sensor")
    row = box.row(align=True)
    row.prop(cam.dof, "use_dof", text="DOF")
    sub = row.row()
    sub.active = cam.dof.use_dof
    sub.prop(cam.dof, "aperture_fstop", text="f-stop")
    row = box.row(align=True)
    row.prop(cam, "show_safe_areas")
    row.prop(cam, "show_background_images")


class CamerasPanel(_SceneListPanelMixin, Panel):
    """相机列表面板(创建/切换/设为场景相机依赖 CH Custom Tools)"""

    bl_idname = "VIEW3D_PT_ch_cameras"
    _title = "Cameras"
    _title_icon = 'OUTLINER_OB_CAMERA'
    _coll_name = "cameras"
    _index_name = "cameras_active_index"
    _ul_id = CH_UL_cameras.__name__
    _list_id = "ch_cameras"
    _empty_text = "No cameras in the scene"
    _list_kind = 'CAMERAS'

    def draw(self, context: Context):
        state = context.window_manager.ch_scene_lists
        ui_state = context.window_manager.ch_scene_lists_ui
        col = self.layout.column()
        _draw_list_body(col, state, self)
        # 创建行 -> 相机动作行 -> 设置子面板(作者意见的顺序)
        available = _utils_tools_camera_available()
        _draw_cameras_create_row(col, available)
        _draw_cameras_actions(col, context, available)
        if not available:
            _draw_missing_utils_tools_hint(col)
        _draw_cameras_settings(col, context, state, ui_state)


# ------------------------------------------------------------
# Materials 面板
# ------------------------------------------------------------

def _draw_materials_actions(layout: UILayout) -> None:
    """材质动作行(赋给选中物体)"""
    row = layout.row(align=True)
    row.operator(MaterialAssign.bl_idname, text="Assign to Selected")


class MaterialsPanel(_SceneListPanelMixin, Panel):
    """材质列表面板"""

    bl_idname = "VIEW3D_PT_ch_materials"
    _title = "Materials"
    _title_icon = 'MATERIAL'
    _coll_name = "materials"
    _index_name = "materials_active_index"
    _ul_id = CH_UL_materials.__name__
    _list_id = "ch_materials"
    _empty_text = "No materials in use in the scene"
    _list_kind = 'MATERIALS'

    def draw(self, context: Context):
        state = context.window_manager.ch_scene_lists
        col = self.layout.column()
        _draw_list_body(col, state, self)
        _draw_materials_actions(col)
