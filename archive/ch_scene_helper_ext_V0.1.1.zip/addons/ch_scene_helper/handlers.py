"""
实时同步处理器模块

提供以下功能:
- depsgraph_update_post / load_post 处理器: 场景资源列表实时刷新与 3D 视图选中同步
- refresh_lists: 公开的"立即重建快照"入口(供不触发 depsgraph 的算子主动调用)
- 列表活跃索引 update 回调: 用户点击列表行时反向选中场景物体
- 周期计时器: 兜底刷新
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接
- 快照重建与重入护栏机制见 common.blender.list_snapshot
"""

import bpy
from bpy.types import Context

from ...common.blender.list_snapshot import is_syncing, rebuild_if_changed, set_index
from .preference import get_prefs
from .utils import collect_cameras, collect_lights, collect_scene_materials, select_material_users

# 列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0


def _select_object_by_name(context: Context, name: str) -> bool:
    """取消现有选择, 选中并激活指定物体; 物体不存在时返回 False

    先设活动物体再改选中: 后台实测 active 为 None 时 select_set(True) 静默失效
    (同 utils.select_material_users 注; GUI 常规有活动物体不受影响).
    """
    obj = context.scene.objects.get(name)
    if obj is None:
        return False
    context.view_layer.objects.active = obj
    for sel_obj in list(context.selected_objects):
        if sel_obj.name != obj.name:
            sel_obj.select_set(False)
    obj.select_set(True)
    return True


# ------------------------------------------------------------
# 列表点击 -> 场景选中(update 回调, 由 props.py 的活跃索引属性挂接)
# ------------------------------------------------------------


def _index_update_blocked(state, coll_name: str, index_name: str) -> bool:
    """列表点击回调的统一闸门: 快照重建中 / 活跃索引越界 / 双向选中同步关闭"""
    if is_syncing():
        return True
    if getattr(state, index_name) >= len(getattr(state, coll_name)):
        return True
    return not get_prefs().scene_lists_sync


def on_lights_index_update(self, context: Context):
    """灯光列表活跃索引回调: 用户点击行时选中对应物体(灯或自发光材质物体)"""
    if _index_update_blocked(self, "lights", "lights_active_index"):
        return
    _select_object_by_name(context, self.lights[self.lights_active_index].src_name)


def on_cameras_index_update(self, context: Context):
    """相机列表活跃索引回调: 用户点击行时选中对应物体"""
    if _index_update_blocked(self, "cameras", "cameras_active_index"):
        return
    _select_object_by_name(context, self.cameras[self.cameras_active_index].src_name)


def on_materials_index_update(self, context: Context):
    """材质列表活跃索引回调: 点击行时选中全部使用者物体(算法下沉 utils.select_material_users)"""
    if _index_update_blocked(self, "materials", "materials_active_index"):
        return
    mat = bpy.data.materials.get(self.materials[self.materials_active_index].src_name)
    if mat is not None:
        select_material_users(context, mat)


# ------------------------------------------------------------
# 场景 -> 列表同步
# ------------------------------------------------------------


def _sync_index_to_name(state, coll_name: str, index_name: str, name: str):
    """列表快照中存在同名条目时把活跃索引指向它(护栏内写入)"""
    col = getattr(state, coll_name)
    for idx, item in enumerate(col):
        if item.name == name:
            if getattr(state, index_name) != idx:
                set_index(state, index_name, idx)
            return


def _sync_selection(state):
    """把活动物体/活动材质同步到对应列表的活跃索引

    灯光列表含自发光材质物体, 按活动物体名直接匹配(不在列表则无操作).
    双向选中同步开关关闭时跳过(场景选中不回写列表).
    """
    if not get_prefs().scene_lists_sync:
        return
    act_obj = bpy.context.view_layer.objects.active
    if act_obj is None:
        return
    _sync_index_to_name(state, "lights", "lights_active_index", act_obj.name)
    _sync_index_to_name(state, "cameras", "cameras_active_index", act_obj.name)
    if act_obj.active_material is not None:
        _sync_index_to_name(state, "materials", "materials_active_index", act_obj.active_material.name)


def _sync_all():
    """全量同步: 有变化才重建三个列表快照, 然后做选中同步"""
    state = bpy.context.window_manager.ch_scene_lists
    scene = bpy.context.scene
    rebuild_if_changed(state, "lights", "lights_active_index", 'OBJECT', collect_lights(scene)[0])
    rebuild_if_changed(state, "cameras", "cameras_active_index", 'OBJECT', collect_cameras(scene)[0])
    rebuild_if_changed(state, "materials", "materials_active_index", 'MATERIAL', collect_scene_materials(scene)[0])
    _sync_selection(state)


def _sync_all_safe() -> None:
    """全量同步, 吞掉"插件注销窗口期 WM 属性已摘除"类异常(各入口共用)"""
    try:
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _on_depsgraph_update(*_args):
    """depsgraph 更新回调: 场景/选中变化时实时刷新"""
    _sync_all_safe()


def _on_load_post(*_args):
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐新场景"""
    _sync_all_safe()


def refresh_lists() -> None:
    """立即重建列表快照并同步选中

    供"写自定义属性(不触发 depsgraph, 5.1.2 实测)"的算子主动调用, 如列表排序值写入.
    """
    _sync_all_safe()


def _sync_timer():
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register():
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister():
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
