from ....common.i18n.dictionary import preprocess_dictionary

# 翻译条目按对应 Operator / 面板分块注释归类:
# Operator 标签用 ("Operator", "English text"), 通用文本与 report 消息用 ("*", "English text")
dictionary = {
    "zh_HANS": {
        # 侧栏选项卡与三个面板共用文案(ui/panels/scene_lists.py)
        ("*", "Scene Helper"): "场景助手",
        ("*", "No lights in the scene"): "场景中没有灯光",
        ("*", "No cameras in the scene"): "场景中没有相机",
        ("*", "No materials in use in the scene"): "场景中没有使用中的材质",
        ("*", "Requires CH Custom Tools"): "需要 CH Custom Tools 插件",
        # 面板动作行/设置子面板文案(未命中系统词条)
        ("*", "Energy"): "能量",
        ("*", "DOF"): "景深",
        ("*", "f-stop"): "光圈",
        ("*", "Spot Size"): "聚光尺寸",
        ("*", "Create Aligned"): "创建对齐相机",
        ("*", "Look Through"): "相机视角",
        ("*", "Lock to View"): "锁定到视图",
        ("*", "Set as Camera"): "设为场景相机",
        # 原生算子按钮文案(静态审计要求 ctx=Operator 覆盖; 运行时系统 mo 优先, 插件词典兜底)
        ("Operator", "Create Aligned"): "创建对齐相机",
        ("Operator", "Look Through"): "相机视角",
        ("Operator", "Set as Camera"): "设为场景相机",
        ("Operator", "Light Linking"): "灯光链接",
        ("Operator", "Shadow Linking"): "阴影链接",
        # 偏好设置(preference.py)
        ("*", "Two-way Selection Sync"): "双向选中同步",
        ("*", "Keep the list active index and the 3D view selection in sync both ways"): "让列表活跃索引与 3D 视图选中状态双向保持同步",
        # 材质动作算子(operators/utils/material_ops.py)
        ("Operator", "Assign to Selected"): "赋给选中项",
        ("*", "Assign to Selected"): "赋给选中项",
        ("Operator", "Select Users"): "选中使用者",
        ("*", "Select Users"): "选中使用者",
        ("Operator", "Duplicate Material"): "复制材质",
        ("Operator", "Delete Material"): "删除材质",
        ("*", "Delete Material"): "删除材质",
        ("*", "No material selected"): "没有选中材质",
        ("*", "No objects use this material"): "没有物体使用该材质",
        ("*", "Material not found"): "未找到材质",
        ("*", "Material assigned: {} objects"): "已把材质赋给 {} 个物体",
        ("*", "Assign the active material of the Materials panel to the active slot of all selected objects"): "把材质面板的活动材质赋给全部选中物体的活动材质槽",
        ("*", "Select all objects that use the active material of the Materials panel"): "选中全部使用材质面板活动材质的物体",
        ("*", "Duplicate the active material of the Materials panel"): "复制材质面板的活动材质",
        ("*", "Delete the active material of the Materials panel (materials in use will have their slots cleared, undo with Ctrl+Z)"): "删除材质面板的活动材质(在用材质将清空其材质槽, 可用 Ctrl+Z 撤销)",
        # 灯光能量缩放算子(operators/object/light.py)
        ("Operator", "Energy Scale"): "能量缩放",
        ("*", "Energy Scale"): "能量缩放",
        ("*", "No lights selected"): "没有选中灯光",
        ("*", "Energy scaled: {} lights"): "已缩放 {} 个灯光的能量",
        ("*", "Scale the energy of all selected lights by a factor"): "把全部选中灯光的能量乘以系数",
        ("*", "Multiplier applied to the energy of each selected light"): "每个选中灯光能量的乘数",
        # 列表动作算子(operators/utils/scene_list_ops.py)
        ("*", "Move Down"): "下移",
        ("Operator", "Move List Item"): "移动列表项",
        ("*", "Move List Item"): "移动列表项",
        ("*", "Move the active list item up or down (order saved in the blend file)"): "上移或下移列表活跃项(顺序随 blend 文件持久)",
        # "Sort by Name" 系统已有(ctx=空 与 Operator 均在 blender.mo), 不入典
        ("*", "Sort the list by name (order saved in the blend file)"): "按名称排序列表(顺序随 blend 文件持久)",
        ("Operator", "Delete Object"): "删除物体",
        ("*", "Delete Object"): "删除物体",
        ("*", "Delete the active object of the list"): "删除列表活跃项对应的物体",
        ("*", "List item is no longer in the scene"): "列表项已不在场景中",
    }
}

dictionary = preprocess_dictionary(dictionary)
