"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(双向选中同步开关)
- get_prefs: 取本插件偏好实例
"""

import bpy
from bpy.props import BoolProperty
from bpy.types import AddonPreferences, Context

from .config import __addon_name__


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    # ----------Scene Helper 属性----------
    # 双向选中同步: 侧栏 Scene Helper 列表活跃索引与 3D 视图选中状态互相同步
    # (关闭后列表仍实时快照, 仅不做选中联动; 快照刷新不受影响)
    scene_lists_sync: BoolProperty(name="Two-way Selection Sync", description="Keep the list active index and the 3D view selection in sync both ways", default=True)  # type: ignore

    def draw(self, context: Context):
        layout = self.layout
        # 场景助手设置(侧栏 Scene Helper 列表与 3D 视图选中同步)
        box = layout.box()
        box.label(text="Scene Helper", icon='OUTLINER')
        box.prop(self, "scene_lists_sync")


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
