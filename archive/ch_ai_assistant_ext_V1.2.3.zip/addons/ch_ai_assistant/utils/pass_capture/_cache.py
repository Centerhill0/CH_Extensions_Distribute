"""按渲染组的增量缓存: 组是「一次渲染调用」与「缓存失效」的共同单位"""

from ._constants import CRYPTO_SLOT_COUNT, CRYPTO_SLOT_KEYS, CRYPTO_SOURCE_DEFAULT, EDGE_PRESET_DEFAULT, GROUP_LINEART, GROUP_MAIN, GROUP_OUTPUTS, _EEVEE_SAMPLES, _crypto_slots_used, _group_entries


from ._size import _sane_clamp, resolve_capture_size

_PASS_RAW_CACHE: dict | None = None


# 原始字节增量缓存的内存上限. 定标依据(2026-10-13 实测): 2048² 下三层 cryptomatte 约 201 MB,
# 再加深度/法向 EXR 约 280 MB —— 给 512 MB 在常规分辨率不会触发, 又能挡住 4K/8K 把内存吃满.
# 超限即整体丢弃(不做半缓存), 该口径见 store_group_cache 的 docstring.
_RAW_CACHE_MAX_BYTES = 512 * 1024 * 1024


_CHANNEL_GROUP = {key: group for group, entries in GROUP_OUTPUTS.items() for key, _ in entries}
# cryptomatte 各层由主组渲染, 故归入主组(键名由层数派生, 不随渲染组声明表变化)
_CHANNEL_GROUP.update({key: GROUP_MAIN for key in CRYPTO_SLOT_KEYS})


def needed_groups(wanted: dict) -> list:
    """本次需要的渲染组(按批次顺序: 主组在前, 线稿组在后)"""
    return [group for group in (GROUP_MAIN, GROUP_LINEART) if _group_entries(group, wanted)]


def _color_management_key(scene) -> tuple:
    """用户色彩管理的关键项

    只有**合并结果**通道遵循用户色彩管理(其余通道 save_as_render=False 已隔离), 故它只进
    主组键. 漏掉它会导致「改了 view transform 却命中缓存,合并结果不跟着变」——
    实测该回归由 test_capture_passes 的「合并结果随 view transform 变化」断言抓出.
    """
    settings = getattr(scene, "view_settings", None)
    if settings is None:
        return ()
    return (settings.view_transform, settings.look, settings.exposure, settings.gamma)


def scene_content_key(scene) -> tuple:
    """场景**可见内容**的指纹(进渲染键)

    **必须有它**: 渲染键若只含尺寸/相机/参数, 那么增删物体后键**一字不变** → 命中增量
    缓存 → 直接返回**上一个场景**的通道字节(2026-10-15 用户实测: 加/删物体后点生成通道,
    出图仍是旧场景; 已由红基线复现).

    取粗粒度指纹(名字/类型/隐藏态/世界矩阵/网格规模/材质名/帧号)而非逐顶点哈希:
    覆盖增删/改名/移动/隐藏/换材质/改拓扑/换帧这些常见改动, 又不至于每次捕获都做重活.
    宁可多失效(多渲一次)也不能少失效(给出陈旧出图).
    """
    items = []
    for obj in scene.objects:
        data = getattr(obj, "data", None)
        if obj.type == 'MESH' and data is not None:
            shape = (len(data.vertices), len(data.polygons))
        elif obj.type == 'GREASE_PENCIL' and data is not None:
            shape = (len(data.layers),)
        elif data is not None:
            shape = (len(data.name),)  # 其它类型只认数据块名(改数据即改名或换块)
        else:
            shape = ()
        mats = tuple(slot.material.name if slot.material else "" for slot in getattr(obj, "material_slots", ()))
        items.append((obj.name, obj.type, bool(obj.hide_render), tuple(round(v, 4) for row in obj.matrix_world for v in row), shape, mats))
    items.sort()
    return (tuple(items), scene.world.name if getattr(scene, "world", None) else "", getattr(scene, "frame_current", 0))


def group_render_key(
    group: str,
    scene,
    *,
    ao_distance: float = 1.0,
    edge_width_scale: float = 1.0,
    material_borders: bool = False,
    edge_preset: str = EDGE_PRESET_DEFAULT,
    clamp_long_edge: int = 0,
    render_samples: int = _EEVEE_SAMPLES,
    crypto_source: str = CRYPTO_SOURCE_DEFAULT,
    crypto_slots: int = CRYPTO_SLOT_COUNT,
) -> tuple:
    """某组的**渲染键**: 只含改变该组渲染结果的参数

    刻意不含「本次要哪些通道」(由子集判定负责), 也**不含其它组的参数** ——
    线宽不进主组键,AO 距离不进线稿组键, 这样改一个参数只影响它真正影响的那个组.
    公共项(钳制后尺寸/相机名/相机世界矩阵/**场景可见内容指纹**)两组都含:
    它们会改变任何一组的渲染结果. 采样数两组都含: 两组共享同一个场景采样数.
    """
    cap_w, cap_h = resolve_capture_size(scene, _sane_clamp(clamp_long_edge))
    cam = scene.camera
    common = ((cap_w, cap_h), cam.name if cam is not None else "", tuple(cam.matrix_world) if cam is not None else (), render_samples, scene_content_key(scene))
    if group == GROUP_MAIN:
        # 主组是唯一有通道遵循用户色彩管理的组(合并结果), 故色彩管理必须进它的键;
        # 分割依据与落盘层数只影响主组(它们决定主组开哪条 pass,出几层)
        return (ao_distance, crypto_source, _crypto_slots_used(crypto_slots)) + _color_management_key(scene) + common
    if group == GROUP_LINEART:
        # 线稿走 alpha 映射(save_as_render=False), 与色彩管理无关
        return (edge_width_scale, material_borders, edge_preset) + common
    return common


def lookup_group_cache(keys: dict, wanted: dict, crypto_source: str = CRYPTO_SOURCE_DEFAULT, crypto_slots: int = CRYPTO_SLOT_COUNT) -> dict:
    """按组查缓存, 返回可复用的 {组: {通道键: 原始落盘字节}}

    命中条件: 该组渲染键与缓存一致, **且**本次所需通道 ⊆ 该组已产出通道(子集判定).
    子集判定是「取消一个通道不重渲」得以成立的关键.
    """
    cached = (_PASS_RAW_CACHE or {}).get("groups", {})
    reused = {}
    for group, key in keys.items():
        entry = cached.get(group)
        if not entry or entry.get("key") != key:
            continue
        needed = {channel for channel, _socket in _group_entries(group, wanted, crypto_source, crypto_slots)}
        raw = entry.get("raw") or {}
        if needed and needed <= set(raw):
            reused[group] = dict(raw)
    return reused


def store_group_cache(keys: dict, raw_by_group: dict, size, notices) -> None:
    """把本次渲染产出的各组原始字节并入缓存(未重渲的组保留原有条目)"""
    global _PASS_RAW_CACHE
    groups = dict((_PASS_RAW_CACHE or {}).get("groups", {}))
    for group, raw in raw_by_group.items():
        if raw:
            groups[group] = {"key": keys.get(group), "raw": dict(raw)}
    if not groups:
        _PASS_RAW_CACHE = None
        return
    total = sum(len(blob) for entry in groups.values() for blob in entry["raw"].values())
    if total > _RAW_CACHE_MAX_BYTES:
        # 超上限即**整体丢弃**(不留半份): 下次捕获走全量渲染, 绝不静默留一个"看似命中,
        # 实则缺通道"的缓存. 缓存规模本身有界(最多两个组, 各组通道固定), 这里是病态防护.
        _PASS_RAW_CACHE = None
        return
    _PASS_RAW_CACHE = {"groups": groups, "size": size, "notices": list(notices)}


def clear_raw_cache() -> None:
    """清空增量缓存(载入新 .blend 时调用, 防跨文件误用上一份场景的原始字节)"""
    global _PASS_RAW_CACHE
    _PASS_RAW_CACHE = None
