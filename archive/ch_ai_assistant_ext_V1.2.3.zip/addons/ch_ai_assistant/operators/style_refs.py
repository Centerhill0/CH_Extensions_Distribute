"""
参考图引用维护操作模块

纹理面板参考图与效果图风格参考图共用的一组维护算子(按 target 区分):
从磁盘加载,移除列表条目,清空该条目的描述; 引用集合与索引属性名的映射见
operators.image_common 的 REF_TARGET_STATES(单一来源).
"""

import bpy


from bpy.types import Context
from bpy.props import EnumProperty
from bpy.types import Event
from bpy.types import Operator
from bpy.props import StringProperty


from .image_common import any_ref_highlighted
from ..utils import api_error
from ..utils import describe_error
from ..handlers import dump_image_refs
from .image_common import resolve_ref_state
from ..handlers import set_index_after_removal

_REF_TARGET_ITEMS = [
    ('TEXTURE', "Texture", "The texture and image generator panel"),
    ('RENDER', "Render", "The render panel"),
]


def _ref_collection(context: Context, target: str) -> tuple:
    """按 target 取参考图引用的 (状态组, 集合属性名, 索引属性名)

    映射表单一来源见 image_common.REF_TARGET_STATES(纹理参考图 / 效果图风格图).
    """
    return resolve_ref_state(context, target)


class LoadStyleImage(Operator):
    """
    加载参考图操作器

    功能: 从磁盘选择图片加载为图像数据块(同路径复用已有块)并追加到参考图列表末尾;
    纹理面板的参考图随 Generate Texture 发送(模型同纯文生图), 效果图面板的风格参考图
    随 Generate Render 排在通道图之后发送, 每张占一个参考图预算名额
    (最长边超服务商上限时自动缩放副本上传, 原图数据块零改动).
    """

    bl_idname = "ch_ai.load_style_image"
    bl_label = "Load Reference Image"
    bl_description = "Load an image from disk as a reference for AI generation " "(texture panel: sent with the prompt; render panel: sent after the captured passes)"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')  # type: ignore
    target: EnumProperty(name="Target", description="Which panel's reference list to append", items=_REF_TARGET_ITEMS, default='RENDER')  # type: ignore

    def invoke(self, context: Context, _event: Event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        path = self.filepath.strip()
        if not path:
            return {'CANCELLED'}
        try:
            image = bpy.data.images.load(path, check_existing=True)
        except Exception as e:  # noqa: BLE001 - 路径非法/解码失败统一转成可读报告
            self.report({'ERROR'}, describe_error(api_error("Failed to load the image", e)))
            return {'CANCELLED'}
        state, coll_attr, index_attr = _ref_collection(context, self.target)
        ref = getattr(state, coll_attr).add()
        ref.image = image
        # 直接赋值(不走护栏): 沿用"加载即高亮并按面板开关聚焦图像编辑器"的原联动
        setattr(state, index_attr, len(getattr(state, coll_attr)) - 1)
        dump_image_refs()
        return {'FINISHED'}


class ClearStyleDescription(Operator):
    """
    清除参考图描述操作器

    功能: 清空当前高亮参考图的描述(该图的提示词职责声明回落通用措辞);
    描述行行尾的清除按钮调用, 与其它描述行的清除按钮同款.
    """

    bl_idname = "ch_ai.clear_style_description"
    bl_label = "Clear Reference Description"
    bl_description = "Clear the description of the highlighted reference image"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(name="Target", description="Which panel's reference list to clear in", items=_REF_TARGET_ITEMS, default='RENDER')  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return any_ref_highlighted(context)

    def execute(self, context: Context):
        state, coll_attr, index_attr = _ref_collection(context, self.target)
        coll = getattr(state, coll_attr)
        idx = getattr(state, index_attr)
        if not 0 <= idx < len(coll):
            self.report({'WARNING'}, "No reference image selected")
            return {'CANCELLED'}
        coll[idx].description = ""
        dump_image_refs()
        return {'FINISHED'}


class RemoveStyleImage(Operator):
    """
    移除参考图操作器

    功能: 把参考图列表当前高亮的引用移除(只移除列表条目, 不删除图像数据块本身);
    被移除的图不再随生成请求发送.
    """

    bl_idname = "ch_ai.remove_style_image"
    bl_label = "Remove Reference Image"
    bl_description = "Remove the highlighted reference image from the list (the image datablock is kept)"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(name="Target", description="Which panel's reference list to remove from", items=_REF_TARGET_ITEMS, default='RENDER')  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return any_ref_highlighted(context)

    def execute(self, context: Context):
        state, coll_attr, index_attr = _ref_collection(context, self.target)
        coll = getattr(state, coll_attr)
        idx = getattr(state, index_attr)
        if not 0 <= idx < len(coll):
            self.report({'WARNING'}, "No reference image selected")
            return {'CANCELLED'}
        coll.remove(idx)
        # 护栏内压回高亮(移除是结构变动, 不需要"点击行聚焦编辑器"联动)
        set_index_after_removal(state, index_attr, len(coll), idx)
        dump_image_refs()
        return {'FINISHED'}
