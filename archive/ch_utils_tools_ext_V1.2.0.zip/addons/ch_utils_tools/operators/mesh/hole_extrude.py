"""
孔洞挤出操作器模块

提供以下功能:
- HoleExtrude: 将选中的面向内挤出形成孔洞

操作流程:
1. 选择要挤出的面(或闭合的顶点/边环)
2. 拖动鼠标设置挤出深度
3. 调整推拉参数优化结果
4. 确认完成

支持的挤出方向:
- AVERAGE: 平均法线方向
- NORMAL: 各顶点法线方向
- EDGE: 自定义边方向
- CURSOR: 游标轴向

快捷键:
挤出阶段:
- A: 切换到平均法线方向
- N: 切换到各顶点法线方向
- E: 拾取边方向
- C: 切换到游标轴向
- X/Y/Z: 切换游标轴向(仅CURSOR模式)
- R: 重置挤出起点
- 左键/空格: 确认挤出
- 右键/ESC: 取消操作

推拉调整阶段:
- W: 同时调整推和拉
- E: 调整推值
- Q: 调整拉值
- R: 重置推拉值
- S: 切换自相交选项
- A: 切换自动清理
- X: 切换移除冗余边
- Shift: 反向调整
- Ctrl: 加速调整(x100)
- 左键/空格/回车: 完成操作
- 右键/ESC: 返回挤出阶段
"""

__all__ = ["HoleExtrude"]

import logging

import bpy
import bmesh
from bmesh.types import BMesh
from bpy.types import Operator, Context, Event
from mathutils import Vector
from mathutils.geometry import intersect_line_line, intersect_point_line
from bpy.props import FloatProperty, BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d

from .....common.i18n.i18n import iface, report

from ...preference import get_prefs
from ...constants import red, green, blue, white, cyan, yellow, orange, normal, magenta, axis_color_mappings, axis_vector_mappings, ctrl
from ...items import axis_items, extrude_mode_items
from ...utils import (
    DECIMAL_EVENTS_EXT,
    feed_numeric,
    numeric_start_value,
    get_bmesh,
    get_hole_selection,
    build_hole_data,
    update_hole_exit_coords,
    build_hole_extruded_data,
    build_hole_side_data,
    set_hole_extruded_coords,
    apply_hole_push_pull,
    create_hole_geo,
    cleanup_hole_mesh,
    reset_hole_mesh,
    RaycastCache,
    draw_status_item,
    force_statusbar_redraw,
    force_ui_update,
    format_adaptive_precision,
    draw_label,
    draw_line,
    draw_lines,
    draw_point,
    draw_tris,
    draw_vector,
    ignore_events,
    navigation_passthrough,
    get_lerp_position,
    get_length_unit_data,
    Snap,
)
from ...modal_base import ModalOperatorMixin

_logger = logging.getLogger(__name__)


# ============================================================
# 孔洞挤出操作器
# ============================================================
class HoleExtrude(Operator, ModalOperatorMixin):
    """
    孔洞挤出

    功能:将选中的面向内挤出形成孔洞
    - 支持多种挤出方向模式
    - 支持推拉调整优化结果
    - 支持自动网格清理
    - 支持数值输入精确控制

    要求:网格编辑模式下有选中的面或闭合边环
    """

    bl_idname = "ch.hole_extrude"
    bl_label = "Hole Extrude"
    bl_description = "Extrude selected faces into hole"
    bl_options = {'REGISTER', 'UNDO'}

    is_use_self: BoolProperty(name="Is Use Self Intersection", description="Use Self Intersection. Slower but may produce better results.\nIf disabled, you'll often need bigger Push and Pull values.", default=True)  # type: ignore
    mode: EnumProperty(name="Mode", description="Extrude mode", items=extrude_mode_items, default='AVERAGE')  # type: ignore
    cursor_axis: EnumProperty(name="Cursor Axis", description="Cursor Axis", items=axis_items, default='X')  # type: ignore

    depth: FloatProperty(name="Depth", description="Extrude Depth", default=0.5, min=0, precision=4, step=0.1, subtype='DISTANCE')  # type: ignore
    pushed: IntProperty(name="Push", description="Push Side Faces Out", default=1)  # type: ignore
    pulled: IntProperty(name="Pull", description="Pull Side Faces Back", default=1)  # type: ignore

    is_numeric_input: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    numeric_input_amount: StringProperty(name="Numeric Amount to Move Face", description="Amount to Move the Face Selection by", default='0', options={'HIDDEN'})  # type: ignore

    auto_cleanup: BoolProperty(name="Auto Mesh Cleanup", description="Run an automatic mesh cleanup at the end", default=True)  # type: ignore
    remove_redundant: BoolProperty(name="Remove Redundant Edges", description="Remove Redundant Edges", default=True)  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_obj.update_from_editmode()

        # 缓存矩阵数据
        self.act_mx = self.act_obj.matrix_world
        self.cursor_mx = context.scene.cursor.matrix

        # 创建初始bmesh对象
        self.init_bm = bmesh.new()
        self.init_bm.from_mesh(self.act_obj.data)
        self.init_bm.normal_update()

        # 创建bmesh对象
        self.bm = get_bmesh(self.act_obj.data)

        # 不在此预建标记层: 编辑态建层会直接写进网格, 而层的移除只在 cleanup_hole_mesh,
        # 任何取消路径都会把它留在网格上(全 0 的自定义层); 层由 create_hole_geo 在生成阶段 ensure
        self.cache = RaycastCache()  # BVH射线检测缓存, 避免重复构建
        self.is_mesh_non_manifold = False

        selection = self.get_selection(context, self.bm)

        if selection:
            try:
                self.data: dict = build_hole_data(*selection, self.act_mx, self.cursor_mx, axis_vector_mappings)
                update_hole_exit_coords(self.data, self.act_obj, self.cache)
                build_hole_extruded_data(self.data)
                build_hole_side_data(self.data)
            except Exception:
                # invoke 期几何构建即退化: 状态栏/处理器尚未注册, 收敛快照与射线缓存
                # (对照 chamfer.invoke 的兜底与同函数两处早退路径的 cache.clear; 不收敛会泄漏).
                # self.bm 为编辑态共享 BMesh(见 get_bmesh 注), 不可 free, 故不在收敛之列
                _logger.exception("HoleExtrude invoke failed")
                self.report({'ERROR'}, "Hole Extrude failed, see the system console for details")
                self.cache.clear()
                self.init_bm.free()
                self.init_bm = None
                return {'CANCELLED'}

            # 并集字典与三段三角索引在模态期恒定: draw 每帧现算 dict 并集 + 列表拼接是纯浪费
            self.data['all_verts'] = self.data['original_verts'] | self.data['extruded_verts']
            self.data['all_tri_indices'] = self.data['original_tri_indices'] + self.data['extruded_tri_indices'] + self.data['side_tri_indices']

            # 如果没有区域数据,直接执行
            if not context.region_data:
                return self.execute(context)

            self.init_mouse_position(event, hud=True)

            # 获取鼠标位置
            self.depth = 0
            self.set_extrusion_direction(context, 'AVERAGE')

            if not getattr(self, 'init_loc', None):
                # 鼠标视线与挤出方向平行时无交点, 清理资源并中止
                self.cache.clear()
                self.init_bm.free()
                self.report({'WARNING'}, "Mouse ray is parallel to the extrusion direction!")
                return {'CANCELLED'}

            # 初始化其他属性
            self.finalizing = False
            self.cleaned_up_general = 0
            self.cleaned_up_redundant = 0

            self.is_edge_picking = False
            self.edge_coords = None

            self.prev_mode = 'AVERAGE'

            self.is_numeric_input = False
            self.numeric_input_amount = '0'

            # 更新修饰键状态
            self.update_mod_keys()
            # 初始化Snap
            self.S = Snap(context)
            # 初始化状态栏
            self.init_status(context, func=_draw_hole_extrude_status(self))
            # 设置初始header文本
            self.update_header_text(context)
            # 强制UI更新
            force_ui_update(context)
            # 初始化模态处理器
            self.init_modal_handlers(context, hud=True, view3d=True)

            return {'RUNNING_MODAL'}

        # 选区校验失败(get_selection 已给出 warning): 释放独立快照与射线缓存后中止, 泄漏会随误调用累积
        self.cache.clear()
        self.init_bm.free()
        return {'CANCELLED'}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 最小收敛并退出, 否则每个后续事件都抛 AttributeError 且模态永不收敛
            self._abort_without_area(context)
            return {'CANCELLED'}

        try:
            if ignore_events(event):
                return {'RUNNING_MODAL'}

            context.area.tag_redraw()

            if ret := self._numeric_input(context, event):
                return ret

            return self._interactive_input(context, event)
        except Exception:
            # 布尔求解在退化几何上可抛 RuntimeError: 恢复初始网格并收敛模态收尾,
            # 否则异常冲出 modal 后 HUD/状态栏句柄随实例闭包残留(不产生 ReferenceError 故不会被自清理)
            _logger.exception("Hole Extrude modal failed")
            reset_hole_mesh(self.act_obj, self.init_bm)
            self.finish(context)
            self.report({'ERROR'}, report("Hole Extrude failed, see the system console for details"))
            return {'CANCELLED'}

    def _numeric_input(self, context, event):
        if self.finalizing:
            return None
        start = numeric_start_value(event, DECIMAL_EVENTS_EXT)
        if not self.is_numeric_input:
            if start is None:
                return None
            self.is_numeric_input = True
            self.numeric_input_amount = start
            self.update_header_text(context)
            force_ui_update(context)
            return {'RUNNING_MODAL'}

        if event.type in ctrl:
            return {'RUNNING_MODAL'}

        buffer, action = feed_numeric(self.numeric_input_amount, event, DECIMAL_EVENTS_EXT)
        if action != 'ignore':
            self.numeric_input_amount = buffer
            if action == 'cancel':
                self.is_numeric_input = False
                self.update_header_text(context)
                force_ui_update(context)
                return {'RUNNING_MODAL'}
            try:
                # 数字输入按屏幕单位解读, 除以系数还原内部米值(见 get_length_unit_data)
                self.depth = float(buffer) / get_length_unit_data(context)[1]
                self.update_header_text(context)
                force_ui_update(context)
            except ValueError:
                return {'RUNNING_MODAL'}
            self.set_extrusion_amount(context, interactive=False)
            return {'RUNNING_MODAL'}

        if navigation_passthrough(event, alt=True, wheel=True):
            return {'PASS_THROUGH'}
        if event.type in {'RET', 'NUMPAD_ENTER', 'LEFTMOUSE'} and event.value == 'PRESS':
            # 与交互路径同款守卫: 0 深度确认会生成与原选区逐面重合的切割体再交给布尔求解器,
            # 退化输入不应用不确认, 保持模态等有效值
            if self.depth:
                self._apply_extrusion(context, self.bm)
                self.finalizing = True
            return {'RUNNING_MODAL'}
        if event.type == 'ESC' and event.value == 'PRESS':
            self.is_numeric_input = False
            self.update_header_text(context)
            force_ui_update(context)
            return {'RUNNING_MODAL'}
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            self.finish(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _interactive_input(self, context: Context, event: Event):
        """
        处理模态操作期间的交互输入事件

        Args:
            context: Blender上下文对象
            event: 输入事件对象
        """
        # 处理鼠标移动事件
        if event.type == 'MOUSEMOVE':
            self.init_mouse_position(event)

            # 如果之前处于穿透模式,重置初始位置
            if self.pass_through:
                self.pass_through = False
                # 视线与挤出方向平行时无交点: 保持上一初始位置, 避免异常路径把整场重置
                if (loc := self.get_mouse_intersection(context)) is not None:
                    self.init_loc = loc - self.amount_dir * self.depth

        # 非最终化阶段(挤出阶段)
        if not self.finalizing:
            # 边拾取模式切换
            if event.type in ['E', *ctrl]:
                if event.value == 'PRESS':
                    self.is_edge_picking = True
                    self.get_edge_direction(context)
                elif event.value == 'RELEASE':
                    self.is_edge_picking = False

                self.update_header_text(context)
                force_ui_update(context)
                return {'RUNNING_MODAL'}

            # 定义可处理的事件类型
            events = ['MOUSEMOVE', 'A', 'N', 'R', 'C']

            # 光标模式下添加坐标轴切换事件
            if self.mode == 'CURSOR':
                events.extend(['X', 'Y', 'Z'])

            # 处理主要事件
            if event.type in events:
                # 鼠标移动事件
                if event.type == 'MOUSEMOVE':
                    if self.is_edge_picking:
                        self.get_edge_direction(context)
                    else:
                        # 视线与挤出方向平行时无交点: 保持上一深度, 避免异常路径把整场重置
                        if (loc := self.get_mouse_intersection(context)) is not None:
                            self.loc = loc
                            self.set_extrusion_amount(context)

                # 重置初始位置
                elif event.type == 'R' and event.value == 'PRESS':
                    if (loc := self.get_mouse_intersection(context)) is not None:
                        self.init_loc = loc
                        self.set_extrusion_amount(context)

                # 切换挤出方向模式
                elif event.type == 'A' and event.value == 'PRESS':
                    self.set_extrusion_direction(context, direction='AVERAGE')
                    self.set_extrusion_amount(context)

                elif event.type == 'N' and event.value == 'PRESS':
                    self.set_extrusion_direction(context, direction='NORMAL')
                    self.set_extrusion_amount(context)

                elif event.type == 'C' and event.value == 'PRESS':
                    self.set_extrusion_direction(context, direction='CURSOR', init_cursor=True)
                    self.set_extrusion_amount(context)

                # 光标模式下切换坐标轴
                elif event.type in ['X', 'Y', 'Z']:
                    self.cursor_axis = event.type
                    self.set_extrusion_direction(context, direction='CURSOR', init_cursor=False)
                    self.set_extrusion_amount(context)

                self.update_header_text(context)
                force_ui_update(context)

            # 导航穿透事件(视图操作)
            elif navigation_passthrough(event, alt=True, wheel=True):
                self.pass_through = True
                return {'PASS_THROUGH'}

            # 确认挤出操作
            if self.depth and event.type in {'LEFTMOUSE', 'SPACE'} and event.value == 'PRESS':
                self._apply_extrusion(context, self.bm)

                # 进入最终化阶段
                self.finalizing = True
                self.update_header_text(context)
                return {'RUNNING_MODAL'}

            # 取消操作
            elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
                self.finish(context)
                return {'CANCELLED'}

        # 最终化阶段(推拉调整阶段)
        else:
            # 更新修饰键状态
            self.update_mod_keys(event)

            # 定义可处理的事件类型
            events = ['Q', 'W', 'E', 'R', 'S', 'A']

            # 如果启用了自动清理,添加冗余清理切换事件
            if self.auto_cleanup:
                events.append('X')

            # 处理推拉调整事件
            if event.type in events and event.value == 'PRESS':
                # 重置网格到初始状态
                bm = reset_hole_mesh(self.act_obj, self.init_bm, return_bmesh=True)

                # 计算调整因子(Ctrl键加速)
                factor = 100 if self.is_ctrl else 1
                delta = -factor if self.is_shift else factor

                # 使用字典映射处理按键事件
                key_actions = {
                    'W': lambda: (setattr(self, 'pushed', self.pushed + delta), setattr(self, 'pulled', self.pulled + delta)),
                    'E': lambda: setattr(self, 'pushed', self.pushed + delta),
                    'Q': lambda: setattr(self, 'pulled', self.pulled + delta),
                    'R': lambda: (setattr(self, 'pushed', 1), setattr(self, 'pulled', 1)),
                    'S': lambda: setattr(self, 'is_use_self', not self.is_use_self),
                    'A': lambda: setattr(self, 'auto_cleanup', not self.auto_cleanup),
                    'C': lambda: setattr(self, 'auto_cleanup', not self.auto_cleanup),
                    'X': lambda: setattr(self, 'remove_redundant', not self.remove_redundant),
                }

                if event.type in key_actions:
                    key_actions[event.type]()

                # 应用推拉调整
                self._apply_extrusion(context, bm)

                self.update_header_text(context)
                return {'RUNNING_MODAL'}

            # 导航穿透事件
            elif navigation_passthrough(event, alt=True, wheel=True):
                return {'PASS_THROUGH'}

            # 完成操作
            elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                self.finish(context)
                return {'FINISHED'}

            # 返回挤出阶段
            elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
                self.bm = reset_hole_mesh(self.act_obj, self.init_bm, return_bmesh=True)
                self.finalizing = False
                self.pass_through = True
                self.update_header_text(context)
                return {'RUNNING_MODAL'}

        # 默认返回运行状态
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; data 完全由 invoke 的选区解析派生,
        # 且 depth 是 RNA 属性(默认 0.5, 非零), 直调会先进入挤出分支才暴露 data 缺失, 故须在顶部守卫.
        # 不可复入 invoke 重建: invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # invoke 的"无区域数据直接执行"分支(自身调用 execute)已在此前设好 data, 不受此守卫影响;
        # F9 重做走持久实例, data 已存在, 同样不受影响
        if not hasattr(self, "data"):
            self.report({'WARNING'}, "Hole Extrude requires interactive viewport input and cannot be executed directly")
            return {'CANCELLED'}

        self.cleaned_up_general = 0
        self.cleaned_up_redundant = 0

        if self.depth:
            self.act_obj = context.active_object

            if self.mode == 'EDGE' and not self.data['edge_dir']:
                self.mode = 'AVERAGE'  # avoid EDGE mode when an edge dir was never set

            self.bm = bmesh.from_edit_mesh(self.act_obj.data)
            self.bm.normal_update()

            self.set_extrusion_amount(context, interactive=False)

            self._apply_extrusion(context, self.bm)

        return {'FINISHED'}

    def _apply_extrusion(self, context: Context, bm: BMesh):
        """
        应用挤出结果: 推拉坐标 -> 生成几何 -> 布尔差集 -> 清理 -> 同步网格

        Args:
            context: Blender上下文
            bm: 承载挤出的BMesh(模态路径为编辑态共享网格, 推拉重算路径为重置后的新网格)
        """
        self.set_push_and_pull_amount(context)
        create_hole_geo(self.act_obj, bm, self.data)

        # 挤出体与原始网格求差, 得到孔洞
        bpy.ops.mesh.intersect_boolean(operation='DIFFERENCE', use_self=self.is_use_self, solver='EXACT')
        bpy.ops.mesh.select_all(action='DESELECT')

        self.cleaned_up_general, self.cleaned_up_redundant = cleanup_hole_mesh(self.act_obj, generic=self.auto_cleanup, redundant=self.remove_redundant)
        self.act_obj.update_from_editmode()

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 头部文本 -> 刷新 -> 释放资源)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        self.S.finish()
        self.cache.clear()
        self.init_bm.free()
        self.act_obj.update_from_editmode()

        # 取消路径不改网格, 没有 depsgraph 变更可触发重绘, 状态栏会停在退出前最后一帧自绘内容
        # (确认路径靠应用挤出触发重绘, 故只在取消时可见): 规则10 末步强制刷新, 并显式 tag 状态栏区域
        force_ui_update(context)
        force_statusbar_redraw(context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "mode", expand=True)

        # column = layout.column(align=True)
        if self.mode == 'CURSOR':
            row = layout.row(align=True)
            row.prop(self, "cursor_axis", expand=True)

        layout.prop(self, "depth")
        layout.prop(self, "pushed")
        layout.prop(self, "pulled")

        layout.prop(self, "is_use_self")
        layout.prop(self, "auto_cleanup")
        if self.auto_cleanup:
            layout.prop(self, "remove_redundant")
            # 显示清理结果
            column = layout.column(align=True)
            if self.cleaned_up_general:
                info_row = column.row(align=True)
                info_row.alignment = 'RIGHT'
                info_row.label(text=iface("{} verts removed").format(self.cleaned_up_general), icon="INFO")
                info_row.label(text='', icon='CHECKMARK')

            if self.cleaned_up_redundant:
                info_row = column.row(align=True)
                info_row.alignment = 'RIGHT'
                info_row.label(text=iface("{} edges removed").format(self.cleaned_up_redundant), icon="INFO")
                info_row.label(text='', icon='CHECKMARK')

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        # 内部米值乘系数换算成场景单位显示; 数字输入分支显示用户输入原文(本就是屏幕单位值)
        unit_symbol, factor = get_length_unit_data(context)

        if not self.finalizing:
            if self.is_numeric_input:
                text = f"Depth: {self.numeric_input_amount} {unit_symbol}"
            else:
                depth_text = format_adaptive_precision(self.depth * factor, 1)
                text = f"Depth: {depth_text} {unit_symbol}"
        else:
            depth_text = format_adaptive_precision(self.depth * factor, 1)
            text = f"Depth: {depth_text} {unit_symbol} | Push: {self.pushed} | Pull: {self.pulled}"

        context.area.header_text_set(text)

    def draw_HUD(self, context: Context):
        if self.pass_through:
            return

        elif context.area == self.area:
            # 初始化参数
            self.draw_init()
            # 主标题
            dims = draw_label(context, scale=self.hud_scale, title=iface("Hole Extrude"), coords=Vector((self.HUD_x, self.HUD_y)), offset=0, center=False, alpha=0.5, init_obj=self)

            if not self.finalizing:

                if self.is_edge_picking:
                    draw_label(context, scale=self.hud_scale, title=iface("Pick Direction"), coords=Vector((self.HUD_x + dims.x + 15, self.HUD_y)), offset=0, center=False, init_obj=self)

                    self.offset += 18
                    dims = draw_label(context, scale=self.hud_scale, title=iface("Edge:"), coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, alpha=0.5)
                    title, color, alpha = (iface("Valid"), yellow, 1) if self.edge_coords and self.data['edge_dir'] else (iface("Invalid"), red, 1) if self.edge_coords else (iface("None"), white, 0.5)

                    draw_label(context, scale=self.hud_scale, title=title, coords=Vector((self.HUD_x + dims.x, self.HUD_y)), offset=self.offset, center=False, color=color, alpha=alpha, init_obj=self)

                else:
                    draw_label(context, scale=self.hud_scale, title=iface("Extrude"), coords=Vector((self.HUD_x + dims.x + 15, self.HUD_y)), offset=0, center=False, init_obj=self)

                    self.offset += 18
                    dims = draw_label(context, scale=self.hud_scale, title=iface("Along:"), coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, alpha=0.5, init_obj=self)
                    if self.mode == 'CURSOR':
                        dims += draw_label(context, scale=self.hud_scale, title=iface(self.mode.title()) + " ", coords=Vector((self.HUD_x + dims.x + 12, self.HUD_y)), offset=self.offset, center=False, color=magenta, init_obj=self)
                        draw_label(context, scale=self.hud_scale, title=self.cursor_axis, coords=Vector((self.HUD_x + dims.x + 20, self.HUD_y)), offset=self.offset, center=False, color=axis_color_mappings[self.cursor_axis], init_obj=self)

                    else:
                        mode_colors = {
                            'EDGE': yellow,
                            'AVERAGE': green,
                            'NORMAL': cyan,
                        }
                        color = mode_colors.get(self.mode, white)
                        draw_label(context, scale=self.hud_scale, title=iface(self.mode.title()), coords=Vector((self.HUD_x + dims.x + 12, self.HUD_y)), offset=self.offset, center=False, color=color, init_obj=self)

            else:
                draw_label(context, scale=self.hud_scale, title=iface("Finish"), coords=Vector((self.HUD_x + dims.x + 15, self.HUD_y)), offset=0, center=False, init_obj=self)

                self.offset += 18
                draw_label(
                    context,
                    scale=self.hud_scale,
                    title=iface("Use Self Intersection: {}").format(iface("True") if self.is_use_self else iface("False")),
                    coords=Vector((self.HUD_x, self.HUD_y)),
                    offset=self.offset,
                    center=False,
                    color=cyan,
                    init_obj=self,
                )

                if self.auto_cleanup:
                    self.offset += 18
                    dims = draw_label(context, scale=self.hud_scale, title=iface("Auto Cleanup:"), coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=orange, init_obj=self)

                    if self.cleaned_up_general:
                        draw_label(
                            context,
                            scale=self.hud_scale,
                            title=iface("{} Verts Removed ✔️").format(self.cleaned_up_general),
                            coords=Vector((self.HUD_x + dims.x + 5, self.HUD_y)),
                            offset=self.offset,
                            center=False,
                            size=self.size - 2,
                            color=white,
                            init_obj=self,
                        )
                    else:
                        draw_label(context, scale=self.hud_scale, title=iface("None"), coords=Vector((self.HUD_x + dims.x, self.HUD_y)), offset=self.offset, center=False, size=self.size - 2, color=white, alpha=0.5, init_obj=self)

                    self.offset += 18

                    color, alpha = (orange, 1) if self.remove_redundant else (white, 0.5)
                    redundant_text = iface("Redundant:")
                    draw_label(
                        context,
                        scale=self.hud_scale,
                        title=redundant_text,
                        coords=Vector((self.HUD_x + dims.x - self.get_text_dimensions(redundant_text, self.font_id, self.size).x, self.HUD_y)),
                        offset=self.offset,
                        center=False,
                        color=color,
                        alpha=alpha,
                        init_obj=self,
                    )

                    if self.cleaned_up_redundant:
                        draw_label(
                            context,
                            scale=self.hud_scale,
                            title=iface("{} Edges Removed ✔️").format(self.cleaned_up_redundant),
                            coords=Vector((self.HUD_x + dims.x + 5, self.HUD_y)),
                            offset=self.offset,
                            center=False,
                            size=self.size - 1,
                            color=white,
                            init_obj=self,
                        )
                    else:
                        draw_label(context, scale=self.hud_scale, title=iface("None"), coords=Vector((self.HUD_x + dims.x + 5, self.HUD_y)), offset=self.offset, center=False, size=self.size - 1, color=white, alpha=0.5, init_obj=self)

                if self.is_mesh_non_manifold:
                    self.offset += 24
                    draw_label(context, scale=self.hud_scale, title=iface("Non-manifold meshes tend to require higher Push/Pull values"), coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=orange, init_obj=self)

                    self.offset += 18
                    draw_label(context, scale=self.hud_scale, title=iface("and may still produce undesired results"), coords=Vector((self.HUD_x, self.HUD_y)), offset=self.offset, center=False, color=orange, init_obj=self)

    def draw_VIEW3D(self, context: Context):
        """在3D视图中绘制孔洞挤出的可视化辅助信息"""
        if context.area == self.area:
            data = self.data
            orig_verts = data['original_verts']
            extr_verts = data['extruded_verts']

            if self.finalizing:
                # 挤出完成后显示最终三角面,侧面和边界
                tri_coords = [orig_verts[idx].co for idx in data['original_tri_indices']]
                draw_tris(tri_coords, mx=self.act_mx, color=green, alpha=0.05, xray=False)

                tri_coords = [data['all_verts'][idx].co for idx in data['side_tri_indices']]
                draw_tris(tri_coords, mx=self.act_mx, color=blue, alpha=0.05, xray=False)

                boundary_coords = [orig_verts[vidx].co for vidx in data['sorted_boundary']]
                draw_line(boundary_coords, indices=data['sorted_boundary_indices'], mx=self.act_mx, color=white, alpha=0.05)

                extr_boundary_coords = [extr_verts[data['vert_map'][vidx]].co for vidx in data['sorted_boundary']]
                draw_line(extr_boundary_coords, indices=data['sorted_boundary_indices'], mx=self.act_mx, color=white, alpha=0.05)

                side_line_coords = [data['all_verts'][idx].co for vidx in data['sorted_boundary'] for idx in [vidx, data['vert_map'][vidx]]]
                draw_lines(side_line_coords, mx=self.act_mx, color=white, alpha=0.05)

            else:
                # 挤出预览与动态辅助
                avg_co = self.act_mx @ data['avg_co']
                edge_dir = data['edge_dir']

                # 平均中心点
                draw_point(avg_co, color=red if self.depth == 0 else white)

                if self.depth:
                    # 挤出方向向量
                    extr_dir = self.loc - self.init_loc
                    draw_vector(extr_dir, origin=avg_co, fade=True, alpha=0.5)
                    draw_point(avg_co + extr_dir, size=4, alpha=0.5)

                    # 所有三角面预览
                    tri_coords = [data['all_verts'][idx].co for idx in data['all_tri_indices']]
                    draw_tris(tri_coords, mx=self.act_mx, color=green, alpha=0.1)

                    # 挤出后边界线
                    extr_boundary_coords = [extr_verts[data['vert_map'][vidx]].co for vidx in data['sorted_boundary']]
                    draw_line(extr_boundary_coords, indices=data['sorted_boundary_indices'], mx=self.act_mx, color=green, alpha=0.2)

                    # 侧边连线(根据模式变色)
                    mode_colors = {
                        'EDGE': (yellow, 0.5),
                        'AVERAGE': (blue, 1),
                        'CURSOR': (axis_color_mappings[self.cursor_axis], 1),
                        'NORMAL': (normal, 1),
                    }
                    color, alpha_val = mode_colors.get(self.mode, (normal, 1))
                    side_line_coords = [data['all_verts'][idx].co for vidx in data['sorted_boundary'] for idx in [vidx, data['vert_map'][vidx]]]
                    draw_lines(side_line_coords, mx=self.act_mx, color=color, alpha=alpha_val)

                # 边选取高亮
                if self.is_edge_picking and self.edge_coords:
                    color = yellow if self.edge_coords and edge_dir else red
                    draw_line(self.edge_coords, color=color, width=2, alpha=0.99)

                # 出口点连线
                exit_coords = [orig_verts[vidx].exit_co for vidx in data['sorted_boundary'] if orig_verts[vidx].exit_co]
                if exit_coords:
                    exit_coords.append(exit_coords[0])
                    draw_line(exit_coords, mx=self.act_mx, alpha=0.1)

    def get_selection(self, context: Context, bm: BMesh):
        """
        解析挤出目标: 非流形网格按偏好拦截, 其余选择解析交由算法层

        Args:
            context: Blender上下文
            bm: BMesh对象

        Returns:
            tuple: (faces, loop_triangles, sorted_boundary_verts, inner_verts) 或 None
        """
        # 非流形网格按偏好拦截(偏好读取留在交互层)
        self.is_mesh_non_manifold = not all(e.is_manifold for e in bm.edges)

        if self.is_mesh_non_manifold and not get_prefs().non_manifold_extrude:
            self.report({'WARNING'}, "Mesh is Non-manifold, try enabling non-manifold mesh support in the addon preferences")
            return

        selection, err = get_hole_selection(bm)

        if err:
            self.report({'WARNING'}, err)
            return

        return selection

    def set_extrusion_direction(self, context: Context, direction='AVERAGE', init_cursor=False):
        """
        设置挤出方向并初始化相关参数

        Args:
            context: Blender上下文对象
            direction: 挤出方向模式,可选值: 'AVERAGE', 'NORMAL', 'EDGE', 'CURSOR'
            init_cursor: 是否初始化游标方向(仅 CURSOR 模式有效)
        """
        # 设置当前模式
        self.mode = direction

        # 计算挤出起点和方向
        if direction in ['AVERAGE', 'NORMAL']:
            # 使用平均法线方向
            self.amount_origin = self.act_mx @ self.data['avg_co']
            self.amount_dir = self.act_mx.to_3x3() @ self.data['avg_dir']

        elif direction == 'EDGE':
            # 使用边界方向
            self.amount_origin = self.act_mx @ self.data['edge_co']
            self.amount_dir = self.act_mx.to_3x3() @ self.data['edge_dir']

        elif direction == 'CURSOR':
            # 使用光标方向
            self.amount_origin = self.act_mx @ self.data['avg_co']

            if init_cursor:
                # 初始化光标方向:选择与平均法线最对齐的坐标轴
                cursor_dirs = [(axis, self.data[f"cursor_dir_{axis.lower()}"].dot(self.data['avg_dir']), self.data[f"cursor_dir_{axis.lower()}"]) for axis, _, _ in axis_items]

                # 选择点积最大的轴(最对齐的轴)
                aligned = max(cursor_dirs, key=lambda x: x[1])

                self.amount_dir = self.act_mx.to_3x3() @ aligned[2]
                self.cursor_axis = aligned[0]
            else:
                # 使用已选择的光标轴
                self.amount_dir = self.act_mx.to_3x3() @ self.data[f"cursor_dir_{self.cursor_axis.lower()}"]

        # 获取鼠标交点并设置初始位置
        intersection = self.get_mouse_intersection(context)

        if intersection:
            # 计算挤出起点(考虑当前挤出量)
            self.init_loc = intersection - self.amount_dir * self.depth
            self.loc = intersection

        # 计算出口坐标
        update_hole_exit_coords(self.data, self.act_obj, self.cache, direction=direction, cursor_axis=self.cursor_axis)

    def set_extrusion_amount(self, context: Context, interactive=True):
        """
        设置挤出量并更新挤出顶点坐标

        Args:
            context: Blender上下文
            interactive: 是否为交互模式(如鼠标拖动)
        """
        if interactive:
            # 交互模式下,根据鼠标移动方向和距离计算挤出量
            amount_vector = self.loc - self.init_loc
            # 只有当移动方向与挤出方向一致时才允许挤出,否则为0
            self.depth = amount_vector.length if amount_vector.dot(self.amount_dir) > 0 else 0

        if self.depth > 0:
            set_hole_extruded_coords(self.data, self.depth, self.mode, self.cursor_axis)
        else:
            # 挤出量为0,重置初始位置; 视线与挤出方向平行时交点为 None, 保持原 init_loc
            # (None 会在下次 mousemove 的 loc - init_loc 处抛 TypeError 中止整场操作)
            intersection = self.get_mouse_intersection(context)
            if intersection is not None:
                self.init_loc = intersection
                self.loc = self.init_loc

    def set_push_and_pull_amount(self, context: Context):
        """
        根据推拉参数调整顶点坐标, 实现侧面推挤和拉回效果

        Args:
            context: Blender上下文
        """
        apply_hole_push_pull(self.data, self.depth, self.pushed, self.pulled, self.mode, self.cursor_axis)

    def get_mouse_intersection(self, context: Context):
        """
        获取鼠标位置与挤出方向线的交点

        Args:
            context: Blender上下文对象

        Returns:
            Vector: 交点的3D坐标,如果没有找到交点则返回 None
        """
        try:
            # 获取视图原点和视图方向向量
            view_origin = region_2d_to_origin_3d(context.region, context.region_data, self.mouse_region_pos)
            view_dir = region_2d_to_vector_3d(context.region, context.region_data, self.mouse_region_pos)

            # 计算交点, 视线与方向线平行时返回 None
            intersection = intersect_line_line(self.amount_origin, self.amount_origin + self.amount_dir, view_origin, view_origin + view_dir)
            return intersection[0] if intersection else None

        except Exception:
            return None

    def get_edge_direction(self, context: Context):
        """
        获取鼠标点击的边方向,用于 EDGE 模式下的挤出方向

        Args:
            context: Blender上下文对象
        """
        # 获取鼠标点击信息
        self.S.update_hit(self.mouse_region_pos)

        # 如果不是EDGE模式,保存当前模式以便回退
        if self.mode != 'EDGE':
            self.prev_mode = self.mode

        # 如果点击有效
        if self.S.hit:
            hitmx = self.S.hit_mx
            hit_co = hitmx.inverted_safe() @ self.S.hit_location
            hitface = self.S.hit_face

            # 找到点击的边:计算每条边到点击点的距离,选择最近的边
            edge = min([(e, (hit_co - intersect_point_line(hit_co, e.verts[0].co, e.verts[1].co)[0]).length, (hit_co - get_lerp_position(*e.verts)).length) for e in hitface.edges if e.calc_length()], key=lambda x: (x[1] * x[2]) / x[0].calc_length())

            # 计算边方向
            edge_dir = (edge[0].verts[1].co - edge[0].verts[0].co).normalized()

            # 保存边坐标(世界空间)
            self.edge_coords = [hitmx @ v.co for v in edge[0].verts]

            # 计算点击点在边上的最近点
            closest_point_on_edge = intersect_point_line(hit_co, edge[0].verts[0].co, edge[0].verts[1].co)[0]

            # 如果点击的不是活动对象,需要转换坐标系
            if self.S.hit_obj != self.act_obj:
                edge_dir = self.act_mx.inverted_safe().to_3x3() @ hitmx.to_3x3() @ edge_dir
                closest_point_on_edge = self.act_mx.inverted_safe() @ hitmx @ closest_point_on_edge

            # 计算边方向与平均法线的点积
            dot = edge_dir.dot(self.data['avg_dir'])

            # 确保边方向与平均法线方向一致
            if dot < 0:
                edge_dir.negate()

            # 检查边方向是否与平均法线垂直(无效方向)
            if round(dot, 4) == 0:
                self.data['edge_dir'] = None
            else:
                # 设置有效的边方向
                self.data['edge_co'] = closest_point_on_edge
                self.data['edge_dir'] = edge_dir

                # 切换到EDGE模式并设置挤出量
                self.set_extrusion_direction(context, direction='EDGE')
                self.set_extrusion_amount(context)
                return

        else:
            # 没有点击到有效对象,清除边数据
            self.edge_coords = None
            self.data['edge_dir'] = None

        # 回退到之前的模式
        self.mode = self.prev_mode

        # 重新设置挤出方向和挤出量
        self.set_extrusion_direction(context, direction=self.mode)
        self.set_extrusion_amount(context)


def _draw_hole_extrude_status(op: HoleExtrude):
    """
    HoleExtrude状态栏绘制函数

    Args:
        op: HoleExtrude 操作器实例

    Returns:
        状态栏绘制函数
    """

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        if not op.finalizing:
            if op.is_numeric_input:
                draw_status_item(row, key='LMB', text="Confirm")
                draw_status_item(row, key='MMB', text="Viewport Navigation")
                draw_status_item(row, key='RMB', text="Cancel")
            else:
                if op.is_edge_picking:
                    prop = "Valid" if op.edge_coords and op.data['edge_dir'] else "invalid" if op.edge_coords else "None"
                    draw_status_item(row, active=prop == "Valid", key='MOVE', text=iface("Pick Direction"), prop=iface(prop), gap=3)
                else:
                    draw_status_item(row, key='LMB', text="Confirm")
                    draw_status_item(row, key='MMB', text="Viewport Navigation")
                    draw_status_item(row, key='RMB', text="Cancel")

                    if op.depth:
                        draw_status_item(row, key='R', text="Reset", gap=1)

                    draw_status_item(row, text="Extrusion Direction", gap=3)
                    draw_status_item(row, active=op.mode == 'AVERAGE', key='A', text="Average")
                    draw_status_item(row, active=op.mode == 'EDGE', key='E', text="Edge")
                    draw_status_item(row, active=op.mode == 'NORMAL', key='N', text="Normal")
                    draw_status_item(row, active=op.mode == 'CURSOR', key='C', text="Cursor")

                    if op.mode == 'CURSOR':
                        draw_status_item(row, active=op.cursor_axis == 'X', key='X', gap=1)
                        draw_status_item(row, active=op.cursor_axis == 'Y', key='Y')
                        draw_status_item(row, active=op.cursor_axis == 'Z', key='Z')
                        draw_status_item(row, text='Axis')
        else:
            draw_status_item(row, key='LMB', text="Finish")
            draw_status_item(row, key='MMB', text="Viewport Navigation")
            draw_status_item(row, key='RMB', text="Go Back")

            draw_status_item(row, active=op.is_use_self, key='S', text="Use Self", gap=3)
            draw_status_item(row, active=op.auto_cleanup, key='A', text="Auto Mesh Cleanup")
            if op.auto_cleanup:
                draw_status_item(row, active=op.remove_redundant, key='X', text="Remove Redundant Edges")

            draw_status_item(row, text="Push and Pull", gap=3)
            draw_status_item(row, active=op.is_shift, key='SHIFT', text="Invert")
            draw_status_item(row, active=op.is_ctrl, key='CTRL', text="x 100")
            draw_status_item(row, key='W', text="Both")
            draw_status_item(row, key='Q', text="Pull")
            draw_status_item(row, key='E', text="Push")
            draw_status_item(row, key='R', text="Reset", gap=1)

    return draw
