"""
键位注册引擎(供各插件 keymaps.py 共用)

表数据(keymap_items/group_labels)与门面函数(register_keymaps/unregister_keymaps)
留各插件: 键位表是插件资产, 引擎只负责"建映射/建条目/设属性/失效句柄容错"的
通用机制——这些实测知识(幂等清旧代条目防重复触发,失效句柄须吞 ReferenceError,
finally 清空存储,标签先译后加缩进)此前在 ch_utils_tools 与 ch_scene_helper
各写一份, 修 bug 要打两遍.
"""

import bpy

from ..i18n.i18n import iface


def register_keymap_table(items: dict, group_labels: dict, storage: dict) -> None:
    """按表注册键位, 结果写入 storage(键 = 分组显示名, 值 = [(标签, KeyMap, KeyMapItem), ...])

    幂等性由调用方保证(入口先注销上一代), 本函数只做增量注册.
    """
    kc = bpy.context.window_manager.keyconfigs.addon
    if not kc:
        return

    for km_name, km_entries in items.items():
        entries = []

        for entry in km_entries:
            # 创建键映射
            km = kc.keymaps.new(name=entry['keymaps_name'], space_type=entry.get('space_type', 'EMPTY'))

            # 创建键映射项
            kmi = km.keymap_items.new(
                idname=entry['id_name'],
                type=entry['type'],
                value=entry['value'],
                shift=entry.get('shift', False),
                ctrl=entry.get('ctrl', False),
                alt=entry.get('alt', False),
            )

            # 设置操作属性(如菜单名称)
            if 'properties' in entry:
                for prop, value in entry['properties'].items():
                    setattr(kmi.properties, prop, value)

            # 格式化显示标签(先取译文再加缩进: 前导空格会使 Blender 的精确匹配翻译失效)
            display_label = ' ' * 6 + iface(entry['label'])
            entries.append((display_label, km, kmi))

        # 分组显示名(显式声明见调用方 group_labels; 未声明者回退为组键生成名)
        storage[group_labels.get(km_name, km_name.capitalize().replace('_', ' '))] = entries


def unregister_keymap_storage(storage: dict) -> None:
    """注销 storage 内全部键位并清空

    注意: KeyMapItem/KeyMap 被移除后再访问会抛 ReferenceError(而非 RuntimeError/KeyError),
    用户在偏好"快捷键"页删掉任一条目后即产生这种失效句柄; 必须一并吞掉该异常,
    且清空放在 finally 中 —— 否则字典残留失效句柄, 之后每次禁用都在同一条目再次抛错,
    插件再也无法干净禁用.
    """
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        if not kc:
            return

        for _, entries in storage.items():
            for _, km, kmi in entries:
                try:
                    km.keymap_items.remove(kmi)
                except (RuntimeError, KeyError, ReferenceError):
                    pass
    finally:
        # 清空存储字典(无论移除是否成功, 都不能留下失效句柄)
        storage.clear()
