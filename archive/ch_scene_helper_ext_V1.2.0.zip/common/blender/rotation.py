"""
按对象 rotation_mode 写入旋转的工具(通用)

Blender 的旋转按 rotation_mode 生效: 四元数/轴角/欧拉的存储形态各不相同, 且轴角
属性的元组顺序是 (angle, x, y, z)——与 Quaternion.to_axis_angle() 的 (axis, angle)
返回相反, 直接转发会写出翻转的旋转(此前 ch_scene_helper 灯瞄准的轴角档即此误序,
被欧拉/四元数档的默认光标模式掩盖).
"""

from mathutils import Quaternion


def set_rotation_by_mode(obj, rot: Quaternion) -> None:
    """按对象自身的 rotation_mode 写入旋转(四元数/轴角/欧拉各自对号)

    适用于具备 rotation_mode/rotation_quaternion/rotation_axis_angle/rotation_euler
    四同构属性的对象(物体与 3D 游标皆可).
    """
    if obj.rotation_mode == 'QUATERNION':
        obj.rotation_quaternion = rot
    elif obj.rotation_mode == 'AXIS_ANGLE':
        # to_axis_angle 返回 (axis, angle), 而属性要求 (angle, x, y, z), 顺序需重排
        axis, angle = rot.to_axis_angle()
        obj.rotation_axis_angle = (angle, axis.x, axis.y, axis.z)
    else:
        obj.rotation_euler = rot.to_euler(obj.rotation_mode)
