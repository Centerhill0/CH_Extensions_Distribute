"""
快捷键管理模块

提供以下功能:
- 定义插件的快捷键配置
- 注册和注销快捷键映射

快捷键分组:

饼菜单
- CAMERA_PIE: 相机饼菜单 (Alt + C)
- LIGHT_PIE: 灯光饼菜单 (Alt + L)

独立算子
- LIGHT_RIG: 灯光控制模态 (L; 选区里有 rig 或活跃灯光行带控制器时接管, 其余情形原生命令照常)
"""

from bpy.types import KeyMap, KeyMapItem

from ...common.blender.keymaps import register_keymap_table, unregister_keymap_storage

# ============================================================
# 快捷键配置数据
# ============================================================
# 分组显示名(偏好设置快捷键列表用): 由组键生成的名称("Camera Pie")是运行时字符串,
# 无法入典, 故在此显式声明; 饼菜单组须保留 "Pie" 结尾(偏好设置按此分列)
group_labels: dict[str, str] = {
    'CAMERA_PIE': "Camera Pie",
    'LIGHT_PIE': "Light Pie",
    'LIGHT_RIG': "Light Rig",
}

keymap_items: dict[str, list[dict[str, object]]] = {
    # 相机辅助饼菜单 (Alt + C)
    'CAMERA_PIE': [
        {'label': 'Object', 'keymaps_name': '3D View', 'space_type': 'VIEW_3D', 'id_name': 'wm.call_menu_pie', 'type': 'C', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_camera_pie"}},
    ],
    # 灯光饼菜单 (Alt + L)
    'LIGHT_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'L', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_light_pie"}},
    ],
    # 灯光控制模态 (L): poll 限定"选区里有 rig 或活跃灯光行带控制器", 其余情形原生 L 命令照常
    'LIGHT_RIG': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': "ch.light_rig_adjust", 'type': 'L', 'value': 'PRESS'},
    ],
}

# 已注册的快捷键存储字典
# 格式: {分组名: [(显示标签, KeyMap, KeyMapItem), ...]}
addon_keymaps: dict[str, list[tuple[str, KeyMap, KeyMapItem]]] = {}


# ============================================================
# 快捷键注册/注销函数
# ============================================================


def register_keymaps() -> None:
    """
    注册插件的快捷键

    遍历 keymap_items 配置,为每个条目创建键映射和键映射项,
    并存储到 addon_keymaps 字典中以便后续注销.

    幂等: 入口先清掉上一代条目. addon_keymaps 按分组名覆盖写入,
    若不清上一代, 旧 KeyMapItem 会失去句柄但仍在 keyconfigs.addon 中继续生效,
    造成同一快捷键触发多次且再也无法注销.
    """
    unregister_keymaps()
    register_keymap_table(keymap_items, group_labels, addon_keymaps)


def unregister_keymaps() -> None:
    """
    注销插件的快捷键: 移除 addon_keymaps 内全部键映射项并清空存储字典
    (失效句柄容错与 finally 清空的必要性见 common 键位引擎 docstring)
    """
    unregister_keymap_storage(addon_keymaps)
