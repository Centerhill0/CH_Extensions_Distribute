"""
场景助手列表与面板状态模块

提供以下功能:
- SceneHelperState: 六个资源列表的快照集合与活跃索引,选区同步/0 用户开关,
  行内列显示开关,详情子面板展开态与 PBR 镜像枚举
- CameraResolutionSettings / SceneResolutionState: 相机独立分辨率(挂物体)与
  场景侧覆写状态(挂场景), 随 .blend 保存
- LightAdvancedSettings: 灯光高级设置状态(挂灯光数据块), 任一项变化统一重接
  灯光节点树的 Emission 接线(算法见 utils/blender/light_advanced.py)
- WorldEnvSettings: 世界环境设置状态(挂世界数据块, 随 .blend 保存)
- 材质 PBR 镜像枚举的 update 回调: 坐标输出重建接线 / 投影与融合统一写全部命中纹理
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载(WM 级不随 .blend 保存;
  物体/场景级随 .blend 保存)
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot

注: 单一状态组覆盖全部六个列表; 列表种类元数据见 scene_state.LIST_SPECS.
"""

from bpy.props import BoolProperty, BoolVectorProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty
from bpy.types import Context, PropertyGroup

from contextlib import contextmanager

from ...common.blender.list_snapshot import ListItem, is_syncing
from .handlers import on_images_index_update, on_list_scope_update, on_sync_toggle, tag_3d_views
from .preference import online_manifest_library, resolve_library_root
from .scene_state import LIST_SPECS, ONLINE_SPEC_FIELDS, panel_light, panel_material, stored_pick_key
from .utils import (
    ARRAY_MODE_RECT,
    ARRAY_MODE_RING,
    MARK_IMAGE_ARRAY,
    MARK_IMAGE_TEX,
    MARK_IES_TEX,
    MARK_WORLD_ENV_HDRI_SETTING,
    MARK_WORLD_ENV_HDRI_TEX,
    MARK_WORLD_ENV_REPLACE_RAMP_SWITCH,
    MARK_WORLD_ENV_REPLACE_SWITCH,
    apply_light_advanced_wiring,
    apply_light_isolate_world_mute,
    collection_objects_recursive,
    disconnect_world_env_chain,
    ensure_world_env_chain,
    ensure_world_replace_chain,
    existing_source,
    find_advanced_node,
    find_or_load_image,
    find_pbr_nodes,
    find_world_env_node,
    import_pbr_pack,
    init_camera_resolution_from_scene,
    is_pbr_mirror_suppressed,
    pbr_chain_textures,
    is_light_rig_sync_suppressed,
    light_collections_isolated,
    lights_viewport_isolated,
    list_assets,
    list_categories,
    preview_icon_id,
    resolve_category,
    resolve_option,
    rig_controller_of,
    reset_light_self_rotation,
    select_only,
    set_active_collection,
    set_controller_azimuth,
    set_controller_elevation,
    set_light_distance,
    set_light_self_rotation,
    set_pbr_uv_output,
    sync_active_camera_resolution,
)
from .utils._constants import CAMERA_RES_MAX, PROJECTION_OPTIONS, RIG_DEFAULT_DISTANCE, RIG_DEFAULT_ELEVATION, TEXCOORD_OPTIONS

# 自旋转镜像的默认值(0 = 无自转): 属性 default 与"恢复默认值即重新瞄准"的判据共用,
# 改一处即两处同步
_RIG_SELF_ROTATION_DEFAULT = 0.0

# "灯光&阴影链接"子面板的三模式(灯光面板详情区): 前两档编辑面板活跃灯光的链接集合,
# 第三档反查视口活动物体被哪些灯链接. 条目名为系统词条(Light/Shadow Linking 命中
# 原生面板标题)不入插件词典
LIGHT_LINKING_MODES = (
    ('LIGHT_LINKING', "Light Linking", "Edit which objects receive light from the active light of the Lights panel"),
    ('SHADOW_LINKING', "Shadow Linking", "Edit which objects cast shadows for the active light of the Lights panel"),
    ('OBJECT_LINKING', "Object Linking", "Look up which lights light-link or shadow-link the active object"),
)

# 高级设置的一级模块候选: 四项统一绘制("无"=不激活, 激活按钮已从标题栏移除),
# 灯型校验下沉到面板各档的提示行(渐变/图像=面光/聚光, IES=点光, 太阳光整块提示).
# 标签用 "Gradient Module" 反译规避: "Gradient" 命中系统 mo("梯度渐变"), 需显示"渐变";
# "None"/"Image" 为系统词条(无/图像), "IES" 为专有名词, 均不入典
ADVANCED_MODE_ITEMS = (
    ('NONE', "None", "Deactivate the advanced settings (no module drives the light)"),
    ('GRADIENT', "Gradient Module", "Drive the emission with a procedural gradient (radial, linear or softbox)"),
    ('IMAGE', "Image", "Project an image through the light"),
    ('IES', "IES", "Shape the light intensity with an IES profile"),
)


# 渐变二级模式: 三种模板节点组的候选(与 light_advanced 模板的类型串一致)
GRADIENT_TYPE_ITEMS = (
    ('RADIAL', "Radial", "Spherical falloff from the center of the light"),
    ('LINEAR', "Linear", "Linear falloff along a rotatable axis, tilable by the array factor"),
    ('SOFTBOX', "Softbox", "Crossed sine stripes like a softbox grid, tilable in X and Y"),
)

# 图像档接线目标: 颜色=彩色投影(默认), 强度=灰度图调制亮度("Color"/"Strength" 均系统词条不入典)
IMAGE_TARGET_ITEMS = (
    ('COLOR', "Color", "Texture drives the emission color"),
    ('STRENGTH', "Strength", "Texture drives the emission strength (for grayscale maps)"),
)

# 图像档阵列方式: 矩形平铺 / 环形阵列(写阵列坐标组的阵列方式插座, 见 on_image_array_mode_update)
IMAGE_ARRAY_MODE_ITEMS = (
    ('RECT', "Rect", "Rectangular tiling of the projected texture"),
    ('RING', "Ring", "Ring array of the projected texture around the center"),
)

# 世界环境设置的三模式(世界面板"环境设置"子面板的胶囊按钮, 模式体逐档实现):
# "Basic" 系统 * 语境译"基本", Operator 语境空缺, 按钮标签走 Operator 语境故入典;
# "HDRI" 为专有名词不入典; "Procedural Texture" 整句避开系统词条
ENV_MODE_ITEMS = (
    ('BASIC', "Basic", "Plain color or other built-in world settings (default)"),
    ('HDRI', "HDRI", "Light the scene with an HDRI environment image"),
    ('PROCEDURAL', "Procedural Texture", "Build the environment lighting from procedural texture nodes"),
)

# 替换背景的档位(世界面板"替换背景"子面板): "Solid" 命中系统 mo(实体)错义改用
# "Solid Color" 整句, "Gradient" 命中系统 mo(梯度渐变)错义改用 "Color Gradient"
REPLACE_MODE_ITEMS = (
    ('SOLID', "Solid Color", "Replace the camera background with a plain color"),
    ('GRADIENT', "Color Gradient", "Replace the camera background with a gradient between two colors"),
)

# 环境调节组镜像字段 -> HDRI Setting 组实例的输入插座名(镜像绘制与统一写回共用;
# 组实例插座的 RNA 不带接口的子类型与范围, 滑条会退化成裸数字, 故经镜像字段绘制)
_ENV_FIELD_SOCKETS = (
    ('env_exposure', "Exposure"),
    ('env_hue', "Hue"),
    ('env_saturation', "Saturation"),
    ('env_gamma', "Gamma"),
    ('env_highlight_boost', "高光增益"),
    ('env_tint', "Tint"),
    ('env_tint_factor', "着色强度"),
)

# 环境调节组镜像的抑制位: 绘制期真值 -> 镜像回写不触发 update 写回插座
_ENV_MIRROR_SYNCING = False


@contextmanager
def _suppress_env_mirror():
    """环境调节组镜像回写的抑制器(绘制期真值读进镜像时跳过 update 写回)"""
    global _ENV_MIRROR_SYNCING
    _ENV_MIRROR_SYNCING = True
    try:
        yield
    finally:
        _ENV_MIRROR_SYNCING = False


# 替换背景开关镜像的抑制位: 绘制期节点真值 -> 镜像回写不触发 update 写回节点
_REPLACE_TOGGLE_SYNCING = False


@contextmanager
def _suppress_replace_toggle():
    """替换背景开关镜像回写的抑制器(绘制期真值读进镜像时跳过 update 写回)"""
    global _REPLACE_TOGGLE_SYNCING
    _REPLACE_TOGGLE_SYNCING = True
    try:
        yield
    finally:
        _REPLACE_TOGGLE_SYNCING = False


# 灯光高级设置开关镜像的抑制位: 绘制期模式真值 -> 镜像回写不触发 update 写回
_LIGHT_ADV_TOGGLE_SYNCING = False


@contextmanager
def _suppress_light_adv_toggle():
    """灯光高级设置开关镜像回写的抑制器(绘制期真值读进镜像时跳过 update 写回)"""
    global _LIGHT_ADV_TOGGLE_SYNCING
    _LIGHT_ADV_TOGGLE_SYNCING = True
    try:
        yield
    finally:
        _LIGHT_ADV_TOGGLE_SYNCING = False


def on_light_advanced_enabled_update(self, context: Context):
    """灯光高级设置开关镜像的 update 回调: 激活写默认渐变档, 关闭写"无"档

    模式真值在灯数据块的 ch_advanced.mode(随 .blend 保存), 镜像只承载按钮态(绘制期
    经抑制器从模式真值刷新); 面板活跃灯是唯一落点, 无灯/库链接灯静默跳过. 激活不
    联动灯型(模式胶囊的切档联动仍由胶囊算子承担), 灯型不符时面板画各档提示行引导.
    """
    if _LIGHT_ADV_TOGGLE_SYNCING:
        return
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    settings = obj.data.ch_advanced
    if self.advanced_enabled and settings.mode == 'NONE':
        settings.mode = 'GRADIENT'
    elif not self.advanced_enabled:
        settings.mode = 'NONE'


def on_env_enabled_update(self, context: Context):
    """环境设置激活开关的 update 回调: 激活建链并按当前模式接线, 关闭摘来源线

    真值在世界数据块的 env_enabled(随 .blend 保存, prop 直画数据块字段无需 WM
    镜像); 关闭只摘背景 Color 的插件来源线(链节点保留, 重开即恢复), 三件套不动.
    """
    world = self.id_data
    if self.env_enabled:
        ensure_world_env_chain(world)
    else:
        disconnect_world_env_chain(world)


def on_world_env_mode_update(self, context: Context):
    """环境模式 update 回调: 幂等建链/重接(与灯光 ch_advanced.mode 的自愈同口径)

    面板胶囊经模式算子切换(算子内也调建链, 双跑幂等无害); 本回调兜住脚本直调等
    绕过算子的路径.
    """
    ensure_world_env_chain(self.id_data)


def on_env_image_external_update(self, context: Context):
    """外部环境纹理路径回调: 非空时加载并写到场景世界的环境纹理节点"""
    node = find_world_env_node(self.id_data, MARK_WORLD_ENV_HDRI_TEX)
    if node is None:
        return
    ext = self.env_image_external
    if ext:
        image = find_or_load_image(ext)
        if image is not None:
            node.image = image
    elif node.image is not None:
        node.image = None


def on_env_replace_toggle_update(self, context: Context):
    """替换背景开关镜像的 update 回调: 直写分流节点(SWITCH_BgMode)的切换接口

    分流 Switch 是链的真值(随 .blend 保存), 镜像只承载按钮态(绘制期经抑制器从节点
    真值刷新); 开启时链未建则先建链(update/execute 语境写数据合法, 同模式切换算子
    口径).
    """
    if _REPLACE_TOGGLE_SYNCING:
        return
    world = context.scene.world
    bg_switch = find_world_env_node(world, MARK_WORLD_ENV_REPLACE_SWITCH)
    if self.replace_enabled and bg_switch is None:
        ensure_world_replace_chain(world)
        bg_switch = find_world_env_node(world, MARK_WORLD_ENV_REPLACE_SWITCH)
    if bg_switch is not None:
        bg_switch.inputs["Switch"].default_value = bool(self.replace_enabled)


def on_cameras_show_names_update(self, context: Context):
    """视图相机名称开关的 update 回调: 批量设置场景中全部相机的 show_name

    载入文件后的实况回读走护栏写入(handlers._sync_camera_names_state), 见位即跳过,
    避免回读把用户在 N 面板手动设置的个别相机 show_name 批量覆写.
    """
    if is_syncing():
        return
    for obj in context.scene.objects:
        if obj.type == 'CAMERA':
            obj.show_name = self.cameras_show_names


def on_camera_resolution_update(self, context: Context):
    """独立分辨率开关/数值的 update 回调: 开启时按需初始化, 并即时同步场景输出

    面板勾选/拖动 X/Y 逐次触发(幂等 no-op 快), 改场景相机的其它路径仍由 handlers 兜底.
    init 的护栏内写回(resolution.py 经 set_guarded)会再次进入本回调: 见位即跳过,
    否则场景输出退化时(退出期 RNA 读 0)同值写会无限递归.
    """
    if is_syncing():
        return
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    if self.use_independent:
        init_camera_resolution_from_scene(self, scene)
    sync_active_camera_resolution(scene)


def on_lights_mute_world_update(self, context: Context):
    """屏蔽世界开关的 update 回调: 灯光或灯光集合正处于隔离态时立即应用/撤除世界屏蔽

    开关只配置"隔离"按钮的行为; 非隔离态下切换不触碰世界(下次隔离生效).
    灯光隔离与集合隔离的判定各有一套(后者靠集合的 hide_viewport), 任一成立即视为隔离态,
    否则在集合隔离期间切换开关会把世界屏蔽撤掉.
    """
    scene = getattr(context, "scene", None)
    view_layer = getattr(context, "view_layer", None)
    if scene is None or view_layer is None:
        return
    isolated = lights_viewport_isolated(scene, view_layer) or light_collections_isolated(scene, view_layer)
    apply_light_isolate_world_mute(scene, isolated, self.lights_mute_world)
    # 静音连线不触发着色器重估与视口重绘, 显式刷新
    tag_3d_views()


def on_light_collections_index_update(self, context: Context):
    """灯光集合列表活跃索引回调: 点击行时联动大纲管理器

    大纲管理器的集合行选中态没有 RNA API, 可见的"高亮落到该集合"只能靠选中其内部
    灯光物体(大纲里橙色高亮显示在对应集合下), 故同时设活动层集合 + 独占选中集合内
    灯光. 程序化写入(快照重建/高亮回写)均在护栏内, 见位即跳过.
    """
    if is_syncing():
        return
    idx = self.light_collections_active_index
    if not 0 <= idx < len(self.light_collections):
        return
    # 同名本地/链接对按行标记消歧(经 resolver), 不能按名称裸查
    coll = LIST_SPECS["light_collections"].resolve(context, self.light_collections[idx])
    view_layer = getattr(context, "view_layer", None)
    if coll is None or view_layer is None:
        return
    set_active_collection(view_layer, coll)
    # 只选中灯光: 本列表承载灯光面板语义, 集合内混入的其它物体不随行点击选中(与 README 口径一致);
    # 有控制器的灯光连同其控制器空物体一并选中(rig 作为整体操作)
    lights = [obj for obj in collection_objects_recursive(coll) if obj.type == 'LIGHT']
    rig_objects: list = []
    for light in lights:
        rig_objects.append(light)
        controller = rig_controller_of(light)
        if controller is not None:
            rig_objects.append(controller)
    if rig_objects:
        select_only(context, rig_objects)
    tag_3d_views()


def _write_light_rig_prop(context: Context, write) -> None:
    """灯光方位镜像属性的统一写回收口

    镜像属性只是变换的视图, 真值在控制器空物体的旋转与灯光的局部位置上; 面板
    draw 期回读镜像经算法层抑制跳过(否则每帧重画都写一次变换), 用户改动才落到
    变换上. 无面板活跃灯光或无控制器时不写(镜像值维持原样, 属合法空态).
    """
    if is_light_rig_sync_suppressed():
        return
    light = panel_light(context)
    if light is None:
        return
    controller = rig_controller_of(light)
    if controller is None:
        return
    write(light, controller)


def on_light_rig_azimuth_update(self, context: Context):
    """方位角镜像的 update 回调: 写回控制器旋转的 Z 分量"""
    _write_light_rig_prop(context, lambda light, controller: set_controller_azimuth(controller, self.rig_azimuth))


def on_light_rig_elevation_update(self, context: Context):
    """高度角镜像的 update 回调: 写回控制器旋转的 X 分量"""
    _write_light_rig_prop(context, lambda light, controller: set_controller_elevation(controller, self.rig_elevation))


def on_light_rig_distance_update(self, context: Context):
    """距离镜像的 update 回调: 按新距离缩放灯光的局部位置(方向保持)"""
    _write_light_rig_prop(context, lambda light, controller: set_light_distance(light, self.rig_distance))


def on_light_rig_self_rotation_update(self, context: Context):
    """自旋转镜像的 update 回调: 写灯光局部旋转的 Y 分量; 归零时整体归位瞄准姿态

    不直调灯光的 rotation_euler RNA: 整组欧拉上按 Backspace 会三轴全归零(Blender
    对默认值的语义), 打破瞄准; 镜像只暴露 Y. 恢复默认值(0)时顺手把 X/Z 一并归位——镜像看不
    见被 Alt+R 之类带歪的瞄准分量, 归零这一动作正好当作“重新瞄准”的入口.
    """
    if self.rig_self_rotation == _RIG_SELF_ROTATION_DEFAULT:
        _write_light_rig_prop(context, lambda light, controller: reset_light_self_rotation(light))
        return
    _write_light_rig_prop(context, lambda light, controller: set_light_self_rotation(light, self.rig_self_rotation))


def on_light_advanced_update(self, context: Context):
    """高级设置状态的统一 update 回调: 幂等重接本灯 Emission 的插件接线

    模块与渐变模式两类变化共用一个回调(接线算法按当前状态全量重算);
    self 即挂在灯光数据块上的状态组, id_data 直接取到属主灯光, 与面板活跃项无关.
    """
    apply_light_advanced_wiring(self.id_data)


def on_image_array_mode_update(self, context: Context):
    """阵列方式胶囊的 update 回调: 把档位写进阵列坐标组实例的阵列方式插座

    Menu Switch 组写枚举项名, 旧 Mix 组(float 因子 0/1)按插座类型分派;
    同步图像纹理的扩展属性(环形=裁剪 / 其它=重复); 条件显示的参数行按插座值读真值.
    """
    node = find_advanced_node(self.id_data, MARK_IMAGE_ARRAY)
    if node is not None:
        sock = node.inputs.get("阵列方式")
        if sock is None:
            # 组实例缺座(版本不匹配/被手改): 按旧 Mix 组口径跳过, 不在 update 回调里炸
            pass
        elif sock.type == 'MENU':
            sock.default_value = ARRAY_MODE_RING if self.image_array_mode == 'RING' else ARRAY_MODE_RECT
        else:
            sock.default_value = 0.0 if self.image_array_mode == 'RECT' else 1.0
    tex = find_advanced_node(self.id_data, MARK_IMAGE_TEX)
    if tex is not None:
        tex.extension = 'CLIP' if self.image_array_mode == 'RING' else 'REPEAT'


def _adv_pick_items(root: str, category: str, kind: str, only_with_source: bool = False, online: bool = False) -> list:
    """缩略图枚举候选(共享实现): 标识=文件名稳定键, 图标即条目身份; 名称与悬停说明留空
    (运行期拼给动态枚举的非 ASCII 文案会经 C 层渲染成乱码, 选中名走网格下方 label 常显).
    过滤与取数口径须与绘制侧一致(源缺失条目是否入列由"仅显示现有源文件"开关决定,
    在线库按 manifest 索引取条目)"""
    items = []
    for idx, asset in enumerate(list_assets(root, category, kind, only_with_source, online)):
        items.append((asset["key"], "", "", preview_icon_id(asset["thumb"]), idx))
    return items


def _adv_state_category(root: str, state, field: str, online: bool = False, kind: str = 'WORLD') -> str:
    """面板状态里的当前分类, 空/失效(目录改过)回落首分类, 与绘制侧显示回退恒一致;
    无候选时原样返回存储值(下游查无归一, 枚举即空表)"""
    return resolve_category(list_categories(root, online, kind), getattr(state, field, ""))


def _adv_image_pick_items(self, context):
    """图像纹理缩略图候选(根目录取选中的资产库, 分类取面板状态并回落首分类)"""
    root = resolve_library_root('IMAGE', self.adv_image_library)[0]
    return _adv_pick_items(root, _adv_state_category(root, self, "adv_image_category"), 'IMAGE', self.adv_hide_missing_source)


def _adv_ies_pick_items(self, context):
    """IES 光域网缩略图候选(同上)"""
    root = resolve_library_root('IES', self.adv_ies_library)[0]
    return _adv_pick_items(root, _adv_state_category(root, self, "adv_ies_category"), 'IES', self.adv_hide_missing_source)


def _adv_world_pick_items(self, context):
    """世界环境 HDRI 缩略图候选(同上, 库用途 = 世界环境; 在线库按 manifest 索引)"""
    root = resolve_library_root('WORLD', self.adv_world_library)[0]
    online = online_manifest_library('WORLD', self.adv_world_library)
    return _adv_pick_items(root, _adv_state_category(root, self, "adv_world_category", online), 'WORLD', self.adv_hide_missing_source, online)


# 资产档位 -> 面板状态里"缩略图选中键/资产库/分类"的状态字段名(pick 更新回调共用;
# 与 operators/object/light.py 的 _LIBRARY_FIELDS/_CATEGORY_FIELDS/_PICK_FIELDS 同表,
# 算子侧不导入 props 防循环, 两处靠同键名纪律同步)
_PICK_STATE_FIELDS = {
    'IMAGE': ("adv_image_pick", "adv_image_library", "adv_image_category"),
    'IES': ("adv_ies_pick", "adv_ies_library", "adv_ies_category"),
    'WORLD': ("adv_world_pick", "adv_world_library", "adv_world_category"),
    'PBR': ("adv_pbr_pick", "adv_pbr_library", "adv_pbr_category"),
}


def _resolve_picked_asset(state, kind: str, online: bool = False) -> tuple:
    """选中资产统一解析(三档 pick 更新回调共用): 返回 (root, asset, source)

    pick 为空/库根缺失/条目缺失/源缺失都按未命中处理(调用方静默跳过, 与"OneDrive
    云占位加载失败不提示"同口径); 分类走与绘制侧/枚举回调同款的失效回退; 在线库
    条目 source 恒空, 取当前分辨率/格式已落盘的文件(未下载返回空串, 由下载行负责).
    """
    pick_field, library_field, category_field = _PICK_STATE_FIELDS[kind]
    root = resolve_library_root(kind, getattr(state, library_field))[0]
    if not root:
        return "", None, ""
    category = _adv_state_category(root, state, category_field, online, kind)
    # 先备候选表再读选中键: 候选为空时读动态枚举存值会打 C 层 "matches no enum" 告警
    assets = list_assets(root, category, kind, state.adv_hide_missing_source, online)
    key = stored_pick_key(state, pick_field, assets)
    if not key:
        return root, None, ""
    asset = next((item for item in assets if item["key"] == key), None)
    if asset is None:
        return root, None, ""
    if online:
        # 在线库条目 source 恒空: 取当前分辨率/格式已落盘的文件(单文件型为源文件,
        # 包型为该分辨率的贴图目录); 规格字段按资产种类映射取
        fields = ONLINE_SPEC_FIELDS.get(kind)
        option = resolve_option(asset, getattr(state, fields[0], ""), getattr(state, fields[1], "")) if fields else None
        source = existing_source(root, asset, option)
    else:
        source = asset["source"]
    return root, asset, source


def _apply_picked_asset(state, context: Context, kind: str) -> None:
    """缩略图选中共用落地: 把选中资产写到面板活跃灯光的插件链节点上

    自动应用关闭(选择器"自动应用"开关)时只改选中项, 落地由名称行右侧钮显式触发.
    外部路径优先: 灯上的外部文件路径非空时缩略图点击被跳过(清空外路径恢复).
    源文件缺失的条目(离线库未下载/在线库未落盘)只保持选中, 不写节点.
    灯光/链节点/资产任一缺失(如模式已切走,库已改,文件失效)都静默跳过,
    与"OneDrive 云占位加载失败不提示"同口径; 图像按路径查重复用数据块.
    """
    if not state.adv_auto_apply:
        return
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    light = obj.data
    ext_field = "image_external" if kind == 'IMAGE' else "ies_external"
    if getattr(light.ch_advanced, ext_field, ""):
        return
    _, _, source = _resolve_picked_asset(state, kind)
    if not source:
        return
    node = find_advanced_node(light, MARK_IMAGE_TEX if kind == 'IMAGE' else MARK_IES_TEX)
    if node is None:
        return
    if kind == 'IMAGE':
        image = find_or_load_image(source)
        if image is not None:
            node.image = image
    else:
        node.filepath = source


def on_adv_image_pick_update(self, context: Context):
    """图像纹理缩略图选中回调: 应用到面板活跃灯光"""
    _apply_picked_asset(self, context, 'IMAGE')


def on_adv_ies_pick_update(self, context: Context):
    """IES 缩略图选中回调: 写 EXTERNAL 文件路径到面板活跃灯光"""
    _apply_picked_asset(self, context, 'IES')


def on_adv_world_pick_update(self, context: Context):
    """世界环境 HDRI 缩略图选中回调: 载入源文件到场景世界的环境纹理节点

    自动应用关闭时只改选中项, 落地由名称行右侧钮(来源刷新)显式触发.
    外部路径优先: 世界的外部文件路径非空时缩略图点击被跳过(清空外路径恢复),
    与灯光图像档同口径. 源文件缺失的条目只保持选中. 链未建(从未点过模式胶囊)时
    静默跳过, 切到 HDRI 档后可用来源刷新钮按当前选中回填.
    """
    if not self.adv_auto_apply:
        return
    world = context.scene.world
    if world is None or world.library is not None:
        return
    if world.ch_env.env_image_external:
        return
    online = online_manifest_library('WORLD', self.adv_world_library)
    _, _, source = _resolve_picked_asset(self, 'WORLD', online)
    if not source:
        return
    node = find_world_env_node(world, MARK_WORLD_ENV_HDRI_TEX)
    if node is None:
        return
    image = find_or_load_image(source)
    if image is not None:
        node.image = image


def _adv_pbr_pick_items(self, context):
    """PBR 材质资产包缩略图候选(同上, 库用途 = PBR 材质; 在线库按 manifest 索引)

    离线库的条目 = 分类顶层的资产包目录; 在线库的条目按索引的 package 字段定位包目录,
    贴图按需下载到 <包目录>/<分辨率>/
    """
    root = resolve_library_root('PBR', self.adv_pbr_library)[0]
    online = online_manifest_library('PBR', self.adv_pbr_library)
    return _adv_pick_items(root, _adv_state_category(root, self, "adv_pbr_category", online, 'PBR'), 'PBR', self.adv_hide_missing_source, online)


def on_adv_pbr_pick_update(self, context: Context):
    """PBR 资产包缩略图选中回调: 自动应用开启时把选中包导入面板活动材质(整树重建)

    自动应用关闭时只改选中项, 落地由名称行右侧钮(导入资产包)显式触发.
    材质缺失/库链接/源缺失(离线库包目录不存在或空/在线库该分辨率未下载)都静默跳过,
    与灯光图像档同口径; 导入本身按"包内无可识别贴图则不动材质"拒绝(见 import_pbr_pack).
    在线库按索引声明的法线朝向建链(cgbookcase 为 DirectX, 包内文件名不带朝向后缀).
    """
    if not self.adv_auto_apply:
        return
    mat = panel_material(context)
    if mat is None or mat.library is not None:
        return
    _, asset, source = _resolve_picked_asset(self, 'PBR', online_manifest_library('PBR', self.adv_pbr_library))
    if not source:
        return
    import_pbr_pack(mat, source, asset.get("normal_convention", ""))


def on_pbr_uv_output_update(self, context: Context):
    """纹理坐标镜像枚举的 update 回调: 重建链内 TexCoordinate -> Mapping 的接线

    真值在链的连接关系里, 本枚举只是镜像; 用户改动下拉 = 换接线(不进 Undo 栈, tooltip 说明).
    面板 draw 期把连接真值写回镜像时经抑制器跳过本回调(否则每帧重画都会重建接线).
    """
    if is_pbr_mirror_suppressed():
        return
    mat = panel_material(context)
    if mat is None or mat.library is not None:
        return
    set_pbr_uv_output(mat, self.pbr_uv_output)


def _write_pbr_switch(context: Context, marker: str, value: bool) -> None:
    """把面板镜像开关写回链内指定 Switch 的切换输入(五条链共用)

    draw 期把节点真值读进镜像时经抑制器跳过; 面板活动材质为库链接材质时不写.
    """
    if is_pbr_mirror_suppressed():
        return
    mat = panel_material(context)
    if mat is None or mat.library is not None:
        return
    switch = find_pbr_nodes(mat).get(marker)
    if switch is not None:
        switch.inputs["Switch"].default_value = value


def on_pbr_ao_factor_update(self, context: Context):
    """AO 系数镜像的 update 回调: 把系数写回链内 AO 乘算节点"""
    if is_pbr_mirror_suppressed():
        return
    mat = panel_material(context)
    if mat is None or mat.library is not None:
        return
    mix = find_pbr_nodes(mat).get("MIX:ao")
    if mix is not None:
        mix.inputs[0].default_value = self.pbr_ao_factor


def on_pbr_ao_enabled_update(self, context: Context):
    """AO 切换镜像的 update 回调: 写回链末 AO Switch(关 = 原基础色)"""
    _write_pbr_switch(context, "SWITCH_AO", self.pbr_ao_enabled)


def on_pbr_normal_enabled_update(self, context: Context):
    """法向切换镜像的 update 回调: 写回链末法向 Switch(关 = 零向量)"""
    _write_pbr_switch(context, "SWITCH_NORMAL", self.pbr_normal_enabled)


def on_pbr_bump_enabled_update(self, context: Context):
    """凹凸切换镜像的 update 回调: 写回链末凹凸 Switch(关 = 零向量)"""
    _write_pbr_switch(context, "SWITCH_BUMP", self.pbr_bump_enabled)


def on_pbr_flip_normal_y_update(self, context: Context):
    """翻转 Y 镜像的 update 回调: 写回链内法线 Switch 的切换输入(按下 = DirectX 翻转绿通道)"""
    _write_pbr_switch(context, "SWITCH_FLIPY", self.pbr_flip_normal_y)


def on_pbr_displacement_update(self, context: Context):
    """置换镜像的 update 回调: 写回链末置换 Switch(关 = 输出零位移)"""
    _write_pbr_switch(context, "SWITCH_DISP", self.pbr_displacement)


def _pbr_chain_textures_of_context(context: Context) -> list:
    """面板活动材质已导入链里的全部图像纹理节点(投影统一控制的写入目标); 无链为空表"""
    mat = panel_material(context)
    if mat is None or mat.library is not None:
        return []
    return pbr_chain_textures(mat)


def on_pbr_projection_update(self, context: Context):
    """投影统一控制镜像枚举的 update 回调: 把新投影写进链内全部图像纹理

    真值散在各 Image Texture 节点的 projection 上, 本枚举只是镜像; 用户改动 = 统一改写
    全部链内纹理. Blend 只在 Box 时有意义: 改到非 Box 时把 Blend 归零(与节点面板一致).
    """
    if is_pbr_mirror_suppressed():
        return
    for tex in _pbr_chain_textures_of_context(context):
        tex.projection = self.pbr_projection
        if self.pbr_projection != 'BOX':
            tex.projection_blend = 0.0


def on_pbr_projection_blend_update(self, context: Context):
    """投影融合统一控制的 update 回调: 把新 Blend 写进链内全部图像纹理"""
    if is_pbr_mirror_suppressed():
        return
    for tex in _pbr_chain_textures_of_context(context):
        tex.projection_blend = self.pbr_projection_blend


def on_env_field_update(self, context: Context):
    """环境调节组镜像字段的统一 update 回调: 把镜像值写回组实例插座

    镜像绘制的真值在插座上; 绘制期真值 -> 镜像经抑制器跳过本回调. 统一全量写回
    (值未变的插座赋值无副作用), 节点缺失(链未建)静默跳过. 镜像宿主是 WM 状态组,
    世界经 context 取(面板活跃世界 = 场景世界).
    """
    if _ENV_MIRROR_SYNCING:
        return
    world = context.scene.world
    node = find_world_env_node(world, MARK_WORLD_ENV_HDRI_SETTING)
    if node is None:
        return
    for field, socket_name in _ENV_FIELD_SOCKETS:
        sock = node.inputs.get(socket_name)
        if sock is not None:
            sock.default_value = getattr(self, field)


def on_env_replace_mode_update(self, context: Context):
    """替换背景档位 update 回调: 直写档位分流节点(SWITCH_RepMode)的切换接口

    激活 = 渐变(True 路 = 色标渐变); 真值双写: 枚举镜像(随 .blend 保存) + 节点切换
    接口; 链未建时静默跳过, 建链按镜像归位(见 ensure_world_replace_chain).
    """
    is_gradient = self.replace_mode == 'GRADIENT'
    ramp_switch = find_world_env_node(self.id_data, MARK_WORLD_ENV_REPLACE_RAMP_SWITCH)
    if ramp_switch is not None:
        ramp_switch.inputs["Switch"].default_value = is_gradient


def on_image_external_update(self, context: Context):
    """外部图像路径回调: 非空时加载并写到面板活跃灯光的图像纹理节点"""
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    ext = self.image_external
    node = find_advanced_node(obj.data, MARK_IMAGE_TEX)
    if node is None:
        return
    if ext:
        image = find_or_load_image(ext)
        if image is not None:
            node.image = image
    elif node.image is not None:
        node.image = None


def on_ies_external_update(self, context: Context):
    """外部 IES 路径回调: 非空时写到面板活跃灯光的 IES 纹理节点"""
    obj = panel_light(context)
    if obj is None or obj.library is not None:
        return
    ext = self.ies_external
    node = find_advanced_node(obj.data, MARK_IES_TEX)
    if node is None:
        return
    node.filepath = ext


class LightLinkItem(PropertyGroup):
    """灯光&阴影链接列表的镜像条目(真值在灯侧链接集合, 绘制期签名比对重建)

    条目字段即行内钮的算子载荷: 行内状态切换/移除与侧列移除直接取条目组装,
    不必在绘制期再解析面板活跃灯. writable 记录重建时发射器是否可写(库链接灯整行置灰).
    物体链接反查为合并行: 一行一灯, state/direct 是灯光链接侧, shadow_state/shadow_direct
    是阴影链接侧(空串 = 该灯此侧无链接关系, 行内置灰标识), users = 共享该灯
    灯光链接集合的灯数(行尾数字, 点击独立化); subject_name/is_collection 记反查主体
    (活动物体或集合视角下的活动集合), 行内钮载荷直接取条目.
    """

    src_name: StringProperty(name="Name")  # type: ignore
    emitter_name: StringProperty()  # type: ignore
    subject_name: StringProperty()  # type: ignore
    link_type: StringProperty()  # type: ignore
    state: StringProperty()  # type: ignore
    is_collection: BoolProperty()  # type: ignore
    direct: BoolProperty()  # type: ignore
    writable: BoolProperty()  # type: ignore
    shadow_state: StringProperty()  # type: ignore
    shadow_direct: BoolProperty()  # type: ignore
    users: IntProperty(default=1)  # type: ignore


class SceneHelperState(PropertyGroup):
    """场景助手六个列表的快照与全部 UI 状态(WM 级, 不随 .blend 保存)"""

    # --- 快照与活跃索引(索引只表高亮, 不做场景联动) ---
    cameras: CollectionProperty(type=ListItem)  # type: ignore
    cameras_active_index: IntProperty(default=0)  # type: ignore
    lights: CollectionProperty(type=ListItem)  # type: ignore
    lights_active_index: IntProperty(default=0)  # type: ignore
    # 灯光集合(CLS_ 前缀)管理列表: 灯光面板主列表上方的附属列表
    light_collections: CollectionProperty(type=ListItem)  # type: ignore
    light_collections_active_index: IntProperty(default=0, update=on_light_collections_index_update)  # type: ignore
    materials: CollectionProperty(type=ListItem)  # type: ignore
    materials_active_index: IntProperty(default=0)  # type: ignore
    worlds: CollectionProperty(type=ListItem)  # type: ignore
    worlds_active_index: IntProperty(default=0)  # type: ignore
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_images_index_update)  # type: ignore

    # --- 列表范围与同步 ---
    # 选区同步(选项菜单第 1 位, 世界环境无): 四个面板共用同一个开关
    sync_selection: BoolProperty(name="Sync Selection", default=True, update=on_sync_toggle, description="Highlight the list item of the active object whenever the active object changes")  # type: ignore
    # 显示0用户(选项菜单第 2 位, 无该概念的面板不显示)
    # 材质/世界/图像默认开启: 列表默认列出全部数据块, 只有用户主动关掉时才
    # 过滤到"有使用者"的子集. 图像侧另有硬理由: 图像生成/通道捕获的产物都是 0 用户的独立数据块,
    # 默认过滤会让它们在面板里"不存在"; 且这类图像被图像编辑器显示过就带上一个临时使用者
    # (id_us_ensure_real), 点伪用户时该临时位被转正而 users 不加一, "真实使用者"口径随即判成
    # 0 用户 → 整行忽隐忽现.
    show_zero_user_materials: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list materials that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_worlds: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list worlds that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_images: BoolProperty(name="Show 0 Users", default=True, update=on_list_scope_update, description="Also list images that have no users (orphans and fake-user only)")  # type: ignore
    # 显示库链接(材质/世界/图像三处选项共用同一开关): 是否列出经库链接引入的数据块, 默认开
    show_linked_data: BoolProperty(name="Show Linked Data", default=True, update=on_list_scope_update, description="Also list data-blocks linked from libraries (materials, worlds and images); turn off to list only data-blocks from this file")  # type: ignore

    # --- 列表内建过滤/排序开关镜像 ---
    # template_list 的漏斗开关存在 UIList 实例上, 算子拿不到; UIList.filter_items 每次绘制时
    # 镜像到这两条向量(顺序同 scene_state.LIST_KINDS), 供"上移/下移"判断显示顺序.
    filter_alpha: BoolVectorProperty(size=6, default=(False, False, False, False, False, False))  # type: ignore
    filter_reverse: BoolVectorProperty(size=6, default=(False, False, False, False, False, False))  # type: ignore

    # --- 详情子面板展开态(高级设置与灯光方位默认收缩, 灯光&阴影链接同) ---
    show_camera_details: BoolProperty(default=True)  # type: ignore
    show_light_details: BoolProperty(default=True)  # type: ignore
    show_light_advanced: BoolProperty(default=False)  # type: ignore
    show_light_rig: BoolProperty(default=False)  # type: ignore
    # 灯光&阴影链接子面板默认收缩
    show_light_linking: BoolProperty(default=False)  # type: ignore
    # 材质面板的 PBR 子面板默认展开
    show_pbr_details: BoolProperty(default=True)  # type: ignore
    # 世界环境的环境设置子面板默认收缩
    show_env_settings: BoolProperty(default=False)  # type: ignore
    # 世界环境的替换背景子面板默认展开(开关在折叠头行尾)
    show_replace_settings: BoolProperty(default=True)  # type: ignore

    # --- 灯光&阴影链接子面板 ---
    # 三模式切换(灯光面板详情区, expand 绘制): 灯光/阴影链接编辑面板活跃灯光的
    # 链接集合, 物体链接反查视口活动物体
    light_linking_mode: EnumProperty(name="Mode", items=LIGHT_LINKING_MODES, default=0)  # type: ignore
    # 物体链接的集合视角(作者定): 激活后反查列表显示活动集合作为直接子集合条目在各灯
    # 链接集合中的状态, 取消激活则显示活动物体的链接状态
    use_collection_view: BoolProperty(name="Collection View", default=False, description="Show the active collection's link states instead of the active object's")  # type: ignore
    # 链接列表镜像(真值在灯侧链接集合, 绘制期签名比对重建; 不用 common.ListItem
    # 是因为其 name 带写穿 update, 镜像条目不可改名): 条目携带行内钮所需载荷
    link_members: CollectionProperty(type=LightLinkItem)  # type: ignore
    link_members_index: IntProperty(default=0)  # type: ignore
    link_members_signature: StringProperty()  # type: ignore
    object_light_links: CollectionProperty(type=LightLinkItem)  # type: ignore
    object_light_links_index: IntProperty(default=0)  # type: ignore
    object_link_signature: StringProperty()  # type: ignore

    # --- 行内列显示开关 ---
    cameras_show_lens: BoolProperty(name="Lens", default=False, description="Show the lens column")  # type: ignore
    cameras_show_type: BoolProperty(name="Type", default=False, description="Show the camera type column")  # type: ignore
    cameras_show_names: BoolProperty(name="View Camera Name", default=False, description="Show or hide the names of all cameras in the 3D view (writes each camera's show_name flag, saved with the .blend; the toggle state itself is re-read on file load)", update=on_cameras_show_names_update)  # type: ignore
    lights_show_color: BoolProperty(name="Color", default=False, description="Show the light color column")  # type: ignore
    lights_show_shadow: BoolProperty(name="Shadow", default=False, description="Show the shadow toggle column")  # type: ignore
    # 屏蔽世界: 灯光/灯光集合隔离时同时屏蔽世界输出节点的全部接入端连线(取消隔离恢复).
    # 灯光面板与灯光集合列表共用同一个开关, 两个选项菜单各显示一次
    lights_mute_world: BoolProperty(name="Mute World", default=False, update=on_lights_mute_world_update, description="While isolating a light or a light collection, also mute every link into the World Output node to isolate it from the world lighting (links are restored on un-isolating)")  # type: ignore
    materials_show_pass_index: BoolProperty(name="Pass Index", default=False, description="Show the pass index column")  # type: ignore
    materials_show_node_count: BoolProperty(name="Node Count", default=False, description="Show the material node count column")  # type: ignore
    worlds_show_color: BoolProperty(name="Color", default=False, description="Show the world color swatch")  # type: ignore

    # --- 灯光方位镜像属性(灯光控制器 rig, 灯光面板"Light Rig"折叠区绘制) ---
    # 真值在控制器空物体的旋转与灯光的局部位置上(方位角=控制器旋转 Z 分量, 高度角=X
    # 分量, 距离=灯光局部位置长度), 绘制前经算法层抑制读进镜像, 用户改动经 update 回调
    # 写回变换; 纯运行期镜像不落任何自定义属性, 不进"自定义属性"面板
    rig_azimuth: FloatProperty(name="Azimuth", subtype='ANGLE', default=0.0, update=on_light_rig_azimuth_update, description="Rotation of the controller empty around its Z axis (edits the controller transform, not undoable)")  # type: ignore
    rig_elevation: FloatProperty(name="Elevation", subtype='ANGLE', default=RIG_DEFAULT_ELEVATION, update=on_light_rig_elevation_update, description="Rotation of the controller empty around its X axis (edits the controller transform, not undoable)")  # type: ignore
    rig_distance: FloatProperty(name="Distance", subtype='DISTANCE', min=0.0, default=RIG_DEFAULT_DISTANCE, update=on_light_rig_distance_update, description="Distance from the light to its controller (edits the light's local location, not undoable)")  # type: ignore
    rig_self_rotation: FloatProperty(name="Self Rotation", subtype='ANGLE', default=_RIG_SELF_ROTATION_DEFAULT, update=on_light_rig_self_rotation_update, description="Self rotation of the light around its local Y axis (edits only the Y component, not undoable; resetting to 0 also restores the local rotation X -90 and Z 0)")  # type: ignore

    # --- 灯光高级设置资产选择器(图像纹理/IES 光域网) ---
    # 选中资产库(存库根目录路径, 空/失效时回落该用途首个启用的库; 库本身在偏好里管理);
    # 分类目录名(经下拉菜单选定, 显示走按钮文本不进动态枚举); 缩略图选中键为动态枚举
    # (标识=文件名键, 名称/悬停留空避开动态枚举中文乱码), 点击经 update 应用到面板活跃灯;
    # 缩略图尺寸与弹窗放大系数在偏好(asset_thumb_size / asset_thumb_popup_factor, 两选择器共用)
    adv_image_library: StringProperty(default="")  # type: ignore
    adv_ies_library: StringProperty(default="")  # type: ignore
    adv_world_library: StringProperty(default="")  # type: ignore
    adv_image_category: StringProperty(default="")  # type: ignore
    adv_ies_category: StringProperty(default="")  # type: ignore
    adv_world_category: StringProperty(default="")  # type: ignore
    adv_image_pick: EnumProperty(items=_adv_image_pick_items, update=on_adv_image_pick_update)  # type: ignore
    adv_ies_pick: EnumProperty(items=_adv_ies_pick_items, update=on_adv_ies_pick_update)  # type: ignore
    # 世界环境 HDRI 选择器(世界面板环境设置子面板, 机制同上; 选中落点 = 场景世界的环境纹理节点)
    adv_world_pick: EnumProperty(items=_adv_world_pick_items, update=on_adv_world_pick_update)  # type: ignore
    # PBR 材质选择器(材质面板 PBR 子面板, 机制同上): 条目 = 分类顶层的资产包目录,
    # 选中落点 = 面板活动材质按 PBR_Universal 模板整树重建(自动应用开启时点击即重建)
    adv_pbr_library: StringProperty(default="")  # type: ignore
    adv_pbr_category: StringProperty(default="")  # type: ignore
    adv_pbr_pick: EnumProperty(items=_adv_pbr_pick_items, update=on_adv_pbr_pick_update)  # type: ignore

    # --- 材质 PBR 子面板参数区镜像字段 ---
    # 真值全在链节点上, 绘制前经抑制器读进镜像, 用户改动经 update 回调写回链节点
    # (镜像不挂材质数据块: draw 语境禁写 ID 类数据块的 idprop, WM 级可写同灯方位先例)
    # 链末四个切换开关(真值在各链末 Switch 的切换输入, 默认态与导入建链一致):
    # AO 开 / 法向开 / 凹凸开 / 置换关; 关闭时回落原基础色或零向量
    pbr_ao_enabled: BoolProperty(name="AO", default=True, update=on_pbr_ao_enabled_update, description="Enable or disable the AO overlay on the base color; when off the base color is used as-is")  # type: ignore
    pbr_normal_enabled: BoolProperty(name="Normal", default=True, update=on_pbr_normal_enabled_update, description="Enable or disable the normal map on the surface; when off a zero normal is fed")  # type: ignore
    pbr_bump_enabled: BoolProperty(name="Bump", default=True, update=on_pbr_bump_enabled_update, description="Enable or disable the bump map on the surface; when off a zero normal is fed")  # type: ignore
    pbr_displacement: BoolProperty(name="Displacement", default=False, update=on_pbr_displacement_update, description="Displace the surface using the height texture; when off a zero displacement is fed to the output")  # type: ignore
    # AO 系数: 链内 AO 乘算节点的 Factor(默认 0.5)
    pbr_ao_factor: FloatProperty(name="Factor", default=0.5, subtype='FACTOR', min=0.0, max=1.0, update=on_pbr_ao_factor_update, description="AO overlay coefficient on the base color; higher values make the occluded areas darker")  # type: ignore
    # 翻转 Y 按钮: 链内法线 Switch 的切换输入(按下 = DirectX 翻转绿通道; 导入按后缀自动判定)
    pbr_flip_normal_y: BoolProperty(name="Flip Y", default=False, update=on_pbr_flip_normal_y_update, description="Flip the green channel of the normal map for DirectX textures; auto-set from the filename suffix on import")  # type: ignore
    # 纹理坐标: 真值在链内 TexCoordinate->Mapping 的连接里, 绘制前读进镜像, 用户改动重建接线
    pbr_uv_output: EnumProperty(name="Texture Coordinate", items=TEXCOORD_OPTIONS, default="UV", update=on_pbr_uv_output_update, description="Texture coordinate output feeding the Mapping node of the imported PBR chain (edits node links, not undoable)")  # type: ignore
    # 投影统一控制: 真值在链内各 Image Texture 的 projection 上; 全部一致 -> 该值, 不一致时保持镜像原值
    pbr_projection: EnumProperty(name="Projection", items=PROJECTION_OPTIONS, default=0, update=on_pbr_projection_update, description="Projection for every image texture of the imported PBR chain (applied to every texture; not undoable)")  # type: ignore
    # 投影融合: 仅 Box 时显示, 写进链内全部纹理
    pbr_projection_blend: FloatProperty(name="Blend", default=0.0, subtype='FACTOR', min=0.0, max=1.0, update=on_pbr_projection_blend_update, description="Blend for box projection, applied to every image texture of the imported PBR chain (not undoable)")  # type: ignore
    # 在线库下载规格(世界环境 HDRI 档 / PBR 材质档): 分辨率与格式选择, 空串表示按索引默认
    # 解析(分辨率优先 4K/2K/1K, 格式取该分辨率首个); 换资产时保留记忆, 该资产缺档由解析回落
    adv_world_resolution: StringProperty(default="")  # type: ignore
    adv_world_format: StringProperty(default="")  # type: ignore
    adv_pbr_resolution: StringProperty(default="")  # type: ignore
    adv_pbr_format: StringProperty(default="")  # type: ignore
    # 选择器行尾两枚共用开关(图像/IES/世界环境/PBR 材质四档同一份, 绘制在资产库与分类行末尾):
    # 自动应用关闭时点击/循环缩略图只改选中项, 落地由名称行右侧钮(来源刷新)显式触发;
    # 仅显示现有源文件开启时只列源文件存在的条目(关闭时源缺失的缩略图也入列但不可应用)
    adv_auto_apply: BoolProperty(name="Auto Apply", default=False, description="Apply the picked thumbnail to the node as soon as it is selected; turn off to apply manually with the button next to the asset name")  # type: ignore
    adv_hide_missing_source: BoolProperty(name="Only Existing Sources", default=False, description="List only the assets whose source file exists; thumbnails without a source file are listed otherwise but cannot be applied")  # type: ignore

    # --- 环境调节组镜像(世界面板 HDRI 档) ---
    # 组实例插座的 RNA 不带接口的子类型与范围(着色强度等滑条退化成裸数字), 面板经
    # 镜像字段绘制: 绘制前经抑制器把插座真值读进镜像, 改动经 on_env_field_update
    # 统一写回插座(直接编辑节点插座语义, 不进撤销栈). 挂 WM 状态组而非世界数据块:
    # draw 语境禁写 ID 类数据块的 idprop(第 29 条实测坑), WM 级可写同 PBR/灯方位镜像
    env_exposure: FloatProperty(name="Exposure", default=0.0, update=on_env_field_update, description="Multiply the HDRI color by (exposure + 1) (not undoable)")  # type: ignore
    env_hue: FloatProperty(name="Hue", default=0.5, min=0.0, max=1.0, update=on_env_field_update, description="Hue shift of the HDRI color (not undoable)")  # type: ignore
    env_saturation: FloatProperty(name="Saturation", default=1.0, min=0.0, max=2.0, update=on_env_field_update, description="Saturation of the HDRI color (not undoable)")  # type: ignore
    env_gamma: FloatProperty(name="Gamma", default=1.0, min=0.001, max=10.0, update=on_env_field_update, description="Gamma correction of the HDRI color (not undoable)")  # type: ignore
    env_highlight_boost: FloatProperty(name="高光增益", default=0.0, min=-10000.0, max=10000.0, update=on_env_field_update, description="Boost of the bright areas of the HDRI (not undoable)")  # type: ignore
    env_tint: FloatVectorProperty(name="Tint", subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 1.0, 1.0), update=on_env_field_update, description="Color multiplied into the HDRI (not undoable)")  # type: ignore
    env_tint_factor: FloatProperty(name="着色强度", default=1.0, min=0.0, max=1.0, subtype='FACTOR', update=on_env_field_update, description="Strength of the tint mixed into the HDRI (not undoable)")  # type: ignore
    # 替换背景开关镜像(子面板折叠头行尾的 prop toggle 按钮, 绘制按钮背景):
    # 切换节点的 Switch 接口是链的真值(随 .blend 保存), 镜像只承载按钮态(绘制期经
    # 抑制器从节点真值刷新); 开启时链未建则先建链(同模式切换算子口径), 关闭只写
    # SWITCH_BgMode 的切换接口保留参数不丢(作者模板已删布尔节点, 直写分流 Switch)
    replace_enabled: BoolProperty(name="Replace Enabled", default=False, update=on_env_replace_toggle_update, description="Toggle the replacement background for camera rays (enabling builds the replace node chain; disabling switches back to the environment background and keeps the nodes)")  # type: ignore
    # 灯光高级设置激活镜像(高级设置子面板折叠头行尾的 prop toggle 按钮, "无"档
    # 移出模式胶囊改由开关承担): 模式真值在灯数据块的 ch_advanced.mode, 镜像只承载
    # 按钮态(绘制期经抑制器从模式真值刷新); 激活写默认渐变档, 关闭写"无"档
    advanced_enabled: BoolProperty(name="Advanced Enabled", default=False, update=on_light_advanced_enabled_update, description="Toggle the advanced settings of the active light (enabling picks the gradient module; the mode pills and the light type coupling keep working)")  # type: ignore


class CameraResolutionSettings(PropertyGroup):
    """相机独立分辨率: 该相机为场景相机时覆写场景输出分辨率(挂在物体上, 随 .blend 保存)

    res_x/res_y 出厂为 0 表示"未初始化": 首次开启由属性 update 回调以场景输出初始化,
    关闭再开启保留上次数值; 数值低于有效下限视同未启用(判据见
    utils/blender/resolution.py 的 camera_resolution).
    """

    # 标签沿用词典已有词条 "Independent Resolution"
    use_independent: BoolProperty(
        name="Independent Resolution",
        description="Override the scene output resolution with this camera's own resolution while it is the scene camera",
        default=False,
        update=on_camera_resolution_update,
    )  # type: ignore
    # 标签沿用系统词条 "Resolution X/Y"(与原生输出分辨率同名, 不入典)
    res_x: IntProperty(
        name="Resolution X",
        description="Independent output width in pixels",
        default=0,
        min=0,
        max=CAMERA_RES_MAX,
        subtype='PIXEL',
        update=on_camera_resolution_update,
    )  # type: ignore
    res_y: IntProperty(
        name="Resolution Y",
        description="Independent output height in pixels",
        default=0,
        min=0,
        max=CAMERA_RES_MAX,
        subtype='PIXEL',
        update=on_camera_resolution_update,
    )  # type: ignore


class SceneResolutionState(PropertyGroup):
    """场景侧独立分辨率覆写状态: 覆写前基准与当前覆写来源(挂在场景上, 随 .blend 保存)

    纯内部记账, 不进 UI(无 name/description, 仿 ch_ai_assistant 的 lock_ratio).
    """

    # 基准是否有效(idprop 时代的"键存在"语义改为显式布尔)
    has_base: BoolProperty(default=False)  # type: ignore
    base_x: IntProperty(default=0)  # type: ignore
    base_y: IntProperty(default=0)  # type: ignore
    # 当前覆写来源相机名(空 = 未处于覆写态)
    applied_src: StringProperty(default="")  # type: ignore


class LightAdvancedSettings(PropertyGroup):
    """灯光高级设置状态(挂在灯光数据块上, 随 .blend 保存; 多物体共享数据块时同步生效)

    真值分两层: 模块(mode, "无"档即不激活)与渐变模式在此; 渐变参数与色标色值的真值在
    灯光节点树的插件实例节点上(面板直绘节点插座, 同材质基础参数区先例). 任一项变化经
    on_light_advanced_update 幂等重接 Emission; Emission 被用户手改接线时照常接管
    (重接后插件线生效, 面板画提示行).
    """

    mode: EnumProperty(
        name="Mode",
        items=ADVANCED_MODE_ITEMS,
        default='NONE',
        update=on_light_advanced_update,
        description="Which advanced module drives the light; None deactivates all modules",
    )  # type: ignore
    gradient_type: EnumProperty(
        name="Gradient Type",
        items=GRADIENT_TYPE_ITEMS,
        default='RADIAL',
        update=on_light_advanced_update,
        description="Gradient pattern applied to the light emission",
    )  # type: ignore
    # 图像档接线目标: 纹理驱动发光颜色(默认)还是强度(灰度图必须接强度才有正确照明)
    image_target: EnumProperty(
        name="Target",
        items=IMAGE_TARGET_ITEMS,
        default='COLOR',
        update=on_light_advanced_update,
        description="Which emission socket the image texture drives",
    )  # type: ignore
    # 图像档阵列方式(矩形/环形): UI 真值写阵列坐标组实例的阵列方式插座
    # (Menu Switch 组写枚举项名 / 旧 Mix 组写 0/1 因子), 条件显示的参数行按插座值读真值
    image_array_mode: EnumProperty(
        name="Array Mode",
        items=IMAGE_ARRAY_MODE_ITEMS,
        default='RECT',
        update=on_image_array_mode_update,
        description="Rectangular tiling or ring array of the projected texture",
    )  # type: ignore
    # 外部文件路径(图像/IES): 不在资产库中的文件, 非空时优先于缩略图选择
    image_external: StringProperty(
        name="External Image",
        description="Path to an external image file (overrides the asset picker when set)",
        subtype='FILE_PATH',
        update=on_image_external_update,
    )  # type: ignore
    ies_external: StringProperty(
        name="External IES",
        description="Path to an external IES file (overrides the asset picker when set)",
        subtype='FILE_PATH',
        update=on_ies_external_update,
    )  # type: ignore


class WorldEnvSettings(PropertyGroup):
    """世界环境设置状态(挂在世界数据块上, 随 .blend 保存; 多场景共享世界时同步生效)

    模式与替换背景档位的真值在此(世界面板"环境设置"/"替换背景"子面板的按钮切换);
    环境调节组的镜像字段在 WM 级 SceneHelperState 上(真值在组实例插座上, 镜像绘制
    口径见 _ENV_FIELD_SOCKETS; 不挂本组是因 draw 语境禁写 ID 类数据块的 idprop).
    """

    # 环境设置激活开关(子面板折叠头行尾的 prop toggle 按钮): 未激活时模式体只画
    # 需激活提示(胶囊与参数区都不画), 模式真值(基础/HDRI/程序纹理)独立记忆不受
    # 开关影响; 关闭只摘背景来源线, 链节点保留参数不丢
    env_enabled: BoolProperty(
        name="Environment Enabled",
        default=False,
        update=on_env_enabled_update,
        description="Toggle the environment settings of the scene world (enabling builds the chain for the current mode; disabling unwires the background back to its plain color)",
    )  # type: ignore
    mode: EnumProperty(
        name="Mode",
        items=ENV_MODE_ITEMS,
        default='BASIC',
        update=on_world_env_mode_update,
        description="Which environment preset drives the world",
    )  # type: ignore
    # 替换背景档位(纯色/渐变): 真值双写(枚举镜像 + SWITCH_RepMode 的 Switch 接口,
    # 作者模板已删 Solid or Gradient 布尔节点), 切档经 update 写节点(链未建时静默
    # 跳过, 建链/开链按镜像归位)
    replace_mode: EnumProperty(
        name="Mode",
        items=REPLACE_MODE_ITEMS,
        default='SOLID',
        update=on_env_replace_mode_update,
        description="Whether the replacement background is a plain color or a color gradient",
    )  # type: ignore
    # 外部环境纹理路径(随 .blend 保存): 非空时优先于缩略图选择器(清空恢复选择器
    # 控制权, 与灯光图像档同口径)
    env_image_external: StringProperty(
        name="External Image",
        description="Path to an external image file (overrides the asset picker when set)",
        subtype='FILE_PATH',
        update=on_env_image_external_update,
    )  # type: ignore
