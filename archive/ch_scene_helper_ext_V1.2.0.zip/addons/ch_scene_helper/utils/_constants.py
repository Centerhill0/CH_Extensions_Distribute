"""
插件内跨模块共享的常量

判据(规范 §6.1): 数值型且被两个以上模块引用(或需调参)才收在此; 仅单模块使用的写死值
留在原模块. 按用途分区, 各常量旁注释写明口径来源与版本兼容结论.

分区:
- 材质面板 PBR 子面板: 纹理坐标/投影的镜像枚举候选项(真值在链节点侧, 面板只存镜像)
- 灯光控制器: RIG_DEFAULT_ELEVATION(新建 rig 的控制器仰角, 与面板镜像默认值同源) /
  RIG_DEFAULT_DISTANCE(面板距离默认值, 同时是新建 rig 的初始距离下限)
- 相机独立分辨率: CAMERA_RES_MAX(属性组 RNA 上限与算法层收口上限)
- 灯光&阴影链接: LINK_TYPE_ITEMS(链接算子 link_type 属性的候选项, 对应 receiver/blocker)
"""

from math import radians

# ------------------------------------------------------------
# 材质面板 PBR 子面板(镜像枚举)
# ------------------------------------------------------------

# 纹理坐标下拉的候选项(镜像枚举, 见 props.SceneHelperState.pbr_uv_output)
# - 三元组 (标识, 名称, 描述): EnumProperty items 的最小合法形态; 描述给英文(运行期不翻译)
# - 标识/名称一律 ASCII(动态枚举文案口径): 三项均为 Blender 节点原词, 系统词典已含
#   (Generated->生成 / UV->UV / Object->物体), 插件词典不得再收录
# - default 必须是整数下标(动态枚举)
TEXCOORD_OPTIONS = (
    ("GENERATED", "Generated", "Use the Generated texture coordinate output"),
    ("UV", "UV", "Use the UV texture coordinate output"),
    ("OBJECT", "Object", "Use the Object texture coordinate output"),
)


# 投影统一控制的候选项(全部贴图统一控制, 见 props.SceneHelperState.pbr_projection)
# - 四项与 Image Texture.projection 的原生枚举一致(FLAT/BOX/SPHERE/TUBE)
# - 标识/名称一律 ASCII(pitfalls §9)
# - 不设 Mixed 哨兵项: 各图投影不一致时下拉**保持镜像原值不变**,
#   不再声称任何一张图的当前状态; 选定任一项即统一写全部命中纹理
PROJECTION_OPTIONS = (
    ("FLAT", "Flat", "Project the image flat along the axes"),
    ("BOX", "Box", "Project the image as a box, with blend between sides"),
    ("SPHERE", "Sphere", "Project the image spherically around the object"),
    ("TUBE", "Tube", "Project the image from the tube using the Z axis as central"),
)

# ------------------------------------------------------------
# 灯光控制器(rig)
# ------------------------------------------------------------

# 新建 rig 时控制器绕 X 轴抬起的初始仰角(弧度): 灯光随之抬到 45°, 高度角属性从创建起
# 即真实值. 与 props.SceneHelperState.rig_elevation 的默认值同源
# ——本常量是唯一出处, 面板镜像与 light_rig.create_light_rig 都引用它, 不得各自内联
RIG_DEFAULT_ELEVATION = radians(45.0)

# 灯光到控制器的默认距离(米): 面板"距离"镜像的默认值(右键恢复默认值即回到本值), 同时是
# 新建 rig 初始偏移的下限. 两处同一口径——"默认距离"只有一个数
RIG_DEFAULT_DISTANCE = 5.0

# 新建 rig 的灯光功率(瓦): 点光/聚光/区域光创建即按本值设 energy, 太阳光亮度单位是 W/m²
# (量纲不同)保持 Blender 默认不设
RIG_DEFAULT_ENERGY = 100.0

# 新建 rig 的面光源默认边长(米): AREA 形状保持 Blender 默认 SQUARE, size 即正方形边长.
# 面板与饼菜单两入口共用本创建路径, 默认尺寸只有一个数
RIG_DEFAULT_AREA_SIZE = 1.0

# ------------------------------------------------------------
# 相机独立分辨率
# ------------------------------------------------------------

# 相机独立分辨率的上限: props.CameraResolutionSettings 的 res_x/res_y RNA max 与
# resolution.init_camera_resolution_from_scene 的收口钳位共用; 下限 4 只在算法层用
# (见 resolution.py 的 _RES_MIN, 原生 render.resolution 语义), 不进本模块
CAMERA_RES_MAX = 10000

# ------------------------------------------------------------
# 灯光&阴影链接
# ------------------------------------------------------------

# 链接集合种类(链接算子 link_type 属性的 items): 接收者 / 阴影遮挡者.
# 与 Object.light_linking 的 receiver/blocker 两个集合指针一一对应
LINK_TYPE_ITEMS = (
    ('RECEIVER', "Receiver", ""),
    ('BLOCKER', "Blocker", ""),
)
