"""灯光链接数据查询工具模块

围绕 Blender 发射器中心灯光链接模型(Object.light_linking 的 receiver/blocker 集合)的
纯查询算法, 供"灯光&阴影链接"子面板与链接写入算子共用.

主要功能:
- linking_collection_of: 取灯的灯光/阴影链接集合指针
- iter_linking_members: 链接集合直接成员条目(含身份还原)
- find_linking_entry: 按名称定位直接成员条目(状态切换/移除用)
- link_state_of_target: 目标在链接集合内的有效状态(排除恒胜包含, 与 depsgraph 求值同口径)
- expand_linking_objects: 递归展开链接集合的全部物体成员(选中接收者用)
- scene_used_collection: 集合是否为某场景的主集合(链接写入禁用条件, 与原生同)
- sync_link_member_list / sync_object_link_lists: 链接列表镜像的签名比对重建
  (面板 template_list 数据源, 条目载荷见 props.LightLinkItem)
- bbox_wireframe_polylines / bbox_top_center / bbox_center / arrow_wing_points:
  链接预览的世界几何(边界盒线框/顶面中心/中心/箭头两翼)
"""

import bpy

from mathutils import Vector
from bpy.types import Collection, Object


def linking_collection_of(obj: Object, link_type: str) -> Collection | None:
    """obj 的灯光/阴影链接集合指针, 未启用返回 None

    Args:
        obj: 发射器物体(灯); link_type: 'RECEIVER' 或 'BLOCKER'
    """
    if link_type == 'RECEIVER':
        return obj.light_linking.receiver_collection
    return obj.light_linking.blocker_collection


def iter_linking_members(coll: Collection) -> list[tuple[str, object, object, bool]]:
    """链接集合直接成员条目列表(子集合在前,物体在后, 与原生链接模板同序)

    CollectionObject/CollectionChild 条目不暴露所指数据块, 靠与 objects/children
    对同一 listbase 的同序迭代 zip 配对还原身份.

    Returns:
        (成员名, 条目(含 light_linking), 成员数据块, 是否子集合) 列表
    """
    members: list[tuple[str, object, object, bool]] = []
    for entry, child in zip(coll.collection_children, coll.children):
        members.append((child.name, entry, child, True))
    for entry, obj in zip(coll.collection_objects, coll.objects):
        members.append((obj.name, entry, obj, False))
    return members


def find_linking_entry(coll: Collection, name: str, is_collection: bool):
    """按名称定位直接成员条目, 非直接成员返回 None"""
    pairs = zip(coll.collection_children, coll.children) if is_collection else zip(coll.collection_objects, coll.objects)
    for entry, member in pairs:
        if member.name == name:
            return entry
    return None


def _referencing_link_states(coll: Collection, target_name: str) -> list[str]:
    """引用到目标的全部条目状态(直接条目 + 逐层含目标的后代子集合条目)"""
    states: list[str] = []
    for entry, obj in zip(coll.collection_objects, coll.objects):
        if obj.name == target_name:
            states.append(entry.light_linking.link_state)
    for entry, child in zip(coll.collection_children, coll.children):
        sub_states = _referencing_link_states(child, target_name)
        if sub_states:
            states.append(entry.light_linking.link_state)
            states.extend(sub_states)
    return states


def link_state_of_target(coll: Collection, target_name: str) -> str | None:
    """目标在链接集合内的有效状态, 与集合无约束关系时返回 None

    求值口径与 depsgraph 一致: 任一路径排除即排除, 否则任一路径包含即包含;
    一个条目状态是否生效只看其集合是否(直接或经嵌套)含有目标.
    """
    states = _referencing_link_states(coll, target_name)
    if 'EXCLUDE' in states:
        return 'EXCLUDE'
    if 'INCLUDE' in states:
        return 'INCLUDE'
    return None


def expand_linking_objects(coll: Collection) -> list[Object]:
    """递归展开链接集合的全部物体成员(子集合逐层展开, 去重保序)"""
    objects: list[Object] = []
    seen: set[str] = set()

    def _walk(collection: Collection) -> None:
        for _entry, obj in zip(collection.collection_objects, collection.objects):
            if obj.name not in seen:
                seen.add(obj.name)
                objects.append(obj)
        for _entry, child in zip(collection.collection_children, collection.children):
            _walk(child)

    _walk(coll)
    return objects


def scene_used_collection(coll: Collection) -> bool:
    """集合是否为某个场景的主集合(原生禁止把这类集合当链接集合写入)"""
    return any(scene.collection == coll for scene in bpy.data.scenes)


def _world_bbox(obj: Object):
    """物体世界边界盒的 min/max 角

    bound_box 恒为 8 角; 空物体等无几何物体 8 角全 0, 零尺寸盒由调用方 min==max
    判定兜底(bound_box 为空返回 None 的口径不存在, 调用方的 None 分支仅作守卫保留).
    """
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    if not corners:
        return None, None
    min_corner = Vector((min(c.x for c in corners), min(c.y for c in corners), min(c.z for c in corners)))
    max_corner = Vector((max(c.x for c in corners), max(c.y for c in corners), max(c.z for c in corners)))
    return min_corner, max_corner


def bbox_wireframe_polylines(obj: Object) -> list:
    """物体世界边界盒的 12 条棱, 组织为 6 条折线(底/顶矩形环 + 四条竖棱)

    零尺寸盒(集合实例空体等无几何物体)返回空列表, 调用方跳过线框绘制.
    """
    min_corner, max_corner = _world_bbox(obj)
    if min_corner is None:
        return []
    if (max_corner - min_corner).length < 1e-6:
        return []
    bottom = [
        Vector((min_corner.x, min_corner.y, min_corner.z)),
        Vector((max_corner.x, min_corner.y, min_corner.z)),
        Vector((max_corner.x, max_corner.y, min_corner.z)),
        Vector((min_corner.x, max_corner.y, min_corner.z)),
        Vector((min_corner.x, min_corner.y, min_corner.z)),
    ]
    top = [
        Vector((min_corner.x, min_corner.y, max_corner.z)),
        Vector((max_corner.x, min_corner.y, max_corner.z)),
        Vector((max_corner.x, max_corner.y, max_corner.z)),
        Vector((min_corner.x, max_corner.y, max_corner.z)),
        Vector((min_corner.x, min_corner.y, max_corner.z)),
    ]
    verticals = [[bottom[i].copy(), top[i].copy()] for i in range(4)]
    return [bottom, top] + verticals


def bbox_top_center(obj: Object) -> Vector | None:
    """物体世界边界盒顶面中心(预览线在物体端的落点); 无几何时回退原点"""
    min_corner, max_corner = _world_bbox(obj)
    if min_corner is None:
        return None
    return Vector(((min_corner.x + max_corner.x) * 0.5, (min_corner.y + max_corner.y) * 0.5, max_corner.z))


def bbox_center(obj: Object) -> Vector | None:
    """物体世界边界盒中心(反查预览线在物体端的起点); 无几何时回退原点"""
    min_corner, max_corner = _world_bbox(obj)
    if min_corner is None:
        return None
    return (min_corner + max_corner) * 0.5


def arrow_wing_points(tip: Vector, direction: Vector, length: float):
    """箭头两翼点(世界坐标, 翼面取水平垂直于线的平面), 方向为零向量返回 None"""
    if direction.length < 1e-9:
        return None
    forward = direction.normalized()
    side = forward.cross(Vector((0.0, 0.0, 1.0)))
    if side.length < 1e-6:
        side = forward.cross(Vector((1.0, 0.0, 0.0)))
    side.normalize()
    base = tip - forward * length
    return (base + side * length * 0.45, base - side * length * 0.45)


def _sync_link_mirror(state, collection_prop: str, index_prop: str, rows: list) -> None:
    """镜像集合整体重建(签名比对由调用方负责); 活跃索引按真名跟随, 失效再数值夹取

    rows 为 LightLinkItem 字段 dict 列表(键 = 属性名).
    """
    collection = getattr(state, collection_prop)
    if 0 <= getattr(state, index_prop) < len(collection):
        current_name = collection[getattr(state, index_prop)].src_name
    else:
        current_name = ""
    collection.clear()
    for fields in rows:
        item = collection.add()
        for attr, value in fields.items():
            setattr(item, attr, value)
    idx = next((i for i, item in enumerate(collection) if item.src_name == current_name), -1)
    if idx < 0:
        idx = min(getattr(state, index_prop), max(len(collection) - 1, 0))
    setattr(state, index_prop, idx)


def sync_link_member_list(state, mode: str, light, link_type: str) -> None:
    """灯光/阴影链接模式的成员镜像列表, 签名比对重建(真值在灯侧链接集合)

    绘制期调用: 签名 = 模式 + 发射器 + 成员(名称/种类/状态)序列, 任一变化才整体重建;
    条目字段即行内钮载荷(见 props.LightLinkItem). state 为 SceneHelperState.
    """
    coll = linking_collection_of(light, link_type)
    members = iter_linking_members(coll) if coll is not None else []
    writable = light.library is None
    signature = "|".join([mode, light.name, str(writable)] + ["{}:{}:{}".format(name, int(is_collection), entry.light_linking.link_state) for name, entry, _member, is_collection in members])
    if signature == state.link_members_signature:
        return
    state.link_members_signature = signature
    _sync_link_mirror(
        state,
        "link_members",
        "link_members_index",
        [
            {
                "src_name": name,
                "emitter_name": light.name,
                "link_type": link_type,
                "state": entry.light_linking.link_state,
                "is_collection": is_collection,
                "writable": writable,
            }
            for name, entry, _member, is_collection in members
        ],
    )


def sync_object_link_lists(state, obj_name: str, lights: list, is_collection: bool = False) -> None:
    """物体链接模式的反查镜像列表(合并行: 一行一灯, 双侧状态), 签名比对重建

    灯光与阴影链接合并在一个列表: 一行一灯, state/direct 为灯光链接侧,
    shadow_state/shadow_direct 为阴影链接侧(空串 = 该灯此侧无关系), users =
    共享该灯灯光链接集合的灯数(无灯光链接集合时回退阴影集合). 顺序随面板灯光列表.
    主体二态(作者定的集合视角): is_collection=False 主体 = 视口活动物体, 状态取
    递归展开嵌套子集合后的有效态(排除恒胜包含); is_collection=True 主体 = 活动集合,
    状态取该集合作为**直接子集合条目**的状态(不递归, 与原生链接列表只列直接成员
    同口径), 该集合不是某灯的直接子集合时该灯此侧为空串并整行不画该侧钮.
    签名 = 主体种类 + 主体名 + 全部行(灯名/双侧状态与直接性/用户数)序列.
    """
    rows = []
    for light in lights:
        receiver = linking_collection_of(light, 'RECEIVER')
        blocker = linking_collection_of(light, 'BLOCKER')
        if is_collection:
            r_entry = find_linking_entry(receiver, obj_name, True) if receiver is not None else None
            b_entry = find_linking_entry(blocker, obj_name, True) if blocker is not None else None
            r_state = r_entry.light_linking.link_state if r_entry is not None else None
            b_state = b_entry.light_linking.link_state if b_entry is not None else None
            r_direct = r_entry is not None
            b_direct = b_entry is not None
        else:
            r_state = link_state_of_target(receiver, obj_name) if receiver is not None else None
            b_state = link_state_of_target(blocker, obj_name) if blocker is not None else None
            r_direct = find_linking_entry(receiver, obj_name, False) is not None if receiver is not None else False
            b_direct = find_linking_entry(blocker, obj_name, False) is not None if blocker is not None else False
        if r_state is None and b_state is None:
            continue
        if receiver is not None:
            users = sum(1 for obj in lights if linking_collection_of(obj, 'RECEIVER') is receiver)
        elif blocker is not None:
            users = sum(1 for obj in lights if linking_collection_of(obj, 'BLOCKER') is blocker)
        else:
            users = 1
        rows.append(
            {
                "src_name": light.name,
                "emitter_name": light.name,
                "subject_name": obj_name,
                "link_type": 'RECEIVER',
                "state": r_state or "",
                "is_collection": is_collection,
                "direct": r_direct,
                "writable": light.library is None,
                "shadow_state": b_state or "",
                "shadow_direct": b_direct,
                "users": users,
            }
        )

    def _sig() -> str:
        return ",".join("{}:{}:{}:{}:{}:{}".format(r["src_name"], r["state"], int(r["direct"]), r["shadow_state"], int(r["shadow_direct"]), r["users"]) for r in rows)

    signature = ("C" if is_collection else "O") + "|" + obj_name + "|" + _sig()
    if signature == state.object_link_signature:
        return
    state.object_link_signature = signature
    _sync_link_mirror(state, "object_light_links", "object_light_links_index", rows)
