"""
物体选中工具模块

行内"选中关联物体",材质/图像使用者批量选中与相机切换共用的选中算法.
"""

from bpy.types import Context, Object


def is_selectable(context: Context, obj: Object) -> bool:
    """物体是否在视图层内可选中

    exclude 集合内的物体不在 view_layer.objects 里, 对它 select_set(True) 或设为
    活动物体会抛 RuntimeError(5.1.2 实测); 选中路径一律经本谓词跳过不可选中者.
    view_layer.objects 按名取值, 同名本地/链接对会命中先挂的孪生行(pitfalls §19)——
    命中的不是本对象时全扫指针核对(常见路径仍是 O(1)).
    """
    gotten = context.view_layer.objects.get(obj.name)
    if gotten is None:
        return False
    if gotten == obj:
        return True
    return any(candidate == obj for candidate in context.view_layer.objects)


def select_only(context: Context, objects: list, active: Object | None = None) -> None:
    """只选中给定物体(按名称集合写选中态), 并把 active 设为活动物体

    先设活动物体再遍历选中: 后台实测 active 为 None 时 select_set(True) 静默失效;
    迭代 view_layer.objects 的副本, 避免边选中边改动活集合令迭代器失效.
    不在视图层内的物体(被排除集合)跳过; 全部不可选中时不改动任何状态.
    """
    objects = [obj for obj in objects if obj is not None and is_selectable(context, obj)]
    if not objects:
        return
    first_obj = active if active is not None and is_selectable(context, active) else objects[0]
    context.view_layer.objects.active = first_obj
    selected_names = {obj.name for obj in objects}
    for obj in list(context.view_layer.objects):
        if obj is not None:
            obj.select_set(obj.name in selected_names)


def select_object(context: Context, obj: Object, extend: bool = False, deselect: bool = False) -> None:
    """选中单个物体(extend 加选, deselect 减选, 否则独占选中并设为活动物体)

    不在视图层内的物体(被排除集合)完全跳过——不清选,不写选中态,不设活动, 不抛错.
    """
    if not is_selectable(context, obj):
        return
    if not extend and not deselect:
        for other in context.selected_objects:
            other.select_set(False)
    obj.select_set(not deselect)
    if not deselect:
        context.view_layer.objects.active = obj
