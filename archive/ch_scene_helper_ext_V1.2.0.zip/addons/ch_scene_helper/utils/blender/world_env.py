"""
世界环境算法模块

以常驻节点链的方式管理世界节点树上的三档环境背景(基础/HDRI/程序纹理)与替换背景:
结构与坐标照抄作者 HDRI_Universal 模板(Shader_Nodes.blend), HDRI Setting 为代码重建
的模板节点组(组随 .blend 保存, Tint/着色强度经组接口传入取代作者的 RGB_Tint 遗留
节点); 输出区三件套 = 背景 -> Mix Shader -> World Output, 背景与世界输出**直接复用
树里已有的出厂节点**(没有才新建), 模式切换只改背景 Color 插座的来源接线(HDRI = 调节
组结果, 程序纹理 = 天空纹理, 基础 = 不接线用默认色), 替换背景恒接 Mix Shader 第二个
着色器插槽, 由两个分流 Switch 节点(SWITCH_BgMode/SWITCH_RepMode)的切换接口直写分流
(作者模板已删布尔节点). 链的构建只在算子 execute 里发生(绘制期不写数据).

主要功能:
- ensure_world_env_chain: 按世界的环境模式建环境链/重接(幂等; 模式切换算子调用)
- ensure_world_replace_chain: 建替换背景链(幂等; 替换背景开关算子调用)
- find_world_env_node: 按标记取世界树里的插件节点(面板直绘插座与选择器落点共用)
- MARK_WORLD_ENV_*: 各插件节点的标记常量(绘制与选择器落点共用)
"""

import math

import bpy
from bpy.types import Node, NodeTree, World

# 插件节点的归属标记(node 级 IDProperty, 用户改名节点后仍可识别); 键名借 World.ch_env
# 属性组的 RNA 名(同名 RNA 已在 _addon_properties 注册, 按 §10.3 口径遮蔽"自定义属性"
# 面板; 与灯光链 node["ch_advanced"] 借 light.ch_advanced 同构, Node 与 World 是两个
# 数据块对象, 同名互不冲突)
_MARKER_KEY = "ch_env"

# 模板组与链 Frame 的标记前缀
_TEMPLATE_KIND = "TEMPLATE:"
_FRAME_KIND = "FRAME:"

# 链节点标记值(面板与选择器按标记取节点)
MARK_WORLD_ENV_MIX = "MIX"
MARK_WORLD_ENV_TEXCOORD = "TEXCOORD"
MARK_WORLD_ENV_BG = "MAIN_BG"
MARK_WORLD_ENV_OUTPUT = "MAIN_OUTPUT"
MARK_WORLD_ENV_HDRI_MAP = "HDRI_MAP"
MARK_WORLD_ENV_HDRI_TEX = "HDRI_TEX"
MARK_WORLD_ENV_HDRI_SETTING = "HDRI_SETTING"
MARK_WORLD_ENV_SKY_TEX = "SKY_TEX"
MARK_WORLD_ENV_REPLACE_MAP = "REPLACE_MAP"
MARK_WORLD_ENV_REPLACE_GRADIENT = "REPLACE_GRADIENT"
MARK_WORLD_ENV_REPLACE_RAMP = "REPLACE_RAMP"
MARK_WORLD_ENV_REPLACE_COLOR = "REPLACE_COLOR"
MARK_WORLD_ENV_REPLACE_RAMP_SWITCH = "REPLACE_RAMP_SWITCH"
MARK_WORLD_ENV_REPLACE_BG = "REPLACE_BG"
MARK_WORLD_ENV_REPLACE_LIGHT_PATH = "REPLACE_LIGHT_PATH"
MARK_WORLD_ENV_REPLACE_SWITCH = "REPLACE_SWITCH"

# 模板节点组的 bpy.data.node_groups 名(ch_ 前缀: 作者原组同名时不冲突)与模板标记
_ENV_SETTINGS_TREE_NAME = "ch_world_env_settings"
_ENV_SETTINGS_TEMPLATE_MARKER = _TEMPLATE_KIND + "ENV_SETTINGS"

# 四个 Frame 的标签与位置(照抄作者模板)
_ENV_FRAMES = {
    'HDRI': ("HDRI", -1149.0, 421.8),
    'PROCEDURAL': ("程序纹理", -709.0, -24.2),
    'REPLACE_CONTENT': ("替换用背景", -1509.0, -444.2),
    'REPLACE_MODE': ("替换背景", -229.0, 395.8),
}

# 输出区三件套与 TEXCOORD 的绝对坐标(照抄作者模板; 背景与世界输出复用树里已有的
# 出厂节点, 没有才新建)
_TEXCOORD_LOC = (-1820.0, 20.0)
_BG_LOC = (-200.0, 100.0)
_MIX_LOC = (-20.0, 100.0)
_OUTPUT_LOC = (160.0, 100.0)

# HDRI 档链内节点的相对 Frame 坐标(照抄作者模板)
_HDRI_MAP_LOC = (29.0, -41.8)
_HDRI_TEX_LOC = (209.0, -41.8)
_HDRI_SETTING_LOC = (489.0, -41.8)

# 程序纹理档的相对 Frame 坐标(照抄作者模板)
_SKY_TEX_LOC = (29.0, -35.8)

# 替换背景链的相对 Frame 坐标(照抄作者模板)
_REPLACE_MAP_LOC = (29.0, -55.8)
_REPLACE_GRADIENT_LOC = (209.0, -55.8)
_REPLACE_RAMP_LOC = (389.0, -195.8)
_REPLACE_COLOR_LOC = (489.0, -35.8)
_REPLACE_RAMP_SWITCH_LOC = (669.0, -35.8)
_REPLACE_BG_LOC = (849.0, -35.8)
_REPLACE_LIGHT_PATH_LOC = (29.0, -35.8)
_REPLACE_SWITCH_LOC = (209.0, -35.8)


def _marked(nodes, marker: str):
    """按归属标记取节点(取不到返回 None)"""
    for node in nodes:
        if node.get(_MARKER_KEY) == marker:
            return node
    return None


def find_world_env_node(world, marker: str):
    """取世界节点树中带指定标记的插件节点(无世界/无树/无节点返回 None)"""
    if world is None or world.node_tree is None:
        return None
    return _marked(world.node_tree.nodes, marker)


def _mix_socket(sockets, name: str, socket_type: str):
    """ShaderNodeMix 的 RGBA 插座(A/B/Result 同名多类型并存, 按启用 + 类型取)"""
    for socket in sockets:
        if socket.enabled and socket.name == name and socket.type == socket_type:
            return socket
    return None


def collect_world_env_orphans(world: World) -> list:
    """世界节点树里的孤立节点(从 World Output 反向不可达), 供清理算子删除

    与灯光版同口径: **只要孤立就清理**(按模式生成的链切走档后即孤立, 清后重进档
    重建), 不豁免带归属标记的链节点; Frame 恒保留(组织容器). 无树/库链接世界返回
    空表.
    """
    if world is None or world.library is not None or world.node_tree is None:
        return []
    tree = world.node_tree
    stack = [node for node in tree.nodes if node.type == 'OUTPUT_WORLD']
    if not stack:
        # 无输出节点时反向可达集为空, 全树都会被判孤立 - 按无锚点口径不清理
        return []
    reachable = set()
    while stack:
        node = stack.pop()
        if node in reachable:
            continue
        reachable.add(node)
        for socket in node.inputs:
            for link in socket.links:
                stack.append(link.from_node)
    return [node for node in tree.nodes if node not in reachable and node.type != 'FRAME']


# ------------------------------------------------------------
# HDRI Setting 模板节点组(代码重建, 结构与坐标照抄作者组"环境背景设置")
# ------------------------------------------------------------


def _new_float_socket(tree: NodeTree, name: str, default: float, min_value: float = None, max_value: float = None):
    """给模板组加一个浮点输入接口(带范围与默认值)"""
    socket = tree.interface.new_socket(name=name, in_out='INPUT', socket_type='NodeSocketFloat')
    socket.default_value = default
    if min_value is not None:
        socket.min_value = min_value
    if max_value is not None:
        socket.max_value = max_value
    return socket


def _env_frame(tree: NodeTree, label: str, loc: tuple) -> Node:
    """模板组内的组织 Frame(新建; location 照抄作者模板)"""
    frame = tree.nodes.new('NodeFrame')
    frame.label = label
    frame.location = loc
    return frame


def _pin(node: Node, frame: Node, loc: tuple) -> None:
    """把节点钉回预设坐标与 Frame

    先挂父级,再写 location: 给已定位的 Frame 赋 parent 时, Blender 按"保持视觉位置"
    把 location 反算成差值(loc - frame.location), 顺序反了 loc 就成了绝对坐标, 各档
    内容会全叠到 Frame 处(灯光高级设置 5.1.2 实测, 见 memories/blender-api-pitfalls §31).
    挂完再写 location 才是相对 Frame 的偏移.
    """
    node.parent = frame
    node.location = loc


def _build_env_settings_template() -> NodeTree:
    """环境调节模板组(接口/节点/连线/坐标照抄作者组): 曝光乘改 -> Tint 乘染(色值与
    强度经组接口传入) -> HSV -> Gamma 整形, 主链经 Reroute 分出高光强化支路(亮度按
    阈值取遮罩 * 增益, 乘进主色后再加回). ShaderNodeMix 的曝光/强化/补光三处 Factor
    无接线恒 1 = 完全应用 blend 结果(乘/加语义), Tint 档 Factor = 着色强度接口, 与
    作者组一致.
    """
    tree = bpy.data.node_groups.new(_ENV_SETTINGS_TREE_NAME, 'ShaderNodeTree')
    color = tree.interface.new_socket(name="Color", in_out='INPUT', socket_type='NodeSocketColor')
    color.default_value = (0.5, 0.5, 0.5, 1.0)
    _new_float_socket(tree, "Exposure", 0.0)
    _new_float_socket(tree, "Hue", 0.5, 0.0, 1.0)
    _new_float_socket(tree, "Saturation", 1.0, 0.0, 2.0)
    _new_float_socket(tree, "Gamma", 1.0, 0.001, 10.0)
    _new_float_socket(tree, "高光增益", 0.0, -10000.0, 10000.0)
    # 作者模板新版: Tint 与着色强度取代原 RGB_Tint 节点(染色色值与强度经组接口传入)
    tint = tree.interface.new_socket(name="Tint", in_out='INPUT', socket_type='NodeSocketColor')
    tint.default_value = (1.0, 1.0, 1.0, 1.0)
    _new_float_socket(tree, "着色强度", 1.0, 0.0, 1.0)
    tree.interface.new_socket(name="Result", in_out='OUTPUT', socket_type='NodeSocketColor')

    group_input = tree.nodes.new('NodeGroupInput')
    group_input.location = (-900.0, -480.0)
    group_output = tree.nodes.new('NodeGroupOutput')
    group_output.location = (2060.0, 140.0)

    # F01 曝光与色彩(坐标照抄作者组; Frame 内为相对坐标)
    frame01 = _env_frame(tree, "F01 曝光与色彩", (-689.0, 141.8))
    math_exposure = tree.nodes.new('ShaderNodeMath')
    math_exposure.operation = 'ADD'
    # 第二操作数 = 1.0(照抄作者组): 语义为 Color * (Exposure + 1), 出厂默认 0.5 会让
    # 中性曝光 0 时画面减半亮度(独立复核 P1)
    math_exposure.inputs[1].default_value = 1.0
    _pin(math_exposure, frame01, (29.0, -261.8))
    mix_exposure = tree.nodes.new('ShaderNodeMix')
    mix_exposure.name = "MIX_Exposure"
    mix_exposure.blend_type = 'MULTIPLY'
    mix_exposure.data_type = 'RGBA'
    _pin(mix_exposure, frame01, (209.0, -41.8))
    mix_tint = tree.nodes.new('ShaderNodeMix')
    mix_tint.name = "MIX_Tint"
    mix_tint.blend_type = 'MULTIPLY'
    mix_tint.data_type = 'RGBA'
    _pin(mix_tint, frame01, (389.0, -41.8))
    hsv_color = tree.nodes.new('ShaderNodeHueSaturation')
    hsv_color.name = "HSV_Color"
    _pin(hsv_color, frame01, (569.0, -41.8))
    gamma_color = tree.nodes.new('ShaderNodeGamma')
    gamma_color.name = "GAMMA_Color"
    _pin(gamma_color, frame01, (749.0, -41.8))

    # F02 高光强化
    frame02 = _env_frame(tree, "F02 高光强化", (266.17, 141.8))
    route_main = tree.nodes.new('NodeReroute')
    route_main.name = "ROUTE_ColorMain"
    _pin(route_main, frame02, (33.8, -341.8))
    rgb2bw = tree.nodes.new('ShaderNodeRGBToBW')
    rgb2bw.name = "RGB2BW_Luminance"
    _pin(rgb2bw, frame02, (53.8, -41.8))
    val_threshold = tree.nodes.new('ShaderNodeValue')
    val_threshold.name = "VAL_SUN_THRESHOLD"
    val_threshold.outputs[0].default_value = 0.9
    _pin(val_threshold, frame02, (53.8, -121.8))
    map_range = tree.nodes.new('ShaderNodeMapRange')
    map_range.name = "MAPRANGE_SunMask"
    map_range.data_type = 'FLOAT'
    _pin(map_range, frame02, (233.8, -41.8))
    math_gain = tree.nodes.new('ShaderNodeMath')
    math_gain.name = "MATH_SunGain"
    math_gain.operation = 'MULTIPLY'
    _pin(math_gain, frame02, (413.8, -41.8))
    mix_boost = tree.nodes.new('ShaderNodeMix')
    mix_boost.name = "MIX_SunBoost"
    mix_boost.blend_type = 'MULTIPLY'
    mix_boost.data_type = 'RGBA'
    _pin(mix_boost, frame02, (593.8, -41.8))
    mix_add = tree.nodes.new('ShaderNodeMix')
    mix_add.name = "MIX_SunAdd"
    mix_add.blend_type = 'ADD'
    mix_add.data_type = 'RGBA'
    _pin(mix_add, frame02, (773.8, -41.8))
    route_input_a = tree.nodes.new('NodeReroute')
    route_input_a.name = "ROUTE_SunInputA"
    _pin(route_input_a, frame02, (573.8, -341.8))
    route_input_b = tree.nodes.new('NodeReroute')
    route_input_b.name = "ROUTE_SunInputB"
    _pin(route_input_b, frame02, (753.8, -341.8))

    links = tree.links
    # 曝光与色彩主链: Color * (Exposure + 1) -> * Tint -> HSV -> Gamma
    links.new(group_input.outputs["Color"], _mix_socket(mix_exposure.inputs, "A", 'RGBA'))
    links.new(math_exposure.outputs[0], _mix_socket(mix_exposure.inputs, "B", 'RGBA'))
    links.new(group_input.outputs["Exposure"], math_exposure.inputs[0])
    links.new(_mix_socket(mix_exposure.outputs, "Result", 'RGBA'), _mix_socket(mix_tint.inputs, "A", 'RGBA'))
    links.new(group_input.outputs["Tint"], _mix_socket(mix_tint.inputs, "B", 'RGBA'))
    links.new(group_input.outputs["着色强度"], _mix_socket(mix_tint.inputs, "Factor", 'VALUE'))
    links.new(_mix_socket(mix_tint.outputs, "Result", 'RGBA'), hsv_color.inputs["Color"])
    links.new(group_input.outputs["Hue"], hsv_color.inputs["Hue"])
    links.new(group_input.outputs["Saturation"], hsv_color.inputs["Saturation"])
    links.new(hsv_color.outputs["Color"], gamma_color.inputs["Color"])
    links.new(group_input.outputs["Gamma"], gamma_color.inputs["Gamma"])
    # 主链经 Reroute 分流: 亮度遮罩支路 + 两个 Mix 的 A 输入
    links.new(gamma_color.outputs["Color"], route_main.inputs[0])
    links.new(route_main.outputs[0], rgb2bw.inputs["Color"])
    links.new(route_main.outputs[0], route_input_a.inputs[0])
    links.new(route_input_a.outputs[0], route_input_b.inputs[0])
    links.new(route_input_a.outputs[0], _mix_socket(mix_boost.inputs, "A", 'RGBA'))
    # 高光强化支路: 亮度按阈值取遮罩 * 高光增益 -> 乘进主色 -> 再加回
    links.new(val_threshold.outputs[0], map_range.inputs["From Min"])
    links.new(rgb2bw.outputs["Val"], map_range.inputs["Value"])
    links.new(map_range.outputs["Result"], math_gain.inputs[0])
    links.new(group_input.outputs["高光增益"], math_gain.inputs[1])
    links.new(math_gain.outputs[0], _mix_socket(mix_boost.inputs, "B", 'RGBA'))
    links.new(route_input_b.outputs[0], _mix_socket(mix_add.inputs, "A", 'RGBA'))
    links.new(_mix_socket(mix_boost.outputs, "Result", 'RGBA'), _mix_socket(mix_add.inputs, "B", 'RGBA'))
    links.new(_mix_socket(mix_add.outputs, "Result", 'RGBA'), group_output.inputs["Result"])
    tree[_MARKER_KEY] = _ENV_SETTINGS_TEMPLATE_MARKER
    return tree


def _ensure_env_settings_template() -> NodeTree:
    """确保环境调节模板组存在(按标记查复用, 缺失重建; 组随使用它的 .blend 保存)

    复用时归位曝光第二操作数(早期重建版漏写 1.0, 独立复核 P1; 该值面板不暴露,
    归位口径同 Frame).
    """
    for tree in bpy.data.node_groups:
        if tree.get(_MARKER_KEY) == _ENV_SETTINGS_TEMPLATE_MARKER:
            for node in tree.nodes:
                if node.type == 'MATH' and node.operation == 'ADD':
                    node.inputs[1].default_value = 1.0
            return tree
    return _build_env_settings_template()


# ------------------------------------------------------------
# 世界节点树上的常驻链(建链只在模式切换算子 execute 里发生)
# ------------------------------------------------------------


def _chain_frame(tree: NodeTree, mode_key: str) -> Node:
    """按档取/建链 Frame(组织容器; 标签与位置照抄作者模板, 见 _ENV_FRAMES)

    位置每次调用都重写: Frame 会随内容自动收缩, 手拖或历史漂移都在下一次 apply 归位
    (代价是不保留用户对 Frame 的手动摆位).
    """
    label, frame_x, frame_y = _ENV_FRAMES[mode_key]
    marker = _FRAME_KIND + mode_key
    frame = _marked(tree.nodes, marker)
    if frame is None:
        frame = tree.nodes.new('NodeFrame')
        frame.name = "ch_env_frame_" + mode_key.lower()
        frame.label = label
        frame[_MARKER_KEY] = marker
    frame.location = (frame_x, frame_y)
    return frame


def _ensure_marked_node(tree: NodeTree, marker: str, bl_idname: str, name: str, frame, loc: tuple) -> Node:
    """按标记取/建一个链节点(误删重建), 并钉回预设坐标与 Frame(可为 None)"""
    node = _marked(tree.nodes, marker)
    if node is None:
        node = tree.nodes.new(bl_idname)
        node.name = name
        node[_MARKER_KEY] = marker
    if frame is not None:
        _pin(node, frame, loc)
    else:
        node.parent = None
        node.location = loc
    return node


def _ensure_output_chain(tree: NodeTree) -> tuple:
    """输出区三件套(背景/Mix Shader/世界输出)与恒接段(环境链与替换链共用)

    背景与世界输出**直接复用树里已有的出厂节点**(打归属标记后按标记复用; 没有才
    新建), 统一归位到模板布局; 背景 -> Mix Shader 第一个着色器插槽恒接, Fac 写 0
    = 替换背景关闭时恒用环境背景(开启时 Fac 被 SWITCH_BgMode 接线接管, 写默认值
    无效果).
    """
    output = _marked(tree.nodes, MARK_WORLD_ENV_OUTPUT)
    active = tree.nodes.active
    if output is None:
        # 复用出厂输出优先取 active(新建输出会自动成为 active, 非 active 的旧输出
        # 不参与渲染), 没有才新建
        output = active if active is not None and active.type == 'OUTPUT_WORLD' else next((node for node in tree.nodes if node.type == 'OUTPUT_WORLD'), None)
        if output is None:
            output = tree.nodes.new('ShaderNodeOutputWorld')
            output.name = "OUTPUT_World"
            output.label = "World Output"
        output[_MARKER_KEY] = MARK_WORLD_ENV_OUTPUT
    elif active is not None and active.type == 'OUTPUT_WORLD' and active != output:
        # 用户新建了第二个输出(active, 参与渲染): 归位到它, 旧输出标记清除(恒单标记,
        # 5.3.0 RC 探针实证双标记残留可长期滞留树上)——旧输出随之孤立交由清理钮回收
        # (独立复核 P2). 注意用 != 而非 is: 两次属性访问得到的 bpy 包装器禁 is 比较
        # (pitfalls §14, 恒不等致本分支误触发)
        if output.get(_MARKER_KEY) is not None:
            del output[_MARKER_KEY]
        output = active
        output[_MARKER_KEY] = MARK_WORLD_ENV_OUTPUT
    output.parent = None
    output.location = _OUTPUT_LOC
    mix = _ensure_marked_node(tree, MARK_WORLD_ENV_MIX, 'ShaderNodeMixShader', "MIXSHADER_CameraLight", None, _MIX_LOC)
    mix.label = "相机/照明分流"
    mix.inputs['Fac'].default_value = 0.0
    bg = _marked(tree.nodes, MARK_WORLD_ENV_BG)
    if bg is None:
        # 复用出厂背景只认无标记节点(带标记的背景属于替换背景等插件链, 不可吞并)
        bg = next((node for node in tree.nodes if node.type == 'BACKGROUND' and node.get(_MARKER_KEY) is None), None)
        if bg is None:
            bg = tree.nodes.new('ShaderNodeBackground')
            bg.name = "Base Background"
            bg.label = "基础背景"
        bg[_MARKER_KEY] = MARK_WORLD_ENV_BG
    bg.parent = None
    bg.location = _BG_LOC
    links = tree.links
    links.new(bg.outputs["Background"], mix.inputs[1])
    links.new(mix.outputs[0], output.inputs["Surface"])
    return mix, bg


def ensure_world_env_chain(world: World) -> None:
    """按世界数据块上的环境模式建环境链并重接统一背景(幂等; 灯光高级设置同口径)

    链按模式需要生成(与灯光高级设置对齐, 首次进入某档才建该档): 基础档 = 仅输出
    三件套(背景/相机照明分流/世界输出), HDRI 档 = 世界坐标 + HDRI Frame 链, 程序
    纹理档 = 天空纹理; 切走档的链节点保留(参数不丢, 清理钮可清). 分流接线: 当前档
    的来源接背景 Color 插座(摘插件旧线再接新线, 基础档不接线用插座默认色), 背景
    输出恒接 Mix Shader 第一个着色器插槽, 强度三档共用. 常驻段接线每次重接(幂等
    修复用户误删的链内线). 激活开关(env_enabled)关闭时不建链不接线(停用语义).
    无世界/库链接世界/无节点树直接返回.
    """
    if world is None or world.library is not None:
        return
    tree = world.node_tree
    if tree is None:
        return
    settings = getattr(world, "ch_env", None)
    if settings is None or not settings.env_enabled:
        # 环境设置未激活: 不建链不接线(开关关闭经 disconnect 摘线, 链节点保留)
        return
    mix, bg = _ensure_output_chain(tree)
    links = tree.links
    mode = getattr(world, "ch_env", None)
    mode_value = mode.mode if mode is not None else 'BASIC'

    if mode_value == 'HDRI':
        texcoord = _ensure_marked_node(tree, MARK_WORLD_ENV_TEXCOORD, 'ShaderNodeTexCoord', "TEXCOORD_World", None, _TEXCOORD_LOC)
        texcoord.label = "世界坐标"
        # HDRI 档(朝向映射 -> 环境纹理 -> 环境调节组)
        frame_hdri = _chain_frame(tree, 'HDRI')
        mapping = _ensure_marked_node(tree, MARK_WORLD_ENV_HDRI_MAP, 'ShaderNodeMapping', "MAPPING_Rotation 1", frame_hdri, _HDRI_MAP_LOC)
        mapping.label = "朝向映射"
        tex_env = _ensure_marked_node(tree, MARK_WORLD_ENV_HDRI_TEX, 'ShaderNodeTexEnvironment', "TEX_Env_HDRI", frame_hdri, _HDRI_TEX_LOC)
        tex_env.label = "TEX_Environment  [EXR/HDR]"
        setting = _ensure_marked_node(tree, MARK_WORLD_ENV_HDRI_SETTING, 'ShaderNodeGroup', "HDRI Setting", frame_hdri, _HDRI_SETTING_LOC)
        template = _ensure_env_settings_template()
        if setting.node_tree != template:
            setting.node_tree = template
        links.new(texcoord.outputs["Generated"], mapping.inputs["Vector"])
        links.new(mapping.outputs["Vector"], tex_env.inputs["Vector"])
        links.new(tex_env.outputs["Color"], setting.inputs["Color"])
        source_marker = MARK_WORLD_ENV_HDRI_SETTING
    elif mode_value == 'PROCEDURAL':
        # 程序纹理档(天空纹理)
        frame_proc = _chain_frame(tree, 'PROCEDURAL')
        _ensure_marked_node(tree, MARK_WORLD_ENV_SKY_TEX, 'ShaderNodeTexSky', "Sky Texture", frame_proc, _SKY_TEX_LOC)
        source_marker = MARK_WORLD_ENV_SKY_TEX
    else:
        source_marker = None

    # 模式接线: 当前档的来源接共享背景的 Color 插座(摘插件旧线再接新线;
    # 基础档不接线, Color 用插座默认色). 激活档的 links.new 会顶掉该插座上残留的
    # 无标记手线(单输入插座替换语义), 基础档不接线不顶 - 与灯光高级设置同口径
    color_socket = bg.inputs["Color"]
    for link in list(color_socket.links):
        if link.from_node.get(_MARKER_KEY) is not None:
            links.remove(link)
    source = _marked(tree.nodes, source_marker) if source_marker else None
    if source is not None:
        # 调节组走 Result 输出, 天空纹理走 Color 输出
        links.new(source.outputs["Result" if source.type == 'GROUP' else "Color"], color_socket)


def disconnect_world_env_chain(world: World) -> None:
    """摘掉背景 Color 插座上的全部插件来源线(环境设置开关关闭 = 停用)

    链节点与三件套保留(参数不丢, 重开开关重进 ensure 即恢复接线); 模式记忆
    (ch_env.mode)不受影响. 库链接世界直接返回(节点树只读, 与 ensure 的守卫对称).
    """
    if world is None or world.library is not None:
        return
    bg = find_world_env_node(world, MARK_WORLD_ENV_BG)
    if bg is None or world.node_tree is None:
        return
    for link in list(bg.inputs["Color"].links):
        if link.from_node.get(_MARKER_KEY) is not None:
            world.node_tree.links.remove(link)


def ensure_world_replace_chain(world: World) -> None:
    """确保替换背景链常驻并接线(幂等; 替换背景开关镜像与档位切换调用)

    添加模板"替换用背景"与"替换背景"两 Frame 的节点(输出区三件套与环境链复用);
    Background Replace 恒接 Mix Shader 第二个着色器插槽, 分流 Switch(SWITCH_BgMode,
    模板默认名 Node)的切换接口由面板开关直写(激活 = 相机光线走替换背景), 节点保留
    参数不丢; 纯色/渐变档位按 ch_env.replace_mode 归位到 SWITCH_RepMode 的切换接口
    (激活 = 渐变).
    """
    if world is None or world.library is not None:
        return
    tree = world.node_tree
    if tree is None:
        return
    mix, _bg = _ensure_output_chain(tree)
    texcoord = _ensure_marked_node(tree, MARK_WORLD_ENV_TEXCOORD, 'ShaderNodeTexCoord', "TEXCOORD_World", None, _TEXCOORD_LOC)
    texcoord.label = "世界坐标"

    # 替换用背景(朝向映射 -> 渐变纹理 -> 色标; 纯色 RGB 与二选一开关)
    frame_content = _chain_frame(tree, 'REPLACE_CONTENT')
    replace_map = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_MAP, 'ShaderNodeMapping', "MAPPING_Rotation 2", frame_content, _REPLACE_MAP_LOC)
    replace_map.label = "朝向映射"
    gradient_tex = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_GRADIENT, 'ShaderNodeTexGradient', "Gradient Texture", frame_content, _REPLACE_GRADIENT_LOC)
    ramp = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_RAMP, 'ShaderNodeValToRGB', "Background Color Ramp", frame_content, _REPLACE_RAMP_LOC)
    solid_color = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_COLOR, 'ShaderNodeRGB', "Color", frame_content, _REPLACE_COLOR_LOC)
    ramp_switch = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_RAMP_SWITCH, 'GeometryNodeSwitch', "SWITCH_RepMode", frame_content, _REPLACE_RAMP_SWITCH_LOC)
    replace_bg = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_BG, 'ShaderNodeBackground', "Background Replace", frame_content, _REPLACE_BG_LOC)
    replace_bg.label = "替换背景"  # 作者模板的结构预设(面板不暴露这几项, 每次归位与 Frame 同口径): 渐变绕 Y 轴
    # 90° 竖直展开, 渐变类型为缓动; 档位切换接口按 ch_env.replace_mode 归位(激活 = 渐变)
    replace_map.inputs["Rotation"].default_value = (0.0, math.pi / 2.0, 0.0)
    gradient_tex.gradient_type = 'EASING'
    settings = getattr(world, "ch_env", None)
    ramp_switch.inputs["Switch"].default_value = settings is not None and settings.replace_mode == 'GRADIENT'

    # 替换背景(光线类型分流; 分流 Switch 由面板开关直写)
    frame_mode = _chain_frame(tree, 'REPLACE_MODE')
    light_path = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_LIGHT_PATH, 'ShaderNodeLightPath', "LIGHT_PATH", frame_mode, _REPLACE_LIGHT_PATH_LOC)
    light_path.label = "光线类型"
    # 链只消费相机光线口, 其余输出口隐藏(作者定)
    for out in light_path.outputs:
        out.hide = out.name != "Is Camera Ray"
    bg_switch = _ensure_marked_node(tree, MARK_WORLD_ENV_REPLACE_SWITCH, 'GeometryNodeSwitch', "SWITCH_BgMode", frame_mode, _REPLACE_SWITCH_LOC)
    # 作者模板口径: 分流节点类型为浮点(True 路 = 相机光线因子), RepMode 恒 RGBA
    # (纯色/渐变色值二选一); 改类型会重建数据插座, 必须先于接线归位
    bg_switch.input_type = 'FLOAT'
    ramp_switch.input_type = 'RGBA'

    # 接线(照抄作者模板; 幂等; 两个分流 Switch 均空置由面板直写)
    links = tree.links
    links.new(texcoord.outputs["Generated"], replace_map.inputs["Vector"])
    links.new(replace_map.outputs["Vector"], gradient_tex.inputs["Vector"])
    links.new(gradient_tex.outputs["Fac"], ramp.inputs["Fac"])
    links.new(solid_color.outputs["Color"], ramp_switch.inputs["False"])
    links.new(ramp.outputs["Color"], ramp_switch.inputs["True"])
    links.new(ramp_switch.outputs["Output"], replace_bg.inputs["Color"])
    links.new(light_path.outputs["Is Camera Ray"], bg_switch.inputs["True"])
    links.new(bg_switch.outputs["Output"], mix.inputs["Fac"])
    links.new(replace_bg.outputs["Background"], mix.inputs[2])
