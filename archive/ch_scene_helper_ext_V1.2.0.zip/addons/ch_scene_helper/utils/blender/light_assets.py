"""
灯光资产目录扫描模块

高级设置子面板(图像/IES 档)与世界环境面板(HDRI 档)的资源选择器后端: 扫描偏好目录下的
分类子文件夹与缩略图条目(顶层 PNG=缩略图, Textures/ 或 IES/ 子目录内同名文件=源文件),
缩略图图标走文件级预览集合(不产生图像数据块), 并负责源文件的查找与图像数据块的查重加载.

主要功能:
- list_categories / list_assets: 目录结构与条目扫描(条目可含源缺失的缩略图, 由选择器开关过滤;
  PBR 材质档口径不同: 分类顶层 <包名>/ 目录为资产包, 同名 png|jpg|jpeg 为缩略图)
- preview_icon_id: 缩略图预览图标(文件级预览集合; 像素由 Blender 在图标首次绘制时
  经后台任务按磁盘缩略图缓存加载, 会话内零解码起手)
- find_or_load_image: 按绝对路径查重加载图像数据块(应用真实纹理源用)
- release_previews: 释放预览集合(插件注销时调用)
- resolve_asset: 按条目键反查资产(缩略图枚举 update 回调用)
"""

import os
import time
import zlib
from pathlib import Path

import bpy
from bpy.utils import previews

from .asset_manifest import downloaded_keys, list_manifest_assets, list_manifest_categories, list_manifest_pbr_assets, manifest_signature, source_dirs
from .pbr_convention import IMAGE_EXTS

# 目录约定: <根>/<分类>/ 顶层 PNG 为缩略图, 子目录内同名文件为源文件
IMAGE_SOURCE_SUBDIR = "Textures"
IES_SOURCE_SUBDIR = "IES"
HDRI_SOURCE_SUBDIR = "HDRIs"

# 资产种类 -> 源文件子目录名(世界环境库的源目录为 HDRIs/, 与图像/IES 库不同名)
_SOURCE_SUBDIRS = {'IMAGE': IMAGE_SOURCE_SUBDIR, 'IES': IES_SOURCE_SUBDIR, 'WORLD': HDRI_SOURCE_SUBDIR}

# 资产种类 -> 源文件候选扩展名(按序取首个命中; 世界环境库以 EXR/HDR 优先)
_SOURCE_EXTS = {
    'IMAGE': (".jpg", ".jpeg", ".png", ".exr"),
    'IES': (".ies",),
    'WORLD': (".exr", ".hdr", ".jpg", ".jpeg", ".png"),
}

# 文件级预览集合: load 只登记路径零读取, 像素在图标首次绘制时由 Blender 后台任务
# 经磁盘缩略图缓存加载(mtime 失效自动重生成), 会话内不产生 Image 数据块;
# None = 已释放, 再取用时惰性重建(注销后绘制/热重载兜底)
_preview_collection: previews.ImagePreviewCollection | None = None

# 目录扫描缓存(绘制期每帧两次扫描的降噪): 键 = 扫描标识, 值 = (目录签名, 结果列表);
# 签名 = 目录内 (名字, mtime_ns) 元组(含源文件子目录)——增删/改写任一变化即失效重扫
_scan_cache: dict = {}
_SCAN_CACHE_MAX = 256


# 签名短窗缓存(键 = 目录路径, 值 = (单调时刻, 签名)): _cached_scan 的缓存命中路径
# 每帧仍要 2-3 趟 iterdir+stat 算签名, OneDrive 云占位/网络盘上每帧都卡 UI 线程;
# 签名在窗口内视作不变——绘制帧间隔毫秒级, 0.25s 窗口对真实改动感知不到延迟
_SIG_CACHE: dict = {}
_SIG_WINDOW_SECONDS = 0.25


def _dir_signature(directory: Path) -> tuple:
    """目录签名((名字, mtime_ns) 按名排序); 目录不存在返回 ()"""
    now = time.monotonic()
    hit = _SIG_CACHE.get(directory)
    if hit is not None and now - hit[0] <= _SIG_WINDOW_SECONDS:
        return hit[1]
    if not directory.is_dir():
        sig = ()
    else:
        try:
            sig = tuple(sorted((item.name, item.stat().st_mtime_ns) for item in directory.iterdir()))
        except OSError:
            # 目录在签名期被移走(极端竞态): 视为空, 下次绘制按空目录口径走
            sig = ()
    if len(_SIG_CACHE) >= 256:
        _SIG_CACHE.clear()
    _SIG_CACHE[directory] = (now, sig)
    return sig


def _cached_scan(cache_key: str, scan_dir: Path, sub_dirs: tuple, scan_fn) -> list:
    """带签名的扫描记忆化: 签名不变直接回缓存, 变化则重扫并更新"""
    sig = (_dir_signature(scan_dir), tuple((name, _dir_signature(scan_dir / name)) for name in sub_dirs))
    hit = _scan_cache.get(cache_key)
    if hit is not None and hit[0] == sig:
        return hit[1]
    result = scan_fn()
    if len(_scan_cache) >= _SCAN_CACHE_MAX:
        _scan_cache.clear()
    _scan_cache[cache_key] = (sig, result)
    return result


def asset_key(name: str) -> str:
    """条目稳定键(文件名 crc32 十六进制): 跨扫描稳定, 重命名文件即换键"""
    return format(zlib.crc32(name.encode("utf-8")) & 0xFFFFFFFF, "08x")


def list_categories(root: str, online: bool = False, kind: str = 'WORLD') -> list:
    """根目录下的分类子文件夹名(排序; 根目录缺失/非目录/为空返回 [])

    online: 按库根的 manifest.json 索引取分类(在线库源文件不落地, 目录扫描口径不适用);
    kind 决定在线分类的收窄口径(包型只列有可建链条目的分类, 见 asset_manifest)
    """
    if not root:
        return []
    if online:
        return list_manifest_categories(root, kind)
    root_path = Path(root)
    if not root_path.is_dir():
        # 非目录(含不存在/是文件)直接空表: iterdir 会抛 NotADirectoryError
        return []

    def _scan():
        return sorted(item.name for item in root_path.iterdir() if item.is_dir() and not item.name.startswith("."))

    return _cached_scan(("cats", _norm_path(root)), root_path, (), _scan)


def resolve_category(categories: list, stored: str) -> str:
    """分类失效回退: 存储值不在候选里时回落首分类; 无候选时原样返回存储值(下游查无归一)

    绘制/枚举/算子四共用的失效回退口径(此前四份逐字重复, 一致性靠复制纪律维持):
    首开态存储值为空, 直读会查无资产静默早退.
    """
    if categories and stored not in categories:
        return categories[0]
    return stored


def _mtime_ns(path: Path) -> int:
    """文件修改时间(取不到按 0: 仅用于排序, 单个文件异常不中断扫描)"""
    try:
        return path.stat().st_mtime_ns
    except OSError:
        return 0


def _find_source(source_dir: Path, stem: str, exts) -> str | None:
    """在源文件子目录里匹配源文件: 先精确 <stem><ext>, 再前缀 <stem>_<规格><ext>

    前缀档是插件按需下载的落盘命名(<key>_4K.exr): 索引被移走后这些文件仍应被识别.
    离线库目前恒只有一档, 多命中时按扩展名优先级取首个非空组,组内取最近修改的一个
    (即最后下载的那档), 与在线库共用同一命名前缀规则.
    """
    for ext in exts:
        candidate = source_dir / (stem + ext)
        if candidate.is_file():
            return str(candidate)
    prefix = stem + "_"
    try:
        items = [item for item in source_dir.iterdir() if item.is_file() and item.name.startswith(prefix)]
    except OSError:
        return None
    for ext in exts:
        matches = [item for item in items if item.suffix.lower() == ext]
        if matches:
            matches.sort(key=lambda path: (_mtime_ns(path), path.name), reverse=True)
            return str(matches[0])
    return None


def list_assets(root: str, category: str, kind: str, only_with_source: bool = False, online: bool = False) -> list:
    """某分类下的资产条目(排序; 带签名记忆化, 重绘期免重复扫描)

    kind: 'IMAGE' -> Textures/ 内同名图像; 'IES' -> IES/ 内同名 .ies;
    'WORLD' -> HDRIs/ 内同名 HDRI 源文件(EXR/HDR 优先);
    'PBR' -> 分类顶层 <包名>/ 资产包(条目 source = 包目录路径, 包内贴图由导入侧逐文件识别).
    only_with_source: 只收录源文件存在的条目; 关闭时源缺失的缩略图也收录(选择器的
    "仅显示现有源文件"开关即此形参, 源缺失条目 source/source_name 为空串).
    online: 按库根 manifest.json 索引列条目(在线库; 条目 source 恒为空串, 已下载判定与
    落盘路径见 asset_manifest), 此时 only_with_source 表示"任一规格已落盘". 包型资产
    (PBR 材质)按 package 字段列条目, 与目录扫描口径不同.
    条目为 dict: name(主干名)/key(稳定键)/thumb(缩略图绝对路径)/source(源文件绝对路径,
    缺失为空串)/source_name(源文件名, 缺失为空串).
    """
    if not root or not category:
        return []
    if online:
        # 包型(PBR 材质)与单文件型(HDRI)的索引条目字段不同, 由各自的条目表构造
        assets = list_manifest_pbr_assets(root, category) if kind == 'PBR' else list_manifest_assets(root, category)
        if not only_with_source or not assets:
            return assets
        root_path = Path(bpy.path.abspath(root))
        # 签名覆盖 downloaded_keys 实际分组的全部源目录(与下载写入同源 _source_rel):
        # 只盯 assets[0] 的 hdri 时, 索引缺 hdri 的回落口径下签名会退化成库根——下载写进
        # <分类>/HDRIs/ 不改变库根直系子项 mtime, 列表会一直命中旧缓存
        scan_dirs = source_dirs(assets)

        def _scan_downloaded():
            downloaded = downloaded_keys(root, assets)
            return [asset for asset in assets if asset["key"] in downloaded]

        # 源目录签名 + 索引版本参与缓存: 下载/删除文件或索引增删条目即失效重扫
        return _cached_scan(("online_sourced", _norm_path(root), category, manifest_signature(root)), root_path, scan_dirs, _scan_downloaded)
    cat_dir = Path(root) / category
    if not cat_dir.is_dir():
        return []
    if kind == 'PBR':
        # PBR 材质库: 分类顶层 <包名>/ 目录为资产包(整包多张贴图), <包名>.png|jpg|jpeg 为缩略图
        def _scan_pbr():
            return _scan_pbr_assets(cat_dir, only_with_source)

        # 签名覆盖分类目录与其全部直接子项(包目录内增删贴图文件即失效重扫)
        sub_dirs = tuple(name for name, _mtime in _dir_signature(cat_dir))
        return _cached_scan(("assets", _norm_path(root), category, kind, only_with_source), cat_dir, sub_dirs, _scan_pbr)
    subdir_name = _SOURCE_SUBDIRS[kind]
    exts = _SOURCE_EXTS[kind]

    def _scan():
        assets = []
        for thumb in sorted(cat_dir.glob("*.png")):
            if not thumb.is_file():
                continue
            source = _find_source(cat_dir / subdir_name, thumb.stem, exts)
            if source is None and only_with_source:
                continue
            assets.append({"name": thumb.stem, "key": asset_key(thumb.stem), "thumb": str(thumb), "source": source or "", "source_name": Path(source).name if source else ""})
        return assets

    return _cached_scan(("assets", _norm_path(root), category, kind, only_with_source), cat_dir, (subdir_name,), _scan)


def _scan_pbr_assets(cat_dir: Path, only_with_source: bool) -> list:
    """PBR 材质库条目扫描: 包目录与缩略图配对成条目(按名排序)

    条目以"包名"为单元: 分类顶层同名目录 = 资产包, 同名 .png|jpg|jpeg = 缩略图.
    缩略图缺失画空图标; 包目录缺失(只有缩略图)按源缺失条目处理(选择器标红且不可应用);
    sourced = 包目录存在且含至少一个图像文件(空目录同按源缺失).
    """
    entries: dict = {}
    try:
        items = list(cat_dir.iterdir())
    except OSError:
        return []
    for item in items:
        if item.name.startswith("."):
            continue
        if item.is_dir():
            entries.setdefault(item.name, {})["pack"] = item
        elif item.suffix.lower() in (".png", ".jpg", ".jpeg") and item.is_file():
            # 同名多扩展并存时按 png > jpg > jpeg 取(迭代顺序不定, 固定优先级保证跨缓存稳定)
            thumb = entries.setdefault(item.stem, {}).get("thumb")
            rank = {".png": 0, ".jpg": 1, ".jpeg": 2}
            if thumb is None or rank.get(item.suffix.lower(), 3) < rank.get(thumb.suffix.lower(), 3):
                entries[item.stem]["thumb"] = item
    assets = []
    for name in sorted(entries):
        spec = entries[name]
        pack = spec.get("pack")
        thumb = spec.get("thumb")
        source = ""
        if pack is not None:
            try:
                has_texture = any(child.is_file() and child.suffix.lower() in IMAGE_EXTS for child in pack.iterdir())
            except OSError:
                has_texture = False
            if has_texture:
                source = str(pack)
        if not source and only_with_source:
            continue
        assets.append({"name": name, "key": asset_key(name), "thumb": str(thumb) if thumb is not None else "", "source": source, "source_name": name})
    return assets


def resolve_asset(root: str, category: str, kind: str, key: str, only_with_source: bool = False, online: bool = False):
    """按稳定键反查资产条目(查无返回 None; 过滤与取数口径须与绘制侧一致)"""
    for asset in list_assets(root, category, kind, only_with_source, online):
        if asset["key"] == key:
            return asset
    return None


def _norm_path(path: str) -> str:
    """路径归一(解 // 相对前缀 + 绝对化 + 大小写归一, 供集合比对)"""
    return os.path.normcase(os.path.abspath(bpy.path.abspath(path)))


def _get_preview_collection():
    """预览集合取用(已释放则重建): 注销释放后再遇绘制不炸"""
    global _preview_collection
    if _preview_collection is None:
        _preview_collection = previews.new()
    return _preview_collection


def release_previews() -> None:
    """释放预览集合(插件注销时调用): 全部预览条目与图标归还 Blender"""
    global _preview_collection
    if _preview_collection is not None:
        previews.remove(_preview_collection)
        _preview_collection = None


def preview_icon_id(thumb_path: str) -> int:
    """缩略图的预览图标 id(文件级预览集合, 不产生图像数据块; 文件浏览器同款机制)

    键 = 规范化缩略图路径(同路径跨扫描复用同一条目); 文件缺失/不可读(含 OneDrive
    仅云占位)的像素在后台加载期失败, 图标画空位, 不提示.
    """
    if not thumb_path:
        return 0
    key = _norm_path(thumb_path)
    pcoll = _get_preview_collection()
    preview = pcoll.get(key)
    if preview is None:
        preview = pcoll.load(key, thumb_path, 'IMAGE')
    return preview.icon_id if preview is not None else 0


def find_or_load_image(source_path: str):
    """按绝对路径取图像数据块(同路径查重复用, 查重按已载入数据块)"""
    if not source_path:
        return None
    try:
        return bpy.data.images.load(source_path, check_existing=True)
    except (RuntimeError, ValueError):
        # 文件缺失/不可读(含 OneDrive 仅云占位): 按约定不提示, 保持现状
        return None
