"""
PBR 材质资产包导入算法模块

材质面板 PBR 子面板的算法层: 扫描资产包目录(通道识别见 pbr_convention)后, 把目标材质的
节点树整树重建为 PBR_Universal 模板链. 模板结构(节点命名/连线/Frame 分区/版式)代码重建,
节点坐标与挂父关系照抄模板(先挂父级再写相对坐标, 同灯光/世界环境建链先例), 按需导入——
包内有哪张贴图就建哪条链, 空分区(Frame)不建; 冲突裁决: roughness 与 glossiness 同在取
roughness, normal 与 bump 同在取 normal. 贴图按外部路径引用(不打包进 .blend), 颜色空间
按组表设置. 基础色/法向/凹凸/置换四条链末端各有 Switch 切换节点(False 路 = 该链关闭时的
回落值: 原基础色或零向量), 面板经镜像布尔控制.

面板参数区的真值接口:
- find_pbr_nodes: 按标记收集已导入链的节点表(链末 Switch / AO 乘算 / 翻转法向 Y /
  纹理坐标 / 投影的绘制源)
- get_pbr_uv_output / set_pbr_uv_output: 读/重建 TexCoordinate -> Mapping 的接线(纹理坐标枚举落点)
- suppress_pbr_mirror_updates: 面板 draw 期把真值写回镜像枚举时的抑制器

主要功能:
- parse_pack: 扫描包目录识别通道贴图(冲突裁决后每通道至多一图), 返回通道表与未识别文件
- import_pbr_pack: 整树重建(清空 -> 模板节点 -> 按通道接线 -> 标记), 返回导入结果
"""

from contextlib import contextmanager
import traceback
from pathlib import Path

from bpy.types import Material, Node, NodeTree

from .light_assets import find_or_load_image
from .pbr_convention import GROUP_BY_KEY, IMAGE_EXTS, parse_texture_filename

# 插件链节点的归属标记(node 级 IDProperty, 用户改名节点后仍可识别)
_MARKER_KEY = "ch_pbr"

_FRAME_KIND = "FRAME:"

# Frame 分区表(键 -> (标签, 绝对坐标, 占用通道)): 版式与标签照 PBR_Universal 模板
# (作者的 Shader_Nodes.blend), 调整版式只改本表; 占用通道为空的分区恒建(uv),
# 其余分区仅在任一占用通道导入时才建(孤立空 Frame 不绘制)
_FRAMES = {
    "uv": ("F00 UV 控制（全局共享）", -3330.0, -118.0, ()),
    "base_color": ("F10 基础色（含 AO 乘算）", -2150.0, 1142.0, ("base_color", "ao")),
    "metallic": ("F11 金属度", -2150.0, 462.0, ("metallic",)),
    "roughness": ("F12 粗糙度（rough/gloss 互斥）", -2150.0, 82.0, ("roughness", "glossiness")),
    "ior": ("F13 折射率", -2150.0, -1638.0, ("ior",)),
    "alpha": ("F14 不透明度", -1790.0, -1638.0, ("alpha",)),
    "normal": ("F15 法线 + 凹凸", -2150.0, -498.0, ("normal", "bump")),
    "subsurface": ("F16 次表面", -1430.0, -1638.0, ("subsurface",)),
    "specular": ("F17 高光", -2150.0, -2018.0, ("specular",)),
    "transmission": ("F18 透射", -1790.0, -2018.0, ("transmission",)),
    "emission": ("F19 自发光", -1410.0, -2018.0, ("emission",)),
    "displacement": ("F20 置换（→ Material Output）", -2150.0, -1178.0, ("displacement",)),
}

# 图像纹理节点的规格表(组键 -> (节点名, 标签, 所属 Frame, Frame 内相对坐标)), 版式照模板
_TEX_SPECS = {
    "base_color": ("TEX_BaseColor", "TEX_BaseColor [sRGB]", "base_color", (30.0, -42.0)),
    "ao": ("TEX_AO", "TEX_AO [Non-Color]", "base_color", (30.0, -342.0)),
    "metallic": ("TEX_Metallic", "TEX_Metallic [Non-Color]", "metallic", (30.0, -42.0)),
    "roughness": ("TEX_Roughness", "TEX_Roughness [Non-Color]", "roughness", (30.0, -42.0)),
    "glossiness": ("TEX_Glossiness", "TEX_Glossiness [Non-Color]", "roughness", (30.0, -242.0)),
    "ior": ("TEX_IOR", "TEX_IOR [Non-Color]", "ior", (30.0, -42.0)),
    "alpha": ("TEX_Alpha", "TEX_Alpha [Non-Color]", "alpha", (30.0, -42.0)),
    "normal": ("TEX_Normal", "TEX_Normal [Non-Color]", "normal", (30.0, -42.0)),
    "bump": ("TEX_Bump", "TEX_Bump [Non-Color]", "normal", (30.0, -322.0)),
    "subsurface": ("TEX_Subsurface", "TEX_Subsurface [Non-Color]", "subsurface", (30.0, -42.0)),
    "specular": ("TEX_Specular", "TEX_Specular [Non-Color]", "specular", (30.0, -42.0)),
    "transmission": ("TEX_Transmission", "TEX_Transmission [Non-Color]", "transmission", (30.0, -42.0)),
    "emission": ("TEX_Emission", "TEX_Emission [sRGB]", "emission", (30.0, -42.0)),
    "displacement": ("TEX_Height_Displacement", "TEX_Height（置换用） [Non-Color]", "displacement", (30.0, -42.0)),
}

# 导入结果的展示顺序(包内可能出现的组按模板 Frame 序)
_DISPLAY_ORDER = (
    "base_color",
    "ao",
    "metallic",
    "roughness",
    "glossiness",
    "normal",
    "bump",
    "displacement",
    "transmission",
    "subsurface",
    "specular",
    "emission",
    "alpha",
    "ior",
)

# 纹理坐标枚举标识 -> TexCoordinate 节点真实输出口名(Object 的口名首字母大写, 与标识不同)
_TEXCOORD_SOCKET_NAMES = {"GENERATED": "Generated", "UV": "UV", "OBJECT": "Object"}


# ------------------------------------------------------------
# 包扫描与通道裁决
# ------------------------------------------------------------


def parse_pack(pack_dir: str, normal_convention: str = "") -> dict:
    """扫描资产包目录, 按文件名后缀识别通道贴图

    Args:
        pack_dir: 资产包目录(包内贴图平铺)
        normal_convention: 库声明的法线朝向('directx' / 'opengl' / 空); 文件名不带朝向后缀时
            作为该包的朝向真值(cgbookcase 包内是裸 _Normal, 站点约定为 DirectX)

    Returns:
        {"channels": {组键: {"path": 路径, "direction": 法线朝向或 None}}, "unrecognized": [文件名]}
        图像扩展名之外的文件静默忽略; 后缀未命中的图像文件计入 unrecognized;
        冲突裁决(roughness>glossiness / normal>bump)后每通道至多一图.
    """
    root = Path(pack_dir)
    result = {"channels": {}, "unrecognized": []}
    if not root.is_dir():
        return result
    grouped: dict = {}
    try:
        items = sorted(root.iterdir())
    except OSError:
        # 目录在扫描与导入之间被移走(竞态): 视为空包, 走 no_textures 拒绝路径
        return result
    for item in items:
        if not item.is_file() or item.name.startswith("."):
            continue
        if item.suffix.lower() not in IMAGE_EXTS:
            continue
        parsed = parse_texture_filename(item.name)
        if parsed.group_key is None:
            result["unrecognized"].append(item.name)
            continue
        grouped.setdefault(parsed.group_key, []).append({"path": str(item), "direction": parsed.direction})
    for key, entries in grouped.items():
        result["channels"][key] = _pick_group_file(key, entries)
    # 包内文件名不带朝向信息时按库声明补上(裸 _normal 默认按 GL 处理, 只有声明才翻转)
    normal = result["channels"].get("normal")
    if normal is not None and normal["direction"] is None and normal_convention == 'directx':
        normal["direction"] = "DX"
    # 冲突裁决: 同义通道同在时按固定优先级留一(被弃通道整组不建链)
    if "roughness" in result["channels"]:
        result["channels"].pop("glossiness", None)
    if "normal" in result["channels"]:
        result["channels"].pop("bump", None)
    return result


def _pick_group_file(key: str, entries: list) -> dict:
    """同组多文件命中时取一(目录扫描已按名排序, 同名多扩展取首个)

    normal 组按朝向取: GL 优先(Blender 原生朝向), 裸 _normal(无朝向信息)按 GL 口径居中,
    DX 最后——同包同时给出 DX/GL 两版法线时免翻转的那版胜出.
    """
    if key != "normal":
        return entries[0]
    direction_rank = {"GL": 0, None: 1, "DX": 2}
    return min(entries, key=lambda entry: direction_rank.get(entry["direction"], 3))


def _channel_label(key: str, entry: dict) -> str:
    """通道的中文展示名(报告文案); 法线带朝向标注"""
    label = GROUP_BY_KEY[key].label_zh
    if key == "normal" and entry["direction"]:
        label = "{}({})".format(label, entry["direction"])
    return label


# ------------------------------------------------------------
# 模板节点重建
# ------------------------------------------------------------


def _build_frame(tree: NodeTree, frames: dict, key: str) -> None:
    """按分区表建 Frame(组织容器; 仅被占用通道命中的分区才进入本函数)"""
    label, x, y, _channels = _FRAMES[key]
    frame = tree.nodes.new('NodeFrame')
    frame.name = "ch_pbr_frame_" + key
    frame.label = label
    frame.location = (x, y)
    frame[_MARKER_KEY] = _FRAME_KIND + key
    frames[key] = frame


def _new_node(tree: NodeTree, frames: dict, marker: str, bl_idname: str, name: str, frame_key: str | None, loc: tuple, label: str = "") -> Node:
    """新建模板节点: 打标记, 挂 Frame 后再写相对坐标(顺序反了坐标会被反算成差值,
    位置不再与模板一致); frame_key 对应分区未建(通道未导入)时传 None 按绝对坐标落位"""
    node = tree.nodes.new(bl_idname)
    node.name = name
    node[_MARKER_KEY] = marker
    if label:
        node.label = label
    if frame_key is not None and frame_key in frames:
        node.parent = frames[frame_key]
    node.location = loc
    return node


def _new_tex(tree: NodeTree, frames: dict, mapping: Node, key: str, image) -> Node:
    """按组规格建图像纹理节点: 设图像并接入共享 UV 映射"""
    name, label, frame_key, loc = _TEX_SPECS[key]
    node = _new_node(tree, frames, "TEX:" + key, 'ShaderNodeTexImage', name, frame_key, loc, label)
    node.image = image
    tree.links.new(mapping.outputs["Vector"], node.inputs["Vector"])
    return node


def _new_value_ramp(tree: NodeTree, frames: dict, marker: str, name: str, frame_key: str, loc: tuple) -> Node:
    """数值重映射 ColorRamp(黑白两端 0->1 线性, 与模板一致)"""
    return _new_node(tree, frames, marker, 'ShaderNodeValToRGB', name, frame_key, loc)


def _new_switch(tree: NodeTree, frames: dict, marker: str, name: str, frame_key: str, loc: tuple, input_type: str, enabled: bool) -> Node:
    """新建链末端的 Switch 切换节点(False 路 = 该链关闭时的回落值)

    input_type 改型会重建插座, 须在接线前完成; VECTOR 档的 False 路恒为零向量
    (无位移/无法线扰动), RGBA 档的 False 路由调用方接原基础色.
    """
    node = _new_node(tree, frames, marker, 'GeometryNodeSwitch', name, frame_key, loc)
    node.input_type = input_type
    if input_type == 'VECTOR':
        node.inputs["False"].default_value = (0.0, 0.0, 0.0)
    node.inputs["Switch"].default_value = enabled
    return node


def _mix_rgba_sockets(mix: Node) -> tuple:
    """Mix 节点的 RGBA 数据 sockets: (Factor, A, B, Result)

    Mix 节点为各 data_type 各持一套同名插座, 按名裸取会命中 float 套——按类型过滤取 RGBA 套.
    """
    a = next(inp for inp in mix.inputs if inp.name == "A" and inp.type == 'RGBA')
    b = next(inp for inp in mix.inputs if inp.name == "B" and inp.type == 'RGBA')
    out = next(out for out in mix.outputs if out.type == 'RGBA')
    return mix.inputs[0], a, b, out


def _build_chains(tree: NodeTree, frames: dict, mapping: Node, bsdf: Node, output: Node, images: dict, directions: dict) -> None:
    """按通道表建模板链(资产包导入与材质初始化共用)

    images: {组键: Image}; directions: {组键: 'DX'/'GL'/None}(法线朝向; 按文件名重建时读不到
    朝向, 传空表 = 不翻转). 只建 images 在场的通道, 链末 Switch 默认态照模板(AO 开/法向开/
    凹凸开/置换关), AO 系数 0.5,凹凸距离 0.01,置换中间值 0.5 与缩放 0.01(调用方事后可覆盖).
    """
    links = tree.links.new

    # F10 基础色(含 AO 乘算): 链末 Switch 决定是否叠加(False = 原基础色),
    # 乘算因子默认 0.5, 面板"系数"调
    if "base_color" in images:
        base = _new_tex(tree, frames, mapping, "base_color", images["base_color"])
        if "ao" in images:
            ao = _new_tex(tree, frames, mapping, "ao", images["ao"])
            mix = _new_node(tree, frames, "MIX:ao", 'ShaderNodeMix', "MIX_AO", "base_color", (310.0, -42.0), "AO 乘算")
            mix.data_type = 'RGBA'
            mix.blend_type = 'MULTIPLY'
            factor, mix_a, mix_b, mix_out = _mix_rgba_sockets(mix)
            factor.default_value = 0.5
            links(base.outputs["Color"], mix_a)
            links(ao.outputs["Color"], mix_b)
            ao_switch = _new_switch(tree, frames, "SWITCH_AO", "SWITCH_AO", "base_color", (490.0, -42.0), 'RGBA', True)
            links(base.outputs["Color"], ao_switch.inputs["False"])
            links(mix_out, ao_switch.inputs["True"])
            links(ao_switch.outputs[0], bsdf.inputs["Base Color"])
        else:
            links(base.outputs["Color"], bsdf.inputs["Base Color"])

    # F11 金属度(贴图经数值 Ramp 再进 BSDF); Ramp 名恒传 "Color Ramp"——按创建序
    # 由 Blender 自动消歧 .001/.002(与全包模板命名一致, 仅 gloss 包不再背 .002 空号)
    if "metallic" in images:
        metal = _new_tex(tree, frames, mapping, "metallic", images["metallic"])
        ramp = _new_value_ramp(tree, frames, "RAMP:metallic", "Color Ramp", "metallic", (310.0, -42.0))
        links(metal.outputs["Color"], ramp.inputs["Factor"])
        links(ramp.outputs["Color"], bsdf.inputs["Metallic"])

    # F12 粗糙度(rough/gloss 互斥, 解析侧已裁决): rough 直进 Ramp; 仅 gloss 时反相进 Ramp
    if "roughness" in images:
        rough = _new_tex(tree, frames, mapping, "roughness", images["roughness"])
        ramp = _new_value_ramp(tree, frames, "RAMP:roughness", "Color Ramp", "roughness", (310.0, -42.0))
        links(rough.outputs["Color"], ramp.inputs["Factor"])
        links(ramp.outputs["Color"], bsdf.inputs["Roughness"])
    elif "glossiness" in images:
        gloss = _new_tex(tree, frames, mapping, "glossiness", images["glossiness"])
        invert = _new_node(tree, frames, "INVERT:glossiness", 'ShaderNodeInvert', "INVERT_Gloss", "roughness", (310.0, -242.0), "1 − G")
        ramp = _new_value_ramp(tree, frames, "RAMP:glossiness", "Color Ramp", "roughness", (490.0, -242.0))
        links(gloss.outputs["Color"], invert.inputs["Color"])
        links(invert.outputs["Color"], ramp.inputs["Factor"])
        links(ramp.outputs["Color"], bsdf.inputs["Roughness"])

    if "ior" in images:
        links(_new_tex(tree, frames, mapping, "ior", images["ior"]).outputs["Color"], bsdf.inputs["IOR"])
    if "alpha" in images:
        links(_new_tex(tree, frames, mapping, "alpha", images["alpha"]).outputs["Color"], bsdf.inputs["Alpha"])

    # F15 法线 + 凹凸(互斥, 解析侧已裁决): 法线经分离-翻转绿通道-重组-Normal Map,
    # 朝向由链内 Switch 承担(DX 翻转 / GL 与裸 _normal 不翻; 初始按文件名后缀自动判定,
    # 面板"翻转 Y"按钮可改); 两条链末端各有启用 Switch(关 = BSDF.Normal 接零向量)
    if "normal" in images:
        normal = _new_tex(tree, frames, mapping, "normal", images["normal"])
        sep = _new_node(tree, frames, "SEP_NORMAL", 'ShaderNodeSeparateColor', "SEP_Normal", "normal", (310.0, -42.0), "分离 RGB")
        math_g = _new_node(tree, frames, "INVERT_NORMAL_G", 'ShaderNodeMath', "MATH_InvertG", "normal", (490.0, -162.0), "1 − G")
        math_g.operation = 'SUBTRACT'
        math_g.inputs[0].default_value = 1.0
        # Switch 的数值套按用途改型(改型重建插座, 须在接线前完成; 属性名是 input_type 非 data_type)
        switch = _new_node(tree, frames, "SWITCH_FLIPY", 'GeometryNodeSwitch', "SWITCH_FlipY", "normal", (670.0, -162.0), "翻转 G")
        switch.input_type = 'FLOAT'
        switch.inputs["Switch"].default_value = (directions or {}).get("normal") == 'DX'
        comb = _new_node(tree, frames, "COMB_NORMAL", 'ShaderNodeCombineColor', "COMB_Normal", "normal", (850.0, -42.0), "重组 RGB")
        nmap = _new_node(tree, frames, "NMAP", 'ShaderNodeNormalMap', "NMAP_Normal", "normal", (1030.0, -42.0), "Normal Map")
        nmap.inputs["Strength"].default_value = 1.0
        normal_switch = _new_switch(tree, frames, "SWITCH_NORMAL", "SWITCH_Normal", "normal", (1210.0, -42.0), 'VECTOR', True)
        links(normal.outputs["Color"], sep.inputs["Color"])
        links(sep.outputs["Green"], math_g.inputs[1])
        links(sep.outputs["Green"], switch.inputs["False"])
        links(math_g.outputs[0], switch.inputs["True"])
        links(sep.outputs["Red"], comb.inputs["Red"])
        links(switch.outputs[0], comb.inputs["Green"])
        links(sep.outputs["Blue"], comb.inputs["Blue"])
        links(comb.outputs["Color"], nmap.inputs["Color"])
        links(nmap.outputs["Normal"], normal_switch.inputs["True"])
        links(normal_switch.outputs[0], bsdf.inputs["Normal"])
    elif "bump" in images:
        bump = _new_tex(tree, frames, mapping, "bump", images["bump"])
        bump_node = _new_node(tree, frames, "BUMP", 'ShaderNodeBump', "BUMP_Normal", "normal", (310.0, -322.0), "Bump")
        bump_node.inputs["Strength"].default_value = 1.0
        bump_node.inputs["Distance"].default_value = 0.01
        bump_switch = _new_switch(tree, frames, "SWITCH_BUMP", "SWITCH_Bump", "normal", (490.0, -322.0), 'VECTOR', True)
        links(bump.outputs["Color"], bump_node.inputs["Height"])
        links(bump_node.outputs["Normal"], bump_switch.inputs["True"])
        links(bump_switch.outputs[0], bsdf.inputs["Normal"])

    if "subsurface" in images:
        links(_new_tex(tree, frames, mapping, "subsurface", images["subsurface"]).outputs["Color"], bsdf.inputs["Subsurface Weight"])
    if "specular" in images:
        links(_new_tex(tree, frames, mapping, "specular", images["specular"]).outputs["Color"], bsdf.inputs["Specular IOR Level"])
    if "transmission" in images:
        links(_new_tex(tree, frames, mapping, "transmission", images["transmission"]).outputs["Color"], bsdf.inputs["Transmission Weight"])

    # F19 自发光: 颜色直连; 模板强度默认 0(链在无光), 导入即点亮
    if "emission" in images:
        links(_new_tex(tree, frames, mapping, "emission", images["emission"]).outputs["Color"], bsdf.inputs["Emission Color"])
        bsdf.inputs["Emission Strength"].default_value = 1.0

    # F20 置换: 高度图先进 Displacement, 链末 Switch 决定是否输出到 Material Output
    # (关 = 输出零向量); 默认关, 面板"置换"开
    if "displacement" in images:
        height = _new_tex(tree, frames, mapping, "displacement", images["displacement"])
        disp = _new_node(tree, frames, "DISP", 'ShaderNodeDisplacement', "DISP_Output", "displacement", (310.0, -42.0), "Displacement")
        disp.inputs["Midlevel"].default_value = 0.5
        disp.inputs["Scale"].default_value = 0.01
        switch_disp = _new_switch(tree, frames, "SWITCH_DISP", "SWITCH_Displace", "displacement", (490.0, -42.0), 'VECTOR', False)
        links(height.outputs["Color"], disp.inputs["Height"])
        links(disp.outputs["Displacement"], switch_disp.inputs["True"])
        links(switch_disp.outputs[0], output.inputs["Displacement"])


def import_pbr_pack(mat: Material, pack_dir: str, normal_convention: str = "") -> dict:
    """把材质节点树整树重建为 PBR 模板链(按需导入包内贴图)

    流程: 解析包 -> 清空树前先载图(识别成功但全部落空则拒绝导入, 不清树) ->
    恒建 UV/BSDF/Output ->
    按在场通道建链(接线与节点名照模板, 空分区 Frame 不建) -> 照抄模板材质旗标.
    链末切换节点默认态: AO 开 / 法向开 / 凹凸开 / 置换关; AO 乘算系数 0.5,
    凹凸距离 0.01, 翻转法向 Y 按文件名朝向判定(面板可改); 库链接材质与无节点树拒绝
    (AO 无基础色配对时剔除, 混算 A 默认黑会吞掉颜色).

    Returns:
        {"ok": 是否已重建, "error": None | "linked" | "no_tree" | "no_textures",
         "imported": [中文通道名], "unrecognized": [文件名], "failed": [中文通道名]}
    """
    result = {"ok": False, "error": None, "imported": [], "unrecognized": [], "failed": []}
    if mat.library is not None:
        result["error"] = "linked"
        return result
    tree = mat.node_tree
    if tree is None:
        result["error"] = "no_tree"
        return result
    pack = parse_pack(pack_dir, normal_convention)
    result["unrecognized"] = pack["unrecognized"]
    if not pack["channels"]:
        result["error"] = "no_textures"
        return result

    images = {}
    for key, entry in pack["channels"].items():
        image = find_or_load_image(entry["path"])
        if image is None:
            result["failed"].append(_channel_label(key, entry))
            continue
        # 复用数据块(find_or_load_image 按路径查重)时同样覆写: 同一文件被灯光图像档
        # (sRGB 投影)等其它用途引用时, 颜色空间会被 PBR 通道口径接管——共享副作用属
        # 已知边界(同文件跨用途为低频配置), 不做提示(审查轮定)
        image.colorspace_settings.name = GROUP_BY_KEY[key].colorspace
        images[key] = image
    if "ao" in images and "base_color" not in images:
        # AO 乘算的 A 输入来自基础色: 无基础色时混算 A 默认黑, 链在也无效果, 剔除
        del images["ao"]
        result["failed"].append(GROUP_BY_KEY["ao"].label_zh)
    if not images:
        # 识别成功但全部落空(载图失败/AO 配对剔除后无可用通道): 不清树, 材质保持原状
        result["error"] = "load_failed"
        return result

    tree.nodes.clear()
    # Frame 只建被占用通道命中的分区(uv 分区恒建): 孤立空 Frame 不绘制
    frames: dict = {}
    for frame_key, (_label, _x, _y, channels) in _FRAMES.items():
        if not channels or any(channel in images for channel in channels):
            _build_frame(tree, frames, frame_key)

    coord = _new_node(tree, frames, "UV:coord", 'ShaderNodeTexCoord', "TEXCOORD_UV", "uv", (30.0, -42.0), "UV 坐标")  # 节点标签照模板, 面板行为名"纹理坐标"
    mapping = _new_node(tree, frames, "UV:mapping", 'ShaderNodeMapping', "MAPPING_UV", "uv", (210.0, -42.0), "UV 平铺/偏移")
    tree.links.new(coord.outputs["UV"], mapping.inputs["Vector"])
    bsdf = _new_node(tree, frames, "BSDF", 'ShaderNodeBsdfPrincipled', "PBR_BSDF_Principled", None, (-200.0, 100.0))
    output = _new_node(tree, frames, "OUTPUT", 'ShaderNodeOutputMaterial', "OUTPUT_Material", None, (140.0, 100.0), "Material Output")
    tree.links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    directions = {"normal": pack["channels"]["normal"]["direction"]} if "normal" in pack["channels"] else {}
    _build_chains(tree, frames, mapping, bsdf, output, images, directions)

    # 材质旗标照模板(抖动渲染[DITHERED, 旧口语"镂空"] + 真置换)
    mat.surface_render_method = 'DITHERED'
    mat.displacement_method = 'DISPLACEMENT'

    for key in _DISPLAY_ORDER:
        if key in images:
            result["imported"].append(_channel_label(key, pack["channels"][key]))
    result["ok"] = True
    return result


# ------------------------------------------------------------
# 普通材质 -> 插件链(整树重建, 与资产包导入共用建链段)
# ------------------------------------------------------------


def rebuild_channels(mat: Material, channels: dict, displacement_params: dict | None = None, normal_direction: str = "") -> dict:
    """普通 PBR 材质 -> 插件模板链的**整树重建**(按通道表, 不看文件路径)

    与 import_pbr_pack 的区别只在贴图来源: 这里吃已经扫出来的图像数据块(见 pbr_scan),
    之后同样整树重建——清空旧节点(含 Frame 等布局节点与自定义拓扑), 照模板建 UV/BSDF/
    Output 与各通道链, 并照抄模板的材质旗标. 链节点名与标记与导入路径完全一致, 故参数区
    认得出这些链.

    Args:
        mat: 目标材质(库链接拒绝)
        channels: {组键: Image} 或扫描条目(形如 {"image": Image, ...})
        displacement_params: 原置换节点的 {"midlevel", "scale"}; 给了就覆盖模板默认值
        normal_direction: 法线朝向('DX' / 'GL'; 空按 GL).按名称关键字判定, 见 pbr_scan

    Returns:
        {"ok": bool, "error": None | "linked" | "no_tree" | "no_textures" | "failed",
         "built": [中文通道名]}
    """
    result = {"ok": False, "error": None, "built": []}
    if mat.library is not None:
        result["error"] = "linked"
        return result
    tree = mat.node_tree
    if tree is None:
        result["error"] = "no_tree"
        return result
    images = {}
    for key, entry in (channels or {}).items():
        image = entry.get("image") if isinstance(entry, dict) else entry
        if image is not None and key in GROUP_BY_KEY:
            images[key] = image
    # AO 是"乘进基础色"的支路: 没有基础色时链建了也无效果(乘算 A 默认黑会吞掉颜色),
    # 与 pbr_scan / 资产包导入同口径剔除(调用方直接传通道表时也守住这条)
    if "ao" in images and "base_color" not in images:
        images.pop("ao")
    if not images:
        result["error"] = "no_textures"
        return result

    tree.nodes.clear()
    frames: dict = {}
    for frame_key, (_label, _x, _y, frame_channels) in _FRAMES.items():
        if not frame_channels or any(channel in images for channel in frame_channels):
            _build_frame(tree, frames, frame_key)

    coord = _new_node(tree, frames, "UV:coord", 'ShaderNodeTexCoord', "TEXCOORD_UV", "uv", (30.0, -42.0), "UV 坐标")
    mapping = _new_node(tree, frames, "UV:mapping", 'ShaderNodeMapping', "MAPPING_UV", "uv", (210.0, -42.0), "UV 平铺/偏移")
    tree.links.new(coord.outputs["UV"], mapping.inputs["Vector"])
    bsdf = _new_node(tree, frames, "BSDF", 'ShaderNodeBsdfPrincipled', "PBR_BSDF_Principled", None, (-200.0, 100.0))
    output = _new_node(tree, frames, "OUTPUT", 'ShaderNodeOutputMaterial', "OUTPUT_Material", None, (140.0, 100.0), "Material Output")
    tree.links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    # 图像颜色空间按通道口径(模板链要求 Non-Color / sRGB)
    for key, image in images.items():
        image.colorspace_settings.name = GROUP_BY_KEY[key].colorspace

    direction = normal_direction or "GL"
    try:
        _build_chains(tree, frames, mapping, bsdf, output, images, {"normal": direction})
    except Exception:  # noqa: BLE001 - 建链异常不该把 traceback 抛给用户, 由算子汇报并可 Ctrl+Z 回滚
        # 控制台留原始异常(同"同步计时器异常首次留痕"口径), 面板只给短句;
        # 树已清空, 这里补一棵最小可用树, 免得材质停在半成品(原树仍可用 Ctrl+Z 回滚)
        traceback.print_exc()
        tree.nodes.clear()
        fallback_bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled')
        fallback_output = tree.nodes.new('ShaderNodeOutputMaterial')
        fallback_bsdf.location = (-200.0, 100.0)
        fallback_output.location = (140.0, 100.0)
        tree.links.new(fallback_bsdf.outputs["BSDF"], fallback_output.inputs["Surface"])
        result["error"] = "failed"
        return result
    if displacement_params and "displacement" in images:
        disp = tree.nodes.get("DISP_Output")
        if disp is not None:
            for socket_name, value in (("Midlevel", displacement_params.get("midlevel")), ("Scale", displacement_params.get("scale"))):
                if value is not None and socket_name in disp.inputs:
                    disp.inputs[socket_name].default_value = value
    # 材质旗标照模板(抖动渲染[DITHERED, 旧口语"镂空"] + 真置换)
    mat.surface_render_method = 'DITHERED'
    mat.displacement_method = 'DISPLACEMENT'
    result["ok"] = True
    result["built"] = [GROUP_BY_KEY[key].label_zh + ("({})".format(direction) if key == "normal" else "") for key in _DISPLAY_ORDER if key in images]
    return result


# ------------------------------------------------------------
# 已导入链查询与参数真值
# ------------------------------------------------------------


def find_pbr_nodes(mat: Material) -> dict:
    """按标记收集材质节点树里的 PBR 链节点(标记值 -> 节点; 无链/库链接返回空表)"""
    if mat is None or mat.library is not None or mat.node_tree is None:
        return {}
    nodes = {}
    for node in mat.node_tree.nodes:
        marker = node.get(_MARKER_KEY)
        if marker:
            nodes[marker] = node
    return nodes


def get_pbr_uv_output(mat: Material) -> str:
    """读当前纹理坐标真值: TexCoordinate 的哪个输出口接到了 Mapping.Vector, 返回枚举标识"""
    nodes = find_pbr_nodes(mat)
    coord = nodes.get("UV:coord")
    mapping = nodes.get("UV:mapping")
    if coord is None or mapping is None:
        return ""
    vector = mapping.inputs.get("Vector")
    if vector is None or not vector.is_linked:
        return ""
    name_to_id = {value: key for key, value in _TEXCOORD_SOCKET_NAMES.items()}
    for link in vector.links:
        # 按 name(+type) 比较而非 is: 不同获取路径的 bpy_struct 包装器身份不同
        if link.from_node.name == coord.name and link.from_node.type == 'TEX_COORD':
            return name_to_id.get(link.from_socket.name, "")
    return ""


def set_pbr_uv_output(mat: Material, output_id: str) -> None:
    """重建 TexCoordinate -> Mapping.Vector 的接线(纹理坐标枚举改动的落点)

    断掉 Mapping.Vector 上来自该 TexCoordinate 的旧线(按 name 比较), 接到 output_id
    指定的输出口; 写节点树连接不进撤销栈(tooltip 说明).
    """
    nodes = find_pbr_nodes(mat)
    coord = nodes.get("UV:coord")
    mapping = nodes.get("UV:mapping")
    tree = mapping.id_data if mapping is not None else None
    socket_name = _TEXCOORD_SOCKET_NAMES.get(output_id)
    target = coord.outputs.get(socket_name) if coord is not None and socket_name else None
    vector = mapping.inputs.get("Vector") if mapping is not None else None
    if tree is None or target is None or vector is None:
        return
    for link in list(vector.links):
        if link.from_node.name == coord.name and link.from_node.type == 'TEX_COORD':
            tree.links.remove(link)
    tree.links.new(target, vector)
    tree.update_tag()


# UV/投影镜像写回的抑制计数: 面板 draw 期把"链上真值"写进镜像枚举时,
# 对应 update 回调查此计数跳过接线/写入 —— 否则每帧重画都会触发一次写回.
# 用深度计数而非布尔值防嵌套.
_suppress_depth = 0


@contextmanager
def suppress_pbr_mirror_updates():
    """进入镜像写回抑制(面板 draw 期把真值写回镜像枚举时使用), 退出时恢复"""
    global _suppress_depth
    _suppress_depth += 1
    try:
        yield
    finally:
        _suppress_depth -= 1


def is_pbr_mirror_suppressed() -> bool:
    """镜像枚举的 update 回调当前是否应跳过(面板 draw 期)"""
    return _suppress_depth > 0


def pbr_chain_textures(mat: Material) -> list:
    """已导入链里的全部图像纹理节点(投影统一控制的写入目标)"""
    return [node for marker, node in find_pbr_nodes(mat).items() if marker.startswith("TEX:")]
