"""
在线资产下载模块

后台线程分块下载资产包(下载包保留不删, 可重复解压)并按资产种类落盘: 单文件型解出 HDRI
源文件, 包型解出整包贴图到 <包目录>/<分辨率>/; 主线程计时器轮询进度,刷新面板并在任务
收尾后自动注销. 全局同一时刻只跑一个任务(不排队).

主要功能:
- start_download: 启动任务(校验联网访问与全局单任务互斥), 返回 (成功, 错误文案)
- has_active_download: 是否有进行中的任务(面板据此置灰其它下载钮)
- download_state: 任务状态快照(阶段/已收字节/总量/进度/错误), 供面板绘制
- cancel_active_download / cancel_all_downloads: 置取消位(未完成文件的清理由 _worker 收尾统一执行)
"""

import os
import shutil
import threading
import urllib.request
import zipfile
from pathlib import Path

import bpy

from .pbr_convention import IMAGE_EXTS

# 分块大小(进度粒度与内存占用的折中)
CHUNK_SIZE = 64 * 1024

# 中文注释: 计时器节拍(秒)与单次请求超时(秒); 大包走分块读, 超时只管连接与相邻块间隔
_TICK_SECONDS = 0.2
_TIMEOUT = 60

# 未完成文件后缀(下载/解压均先写 .part 再原子替换)
_PART_SUFFIX = ".part"

# 解压时认可的 HDRI 源文件扩展名(站点包内实际为 EXR, HDR 作兜底)
_HDRI_EXTS = (".exr", ".hdr")

# 解压优先成员: 站点包内真正的 HDRI 文件名恒带 _HDR 后缀
_HDRI_PREFERRED = "_hdr.exr"

# 任务模式: 单文件型解出一个源文件; 包型把整包贴图解到目标目录(材质资产包)
MODE_HDRI = 'HDRI'
MODE_PACK = 'PACK'

# 任务阶段(字符串直出, 面板按阶段切三态显示)
PHASE_DOWNLOAD = 'DOWNLOAD'
PHASE_EXTRACT = 'EXTRACT'
PHASE_DONE = 'DONE'
PHASE_ERROR = 'ERROR'
PHASE_CANCELLED = 'CANCELLED'

_ACTIVE_PHASES = (PHASE_DOWNLOAD, PHASE_EXTRACT)

# 任务表(键 = 规范化下载包路径; 值 = 任务 dict); worker 只写自己的任务, 主线程增删表项
_JOBS: dict = {}
_LOCK = threading.Lock()

# 需刷新的区域类型(面板在 3D 视图侧栏, 属性编辑器同面板另存一份)
_REDRAW_AREAS = {'VIEW_3D', 'PROPERTIES'}


def _job_key(zip_path: str) -> str:
    """任务键(路径绝对化 + 大小写归一)"""
    return os.path.normcase(os.path.abspath(zip_path))


def download_state(zip_path: str):
    """任务状态快照(无任务返回 None)

    字段: phase(阶段)/received(已收字节)/total(总量, 响应头缺失时取索引体积)/factor(0~1)/error(错误文案)
    """
    job = _JOBS.get(_job_key(zip_path))
    if job is None:
        return None
    total = job["total"] or job["expected"] or 0
    factor = (job["received"] / total) if total > 0 else 0.0
    return {"phase": job["phase"], "received": job["received"], "total": total, "factor": min(max(factor, 0.0), 1.0), "error": job["error"]}


def has_active_download() -> bool:
    """是否有进行中的任务(全局单任务约束: 任一目标在下载/解压即 True)"""
    return any(job["phase"] in _ACTIVE_PHASES for job in _JOBS.values())


# 错误归类 -> 面板短句(归类在此判定, 短句由 UI 层翻译; 原始异常名附在后面便于排查)
_ERROR_HINTS = (
    ("no hdri file", 'NO_SOURCE'),
    ("no texture", 'NO_SOURCE'),
    ("timed out", 'TIMEOUT'),
    ("timeout", 'TIMEOUT'),
    ("urlerror", 'NETWORK'),
    ("connection", 'NETWORK'),
    ("getaddrinfo", 'NETWORK'),
    ("ssl", 'NETWORK'),
    ("permission", 'DISK'),
    ("no space", 'DISK'),
    ("errno 28", 'DISK'),
    ("errno 13", 'DISK'),
)


def error_kind(error: str) -> str:
    """错误归类: NO_SOURCE / TIMEOUT / NETWORK / DISK / OTHER(面板据此画可读短句)"""
    text = (error or "").lower()
    for hint, kind in _ERROR_HINTS:
        if hint in text:
            return kind
    return 'OTHER'


def start_download(url: str, zip_path: str, source_base: str, expected_size: int = 0, mode: str = MODE_HDRI, skip_stem: str = "", attr: str = "", referer: str = ""):
    """启动下载任务: 下载到 <zip_path>, 按模式落盘

    返回 (True, None) 或 (False, 错误文案). 全局同一时刻只跑一个任务(不排队), 已有任务
    在下载/解压中时直接拒绝, 由面板把下载钮置灰.

    source_base: 单文件型为不含扩展名的绝对路径(扩展名按包内成员决定); 包型为解压目标目录.
    skip_stem: 包型专用, 包内与资产同名的缩略图副本(解压时跳过).
    attr: 包型专用, 该档规格标识(解出后按它清理同目录下其它档的旧贴图).
    referer: 索引 source.site; cgbookcase 的 CDN 无 Referer 即 403(探针实测), 空串表示不带.
    """
    if not bpy.app.online_access:
        return False, "Online access is disabled, allow it in Blender system preferences"
    key = _job_key(zip_path)
    with _LOCK:
        if any(job["phase"] in _ACTIVE_PHASES for job in _JOBS.values()):
            return False, "A download is already running, wait for it to finish"
        job = {
            "url": url,
            "zip_path": zip_path,
            "source_base": source_base,
            "expected": int(expected_size or 0),
            "mode": mode,
            "skip_stem": skip_stem,
            "attr": attr,
            "referer": referer,
            "phase": PHASE_DOWNLOAD,
            "received": 0,
            "total": 0,
            "error": "",
            "cancel": False,
        }
        _JOBS[key] = job
    threading.Thread(target=_worker, args=(job,), daemon=True).start()
    _ensure_timer()
    return True, None


def cancel_active_download() -> bool:
    """取消当前进行中的任务并返回是否命中

    全局单任务: 面板在下拉里切了规格后仍能取消(任务键是启动时的那个规格, 按当前选择查不到).
    """
    found = False
    for job in _JOBS.values():
        if job["phase"] in _ACTIVE_PHASES:
            job["cancel"] = True
            found = True
    return found


def cancel_all_downloads() -> None:
    """取消全部任务并注销计时器(插件注销时调用, 防注销后计时器继续访问 bpy)"""
    for job in _JOBS.values():
        job["cancel"] = True
    _JOBS.clear()
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)


def _worker(job: dict) -> None:
    """线程入口: 下载 -> 解压 -> 置完成; 异常落错误阶段, 取消/失败清理未完成文件

    坏包(zip 结构损坏)连下载包一起删除, 让下次点击重新下载而不是反复解压失败.
    """
    try:
        if not _fetch(job):
            job["phase"] = PHASE_CANCELLED
            return
        if job["cancel"]:
            job["phase"] = PHASE_CANCELLED
            return
        job["phase"] = PHASE_EXTRACT
        if job["mode"] == MODE_PACK:
            written = _extract_pack(job)
            if job["cancel"]:
                # 取消在解压中途: 删掉本次已落盘的贴图, 不留半套包(下次点击重新解)
                for name in written:
                    _remove_quietly(os.path.join(job["source_base"], name))
                job["phase"] = PHASE_CANCELLED
                return
        else:
            _extract(job)
        job["phase"] = PHASE_DONE
    except Exception as e:  # noqa: BLE001 - 网络/压缩包/磁盘异常统一落面板错误行
        extracting = job["phase"] == PHASE_EXTRACT
        job["error"] = "{}: {}".format(type(e).__name__, e)
        job["phase"] = PHASE_ERROR
        if extracting:
            # 解压期失败(坏包/包内无源文件/写盘失败): 连下载包与本次已解出的文件一起删,
            # 否则下次点击会跳过下载反复失败, 或让半套贴图被当成完整包导入
            _remove_quietly(job["zip_path"])
            for name in job.get("written") or ():
                _remove_quietly(os.path.join(job["source_base"], name))
    finally:
        if job["phase"] != PHASE_DONE:
            _remove_quietly(job["zip_path"] + _PART_SUFFIX)


def _request_headers(job: dict) -> dict:
    """下载请求头: UA 恒带(bare urllib 的 Python-urllib UA 常被 CDN 挡), Referer 按索引声明带

    cgbookcase 的 CDN 开了防盗链: 不带 Referer 直接回 403, 且只认站点自身地址
    (https://www.cgbookcase.com 通过, https://cgbookcase.com 与裸请求均 403, 探针实测).
    站点地址由索引 source.site 给出(见 asset_manifest), 换镜像只改索引, 下载器里不硬编码站点.
    """
    headers = {"User-Agent": "Mozilla/5.0"}
    referer = job.get("referer") or ""
    if referer:
        headers["Referer"] = referer
    return headers


def _fetch(job: dict) -> bool:
    """下载到 <zip>.part 后原子改名; 下载包已存在则跳过下载直接返回 True

    返回 False 表示收到取消请求.
    """
    zip_path = job["zip_path"]
    if os.path.isfile(zip_path) and os.path.getsize(zip_path) > 0:
        job["received"] = job["total"] = os.path.getsize(zip_path)
        return True
    part = zip_path + _PART_SUFFIX
    os.makedirs(os.path.dirname(zip_path), exist_ok=True)
    request = urllib.request.Request(job["url"], headers=_request_headers(job))
    with urllib.request.urlopen(request, timeout=_TIMEOUT) as response, open(part, "wb") as fh:
        job["total"] = int(response.headers.get("Content-Length") or 0)
        while True:
            if job["cancel"]:
                return False
            chunk = response.read(CHUNK_SIZE)
            if not chunk:
                break
            fh.write(chunk)
            job["received"] += len(chunk)
    os.replace(part, zip_path)
    return True


def _hdri_member(names: list) -> str:
    """包内 HDRI 成员名: 优先 *_HDR.exr, 其次首个 .exr/.hdr, 都没有返回空串"""
    for name in names:
        if name.lower().endswith(_HDRI_PREFERRED):
            return name
    for name in names:
        if Path(name).suffix.lower() in _HDRI_EXTS:
            return name
    return ""


def _extract(job: dict) -> None:
    """从下载包解压 HDRI 源文件到 <source_base><包内扩展名>(先 .part 再原子替换)

    解压中途失败时连带删掉 <目标>.part: 它不是源文件(existing_source 按扩展名探测,
    list_archives 只认索引推出的 .zip), 留下就永久占库且用户无从察觉.
    """
    with zipfile.ZipFile(job["zip_path"]) as archive:
        member = _hdri_member(archive.namelist())
        if not member:
            raise RuntimeError("no HDRI file in the archive")
        target = job["source_base"] + Path(member).suffix.lower()
        part = target + _PART_SUFFIX
        os.makedirs(os.path.dirname(target), exist_ok=True)
        replaced = False
        try:
            with archive.open(member) as src, open(part, "wb") as dst:
                shutil.copyfileobj(src, dst, CHUNK_SIZE)
            os.replace(part, target)
            replaced = True
        finally:
            # 成功时 .part 已被 replace 掉; 失败/中断时在这里收尾, 与 _worker 只清 zip.part 的分工互补
            if not replaced:
                _remove_quietly(part)


def _extract_pack(job: dict) -> list:
    """把下载包内的贴图全部解到目标目录, 返回已写出文件名(取消时由调用方清理)

    包内还带 .blend/.mtlx 与站点缩略图副本, 前者按扩展名排除, 后者与资产同名(见 skip_stem);
    贴图平铺进目标目录(站点包内子目录层级不保留), 先写 .part 再原子替换.
    """
    target_dir = Path(job["source_base"])
    skip_stem = (job["skip_stem"] or "").lower()
    # 已写出清单挂在任务上: 解压中途抛错时由 _worker 的异常分支按它清理(不留半套贴图)
    written = job["written"] = []
    with zipfile.ZipFile(job["zip_path"]) as archive:
        members = [name for name in archive.namelist() if Path(name).suffix.lower() in IMAGE_EXTS]
        if not members:
            raise RuntimeError("no texture files in the archive")
        selected = []
        for member in members:
            name = Path(member).name
            if not name or name.startswith(".") or Path(name).stem.lower() == skip_stem:
                continue
            selected.append((member, name))
        os.makedirs(target_dir, exist_ok=True)
        # 解压期进度分母只算实际要写出的贴图(缩略图/隐藏/非图像成员不计, 否则进度条到不了满)
        job["total"] = len(selected)
        job["received"] = 0
        for member, name in selected:
            if job["cancel"]:
                break
            target = target_dir / name
            part = str(target) + _PART_SUFFIX
            replaced = False
            try:
                with archive.open(member) as src, open(part, "wb") as dst:
                    shutil.copyfileobj(src, dst, CHUNK_SIZE)
                os.replace(part, target)
                replaced = True
            finally:
                if not replaced:
                    _remove_quietly(part)
            written.append(name)
            job["received"] += 1
    if not job["cancel"]:
        _prune_other_specs(target_dir, job["attr"], written)
    return written


def _prune_other_specs(directory: Path, attr: str, written: list) -> None:
    """清理同目录下不属于本档的贴图(同分辨率换格式重下时不留上一套)

    只在本次解出的文件确实带该档标记时才动手: 标记一个都没命中说明站点命名变了,
    此时删文件只会把刚解出的整套弄丢. 下载包(.zip)不在此列.
    """
    token = "_" + (attr or "").lower()
    if not attr or not any(token in name.lower() for name in written):
        return
    keep = {name.lower() for name in written}
    try:
        entries = list(os.scandir(directory))
    except OSError:
        return
    for entry in entries:
        if entry.is_file() and entry.name.lower() not in keep and Path(entry.name).suffix.lower() in IMAGE_EXTS:
            _remove_quietly(entry.path)


def _remove_quietly(path: str) -> None:
    """删除文件(不存在/被占用时静默跳过)"""
    try:
        os.remove(path)
    except OSError:
        pass


def _ensure_timer() -> None:
    """按需注册进度轮询计时器(persistent: 载入其它 .blend 不打断下载显示)"""
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=_TICK_SECONDS, persistent=True)


def _redraw_panels() -> None:
    """标记面板所在区域重绘(后台线程不改 UI, 由本计时器在主线程统一触发)"""
    for window in bpy.context.window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type in _REDRAW_AREAS:
                area.tag_redraw()


def _tick():
    """进度轮询(主线程): 摘掉完成/取消的任务并重绘, 仍有活动任务时续跳

    完成的任务不留在表里——"已下载"由磁盘存在性判定, 面板下一帧自动切到完成态;
    错误任务保留, 供面板显示失败原因直到用户重试或切换目标.
    """
    active = False
    for key, job in list(_JOBS.items()):
        if job["phase"] in _ACTIVE_PHASES:
            active = True
        elif job["phase"] in (PHASE_DONE, PHASE_CANCELLED):
            _JOBS.pop(key, None)
    _redraw_panels()
    return _TICK_SECONDS if active else None
