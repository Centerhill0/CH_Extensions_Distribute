"""
在线资产库索引模块

读取在线资产库根目录的 manifest.json(建库脚本产出的唯一索引)并按索引列条目: 缩略图在本地,
源文件按需下载. 本模块只做纯数据推导(路径/规格/链接), 不读偏好也不下载.

索引里有两类条目形态, 落盘布局不同:
- 单文件型(HDRI): 条目带 hdri 字段, 下载解出单个 .exr/.hdr 到 <分类>/HDRIs/
- 包型(材质): 条目带 package 字段, 下载解出整包贴图到 <包目录>/<分辨率>/

主要功能:
- load_manifest: 按路径与 mtime 记忆化读取索引(缺失/损坏返回 None)
- list_manifest_categories / list_manifest_assets / list_manifest_pbr_assets: 分类与条目表
- resolution_items / format_items / resolve_option: 下载规格归一(分辨率 + 格式 + 体积)
- local_base / archive_path / spec_dir / existing_source / download_url: 本地落盘路径与已下载探测
- size_text: 体积展示文案
"""

import json
import os
import time
from pathlib import Path

import bpy

from .pbr_convention import IMAGE_EXTS

# 索引文件名(建库脚本固定产出, 位于库根)
MANIFEST_NAME = "manifest.json"

# 源文件子目录(索引缺 hdri 字段时按"<分类>/HDRIs/"回落, 与目录扫描口径一致)
HDRI_SOURCE_SUBDIR = "HDRIs"

# HDRI 源文件候选扩展名(与目录扫描同表)
HDRI_SOURCE_EXTS = (".exr", ".hdr")

# 默认分辨率优先序(作者定 4K 起步; 该档缺失时逐档回落, 全缺取最小档)
DEFAULT_RESOLUTION_ORDER = ("4K", "2K", "1K")

# 索引缓存(键 = 规范化库根, 值 = ((mtime_ns, size), 数据)); 超过上限整体清空
_CACHE_MAX = 8
_MANIFEST_CACHE: dict = {}

# 索引条目表缓存(键 = (规范化库根, 分类, 资产种类), 值 = (索引签名, 条目列表)): 面板每帧
# 至少两遍取数(选择器主体 + 下载行), 大索引上逐条重建 dict 可感知(2000 条 37-57ms/次
# 探针实测); 签名 = manifest_signature(mtime_ns, size), 索引增删即失效
_ASSETS_CACHE: dict = {}

# 包型条目的分类缓存(键 = 规范化库根, 值 = (索引签名, 分类列表)): 分类下拉每帧取一次,
# 逐条筛选 2000+ 条目不必每帧重跑
_PBR_CATEGORIES_CACHE: dict = {}

# 下载包统计短窗缓存(键 = 规范化库根, 值 = (单调时刻, (数量, 体积))): 偏好面板每帧都要
# 重建"索引条目 × 规格"的名称表, 窗口内复用上次结果; 清理动作后主动失效
_STATS_CACHE: dict = {}
_STATS_WINDOW_SECONDS = 0.5

# 体积单位换算(只用于展示, 1024 进制)
_SIZE_KB = 1024.0
_SIZE_MB = 1024.0 * 1024.0
_SIZE_GB = 1024.0 * 1024.0 * 1024.0


def _root_path(root: str) -> Path:
    """库根的绝对路径(解 // 相对前缀)"""
    return Path(bpy.path.abspath(root))


def _safe_rel_text(text) -> str:
    """索引里的相对路径字段(thumb/hdri): 非字符串/绝对路径/含 `..` 时返回空串

    索引是外部产出, 坏索引不该把缩略图与落盘路径带出库根(与 _source_rel 的收窄同口径).
    """
    if not isinstance(text, str) or not text:
        return ""
    rel = Path(text)
    if rel.is_absolute() or ".." in rel.parts:
        return ""
    return text


def _safe_segment(text) -> str:
    """索引里的单段名成分(key/attr/category): 含分隔符/盘符或是 `.`/`..` 时返回空串

    这些字段会被拼进落盘基名(<key>_<attr>)与源目录, 带分隔符即可越出库根.
    """
    if not isinstance(text, str) or not text or text in (".", ".."):
        return ""
    return "" if any(char in text for char in "/\\:") else text


def load_manifest(root: str) -> dict | None:
    """读取库根的 manifest.json(mtime/size 未变则复用缓存; 缺失/无法解析返回 None)

    只认带 assets 字典的顶层对象; 更早期/损坏的索引一律按"无索引"处理, 由调用方提示.
    """
    if not root:
        return None
    path = _root_path(root) / MANIFEST_NAME
    try:
        stat = path.stat()
    except OSError:
        return None
    key = os.path.normcase(str(path.parent))
    hit = _MANIFEST_CACHE.get(key)
    if hit is not None and hit[0] == (stat.st_mtime_ns, stat.st_size):
        return hit[1]
    data = None
    try:
        # 用 Path.read_text 而非内建 open: 静态审计把本树内同名的 open 定义当候选形参表;
        # utf-8-sig 容忍带 BOM 的索引(Windows 记事本另存常见), 无 BOM 文件行为不变
        loaded = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(loaded, dict) and isinstance(loaded.get("assets"), dict):
            data = loaded
    except (OSError, ValueError):
        data = None
    if len(_MANIFEST_CACHE) >= _CACHE_MAX:
        _MANIFEST_CACHE.clear()
    _MANIFEST_CACHE[key] = ((stat.st_mtime_ns, stat.st_size), data)
    return data


def manifest_state(root: str) -> str:
    """库根的索引状态: ONLINE(可解析) / BROKEN(有文件但解析失败) / OFFLINE(无索引)

    偏好列表的在线图标与 HDRI 档的下载行据此区分三态: 损坏时提示"索引无法解析",
    而不是静默退回离线模式.
    """
    if not root:
        return 'OFFLINE'
    if load_manifest(root) is not None:
        return 'ONLINE'
    return 'BROKEN' if (_root_path(root) / MANIFEST_NAME).is_file() else 'OFFLINE'


def manifest_signature(root: str) -> tuple:
    """索引文件的 (mtime_ns, size); 缺失/不可读返回 ()

    供列表缓存把"索引版本"并入签名: 索引增删条目而源目录未变时也要失效重扫.
    """
    if not root:
        return ()
    try:
        stat = (_root_path(root) / MANIFEST_NAME).stat()
    except OSError:
        return ()
    return (stat.st_mtime_ns, stat.st_size)


def _url_template(data: dict) -> str:
    """索引声明的下载链接模板(缺 source 段返回空串)"""
    source = data.get("source")
    if not isinstance(source, dict):
        return ""
    return str(source.get("downloadUrlTemplate") or "")


def _source_site(data: dict) -> str:
    """索引声明的站点地址(下载请求的 Referer 来源; 非 http(s) 或缺失返回空串)

    cgbookcase 的 CDN 对不带 Referer 的请求直接回 403, 而允许的 Referer 正是这个站点地址
    (探针实测: https://www.cgbookcase.com 通过, https://cgbookcase.com 与裸请求均 403).
    站点点位由索引给出而不是硬编码在下载器里: 换镜像/换站点只改索引.
    """
    source = data.get("source")
    if not isinstance(source, dict):
        return ""
    site = source.get("site")
    site = site.strip() if isinstance(site, str) else ""
    return site if site.startswith(("http://", "https://")) else ""


def _download_items(rec: dict, template: str, referer: str = "") -> list:
    """条目下载规格归一: attr 拆成分辨率与格式, 并附体积/下载链接/容器种类/请求 Referer

    站点侧 attr 形如 '4K'(HDRI, 无格式后缀),'2K-JPG'(ambientCG 材质)或 '2K'(cgbookcase 材质);
    无格式后缀时格式取条目自身声明的格式(HDRI 取 hdri 字段扩展名, 材质包全为 PNG), 供格式
    下拉仍有一项可选. 下载链接有两种来源: 索引顶层模板(按 assetId + attr 拼)或条目内
    downloadUrls 直链表(材质库无需插件复刻站点命名规则), 后者同时给出容器种类.
    referer: 索引 source.site, 下载请求带上它(cgbookcase 的 CDN 无 Referer 即 403).
    """
    is_pack = bool(_safe_rel_text(rec.get("package")))
    fallback_fmt = "PNG" if is_pack else (Path(str(rec.get("hdri") or "")).suffix.lstrip(".").upper() or "EXR")
    asset_id = rec.get("assetId")
    asset_id = asset_id if isinstance(asset_id, str) else ""
    items = []
    for entry in rec.get("downloads") or []:
        if isinstance(entry, dict):
            attr = _safe_segment(str(entry.get("attr") or "").strip())
            size = entry.get("size") or 0
        else:
            attr, size = _safe_segment(str(entry).strip()), 0
        if not attr:
            continue
        resolution, _sep, fmt = attr.partition("-")
        try:
            size_value = int(size)
        except (TypeError, ValueError):
            size_value = 0
        url = _download_link(rec, template, asset_id, attr)
        items.append(
            {
                "attr": attr,
                "res": resolution,
                "fmt": fmt or fallback_fmt,
                "size": size_value if size_value > 0 else 0,
                "url": url,
                "referer": referer,
            }
        )
    return items


def _download_link(rec: dict, template: str, asset_id: str, attr: str) -> str:
    """该规格的下载链接: 条目自带 downloadUrls 时直取, 否则按顶层模板拼"""
    urls = rec.get("downloadUrls")
    if isinstance(urls, dict):
        info = urls.get(attr)
        if isinstance(info, dict):
            return str(info.get("url") or "")
        return ""
    return _format_url(template, asset_id, attr)


def _format_url(template: str, asset_id: str, attr: str) -> str:
    """按索引模板拼下载链接: 模板占位符缺失/多余一律给空串(坏索引不该让绘制帧抛错)"""
    if not template:
        return ""
    try:
        return template.format(assetId=asset_id, attribute=attr)
    except (KeyError, IndexError, ValueError, AttributeError):
        return ""


def list_manifest_categories(root: str, kind: str = 'WORLD') -> list:
    """索引里的分类名(保持索引顺序; 无索引/分类段为空时按资产汇总; 都无返回空表)

    kind='PBR' 时只列真正有可列条目的分类: 无通道声明的资产(单图掩膜/图案)不进入在线
    材质列表, 其独占的分类留在分类下拉里只会落到"该分类没有缩略图"的空态.
    """
    data = load_manifest(root)
    if data is None:
        return []
    if kind == 'PBR':
        return _pbr_categories(root, data)
    categories = data.get("categories")
    if isinstance(categories, dict) and categories:
        return list(categories)
    names = {rec.get("category") for rec in data["assets"].values() if isinstance(rec, dict) and isinstance(rec.get("category"), str) and rec.get("category")}
    return sorted(names)


def _pbr_categories(root: str, data: dict) -> list:
    """包型条目覆盖到的分类(按索引 categories 的顺序; 多分类资产计入其全部分类)

    结果按索引签名缓存: 分类下拉与条目表每帧各取一遍, 2000+ 条目的逐条筛选不必每帧重跑.
    """
    key = os.path.normcase(str(_root_path(root)))
    signature = manifest_signature(root)
    hit = _PBR_CATEGORIES_CACHE.get(key)
    if hit is not None and hit[0] == signature:
        return list(hit[1])
    names = []
    for _key, rec in data["assets"].items():
        if not isinstance(rec, dict) or rec.get("retired"):
            continue
        if not rec.get("maps") or not _safe_rel_text(rec.get("package")):
            continue
        for name in _record_categories(rec):
            if name not in names:
                names.append(name)
    order = list(data.get("categories") or {})
    names.sort(key=lambda name: (order.index(name) if name in order else len(order), name))
    if len(_PBR_CATEGORIES_CACHE) >= _CACHE_MAX:
        _PBR_CATEGORIES_CACHE.clear()
    _PBR_CATEGORIES_CACHE[key] = (signature, names)
    return list(names)


def list_manifest_assets(root: str, category: str) -> list:
    """某分类下的索引条目(排除已下架; 结构与目录扫描条目同构, source 恒为空串)

    条目为 dict: name(展示名)/key(小写 assetId)/thumb(缩略图绝对路径)/source(恒空串)/
    source_name(恒空串)/category/hdri(源文件相对路径)/asset_id/downloads(规格表).
    HDRI 档面板每帧至少两遍取数(选择器主体 + 下载行), 结果按 (库根, 分类) + 索引签名
    缓存(大索引逐条重建 dict 每帧几十毫秒, 探针实测); 返回副本, 调用方原地排序不污染缓存.
    """
    data = load_manifest(root)
    if data is None or not category:
        return []
    cache_key = (os.path.normcase(str(_root_path(root))), category, 'WORLD')
    signature = manifest_signature(root)
    hit = _ASSETS_CACHE.get(cache_key)
    if hit is not None and hit[0] == signature:
        return list(hit[1])
    root_path = _root_path(root)
    template = _url_template(data)
    referer = _source_site(data)
    assets = []
    for key, rec in data["assets"].items():
        if not isinstance(rec, dict) or rec.get("retired") or rec.get("category") != category:
            continue
        # 键会被拼进落盘基名, 带分隔符/盘符即可能越出库根: 坏索引条目直接跳过
        key = _safe_segment(key)
        if not key:
            continue
        # 字段类型逐项收窄: 坏索引只让该条目的对应字段退化为空, 不让绘制帧抛错;
        # 路径字段另做越界收窄(绝对路径/`..` 一律空, 见 _safe_rel_text)
        thumb = _safe_rel_text(rec.get("thumb"))
        name = rec.get("name")
        name = name if isinstance(name, str) and name else key
        hdri = _safe_rel_text(rec.get("hdri"))
        asset_id = rec.get("assetId")
        asset_id = asset_id if isinstance(asset_id, str) and asset_id else key
        assets.append(
            {
                "name": name,
                "key": key,
                "thumb": str(root_path / thumb) if thumb else "",
                "source": "",
                "source_name": "",
                "category": category,
                "hdri": hdri,
                "asset_id": asset_id,
                "downloads": _download_items(rec, template, referer),
            }
        )
    if len(_ASSETS_CACHE) >= _CACHE_MAX:
        _ASSETS_CACHE.clear()
    _ASSETS_CACHE[cache_key] = (signature, assets)
    return list(assets)


def find_manifest_asset(root: str, category: str, key: str):
    """按条目键反查索引条目(查无返回 None)"""
    for asset in list_manifest_assets(root, category):
        if asset["key"] == key:
            return asset
    return None


def _record_categories(rec: dict) -> list:
    """条目所属分类(多分类资产取 allCategories, 否则取主分类单值)"""
    all_categories = rec.get("allCategories")
    if isinstance(all_categories, list) and all_categories:
        return [name for name in all_categories if isinstance(name, str) and name]
    category = rec.get("category")
    return [category] if isinstance(category, str) and category else []


def _in_category(rec: dict, category: str) -> bool:
    """条目是否属于该分类: 多分类资产按 allCategories 匹配(物理位置只取主分类一份)

    站点一个资产可跨多个分类(如 Floor 与 Tiles), 物理文件只放主分类, 但用户点任一分类
    都应能检索到同一条目; 无 allCategories 的索引(ambientCG)按 category 单值匹配.
    """
    return category in _record_categories(rec)


def _normal_convention(rec: dict, default: str) -> str:
    """条目的法线朝向声明(directx / opengl); 未声明或取值未知时返回空串"""
    value = rec.get("normalConvention") or default
    value = value.lower() if isinstance(value, str) else ""
    return value if value in ('directx', 'opengl') else ""


def list_manifest_pbr_assets(root: str, category: str) -> list:
    """某分类下的包型(材质资产包)索引条目(排除已下架与无通道声明的条目)

    条目为 dict: name/key/thumb(缩略图绝对路径)/source(恒空串)/source_name(恒空串)/
    category(请求的分类)/package(包目录相对路径)/asset_id/maps(站点声明的通道组)/
    normal_convention(directx / opengl / 空)/downloads(规格表, 含 url).
    无 maps 声明的条目(单图掩膜,图案装饰)不构成本插件可建的 PBR 链, 不入在线列表——
    避免出现"能下载但导不进来"的死条目. 结果按 (库根, 分类) + 索引签名缓存, 返回副本.
    """
    data = load_manifest(root)
    if data is None or not category:
        return []
    cache_key = (os.path.normcase(str(_root_path(root))), category, 'PBR')
    signature = manifest_signature(root)
    hit = _ASSETS_CACHE.get(cache_key)
    if hit is not None and hit[0] == signature:
        return list(hit[1])
    root_path = _root_path(root)
    template = _url_template(data)
    referer = _source_site(data)
    default_convention = data.get("normalConvention")
    assets = []
    for key, rec in data["assets"].items():
        if not isinstance(rec, dict) or rec.get("retired") or not _in_category(rec, category):
            continue
        maps = [name for name in (rec.get("maps") or []) if isinstance(name, str) and name]
        if not maps:
            continue
        # 键会被拼进下载包名, 带分隔符/盘符即可能越出库根: 坏索引条目直接跳过
        key = _safe_segment(key)
        package = _safe_rel_text(rec.get("package"))
        if not key or not package:
            continue
        thumb = _safe_rel_text(rec.get("thumb"))
        name = rec.get("name")
        name = name if isinstance(name, str) and name else key
        asset_id = rec.get("assetId")
        asset_id = asset_id if isinstance(asset_id, str) and asset_id else key
        assets.append(
            {
                "name": name,
                "key": key,
                "thumb": str(root_path / thumb) if thumb else "",
                "source": "",
                "source_name": "",
                "category": category,
                "package": package,
                "asset_id": asset_id,
                "maps": maps,
                "normal_convention": _normal_convention(rec, default_convention),
                "downloads": _download_items(rec, template, referer),
            }
        )
    if len(_ASSETS_CACHE) >= _CACHE_MAX:
        _ASSETS_CACHE.clear()
    _ASSETS_CACHE[cache_key] = (signature, assets)
    return list(assets)


def find_manifest_pbr_asset(root: str, category: str, key: str):
    """按条目键反查包型索引条目(查无返回 None)"""
    for asset in list_manifest_pbr_assets(root, category):
        if asset["key"] == key:
            return asset
    return None


def resolution_rank(resolution: str) -> int:
    """分辨率档位值('16K' -> 16; 非数字前缀按 0), 排序与大档判定共用"""
    digits = ""
    for char in resolution:
        if not char.isdigit():
            break
        digits += char
    return int(digits) if digits else 0


def resolution_items(asset) -> list:
    """分辨率候选(按数值升序)"""
    seen = []
    for item in asset.get("downloads") or []:
        if item["res"] not in seen:
            seen.append(item["res"])
    return sorted(seen, key=resolution_rank)


def format_items(asset) -> list:
    """格式候选(首见顺序; 无格式后缀的库为单项, 取自源文件扩展名)"""
    formats = []
    for item in asset.get("downloads") or []:
        if item["fmt"] not in formats:
            formats.append(item["fmt"])
    return formats


def _default_resolution(resolutions: list) -> str:
    """默认分辨率(优先序见 DEFAULT_RESOLUTION_ORDER, 全缺取最小档)"""
    for resolution in DEFAULT_RESOLUTION_ORDER:
        if resolution in resolutions:
            return resolution
    return resolutions[0]


def resolve_option(asset, resolution: str, fmt: str):
    """按面板选择解析生效的下载规格(选择失效时回落默认分辨率/该分辨率首个格式)

    无任何规格(索引 downloads 为空)返回 None, 由调用方禁用下载.
    """
    items = asset.get("downloads") or []
    if not items:
        return None
    resolutions = resolution_items(asset)
    chosen_res = resolution if resolution in resolutions else _default_resolution(resolutions)
    formats = [item for item in items if item["res"] == chosen_res]
    chosen_fmt = fmt if any(item["fmt"] == fmt for item in formats) else formats[0]["fmt"]
    return next((item for item in formats if item["fmt"] == chosen_fmt), formats[0])


def _source_rel(rec: dict) -> str:
    """条目落盘目录(相对库根): 包型取 package 字段, 单文件型取 hdri 的父目录

    缺失/绝对路径/含 `..` 时一律回落 "<分类>/HDRIs/"(与目录扫描同口径), 避免坏索引把
    落盘与清理带到库根甚至库外; 分类名本身也按单段收窄(含分隔符即按空分类回落).
    """
    package = _safe_rel_text(rec.get("package"))
    if package:
        return package
    hdri = _safe_rel_text(rec.get("hdri"))
    if hdri:
        return str(Path(hdri).parent)
    category = _safe_segment(rec.get("category"))
    return str(Path(category) / HDRI_SOURCE_SUBDIR)


def source_dirs(assets: list) -> tuple:
    """这些条目实际用到的源目录(相对库根, 去重保序; 分组口径与 downloaded_keys 同一来源)

    供列表缓存的目录签名覆盖全部分组: 只盯首个条目的 hdri 时, 索引缺 hdri(受支持的回落
    口径)会把签名退化成库根, 下载写入 <分类>/HDRIs/ 后列表不刷新; 同分类存在多个源目录
    时同理只盯一个目录会漏失效.
    """
    return tuple(dict.fromkeys(_source_rel(asset) for asset in assets))


def local_base(root: str, asset, option) -> Path:
    """本地文件基名(不含扩展名): <源目录>/<key>_<attr>

    源目录见 _source_rel(尊重分类变更未迁移时的旧路径, 缺失时回落 "<分类>/HDRIs/").
    """
    return _root_path(root) / _source_rel(asset) / "{}_{}".format(asset["key"], option["attr"])


def archive_path(root: str, asset, option) -> str:
    """下载包落盘路径(与源文件同基名, .zip 后缀; 解压后保留不删)"""
    return str(local_base(root, asset, option)) + ".zip"


def _is_pack(rec: dict) -> bool:
    """条目是否为包型资产(材质资产包: 索引带 package 字段)"""
    return bool(_safe_rel_text(rec.get("package")))


def package_dir(root: str, asset):
    """包型资产的包目录绝对路径(非包型/坏路径返回 None)"""
    rel = _safe_rel_text(asset.get("package"))
    return _root_path(root) / rel if rel else None


def spec_dir(root: str, asset, option):
    """包型资产某档的贴图目录: <包目录>/<分辨率>(非包型/无规格返回 None)

    一个分辨率一个子包: 换档下载不覆盖其它分辨率, 导入按当前选择的分辨率取目录.
    """
    base = package_dir(root, asset)
    resolution = _safe_segment(str((option or {}).get("res") or ""))
    if base is None or not resolution:
        return None
    return base / resolution


def _dir_texture_names(directory) -> set:
    """目录内贴图文件名(小写集合; 目录缺失/不可读返回空集)"""
    names = set()
    if directory is None:
        return names
    try:
        with os.scandir(directory) as entries:
            for entry in entries:
                if entry.is_file() and Path(entry.name).suffix.lower() in IMAGE_EXTS:
                    names.add(entry.name.lower())
    except OSError:
        pass
    return names


def _spec_in_names(names, option) -> bool:
    """这些文件名里是否含该规格的标记(站点包内文件名恒带 _<attr>, 如 _2K-JPG / _2k)

    按 "_<attr>" 而不是裸 attr 比对: 12K 包的 "12k" 里含 "2k", 裸匹配会把 2K 误判成已下载.
    """
    attr = str((option or {}).get("attr") or "").lower()
    return bool(attr) and any("_" + attr in name for name in names)


def existing_source(root: str, asset, option) -> str:
    """该规格已落盘的源路径(未下载返回空串)

    单文件型按扩展名候选探测; 包型返回该分辨率的贴图子目录(要求子目录内已有该档贴图),
    供选择器判定"可否导入"与导入侧取包目录.
    """
    if asset is None or option is None:
        return ""
    if _is_pack(asset):
        directory = spec_dir(root, asset, option)
        return str(directory) if _spec_in_names(_dir_texture_names(directory), option) else ""
    base = str(local_base(root, asset, option))
    for ext in HDRI_SOURCE_EXTS:
        candidate = base + ext
        if os.path.isfile(candidate):
            return candidate
    return ""


def spec_archive_exists(root: str, asset, option) -> bool:
    """该规格的下载包是否仍在(清理包后贴图仍在, 图标据此仍判为已下载)"""
    if asset is None or option is None:
        return False
    return os.path.isfile(archive_path(root, asset, option))


def downloaded_keys(root: str, assets: list) -> set:
    """这些条目里"任一规格已落盘"的键集合(每个落盘目录只列一次)

    供选择器的"仅显示现有源文件"开关在在线库上过滤: 在线库的源文件按需下载, 判定口径是
    本地是否已有该资产的任一分辨率/格式. 单文件型按文件名匹配, 包型按分辨率子目录内的
    贴图标记匹配(每个包目录只扫一遍子目录).
    """
    keys = set()
    groups: dict = {}
    for asset in assets:
        groups.setdefault(_source_rel(asset), []).append(asset)
    root_path = _root_path(root)
    for parent, group in groups.items():
        if _is_pack(group[0]):
            specs: dict = {}
            try:
                with os.scandir(root_path / parent) as entries:
                    for entry in entries:
                        if not entry.is_dir():
                            continue
                        names = _dir_texture_names(Path(entry.path))
                        if names:
                            specs[entry.name] = names
            except OSError:
                continue
            for asset in group:
                if any(_spec_in_names(specs.get(str(item["res"]), ()), item) for item in asset.get("downloads") or []):
                    keys.add(asset["key"])
            continue
        try:
            names = {name.lower() for name in os.listdir(root_path / parent)}
        except OSError:
            continue
        for asset in group:
            prefix = asset["key"].lower() + "_"
            stems = [prefix + str(item["attr"]).lower() for item in asset.get("downloads") or []]
            if any(stem + ext in names for stem in stems for ext in HDRI_SOURCE_EXTS):
                keys.add(asset["key"])
    return keys


def download_url(asset, option) -> str:
    """该规格的下载链接(索引缺模板/该规格无链接返回空串)"""
    if asset is None or option is None:
        return ""
    return option.get("url") or ""


def size_text(size: int) -> str:
    """体积展示文案(0/非法返回空串)"""
    if not size or size <= 0:
        return ""
    if size < _SIZE_MB:
        return "{:.0f} KB".format(size / _SIZE_KB)
    if size < _SIZE_GB:
        return "{:.0f} MB".format(size / _SIZE_MB)
    return "{:.1f} GB".format(size / _SIZE_GB)


def list_archives(root: str) -> list:
    """库内插件下载的资产包(.zip; 无索引返回空表)

    只按"索引条目 × 下载规格"推出的确定文件名探测, 不做目录通配: 用户自己放在源目录里的
    zip 不会被误认成下载包(收口的清理动作只该删自己产出的东西).
    """
    data = load_manifest(root)
    if data is None:
        return []
    root_path = _root_path(root)
    groups: dict = {}
    for key, rec in data["assets"].items():
        if not isinstance(rec, dict):
            continue
        names = groups.setdefault(_source_rel(rec), [])
        for option in _download_items(rec, ""):
            names.append("{}_{}.zip".format(key, option["attr"]))
    archives = []
    for rel, names in groups.items():
        directory = root_path / rel
        try:
            # 目录只列一次(按小写名建索引), 再与"索引推出的文件名"求交: 既不做通配误删,
            # 也不对每个规格逐一 stat(2040 资产的库上每帧就是上万次系统调用)
            present = {name.lower(): name for name in os.listdir(directory)}
        except OSError:
            continue
        for name in names:
            actual = present.get(name.lower())
            if actual:
                archives.append(directory / actual)
    return sorted(archives)


def remove_archives(root: str) -> tuple:
    """删除库内全部下载包, 返回 (删除数量, 删除字节数, 失败数量)

    源文件与索引不动; 单个文件被占用/只读时计入失败数而不中断其余删除,
    该文件的体积也不计入删除量(汇报不虚报).
    """
    count = 0
    size = 0
    failed = 0
    for path in list_archives(root):
        try:
            file_size = path.stat().st_size
            path.unlink()
        except OSError:
            failed += 1
            continue
        count += 1
        size += file_size
    # 清理后统计缓存立即失效(窗口内不留旧数)
    _STATS_CACHE.clear()
    return count, size, failed


def archive_stats(root: str) -> tuple:
    """库内下载包的数量与总体积(只统计不删除; 无索引返回 (0, 0))

    偏好面板每帧调用: 每次都要重建"索引条目 × 规格"的名称表, 故取 _STATS_WINDOW_SECONDS
    短窗缓存(下载完成/外部放包最迟半个窗口后可见); 清理动作主动失效(见 remove_archives).
    """
    key = os.path.normcase(str(_root_path(root))) if root else ""
    now = time.monotonic()
    hit = _STATS_CACHE.get(key)
    if hit is not None and now - hit[0] <= _STATS_WINDOW_SECONDS:
        return hit[1]
    count = 0
    size = 0
    for path in list_archives(root):
        try:
            size += path.stat().st_size
        except OSError:
            continue
        count += 1
    if len(_STATS_CACHE) >= _CACHE_MAX:
        _STATS_CACHE.clear()
    _STATS_CACHE[key] = (now, (count, size))
    return count, size


def archive_stats_fields(count: int, size: int) -> tuple:
    """下载包统计的数值字段 (数量, 体积MB): 纯整数文本, 不补位不加空格

    面板拼「共{}个zip包,共计{}MB」时用这两个字段; 体积折成整数 MB(向下取整, 不足 1 MB 记 0).
    """
    return str(count), str(int(size // _SIZE_MB))
