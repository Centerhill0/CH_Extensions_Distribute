"""
PBR 贴图文件名识别数据表

PBR 贴图后缀 -> 通道组映射的单一事实来源: 文件名归一化后按别名最长匹配归入 14 组纹理
类型之一, 供资产包导入(pbr_material)把包内贴图对号入座. 组表同时携带各通道的颜色空间
口径(sRGB / Non-Color)与法线朝向标记, 建链侧据此设图像数据块.

数据与作者批处理脚本(NoteBook/Test/Blender_Node_build/pbr_texture_convention.py)同源:
两边共用同一份别名表, 修改任一侧后须同步另一侧, 避免"文件按 A 规则改名, 插件按 B 规则识别".
端口/开关/参数节点等建链侧信息不在此表(建链照 PBR_Universal 模板, 见 pbr_material).

主要功能:
- parse_texture_filename: 文件名 -> (包名, 通道组, 法线朝向, 扩展名)
- normalize_name: 文件名归一化(小写 / 空格连字符转下划线 / 去撇号 / 压缩下划线)
- GROUP_BY_KEY / ALIAS_TO_GROUP / NORMAL_DIRECTION_TAGS: 组表与别名索引
- compact_name / match_alias_in_name: 按数据块名称(不分词)反查通道组
"""

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class TextureGroup:
    """一种纹理类型的识别数据: 组键 / 展示名 / 别名 / 颜色空间

    Attributes:
        key: 组标识(建链侧与报告文案按它取)
        label_zh: 组的中文展示名(报告文案用中文; 英文界面沿用原文, 不设英文字段)
        aliases: 文件名后缀别名(归一化后按最长匹配命中)
        colorspace: 图像数据块颜色空间('sRGB' | 'Non-Color')
    """

    key: str
    label_zh: str
    aliases: tuple
    colorspace: str


# 14 组纹理类型. 别名维护注意:
# - 短别名依赖长度降序命中(basecolor 9 字符 > color 5 > base 4 > col 3), 不要再入更短别名
# - "height" 归置换组(主用途), 不归凹凸
GROUPS = (
    TextureGroup(
        key="base_color",
        label_zh="基础色",
        aliases=("diffuse", "diff", "albedo", "color", "colour", "basecolor", "basecol", "base", "col"),
        colorspace="sRGB",
    ),
    TextureGroup(
        key="metallic",
        label_zh="金属度",
        aliases=("metallic", "metalness", "metal", "mtl"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="specular",
        label_zh="高光",
        aliases=("specular", "specularity", "spec", "spc"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="roughness",
        label_zh="粗糙度",
        aliases=("roughness", "rough", "rgh"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="glossiness",
        label_zh="光泽度",
        aliases=("gloss", "glossy", "glossiness"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="normal",
        label_zh="法向",
        aliases=("normal", "nor", "nrm", "nrml", "norm"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="bump",
        label_zh="凹凸",
        aliases=("bump", "bmp"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="displacement",
        label_zh="置换",
        aliases=("displacement", "displace", "disp", "dsp", "height", "heightmap"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="transmission",
        label_zh="透射",
        aliases=("transmission", "transparency", "refraction"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="emission",
        label_zh="自发光",
        aliases=("emission", "emissive", "emit"),
        colorspace="sRGB",
    ),
    TextureGroup(
        key="alpha",
        label_zh="不透明度",
        # mask: cgbookcase 站点的 Mask 文件在其 mapNameToGroup 里就归不透明度(站点只挂网页,
        # 不进 MR 压缩包; 用户手工放进包内时按 alpha 用, 比整包跳过好)
        aliases=("alpha", "opacity", "mask"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="ao",
        label_zh="环境光遮蔽",
        aliases=("ao", "ambient", "occlusion", "ambientocclusion"),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="ior",
        label_zh="折射率",
        aliases=("ior",),
        colorspace="Non-Color",
    ),
    TextureGroup(
        key="subsurface",
        label_zh="次表面",
        # translucency: cgbookcase 站点的 Translucency 文件(其 mapNameToGroup 归次表面);
        # 与 translucent 并列收, 最长匹配会先命中 12 字符的 translucency
        aliases=("translucent", "translucency", "scattering", "sss", "subsurface"),
        colorspace="Non-Color",
    ),
)

# 包内参与识别的图像扩展名(其余文件如许可说明/索引静默忽略, 不计入未识别)
IMAGE_EXTS = frozenset({".jpg", ".jpeg", ".png", ".tif", ".tiff", ".exr", ".hdr", ".bmp", ".tga", ".webp"})

GROUP_BY_KEY = {g.key: g for g in GROUPS}

ALIAS_TO_GROUP: dict = {}
for _g in GROUPS:
    for _a in _g.aliases:
        if _a in ALIAS_TO_GROUP:
            raise ValueError(f"别名重复定义:{_a}")
        ALIAS_TO_GROUP[_a] = _g

# 按长度降序, 供最长匹配使用(保证 basecolor 先于 color, opengl_normal 先于 normal)
ALIASES_BY_LENGTH: tuple = tuple(sorted(ALIAS_TO_GROUP, key=lambda s: (-len(s), s)))

# 法线朝向标记: normal 组的"限定词后缀"单独处理, 归一化后的完整后缀 -> 朝向
# (DX 需翻转绿通道, GL 不需; 裸 _normal 后缀无朝向信息, 建链侧按 GL 处理)
NORMAL_DIRECTION_TAGS: dict = {
    "normaldx": "DX",
    "normalgl": "GL",
    "directx_normal": "DX",
    "opengl_normal": "GL",
    "normal_dx": "DX",
    "normal_gl": "GL",
}
# 完整后缀(含朝向标记)按长度降序
SUFFIXES_BY_LENGTH: tuple = tuple(sorted(list(ALIASES_BY_LENGTH) + list(NORMAL_DIRECTION_TAGS), key=lambda s: (-len(s), s)))


# 名称匹配的分隔符: 名称与别名都压掉这些字符后做子串匹配, 于是 "Base Color"/"base-color"/
# "base_color" 与别名 basecolor 等价(作者定口径: 不分词, 直接判别名是否出现在名称里)
_RE_NAME_SEPARATORS = re.compile(r"[-_\s.]+")


def compact_name(name: str) -> str:
    """名称压成匹配形态: 小写 + 压掉分隔符(连字符/下划线/空白/点)"""
    return _RE_NAME_SEPARATORS.sub("", name.lower())


def _name_tokens(name: str) -> list:
    """按分隔符(- _ 空白 .)切出的词(小写, 丢弃空词)"""
    return [token for token in _RE_NAME_SEPARATORS.split(name.lower()) if token]


# 法线朝向关键字(Auto 判定的词表): 整词或以它结尾的词都算(normaldx / normalgl 这种粘连写法)
_NORMAL_DX_WORDS = ("dx", "directx")
_NORMAL_GL_WORDS = ("gl", "opengl")

# 词尾允许被"朝向标记"或"规格档"粘连: normaldx / normalgl / rough4k 里的通道词仍算整词命中
_RE_TRAILING_SIZE = re.compile(r"\d+k?$")

# 通道词后粘连的通用后缀(map/maps): normalmap / diffusemap / roughnessmap 仍算整词
_TRAILING_MAP_SUFFIXES = ("maps", "map")

# 单 token 纯子串兜底的最短别名: 短别名(如 ao)只按整词认, 词内巧合不认(kaolin)
_FALLBACK_MIN_ALIAS_LEN = 3


def _token_end_offsets(compact_token: str) -> set:
    """一个词允许被当作"别名终点"的位置(相对词首): 词尾, 以及剥掉粘连后缀后的位置"""
    offsets = {len(compact_token)}
    for suffix in _NORMAL_DX_WORDS + _NORMAL_GL_WORDS + _TRAILING_MAP_SUFFIXES:
        if compact_token.endswith(suffix) and len(compact_token) > len(suffix):
            offsets.add(len(compact_token) - len(suffix))
    match = _RE_TRAILING_SIZE.search(compact_token)
    if match and match.start() > 0:
        offsets.add(match.start())
    return offsets


def _token_spans(tokens: list) -> tuple:
    """各词在"压掉分隔符后的整名"里的区间 -> (起点集合, 终点集合)"""
    starts, ends = set(), set()
    cursor = 0
    for token in tokens:
        compact_token = compact_name(token)
        starts.add(cursor)
        ends.update(cursor + offset for offset in _token_end_offsets(compact_token))
        cursor += len(compact_token)
    return starts, ends


def match_alias_in_name(name: str) -> tuple:
    """数据块名称里**最靠右**出现的别名 -> (组键, 命中的别名); 未命中返回 (None, "")

    作者定口径: **不分词**, 名称与别名都压掉分隔符后做子串匹配; 命中位置取"最靠右"
    (通道词通常写在名称尾部), 同一结束位置取更长别名(heightmap 优于 height).

    额外的**边界校验**(避免 kaolin 里的 ao 这类巧合命中): 别名的首尾必须落在词边界上,
    即整词或相邻几个整词拼起来——"wood_ao" 命中, "kaolin_plate" 的 ao 不命中.
    整名一个词都没切开时(wooddiffusemap 这类)退回纯子串匹配, 保住那种写法的可用性;
    兜底不认短于 _FALLBACK_MIN_ALIAS_LEN 的别名, 否则 kaolin 里的 ao 会从这条路径复活.
    """
    tokens = _name_tokens(name)
    compact = "".join(compact_name(token) for token in tokens)
    starts, ends = _token_spans(tokens)
    best_alias, best_end = "", -1
    for alias in ALIASES_BY_LENGTH:
        index = compact.rfind(alias)
        while index >= 0:
            end = index + len(alias)
            if index in starts and end in ends:
                if end > best_end or (end == best_end and len(alias) > len(best_alias)):
                    best_alias, best_end = alias, end
                break
            index = compact.rfind(alias, 0, index)
    if not best_alias and len(tokens) <= 1:
        # 没有分隔符的整块名: 退回子串(否则 wooddiffusemap 这类永远认不出); 短别名不参与兜底
        for alias in ALIASES_BY_LENGTH:
            if len(alias) < _FALLBACK_MIN_ALIAS_LEN:
                continue
            index = compact.rfind(alias)
            if index < 0:
                continue
            end = index + len(alias)
            if end > best_end or (end == best_end and len(alias) > len(best_alias)):
                best_alias, best_end = alias, end
    if not best_alias:
        return None, ""
    return ALIAS_TO_GROUP[best_alias].key, best_alias


def normal_direction_in_name(name: str) -> str:
    """按数据块名称判定法线朝向 -> 'DX' / 'GL'(默认 OpenGL, 即不翻转绿通道)

    认 directx/dx/opengl/gl 四个关键字: 先按分隔符切词, **整词或以关键字结尾的词**命中
    (normaldx / normalgl / normaldirectx 这类粘连后缀也认), 从最靠后的词往前找, 先命中者胜
    ——通道词落在尾部, 朝向标记通常也在尾部. 一个词都没切开时退回整串子串判断.
    """
    tokens = _name_tokens(name)
    if len(tokens) <= 1:
        compact = compact_name(name)
        if "directx" in compact or compact.endswith("dx"):
            return "DX"
        return "GL"
    for token in reversed(tokens):
        if token.endswith(_NORMAL_DX_WORDS):
            return "DX"
        if token.endswith(_NORMAL_GL_WORDS):
            return "GL"
    return "GL"


# ---------------------------------------------------------------------------
# 文件名归一化 + 后缀识别
# ---------------------------------------------------------------------------
# 归一化规则: 小写化; 空格/连字符(含 Unicode 破折号)转下划线; 撇号(含弯撇号)删除;
# 压缩连续下划线
_RE_SPACE_OR_DASH = re.compile(r"[ \-\u2010-\u2015]+")
_RE_APOSTROPHE = re.compile(r"['\u2018\u2019\u02bc]")
_RE_MULTI_UNDERSCORE = re.compile(r"_{2,}")


def normalize_name(name: str, collapse_underscores: bool = True) -> str:
    """把单个文件名/目录名归一化为识别口径

    'Multi-Color Stained-Glass_21_Diffuse.JPG' -> 'multi_color_stained_glass_21_diffuse.jpg'
    "Rubik's Cube-90.PNG" -> 'rubiks_cube_90.png'
    """
    out = name.lower()
    out = _RE_SPACE_OR_DASH.sub("_", out)
    out = _RE_APOSTROPHE.sub("", out)
    if collapse_underscores:
        out = _RE_MULTI_UNDERSCORE.sub("_", out)
    # 首尾下划线剥掉(目录名两端有效; 文件名的尾下划线在扩展名之前, 本函数够不到,
    # 由 parse_texture_filename 对 stem 再剥——后缀 endswith 匹配靠它, 探针实证)
    return out.strip("_")


@dataclass(frozen=True)
class ParsedName:
    """文件名解析结果

    Attributes:
        prefix: 包名(去掉通道后缀)
        group_key: 通道组标识; None 表示不认识(缩略图/孤立文件)
        suffix: 实际命中的后缀
        direction: 仅 normal 组: 'DX' / 'GL' / None(裸 _normal 无朝向信息)
        ext: 扩展名(含点, 小写)
        normalized: 归一化后的完整文件名
    """

    prefix: str
    group_key: str | None
    suffix: str
    direction: str | None
    ext: str
    normalized: str


def parse_texture_filename(filename: str) -> ParsedName:
    """从文件名解析 (包名, 通道组, 法线朝向, 扩展名)

    匹配规则(顺序即优先级): 完整后缀最长匹配(含 directx_normal 这类带限定词的写法)
    -> 普通别名归组 -> 未命中返回 group_key=None(调用方按"类型外"处理).
    自身先做归一化, 对未按约定命名的文件同样可用.
    """
    norm = normalize_name(filename)
    stem, dot, ext = norm.rpartition(".")
    if not dot:
        stem, ext = norm, ""
    # 首尾下划线在 stem 上剥(normalize 的 strip 只够到首下划线——尾下划线在扩展名
    # 之前, 对带扩展名的全名 strip 无效): wood_diffuse_.png / _wood_diffuse.png 同样可识别
    stem = stem.strip("_")

    for suf in SUFFIXES_BY_LENGTH:
        if stem.endswith("_" + suf):
            prefix = stem[: -(len(suf) + 1)]
            direction = NORMAL_DIRECTION_TAGS.get(suf)
            group_key = "normal" if direction else ALIAS_TO_GROUP[suf].key
            return ParsedName(prefix, group_key, suf, direction, ext, norm)

    # 无后缀(缩略图/孤立文件)
    return ParsedName(stem, None, "", None, ext, norm)
