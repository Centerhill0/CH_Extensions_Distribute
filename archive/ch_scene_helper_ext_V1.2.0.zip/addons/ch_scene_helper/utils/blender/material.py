"""
场景资源面板材质动作算法模块

提供以下功能:
- MATERIAL_SLOT_TYPES: 可拥有材质槽的物体类型集合
- assign_material: 把材质赋给一组物体的材质槽(追加新槽 / 替换活动槽 / 单物体替换指定槽)
- duplicate_material / delete_material / unlink_material: 材质数据块动作
- material_users: 材质的场景使用者查询
- find_material_slot: 在物体材质槽中查找指定材质的位置
- find_instance_group / unsync_instance_group: 实例组查找与独立化
- focus_material: 材质使用者聚焦(设活动物体并对齐活动槽)

注: 本模块自持一份材质赋值实现(与 ch_utils_tools 的材质拾取器已分叉);
PBR 资产包导入算法见 pbr_material(整树重建, 与本模块的槽位动作互不依赖).
"""

import bpy
from bpy.types import Context, ID, Material, Object, Scene

from .selection import is_selectable

# 可拥有材质槽的物体类型(网格/曲线/文本/曲面/融球)
MATERIAL_SLOT_TYPES = {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}


# ------------------------------------------------------------
# 材质槽动作
# ------------------------------------------------------------


def _has_material(mat: Material, obj: Object) -> bool:
    """物体材质槽中是否已有该材质(按数据块身份比较)"""
    return any(slot.material == mat for slot in obj.material_slots)


def _ensure_unique_data(obj: Object) -> None:
    """新增材质槽前把共享数据块独立化

    槽数量是数据块级属性: 直接 `obj.data.materials.append` 会给所有共享该 mesh 的实例
    一起加槽. 需要只影响当前物体时先复制数据块(与 Blender 的 Make Single User 同语义).
    """
    data = getattr(obj, "data", None)
    if data is not None and data.users > 1:
        obj.data = data.copy()


def _assign_slot_material(mat: Material, obj: Object, slot_idx: int) -> None:
    """写入已有槽位; 共享数据块时把该槽改为物体级链接, 避免改动其它实例

    槽的 link 为 DATA 时材质存放在 mesh 上, 写入会连带所有使用者; 改为 OBJECT 后
    材质由物体自己持有, mesh 上的原材质与兄弟实例保持不变.
    """
    slot = obj.material_slots[slot_idx]
    if slot.link == 'DATA' and obj.data is not None and obj.data.users > 1:
        slot.link = 'OBJECT'
    slot.material = mat


def _assign_to_slot(mat: Material, obj: Object, slot_idx: int) -> None:
    """把材质写到指定槽位; 编号越界时替换末尾槽"""
    slots = obj.material_slots
    idx = min(slot_idx, len(slots) - 1)
    _assign_slot_material(mat, obj, idx)
    obj.active_material_index = idx


def assign_material(mat: Material, objects: list, append: bool = False, slot_index: int | None = None) -> tuple:
    """把材质赋给一组物体的材质槽, 返回 (赋值物体数, 错误信息)

    三种语义(交互层按修饰键选择):
    - 默认: 写到各物体的活动材质槽, 无槽时追加新槽
    - append=True: 追加到槽列表末尾; 物体已持有该材质时只把活动槽切到它
    - slot_index 非 None: 只对首个物体生效, 替换其第 slot_index 个槽(0 起), 越界改替换末尾槽

    仅处理可拥有材质槽的物体类型(见 MATERIAL_SLOT_TYPES), 其它类型静默跳过.

    隔离语义: 实例(Alt+D / 关联复制)共享同一数据块时不改动兄弟实例 —— 替换已有槽
    改走物体级链接, 新增槽前先复制数据块.
    """
    if mat is None:
        return 0, "material is None"
    targets = objects[:1] if slot_index is not None else objects
    count = 0
    for obj in targets:
        if obj.type not in MATERIAL_SLOT_TYPES:
            continue
        if append:
            if _has_material(mat, obj):
                obj.active_material_index = find_material_slot(obj, mat)
            else:
                _ensure_unique_data(obj)
                obj.data.materials.append(mat)
                obj.active_material_index = len(obj.material_slots) - 1
        elif slot_index is not None:
            if not obj.material_slots:
                _ensure_unique_data(obj)
                obj.data.materials.append(mat)
            else:
                _assign_to_slot(mat, obj, slot_index)
        elif not obj.material_slots:
            _ensure_unique_data(obj)
            obj.data.materials.append(mat)
        else:
            _assign_slot_material(mat, obj, obj.active_material_index)
        count += 1
    return count, None


def find_material_slot(obj: Object | None, mat: Material) -> int:
    """在物体材质槽中查找该材质的位置, 找不到返回 -1"""
    if obj is None or mat is None:
        return -1
    for slot_idx, slot in enumerate(obj.material_slots):
        if slot.material == mat:
            return slot_idx
    return -1


def duplicate_material(mat: Material) -> Material | None:
    """复制材质数据块(含节点树), 继承假用户设置; 入参无效返回 None"""
    if mat is None:
        return None
    new_mat = mat.copy()
    new_mat.use_fake_user = mat.use_fake_user
    return new_mat


def delete_material(mat: Material) -> tuple:
    """删除材质数据块(在用材质由 Blender 自动清空其材质槽), 返回 (是否成功, 错误信息)"""
    if mat is None:
        return False, "material is None"
    bpy.data.materials.remove(mat)
    return True, None


def unlink_material(scene: Scene, mat: Material) -> tuple:
    """解除材质与场景物体材质槽的全部关联(不删除数据块), 返回 (清空的槽数, 错误信息)"""
    if mat is None:
        return 0, "material is None"
    count = 0
    for obj in scene.objects:
        for slot in obj.material_slots:
            if slot.material == mat:
                slot.material = None
                count += 1
    return count, None


def material_users(scene: Scene, mat: Material) -> list:
    """场景中把该材质放进了材质槽的全部物体(按场景物体顺序, 天然去重)"""
    if mat is None:
        return []
    return [obj for obj in scene.objects if any(slot.material == mat for slot in obj.material_slots)]


def _has_user_outside(data: ID, sel_objs: list) -> bool:
    """数据块是否还有选中集合之外的使用者物体

    直接扫 bpy.data.objects, 按数据块身份与物体名称判断(名称在物体命名空间内唯一).
    """
    selected_names = {obj.name for obj in sel_objs if obj is not None}
    for obj in bpy.data.objects:
        if obj.data is data and obj.name not in selected_names:
            return True
    return False


def find_instance_group(sel_objs: list) -> dict:
    """找出选中物体里的实例残留, 按数据块分组: {数据块名: [选中物体...]}

    判据只看数据块共享用户数:
    - 共享用户数为 1 不算实例
    - 全部用户都在选中集合里不算实例(独立化没有意义)
    - 数据块还有未选中的用户时才算实例; 同数据块的多个选中物体归成一组
    """
    selected = list(sel_objs)
    groups = {}
    for obj in selected:
        data = obj.data
        if data is None or data.users < 2:
            continue
        if not _has_user_outside(data, selected):
            continue
        groups.setdefault(data.name, []).append(obj)
    return groups


def unsync_instance_group(group_objs: list) -> dict:
    """把一组实例物体独立化: 共用一份新数据块, 同数据块的其余物体保持原样

    Returns:
        {"ok": 是否成功, "data": 新数据块名或 None, "count": 独立化的物体数, "error": 错误信息}
    """
    result = {"ok": False, "data": None, "count": 0, "error": None}
    if not group_objs:
        result["error"] = "no objects"
        return result
    old_data = group_objs[0].data
    if old_data is None:
        result["error"] = "object has no data"
        return result
    try:
        new_data = old_data.copy()
    except (RuntimeError, AttributeError) as e:
        result["error"] = str(e)
        return result
    for obj in group_objs:
        obj.data = new_data
    result["ok"] = True
    result["data"] = new_data.name
    result["count"] = len(group_objs)
    return result


def focus_material(context: Context, mat: Material) -> bool:
    """把该材质的使用者物体设为活动物体并切到对应槽位, 返回是否成功

    着色器编辑器跟随活动物体的活动材质, 故切编辑器只需这两步;
    材质没有场景使用者时不做任何事. 聚焦目标取视图层内的首个使用者:
    使用者全在排除集合里时设活动物体会抛 RuntimeError(见 selection.is_selectable),
    此时同样不做任何事.
    """
    users = material_users(context.scene, mat)
    first_obj = next((obj for obj in users if is_selectable(context, obj)), None)
    if first_obj is None:
        return False
    context.view_layer.objects.active = first_obj
    for idx, slot in enumerate(first_obj.material_slots):
        if slot.material == mat:
            first_obj.active_material_index = idx
            break
    return True
