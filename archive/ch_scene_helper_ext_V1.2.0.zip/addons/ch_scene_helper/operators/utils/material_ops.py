"""
材质面板算子模块

提供以下功能:
- MaterialAssign: 把面板活动材质赋给选中物体(+Ctrl 追加 / +Alt 替换指定槽)
- MaterialActivateToggle: 行首激活按钮(默认独占, +Shift 加选/减选), 场景物体选中随激活联动
- MaterialMerge: 行内"合并材质"按钮(激活材质的全部使用者引用替换为本行材质, 源材质删除)
- MaterialDuplicate: 复制面板活动材质并赋给选中物体(列表高亮切到副本)
- MaterialDelete: 解除面板活动材质的关联(默认), Shift 点击删除材质数据块
- MaterialNew: 新建材质并赋给活动物体
- PassIndexBatch: 场景材质 pass index 批量设置

注: "面板活动材质"指材质列表活跃索引对应的数据块(按 src_name 真实名检索),
即材质赋值的目标, 与"活动物体自身的活动材质槽"无关.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from .....common.blender.list_order import assign_order_at_end
from ... import handlers
from ...preference import online_manifest_library, resolve_library_root
from ...scene_state import active_block, all_blocks_for, blocks_for, get_state, highlight_item, resolve_id, stored_pick_key
from ...utils import (
    rebuild_channels,
    scan_material,
    MATERIAL_SLOT_TYPES,
    assign_material,
    collect_scene_material_blocks,
    delete_material,
    duplicate_material,
    existing_source,
    find_instance_group,
    focus_material,
    import_pbr_pack,
    list_assets,
    list_categories,
    material_users,
    real_user_count,
    resolve_category,
    resolve_option,
    unlink_material,
    unsync_instance_group,
)
from ._base import PanelMaterialMixin, TranslatedDescriptionMixin, deletion_guard

# 提示之间在状态栏的合并分隔符(多条 report 会互相覆盖, 故合并成一条)
_NOTE_SEP = " | "


def resolve_material_block(name: str, linked: bool):
    """按名称 + 库链接标记取材质数据块(同名本地/链接对消歧), 都不匹配返回 None

    复制链接材质会产生同名本地副本, 而 bpy.data 按名查找恒命中本地块, 行内算子
    必须按行标记消歧(机制见 scene_state.resolve_named).
    """
    return resolve_id('MATERIAL', name, bool(linked))


class MaterialAssign(PanelMaterialMixin, TranslatedDescriptionMixin, Operator):
    """把面板活动材质赋给选中物体(直接点击替换活动槽 / +Ctrl 追加 / +Alt 替换指定槽)

    要求: 物体模式; 有选中物体; 面板材质列表有活跃项; +Alt 时恰好选中一个物体
    """

    bl_idname = "ch.material_assign"
    bl_label = "Apply Material"
    bl_description = "Assign the active material of the Materials panel to all selected objects\n+Ctrl: Append to the material slots instead of replacing the active one\n+Alt: Replace the slot of the given index (single selected object only, out of range replaces the last slot)"
    bl_options = {'REGISTER', 'UNDO'}

    # SKIP_SAVE: 槽号不得进"上次算子属性"复用——否则 +Alt 弹窗用过非 0 槽号后,
    # 无修饰键点击会因槽号残留误入替换指定槽分支
    slot_index: IntProperty(name="Slot Index", description="Material slot index to replace (0-based, out of range replaces the last slot)", default=0, min=0, options={'SKIP_SAVE'})  # type: ignore
    append: BoolProperty(name="Append", description="Append the material to the object material slots instead of replacing the active one", default=False)  # type: ignore
    # invoke 中按 Alt 置位; 存 RNA 供 Redo 沿用同一分支(F9 面板不显示)
    replace_slot: BoolProperty(name="Replace Slot", default=False, options={'HIDDEN'})  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.append = bool(event is not None and event.ctrl)
        self.replace_slot = bool(event is not None and event.alt)
        if self.replace_slot:
            return self._invoke_slot_dialog(context)
        return self.execute(context)

    def draw(self, context: Context):
        self.layout.use_property_split = True
        self.layout.prop(self, "slot_index")

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        sel_objs = context.selected_objects
        if self.append:
            count, _err = assign_material(mat, sel_objs, append=True)
            if count == 0:
                self.report({'WARNING'}, report("No objects can hold the material"))
                return {'CANCELLED'}
            self.report({'INFO'}, report("Material appended: {} objects").format(count))
            return {'FINISHED'}
        if self._is_slot_assign():
            return self._execute_slot_assign(context, mat, sel_objs)
        count, _err = assign_material(mat, sel_objs)
        if count == 0:
            self.report({'WARNING'}, report("No objects can hold the material"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Material assigned: {} objects").format(count))
        return {'FINISHED'}

    def _is_slot_assign(self) -> bool:
        """是否走"替换指定槽"分支: invoke 按过 Alt, 或用户在 F9 面板把编号改成非 0"""
        return self.replace_slot or self.slot_index > 0

    def _invoke_slot_dialog(self, context: Context):
        """+Alt 入口: 校验单物体后弹出 F9 面板, 确认才执行"""
        sel_objs = context.selected_objects
        if len(sel_objs) != 1:
            self.report({'WARNING'}, report("Slot assign requires exactly one selected object"))
            return {'CANCELLED'}
        act_obj = sel_objs[0]
        if act_obj.type not in MATERIAL_SLOT_TYPES:
            self.report({'WARNING'}, report("Object has no material slots"))
            return {'CANCELLED'}
        self.slot_index = act_obj.active_material_index
        return context.window_manager.invoke_props_dialog(self, width=320)

    def _execute_slot_assign(self, context: Context, mat, sel_objs: list):
        """替换单物体的指定槽(编号越界由 utils.assign_material 落到末尾槽)"""
        if not sel_objs:
            self.report({'WARNING'}, report("Slot assign requires exactly one selected object"))
            return {'CANCELLED'}
        obj = sel_objs[0]
        count, _err = assign_material(mat, [obj], slot_index=self.slot_index)
        if count == 0:
            self.report({'WARNING'}, report("Object has no material slots"))
            return {'CANCELLED'}
        slot_count = len(obj.material_slots)
        idx = min(self.slot_index, slot_count - 1)
        if self.slot_index >= slot_count:
            self.report({'INFO'}, report("Slot index out of range, replaced the last slot: {}").format(idx))
        else:
            self.report({'INFO'}, report("Material replaced at slot: {}").format(idx))
        return {'FINISHED'}


class MaterialActivateToggle(Operator):
    """激活材质(默认独占, +Shift 加选/减选)

    激活的材质决定场景选中: 选中集 = 全部激活材质使用者的并集(整体重建);
    最后点击加选的材质项为面板活动材质, 减选活动材质时活动/高亮跳回上一个激活项.
    """

    bl_idname = "ch.material_activate_toggle"
    bl_label = "Activate Material"
    bl_description = "Activate this material and select its users in the scene (deactivates the others)\n+Shift: Toggle this material without touching the others (users are selected/deselected accordingly)"
    bl_options = {'REGISTER', 'UNDO'}

    mat_name: StringProperty(name="Material", options={'HIDDEN'})  # type: ignore
    mat_linked: BoolProperty(name="Linked", description="Whether the material is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore
    extend: BoolProperty(name="Extend", description="Toggle this material without touching the others", default=False, options={'HIDDEN'})  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.extend = bool(event is not None and event.shift)
        return self.execute(context)

    def execute(self, context: Context):
        mat = resolve_material_block(self.mat_name, self.mat_linked)
        if mat is None:
            self.report({'WARNING'}, report("Material not found"))
            return {'CANCELLED'}
        if self.extend:
            mat.ch_material_active = not mat.ch_material_active
        else:
            for other in bpy.data.materials:
                if other is not mat and other.ch_material_active:
                    other.ch_material_active = False
            mat.ch_material_active = True
        # 场景选中按激活集使用者的并集整体重建(作者定: 物体选中跟随材质激活状态)
        self._sync_scene_selection(context)
        highlight_item(context, "materials", mat.name)
        if mat.ch_material_active:
            # 最后激活的材质设为活动材质: 活动物体活动槽指向 + 着色器编辑器跟随
            focus_material(context, mat)
        elif active_block(context, "materials") is mat:
            # 减选的正是活动材质: 活动/高亮跳回列表序中前一个仍激活的材质
            self._jump_back(context, mat)
        return {'FINISHED'}

    def _sync_scene_selection(self, context: Context) -> None:
        """场景选中 := 全部激活材质使用者的并集(每次整体重建, 不逐个增减)

        并集语义: 物体同时是多个激活材质的使用者时, 减选其一仍保持选中
        (只要还有其它激活材质覆盖它) —— 这是"选中跟随激活集"模型的固有行为.
        只迭代视图层内物体: 排除集合里的物体 select_set 会抛 RuntimeError(见
        utils/blender/selection.py 的 is_selectable), 且它们本就不可选中.
        """
        selected = set()
        for other in bpy.data.materials:
            if other.ch_material_active:
                for obj in material_users(context.scene, other):
                    selected.add(obj.name)
        for obj in context.view_layer.objects:
            obj.select_set(obj.name in selected)

    def _jump_back(self, context: Context, mat) -> None:
        """减选的是活动材质: 活动/高亮跳回列表序中最近的仍激活材质

        优先取前一个, 前方没有则取后方最近的(否则减选列表首个激活项时无目标,
        高亮会留在已减选行); 没有剩余激活项则维持原行.
        """
        prev = None
        after = None
        passed = False
        for block in blocks_for(context, "materials"):
            if block is None:
                continue
            if block is mat:
                passed = True
                continue
            if not block.ch_material_active:
                continue
            if not passed:
                prev = block
            elif after is None:
                after = block
        target = prev if prev is not None else after
        if target is not None:
            highlight_item(context, "materials", target.name)
            focus_material(context, target)


class MaterialMerge(Operator):
    """合并材质: 把激活的材质全部替换为本行材质

    全部使用者引用改链到本行材质(user_remap 文件级替换, 含节点树等引用); 本地源材质
    随之删除, 库链接源材质不可删,只改链其使用者(数据块保留); 设计目的是合并相似材质,
    而非把材质赋予物体.
    """

    bl_idname = "ch.material_merge"
    bl_label = "Merge Materials"
    bl_description = "Replace all activated materials with this row's material: every user reference is re-linked and local source materials are removed (linked sources are kept, only their users are re-linked)"
    bl_options = {'REGISTER', 'UNDO'}

    mat_name: StringProperty(name="Material", options={'HIDDEN'})  # type: ignore
    mat_linked: BoolProperty(name="Linked", description="Whether the target material is linked from a library (disambiguates same-named local/linked pairs)", default=False, options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        target = resolve_material_block(self.mat_name, self.mat_linked)
        if target is None:
            self.report({'WARNING'}, report("Material not found"))
            return {'CANCELLED'}
        sources = [m for m in bpy.data.materials if m.ch_material_active and m is not target]
        if not sources:
            self.report({'INFO'}, report("No activated materials to merge"))
            return {'CANCELLED'}
        linked_kept = 0
        for source in sources:
            source.user_remap(target)
            if source.library is None:
                bpy.data.materials.remove(source)
            else:
                # 库链接源不可删(数据块来自库, 实测 5.1.2 的 remove 也会把链接块从会话摘除):
                # 只改链使用者, 数据块随零用户规则在重载后不再载入
                linked_kept += 1
        if linked_kept:
            self.report({'INFO'}, report("Linked source kept, its users were re-linked to the target"))
        handlers.refresh_lists()
        highlight_item(context, "materials", target.name)
        return {'FINISHED'}


class MaterialDuplicate(PanelMaterialMixin, TranslatedDescriptionMixin, Operator):
    """复制面板活动材质并赋给选中物体, 列表高亮切到新副本

    +Alt: 先把选中的实例物体独立化, 再复制材质; 没有实例时只提示,
    行为与直接点击一致.
    """

    bl_idname = "ch.material_duplicate"
    bl_label = "Duplicate Material"
    bl_description = "Duplicate the active material of the Materials panel and assign it to all selected objects\n+Alt: Make the selected instanced objects independent (shared meshes become one unified instance) before duplicating; without instances only a notice is shown"
    bl_options = {'REGISTER', 'UNDO'}

    # invoke 中按 Alt 置位; 存 RNA 供 Redo 沿用同一分支(F9 面板不显示)
    unsync_instances: BoolProperty(name="Unsync Instances", default=False, options={'HIDDEN'})  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.unsync_instances = bool(event is not None and event.alt)
        return self.execute(context)

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        notes = []
        if self.unsync_instances:
            notes.extend(self._unsync_selected(context))
        new_mat = duplicate_material(mat)
        if new_mat is None:
            self.report({'ERROR'}, report("Material not found"))
            return {'CANCELLED'}
        count, _err = assign_material(new_mat, context.selected_objects)
        # 写自定义属性与新建数据块均不触发 depsgraph, 主动重建快照后才有副本条目可高亮
        handlers.refresh_lists()
        highlight_item(context, "materials", new_mat.name)
        notes.append(report("Material duplicated and assigned: {}").format(new_mat.name))
        if count == 0:
            notes.append(report("No objects selected, the copy has no users"))
        self.report({'INFO'}, _NOTE_SEP.join(notes))
        return {'FINISHED'}

    def _unsync_selected(self, context: Context) -> list:
        """+Alt 的第一步: 把选中的实例组独立化, 返回需要汇报的提示行(不直接 report)"""
        groups = find_instance_group(context.selected_objects)
        if not groups:
            return [report("No instanced objects to make independent")]
        notes = []
        done = 0
        for data_name, group_objs in groups.items():
            result = unsync_instance_group(group_objs)
            if not result["ok"]:
                notes.append(report("Failed to make instance independent: {}").format(data_name))
                continue
            done += result["count"]
        if done > 0:
            notes.append(report("Instances made independent: {} objects").format(done))
        return notes


class MaterialDelete(PanelMaterialMixin, Operator):
    """解除材质关联或删除材质数据块

    默认解除面板活动材质与全部物体的材质槽关联(保留数据块, Ctrl+Z 可撤销);
    Shift 点击才真正删除材质数据块(在用材质由 Blender 自动清空其材质槽).
    """

    bl_idname = "ch.material_delete"
    bl_label = "Unlink Material"
    bl_description = "Unlink the active material from all objects\n+Shift: Delete the material data-block directly"
    bl_options = {'REGISTER', 'UNDO'}

    require_object_mode = False

    delete: BoolProperty(name="Delete", description="Delete the material data-block instead of only unlinking it", default=False)  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        # Shift 点击 = 删除数据块; invoke 直调(event 为 None)时保持默认的解除关联
        self.delete = bool(event is not None and event.shift)
        if self.delete:
            mat = self.require_panel_material(context)
            if mat is None:
                return {'CANCELLED'}
            blocked = deletion_guard(
                self,
                context,
                event,
                mat,
                linked_msg="Linked material cannot be deleted",
                users_msg="Material is used by {} users, deleting it clears them",
            )
            if blocked is not None:
                return blocked
        return self.execute(context)

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        if self.delete:
            # 直调绕过 invoke: 未确认且仍在用时拒绝删除, 避免静默清空全场景材质槽
            if mat.library is not None:
                self.report({'ERROR'}, report("Linked material cannot be deleted"))
                return {'CANCELLED'}
            users = real_user_count(mat)
            if users > 0 and not self.confirmed:
                self.report({'WARNING'}, report("Material is used by {} users, deleting it clears them").format(users))
                return {'CANCELLED'}
            ok, _err = delete_material(mat)
            if not ok:
                self.report({'ERROR'}, report("Material not found"))
                return {'CANCELLED'}
            handlers.refresh_lists()
            return {'FINISHED'}
        count, _err = unlink_material(context.scene, mat)
        if count == 0:
            self.report({'INFO'}, report("Material not linked to any object"))
            return {'CANCELLED'}
        # 用户数变化与"场景在用"口径相关, 与世界/图像删除路径同口径主动重建
        handlers.refresh_lists()
        self.report({'INFO'}, report("Material unlinked from {} slots").format(count))
        return {'FINISHED'}


class MaterialNew(Operator):
    """新建材质并赋给活动物体(无可持有材质的活动物体时保留为 0 用户材质)"""

    bl_idname = "ch.material_new"
    bl_label = "Add Material"
    bl_description = "Create a new material and assign it to the active object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        # 新建材质自动带默认节点树(5.1 实测, use_nodes 已弃用为 no-op)
        mat = bpy.data.materials.new("Material")
        obj = context.view_layer.objects.active
        # 追加走 assign_material 的隔离语义: 共享数据块(实例)先独立化再加槽, 不波及兄弟实例
        count, _err = assign_material(mat, [obj], append=True) if obj is not None else (0, None)
        # 新建项默认追加到列表末尾(不按名称插入无顺序值组)
        assign_order_at_end(mat, all_blocks_for(context, "materials"))
        # 新材质挂到活动物体上后应立刻出现在快照里(材质列表只列场景在用材质)
        handlers.refresh_lists()
        highlight_item(context, "materials", mat.name)
        if not count:
            self.report({'INFO'}, report("Material created without users"))
        return {'FINISHED'}


class PassIndexBatch(Operator):
    """场景材质的 pass index 批量设置"""

    bl_idname = "ch.pass_index_batch"
    bl_label = "Batch Pass Index"
    bl_description = "Set the pass index of all materials used in the scene in one go"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        name="Mode",
        items=(
            ("SEQUENTIAL", "Sequential", "Assign increasing values"),
            ("FIXED", "Fixed", "Assign the same value to every material"),
        ),
        default=0,
        description="How the pass indices are assigned",
    )  # type: ignore
    start: IntProperty(name="Start", default=1, min=0, description="Value assigned to the first material")  # type: ignore
    fixed_value: IntProperty(name="Value", default=0, min=0, description="Value assigned to every material")  # type: ignore
    skip_assigned: BoolProperty(name="Skip Assigned", default=True, description="Leave materials with a non-zero pass index untouched")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "mode", expand=True)
        if self.mode == 'FIXED':
            layout.prop(self, "fixed_value")
        else:
            layout.prop(self, "start")
            layout.prop(self, "skip_assigned")

    def execute(self, context: Context):
        materials = collect_scene_material_blocks(context.scene)
        if self.mode == 'FIXED':
            for mat in materials:
                mat.pass_index = self.fixed_value
            self.report({'INFO'}, report("Pass index set: {} materials").format(len(materials)))
            return {'FINISHED'}
        count = 0
        for mat in materials:
            if self.skip_assigned and mat.pass_index:
                continue
            mat.pass_index = self.start + count
            count += 1
        self.report({'INFO'}, report("Pass index set: {} materials").format(count))
        return {'FINISHED'}


def _initialize_message(result: dict, scan: dict) -> str:
    """初始化 PBR 材质的汇报文案: 已建链 + 缺基础色剔除数 + 同通道未采用的图名

    Args:
        result: rebuild_channels 的返回(取 built)
        scan: scan_material 的返回(取 dropped / duplicates)
    Returns:
        以 " · " 分段的信息串(各段自身已翻译)
    """
    parts = [report("PBR chains rebuilt: {}").format("、".join(result["built"]))]
    if scan["dropped"]:
        parts.append(report("Skipped {} images without a base color to pair with").format(len(scan["dropped"])))
    if scan["duplicates"]:
        parts.append(report("Duplicates not used: {}").format("、".join(scan["duplicates"])))
    return " · ".join(parts)


class PBRMaterialInitialize(PanelMaterialMixin, Operator):
    """初始化 PBR 材质: 把普通 PBR 材质按模板整树重建(按图像数据块名称识别通道)

    扫全树的图像纹理节点, 按数据块名称识别通道(不看文件路径与后缀, 不分词), 命中多少建多少;
    整树重建(含 Frame 等布局节点与原自定义拓扑)会清空后照模板重建, 故重建后即可由 PBR 参数区
    接管. 输出没连线的图也按名称纳入(同通道内已连线的优先). 恒可点——识别不到时只提示, 材质保持原状.
    """

    bl_idname = "ch.pbr_material_initialize"
    bl_label = "Initialize PBR Material"
    bl_description = "Rebuild the active material with the PBR_Universal template using every image texture node of its node tree (classified by image data-block name); the whole node tree is replaced"
    bl_options = {'REGISTER', 'UNDO'}

    # 只改材质节点树, 与物体模式无关(编辑/雕刻模式下也该可点)
    require_object_mode = False

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        if mat.library is not None:
            self.report({'WARNING'}, report("Linked material data is read-only"))
            return {'CANCELLED'}
        if mat.node_tree is None:
            self.report({'WARNING'}, report("This material has no node tree"))
            return {'CANCELLED'}
        scan = scan_material(mat)
        if not scan["channels"]:
            self.report({'WARNING'}, report("No PBR texture recognized in this material"))
            return {'CANCELLED'}
        result = rebuild_channels(mat, scan["channels"], scan["displacement"], scan["normal_direction"])
        if not result["ok"]:
            message = {
                'linked': "Linked material data is read-only",
                'no_tree': "This material has no node tree",
                'failed': "Failed to rebuild the material node tree",
            }.get(result["error"], "No PBR texture recognized in this material")
            self.report({'WARNING'}, report(message))
            return {'CANCELLED'}
        self.report({'INFO'}, _initialize_message(result, scan))
        return {'FINISHED'}


class PBRImportPack(PanelMaterialMixin, Operator):
    """导入 PBR 资产包: 面板活动材质按 PBR_Universal 模板整树重建

    资产包 = 偏好里用途为 PBR 材质的库中, 分类顶层与缩略图同名的目录; 包内贴图按文件名
    后缀识别通道, 按需建链(roughness 与 glossiness 同在取 roughness, normal 与 bump
    同在取 normal). 整树重建会清空该材质原节点树(Ctrl+Z 可回), 贴图按外部路径引用.
    """

    bl_idname = "ch.pbr_import_pack"
    bl_label = "Import Pack"
    bl_description = "Rebuild the active material with the PBR_Universal node template and the picked texture pack (replaces the whole node tree, textures are referenced from the asset library)"
    bl_options = {'REGISTER', 'UNDO'}

    # 与选择器家族同款的种类载荷(名称行右侧钮统一透传): 本算子只服务 PBR 档, 恒定值
    pick_kind: StringProperty(name="Kind", description="Asset kind", default="PBR", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    def execute(self, context: Context):
        mat = self.require_panel_material(context)
        if mat is None:
            return {'CANCELLED'}
        if mat.library is not None:
            self.report({'WARNING'}, report("Linked material data is read-only"))
            return {'CANCELLED'}
        state = get_state(context)
        online = online_manifest_library('PBR', state.adv_pbr_library)
        root = resolve_library_root('PBR', state.adv_pbr_library)[0]
        if not root:
            self.report({'WARNING'}, report("Add an asset library in the addon preferences"))
            return {'CANCELLED'}
        categories = list_categories(root, online, 'PBR')
        if not categories:
            self.report({'WARNING'}, report("No category folders in this asset library"))
            return {'CANCELLED'}
        category = resolve_category(categories, state.adv_pbr_category)
        assets = list_assets(root, category, 'PBR', state.adv_hide_missing_source, online)
        if not assets:
            # 先按空集早退再读动态枚举存值: 空集读存值会打 C 层 "matches no enum" 告警
            self.report({'WARNING'}, report("No thumbnails in this category"))
            return {'CANCELLED'}
        key = stored_pick_key(state, "adv_pbr_pick", assets)
        asset = next((a for a in assets if a["key"] == key), None)
        if asset is None:
            self.report({'WARNING'}, report("The picked asset is no longer available"))
            return {'CANCELLED'}
        # 在线库: 包目录 = 当前分辨率/格式的贴图子目录(未下载则只有缩略图, 无可导入内容);
        # 法线朝向按索引声明透传(cgbookcase 包内文件名不带朝向后缀)
        if online:
            option = resolve_option(asset, state.adv_pbr_resolution, state.adv_pbr_format)
            source = existing_source(root, asset, option) if option is not None else ""
            if not source:
                self.report({'WARNING'}, report("This texture set is not downloaded yet"))
                return {'CANCELLED'}
            convention = asset.get("normal_convention", "")
        else:
            source = asset["source"]
            if not source:
                self.report({'WARNING'}, report("This pack has no texture files"))
                return {'CANCELLED'}
            convention = ""
        result = import_pbr_pack(mat, source, convention)
        if not result["ok"]:
            # 三条拒绝路径都不动材质: no_textures = 后缀全部未命中(空包/纯外文件包);
            # load_failed = 识别成功但贴图全部载图失败(含 AO 无基础色配对剔除后落空);
            # no_tree = 材质无节点树(理论路径, 5.3 材质恒有树)
            if result["error"] == "load_failed":
                self.report({'WARNING'}, report("No textures could be loaded from this pack"))
            elif result["error"] == "no_tree":
                self.report({'WARNING'}, report("This material has no node tree"))
            else:
                self.report({'WARNING'}, report("No recognized PBR textures in this pack"))
            return {'CANCELLED'}
        notes = [report("PBR pack imported: {}").format("、".join(result["imported"]))]
        if result["unrecognized"]:
            notes.append(report("Skipped {} unrecognized files").format(len(result["unrecognized"])))
        if result["failed"]:
            notes.append(report("Skipped textures: {}").format("、".join(result["failed"])))
        self.report({'INFO'}, _NOTE_SEP.join(notes))
        return {'FINISHED'}
