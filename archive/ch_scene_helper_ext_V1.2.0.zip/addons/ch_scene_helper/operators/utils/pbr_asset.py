"""
PBR 材质在线资产操作器模块

在线 PBR 材质库(库根带 manifest.json 索引)的下载入口: 分辨率/格式下拉, 规格选定,
按当前缩略图与规格下载资产包并把整包贴图解到 <包目录>/<分辨率>/, 以及取消进行中的下载.
绘制与执行逻辑在 operators/utils/asset_online(与世界环境 HDRI 档共用一套实现), 本模块只
声明标识与载荷. 贴图导入材质不在此模块——由缩略图名称行右侧的"导入资产包"钮完成.

提供以下功能:
- PBRMaterialResolutionMenu / PBRMaterialFormatMenu: 下载规格下拉(图标标识该组合是否已下载)
- PBRMaterialOptionSet: 把选定的分辨率/格式写进面板状态
- PBRMaterialDownload: 按当前选择下载并解压到资产库(8K 起先弹确认)
- PBRMaterialDownloadCancel: 取消该规格进行中的下载
"""

from bpy.props import StringProperty
from bpy.types import Menu, Operator

from .asset_online import OnlineCancelMixin, OnlineDownloadMixin, OnlineFormatMixin, OnlineOptionSetMixin, OnlineResolutionMixin

# 本档规格设定算子的标识(菜单项创建算子时引用, 与下方类声明同源)
_OPTION_SET = "ch.pbr_material_option_set"


class PBRMaterialResolutionMenu(OnlineResolutionMixin, Menu):
    """材质下载行的分辨率下拉(各档解到独立的 <包目录>/<分辨率>/ 子包)"""

    bl_idname = "CH_MT_pbr_material_resolution"
    bl_label = "Resolution"
    pick_kind = 'PBR'
    option_set = _OPTION_SET


class PBRMaterialFormatMenu(OnlineFormatMixin, Menu):
    """材质下载行的格式下拉(ambientCG 提供 JPG/PNG; cgbookcase 仅 PNG)"""

    bl_idname = "CH_MT_pbr_material_format"
    bl_label = "Format"
    pick_kind = 'PBR'
    option_set = _OPTION_SET


class PBRMaterialOptionSet(OnlineOptionSetMixin, Operator):
    """下载规格选定: 写面板状态里的分辨率或格式(空/失效由解析回落, 无需校验取值)"""

    bl_idname = _OPTION_SET
    bl_label = "Set Download Option"
    bl_description = "Use this resolution or format for the material download"

    pick_kind = 'PBR'

    field: StringProperty(name="Field", default="RESOLUTION", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    value: StringProperty(name="Value", default="", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore


class PBRMaterialDownload(OnlineDownloadMixin, Operator):
    """材质下载: 按当前缩略图与规格下载资产包并解压出整包贴图

    仅在线库可用; 8K 及以上的大档先弹确认(材质包 8K 可达 GB 级, 误点代价高).
    解压目标是 <包目录>/<分辨率>/, 同分辨率换格式重下时清掉上一套贴图; 下载包保留.
    全局单任务由下载模块保证(任务进行中面板已把其余下载钮置灰).
    """

    bl_idname = "ch.pbr_material_download"
    bl_label = "Download"
    bl_description = "Download the selected material at the chosen resolution and extract its textures into the asset library (the archive is kept)"

    pick_kind = 'PBR'


class PBRMaterialDownloadCancel(OnlineCancelMixin, Operator):
    """取消下载: 置当前任务取消位(全局单任务, 面板切了规格也能取消), 未完成文件由下载模块清理"""

    bl_idname = "ch.pbr_material_download_cancel"
    bl_label = "Cancel Download"
    bl_description = "Cancel the running material download and remove the incomplete file"
