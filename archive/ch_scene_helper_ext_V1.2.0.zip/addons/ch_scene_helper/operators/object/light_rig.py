"""灯光控制器 rig 操作器模块

"空物体控制器(父级) + 灯光"rig 的全套交互:
- LightAdd: 添加灯光(默认控制器落活动物体; +Shift 弹类型菜单, +Ctrl 游标, +Alt 原点)
- LightCopy / LightInstanceCopy: 复制灯光(数据独立副本) / 实例复制(共享灯光数据)
- LightControllerSet: 给灯光设置控制器(无控制器则绑定, 已有则挪位重设)
- LightRigParamsReset: 把灯光 rig 的四参数(方位/高度/距离/自旋转)恢复默认值
- LightControllerRemove: 摘除灯光的控制器
- LightRigAdjust: L 键模态, 调灯光方位/自旋转/距离/功率与控制器吸附对齐

操作流程:
- 面板按钮族(复制/实例/设置控制器/摘控制器/重置参数)作用于灯光面板的活跃灯光行;
- 灯光饼菜单(Alt+L)复用同一批算子, 对选中集筛选出的灯光批量起作用(隐藏属性
  use_selection_batch, 六钮置 True): 面板单灯与饼菜单批量是两套口径, 由入口显式声明;
  批量目标 = 选中集里的灯光(控制器空体映射到其灯), 除设置控制器外只取带控制器的灯;
- 模态算子按"选到灯光或控制器或二者都选中"解析 rig, 从任一侧进入都能操作整套;
- 模态 A 档与 D 档在 3D 视图叠加轨迹预览(方位圆环 + 高度大圆 + 半径连线 + 刻度圆点),
  透明度按到灯光的距离衰减(灯处不透明, 最远处降到偏好"轨迹线暗淡"), 线宽/刻度/遮挡与开关读偏好, 只画不改数据;
- rig 硬性约束: 一个控制器只挂一个灯光子级.

快捷键:
- L: LightRigAdjust(仅物体模式, 选区里有 rig; 键位见 keymaps.py 的 LIGHT_RIG 组)
- 添加灯光修饰键: 默认控制器落活动物体 / +Shift 类型菜单(可叠加 +Ctrl 游标 +Alt 原点) / +Ctrl 游标 / +Alt 原点
- 设置控制器修饰键: 默认落点为选中集最后一个合格物体 / +Ctrl 游标 / +Alt 原点
"""

import bpy
from math import degrees

from mathutils import Matrix, Vector
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Context, Event, Object, Operator

from .....common.i18n.i18n import iface, iface_ctx, report
from ...handlers import refresh_lists, set_sync_suppressed
from ...modal_base import ModalOperatorMixin, draw_status_item, force_statusbar_redraw, force_ui_update, ignore_events, navigation_passthrough
from ...scene_state import highlight_item, panel_light
from ...utils import (
    add_controller,
    align_controller_y,
    collect_light_blocks,
    copy_light_rig,
    create_light_rig,
    draw_discs,
    draw_polyline,
    fade_alpha_by_distance,
    filter_batch_lights,
    get_controller_azimuth,
    get_controller_elevation,
    get_light_distance,
    get_light_self_rotation,
    is_selectable,
    raycast_surface,
    reflection_direction,
    remove_controller,
    reset_controller,
    reset_light_self_rotation,
    resolve_rig,
    rig_controller_of,
    rig_init_distance,
    rig_light_of,
    rig_trajectory,
    rig_trajectory_ticks,
    select_only,
    set_controller_azimuth,
    set_controller_elevation,
    set_light_distance,
    set_light_self_rotation,
)
from ..utils._base import TranslatedDescriptionMixin, SelectionBatchMixin, append_skip_notes, batch_report
from ...constants import AXIS_TICK_COLORS
from ...preference import get_prefs
from ...utils._constants import RIG_DEFAULT_ELEVATION

# 模态的调节模式键(A 为基础档; S/D/W 为按住式, 松开回落到 A)
_AXIS_KEYS = ('A', 'S', 'D', 'W')

# 按住式调节键: 按住期间生效, 松开即回基础档 A
_HOLD_KEYS = ('S', 'D', 'W')

# 显示轨迹预览的档位: 方位/高度(A)与距离(D)共用同一条球面轨迹, 两档都显示
_PREVIEW_AXES = ('A', 'D')

# 半径连线透明度: 只作提示, 压过背景但不遮模型; 刻度圆点是实心参考点, 用不透明
_PREVIEW_SPOKE_ALPHA = 0.8
_TICK_ALPHA = 1.0
# 正轴刻度直径恒为普通刻度的 1.5 倍; 普通刻度直径 = 轨迹线宽 x 偏好"刻度系数"
# (刻度显示厚度的单一来源在偏好, 算子侧不再持有倍率常量)
_AXIS_TICK_SCALE = 1.5


def _draw_rig_status(op):
    """模态状态栏: 组合键提示, 绘制风格对齐 chamfer.py 的 ChamferToFillet——
    不画算子标题, 导航三键后跟 A/S/D/W 模式键, 再 Shift/Ctrl/Alt
    """

    def draw(self, context: Context):
        row = self.layout.row(align=True)
        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")
        draw_status_item(row, key='A', text="Azimuth/Elevation", gap=1)
        draw_status_item(row, key='S', text="Brightness")
        draw_status_item(row, key='D', text="Distance")
        draw_status_item(row, key='W', text="Self Rotation")
        draw_status_item(row, key='SHIFT', text="Precise", gap=1)
        draw_status_item(row, key='CTRL', text="Snap Normal")
        draw_status_item(row, key='ALT', text="Snap Reflect")

    return draw


def _preview_projection(op) -> tuple:
    """绘制期取当前 3D 视图的投影来源(区域 + RegionView3D), 供像素级圆点换算

    绘制回调里没有可信的 bpy.context: 先按当前上下文取, 取不到再回落到模态所在区域
    自身的 WINDOW 区域(圆点直径只与视图尺寸/朝向有关, 与画布无关). 两者都不可得返回
    (None, None), 由绘制层跳过圆点——宁可不画也不画错位置.
    """
    context = bpy.context
    region = getattr(context, 'region', None)
    region_data = getattr(context, 'region_data', None)
    if region is not None and region_data is not None:
        return region, region_data
    area = getattr(op, 'area', None)
    if area is not None:
        for area_region in area.regions:
            if area_region.type == 'WINDOW':
                return area_region, area_region.data
    return None, None


def _viewport_light(context: Context):
    """视口活动物体是灯光时返回它, 否则 None"""
    active = context.view_layer.objects.active
    return active if active is not None and active.type == 'LIGHT' else None


def _landing_at_active(context: Context, exclude_controllers: bool) -> Vector | None:
    """默认落点取活动物体; exclude_controllers 时灯光控制器空体也不合格(设置控制器防自撞)"""
    active = context.view_layer.objects.active
    if active is None or active.type == 'LIGHT':
        return None
    if exclude_controllers and rig_light_of(active) is not None:
        return None
    return active.matrix_world.translation.copy()


def _landing_from_selection(context: Context) -> Vector | None:
    """面板默认落点: 活动物体优先, 否则选中集(视图层序)最后一个非灯光且非灯光控制器物体

    "最后选中"在 Blender 里没有可靠的选择历史序, 活动物体是唯一可靠的最后信号,
    故活动物体合格即取它, 其余情形按 selected_objects 返回序取末位.
    """
    candidates = [obj for obj in context.selected_objects if obj.type != 'LIGHT' and rig_light_of(obj) is None]
    if not candidates:
        return None
    active = context.view_layer.objects.active
    if active is not None and active in candidates:
        return active.matrix_world.translation.copy()
    return candidates[-1].matrix_world.translation.copy()


def _candidate_lights(context: Context) -> list:
    """按钮可用性判定用的目标候选: 视口活动灯 + 面板活跃灯(去重, 不含 None)

    poll 在 UI 绘制期执行, 拿不到入口标记(那是 UI 按钮带上,invoke 才生效的属性), 故
    按候选集判"按钮是否可用"; 两入口的按钮精度由绘制期 enabled 保证(面板按面板活跃行,
    饼菜单按选中集), poll 只兜 F3/脚本路径.
    """
    candidates = []
    for light in (_viewport_light(context), panel_light(context)):
        if light is not None and light not in candidates:
            candidates.append(light)
    return candidates


def _linked_guard(op: Operator, light: Object) -> bool:
    """execute 直调路径的库链接复查(规范 10.2): poll 拦得住 GUI, 直调绕过 poll

    返回 True 表示已报告并应取消.
    """
    if light.library is not None:
        op.report({'WARNING'}, report("Linked lights cannot be edited"))
        return True
    return False


def _adjust_rig_linked(rig_light: Object, rig_controller: Object) -> bool:
    """L 模态库链接判定: 灯光或控制器任一为库链接数据块即整体拒绝

    模态各档直写两者变换(A/S/D/W 调值/吸附/取消还原同口径), 不做按档拆分——Blender
    对链接物体的变换写入不设防, 直写静默改写库资产; 能量属灯光数据块, 本地物体
    挂链接灯光数据块的残余写由 S 档与还原路径的数据块级守卫另行拦.
    """
    return rig_light.library is not None or rig_controller.library is not None


def _reset_rig_params(light: Object) -> None:
    """把灯光 rig 的四参数恢复默认值: 方位角 0 / 高度角默认 / 距离回创建初值 / 自旋转 0

    距离默认值 = 创建时记录的初始距离(旧 rig 回退面板默认), 自旋转归零顺带整体归位瞄准姿态.
    前提: 灯光带**本地**控制器——Blender 对链接物体的 matrix_basis 写入不设防, 直写会静默
    改写库数据; 调用方须先行过滤(面板路径有链接控制器守卫, 批量路径按链接控制器计数跳过).
    """
    controller = rig_controller_of(light)
    set_controller_azimuth(controller, 0.0)
    set_controller_elevation(controller, RIG_DEFAULT_ELEVATION)
    set_light_distance(light, rig_init_distance(light))
    reset_light_self_rotation(light)


def _invoke_type_menu(context: Context, is_ctrl: bool, is_alt: bool) -> None:
    """+Shift 弹出灯光类型菜单: 菜单项带 from_type_menu 标记直达创建

    落点修饰键由开窗时捕获并经菜单项 RNA 预设传递——菜单/弹窗里的算子按钮走 AfterFunc
    延迟调用(event=None, invoke 不运行), 点击时的事件修饰键不可得, 开窗时按下的
    Ctrl/Alt(用户按住不放穿过菜单点击)即唯一语义来源.
    """

    def draw(menu, _context: Context) -> None:
        column = menu.layout.column()
        for type_id, text, icon in (
            ('AREA', "Area", 'LIGHT_AREA'),
            ('POINT', "Point", 'LIGHT_POINT'),
            ('SUN', "Sun", 'LIGHT_SUN'),
            ('SPOT', "Spot", 'LIGHT_SPOT'),
        ):
            # 词条走系统 mo 的 "Light" 语境(点光/日光/聚光/面光, 与系统灯型命名一致),
            # 预译成中文再进按钮——弹窗按钮的显式 text 按 Operator 语境查找, 中文原样透传
            props = column.operator(LightAdd.bl_idname, text=iface_ctx(text, "Light"), icon=icon)
            props.light_type = type_id
            props.from_type_menu = True
            props.is_ctrl = is_ctrl
            props.is_alt = is_alt

    context.window_manager.popup_menu(draw, title=iface("Add Light"))


def _resolve_adjust_rig(context: Context) -> tuple[Object, Object] | None:
    """模态算子的 rig 解析: 选区优先 + 面板活跃灯光回退

    灯光方位折叠区按"面板活跃行"显示/编辑属性, 模态若只认选区会出现"属性可编辑
    而唤起按钮置灰"的口径分裂(审查 P2); 回退路径让按钮与属性行同口径.
    """
    rig = resolve_rig(context)
    if rig is not None:
        return rig
    light = panel_light(context)
    if light is not None:
        controller = rig_controller_of(light)
        if controller is not None:
            return (light, controller)
    return None


class LightAdd(TranslatedDescriptionMixin, Operator):
    """添加灯光: 默认控制器落到活动物体; +Shift 弹类型菜单, +Ctrl 游标, +Alt 原点"""

    bl_idname = "ch.light_add"
    bl_label = "Add Light"
    bl_description = (
        "Add a light rig with its controller at the active object (requires a non-light object)\n"
        "+Shift: Pick the light type from a popup (combine with Ctrl/Alt to land at the 3D cursor or world origin)\n"
        "+Ctrl: Land the controller at the 3D cursor\n"
        "+Alt: Land the controller at the world origin"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_shift: BoolProperty(name="Shift", default=False, options={'HIDDEN'}, description="Open the light type menu (set by +Shift)")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore
    # SKIP_SAVE: 类型与菜单标记不得进 Blender 的"上次算子属性"复用——否则菜单项运行后,
    # 任何入口都会继承上次类型并跳过菜单(WM_operator_last_properties_init 只回填未显式
    # 设置且未打 SKIP_SAVE 的属性)
    light_type: EnumProperty(
        name="Light Type",
        items=(
            ('AREA', "Area", ""),
            ('POINT', "Point", ""),
            ('SUN', "Sun", ""),
            ('SPOT', "Spot", ""),
        ),
        default='AREA',
        options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore
    from_type_menu: BoolProperty(name="From Type Menu", default=False, options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def invoke(self, context: Context, event: Event):
        self.is_shift = bool(event is not None and event.shift)
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        if self.from_type_menu:
            # 类型菜单项直呼: 落点修饰键来自菜单项点击事件, 直达创建
            return self.execute(context)
        if self.is_shift:
            _invoke_type_menu(context, is_ctrl=self.is_ctrl, is_alt=self.is_alt)
            return {'CANCELLED'}
        return self.execute(context)

    def execute(self, context: Context):
        if self.is_ctrl:
            position = context.scene.cursor.location.copy()
        elif self.is_alt:
            position = Vector((0.0, 0.0, 0.0))
        else:
            # 默认落点 = 活动物体(非灯光即可; 控制器空体也是合法落点, 新 rig 无自撞问题)
            position = _landing_at_active(context, exclude_controllers=False)
            if position is None:
                self.report({'WARNING'}, report("Select a non-light object to place the controller at"))
                return {'CANCELLED'}
        light, _controller = create_light_rig(context, position, light_type=self.light_type)
        # 新建项高亮(与 CreateAlignCamera 同口径): 先同步快照再按名定位
        refresh_lists()
        highlight_item(context, "lights", light.name)
        return {'FINISHED'}


def _select_new_rigs(context: Context, pairs: list[tuple[Object, Object]]) -> None:
    """收尾一次性选中全部新 rig, 末套灯光为活动物体

    逐套选中会全场景重写选中集, 批量复制后只剩最后一套(作者口径: 收尾一次选
    新 rig 全体); 新建物体要等视图层求值后才进 view_layer.objects——select_only
    的可选中判定会静默跳过, 先显式 update 一次再选中.
    """
    context.view_layer.update()
    select_only(context, [obj for pair in pairs for obj in pair], active=pairs[-1][0])


def _copy_rigs_execute(op: Operator, context: Context, shared_data: bool, batch_text: str, single_text: str) -> set[str]:
    """复制/实例复制共用 execute(批量与面板两入口), 仅 shared_data 与报告文案不同

    批量逐灯复制不写选中态, 收尾 _select_new_rigs 一次选全体; 面板单灯入口即选该套.
    """
    if op.use_selection_batch:
        lights, linked = filter_batch_lights(context.selected_objects, require_controller=True)
        if not lights:
            op.report({'WARNING'}, report("No lights with controllers in the selection"))
            return {'CANCELLED'}
        pairs = [pair for pair in (copy_light_rig(context, light, shared_data=shared_data) for light in lights) if pair is not None]
        if not pairs:
            op.report({'WARNING'}, report("No lights with controllers in the selection"))
            return {'CANCELLED'}
        _select_new_rigs(context, pairs)
        refresh_lists()
        highlight_item(context, "lights", pairs[-1][0].name)
        batch_report(op, report(batch_text).format(len(lights)), linked)
        return {'FINISHED'}
    light = panel_light(context)
    if light is None:
        return {'CANCELLED'}
    if _linked_guard(op, light):
        return {'CANCELLED'}
    pair = copy_light_rig(context, light, shared_data=shared_data)
    if pair is None:
        op.report({'WARNING'}, report("The active light has no controller"))
        return {'CANCELLED'}
    _select_new_rigs(context, [pair])
    refresh_lists()
    highlight_item(context, "lights", pair[0].name)
    op.report({'INFO'}, report(single_text).format(pair[0].name))
    return {'FINISHED'}


class LightCopy(SelectionBatchMixin, TranslatedDescriptionMixin, Operator):
    """复制灯光: 面板复制活跃灯光整套 rig(数据独立副本); 饼菜单批量复制选中集里的 rig"""

    bl_idname = "ch.light_copy"
    bl_label = "Copy Light"
    bl_description = "Duplicate the active light with its controller empty (the light data-block is copied)\nLight pie menu: duplicate every selected light with a controller (batch)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(light.library is None and rig_controller_of(light) is not None for light in _candidate_lights(context))

    def execute(self, context: Context):
        return _copy_rigs_execute(self, context, shared_data=False, batch_text="Light rigs copied: {}", single_text="Light rig copied: {}")


class LightInstanceCopy(SelectionBatchMixin, TranslatedDescriptionMixin, Operator):
    """实例复制: 面板复制活跃灯光层级但共享灯光数据; 饼菜单批量实例复制选中集里的 rig"""

    bl_idname = "ch.light_instance_copy"
    bl_label = "Instance Copy"
    bl_description = "Duplicate the active light with its controller empty while sharing the light data-block (power/color edits affect every instance)\nLight pie menu: instance-copy every selected light (batch, sharing data)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(light.library is None and rig_controller_of(light) is not None for light in _candidate_lights(context))

    def execute(self, context: Context):
        return _copy_rigs_execute(self, context, shared_data=True, batch_text="Light instances created: {}", single_text="Light instance created: {}")


class LightControllerSet(SelectionBatchMixin, TranslatedDescriptionMixin, Operator):
    """设置控制器: 面板对活跃灯光绑定/重设; 饼菜单对选中灯光批量绑定或重设到落点"""

    bl_idname = "ch.light_controller_set"
    bl_label = "Set Controller"
    bl_description = (
        "Attach a controller empty to the panel's active light, or move the existing one and re-aim (the light keeps its world position, self rotation resets to 0; the controller lands on the last selected object that is neither a light nor a light controller)\n"
        "+Ctrl: Land at the 3D cursor\n"
        "+Alt: Land at the world origin\n"
        "Light pie menu: batch for every selected light — reset its controller to the active object, or attach one when missing (the active object must not be a light or a light controller)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        # 无控制器(添加路径)或有本地控制器(重设路径)都可用; 链接灯光/链接控制器不可编辑
        for light in _candidate_lights(context):
            if light.library is not None:
                continue
            controller = rig_controller_of(light)
            if controller is None or controller.library is None:
                return True
        return False

    def invoke(self, context: Context, event: Event):
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        return self.execute(context)

    def execute(self, context: Context):
        if self.use_selection_batch:
            return self._execute_batch(context)
        return self._execute_panel(context)

    def _resolve_position(self, context: Context, batch: bool) -> Vector | None:
        """按入口解析落点; 无法确定时报警告并返回 None

        +Ctrl = 游标; +Alt = 世界原点(Ctrl 优先); 默认: 批量取活动物体, 面板取
        "选中集最后一个合格物体"(活动物体优先). 两者的合格判据都排除灯光与灯光控制器
        空体——控制器落到自己身上毫无意义.
        """
        if self.is_ctrl:
            return context.scene.cursor.location.copy()
        if self.is_alt:
            return Vector((0.0, 0.0, 0.0))
        if batch:
            return _landing_at_active(context, exclude_controllers=True)
        return _landing_from_selection(context)

    def _execute_panel(self, context: Context):
        light = panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        position = self._resolve_position(context, batch=False)
        if position is None:
            self.report({'WARNING'}, report("Select a non-light object to place the controller at"))
            return {'CANCELLED'}
        if rig_controller_of(light) is None:
            # 添加路径: 绑定控制器并转身瞄准, 控制器入选中集给即时视觉反馈
            controller = add_controller(context, light, position)
            context.view_layer.update()
            if is_selectable(context, controller):
                controller.select_set(True)
            refresh_lists()
            highlight_item(context, "lights", light.name)
            self.report({'INFO'}, report("Controller added: {}").format(controller.name))
            return {'FINISHED'}
        # 重设路径: 控制器挪到新位置并重新瞄准(灯光保位, 自旋转归零)
        result = reset_controller(context, light, position)
        if result == "none":
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        if result == "linked":
            self.report({'WARNING'}, report("Linked controller empties cannot be edited"))
            return {'CANCELLED'}
        refresh_lists()
        highlight_item(context, "lights", light.name)
        # 占位符填控制器名(原误填 reset_controller 的内部状态串 "reset", 状态栏显示
        # "已重置控制器: reset")
        self.report({'INFO'}, report("Controller reset: {}").format(rig_controller_of(light).name))
        return {'FINISHED'}

    def _execute_batch(self, context: Context):
        position = self._resolve_position(context, batch=True)
        if position is None:
            self.report({'WARNING'}, report("Select a non-light object to place the controller at"))
            return {'CANCELLED'}
        lights, linked = filter_batch_lights(context.selected_objects, require_controller=False)
        if not lights:
            self.report({'WARNING'}, report("No lights in the selection"))
            return {'CANCELLED'}
        # 有控制器走重设, 无控制器走绑定(不跳过); 不逐个改选中集(批量后选中集应保持可预期)
        reset_count = 0
        add_count = 0
        linked_ctrl = 0
        for light in lights:
            if rig_controller_of(light) is None:
                add_controller(context, light, position, update=False)
                add_count += 1
                continue
            result = reset_controller(context, light, position, update=False)
            if result == "linked":
                # 本地灯挂链接控制器(混合态): 重设侧无可写数据, 计数跳过
                linked_ctrl += 1
                continue
            if result != "none":
                reset_count += 1
        # 全场景求值上移到循环后一次(add_controller/reset_controller 单灯路径自带
        # update, 批量 N 灯 N 次全场景求值在大场景点击后秒级卡顿——批量循环内不读
        # 任何变换)
        context.view_layer.update()
        msg = append_skip_notes(report("Controllers reset: {}, controllers added: {}").format(reset_count, add_count), linked_ctrl, linked)
        if not reset_count and not add_count:
            # 全为链接控制器等不可写态: 按零计数与跳过实情取消, 不谎报"选中集里没有灯光"
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        refresh_lists()
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class LightControllerRemove(SelectionBatchMixin, TranslatedDescriptionMixin, Operator):
    """移除控制器: 面板摘除活跃灯光的控制器; 饼菜单批量摘除选中灯光的控制器"""

    bl_idname = "ch.light_controller_remove"
    bl_label = "Remove Controller"
    bl_description = "Remove the controller empty from the active light (the light keeps its world transform)\nLight pie menu: remove the controllers of every selected light with one (batch)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(light.library is None and rig_controller_of(light) is not None for light in _candidate_lights(context))

    def execute(self, context: Context):
        if self.use_selection_batch:
            return self._execute_batch(context)
        light = panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        result = remove_controller(light)
        if result == "none":
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        refresh_lists()
        highlight_item(context, "lights", light.name)
        if result == "removed":
            self.report({'INFO'}, report("Controller removed"))
        elif result == "linked":
            self.report({'INFO'}, report("Linked controller kept, only the parent binding was removed"))
        else:
            self.report({'INFO'}, report("Controller has other children, kept as a regular empty"))
        return {'FINISHED'}

    def _execute_batch(self, context: Context):
        lights, linked = filter_batch_lights(context.selected_objects, require_controller=True)
        if not lights:
            self.report({'WARNING'}, report("No lights with controllers in the selection"))
            return {'CANCELLED'}
        removed = 0
        unbound = 0
        for light in lights:
            result = remove_controller(light)
            if result == "removed":
                removed += 1
            elif result in {"linked", "shared"}:
                # 链接/共挂的控制器只解绑不删(与单个移除同口径), 计入"仅解绑"
                unbound += 1
        if not removed and not unbound:
            self.report({'WARNING'}, report("No lights with controllers in the selection"))
            return {'CANCELLED'}
        refresh_lists()
        batch_report(self, report("Controllers removed: {}, bindings only removed: {}").format(removed, unbound), linked)
        return {'FINISHED'}


class LightRigParamsReset(SelectionBatchMixin, TranslatedDescriptionMixin, Operator):
    """重置参数: 面板重置活跃灯光 rig 的四参数; 饼菜单批量重置选中灯光"""

    bl_idname = "ch.light_rig_params_reset"
    bl_label = "Reset Parameters"
    bl_description = "Reset the rig parameters of the active light to their defaults (azimuth 0, elevation 45 degrees, distance back to the rig's recorded initial distance, self rotation 0; rigs without a record fall back to the 5 m default)\nLight pie menu: reset every selected light with a controller (batch)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        # 方位/高度角要写控制器变换: 链接灯光与链接控制器都不可重置(与四钮口径一致)
        for light in _candidate_lights(context):
            if light.library is not None:
                continue
            controller = rig_controller_of(light)
            if controller is not None and controller.library is None:
                return True
        return False

    def execute(self, context: Context):
        if self.use_selection_batch:
            return self._execute_batch(context)
        light = panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        controller = rig_controller_of(light)
        if controller is None:
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        if controller.library is not None:
            self.report({'WARNING'}, report("Linked controller empties cannot be edited"))
            return {'CANCELLED'}
        _reset_rig_params(light)
        self.report({'INFO'}, report("Light rig parameters reset"))
        return {'FINISHED'}

    def _execute_batch(self, context: Context):
        lights, linked = filter_batch_lights(context.selected_objects, require_controller=True)
        if not lights:
            self.report({'WARNING'}, report("No lights with controllers in the selection"))
            return {'CANCELLED'}
        reset_count = 0
        linked_ctrl = 0
        for light in lights:
            controller = rig_controller_of(light)
            if controller is not None and controller.library is not None:
                # 本地灯挂链接控制器(混合态): Blender 对链接物体 matrix_basis 写入不设防,
                # 直写会静默改写库数据(红基线实证), 与面板路径"链接控制器不可编辑"同口径计数跳过
                linked_ctrl += 1
                continue
            _reset_rig_params(light)
            reset_count += 1
        msg = append_skip_notes(report("Light rig parameters reset: {}").format(reset_count), linked_ctrl, linked)
        if not reset_count:
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        refresh_lists()
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class LightControllersRemoveAll(TranslatedDescriptionMixin, Operator):
    """移除所有控制器: 把当前灯光列表内全部灯光的控制器批量摘除(灯保位并解锁旋转)"""

    bl_idname = "ch.light_controllers_remove_all"
    bl_label = "Remove All Controllers"
    bl_description = "Remove the controller empty from every light in the current lights list (each light keeps its world position, rotation unlocked; linked or shared controller empties are kept — only the parent binding is removed)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        scene = context.scene
        view_layer = context.view_layer
        # 与四钮同口径: 库链接灯不计入(链接控制器不可解绑)
        return any(light.library is None and rig_controller_of(light) is not None for light in collect_light_blocks(scene, view_layer))

    def execute(self, context: Context):
        lights = collect_light_blocks(context.scene, context.view_layer)
        removed = 0
        unbound = 0
        for light in lights:
            if light.library is not None:
                # 链接灯跳过(会话内解绑库资产重载即复原, 与四钮置灰口径一致)
                continue
            result = remove_controller(light)
            if result == "removed":
                removed += 1
            elif result in {"linked", "shared"}:
                # 链接/共挂的控制器只解绑不删(与单个移除同口径), 计入"仅解绑"
                unbound += 1
        if not removed and not unbound:
            self.report({'INFO'}, report("No lights with controllers"))
            return {'CANCELLED'}
        refresh_lists()
        self.report({'INFO'}, report("Controllers removed: {}, bindings only removed: {}").format(removed, unbound))
        return {'FINISHED'}


class LightRigAdjust(ModalOperatorMixin, TranslatedDescriptionMixin, Operator):
    """灯光控制模态: A 档调方位/高度, S/D/W 按住调亮度/距离/自旋转, Ctrl/Alt 吸附对齐控制器"""

    bl_idname = "ch.light_rig_adjust"
    bl_label = "Light Control"
    bl_description = (
        "Adjust the light rig interactively\n"
        "+A/S/D/W: A is the base mode (mouse X/Y for azimuth/elevation); hold S/D/W for brightness/distance/self rotation (mouse X), release returns to A\n"
        "+Shift: Precise adjustment (half the rate)\n"
        "+Ctrl: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the surface normal (leaves adjustment mode; press A/S/D/W to resume)\n"
        "+Alt: Hold and move the mouse to snap to surfaces and align its Y axis to the reflection line of the current view's virtual camera (scene camera in a camera view; the clicked point becomes the highlight position)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and _resolve_adjust_rig(context) is not None

    def execute(self, context: Context):
        # 模态算子直调守卫(规范 10.2): report WARNING + CANCELLED, 不复入 invoke
        self.report({'WARNING'}, report("This operator runs interactively in the 3D view"))
        return {'CANCELLED'}

    def invoke(self, context: Context, event: Event):
        rig = _resolve_adjust_rig(context)
        if rig is None:
            return {'CANCELLED'}
        self.rig_light: Object = rig[0]
        self.rig_controller: Object = rig[1]
        # 库链接 rig 整体拒绝(与四钮"库链接灯光不可编辑"同族): A/D 档/吸附/还原都直写
        # 灯与控制器的变换——链接物体的变换写入不设防, 直写静默改写库资产
        if _adjust_rig_linked(self.rig_light, self.rig_controller):
            self.report({'WARNING'}, report("Linked lights cannot be edited"))
            return {'CANCELLED'}
        if context.region_data is None:
            # 后台无视图: 交互不成立, 走直调守卫口径
            return self.execute(context)
        # --- 模态状态 ---
        # 取消还原快照: 控制器/灯光的 basis 与功率(父级逆不受模态影响, basis 还原即世界还原)
        self.init_controller_mx: Matrix = self.rig_controller.matrix_basis.copy()
        self.init_light_mx: Matrix = self.rig_light.matrix_basis.copy()
        self.init_energy: float = self.rig_light.data.energy
        # 调节模式: A 为常驻基础档, S/D/W 为按住式(见 _HOLD_KEYS), 进入默认 A 档
        self.axis: str = 'A'
        self.held_axes: set = set()
        self.pass_through = False
        self.init_mouse_position(event)
        self.init_status(context, func=_draw_rig_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context)
        self.init_view_draw(self._draw_preview)
        force_ui_update(context)
        # 模态调值只写变换, 不改任何列表成员: 挂起 handlers 的全量列表同步(否则每次
        # 调值的 depsgraph 更新都会触发 0.1s 一次的六列表全量重建, 是模态卡顿主因);
        # 置位放在 RUNNING_MODAL 前一行, 消掉 invoke 尾部异常的泄漏窗口(审查 P1)
        set_sync_suppressed(True)
        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        try:
            return self._modal_dispatch(context, event)
        except Exception:
            # 模态期异常(如灯/控制器被外部删除): Blender 直接摘除模态算子且不再走
            # _finish——必须在此复位同步抑制与状态栏, 否则全量同步静默停摆(审查 P1);
            # 收敛动作逐一兜住, 收敛自身失败不掩盖原异常
            set_sync_suppressed(False)
            try:
                self.finish_status()
                self.finish_modal_handlers()
                self.finish_view_draw()
                force_statusbar_redraw(context)
            except Exception:
                pass
            return {'CANCELLED'}

    def _modal_dispatch(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 先数据级还原(不依赖 area, 与 ESC 取消同语义——否则已做
            # 的调整漏进下一次无关操作的 undo 步), 再最小收敛退出
            self._restore()
            set_sync_suppressed(False)
            self._abort_without_area(context)
            force_statusbar_redraw(context)
            return {'CANCELLED'}
        if event.type == 'WINDOW_DEACTIVATE':
            # 窗口失活时按键松开事件会送到别处: 按住集必须清空, 否则 S/D/W 档卡在按住态
            # (回到窗口后鼠标一动就继续改功率/距离, 直到重按 A/S/D/W)
            self.held_axes.clear()
            if self.axis in _HOLD_KEYS:
                self.axis = 'A'
            return {'RUNNING_MODAL'}
        if ignore_events(event):
            return {'RUNNING_MODAL'}
        context.area.tag_redraw()
        return self._handle_modal_events(context, event)

    def _handle_modal_events(self, context: Context, event: Event):
        if event.type == 'MOUSEMOVE':
            return self._handle_mouse_move(context, event)
        if navigation_passthrough(event, alt=True):
            # 视图导航(MMB 旋转等): 事件交给导航系统, 下一帧 MOUSEMOVE 重置基线
            self.pass_through = True
            return {'PASS_THROUGH'}
        if event.value == 'PRESS' or (event.value == 'RELEASE' and event.type in _HOLD_KEYS):
            # 松开事件只对按住式调节键有意义(A 为基础档, 松开不改变档位)
            return self._handle_key_press(context, event)
        return {'RUNNING_MODAL'}

    def _handle_mouse_move(self, context: Context, event: Event):
        if self.pass_through:
            # 视图导航结束: 重置基线, 本帧不做任何调整
            self.pass_through = False
            self.init_mouse_position(event)
            return {'RUNNING_MODAL'}
        if event.ctrl or event.alt:
            # 吸附档: 进入即退出调节模式(置 None)——松开 Ctrl/Alt 后鼠标移动不再调值,
            # 须重新按 A/S/D/W 才恢复
            self.axis = None
            self._handle_controller_move(context, event)
        elif self.axis is not None:
            # 调值态光标到区域边缘跳到对侧: 包裹帧跳过调值, 基线已在包裹内重置
            if self.wrap_mouse_position(context, event):
                return {'RUNNING_MODAL'}
            self._handle_light_axis(context, event)
        self.init_mouse_position(event)
        self.update_header_text(context)
        return {'RUNNING_MODAL'}

    def _reflection_view_point(self, context: Context) -> Vector:
        """反射模式的观察点: 相机视图用场景相机, 其余用 3D 视图的虚拟相机视点

        反射线 = 虚拟相机指向表面点的矢量经表面反射, 逐帧现算, 模态中导航后仍跟随当前视角.
        """
        rv3d = context.region_data
        if rv3d.view_perspective == 'CAMERA' and context.scene.camera is not None:
            return context.scene.camera.matrix_world.translation
        return rv3d.view_matrix.inverted().translation.copy()

    def _handle_controller_move(self, context: Context, event: Event) -> None:
        """控制器调整: 射线吸附表面; +Ctrl 法线对齐 / +Alt 反射对齐(同按 Alt 优先)

        对齐轴为控制器局部 +Y(rig 几何约定灯在局部 +Y 轴上).
        """
        result = raycast_surface(context, (event.mouse_region_x, event.mouse_region_y))
        if result is None:
            return
        hit, normal = result
        _loc, rot, scale = self.rig_controller.matrix_basis.decompose()
        self.rig_controller.matrix_basis = Matrix.Translation(hit) @ rot.to_matrix().to_4x4() @ Matrix.Diagonal(scale.to_4d())
        if event.alt:
            align_controller_y(self.rig_controller, reflection_direction(self._reflection_view_point(context), hit, normal))
        elif event.ctrl:
            align_controller_y(self.rig_controller, normal)

    def _handle_light_axis(self, context: Context, event: Event) -> None:
        """按当前模式把鼠标增量写进 rig(区域归一幅度与 Shift 精确比率读偏好设置)"""
        prefs = get_prefs()
        delta_x = event.mouse_x - self.last_mouse_x
        delta_y = event.mouse_y - self.last_mouse_y
        factor = prefs.light_rig_shift_factor if event.shift else 1.0
        step_x = delta_x * factor / max(context.region.width, 1)
        step_y = delta_y * factor / max(context.region.height, 1)
        light = self.rig_light
        controller = self.rig_controller
        if self.axis == 'A':
            set_controller_azimuth(controller, get_controller_azimuth(controller) + step_x * prefs.light_rig_angle_sweep)
            set_controller_elevation(controller, get_controller_elevation(controller) + step_y * prefs.light_rig_angle_sweep)
        elif self.axis == 'D':
            set_light_distance(light, get_light_distance(light) + step_x * prefs.light_rig_distance_span)
        elif self.axis == 'W':
            # 自旋转写灯光局部旋转的 Y 分量(X/Z 瞄准分量不动; 非 XYZ 欧拉时工具函数拒写);
            # 旋转属灯光物体, invoke 的库链接整体拒绝已覆盖
            set_light_self_rotation(light, get_light_self_rotation(light) + step_x * prefs.light_rig_angle_sweep)
        else:
            # 功率按绝对幅度增减(归一化), 0 起步自然可用; 能量属灯光数据块——链接物体
            # 已在 invoke 整体拒绝, 此处拦本地物体挂链接灯光数据块的残余写
            if light.data.library is None:
                light.data.energy = max(0.0, light.data.energy + step_x * prefs.light_rig_power_span)

    def _handle_key_press(self, context: Context, event: Event):
        if event.type in _AXIS_KEYS:
            return self._handle_axis_key(event)
        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            self._finish(context)
            return {'FINISHED'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._restore()
            self._finish(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _handle_axis_key(self, event: Event):
        """A/S/D/W 的按下与松开: A 为常驻基础档, S/D/W 为按住式, 松开回落到 A

        吸附档(axis 为 None)不在此恢复——松开 Ctrl/Alt 后仍须重按 A/S/D/W 才继续调值, 故松开事件只在档位仍有效时回落.
        """
        if event.value == 'RELEASE':
            self.held_axes.discard(event.type)
            if self.axis is not None:
                self.axis = self._held_axis()
            return {'RUNNING_MODAL'}
        if event.type == 'A':
            # 按 A 即回基础档: 清空按住集, 避免仍按着的 S/D 把档位顶回去
            self.held_axes.clear()
        else:
            self.held_axes.add(event.type)
        self.axis = self._held_axis()
        return {'RUNNING_MODAL'}

    def _held_axis(self) -> str:
        """按住中的键决定档位(D 优先于 S, S 优先于 W), 都没按住则基础档 A"""
        if 'D' in self.held_axes:
            return 'D'
        if 'S' in self.held_axes:
            return 'S'
        if 'W' in self.held_axes:
            return 'W'
        return 'A'

    def update_header_text(self, context: Context) -> None:
        """header 只显数值(规范 5.3): 五属性实时值, 角度带 °, 距离/亮度按场景单位走 Blender 单位串"""
        unit_system = context.scene.unit_settings.system
        distance_text = bpy.utils.units.to_string(unit_system, 'LENGTH', get_light_distance(self.rig_light), precision=2).strip()
        brightness_text = bpy.utils.units.to_string(unit_system, 'POWER', self.rig_light.data.energy, precision=1)
        text = iface("Azimuth: {}  Elevation: {}  Distance: {}  Brightness: {}  Self Rotation: {}").format(
            "{:.1f}°".format(degrees(get_controller_azimuth(self.rig_controller))),
            "{:.1f}°".format(degrees(get_controller_elevation(self.rig_controller))),
            distance_text,
            brightness_text,
            "{:.1f}°".format(degrees(get_light_self_rotation(self.rig_light))),
        )
        context.area.header_text_set(text)

    def _draw_preview(self) -> None:
        """A/D 档轨迹预览: 方位圆环 + 高度大圆 + 半径连线 + 刻度圆点

        轨迹线颜色保持偏好色, 透明度按"到灯光的距离"衰减(灯处不透明, 最远处降到偏好"轨迹线暗淡");
        偏好每帧现读(开关/颜色/线宽/刻度/遮挡改完即时生效). 只读变换不改数据, 不触发
        depsgraph 变更, 也不进撤销栈; 灯或控制器被外部删除时读取即抛 ReferenceError,
        由绘制层吞掉并停用, 不影响模态本身.
        """
        if self.axis not in _PREVIEW_AXES:
            return
        prefs = get_prefs()
        if not prefs.light_rig_show_preview:
            return
        trajectory = rig_trajectory(self.rig_light)
        if trajectory is None:
            return
        ring, meridian, position = trajectory
        center = self.rig_controller.matrix_world.translation
        azimuth_color = tuple(prefs.light_rig_preview_azimuth_color)
        elevation_color = tuple(prefs.light_rig_preview_elevation_color)
        spoke_color = tuple(prefs.light_rig_preview_spoke_color)
        width = prefs.light_rig_preview_line_width
        tick_scale = prefs.light_rig_preview_tick_scale
        track_dim = prefs.light_rig_preview_track_dim
        xray = prefs.light_rig_preview_xray
        draw_polyline(ring, fade_alpha_by_distance(ring, position, azimuth_color, track_dim), width=width, xray=xray, closed=True)
        draw_polyline(meridian, fade_alpha_by_distance(meridian, position, elevation_color, track_dim), width=width, xray=xray, closed=True)
        # 半径连线: 控制器 -> 灯, 表达当前距离与方位(环本身穿过灯位, 连线只作提示); 颜色独立偏好
        draw_polyline((center, position), (spoke_color, spoke_color), width=width, alpha=_PREVIEW_SPOKE_ALPHA, xray=xray)
        if not prefs.light_rig_preview_show_ticks:
            return
        # 刻度间隔属性是 ANGLE 子类型(内部弧度), 几何层按度取角, 故在此换算
        ring_ticks, meridian_ticks = rig_trajectory_ticks(self.rig_light, degrees(prefs.light_rig_preview_tick_angle))
        # 圆点直径是像素量, 需视图投影换算世界半径; 取不到投影时绘制层自行跳过
        region, region_data = _preview_projection(self)
        for ticks, track_color in ((ring_ticks, azimuth_color), (meridian_ticks, elevation_color)):
            points = []
            sizes = []
            colors = []
            for point, axis in ticks:
                axis_color = AXIS_TICK_COLORS.get(axis) if axis else None
                points.append(point)
                # 刻度直径 = 线宽 x 偏好"刻度系数"(刻度显示厚度单一来源); 正轴恒为普通刻度 1.5 倍
                sizes.append(width * (tick_scale * _AXIS_TICK_SCALE if axis_color else tick_scale))
                colors.append(axis_color if axis_color else track_color)
            draw_discs(points, sizes, colors, alpha=_TICK_ALPHA, xray=xray, region=region, region_data=region_data)

    def _restore(self) -> None:
        """取消路径: 控制器变换 / 灯光局部变换 / 功率整体还原到 invoke 快照

        变换回写由 invoke 的库链接整体拒绝兜住; 能量属灯光数据块, 本地物体挂链接
        数据块时不回写(S 档同口径未写, 还原无值可还).
        """
        self.rig_controller.matrix_basis = self.init_controller_mx
        self.rig_light.matrix_basis = self.init_light_mx
        if self.rig_light.data.library is None:
            self.rig_light.data.energy = self.init_energy

    def _finish(self, context: Context) -> None:
        """收尾(生命周期调用序): 状态栏 -> 模态处理器 -> header 清除 -> UI 刷新"""
        set_sync_suppressed(False)
        self.finish_status()
        self.finish_modal_handlers()
        self.finish_view_draw()
        context.area.header_text_set(None)
        # 状态栏区域显式重绘: 恢复 statusbar.draw 后不 tag 会残留旧自绘内容
        force_statusbar_redraw(context)
        force_ui_update(context)
