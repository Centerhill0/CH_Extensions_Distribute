"""
世界环境在线 HDRI 操作器模块

在线资产库(库根带 manifest.json 索引)的 HDRI 下载入口: 分辨率/格式下拉,规格选定,
按当前缩略图与规格下载(下载包保留,解压出 .exr/.hdr)与取消进行中的下载.
绘制与执行逻辑在 operators/utils/asset_online(与 PBR 材质档共用一套实现), 本模块只声明
标识与载荷. 加载到节点不在此模块——由缩略图名称行右侧的来源刷新钮统一完成.

提供以下功能:
- WorldHDRIResolutionMenu / WorldHDRIFormatMenu: 下载规格下拉(候选来自索引的下载表,
  菜单项用 DOT/BLANK1 标识该组合是否已下载并留位对齐)
- WorldHDRIOptionSet: 把选定的分辨率/格式写进面板状态
- WorldHDRIDownload: 按当前选择下载并解压到资产库(8K 起先弹确认)
- WorldHDRIDownloadCancel: 取消该规格进行中的下载
"""

from bpy.props import StringProperty
from bpy.types import Menu, Operator

from ..utils.asset_online import OnlineCancelMixin, OnlineDownloadMixin, OnlineFormatMixin, OnlineOptionSetMixin, OnlineResolutionMixin

# 本档规格设定算子的标识(菜单项创建算子时引用, 与下方类声明同源)
_OPTION_SET = "ch.world_hdri_option_set"


class WorldHDRIResolutionMenu(OnlineResolutionMixin, Menu):
    """HDRI 下载行的分辨率下拉(菜单项带该档体积; 图标标识该组合是否已下载)"""

    bl_idname = "CH_MT_world_hdri_resolution"
    bl_label = "Resolution"
    pick_kind = 'WORLD'
    option_set = _OPTION_SET


class WorldHDRIFormatMenu(OnlineFormatMixin, Menu):
    """HDRI 下载行的格式下拉(只列当前分辨率可用的格式; 图标口径与分辨率菜单相同)"""

    bl_idname = "CH_MT_world_hdri_format"
    bl_label = "Format"
    pick_kind = 'WORLD'
    option_set = _OPTION_SET


class WorldHDRIOptionSet(OnlineOptionSetMixin, Operator):
    """下载规格选定: 写面板状态里的分辨率或格式(空/失效由解析回落, 无需校验取值)"""

    bl_idname = _OPTION_SET
    bl_label = "Set Download Option"
    bl_description = "Use this resolution or format for the HDRI download"

    pick_kind = 'WORLD'

    field: StringProperty(name="Field", default="RESOLUTION", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    value: StringProperty(name="Value", default="", options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore


class WorldHDRIDownload(OnlineDownloadMixin, Operator):
    """HDRI 下载: 按当前缩略图与规格下载资产包(保留)并解压出源文件

    仅在线库可用; 8K 及以上的大档先弹确认(单包 160-568 MB, 误点代价高).
    全局单任务由下载模块保证(任务进行中面板已把其余下载钮置灰).
    """

    bl_idname = "ch.world_hdri_download"
    bl_label = "Download"
    bl_description = "Download the selected HDRI at the chosen resolution and extract it into the asset library (the archive is kept)"

    pick_kind = 'WORLD'


class WorldHDRIDownloadCancel(OnlineCancelMixin, Operator):
    """取消下载: 置当前任务取消位(全局单任务, 面板切了规格也能取消), 未完成文件由下载模块清理"""

    bl_idname = "ch.world_hdri_download_cancel"
    bl_label = "Cancel Download"
    bl_description = "Cancel the running download of this HDRI and remove the incomplete file"
