"""
相机辅助操作器模块

提供以下功能:
- ToggleCamera: 按列表顺序切换相机
- SetAsSceneCamera: 将活动物体设为场景相机
- CreateAlignCamera: 创建对齐当前视图的相机
- CameraOrganize: 相机整理, 把场景内所有相机移入 Cameras 集合
"""

import bpy
from bpy.props import BoolProperty
from bpy.types import Context, Event, Operator

from .....common.blender.list_order import assign_order_at_end
from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import all_blocks_for, highlight_item, ordered_camera_objects
from ...utils import CAMERAS_COLLECTION_NAME, collect_visible_cameras, ensure_scene_collection, move_objects_to_collection, select_only, sync_active_camera_resolution


class ToggleCamera(Operator):
    """切换相机

    功能: 在场景中的相机之间切换(按列表顺序, 不按名称)
    - Previous: 切换到上一个相机
    - Next: 切换到下一个相机

    要求: 物体模式
    """

    bl_idname = "ch.toggle_camera"
    bl_label = "Toggle Camera"
    bl_description = "Toggle the camera object"
    bl_options = {'REGISTER', 'UNDO'}

    toggle_next: BoolProperty(name="Toggle Next", default=True, description="Toggle to the next camera in the list instead of the previous one")  # type: ignore

    camera_list: list

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def _get_cameras(self, context: Context) -> list:
        """按列表顺序取相机(以 ch_scene_order 为准); 快照未建立时退回名称序"""
        return ordered_camera_objects(context)

    def invoke(self, context: Context, event: Event):
        self.camera_list = self._get_cameras(context)
        if not self.camera_list:
            self.report({'WARNING'}, report("No camera found in view layer"))
            return {'CANCELLED'}
        return self.execute(context)

    def execute(self, context: Context):
        camera_list = getattr(self, "camera_list", None) or self._get_cameras(context)
        self.camera_list = camera_list
        if not camera_list:
            self.report({'WARNING'}, report("No camera found in view layer"))
            return {'CANCELLED'}

        camera_count = len(camera_list)
        current_camera = context.scene.camera
        if current_camera in camera_list:
            current_index = camera_list.index(current_camera)
        elif context.active_object in camera_list:
            current_index = camera_list.index(context.active_object)
        elif self.toggle_next:
            current_index = -1
        else:
            # 没有当前相机时"上一个"应从列表末尾开始(0 - 1 取模), 而不是倒数第二个
            current_index = 0

        offset = 1 if self.toggle_next else -1
        next_camera = camera_list[(current_index + offset) % camera_count]
        select_only(context, [next_camera])
        # 切换即成为场景相机(视图对齐由下面的 object_as_camera 完成, 后台无视图时也保证状态一致)
        context.scene.camera = next_camera
        # 独立分辨率跟随切换(改场景相机的其它路径由 handlers 兜底同步, 此处求即时)
        sync_active_camera_resolution(context.scene)
        # 列表高亮实时跟随: 选区同步关闭时 depsgraph 处理器不回写高亮, 需显式更新
        highlight_item(context, "cameras", next_camera.name)

        # 总是对齐到切换后的相机视图; 无 3D 视图上下文(后台通道)或活动物体不可设为
        # 视图相机(如被排除集合内的相机, 选中已被跳过)时跳过, 不抛异常
        space = getattr(context, "space_data", None)
        if space is not None and getattr(space, "type", "") == 'VIEW_3D' and bpy.ops.view3d.object_as_camera.poll():
            bpy.ops.view3d.object_as_camera()
        return {'FINISHED'}


class SetAsSceneCamera(Operator):
    """设为场景相机

    功能: 将活动物体设为场景相机(不限于相机物体)
    - 默认: 设置并对齐视图(以该物体的 -Z 朝向取景)
    - Ctrl: 仅设置, 不切换视图

    要求: 物体模式, 有活动物体
    """

    bl_idname = "ch.set_as_scene_camera"
    bl_label = "Set As Scene Camera"
    bl_description = "Set the active object as the scene camera and align the view to it\n+Ctrl: Set only, keep the current view"
    bl_options = {'REGISTER', 'UNDO'}

    is_set_only: bool = False  # invoke 中按 Ctrl 设置: 仅设为场景相机, 不切换视图

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and context.active_object is not None

    def invoke(self, context: Context, event: Event):
        self.is_set_only = event.ctrl
        return self.execute(context)

    def execute(self, context: Context):
        act_obj = context.active_object
        if act_obj is None:
            return {'CANCELLED'}
        context.scene.camera = act_obj
        # 成为本相机后立即对齐独立分辨率
        sync_active_camera_resolution(context.scene)
        if not self.is_set_only:
            # 默认进入该物体的取景视角; 无 3D 视图上下文(后台通道)或视图相机不可设时跳过
            space = getattr(context, "space_data", None)
            if space is not None and getattr(space, "type", "") == 'VIEW_3D' and bpy.ops.view3d.object_as_camera.poll():
                bpy.ops.view3d.object_as_camera()
        return {'FINISHED'}


class CreateAlignCamera(Operator):
    """创建对齐视图相机

    功能: 创建一个新相机并自动对齐到当前视图
    - 创建新相机
    - 设为场景相机
    - 对齐到当前视图

    要求: 物体模式
    """

    bl_idname = "ch.create_align_camera"
    bl_label = "Add Align Camera"
    bl_description = "Create a camera for aligning the view"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def execute(self, context: Context):
        bpy.ops.object.camera_add()
        cam = context.active_object
        if cam is None:
            return {'CANCELLED'}
        context.scene.camera = cam
        # 新建项默认追加到列表末尾(不按名称插入无顺序值组)
        assign_order_at_end(cam, all_blocks_for(context, "cameras"))
        # 新相机无独立分辨率, 场景相机切换即触发基准回落(与其它改相机路径同口径, 不等 handlers 兜底)
        sync_active_camera_resolution(context.scene)
        # 新建项高亮: 选区同步关闭时 depsgraph 不会回写高亮, 需显式写(与 ToggleCamera 同口径);
        # 快照里还没有新相机, 先同步快照再按名定位(与 CollectionNew 同口径)
        refresh_lists()
        highlight_item(context, "cameras", cam.name)

        # 用视图矩阵直接写相机变换: bpy.ops.view3d.camera_to_view() 在相机视图下 poll 失败,
        # 而侧栏按钮在相机视图里也应可用.
        space = getattr(context, "space_data", None)
        region_3d = getattr(space, "region_3d", None) if space is not None else None
        if region_3d is not None:
            cam.matrix_world = region_3d.view_matrix.inverted()
            # 创建即进入相机视图, 让"新建并对齐视图"一步到位(后台无视图时跳过)
            if getattr(space, "type", "") == 'VIEW_3D' and bpy.ops.view3d.object_as_camera.poll():
                bpy.ops.view3d.object_as_camera()
        else:
            self.report({'WARNING'}, report("No 3D view to align the camera to"))
        return {'FINISHED'}


class CameraOrganize(Operator):
    """相机整理: 把场景内所有相机(不含被排除集合内的)移入 Cameras 集合"""

    bl_idname = "ch.camera_organize"
    bl_label = "Organize Cameras"
    bl_description = "Move every camera into the Cameras collection (created on first use; cameras are unlinked from their other collections)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        scene = context.scene
        # 先判"有活可干": 场景没有相机时不去凭空建一个空集合
        cameras = collect_visible_cameras(scene, context.view_layer)
        if not cameras:
            # 只说"可整理的": 相机可能都在被排除的集合里, 报"场景没有相机"会误导
            self.report({'INFO'}, report("No cameras to organize"))
            return {'CANCELLED'}
        # 只认本地同名集合: 库链接的 Cameras 集合不可作为写入目标(link 成员报错),
        # 取 None 走下方新建本地集合的路径
        target = next((child for child in scene.collection.children if child.name == CAMERAS_COLLECTION_NAME and child.library is None), None)
        # 已独占在目标集合里的相机无事可做: 二次整理报 "Moved 0" 是噪音, 直接取消
        # (与灯光整理"界外没有灯光即取消"同口径; 判定与 move_objects_to_collection 的跳过规则一致)
        todo = [obj for obj in cameras if target is None or any(coll is not target for coll in obj.users_collection)]
        if not todo:
            self.report({'INFO'}, report("All cameras are already in the Cameras collection"))
            return {'CANCELLED'}
        if target is None:
            target = ensure_scene_collection(scene, CAMERAS_COLLECTION_NAME, 'COLOR_06')
        count = move_objects_to_collection(todo, target)
        # 条目本身没变(只换了集合归属), 但重建一次让列表顺序/大纲归属立即一致
        refresh_lists()
        self.report({'INFO'}, report("Moved {} cameras into {}").format(count, target.name))
        return {'FINISHED'}
