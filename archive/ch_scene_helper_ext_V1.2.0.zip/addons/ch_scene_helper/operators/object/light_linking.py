"""灯光链接操作器模块

"灯光&阴影链接"子面板(灯光面板详情区)的写入族算子: 写入算子的发射器一律取
灯光面板的活跃灯光行(或载荷指名的灯), 与原生算子(context_active_object 为发射器)
口径不同, 因此不复用原生算子.

- LightLinkingReceiverCollectionNew / LightLinkingBlockerCollectionNew:
  新建集合并指派为活跃灯光的灯光/阴影链接集合(template_ID 新建钮入口, 按类型拆两枚)
- LightLinkingEntryAdd: 把选中物体以包含状态链入活跃灯光的链接集合
- LightLinkingEntryStateSet: 切换集合成员的包含/排除状态
- LightLinkingEntryRemove: 把成员从链接集合移除(可同时移除灯光与阴影两处直接条目)
- LightLinkingCollectionSingleUser: 独立化被多灯共享的链接集合(副本保成员与状态)
- LightLinkingReceiverSync / LightLinkingBlockerSync: 把活动灯的灯光/阴影链接集合
  数据块共享给选中灯(饼菜单同步钮)
- LightLinkReceiverPreview / LightLinkBlockerPreview / LightLinkObjectReceiverPreview /
  LightLinkObjectBlockerPreview: 链接关系预览模态(饼菜单四钮, 左键/Enter 关闭)
- LightLinkingSelectTargets: 视口选中活跃灯光的全部接收者/遮挡者
- LightLinkingFocusEmitter: 物体链接反查行点击后把该灯定位到面板列表活跃项

操作流程:
- 全部按钮由面板绘制期传入载荷(link_type/emitter_name/target_name 等, 均为 HIDDEN 属性),
  精度由绘制期 enabled 保证, 算子内再守卫一遍兜住脚本直调;
- 库链接灯光一律拒绝写入; 链接集合被场景占用(主集合)时拒绝写入, 与原生同口径;
- 成员条目按"名称 + 是否子集合"定位(条目包装类不暴露所指数据块, 身份由
  utils.light_linking 的同序 zip 配对还原).
"""

import bpy

from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...modal_base import ModalOperatorMixin, draw_status_item, force_statusbar_redraw, force_ui_update, ignore_events, navigation_passthrough
from ...preference import get_prefs
from ...scene_state import blocks_for, highlight_item, panel_light
from ...utils import (
    arrow_wing_points,
    bbox_center,
    bbox_top_center,
    bbox_wireframe_polylines,
    draw_polyline,
    expand_linking_objects,
    filter_batch_lights,
    find_linking_entry,
    link_state_of_target,
    linking_collection_of,
    scene_used_collection,
    select_only,
)
from ...utils._constants import LINK_TYPE_ITEMS

# 条目状态候选项(切换钮写入值; 与原生 CollectionLightLinking.link_state 同枚举)
_LINK_STATE_ITEMS = (
    ('INCLUDE', "Include", ""),
    ('EXCLUDE', "Exclude", ""),
)


def _writable_panel_light(context: Context, op: Operator):
    """面板活跃灯光且可写(本地数据), 失败时 report 并返回 None"""
    light = panel_light(context)
    if light is None:
        op.report({'WARNING'}, report("No active light"))
        return None
    if light.library is not None:
        op.report({'WARNING'}, report("Linked lights cannot be edited"))
        return None
    return light


def _named_emitter(op: Operator):
    """按载荷名解析发射器灯(物体链接反查行指向面板活跃灯之外的灯), 不可写时 report"""
    light = bpy.data.objects.get(getattr(op, "emitter_name", ""))
    if light is None or light.type != 'LIGHT':
        return None
    if light.library is not None:
        op.report({'WARNING'}, report("Linked lights cannot be edited"))
        return None
    return light


def ensure_linking_collection(light, link_type: str):
    """灯的灯光/阴影链接集合, 缺失时新建并指派(命名与原生一致), 返回集合"""
    collection = linking_collection_of(light, link_type)
    if collection is not None:
        return collection
    name_format = "Light Linking for {}" if link_type == 'RECEIVER' else "Shadow Linking for {}"
    collection = bpy.data.collections.new(name_format.format(light.name))
    if link_type == 'RECEIVER':
        light.light_linking.receiver_collection = collection
    else:
        light.light_linking.blocker_collection = collection
    return collection


def _new_linking_collection(context: Context, op: Operator, link_type: str):
    """新建集合并指派为面板活跃灯光的链接集合, 返回 (light, collection); 失败返回 (None, None)"""
    light = _writable_panel_light(context, op)
    if light is None:
        return None, None
    if linking_collection_of(light, link_type) is not None:
        return light, None
    return light, ensure_linking_collection(light, link_type)


class _CollectionNewMixin:
    """template_ID 新建钮的共享实现(普通混入类, 不参与注册); link_type 由子类类属性给定

    灯光/阴影拆成两个算子类: template_ID 新建钮按链接类型各画各的, 指派的集合属性
    (receiver_collection/blocker_collection)也随之不同.
    """

    link_type = 'RECEIVER'

    @classmethod
    def poll(cls, context: Context):
        light = panel_light(context)
        return light is not None and light.library is None

    def execute(self, context: Context):
        light, collection = _new_linking_collection(context, self, self.link_type)
        if light is None:
            return {'CANCELLED'}
        if collection is None:
            self.report({'WARNING'}, report("The light already has a linking collection"))
            return {'CANCELLED'}
        return {'FINISHED'}


class LightLinkingReceiverCollectionNew(_CollectionNewMixin, Operator):
    """
    新建灯光链接集合操作器

    功能: 新建集合并指派为面板活跃灯光的灯光链接集合(template_ID 新建钮入口;
    原生同名算子绑定视口活动物体, 在面板语境会改错灯, 故按类型自建两枚)
    要求: 灯光面板有活跃灯光行且为本地数据
    """

    bl_idname = "ch.light_linking_receiver_collection_new"
    bl_label = "New Light Linking Collection"
    bl_description = "Create a new collection and assign it as the light/shadow linking collection of the active light of the Lights panel"
    bl_options = {'REGISTER', 'UNDO'}

    link_type = 'RECEIVER'


class LightLinkingBlockerCollectionNew(_CollectionNewMixin, Operator):
    """
    新建阴影链接集合操作器

    功能: 新建集合并指派为面板活跃灯光的阴影链接集合(同上, 与接收者钮按类型拆分)
    要求: 灯光面板有活跃灯光行且为本地数据
    """

    bl_idname = "ch.light_linking_blocker_collection_new"
    bl_label = "New Light Linking Collection"
    bl_description = "Create a new collection and assign it as the light/shadow linking collection of the active light of the Lights panel"
    bl_options = {'REGISTER', 'UNDO'}

    link_type = 'BLOCKER'


def _resolve_link_target(target_name: str, target_is_collection: bool):
    """按条目种类解析目标数据块(集合/物体), 不存在返回 None"""
    return bpy.data.collections.get(target_name) if target_is_collection else bpy.data.objects.get(target_name)


def _add_linking_member(collection, target_name: str, target_is_collection: bool, state: str = 'INCLUDE', target=None):
    """把目标以指定状态链入链接集合(已是成员则改写状态), 返回条目; 目标不存在返回 None

    target 为目标数据块引用(可选): 传入则直接用引用, 跳过按名解析——调用方手里已有
    引用时避免 bpy.data.get 命中同名对里的另一个块; 缺省仍按名解析.
    """
    if target is None:
        target = _resolve_link_target(target_name, target_is_collection)
    if target is None:
        return None
    entry = find_linking_entry(collection, target_name, target_is_collection)
    if entry is None:
        if target_is_collection:
            collection.children.link(target)
        else:
            collection.objects.link(target)
        entry = find_linking_entry(collection, target_name, target_is_collection)
        if entry is None:
            return None
    entry.light_linking.link_state = state
    return entry


class LightLinkingEntryAdd(Operator):
    """
    添加链接目标操作器

    功能: 把选中物体批量以包含状态加入活跃灯光的灯光/阴影链接集合(已是成员改回
    包含; 集合实例物体直接添加实例空体本身, 链接关系经实例化内容生效); +Shift
    改为加入当前视图层的活动集合
    要求: 活跃灯光已启用对应链接; 发射器自身不可链接
    """

    bl_idname = "ch.light_linking_entry_add"
    bl_label = "Add Selected Objects"
    bl_description = "Link the selected objects as included members of the active light's light/shadow linking collection\n+Shift: Add the current view layer's active collection instead"
    bl_options = {'REGISTER', 'UNDO'}

    link_type: EnumProperty(name="Link Type", items=LINK_TYPE_ITEMS, options={'HIDDEN'})  # type: ignore
    is_shift: bool = False

    @classmethod
    def poll(cls, context: Context):
        light = panel_light(context)
        return light is not None and light.library is None

    def invoke(self, context: Context, event: Event):
        self.is_shift = bool(event is not None and event.shift)
        return self.execute(context)

    def execute(self, context: Context):
        light = _writable_panel_light(context, self)
        if light is None:
            return {'CANCELLED'}
        collection = linking_collection_of(light, self.link_type)
        if collection is None:
            self.report({'WARNING'}, report("The light has no linking collection"))
            return {'CANCELLED'}
        if collection.library is not None:
            # 本地灯复制自链接资源时, 其链接集合指针仍指向库内集合: 链接集合不可写
            # (link 成员/改状态均报错), 提前取消而非逐个炸
            self.report({'WARNING'}, report("The light's linking collection is linked from a library"))
            return {'CANCELLED'}
        if scene_used_collection(collection):
            self.report({'ERROR'}, report("Light linking collection '{}' is used by a scene").format(collection.name))
            return {'CANCELLED'}
        entry = None
        name = ""
        if self.is_shift:
            # 5.1 的 ViewLayer 无 active_collection, 活动集合走 active_layer_collection 包装
            layer_collection = context.view_layer.active_layer_collection
            target_collection = layer_collection.collection if layer_collection is not None else None
            if target_collection is None:
                self.report({'WARNING'}, report("No active collection"))
                return {'CANCELLED'}
            if target_collection == collection:
                self.report({'WARNING'}, report("Cannot link a collection into itself"))
                return {'CANCELLED'}
            name = target_collection.name
            try:
                entry = _add_linking_member(collection, name, True, target=target_collection)
            except RuntimeError as e:
                self.report({'WARNING'}, str(e))
                return {'CANCELLED'}
        else:
            # 集合实例物体直接添加实例空体本身(作者实测: 原生面板支持直接添加,
            # 链接关系经实例空体作用于实例化内容)
            targets = [obj for obj in context.selected_objects if obj != light]
            if not targets:
                self.report({'WARNING'}, report("No selected objects to link"))
                return {'CANCELLED'}
            added = 0
            for obj in targets:
                if _add_linking_member(collection, obj.name, False, 'INCLUDE', target=obj) is not None:
                    added += 1
            if added == 0:
                self.report({'WARNING'}, report("No selected objects to link"))
                return {'CANCELLED'}
            self.report({'INFO'}, report("Linked {} objects").format(added))
            return {'FINISHED'}
        if entry is None:
            self.report({'WARNING'}, report("No selected objects to link"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Linked: {}").format(name))
        return {'FINISHED'}


class _EntryStateSetMixin:
    """行内链接状态切换钮的共享实现(普通混入类, 不参与注册); link_type 由子类类属性给定

    灯光/阴影拆成两个算子类是必须的: 反查行同一行画两枚切换钮, 同 bl_idname 的按钮
    重绘期按名字匹配复用属性, 后画钮的载荷会串到先画钮上.
    """

    link_type = 'RECEIVER'

    def execute(self, context: Context):
        light = _named_emitter(self)
        if light is None:
            self.report({'WARNING'}, report("No such light"))
            return {'CANCELLED'}
        # 先解析目标再建集合: 目标缺失直接取消, 不留下"集合已建未链成员"的半完成态
        target = _resolve_link_target(self.target_name, self.target_is_collection)
        if target is None:
            self.report({'WARNING'}, report("Not a direct member of the linking collection"))
            return {'CANCELLED'}
        collection = ensure_linking_collection(light, self.link_type)
        if scene_used_collection(collection):
            self.report({'ERROR'}, report("Light linking collection '{}' is used by a scene").format(collection.name))
            return {'CANCELLED'}
        entry = find_linking_entry(collection, self.target_name, self.target_is_collection)
        if entry is None:
            try:
                entry = _add_linking_member(collection, self.target_name, self.target_is_collection, self.state, target=target)
            except RuntimeError as e:
                self.report({'WARNING'}, str(e))
                return {'CANCELLED'}
            if entry is None:
                self.report({'WARNING'}, report("Not a direct member of the linking collection"))
                return {'CANCELLED'}
            return {'FINISHED'}
        entry.light_linking.link_state = self.state
        return {'FINISHED'}


class LightLinkingEntryStateSet(_EntryStateSetMixin, Operator):
    """
    切换成员链接状态操作器(灯光链接侧)

    功能: 把指名目标的包含/排除状态写回灯侧条目(反查视图与集合视图两处入口共用);
    目标尚未加入该集合时先加入再置态, 该灯缺失链接集合时先建集合(反查行"未加入"态
    点击即加入的入口); 已加入但为间接成员(经子集合)时, 翻转在该灯链接集合生成直连
    条目覆盖嵌套态, 只影响该灯
    """

    bl_idname = "ch.light_linking_entry_state_set"
    bl_label = "Set Link State"
    bl_description = "Toggle between included and excluded, adding the target to the light's linking collection when it is not a member yet"
    bl_options = {'REGISTER', 'UNDO'}

    link_type = 'RECEIVER'
    emitter_name: StringProperty(name="Emitter", options={'HIDDEN'})  # type: ignore
    target_name: StringProperty(name="Target", options={'HIDDEN'})  # type: ignore
    target_is_collection: BoolProperty(name="Target Is Collection", options={'HIDDEN'})  # type: ignore
    state: EnumProperty(name="Link State", items=_LINK_STATE_ITEMS, options={'HIDDEN'})  # type: ignore


class LightLinkingEntryStateSetShadow(_EntryStateSetMixin, Operator):
    """
    切换成员链接状态操作器(阴影链接侧)

    功能: 同灯光链接侧, 写回该灯阴影链接集合的条目状态; 与灯光侧拆成两个算子类,
    反查行同行的两枚切换钮各绑各的 bl_idname, 不因同 idname 串载荷
    """

    bl_idname = "ch.light_linking_entry_state_set_shadow"
    bl_label = "Set Link State"
    bl_description = "Toggle between included and excluded, adding the target to the light's linking collection when it is not a member yet"
    bl_options = {'REGISTER', 'UNDO'}

    link_type = 'BLOCKER'
    emitter_name: StringProperty(name="Emitter", options={'HIDDEN'})  # type: ignore
    target_name: StringProperty(name="Target", options={'HIDDEN'})  # type: ignore
    target_is_collection: BoolProperty(name="Target Is Collection", options={'HIDDEN'})  # type: ignore
    state: EnumProperty(name="Link State", items=_LINK_STATE_ITEMS, options={'HIDDEN'})  # type: ignore


class LightLinkingEntryRemove(Operator):
    """
    移除链接成员操作器

    功能: 把指名成员从该灯的灯光/阴影链接集合移除(解除条目, 不删集合与物体)
    要求: 成员是该集合的直接成员
    """

    bl_idname = "ch.light_linking_entry_remove"
    bl_label = "Remove from Linking"
    bl_description = "Remove this member from the light's linking collection\nObject list rows: removes both the light link and the shadow link entries when direct"
    bl_options = {'REGISTER', 'UNDO'}

    link_type: EnumProperty(name="Link Type", items=LINK_TYPE_ITEMS, options={'HIDDEN'})  # type: ignore
    emitter_name: StringProperty(name="Emitter", options={'HIDDEN'})  # type: ignore
    target_name: StringProperty(name="Target", options={'HIDDEN'})  # type: ignore
    target_is_collection: BoolProperty(name="Target Is Collection", options={'HIDDEN'})  # type: ignore
    also_shadow: BoolProperty(name="Also Shadow", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        light = _named_emitter(self)
        if light is None:
            self.report({'WARNING'}, report("No such light"))
            return {'CANCELLED'}
        link_types = ('RECEIVER', 'BLOCKER') if self.also_shadow else (self.link_type,)
        # 先完成全部集合存在性与场景占用检查, 全过后再统一 unlink——also_shadow 时
        # 任一侧被占用须整体不动, 不能先把另一侧移除掉(部分完成)
        writable = []
        for link_type in link_types:
            collection = linking_collection_of(light, link_type)
            if collection is None:
                continue
            if collection.library is not None:
                # 本地灯复制自链接资源时链接集合指针指向库内集合: 不可 unlink, 与场景占用
                # 同款"整体不动"口径(also_shadow 时不允许部分完成)
                self.report({'WARNING'}, report("The light's linking collection is linked from a library"))
                return {'CANCELLED'}
            if scene_used_collection(collection):
                self.report({'ERROR'}, report("Light linking collection '{}' is used by a scene").format(collection.name))
                return {'CANCELLED'}
            writable.append(collection)
        removed = 0
        for collection in writable:
            if self.target_is_collection:
                member = next((child for child in collection.children if child.name == self.target_name), None)
                if member is None:
                    continue
                collection.children.unlink(member)
            else:
                member = next((obj for obj in collection.objects if obj.name == self.target_name), None)
                if member is None:
                    continue
                collection.objects.unlink(member)
            removed += 1
        if removed == 0:
            self.report({'WARNING'}, report("Not a direct member of the linking collection"))
            return {'CANCELLED'}
        return {'FINISHED'}


class LightLinkingCollectionSingleUser(Operator):
    """
    独立化链接集合操作器

    功能: 载荷指名的灯光/阴影链接集合被多灯共享时, 复制一份指派回该灯(成员与
    包含/排除状态随副本保留, 与"使其独立化"同语义); 行内数字即共享灯数
    要求: 集合确实被多于 1 盏灯引用(行内钮按用户数置灰兜底)
    """

    bl_idname = "ch.light_linking_collection_single_user"
    bl_label = "Make Single User"
    bl_description = "Copy the shared light/shadow linking collection so this light gets its own (members and their include/exclude states are preserved); the row number is how many lights share the collection"
    bl_options = {'REGISTER', 'UNDO'}

    emitter_name: StringProperty(name="Emitter", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        light = _named_emitter(self)
        if light is None:
            self.report({'WARNING'}, report("No such light"))
            return {'CANCELLED'}
        lights = [obj for obj in blocks_for(context, "lights") if obj is not None]
        made = []
        for link_type in ('RECEIVER', 'BLOCKER'):
            collection = linking_collection_of(light, link_type)
            if collection is None:
                continue
            sharers = [obj for obj in lights if obj.library is None and linking_collection_of(obj, link_type) is collection]
            if len(sharers) <= 1:
                continue
            own = collection.copy()
            if link_type == 'RECEIVER':
                light.light_linking.receiver_collection = own
            else:
                light.light_linking.blocker_collection = own
            made.append(own.name)
        if not made:
            self.report({'WARNING'}, report("Linking collection is not shared"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Made single user: {}").format(", ".join(made)))
        return {'FINISHED'}


class LightLinkingSelectTargets(Operator):
    """
    选中链接目标操作器

    功能: 在3D视口中选中活跃灯光的链接集合展开后的全部物体(接收者或阴影遮挡者)
    要求: 活跃灯光已启用对应链接; 只读算子, 库链接灯光也可用
    """

    bl_idname = "ch.light_linking_select_targets"
    bl_label = "Select Receivers"
    bl_description = "Select all objects that receive light from (or cast shadows for) the active light of the Lights panel in the 3D viewport"
    bl_options = {'REGISTER', 'UNDO'}

    link_type: EnumProperty(name="Link Type", items=LINK_TYPE_ITEMS, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return panel_light(context) is not None

    def execute(self, context: Context):
        light = panel_light(context)
        if light is None:
            self.report({'WARNING'}, report("No active light"))
            return {'CANCELLED'}
        collection = linking_collection_of(light, self.link_type)
        if collection is None:
            self.report({'WARNING'}, report("The light has no linking collection"))
            return {'CANCELLED'}
        targets = expand_linking_objects(collection)
        select_only(context, targets, active=targets[0] if targets else None)
        self.report({'INFO'}, report("Selected {} objects").format(len(targets)))
        return {'FINISHED'}


class LightLinkingFocusEmitter(Operator):
    """
    定位反查灯光操作器

    功能: 把物体链接反查行指向的灯设为灯光面板列表的活跃项(联动查看该灯的链接配置)
    """

    bl_idname = "ch.light_linking_focus_emitter"
    bl_label = "Focus Light"
    bl_description = "Highlight this light in the Lights panel list"
    bl_options = {'REGISTER'}

    emitter_name: StringProperty(name="Emitter", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        highlight_item(context, "lights", self.emitter_name)
        return {'FINISHED'}


# 三色语义与线宽进偏好(接入且激活按测分色黄/紫, 接入未激活统一取偏好单色, 默认淡绿)
# 箭头长度按线长比例取值并设下限(过短的连线仍保可辨识的箭头)
_ARROW_LENGTH_RATIO = 0.07
_ARROW_MIN_LENGTH = 0.08


def _preview_color(prefs, link_type: str, state: str):
    """预览线颜色: 接入且激活按测取偏好色, 接入未激活(排除)统一取偏好单色(默认淡绿)"""
    if state == 'EXCLUDE':
        return tuple(prefs.light_linking_preview_inactive_color)
    if link_type == 'RECEIVER':
        return tuple(prefs.light_linking_preview_receiver_color)
    return tuple(prefs.light_linking_preview_blocker_color)


class _SyncMixin:
    """灯光/阴影链接同步钮的共享实现(普通混入类, 不参与注册); link_type 与写回属性名由子类类属性给定

    灯光/阴影拆成两个算子类: 饼菜单两区块各画一枚, label/description 按链接类型分述.
    """

    link_type = 'RECEIVER'
    collection_prop = "receiver_collection"

    @classmethod
    def poll(cls, context: Context):
        obj = context.object
        return obj is not None and obj.type == 'LIGHT' and obj.library is None

    def execute(self, context: Context):
        source = context.object
        collection = linking_collection_of(source, self.link_type)
        if collection is None:
            self.report({'WARNING'}, report("The light has no linking collection"))
            return {'CANCELLED'}
        batch, _linked = filter_batch_lights(context.selected_objects, require_controller=False)
        targets = [light for light in batch if light != source and light.library is None]
        if not targets:
            self.report({'WARNING'}, report("No lights in the selection"))
            return {'CANCELLED'}
        for light in targets:
            setattr(light.light_linking, self.collection_prop, collection)
        self.report({'INFO'}, report("Synced {} lights").format(len(targets)))
        return {'FINISHED'}


class LightLinkingReceiverSync(_SyncMixin, Operator):
    """
    同步灯光链接操作器

    功能: 把活动灯的灯光链接集合数据块共享给选中集筛选出的每一盏本地灯(共享而非
    复制——此后在任一灯侧编辑成员与状态, 全部共享灯同步生效); 活动灯未启用灯光链接
    时拒绝(不做"清空同步")
    要求: 活动物体为本地灯; 选中集里有除活动灯之外的本地灯
    """

    bl_idname = "ch.light_linking_receiver_sync"
    bl_label = "Sync Light Linking"
    bl_description = "Share the active light's light linking collection with every selected light (the collection data-block is shared, so edits affect all of them)"
    bl_options = {'REGISTER', 'UNDO'}

    link_type = 'RECEIVER'
    collection_prop = "receiver_collection"


class LightLinkingBlockerSync(_SyncMixin, Operator):
    """
    同步阴影链接操作器

    功能: 把活动灯的阴影链接集合数据块共享给选中集筛选出的每一盏本地灯(共享而非复制)
    要求: 活动物体为本地灯; 选中集里有除活动灯之外的本地灯
    """

    bl_idname = "ch.light_linking_blocker_sync"
    bl_label = "Sync Shadow Linking"
    bl_description = "Share the active light's shadow linking collection with every selected light (the collection data-block is shared, so edits affect all of them)"
    bl_options = {'REGISTER', 'UNDO'}

    link_type = 'BLOCKER'
    collection_prop = "blocker_collection"


class LightLinkPreviewMixin:
    """链接关系预览模态混入(纯类, 不参与注册; 四枚预览算子共用的交互与绘制)

    主体与链接类型由派生类的 subject_is_light / link_type 类属性给定; 派生类另须
    声明 bl_idname/bl_label/bl_description/bl_options(本类不继承 Operator, 否则
    auto_load 会把无 bl_label 的抽象基类当算子注册)
    """

    subject_is_light: bool = True
    link_type: str = 'RECEIVER'

    @classmethod
    def poll(cls, context: Context):
        obj = context.object
        if cls.subject_is_light:
            return obj is not None and obj.type == 'LIGHT'
        return obj is not None

    def execute(self, context: Context):
        # 模态算子直调守卫(规范 10.2): report WARNING + CANCELLED, 不复入 invoke
        self.report({'WARNING'}, report("This operator runs interactively in the 3D view"))
        return {'CANCELLED'}

    def _resolve(self, context: Context):
        """解析预览几何(线段/箭头/边界盒线框), 无可预览关系返回 None"""
        subject = context.object
        lines = []
        arrows = []
        wires = []
        if self.subject_is_light:
            collection = linking_collection_of(subject, self.link_type)
            if collection is None:
                return None
            targets = expand_linking_objects(collection)
            if not targets:
                return None
            start = subject.matrix_world.translation.copy()
            for target in targets:
                end = bbox_top_center(target)
                if end is None:
                    continue
                state = link_state_of_target(collection, target.name)
                lines.append((start.copy(), end, state))
                direction = end - start
                wings = arrow_wing_points(end, direction, max(direction.length * _ARROW_LENGTH_RATIO, _ARROW_MIN_LENGTH))
                if wings is not None:
                    arrows.append((wings[0], end.copy(), wings[1], state))
                wires.extend((polyline, state) for polyline in bbox_wireframe_polylines(target))
        else:
            lights = [light for light in blocks_for(context, "lights") if light is not None]
            start = bbox_center(subject)
            if start is None:
                return None
            for light in lights:
                collection = linking_collection_of(light, self.link_type)
                if collection is None:
                    continue
                state = link_state_of_target(collection, subject.name)
                if state is None:
                    continue
                end = light.matrix_world.translation.copy()
                lines.append((start.copy(), end, state))
                direction = end - start
                wings = arrow_wing_points(end, direction, max(direction.length * _ARROW_LENGTH_RATIO, _ARROW_MIN_LENGTH))
                if wings is not None:
                    arrows.append((wings[0], end.copy(), wings[1], state))
        if not lines:
            return None
        return {"lines": lines, "arrows": arrows, "wires": wires}

    def invoke(self, context: Context, event: Event):
        if context.region_data is None:
            # 后台无视图: 交互不成立, 走直调守卫口径
            return self.execute(context)
        data = self._resolve(context)
        if data is None:
            self.report({'WARNING'}, report("No linking relation to preview"))
            return {'CANCELLED'}
        self._preview_data = data
        self.init_status(context, func=_draw_preview_status(self))
        self.init_modal_handlers(context)
        self.init_view_draw(self._draw_preview)
        force_ui_update(context)
        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 走区域失效守卫的最小收敛(不触碰依赖 area 的接口)
            self._abort_without_area(context)
            force_statusbar_redraw(context)
            return {'CANCELLED'}
        if ignore_events(event):
            return {'RUNNING_MODAL'}
        if navigation_passthrough(event):
            # 视图导航放行: 预览期可旋转视图从各角度查看连线
            return {'PASS_THROUGH'}
        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            # 滚轮缩放放行: 预览期可缩放视图查看连线细节
            return {'PASS_THROUGH'}
        if event.value == 'PRESS' and event.type in {'LEFTMOUSE', 'RET'}:
            self._finish(context)
            return {'FINISHED'}
        if event.value == 'PRESS' and event.type in {'ESC', 'RIGHTMOUSE'}:
            self._finish(context)
            return {'CANCELLED'}
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def _finish(self, context: Context) -> None:
        """收尾(生命周期调用序): 状态栏 -> 模态处理器 -> 视图绘制 -> UI 刷新

        本模态不走 header 数值显示, 无 header 文本可清除.
        """
        self.finish_status()
        self.finish_modal_handlers()
        self.finish_view_draw()
        force_statusbar_redraw(context)
        force_ui_update(context)

    def _draw_preview(self):
        """预览绘制(静态几何 invoke 期解析一次; 绘制回调无 bpy.context, 只读快照)"""
        data = self._preview_data
        prefs = get_prefs()
        colors = {state: _preview_color(prefs, self.link_type, state) for state in ('INCLUDE', 'EXCLUDE')}
        for start, end, state in data["lines"]:
            draw_polyline((start, end), (colors[state], colors[state]), width=prefs.light_linking_preview_line_width)
        for wing_a, tip, wing_b, state in data["arrows"]:
            draw_polyline((wing_a, tip, wing_b), (colors[state],) * 3, width=prefs.light_linking_preview_line_width)
        for polyline, state in data["wires"]:
            draw_polyline(polyline, (colors[state],) * len(polyline), width=prefs.light_linking_preview_line_width)


def _draw_preview_status(op):
    """模态状态栏: 关闭/取消组合键提示(键位门与文案对齐 _draw_basic_status 基础行)"""

    def draw(self, context: Context):
        row = self.layout.row(align=True)
        draw_status_item(row, key='LMB', text="Finish")
        # 键位门大小写不敏感: 工厂方案名实测为 "Blender"(首字母大写), 小写比较恒 False
        if context.window_manager.keyconfigs.active.name.lower().startswith('blender'):
            draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

    return draw


class LightLinkReceiverPreview(ModalOperatorMixin, LightLinkPreviewMixin, Operator):
    """灯光链接物体预览: 从活动灯引线到每个被灯光链接物体的边界盒顶面中心"""

    bl_idname = "ch.light_linking_receiver_preview"
    bl_options = {'REGISTER'}
    bl_label = "Light Link Objects Preview"
    bl_description = "Preview the light linking relations of the active light: lines run from the light to the top center of every linked object's bounding box, and the boxes draw as wireframes. LMB or Enter closes the preview"

    subject_is_light = True
    link_type = 'RECEIVER'


class LightLinkBlockerPreview(ModalOperatorMixin, LightLinkPreviewMixin, Operator):
    """阴影链接物体预览: 从活动灯引线到每个被阴影链接物体的边界盒顶面中心"""

    bl_idname = "ch.light_linking_blocker_preview"
    bl_options = {'REGISTER'}
    bl_label = "Shadow Link Objects Preview"
    bl_description = "Preview the shadow linking relations of the active light: lines run from the light to the top center of every shadow-linked object's bounding box, and the boxes draw as wireframes. LMB or Enter closes the preview"

    subject_is_light = True
    link_type = 'BLOCKER'


class LightLinkObjectReceiverPreview(ModalOperatorMixin, LightLinkPreviewMixin, Operator):
    """物体灯光链接预览: 从活动物体中心引线到灯光链接它的每盏灯"""

    bl_idname = "ch.light_linking_object_receiver_preview"
    bl_options = {'REGISTER'}
    bl_label = "Object Light Link Preview"
    bl_description = "Preview which lights light-link the active object: lines run from the object's bounding box center to each of those lights. LMB or Enter closes the preview"

    subject_is_light = False
    link_type = 'RECEIVER'


class LightLinkObjectBlockerPreview(ModalOperatorMixin, LightLinkPreviewMixin, Operator):
    """物体阴影链接预览: 从活动物体中心引线到阴影链接它的每盏灯"""

    bl_idname = "ch.light_linking_object_blocker_preview"
    bl_options = {'REGISTER'}
    bl_label = "Object Shadow Link Preview"
    bl_description = "Preview which lights shadow-link the active object: lines run from the object's bounding box center to each of those lights. LMB or Enter closes the preview"

    subject_is_light = False
    link_type = 'BLOCKER'
