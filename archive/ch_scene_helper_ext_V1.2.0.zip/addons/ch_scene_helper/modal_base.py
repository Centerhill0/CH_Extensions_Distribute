"""
模态算子基类模块(ch_scene_helper 自持裁剪版)

与 ch_utils_tools 的 modal_base.py 同源分叉: 跨插件不可导入对方模块(打包器会沿
import 连带复制源码, 产出第二份同名 bl_idname 的算子类), 且本插件无 HUD 绘制栈
与模态偏好——数值反馈统一走 header_text_set, 绘制侧只需一个 3D 视图回调(模态轨迹
预览), 故只保留鼠标基线/模态处理器/状态栏/区域失效守卫/视图绘制回调, HUD 绘制栈
与计时器相关结构裁去.

主要功能:
- ModalOperatorMixin: 模态算子 Mixin(鼠标基线 / 模态处理器 / 状态栏 / 区域守卫 / 视图绘制)
- init_view_draw / finish_view_draw: 单个 3D 视图绘制回调的注册与摘除(轨迹预览)
- ignore_events / navigation_passthrough / force_ui_update: 模态事件纯函数
- 状态栏带异常自还原保护(模态异常退出后不残留自定义绘制回调)

生命周期调用序(与代码规范 §9 一致):
- invoke: init_mouse_position -> init_status -> init_modal_handlers -> init_view_draw -> force_ui_update
- modal: _abort_without_area 守卫 -> ignore_events -> tag_redraw -> 事件分发
- finish: finish_status -> finish_modal_handlers -> finish_view_draw -> header_text_set(None) -> force_ui_update
"""

from bpy.types import Context, Event, UILayout
from bl_ui.space_statusbar import STATUSBAR_HT_header as statusbar

from .utils.drawing import register_view_draw, unregister_view_draw

# 光标包裹带宽度(像素): 光标距区域边缘不足此值即跳到对侧
_WRAP_MARGIN = 10

# 鼠标类键的图标前缀(其余键走 EVENT_ 前缀; 与 ch_utils_tools 的键名约定一致)
_MOUSE_STATUS_KEYS = {'LMB', 'MMB', 'RMB', 'MOVE', 'MMB_SCROLL', 'LMB_DRAG', 'RMB_DRAG'}

# 模态期应忽略的事件类型(模块级常量: 每事件判定的热路径不做重复分配)
_IGNORE_EVENT_TYPES = frozenset({'INBETWEEN_MOUSEMOVE', 'WINDOW_DEACTIVATE', 'NONE', 'TIMER', 'TIMER1', 'TIMER2', 'TIMER3', 'TIMER_REPORT'})


def draw_status_item(layout: UILayout, key=None, text: str = "", active: bool = True, gap=None) -> None:
    """状态栏组合键提示项(键图标 + 文案; ch_utils_tools 同名纯函数的自持裁剪版,

    key 用其同款字符串约定: 'LMB'/'MMB'/'RMB'/'MOVE' 走 MOUSE_ 图标, 字母键走 EVENT_ 图标;
    修饰键图标(Ctrl/Alt 等)后补分隔——否则图标与后续文案重叠(chamfer 同款处理))
    """
    row = layout.row(align=True)
    row.active = active
    keys = (key,) if isinstance(key, str) else (key or ())
    if gap:
        row.separator(factor=gap)
    for item in keys:
        icon = "MOUSE_{}".format(item) if item in _MOUSE_STATUS_KEYS else "EVENT_{}".format(item)
        row.label(text="", icon=icon)
        if icon in {'EVENT_CTRL', 'EVENT_ALT', 'EVENT_OS', 'EVENT_COMMAND'}:
            row.separator(factor=1.5)
    if text:
        row.label(text=text)


def ignore_events(event: Event) -> bool:
    """判断事件类型是否应被忽略(窗口失活/帧间移动/定时器)"""
    return event.type in _IGNORE_EVENT_TYPES


def navigation_passthrough(event: Event, alt=True) -> bool:
    """判断事件是否应交给导航系统处理(MMB 旋转/NDOF/Alt+点击)"""
    if event.type == 'MIDDLEMOUSE' and event.value == 'PRESS':
        return True
    if event.type.startswith('NDOF'):
        return True
    if alt and event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} and event.value == 'PRESS':
        return True
    return False


def force_ui_update(context: Context) -> None:
    """强制刷新界面(程序化写入不触发重绘时的兜底; 本插件算子只在物体模式运行)"""
    if context.mode == 'OBJECT':
        if active := context.active_object:
            active.select_set(active.select_get())
        elif visible := context.visible_objects:
            visible[0].select_set(visible[0].select_get())


def force_statusbar_redraw(context: Context) -> None:
    """强制刷新状态栏区域(恢复 statusbar.draw 后不 tag 会让旧自绘内容残留,

    ch_utils_tools 同名纯函数的自持副本)
    """
    for window in context.window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            # 窗口拆卸态 screen 为 None(与 tag_3d_views 的守卫同口径)
            continue
        for area in screen.areas:
            if area.type == 'STATUSBAR':
                area.tag_redraw()


class ModalOperatorMixin:
    """模态算子 Mixin

    为模态 Operator 提供鼠标基线/模态处理器/状态栏/区域守卫等交互辅助方法;
    算子在 invoke 中调用 init_mouse_position -> init_status -> init_modal_handlers,
    在 finish 流程中调用 finish_status -> finish_modal_handlers(顺序见模块 docstring).
    """

    def init_mouse_position(self, event: Event) -> None:
        """记录鼠标窗口坐标并建立调值基线(每帧增量由此起算)"""
        self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y

    def wrap_mouse_position(self, context: Context, event: Event) -> bool:
        """光标进入区域边缘包裹带时跳到对侧(模态调值可连续拖动不回头)

        发生包裹时返回 True 并把调值基线重置到落点: 调用方须跳过本帧的数值更新,
        下一帧增量从落点重新起算, 避免光标跳变导致数值突变(与 ch_utils_tools
        同名方法同契约; 本插件无对应偏好, 恒启用).
        """
        mouse_x, mouse_y = event.mouse_region_x, event.mouse_region_y
        region_width, region_height = context.region.width, context.region.height
        region_offset_x = event.mouse_x - event.mouse_region_x
        region_offset_y = event.mouse_y - event.mouse_region_y
        # 两缘包裹带重叠(区域过窄)时禁用该轴, 避免无限乒乓
        wrap_x = _WRAP_MARGIN * 2 < region_width
        wrap_y = _WRAP_MARGIN * 2 < region_height
        new_mouse_x, new_mouse_y = None, None
        if wrap_x:
            if mouse_x < _WRAP_MARGIN:
                new_mouse_x = region_width + region_offset_x - _WRAP_MARGIN
            elif mouse_x > region_width - _WRAP_MARGIN:
                new_mouse_x = region_offset_x + _WRAP_MARGIN
        if wrap_y:
            if mouse_y < _WRAP_MARGIN:
                new_mouse_y = region_height + region_offset_y - _WRAP_MARGIN
            elif mouse_y > region_height - _WRAP_MARGIN:
                new_mouse_y = region_offset_y + _WRAP_MARGIN
        if new_mouse_x is None and new_mouse_y is None:
            return False
        if new_mouse_x is None:
            new_mouse_x = event.mouse_x
        if new_mouse_y is None:
            new_mouse_y = event.mouse_y
        context.window.cursor_warp(new_mouse_x, new_mouse_y)
        self.last_mouse_x, self.last_mouse_y = new_mouse_x, new_mouse_y
        return True

    def init_modal_handlers(self, context: Context) -> None:
        """记录当前区域并注册为模态处理器(视图绘制回调由 init_view_draw 单独注册)

        返回 False(无窗口等)时调用方应走本地收敛, 不再返回 RUNNING_MODAL.
        """
        self.area = context.area
        if not context.window_manager.modal_handler_add(self):
            raise RuntimeError("modal_handler_add failed")

    def finish_modal_handlers(self) -> None:
        """清理模态处理器记录(无绘制回调/计时器, 保留结构对齐生命周期调用序)"""
        self.area = None

    def init_view_draw(self, draw_func) -> None:
        """注册 3D 视图绘制回调(本插件仅轨迹预览使用, 单个句柄)

        draw_func 为无参回调: 回调内没有可信的 bpy.context, 偏好与物体变换由回调自身读取.
        """
        self.view_draw_handle = register_view_draw(draw_func)

    def finish_view_draw(self) -> None:
        """摘除 3D 视图绘制回调(重复调用安全; 区域失效路径亦须调用)"""
        handle = getattr(self, 'view_draw_handle', None)
        if handle is not None:
            unregister_view_draw(handle)
            self.view_draw_handle = None

    def _abort_without_area(self, context: Context) -> None:
        """所在区域已失效(关闭视图/切换工作区)时的最小收敛

        只收敛状态栏/处理器/光标, 不触碰 header_text_set 与 tag_redraw——它们依赖
        context.area, 而 area 为 None 正是调用本方法的前提; 不守卫则每个后续事件
        都抛 AttributeError 且模态永不收敛(与 ch_utils_tools 同口径).
        """
        self.finish_status()
        self.finish_modal_handlers()
        self.finish_view_draw()
        try:
            # 状态栏是窗口级独立区域, 不依赖失效的 context.area: 摘除自绘项后显式
            # 刷新, 避免按键提示残留到下一次状态栏重绘(规则10 的最小收敛变体)
            force_statusbar_redraw(context)
        except AttributeError:
            pass  # window 亦不可得时无从刷新, 交由后续用户交互复位
        try:
            context.window.cursor_set('DEFAULT')
        except AttributeError:
            pass  # window 亦不可得时无从恢复, 交由后续用户交互复位

    def init_status(self, context: Context, title: str = '', func=None) -> None:
        """初始化状态栏显示函数, 附带异常退出后的自动还原保护

        Args:
            context: Blender 上下文
            title: 状态栏标题(func 为空时的后备路径, 本插件当前调用均传 func)
            func: 自定义状态栏绘制函数(可选)
        """
        if getattr(statusbar.draw, "is_ch_status_patch", False):
            # 热重载残留的上一代补丁(其捕获的原装 draw 已随旧模块丢失): 不再捕获,
            # 直接顶掉——恢复链此时已断, 只有重启 Blender 能复位
            self.bar_orig = None
        else:
            self.bar_orig = statusbar.draw
        wrapper = _self_restoring_status(func if func else _draw_basic_status(title), self.bar_orig)
        wrapper.is_ch_status_patch = True
        statusbar.draw = wrapper

    def finish_status(self) -> None:
        """恢复原始状态栏绘制函数"""
        if getattr(self, 'bar_orig', None) is not None:
            statusbar.draw = self.bar_orig


def _self_restoring_status(draw_func, bar_orig):
    """返回带自动还原保护的状态栏绘制回调

    模态算子异常退出后, 状态栏绘制回调中访问已释放实例会抛出ReferenceError,
    此时自动恢复原始状态栏绘制函数, 避免状态栏被残留回调永久占据.
    bar_orig 为 None(热重载缠住恢复链)时无原装可还原, 保持补丁直到重启.
    """

    def draw(self, context: Context):
        try:
            draw_func(self, context)
        except Exception:
            # 绘制回调内异常不吞会每帧向控制台刷错(与 utils.drawing.view3d 同款口径);
            # ReferenceError(实例已释放)之外, 等待模态运行时在偏好窗口禁用本插件等路径
            # 同样无法自愈——一律还原原装 draw, 保留补丁只会让错误每帧重演
            if bar_orig is not None:
                statusbar.draw = bar_orig

    return draw


def _draw_basic_status(title: str):
    """基础状态栏绘制函数: 标题 + 左键完成 / 中键导航 / 右键取消"""

    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)
        row.label(text=title)
        row.label(text="", icon='MOUSE_LMB')
        row.label(text="Finish")
        # 键位门大小写不敏感: 工厂方案名实测为 "Blender"(首字母大写), 小写比较恒 False
        if context.window_manager.keyconfigs.active.name.lower().startswith('blender'):
            row.label(text="", icon='MOUSE_MMB')
            row.label(text="Viewport Navigation")
        row.label(text="", icon='MOUSE_RMB')
        row.label(text="Cancel")

    return draw
