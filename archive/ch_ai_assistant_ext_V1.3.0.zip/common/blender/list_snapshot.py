"""
UI 列表快照共享模块

提供以下功能:
- ListItem: 列表条目属性组(name 双击可编辑并写穿到真实数据块, src_name 记录快照时真名, kind 标注数据块类型)
- rebuild_if_changed: 列表快照按 (名称, 类型) 序列差异重建, 活跃索引压回有效范围(返回是否重建)
- rename_datablock / on_item_name_update: 条目名编辑写穿到真实数据块(物体/材质/文本/图像/世界; 失败回写旧名)
- set_index / guarded / is_syncing: 可重入的护栏(处理器驱动的索引/条目名写入期间, 列表 update 回调见位即跳过)
- set_index_after_removal / clamp_index: 删除条目后的活跃索引夹取
- find_item_index / set_index_by_name: 按真实名(+ 类型)定位快照条目并写活跃索引
- StandardFilterMixin / standard_filter: UIList 内建名称过滤与排序控件行为
  (字母排序关闭时保持快照序; 反序由 Blender 显示层统一应用, 本模块不重复取反)
- 列表顺序值(上移/下移/按名称排序的持久顺序)见 common/blender/list_order.py

供 ch_scene_helper(六个资源列表)与 ch_ai_assistant(脚本/图像列表)共用;
ListItem 为 PropertyGroup, 经各插件包内的 class_loader 自动注册.

注: common 的共用算法统一放本子包(common/blender/, 暂不再细分), 见 blender-addon-code-style 技能 §6.1.
"""

from contextlib import contextmanager

import bpy
from bpy.props import StringProperty
from bpy.types import Context, PropertyGroup

# 重入护栏深度: 处理器驱动的索引/条目名写入期间 > 0, 列表的 update 回调见位即跳过.
# 只有用户点击列表行或编辑条目名才联动选中/重命名, 避免同步 -> 选中 -> 再同步的循环,
# 以及快照重建把索引压回时误选无关物体. 用深度而非布尔值: 护栏内的 set_index 会嵌套进入.
_sync_depth = 0


def is_syncing() -> bool:
    """是否处于护栏内的程序化写入期间(列表 update 回调据此跳过联动)"""
    return _sync_depth > 0


@contextmanager
def guarded():
    """进入重入护栏(可嵌套), 退出时恢复上一层状态"""
    global _sync_depth
    _sync_depth += 1
    try:
        yield
    finally:
        _sync_depth -= 1


def set_guarded(state, attr_name: str, value):
    """护栏内写入状态属性(该属性的 update 联动回调见位即跳过)"""
    with guarded():
        setattr(state, attr_name, value)


def set_index(state, index_name: str, value: int):
    """护栏内写入列表活跃索引(不触发列表的选中回调)"""
    set_guarded(state, index_name, value)


def clamp_index(value: int, count: int) -> int:
    """把活跃索引夹进 [0, count - 1]; 空列表回落 0"""
    return min(max(value, 0), max(count - 1, 0))


def set_index_after_removal(state, index_name: str, remaining: int, idx: int) -> None:
    """删除条目后把活跃索引压回有效范围(护栏内写入, 不触发列表选中回调)

    Args:
        state: 列表快照状态组实例
        index_name: 活跃索引属性名
        remaining: 删除后的条目数(非集合对象, 免得调用方各自判空)
        idx: 原活跃索引
    """
    set_index(state, index_name, clamp_index(idx, remaining))


def find_item_index(state, coll_name: str, name: str, item_kind: str = "") -> int:
    """按真实名(+ 可选类型)查找快照条目, 返回索引; 未命中返回 -1

    Args:
        state: 列表快照状态组实例
        coll_name: 集合属性名(如 "materials")
        name: 真实数据块名称(src_name)
        item_kind: 可选类型标签(混排列表用, 如灯光列表的 MATERIAL); 空串表示不限定
    """
    for idx, item in enumerate(getattr(state, coll_name)):
        if item.src_name == name and (not item_kind or item.kind == item_kind):
            return idx
    return -1


def set_index_by_name(state, coll_name: str, index_name: str, name: str, item_kind: str = "") -> bool:
    """按真实名(+ 可选类型)定位条目并写活跃索引; 未命中返回 False(不改索引)"""
    idx = find_item_index(state, coll_name, name, item_kind)
    if idx < 0:
        return False
    set_index(state, index_name, idx)
    return True


def rebuild_if_changed(state, coll_name: str, index_name: str, kind: str, names: list, kinds: list | None = None) -> bool:
    """快照 (名称, 类型) 序列与目标不一致时整体重建, 活跃索引按真实名跟随(失败再夹取)

    活跃条目仍在时索引跟随其新位置(插入/删除/排序后高亮不漂移); 条目已被删除时
    才退回数值夹取.

    Args:
        state: 列表快照状态组实例(含 <coll_name> 集合与 <index_name> 活跃索引属性)
        coll_name: 集合属性名(如 "lights")
        index_name: 活跃索引属性名
        kind: 条目对应的数据块类型标签(OBJECT/MATERIAL/TEXT); kinds 为 None 时统一用它
        names: 数据块名称列表
        kinds: 可选, 与 names 等长的逐条类型标签(混排列表用, 如灯光列表混排物体与材质)

    Returns:
        是否重建了快照(调用方据此失效自己的"已同步"缓存)
    """
    col = getattr(state, coll_name)
    expected = [(name, kinds[idx] if kinds is not None else kind) for idx, name in enumerate(names)]
    # 比较真实名快照(src_name)与类型而非显示名: 条目名可被用户编辑, 显示名一致不代表快照对齐
    if [(item.src_name, item.kind) for item in col] == expected:
        return False
    # 重建前记住活跃条目的真实名: 插入/删除/排序都会改变行号, 只按数字夹取会让高亮
    # 落到另一个条目上(下一次删除/赋值随之作用错对象).
    idx = getattr(state, index_name)
    active = (col[idx].src_name, col[idx].kind) if 0 <= idx < len(col) else None
    with guarded():
        col.clear()
        for name, item_kind in expected:
            item = col.add()
            item.name = name
            item.src_name = name
            item.kind = item_kind
        if active is None or not set_index_by_name(state, coll_name, index_name, active[0], active[1]):
            set_index(state, index_name, clamp_index(idx, len(col)))
    return True


def _resolve_datablock(kind: str, name: str):
    """按类型标签取真实数据块; 未知类型或不存在返回 None"""
    if kind == 'MATERIAL':
        return bpy.data.materials.get(name)
    if kind == 'TEXT':
        return bpy.data.texts.get(name)
    if kind == 'IMAGE':
        return bpy.data.images.get(name)
    if kind == 'WORLD':
        return bpy.data.worlds.get(name)
    if kind == 'COLLECTION':
        return bpy.data.collections.get(name)
    return bpy.context.scene.objects.get(name)


def rename_datablock(kind: str, old: str, new: str) -> tuple:
    """把旧名数据块重命名为新名, 返回 (数据块或 None, 错误信息)

    同名冲突由 Blender 自动追加 .001 后缀, 不算失败(调用方按返回数据块的真实名回写快照);
    空名拒绝.
    """
    if not new.strip():
        return None, "empty name"
    datablock = _resolve_datablock(kind, old)
    if datablock is None:
        return None, "datablock not found"
    try:
        datablock.name = new
    except (RuntimeError, ValueError) as e:
        return None, str(e)
    return datablock, None


def on_item_name_update(self, context: Context):
    """列表条目名编辑回调(双击行内名称): 写穿到真实数据块, 失败回写旧名

    重名时 Blender 会追加 .001 后缀: 必须按返回数据块的真实名回写 name/src_name,
    否则快照仍记着用户输入的名字, 下一次编辑会拿一个不存在的名字检索.
    """
    if is_syncing():
        return
    old = self.src_name
    new = self.name
    if new == old or not old:
        return
    datablock, _err = rename_datablock(self.kind, old, new)
    with guarded():
        if datablock is None:
            self.name = old
            return
        actual = datablock.name
        if self.name != actual:
            self.name = actual
        self.src_name = actual


class ListItem(PropertyGroup):
    """列表条目: name 双击可编辑并写穿到真实数据块, src_name 记录快照时真名, kind 标注数据块类型

    tip 为可选的整行悬停说明(经 template_list 的 item_dyntip_propname 接入),
    不需要悬停信息的列表留空即可.
    """

    name: StringProperty(name="Name", update=on_item_name_update)  # type: ignore
    src_name: StringProperty()  # type: ignore
    kind: StringProperty()  # type: ignore
    tip: StringProperty()  # type: ignore


def standard_filter(self, data, propname: str) -> tuple:
    """标准过滤/排序: 名称通配过滤 + 按名字母序, 返回 (标志列表, 顺序映射)

    返回值契约(与 Blender 的 Python UIList 包装层一致):
    - filter_flags: 与条目等长的可见性标志; 空列表表示"不过滤"
    - filter_neworder: **原索引 -> 新位置** 的映射(UI_UL_list.sort_items_helper 口径),
      不是"按显示序排列的索引表"; 关闭字母排序时返回空列表, 由显示层保持快照序
    - **反序不在此处应用**: 显示层(C 层 template_uilist_collect_items)会对本函数的
      顺序表再统一取反一次, 这里若也取反会两次抵消, 表现为反向按钮无效
      (2026-10-19 作者实测; 旧实现即有此问题)
    """
    items = getattr(data, propname)
    if self.filter_name:
        flt_flags = bpy.types.UI_UL_list.filter_items_by_name(self.filter_name, self.bitflag_filter_item, items)
    else:
        flt_flags = [self.bitflag_filter_item] * len(items)
    flt_neworder = []
    if self.use_filter_sort_alpha:
        flt_neworder = bpy.types.UI_UL_list.sort_items_helper([(idx, item.name) for idx, item in enumerate(items)], lambda entry: entry[1].lower())
    return flt_flags, flt_neworder


class StandardFilterMixin:
    """UIList 内建过滤/排序控件行为(过滤行默认收起, 点漏斗图标展开)

    标准过滤属性(filter_name/use_filter_show/use_filter_sort_alpha/use_filter_sort_reverse)
    由 UIList 基类自带, 此处只需提供 filter_items 行为, 自声明同名属性会被基类遮蔽.
    """

    def filter_items(self, context: Context, data, propname: str):
        return standard_filter(self, data, propname)
