"""
服务商注册表 —— 每服务商一条声明式记录(单一来源)

把原先散落在 items.py / image_client.py / ai_client.py / preference.py / props.py /
ai_generate.py / service_test.py 里的服务商知识(端点 / 密钥 / 模型 / 限制 / 请求体 /
尺寸修正 / 思考档 / 额度策略 / 测试策略)收敛为 dataclass 记录.

**加一个服务商 = 加一条记录 + 一组 `*_items` 枚举字面量**(i18n 提取器要求字面量独立声明),
其余代码一律查表,不再新增 if 分支.

本模块是依赖最底层:不 import 任何插件内模块(含 image_client / ai_client),
只依赖 Python 标准库.image_client / ai_client 反过来从这里导入并复用其中的
纯函数(尺寸修正 / 请求体 / 响应解析).

设计要点(编号与 docs/provider-extension-checklist.md「四、四个关键坑」逐条对应):
- 坑 1(自定义商是"少传"不是"多传"): build_payload 保留为回调, 逐商剔除不要的字段
- 坑 2(模型级差异不能压成服务商级): resolve_size 保留为函数回调, 不做纯数据
- 坑 3(能力开关必须有消费点): supports_* 由 image_common 的单口函数与面板行读取
- 坑 4(思考档位标识两处一致): thinking_items 与 build_thinking_extras 合并为单字段对
"""

import base64
import urllib.error
import urllib.request
from dataclasses import dataclass
from urllib.parse import urlparse

# 下载生成图的上限(字节): 防止服务端返回超大文件把内存吃满
_MAX_DOWNLOAD_BYTES = 64 * 1024 * 1024
_ALLOWED_DOWNLOAD_SCHEMES = {'http', 'https'}
from typing import Callable

# errors.py 是纯数据模块(无 bpy 依赖), 从它导入 api_error 不会引入依赖链;
# 错误对象必须统一为 ClientError 类型, 否则 describe_error 的 isinstance 判断会失效,
# 导致错误文案不翻译.
from .errors import api_error

# ---------------------------------------------------------------------------
# 尺寸修正纯函数(自 image_client 迁入,逻辑逐字保留)
# ---------------------------------------------------------------------------


def _scale_to_total(width: int, height: int, total_min: int, total_max: int):
    total = max(1, width * height)
    if total < total_min:
        scale = (total_min / total) ** 0.5
    elif total > total_max:
        scale = (total_max / total) ** 0.5
    else:
        return width, height
    return max(2, round(width * scale)), max(2, round(height * scale))


def _clamp_aspect(width: int, height: int, aspect_max: float):
    if height <= 0:
        return width, max(2, height)
    ratio = width / height
    if ratio > aspect_max:
        width = round(height * aspect_max)
    elif 1.0 / ratio > aspect_max:
        height = round(width / aspect_max)
    return width, max(2, height)


def _even_up(value: int) -> int:
    return value + (value % 2)


# 方舟 Seedream 约束常量
_SEEDREAM_DIM_MIN, _SEEDREAM_DIM_MAX = 512, 4096
_SEEDREAM_ASPECT_MAX = 16.0
_SEEDREAM_3_0_DIM_MAX = 2048
_SEEDREAM_TOTAL_MIN_LO = 1280 * 720
_SEEDREAM_TOTAL_MIN_HI = 2560 * 1440
_SEEDREAM_TOTAL_MAX_STD = 4096 * 4096
_SEEDREAM_TOTAL_MAX_LITE = int(3072 * 3072 * 1.1025)
_SEEDREAM_TOTAL_MAX_5_PRO = 2048 * 2048 * 11025 // 10000

# 百炼 Qwen-Image 约束常量
_QWEN_DIM_MIN, _QWEN_DIM_MAX = 256, 4096
_QWEN_TOTAL_MIN, _QWEN_TOTAL_MAX = 512 * 512, 2048 * 2048
_QWEN_ASPECT_MAX = 8.0
_QWEN_PRESETS = ((1664, 928), (1472, 1104), (1328, 1328), (1104, 1472), (928, 1664))


def _seedream_total_range(model: str):
    if "lite" in model:
        return _SEEDREAM_TOTAL_MIN_HI, _SEEDREAM_TOTAL_MAX_LITE
    if "4-0" in model or "4.0" in model:
        return _SEEDREAM_TOTAL_MIN_LO, _SEEDREAM_TOTAL_MAX_STD
    if "4-5" in model or "4.5" in model:
        return _SEEDREAM_TOTAL_MIN_HI, _SEEDREAM_TOTAL_MAX_STD
    return _SEEDREAM_TOTAL_MIN_LO, _SEEDREAM_TOTAL_MAX_5_PRO


def _resolve_seedream_size(model: str, width: int, height: int):
    width = min(max(width, _SEEDREAM_DIM_MIN), _SEEDREAM_DIM_MAX)
    height = min(max(height, _SEEDREAM_DIM_MIN), _SEEDREAM_DIM_MAX)
    width, height = _clamp_aspect(width, height, _SEEDREAM_ASPECT_MAX)
    if "3-0" in model or "3.0" in model:
        width = min(width, _SEEDREAM_3_0_DIM_MAX)
        height = min(height, _SEEDREAM_3_0_DIM_MAX)
        return width - width % 2, height - height % 2
    total_min, total_max = _seedream_total_range(model)
    width, height = _scale_to_total(width, height, total_min, total_max)
    width = min(max(width, _SEEDREAM_DIM_MIN), _SEEDREAM_DIM_MAX)
    height = min(max(height, _SEEDREAM_DIM_MIN), _SEEDREAM_DIM_MAX)
    if width * height < total_min:
        if width >= height:
            height = max(height, -(-total_min // width))
        else:
            width = max(width, -(-total_min // height))
    width -= width % 2
    height -= height % 2
    if width * height < total_min:
        if width >= height:
            height = _even_up(-(-total_min // width))
        else:
            width = _even_up(-(-total_min // height))
    while width * height > total_max:
        if width >= height:
            width -= 2
        else:
            height -= 2
    return width, height


def _snap_qwen_preset(width: int, height: int):
    ratio = width / max(1, height)
    return min(_QWEN_PRESETS, key=lambda wh: abs(wh[0] / wh[1] - ratio))


def _resolve_qwen_size(model: str, width: int, height: int):
    if model.startswith(("qwen-image-max", "qwen-image-plus")):
        return _snap_qwen_preset(width, height)
    width, height = _clamp_aspect(width, height, _QWEN_ASPECT_MAX)
    width, height = _scale_to_total(width, height, _QWEN_TOTAL_MIN, _QWEN_TOTAL_MAX)
    width = min(max(width, _QWEN_DIM_MIN), _QWEN_DIM_MAX)
    height = min(max(height, _QWEN_DIM_MIN), _QWEN_DIM_MAX)
    width -= width % 16
    height -= height % 16
    if width > height * _QWEN_ASPECT_MAX:
        width = max(16, int(height * _QWEN_ASPECT_MAX) // 16 * 16)
    elif height > width * _QWEN_ASPECT_MAX:
        height = max(16, int(width * _QWEN_ASPECT_MAX) // 16 * 16)
    while width * height < _QWEN_TOTAL_MIN:
        if width >= height:
            height += 16
        else:
            width += 16
    while width * height > _QWEN_TOTAL_MAX:
        if width >= height:
            width -= 16
        else:
            height -= 16
    return width, height


def _resolve_custom_size(model: str, width: int, height: int):
    """自定义服务商不做修正,原样下发"""
    return width, height


# ---------------------------------------------------------------------------
# 请求体 / 响应解析纯函数(自 image_client 迁入,逻辑逐字保留)
# ---------------------------------------------------------------------------


def _data_uri(image_bytes: bytes) -> str:
    mime = "image/png" if image_bytes[:8] == b"\x89PNG\r\n\x1a\n" else "image/jpeg"
    encoded = base64.b64encode(image_bytes).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def _volcengine_payload(model, prompt, size, ref_images, seed, negative_prompt="") -> dict:
    payload = {
        "model": model,
        "prompt": prompt,
        "response_format": "b64_json",
        "watermark": False,
    }
    if size:
        payload["size"] = size
    if ref_images:
        payload["image"] = [_data_uri(data) for data in ref_images]
    # 方舟官方参数表无负向提示词, negative_prompt 一律不下发(忽略传入值)
    # 方舟 Seedream 4.0 起已移除 seed 参数(官方参数表无该字段; 作者实测同参考图/提示词/
    # 种子两次结果仍不同), 故 seed 一律不下发(忽略传入值); 随机性由服务端决定, 面板对其
    # 不承诺可复现, 行不绘制(见 ui/panels 的 supports_seed 判断)
    return payload


def _dashscope_payload(model, prompt, size, ref_images, seed, negative_prompt="") -> dict:
    content = [{"image": _data_uri(data)} for data in (ref_images or [])]
    content.append({"text": prompt})
    payload = {
        "model": model,
        "input": {"messages": [{"role": "user", "content": content}]},
        "parameters": {"watermark": False, "n": 1},
    }
    if size:
        payload["parameters"]["size"] = size
    if seed:
        payload["parameters"]["seed"] = seed
    if negative_prompt:
        payload["parameters"]["negative_prompt"] = negative_prompt
    return payload


def _custom_payload(model, prompt, size, ref_images, seed, negative_prompt="") -> dict:
    """自定义服务商: OpenAI images 风格,但剔除 watermark / response_format / seed"""
    payload = _volcengine_payload(model, prompt, size, ref_images, seed)
    payload.pop("response_format")
    payload.pop("watermark")
    payload.pop("seed", None)
    return payload


def _download(url: str, timeout: int):
    """下载服务端返回的图片 URL

    只允许 http/https: 服务端若返回 `file://`/自定义 scheme, `urlopen` 会读取本地文件
    (本地文件读取原语). 下载大小设上限, 避免超大响应耗尽内存.
    """
    parsed = urlparse(url)
    if parsed.scheme.lower() not in _ALLOWED_DOWNLOAD_SCHEMES:
        return None, api_error("Refusing to download from a non-HTTP URL")
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            length = resp.headers.get("Content-Length")
            if length is not None and length.isdigit() and int(length) > _MAX_DOWNLOAD_BYTES:
                return None, api_error("Downloaded image is too large")
            data = resp.read(_MAX_DOWNLOAD_BYTES + 1)
    except urllib.error.URLError as e:
        return None, api_error("Failed to download the generated image", str(e.reason))
    except OSError as e:
        return None, api_error("Failed to download the generated image", str(e))
    if len(data) > _MAX_DOWNLOAD_BYTES:
        return None, api_error("Downloaded image is too large")
    if not data:
        return None, api_error("Downloaded image is empty")
    return data, None


def _extract_item_image(data: dict, timeout: int):
    try:
        item = data["data"][0]
    except (KeyError, IndexError, TypeError):
        return None, api_error("Unexpected API response format")
    if not isinstance(item, dict):
        return None, api_error("Unexpected API response format")
    if item.get("b64_json"):
        try:
            return base64.b64decode(item["b64_json"]), None
        except (ValueError, TypeError):
            return None, api_error("API returned invalid base64 image data")
    if item.get("url"):
        return _download(item["url"], timeout)
    return None, api_error("API response contains no image")


def _extract_dashscope_image(data: dict, timeout: int):
    try:
        content = data["output"]["choices"][0]["message"]["content"]
        url = next(entry["image"] for entry in content if isinstance(entry, dict) and entry.get("image"))
    except (KeyError, IndexError, TypeError, StopIteration):
        return None, api_error("Unexpected API response format")
    return _download(url, timeout)


# ---------------------------------------------------------------------------
# 思考参数组装纯函数(自 ai_client.build_thinking_extras 迁入)
# ---------------------------------------------------------------------------


def _glm_thinking_extras(thinking: str) -> dict:
    if not thinking or thinking == 'DEFAULT':
        return {}
    return {"thinking": {"type": "enabled"}, "reasoning_effort": thinking}


def _deepseek_thinking_extras(thinking: str) -> dict:
    if not thinking or thinking == 'DEFAULT':
        return {}
    if thinking == 'off':
        return {"thinking": {"type": "disabled"}}
    return {"thinking": {"type": "enabled"}, "reasoning_effort": thinking}


def _generic_thinking_extras(thinking: str) -> dict:
    if not thinking or thinking == 'DEFAULT':
        return {}
    return {"reasoning_effort": thinking}


# ---------------------------------------------------------------------------
# 服务商枚举 / 候选模型 / 思考档位的 *_items 字面量
#
# 这些字面量必须保持「xxx_items = [元组字面量]」形态, 供 i18n 提取器
# (.agents/i18n_sweep.py) 按名字扫描提取可翻译文案. 切勿改成推导式 / dict /
# 函数调用派生, 否则这些英文文案会从插件词典消失, 中文界面退化显示英文.
# dataclass 记录(见下)的 thinking_items 字段引用这里的字面量; 候选模型表
# (volcengine_t2i_items 等)则由 items.py 直接引用同名元组, 保证「单一来源」
# 与「i18n 可提取」二者兼得.
# ---------------------------------------------------------------------------

# 文本服务商枚举(偏好 provider 下拉; 末档 Custom 单独追加)
provider_items = [
    ('DEEPSEEK', "DeepSeek", "DeepSeek OpenAI-compatible API"),
    ('GLM', "Zhipu GLM", "Zhipu AI OpenAI-compatible API"),
    ('CUSTOM', "Custom", "Manually fill in base URL and model"),
]

# 图像服务商枚举(偏好 image_provider 下拉)
image_provider_items = [
    ('VOLCENGINE', "Volcengine Ark", "Volcengine Ark image API (Doubao Seedream)"),
    ('DASHSCOPE', "Alibaba DashScope", "Alibaba Model Studio image API (Qwen-Image)"),
    ('CUSTOM', "Custom", "Manually fill in base URL and models"),
]

# 文本服务商候选模型
deepseek_model_items = [
    ('deepseek-flash', "DeepSeek Flash", "DeepSeek V4.1 Flash model, fast and inexpensive"),
    ('deepseek-v4-pro', "DeepSeek V4 Pro", "DeepSeek V4 Pro model, strongest reasoning"),
]
glm_model_items = [
    ('glm-5.3-flash', "GLM-5.3 Flash", "Zhipu GLM-5.3 Flash model, fast and inexpensive"),
    ('glm-5.3', "GLM-5.3", "Zhipu GLM-5.3 flagship model"),
]

# 图像服务商候选模型(纹理与编辑两栏共用同一组候选)
volcengine_t2i_items = [
    ('doubao-seedream-5-0-flash-260915', "Seedream 5.0 Flash", "Doubao Seedream 5.0 Flash image model, lighter and faster"),
    ('doubao-seedream-5-0-pro-260628', "Seedream 5.0 Pro", "Doubao Seedream 5.0 Pro image model"),
]
dashscope_t2i_items = [
    ('qwen-image-3.0', "Qwen-Image 3.0", "Alibaba Qwen-Image 3.0 image model"),
    ('qwen-image-3.0-pro', "Qwen-Image 3.0 Pro", "Alibaba Qwen-Image 3.0 Pro image model"),
]

# 思考档位表(档位标识即该服务商的参数值), 表首项即默认档
deepseek_thinking_items = [
    ('off', "Off", "Disable thinking, the default: fastest and cheapest"),
    ('low', "Low", "Low reasoning effort"),
    ('high', "High", "High reasoning effort"),
    ('max', "Highest", "Maximum reasoning effort"),
]
glm_thinking_items = [
    ('low', "Low", "Light reasoning, the default: classification, extraction, quick answers"),
    ('high', "High", "Enhanced reasoning: regular coding and drafts"),
    ('max', "Highest", "Deep reasoning: for complex tasks"),
]
default_thinking_items = [
    ('low', "Low", "Low reasoning effort, the default"),
    ('medium', "Medium", "Medium reasoning effort"),
    ('high', "High", "High reasoning effort"),
]


# ---------------------------------------------------------------------------
# dataclass 定义
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ImageProvider:
    key: str  # 'VOLCENGINE' | 'DASHSCOPE' | 'CUSTOM'
    base_url: str  # 端点(CUSTOM 为 '')
    api_key_attr: str  # 偏好密钥属性名
    default_model_t2i: str  # 唯一图像模型: 纹理贴图/图像/效果图三模式共用(字段名为历史名)
    # 参考图
    ref_count: int  # 张数上限(0 = 不限)
    ref_edge: int  # 最长边(0 = 不限)
    # 提示词
    token_budget: int  # 0 = 不估算
    token_hard: bool  # 是否硬截断
    # 输出尺寸
    resolve_size: Callable  # (model, w, h) -> (w, h)
    size_sep: str  # 'x' | '*'
    output_limits: tuple  # 面板提醒用(最严格模型汇总)
    # 请求
    endpoint_path: str  # 请求路径后缀
    build_payload: Callable  # 请求体构造(承载 CUSTOM 负向剔除,坑 1)
    parse_response: Callable  # 响应解析
    # 能力开关(注意消费点: 标志位只在下述位置生效, 缺消费点的字段不产生运行时行为——
    # 改标志位前先确认有读取方, 否则改了没有效果)
    # - supports_negative_prompt: 请求侧(纹理/效果图各操作器)与 UI 侧(blocks.draw_negative_row)均读取
    # - supports_seed: UI 侧(面板种子行绘制)与 effective_seed(是否本地抽取回填)读取;
    #   请求侧是否下发由 build_payload 回调决定
    # - supports_watermark / supports_response_format: 目前无消费点(仅文档性, 行为由
    #   build_payload 回调实现), 改这两项不会改变请求体
    supports_negative_prompt: bool
    supports_seed: bool
    supports_watermark: bool
    supports_response_format: bool


@dataclass(frozen=True)
class TextProvider:
    key: str
    base_url: str
    api_key_attr: str
    default_model: str
    thinking_items: tuple  # 档位表(合并坑 3 的 T5)
    build_thinking_extras: Callable  # (thinking) -> dict(合并坑 3 的 T6)
    script_max_tokens: int | None  # 输出额度策略(T7): None 或 int
    test_strategy: str  # 'balance' | 'ping'(T8)


# ---------------------------------------------------------------------------
# 记录表
# ---------------------------------------------------------------------------

IMAGE_PROVIDERS = {
    'VOLCENGINE': ImageProvider(
        key='VOLCENGINE',
        base_url="https://ark.cn-beijing.volces.com/api/v3",
        api_key_attr="volcengine_api_key",
        default_model_t2i="doubao-seedream-5-0-flash-260915",
        # 参考图张数按模型分档(火山引擎官方文档): Seedream 5.0 pro/flash 为 10,
        # lite/4.5/4.0 为 14; 本候选表只有 pro/flash 两个模型(均为 10), 故取 10.
        # 将来把 lite/4.5/4.0 纳入候选表时, 需照 resolve_size 的先例把本字段改为模型级回调
        ref_count=10,
        ref_edge=6000,
        token_budget=600,
        token_hard=False,
        resolve_size=_resolve_seedream_size,
        size_sep='x',
        output_limits=(_SEEDREAM_DIM_MIN, _SEEDREAM_DIM_MAX, _SEEDREAM_TOTAL_MIN_LO, _SEEDREAM_TOTAL_MAX_5_PRO, int(_SEEDREAM_ASPECT_MAX)),
        endpoint_path="/images/generations",
        build_payload=_volcengine_payload,
        parse_response=_extract_item_image,
        supports_negative_prompt=False,
        # 方舟 Seedream 4.0 起移除 seed(官方参数表无该字段, 作者实测同种子两次结果不同):
        # 请求不下发(见 _volcengine_payload), 面板整行不绘制, 不对其承诺可复现
        supports_seed=False,
        supports_watermark=True,
        supports_response_format=True,
    ),
    'DASHSCOPE': ImageProvider(
        key='DASHSCOPE',
        base_url="https://dashscope.aliyuncs.com/api/v1",
        api_key_attr="dashscope_api_key",
        default_model_t2i="qwen-image-3.0",
        ref_count=3,
        ref_edge=3072,
        token_budget=800,
        token_hard=True,
        resolve_size=_resolve_qwen_size,
        size_sep='*',
        output_limits=(_QWEN_DIM_MIN, _QWEN_DIM_MAX, _QWEN_TOTAL_MIN, _QWEN_TOTAL_MAX, int(_QWEN_ASPECT_MAX)),
        endpoint_path="/services/aigc/multimodal-generation/generation",
        build_payload=_dashscope_payload,
        parse_response=_extract_dashscope_image,
        supports_negative_prompt=True,
        supports_seed=True,
        supports_watermark=True,
        supports_response_format=False,
    ),
    'CUSTOM': ImageProvider(
        key='CUSTOM',
        base_url="",
        api_key_attr="image_api_key",
        default_model_t2i="",
        ref_count=0,
        ref_edge=0,
        token_budget=0,
        token_hard=False,
        resolve_size=_resolve_custom_size,
        size_sep='x',
        output_limits=None,
        endpoint_path="/images/generations",
        build_payload=_custom_payload,
        parse_response=_extract_item_image,
        supports_negative_prompt=False,
        supports_seed=False,
        supports_watermark=False,
        supports_response_format=False,
    ),
}

TEXT_PROVIDERS = {
    'DEEPSEEK': TextProvider(
        key='DEEPSEEK',
        base_url="https://api.deepseek.com",
        api_key_attr="deepseek_api_key",
        default_model="deepseek-flash",
        thinking_items=tuple(deepseek_thinking_items),
        build_thinking_extras=_deepseek_thinking_extras,
        script_max_tokens=None,  # 省略用服务端默认
        test_strategy='balance',
    ),
    'GLM': TextProvider(
        key='GLM',
        base_url="https://open.bigmodel.cn/api/paas/v4",
        api_key_attr="glm_api_key",
        default_model="glm-5.3-flash",
        thinking_items=tuple(glm_thinking_items),
        build_thinking_extras=_glm_thinking_extras,
        script_max_tokens=65536,
        test_strategy='ping',
    ),
}

# 通用文本服务商(未显式注册时的兜底,等价于旧 default_thinking_items + 通用 reasoning_effort)
DEFAULT_THINKING_ITEMS = tuple(default_thinking_items)


def get_image_provider(provider: str) -> ImageProvider:
    """按 key 取图像服务商记录,未知回落 CUSTOM(不臆断限制)"""
    return IMAGE_PROVIDERS.get(provider, IMAGE_PROVIDERS['CUSTOM'])


def get_text_provider(provider: str) -> TextProvider:
    """按 key 取文本服务商记录,未知回落通用行为"""
    return TEXT_PROVIDERS.get(provider)


def effective_provider(state, prefs, kind: str) -> str:
    """面板生效服务商: GLOBAL(跟随偏好)取偏好对应服务商, 覆盖档取面板所选

    kind 为 'text' 取 prefs.provider, 'image' 取 prefs.image_provider. 面板 UI 与生成算子
    共用单一来源(防"面板显示值与实际请求不一致"); 属 utils 内部协作 API, 不进公共 __all__.
    """
    if state.service_mode != 'GLOBAL':
        return state.service_mode
    return prefs.provider if kind == 'text' else prefs.image_provider


def thinking_items_for(provider: str) -> tuple:
    """按服务商返回思考档位条目(文本服务商),未知回落通用三档"""
    p = get_text_provider(provider)
    return p.thinking_items if p is not None else DEFAULT_THINKING_ITEMS


def build_thinking_extras(provider: str, thinking: str) -> dict:
    """把思考档位组装为该服务商的请求参数,未知服务商回落通用 reasoning_effort"""
    p = get_text_provider(provider)
    if p is None:
        return _generic_thinking_extras(thinking)
    return p.build_thinking_extras(thinking)


# ---------------------------------------------------------------------------
# 注册表自校验(import 时执行一次)
#
# 枚举字面量(*_items)与 dataclass 记录是**手工对齐**的两处:加一个服务商要同时改
# 枚举档 + 记录,漏改任一侧不会在编译期报错,只会导致「下拉里可选,请求却走兜底」
# 或「记录存在,下拉里选不到」的隐性 bug.这里做双向断言,把遗漏提前到加载期暴露.
# ---------------------------------------------------------------------------


def _check_registry() -> None:
    """断言枚举档与 dataclass 记录双向对齐(图像侧含 CUSTOM,文本侧 CUSTOM 有意缺省)"""
    # 图像侧: 枚举档与记录完全对齐(图像侧 CUSTOM 有注册表记录)
    image_enum_keys = {item[0] for item in image_provider_items}
    image_record_keys = set(IMAGE_PROVIDERS)
    assert image_enum_keys == image_record_keys, f"图像枚举档与记录不一致: 仅枚举有 {image_enum_keys - image_record_keys}, " f"仅记录有 {image_record_keys - image_enum_keys}"
    # 文本侧: 预设商(非 CUSTOM)必须有记录; CUSTOM 有意不注册(走 get_text_provider 返回
    # None 的兜底语义), 故不作为缺失报错
    text_enum_keys = {item[0] for item in provider_items}
    text_record_keys = set(TEXT_PROVIDERS)
    missing = (text_enum_keys - {'CUSTOM'}) - text_record_keys
    assert not missing, f"文本枚举档 {missing} 缺少对应的 TextProvider 记录"
    # 记录里有,枚举里没有(记录成了死代码), 同样报错
    extra = text_record_keys - text_enum_keys
    assert not extra, f"TextProvider 记录 {extra} 在 provider_items 枚举里没有对应档"


_check_registry()
