"""
脚本安全预检模块

对即将运行的脚本做运行前的危险调用扫描(纯函数, 不导入 bpy).
RunScript 在运行前调用 scan_dangerous: 命中高风险调用时弹确认框, 由用户决定是否继续,
避免 AI 生成/修改的脚本在误点时毁坏场景或数据.

扫描基于 AST 的**调用名**而非字面匹配: 字面正则可被别名/导入形式/动态取值绕过
(`from os import remove` / `import shutil as s` / `getattr(os, "remove")`),
AST 版解析 Import/ImportFrom 建立别名表, 再按限定名判定. 无法静态确定目标的动态访问
(`getattr` 无字面属性名、`__import__`)按 fail-closed 计入确认项 —— 不能把"没识别出来"
当成"安全".

扫描只覆盖"执行前"这一处收口; 误报(如把字符串/注释里的调用也计入? AST 不会) 由用户
在确认框自行判断, 成本远低于漏报.
"""

import ast

# 说明键按固定顺序返回(与旧实现的声明顺序一致, 用例依赖该顺序)
_LABELS = (
    "quits Blender",
    "overwrites the .blend file",
    "discards the current file",
    "deletes a directory tree",
    "deletes a file",
    "runs a subprocess",
    "runs a shell command",
    "runs dynamic code",
    "deletes Blender data",
    "uses dynamic attribute access",
)

# 精确限定名 -> 说明键
_EXACT_CALLS = {
    "bpy.ops.wm.quit_blender": "quits Blender",
    "bpy.ops.wm.save_mainfile": "overwrites the .blend file",
    "bpy.ops.wm.save_as_mainfile": "overwrites the .blend file",
    "shutil.rmtree": "deletes a directory tree",
    "os.remove": "deletes a file",
    "os.unlink": "deletes a file",
    "os.system": "runs a shell command",
    "os.popen": "runs a shell command",
    "subprocess.run": "runs a subprocess",
    "subprocess.call": "runs a subprocess",
    "subprocess.Popen": "runs a subprocess",
    "subprocess.check_call": "runs a subprocess",
    "subprocess.check_output": "runs a subprocess",
    "eval": "runs dynamic code",
    "exec": "runs dynamic code",
    "compile": "runs dynamic code",
    "__import__": "runs dynamic code",
    "importlib.import_module": "runs dynamic code",
    "bpy.ops.object.delete": "deletes Blender data",
    "bpy.ops.mesh.delete": "deletes Blender data",
    "bpy.ops.outliner.orphans_purge": "deletes Blender data",
    "bpy.ops.wm.read_homefile": "discards the current file",
    "bpy.ops.wm.open_mainfile": "discards the current file",
}

_DYNAMIC_ACCESS = "uses dynamic attribute access"


def _dotted(node) -> str | None:
    """把 Name/Attribute 链还原成点分名; 其它形态返回 None"""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _dotted(node.value)
        return f"{base}.{node.attr}" if base else None
    return None


def _collect_aliases(tree) -> tuple:
    """收集导入别名与已知模块根: (局部名 -> 真实点分名, 已导入的模块根集合)

    作用域不精确只会造成少量漏报/误报, 但能覆盖 AI 脚本最常见的三种改写:
    `import shutil as s` / `from os import remove` / `from os import remove as rm`.
    模块根集合用于区分"`getattr` 的基对象是不是模块": 只有模块(或导入别名)才能静态
    展开成限定名, 局部变量不行.
    """
    aliases = {}
    modules = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                local = alias.asname or alias.name.split(".")[0]
                real = alias.name if alias.asname else alias.name.split(".")[0]
                modules.add(local)
                if local != real:
                    aliases[local] = real
        elif isinstance(node, ast.ImportFrom):
            if node.level or not node.module:
                continue
            for alias in node.names:
                if alias.name == "*":
                    continue
                aliases[alias.asname or alias.name] = f"{node.module}.{alias.name}"
    return aliases, modules


def _resolve(name: str, aliases: dict) -> str:
    """按别名表把局部名展开为真实点分名(只替换首段)"""
    root = name.split(".")[0]
    real = aliases.get(root)
    if real and real != root:
        return real + name[len(root) :]
    return name


def _resolve_getattr(node, aliases, modules) -> str | None:
    """解析 getattr(x, "attr") 的限定名; 无字面属性名或基对象不是已导入模块时返回 None

    基对象是局部变量时无法静态确定(可能是 `mod = os` 也可能是任意对象), 按动态访问
    fail-closed, 不能拼成 "mod.remove" 就当成"已识别".
    """
    if len(node.args) >= 2 and isinstance(node.args[1], ast.Constant) and isinstance(node.args[1].value, str):
        base = _dotted(node.args[0]) if node.args else None
        if base and base.split(".")[0] in modules:
            return f"{_resolve(base, aliases)}.{node.args[1].value}"
    return None


def _scan_calls(tree, aliases, modules) -> set:
    """遍历所有调用, 返回命中的说明键集合"""
    hits = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        name = _dotted(func)
        if name is None and isinstance(func, ast.Call) and _dotted(func.func) == "getattr":
            # getattr(x, "attr")(...) 直接调用: 按解析出的限定名判定
            name = _resolve_getattr(func, aliases, modules)
            if name is None:
                hits.add(_DYNAMIC_ACCESS)
                continue
        elif name == "getattr":
            # getattr(...) 的结果未被直接调用: 能解析出目标就不算危险, 否则按动态访问 fail-closed
            if _resolve_getattr(node, aliases, modules) is None:
                hits.add(_DYNAMIC_ACCESS)
            continue
        if not name:
            continue
        qualified = _resolve(name, aliases)
        label = _EXACT_CALLS.get(qualified)
        if label is not None:
            hits.add(label)
        elif qualified.startswith("bpy.data.") and qualified.endswith(".remove"):
            # 删除 Blender 数据块(物体/材质/图像等)一律按删除数据处理
            hits.add("deletes Blender data")
    return hits


def scan_dangerous(code: str) -> list:
    """扫描脚本源码里的高风险调用, 按固定顺序返回命中的说明键列表(去重)

    语法错误返回空列表: 该脚本无法通过 compile 执行, 不会造成损害.
    """
    if not code:
        return []
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []
    hits = _scan_calls(tree, *_collect_aliases(tree))
    return [label for label in _LABELS if label in hits]
