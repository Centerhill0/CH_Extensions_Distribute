"""
图像生成器面板模块

AI 助手选项卡下的图像生成器面板(默认收缩), 三个生成模式(纹理贴图 / 图像 / 效果图)共用一套外壳:

1. 图像列表(三模式共用一个列表, 靠产物前缀区分: AI Tex / AI Bmp / AI Render)
   + 预览区(共用; 标题行右侧为保存按钮列, 见 preview.draw_preview_box)
2. 生成模式行(常驻, 紧贴预览区下方, 不随任何小节折叠) —— 本面板唯一恒定的控制位
3. 生成通道小节(仅效果图模式, 紧跟模式行; 见 ai_render.draw_pass_section)
4. Settings 小节(常驻折叠, 默认展开; 公共项位置固定, 模式专属项按需出现):
   分辨率(按模式) → 随机种/张数/变体 → 无缝(仅纹理贴图) → 参考图 → 发送通道(仅效果图)
5. 描述与操作行(随模式; 图像侧见 ai_texture.draw_image_prompt, 效果图见 ai_render.draw_render_prompt)
6. 错误摘要与等待进度(三模式共用一个 image 作用域, 切模式不丢进度)

分工: 本模块只做外壳与公共段; 模式专属的绘制留在 ai_texture / ai_render 两个"绘制段"模块.
"""

from bpy.types import Context, Panel
from bpy.types import UILayout

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.image_common import resolve_image_model
from ...preference import get_prefs
from ...utils import resolve_output_size
from ...utils.provider_registry import effective_provider
from .ai_render import draw_pass_section, draw_render_prompt, draw_render_size, draw_send_section
from .ai_texture import draw_image_prompt, draw_image_settings
from .blocks import (
    IMAGE_SIZE_FIELDS,
    RENDER_SIZE_FIELDS,
    TEX_SIZE_FIELDS,
    draw_batch_settings,
    draw_error_box,
    draw_fold_header,
    draw_image_list_row,
    draw_reference_list,
    draw_save_tail,
    draw_wait_box,
)
from .preview import draw_preview_box


def _draw_mode_row(layout: UILayout, state) -> None:
    """生成模式常驻行: 标题 + 三段展开按钮(纹理贴图 / 图像 / 效果图)

    紧贴预览区下方、不参与任何折叠小节: 切模式时下方各段的显隐都跟着它变,
    它是本面板唯一恒定的"控制位"(所以不能收进 Settings).
    """
    box = layout.box()
    box.label(text="Generation Mode", icon='OPTIONS')
    # 不传 text: expand 按钮的文案就是模式条目名(text="" 会把三个按钮的标签一起清空)
    box.row(align=True).prop(state, "mode", expand=True)


# 生成模式 -> 该模式自己的输出尺寸字段组(预设, 锁定, 宽, 高); 三套字段互不覆盖
_SIZE_FIELDS = {
    'TEXTURE': TEX_SIZE_FIELDS,
    'IMAGE': IMAGE_SIZE_FIELDS,
    'RENDER': RENDER_SIZE_FIELDS,
}


def _size_fields(state) -> tuple:
    """当前模式对应的输出尺寸字段组(三模式各一套, 切模式不影响对方)"""
    return _SIZE_FIELDS[state.mode]


def _draw_settings_summary(header, state, provider: str, model: str) -> None:
    """Settings 收起态摘要: 只给一行"实际输出 W x H"(与展开态同口径)"""
    _preset, _lock, width_attr, height_attr = _size_fields(state)
    out_w, out_h = resolve_output_size(provider, model, getattr(state, width_attr), getattr(state, height_attr))
    note = header.row()
    note.enabled = False
    note.label(text=iface("Actual output: {} x {}").format(out_w, out_h), icon='INFO')


def _draw_settings(layout: UILayout, state, scene, provider: str, model: str, prefs) -> None:
    """Settings 小节(常驻折叠, 默认展开)

    公共项(随机种/张数/变体/参考图)位置在三模式下完全一致, 只有输出尺寸(以及纹理贴图的
    无缝、效果图的发送通道)随模式出现 —— 切模式时视觉位移最小.
    """
    box = layout.box()
    header = draw_fold_header(box, state, "use_show_settings", "Settings")
    if not state.use_show_settings:
        _draw_settings_summary(header, state, provider, model)
        return
    sub = box.column()
    sub.use_property_split = True
    # 输出尺寸: 按模式换字段组(三套档位语义不同, 字段各自独立)
    if state.mode == 'RENDER':
        draw_render_size(sub, state, provider, model)
    else:
        draw_image_settings(sub, state, provider, model)
    # 随机种 / 张数 / 多变体: 三模式共用
    draw_batch_settings(sub, state, provider)
    # 无缝贴图: 仅纹理贴图模式显示(图像模式不参与无缝处理, 效果图模式与本项无关)
    if state.mode == 'TEXTURE':
        sub.prop(state, "use_seamless")
    # 参考图: 三模式共用一份列表(图像侧作视觉参考, 效果图作风格参考)
    sub.prop(state, "use_ref_images")
    if state.use_ref_images:
        draw_reference_list(sub, state)
    # 发送通道: 仅效果图模式(与本面板的通道捕获配套)
    if state.mode == 'RENDER':
        draw_send_section(box, state, scene, provider, prefs)


@reg_order(4)
class AiImagePanel(Panel):
    """图像生成器面板"""

    bl_label = "Image Generator"
    bl_idname = "VIEW3D_PT_ch_ai_image"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # AI 助手选项卡(四个面板共用; 本面板在服务/对话/脚本之后)
    bl_category = "AI Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_image_state
        sstate = wm.ch_ai_image_service
        prefs = get_prefs()
        layout = self.layout
        scene = context.scene
        # 服务与模型只解析一次: 尺寸回填、提示词摘要与生成操作器必须同源
        provider = effective_provider(sstate, prefs, 'image')
        model = resolve_image_model(sstate, prefs)

        # 图像列表 + 预览区(三模式共用一份列表: 产物靠前缀区分)
        draw_image_list_row(layout, state, "images", "images_active_index", "ch_ai_images", 'IMAGE')
        draw_preview_box(layout, state, iface("No image generated yet"), label_tail=lambda tail, s: draw_save_tail(tail, s, 'IMAGE'))

        # 生成模式(常驻, 不折叠)
        _draw_mode_row(layout, state)

        # 生成通道(仅效果图, 紧跟模式行)
        if state.mode == 'RENDER':
            draw_pass_section(layout, context, state, provider, prefs)

        # Settings(常驻, 公共项 + 模式专属项)
        _draw_settings(layout, state, scene, provider, model, prefs)

        # 描述与操作(随模式: 各自描述块 / 提示词工具 / 修改与生成)
        if state.mode == 'RENDER':
            draw_render_prompt(layout, state, scene, provider, prefs, sstate)
        else:
            draw_image_prompt(layout, state, provider)

        # 末尾: 错误摘要与等待进度(图像请求三模式共用 image 作用域; 通道捕获是独立作用域,
        # 两者可并行, 故各画一个等待框 —— 谁的 status 为空谁就不画)
        draw_error_box(layout, wm, 'IMAGE')
        draw_wait_box(layout, wm.ch_ai_state, 'capture')
        draw_wait_box(layout, wm.ch_ai_state, 'image')
