"""
图像生成器 · 效果图模式绘制段模块

不是面板: 由 ui/panels/ai_image.py 的合并面板在效果图模式下调用, 只画效果图专属内容——
- draw_pass_section: 生成通道小节(预设 / 通道两列网格 / 通道参数 / 通道迷你列表 /
  体积估算与"生成通道"按钮), 位置紧跟生成模式行
- draw_render_settings: 输出侧设置(钳制 + 相机缩放档分辨率 + 实际输出) + 发送通道段
- draw_render_prompt: 描述 / token 摘要 / 提示词工具 / 修改效果图·生成

公共设置(参考图 / 随机种 / 张数 / 负向提示)与列表、预览区都在合并面板里, 本模块不重复绘制.
"""

from bpy.types import Context
from bpy.types import UILayout

from .....common.i18n.i18n import iface
from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt, resolve_prompt
from ...operators.ai_render import (
    CaptureViewRefs,
    GenerateRender,
    ModifyRender,
    PickDepthRange,
    PreviewRenderPrompt,
)
from ...operators.pass_presets import ApplyPassPreset, DeletePassPreset, SavePassPreset
from ...operators.render_send import (
    _PASS_TOGGLES,
    _pass_title,
    _resolve_service,
    ClearPassBackups,
    captured_pass_count,
    collect_ref_images,
    collect_send_passes,
    count_unavailable_ref_images,
    resolve_render_request,
)
from ...operators.ai_texture import SaveAllImages, SaveImage
from ...operators.image_common import active_ref_count
from ...operators.list_ops import DeleteImage
from ...utils import (
    AI_RENDER_PROMPT_TEXT_NAME,
    WARN_EDGE_PX,
    estimate_capture_bytes,
    estimate_prompt_tokens,
    prompt_token_budget,
    resolve_capture_size,
    resolve_ref_limits,
)
from .blocks import (
    RENDER_SIZE_FIELDS,
    draw_fold_header,
    draw_greyed_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_operator,
    draw_size_settings,
)

# 通道迷你列表的行数下限(空列表的矮框高度)
_PASS_ROWS_MIN = 4


def _size_text(num_bytes: int) -> str:
    """字节数转可读体积文案(不足 1MB 用 KB, 单位不翻译不入典)"""
    if num_bytes >= 1024 * 1024:
        return f"{num_bytes / (1024 * 1024):.1f} MB"
    return f"{num_bytes / 1024:.0f} KB"


# --------------------------------------------------------------------------- 生成通道小节


def _draw_pass_preset_row(sub, state) -> None:
    """通道组合预设行: 下拉 + 应用(对勾) / 保存(加号) / 删除(叉号); 预设存于本面板状态"""
    row = sub.row(align=True)
    row.prop(state, "pass_preset_choice", text="")
    draw_operator(row, ApplyPassPreset.bl_idname, None, 'CHECKMARK', text="")
    draw_operator(row, SavePassPreset.bl_idname, None, 'ADD', text="")
    draw_operator(row, DeletePassPreset.bl_idname, None, 'REMOVE', text="")


def _draw_pass_grid(sub, state) -> None:
    """参考通道两列网格(左 4 右 3, 纵向排布; 每项悬停看通道含义)"""
    grid = sub.row(align=False)
    left = grid.column(align=True)
    right = grid.column(align=True)
    left.prop(state, "use_combined")
    left.prop(state, "use_depth")
    left.prop(state, "use_normal")
    left.prop(state, "use_segmentation")
    right.prop(state, "use_edge")
    right.prop(state, "use_diffuse")
    right.prop(state, "use_ao")


def _draw_pass_params(sub, state, cstate) -> None:
    """通道设置 box: 常驻开关(钳制在面板状态/采样数在场景参数组) + 已开启通道各自的生成参数

    整列属性分栏; 参数按通道顺序排布, 只显示已开启通道的项.
    通道勾选(use_*)是面板状态(state), 通道生成参数是场景挂载的 RNA 组(cstate).
    """
    pbox = sub.box()
    pcol = pbox.column()
    pcol.use_property_split = True
    # 场景挂载的参数属可动画 ID 属性, 默认会画出行尾动画修饰钮(菱形);
    # 这些是生成参数不是动画目标, 关掉修饰(rna_prop_ui 画自定义属性同款处理)
    pcol.use_property_decorate = False
    # 渲染采样数(场景参数)为常驻项(与具体通道无关); "钳制输出分辨率"不在这里画 ——
    # 它属于输出尺寸设置, 统一在 Settings 的效果图尺寸段绘制(此处画会与那里重复)
    pcol.prop(cstate, "render_samples")
    if state.use_depth:
        # 深度拾取按钮必须排在 depth_range 属性**之后**且**同一行内**: 只有落在值列才能
        # 与上下数值列左右对齐.prop() 先调以建立行内分裂, 之后追加的按钮即落进值格;
        # 行内不要再设 use_property_split(分裂已由父列继承, 再设会另起一层).
        brow = pcol.row(align=True)
        brow.prop(cstate, "depth_range")
        draw_operator(brow, PickDepthRange.bl_idname, None, 'UV_SYNC_SELECT', text="")
        pcol.prop(cstate, "depth_curve")
    if state.use_normal:
        pcol.prop(cstate, "normal_convention")
    if state.use_segmentation:
        pcol.prop(cstate, "cryptomatte_source")
        pcol.prop(cstate, "crypto_slots")
        pcol.prop(cstate, "smooth_seg_edges")
    if state.use_edge:
        # 先选画什么线(预设), 再调多宽(系数); 末项为材质之间是否出笔画
        pcol.prop(cstate, "edge_preset")
        pcol.prop(cstate, "edge_width_scale")
        pcol.prop(cstate, "use_material_borders")
    if state.use_ao:
        pcol.prop(cstate, "ao_distance")


def _draw_pass_list(sub, state) -> None:
    """通道迷你列表(常驻): 右侧竖列为保存当前 / 保存全部 / 清除备份 / 删除

    通道图不进主列表与画廊(列表分离), 回看在面板内完成; 删除联动清理发送缓存对应通道.
    """
    sub.label(text="Pass List:", icon='IMAGE_DATA')
    list_row = sub.row(align=True)
    list_row.template_list("CH_UL_ai_images", "ch_ai_pass_images", state, "pass_images", state, "pass_images_active_index", rows=max(_PASS_ROWS_MIN, len(state.pass_images)))
    has_sel = 0 <= state.pass_images_active_index < len(state.pass_images)
    btn_col = list_row.column(align=False)
    save_one = btn_col.row(align=False)
    save_one.enabled = has_sel
    draw_operator(save_one, SaveImage.bl_idname, 'PASS', 'FILE_TICK', text="")
    save_all = btn_col.row(align=False)
    save_all.enabled = has_sel
    draw_operator(save_all, SaveAllImages.bl_idname, 'PASS', 'OUTPUT', text="")
    # 一键清除重新捕获时保留的 "_bak" 备份(无备份时按钮自身置灰)
    draw_operator(btn_col.row(align=False), ClearPassBackups.bl_idname, None, 'TRACKING_CLEAR_BACKWARDS', text="")
    del_btn = btn_col.row(align=False)
    del_btn.enabled = has_sel
    draw_operator(del_btn, DeleteImage.bl_idname, 'PASS', 'X', text="")


def _draw_capture_info(sub, state, cstate, scene, provider, prefs) -> None:
    """捕获输出标签: 像素尺寸 + 落盘体积估算 + 长边超阈值的提醒

    标签与实际渲染同口径(未开钳制即 Blender 输出分辨率乘百分比); 体积为按各通道落盘格式
    的估算值, 能提前暴露"通道图另作他用时的大体积"(超阈值只提醒不禁止).
    """
    _limit_count, limit_edge = resolve_ref_limits(provider, prefs)
    clamp_edge = limit_edge if state.use_clamp_resolution else 0
    cap_w, cap_h = resolve_capture_size(scene, clamp_edge)
    keys = [key for attr, key in _PASS_TOGGLES if getattr(state, attr)]
    estimate = estimate_capture_bytes((cap_w, cap_h), keys, cstate.crypto_slots)
    draw_greyed_row(sub, iface("Capture output: {} x {} ({})").format(cap_w, cap_h, _size_text(estimate)))
    if max(cap_w, cap_h) > WARN_EDGE_PX:
        draw_greyed_row(sub, iface("Long edge above {} px, the pass images will be large").format(WARN_EDGE_PX), icon='ERROR')


def _draw_passes_header_summary(header, state, scene, provider, prefs) -> None:
    """生成通道小节收起态摘要: 已捕获通道数 + 发送集过期标记(不展开即可判断能否直接生成)"""
    _count, limit_edge = resolve_ref_limits(provider, prefs)
    _send_names, _missing, stale = collect_send_passes(state, scene, limit_edge)
    note = header.row()
    note.enabled = False
    note.label(text=iface("Captured: {}").format(captured_pass_count()), icon='INFO')
    if stale:
        note.label(text=iface("previews may be outdated"), icon='ERROR')


def draw_pass_section(layout: UILayout, context: Context, state, provider: str, prefs) -> None:
    """生成通道小节(内联可折叠, 默认收起; 仅效果图模式绘制, 位置紧跟生成模式行)

    只放"捕获什么通道, 怎么触发捕获"这两件同族的事.
    标题原文用 "Pass Generation" 而非 "Passes"(后者是系统词条, 只能改原文反译).
    """
    scene = context.scene
    box = layout.box()
    header = draw_fold_header(box, state, "use_show_passes", "Pass Generation")
    if not state.use_show_passes:
        _draw_passes_header_summary(header, state, scene, provider, prefs)
        return
    sub = box.column()
    _draw_pass_preset_row(sub, state)
    _draw_pass_grid(sub, state)
    sub.separator(type='LINE')
    _draw_pass_params(sub, state, scene.ch_ai_capture_params)
    sub.separator(type='LINE')
    _draw_pass_list(sub, state)
    _draw_capture_info(sub, state, scene.ch_ai_capture_params, scene, provider, prefs)
    # 生成通道: 本地渲染所选通道并在图像编辑器预览(不调用 AI 服务, 不产生费用)
    draw_operator(sub, CaptureViewRefs.bl_idname, None, 'RENDERLAYERS')


# --------------------------------------------------------------------------- 发送通道段


def _draw_send_content(col, state, scene, provider, prefs) -> None:
    """发送通道段: 发送开关两行 + 预算摘要与各类警示行

    摘要与生成操作器同口径(勾选发送但缓存与预览图都缺失的通道会阻断, 这里提前点名);
    超限截断与参考图死引用同理提前可见.
    """
    col.use_property_split = False
    row_one = col.row(align=True)
    row_one.prop(state, "use_send_combined", toggle=True)
    row_one.prop(state, "use_send_depth", toggle=True)
    row_one.prop(state, "use_send_normal", toggle=True)
    row_one.prop(state, "use_send_segmentation", toggle=True)
    row_two = col.row(align=True)
    row_two.prop(state, "use_send_edge", toggle=True)
    row_two.prop(state, "use_send_diffuse", toggle=True)
    row_two.prop(state, "use_send_ao", toggle=True)

    _limit_count, _limit_edge = resolve_ref_limits(provider, prefs)
    send_names, missing, _stale = collect_send_passes(state, scene, _limit_edge)
    style_count = len(collect_ref_images(state))
    total = len(send_names) + style_count
    info = col.column(align=True)
    info.enabled = False
    if _limit_count > 0:
        draw_greyed_row(info, iface("Send {} / {} reference images").format(total, _limit_count))
    else:
        draw_greyed_row(info, iface("Send {} reference images").format(total))
    if 0 < _limit_count < total:
        # 与生成同口径: 参考图占保底名额, 通道截断到"上限 - 参考图张数"(被占满时点名)
        room = _limit_count - style_count
        if room < 1:
            draw_greyed_row(info, iface("The {} reference images fill the budget, " "no room for pass images").format(style_count), icon='ERROR')
        else:
            dropped = ", ".join(_pass_title(name) for name in send_names[room:])
            draw_greyed_row(info, iface("Exceeds the provider limit, will drop: {}").format(dropped), icon='ERROR')
    if missing:
        draw_greyed_row(info, iface("Not captured yet: {}").format(", ".join(_pass_title(name) for name in missing)), icon='ERROR')
    # 参考图存在性: 引用悬空/像素未加载的条目不参与发送, 点名提醒清理;
    # 开关已激活但列表为空同样提醒(否则"激活了却没有参考图被发送"无从察觉)
    if state.use_ref_images:
        invalid = count_unavailable_ref_images(state)
        if invalid:
            draw_greyed_row(info, iface("{} reference image(s) unavailable, " "the image is missing").format(invalid), icon='ERROR')
        elif not state.ref_images:
            draw_greyed_row(info, iface("References enabled but the list is empty"), icon='ERROR')
        elif not active_ref_count(state, "ref_images"):
            # 列表里有图但当前模式一张都没勾选: 与空列表同样"没有参考图被发送"
            draw_greyed_row(info, iface("References enabled but no reference image is active in this mode"), icon='ERROR')


def draw_render_size(layout: UILayout, state, provider: str, model: str) -> None:
    """效果图输出尺寸段: 钳制开关 + 分辨率(相机缩放档) + 实际输出

    字段组是效果图自己的一套(比率基准为相机分辨率), 与图像侧互不干扰;
    公共项(随机种/张数/参考图)与发送通道段由合并面板按固定次序穿插.
    """
    layout.prop(state, "use_clamp_resolution")
    draw_size_settings(layout, state, RENDER_SIZE_FIELDS, provider, model, editable=state.render_size_preset == 'CUSTOM', lock_enabled=True)


def draw_send_section(layout: UILayout, state, scene, provider: str, prefs) -> None:
    """发送通道段(仅效果图): "发送通道:" 标签 + 发送开关两行 + 预算摘要与警示行"""
    layout.separator(type='LINE')
    head = layout.column(align=True)
    head.label(text="Send Passes:", icon='RENDERLAYERS')
    send_col = layout.column()
    send_col.use_property_split = False
    _draw_send_content(send_col, state, scene, provider, prefs)


# --------------------------------------------------------------------------- 提示词摘要


def _draw_token_summary(col, state, scene, provider, prefs, sstate) -> None:
    """提示词 token 摘要(置灰右对齐): 与发送组装同口径(resolve_render_request 预览档)

    超硬预算(百炼, 服务端静默截断)与超软建议(方舟, 模型可能忽略细节)措辞区分;
    描述为空时不显示; 组装失败(预算名额不足等)同样不显示.
    """
    prompt_text = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.render_prompt)
    if not prompt_text:
        return
    _provider, _base_url, _api_key, limits = _resolve_service(sstate, prefs)
    err, _notices, _names, _styles, full_prompt = resolve_render_request(state, scene, prompt_text, provider, limits[0], limits[1], require_captured=False)
    if err is not None:
        return
    budget, hard = prompt_token_budget(provider)
    tokens = estimate_prompt_tokens(full_prompt)
    if budget > 0 and tokens > budget:
        if hard:
            draw_greyed_row(col, iface("Prompt: about {} tokens / {} budget, " "it will be truncated").format(tokens, budget), icon='ERROR')
        else:
            draw_greyed_row(col, iface("Prompt: about {} tokens / {} suggestion, " "the model may miss details").format(tokens, budget), icon='ERROR')
    elif budget > 0:
        draw_greyed_row(col, iface("Prompt: about {} tokens / {} budget").format(tokens, budget))
    else:
        draw_greyed_row(col, iface("Prompt: about {} tokens").format(tokens))


# --------------------------------------------------------------------------- 描述与操作


def draw_render_prompt(layout: UILayout, state, scene, provider: str, prefs, sstate) -> None:
    """效果图描述与操作行: 描述框 + 负向 + 长文提示 + token 摘要 + 提示词工具 + 修改/生成

    长文描述块与完整提示词块按效果图分开(AI_Render_Prompt.txt / AI_Render_Final_Prompt.txt).
    """
    layout.separator(type='LINE')
    col = layout.column(align=False)
    prompt_row = col.row(align=True)
    prompt_row.prop(state, "render_prompt", text="Prompt")
    draw_operator(prompt_row, ClearPrompt.bl_idname, 'RENDER', 'CANCEL_LARGE', text="")
    draw_negative_row(col, state, provider, 'RENDER')
    draw_long_desc_hint(col, AI_RENDER_PROMPT_TEXT_NAME)
    _draw_token_summary(col, state, scene, provider, prefs, sstate)
    row = col.row(align=True)
    draw_operator(row, EditPrompt.bl_idname, 'RENDER', 'TEXT')
    row.separator(factor=0.5)
    draw_operator(row, OptimizePrompt.bl_idname, 'RENDER', 'SHADERFX')
    row.separator(factor=0.5)
    draw_operator(row, PreviewRenderPrompt.bl_idname, None, 'WORDWRAP_ON')
    # 操作行: 修改在左(高亮效果图产物为参考图), 生成在右
    # (捕获按钮"生成通道"已移入上方同名小节)
    row = col.row(align=True)
    draw_operator(row, ModifyRender.bl_idname, None, 'GREASEPENCIL')
    row.separator(factor=0.5)
    draw_operator(row, GenerateRender.bl_idname, None, 'KEY_RETURN')
