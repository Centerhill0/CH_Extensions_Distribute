"""
面板共享绘制块模块(非面板)

文本助手与图像助手各面板重复使用的绘制块, 单一来源(两图像面板绘制去重的落点):
- draw_fold_header: 折叠小节标题行(箭头 + 标题), 返回标题行供收起态挂摘要
- draw_greyed_row: 置灰只读行(右对齐/居中, 可选图标)
- draw_image_list_row: 图像列表行 + 右侧竖列(自动打开/排序/删除)
- draw_reference_list: 参考图引用迷你列表 + 加载/移除按钮 + 描述行
- draw_output_settings: 输出参数块(分辨率/实际输出/随机种/张数/变体)
- draw_service_group: 服务设置组(服务模式 + 覆盖模型/生效模型) + 密钥警示
- draw_save_tail / draw_error_box / draw_wait_box / draw_usage_hint
- draw_negative_row / draw_long_desc_hint

约定:
- 各函数只接收"要画的东西", 面板状态与 target 由调用方传入, 绘制逻辑不再逐面板复制;
- 置灰只读行一律走 draw_greyed_row(见该函数说明);
- 需要把按钮挂到某行最右侧时, 把该行交给 draw_right_aligned.
"""

import bpy
from bpy.types import UILayout

from .....common.i18n.i18n import iface
from ...operators.ai_generate import CancelRequest, ClearPrompt, RandomizeSeed
from ...operators.style_refs import ClearStyleDescription, LoadStyleImage, RemoveStyleImage
from ...operators.ai_texture import OpenImageEditor, SaveAllImages, SaveImage
from ...operators.image_common import REF_COLLECTION, REF_INDEX
from ...operators.list_ops import DeleteImage, MoveListItem
from ...operators.script_actions import ClearError, CopyError
from ...preference import get_prefs
from ...utils import resolve_output_size
from ...utils.provider_registry import get_image_provider

# 长文描述提示行的首行预览长度上限(超长内容只在文本编辑器里读)
_DESC_PREVIEW_CHARS = 6
# 错误摘要盒展示的详情行数(取末尾若干行: traceback 的末几行才是有用信息)
_ERROR_TAIL_LINES = 4


# --------------------------------------------------------------------------- 通用小件


def draw_fold_header(box: UILayout, state, attr: str, text: str) -> UILayout:
    """折叠小节标题行: 展开箭头(无浮雕) + 标题, 返回标题行供收起态挂摘要

    四处折叠小节共用(生成通道 / 设置与发送通道 / 生成参数 / 缩略图控件):
    勾选态是"要展开"的意图, 故用 TRIA_DOWN 表示已展开.
    """
    header = box.row()
    header.prop(state, attr, text="", emboss=False, icon='TRIA_DOWN' if getattr(state, attr) else 'TRIA_RIGHT')
    header.label(text=text)
    return header


def draw_right_aligned(row: UILayout) -> UILayout:
    """取该行内一个右对齐的子行(供把按钮贴到行尾, 不影响同行其它元素的位置)"""
    sub = row.row(align=True)
    sub.alignment = 'RIGHT'
    return sub


def draw_greyed_row(col: UILayout, text: str, icon: str = 'INFO', align: str = 'RIGHT', split: bool = True) -> UILayout:
    """置灰只读行(右对齐或居中): 摘要/提示/警示行的统一写法

    统一了原先三种混用的置灰方式(note.enabled / info.enabled 再逐行关分栏 / row.enabled):
    置灰行的语义是"不可交互但可见", 一律用 enabled=False + 单行 label;
    split 为 True 时关掉该行的属性分栏(否则行内 label 会被分栏推挤, 摘要类文案尤其明显).
    """
    row = col.row(align=True)
    row.alignment = align
    row.enabled = False
    if split:
        row.use_property_split = False
    row.label(text=text, icon=icon)
    return row


def draw_operator(row: UILayout, bl_idname: str, target: str | None, icon: str, text: str | None = None, **props):
    """在给定行内建一个算子按钮, 统一"建按钮 -> 赋 target -> 赋附加属性"的三行样板

    调用方传具名算子类的 `Cls.bl_idname`(不传裸字符串): 类名仍写在各调用点,
    grep 与静态审计照常能查出"哪个面板调了哪个算子"(房规 8: 自定义算子一律用
    ClassName.bl_idname, 禁止硬编码 id).

    **text 的两种语义不可混同**(实测踩过):
    - 不传(None) -> 不向 operator() 传 text, 按钮显示算子自身的 bl_label(如 "Modify Render");
    - 传 ""      -> 显式要求空文案, 按钮**只剩图标**;
    故默认必须是 None: 早期版本硬编码 text="" 把所有原本带文字标签的按钮压成了纯图标.
    target 为 None 时不赋 target(供无 target 的算子); 其余算子属性经 **props 传入.
    """
    if text is None:
        op = row.operator(bl_idname, icon=icon)
    else:
        op = row.operator(bl_idname, text=text, icon=icon)
    if target is not None:
        op.target = target
    for key, value in props.items():
        setattr(op, key, value)
    return op


# 输出尺寸字段名组: 图像侧(纹理贴图/图像)与效果图各一套(档位语义与回填基准不同,
# 故字段分开), 绘制逻辑由 draw_size_settings 共用
TEX_SIZE_FIELDS = ("tex_size_preset", "tex_use_size_lock", "tex_width", "tex_height")
IMAGE_SIZE_FIELDS = ("image_size_preset", "image_use_size_lock", "image_width", "image_height")
RENDER_SIZE_FIELDS = ("render_size_preset", "render_use_size_lock", "render_width", "render_height")


# --------------------------------------------------------------------------- 服务设置


def draw_key_warning(col: UILayout, prefs, key_attr: str) -> None:
    """该服务商密钥未配置时在面板内警示; 无对应密钥字段(未知服务商)时跳过"""
    if key_attr and not getattr(prefs, key_attr):
        draw_greyed_row(col, "No API key for this service in the preferences", icon='ERROR', align='LEFT')


def draw_service_group(layout: UILayout, state, title: str, icon: str, key_attr: str, model_attr: str, effective_model: str) -> UILayout:
    """服务设置组(服务模式 + 覆盖模型/生效模型 + 密钥警示), 返回内部列供调用方追加行

    Global 档绘制置灰的生效模型——面板里看不到偏好当前配的是哪个模型, 覆盖档无此问题
    (下拉即生效值).key_attr 由调用方按生效服务商解析后传入.
    """
    box = layout.box()
    box.label(text=title, icon=icon)
    col = box.column(align=False)
    col.prop(state, "service_mode", text="Provider")
    draw_key_warning(col, get_prefs(), key_attr)
    if state.service_mode == 'GLOBAL':
        # 服务面板的置灰提示一律左对齐(与上方的服务商/模型下拉同起点, 不贴右边缘)
        draw_greyed_row(col, iface("Effective model: {}").format(effective_model or "-"), align='LEFT')
    else:
        col.prop(state, model_attr, text="Model")
    return col


# --------------------------------------------------------------------------- 列表与预览


def draw_image_list_row(layout: UILayout, state, collection: str, index_prop: str, list_key: str, target: str, rows: int = 4) -> None:
    """图像列表行 + 右侧竖列(自动打开开关 / 上移 / 下移 / 删除): 图像生成器面板使用

    target 即 MoveListItem/DeleteImage 的目标列表('IMAGE' 主列表 / 'PASS' 通道预览);
    自动打开开关读的是传入 state 的面板级属性(图像三模式共用一个状态组).
    """
    items = getattr(state, collection)
    has_items = len(items) > 0
    row = layout.row(align=True)
    row.template_list("CH_UL_ai_images", list_key, state, collection, state, index_prop, rows=rows)
    # 右侧竖列整列一次置灰(enabled 沿布局继承: 开关/排序/删除在列表为空时同灰)
    col = row.column(align=False)
    col.enabled = has_items
    col.prop(state, "use_auto_open_images", text="", icon='IMAGE_DATA', toggle=True)
    # 排序两键紧凑成一组, 上移/下移各占一行
    # (两键各自写出: 收进循环会让"面板调了哪些算子"在静态上不可见)
    reorder = col.column(align=True)
    draw_operator(reorder, MoveListItem.bl_idname, target, 'TRIA_UP', text="", direction='UP')
    draw_operator(reorder, MoveListItem.bl_idname, target, 'TRIA_DOWN', text="", direction='DOWN')
    draw_operator(col, DeleteImage.bl_idname, target, 'X', text="")


def draw_save_tail(tail: UILayout, state, target: str) -> None:
    """预览区标题行最右侧的按钮列: 保存当前高亮图像 + 保存全部 + 打开图像编辑器
    (列表为空时整行置灰)"""
    tail.enabled = len(state.images) > 0
    draw_operator(tail, SaveImage.bl_idname, target, 'FILE_TICK', text="")
    tail.separator(factor=0.5)
    draw_operator(tail, SaveAllImages.bl_idname, target, 'OUTPUT', text="")
    tail.separator(factor=0.5)
    draw_operator(tail, OpenImageEditor.bl_idname, target, 'ZOOM_ALL', text="")


def draw_reference_list(col: UILayout, state) -> None:
    """参考图引用迷你列表 + 加载/移除按钮 + 高亮条目描述行(开关与显隐由调用方控制)

    三模式共用一份列表(集合/索引属性名取自 operators.image_common 的 REF_COLLECTION / REF_INDEX).
    """
    items = getattr(state, REF_COLLECTION)
    # 独立关闭属性分栏: 列表与描述行按值列排版, 不受父级 property_split 影响
    wrap = col.column()
    wrap.use_property_split = False
    row = wrap.row(align=True)
    row.template_list("CH_UL_ai_style_refs", "ch_ai_refs", state, REF_COLLECTION, state, REF_INDEX, rows=max(1, min(len(items), 3)))
    btns = row.column(align=True)
    draw_operator(btns, LoadStyleImage.bl_idname, None, 'ADD', text="")
    draw_operator(btns, RemoveStyleImage.bl_idname, None, 'REMOVE', text="")
    # 描述行: 高亮条目存在且图像在位时显示(拼进提示词的职责声明), 行尾清除按钮
    index = getattr(state, REF_INDEX)
    if 0 <= index < len(items) and items[index].image is not None:
        desc_row = wrap.row(align=True)
        desc_row.prop(items[index], "description", text="Description")
        draw_operator(desc_row, ClearStyleDescription.bl_idname, None, 'CANCEL_LARGE', text="")


# --------------------------------------------------------------------------- 输出参数


def draw_size_settings(col: UILayout, state, fields: tuple, provider: str, model: str, editable: bool, lock_enabled: bool) -> None:
    """输出尺寸块: 分辨率预设行(含锁定按钮) + 宽高两行 + 实际输出标签

    fields 为 (预设属性名, 锁定属性名, 宽属性名, 高属性名): 图像侧与效果图各一套字段
    (档位语义与回填基准不同), 绘制逻辑共用; provider/model 由调用方解析后传入,
    尺寸约束与实际下发值同口径.
    """
    preset_attr, lock_attr, width_attr, height_attr = fields
    # 分辨率档位行: 行尾为锁定按钮(锁定时调整一边另一边自动跟随)
    res_row = col.row()
    res_row.prop(state, preset_attr)
    lock_wrap = draw_right_aligned(res_row)
    lock_wrap.enabled = lock_enabled
    lock_wrap.prop(state, lock_attr, text="", toggle=True, icon='LINKED' if getattr(state, lock_attr) else 'UNLINKED')

    # 宽高两行与实际输出标签紧凑成组(align=True), 其余行保持默认间距
    pair = col.column(align=True)
    width_row = pair.row()
    width_row.enabled = editable
    width_row.prop(state, width_attr, text="Width")
    height_row = pair.row()
    height_row.enabled = editable
    height_row.prop(state, height_attr, text="Height")
    out_w, out_h = resolve_output_size(provider, model, getattr(state, width_attr), getattr(state, height_attr))
    draw_greyed_row(pair, iface("Actual output: {} x {}").format(out_w, out_h))


def draw_batch_settings(col: UILayout, state, provider: str) -> None:
    """生成批量块(三模式共用): 随机种(行尾骰子) + 生成张数 + 批量多变体

    随机种只有一个字段(三模式共用), 骰子按钮不再需要 target;
    不支持 seed 的服务商整行不绘制.
    """
    if get_image_provider(provider).supports_seed:
        seed_row = col.row(align=True)
        seed_row.prop(state, "seed")
        draw_operator(seed_row, RandomizeSeed.bl_idname, None, 'FILE_REFRESH', text="")
    # 张数>1 逐张串行请求, 每张单独计费; 批量多变体仅张数>1 时可用
    count_row = col.row(align=True)
    count_row.prop(state, "count")
    vary_row = count_row.row()
    vary_row.enabled = state.count > 1
    vary_row.prop(state, "batch_variants", toggle=True)


# --------------------------------------------------------------------------- 提示与进度


def draw_negative_row(col: UILayout, state, provider: str, target: str) -> None:
    """负向提示行(仅 supports_negative_prompt 的服务商显示), 行尾清除按钮"""
    if not get_image_provider(provider).supports_negative_prompt:
        return
    row = col.row(align=True)
    row.prop(state, "negative_prompt", text="Negative Prompt")
    draw_operator(row, ClearPrompt.bl_idname, target, 'CANCEL_LARGE', text="", negative=True)


def draw_long_desc_hint(col: UILayout, text_name: str) -> None:
    """长文描述提示行(置灰, 顺带展示内容首行): 三个生成面板共用

    长文块对用户不可见且静默优先于单行输入, 残留旧描述时看到内容即可发现
    "发的不是我输入的"; 无长文块或为空时不画.
    """
    block = bpy.data.texts.get(text_name)
    if block is None:
        return
    content = block.as_string()
    if not content.strip():
        return
    first_line = next((ln.strip() for ln in content.splitlines() if ln.strip()), "")
    if len(first_line) > _DESC_PREVIEW_CHARS:
        first_line = first_line[:_DESC_PREVIEW_CHARS] + "..."
    draw_greyed_row(col, iface("Using long description: {}").format(first_line))


def draw_error_box(layout: UILayout, wm, target: str, title_attr: str | None = None, detail_attr: str | None = None) -> None:
    """最近请求错误摘要盒(标题 + 详情末尾若干行 + 清除/复制按钮); 无错误时不画

    字段名默认由 target 推导(last_error_<scope>[_detail], 覆盖 chat/image);
    脚本面板的运行错误字段不同(last_error_script/last_error_traceback), 以两参数覆盖传入.
    """
    ai_state = wm.ch_ai_state
    scope = target.lower()
    title_attr = title_attr or f"last_error_{scope}"
    detail_attr = detail_attr or f"{title_attr}_detail"
    title = getattr(ai_state, title_attr)
    if not title:
        return
    box = layout.box()
    header = box.row()
    header.label(text=iface("Last error: {}").format(title), icon='ERROR')
    draw_operator(header, ClearError.bl_idname, target, 'X', text="")
    draw_operator(header, CopyError.bl_idname, target, 'COPYDOWN', text="")
    detail = getattr(ai_state, detail_attr)
    for line in detail.strip().splitlines()[-_ERROR_TAIL_LINES:]:
        box.label(text=line)


def draw_wait_box(layout: UILayout, ai_state, scope: str) -> None:
    """等待进度盒: 进度文案 + 已等待秒数 + 中断按钮(scope: script/chat/image/capture)"""
    status = getattr(ai_state, f"status_{scope}")
    if not status:
        return
    box = layout.box()
    row = box.row()
    row.label(text=status, icon='TIME')
    wait = getattr(ai_state, f"wait_{scope}")
    if wait > 0:
        row.label(text=f"{wait}s")
    draw_operator(row, CancelRequest.bl_idname, scope.upper(), 'CANCEL', text="")


def draw_usage_hint(layout: UILayout, ai_state, scope: str) -> None:
    """最近请求用量行尾提示(token 输入/输出计数); 服务商不下发 usage 时跳过

    值由 ai_generate 的模态主线程回写(见 last_usage_<scope>), 只反映最近一次完成的请求.
    """
    usage = getattr(ai_state, f"last_usage_{scope}")
    if not usage:
        return
    draw_greyed_row(layout, iface("Tokens in / out: {}").format(usage))
