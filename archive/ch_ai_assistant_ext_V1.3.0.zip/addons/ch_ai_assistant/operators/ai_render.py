"""
AI 相机效果图操作模块

场景相机视图渲染提取参考通道, 连提示词送 AI 图像服务参考图生图(严格两步: 捕获与发送分离,
生成绝不内部渲染, 也不要求活动相机——相机只有捕获需要).

操作流程:
1. 生成通道(CaptureViewRefs): 本地用 EEVEE 在临时场景中渲染相机视图并提取所选通道
   (主组一帧出合并结果/深度/法向/漫射颜色/AO, 勾选分割时同帧附加 cryptomatte 各层;
   线稿组一帧; 详见 utils/pass_capture 子包), 以固定名图像数据块预览;
   面板点击为模态按批路径(批间更新等待秒数, Esc/终止按钮批间生效), execute 直调为
   同步一口气路径; 捕获成功后字节与参数指纹经 render_send.store_capture 写入发送缓存,
   上一轮的通道预览图改名加 "_bak" 后缀保留(偏好份数内)
2. 生成效果图(GenerateRender, 纯发送): 只消费发送缓存——发送集组装见 render_send
   (resolve_render_request); 未捕获直接取消并引导"生成通道", 参数指纹过期只提示不阻断
3. 响应处理: 结果图按版本链命名(首版 "AI Render <stem>", 之后 " 2"/" 3" 递增)逐张加载为
   图像数据块(打包) -> 按偏好目录另存 -> 产物置顶到图像列表第一位并按面板开关聚焦图像编辑器
4. 修改效果图(ModifyRender): 以列表高亮的效果图产物(含旧 _bak 备份图)为参考图做 AI 修改,
   被修改版本不改名, 新图按源图主名归入版本链追加序号; 提示词单行框优先(与生成相反),
   输出尺寸取源图尺寸(面板分辨率只管生成)

本模块只放**效果图模式的业务算子**(三个模式共用一个状态组与一个请求作用域);
发送集组装与通道缓存状态在 render_send, 通道组合预设在 pass_presets,
参考图引用维护在 style_refs.

支持的选项(通道参数与分辨率/张数/变体/负向提示等的完整说明见 README「图像生成器」):
- 捕获通道开关 use_<通道> 与发送通道开关 use_send_<通道> 相互独立
- 参考图(三模式共用一份列表): 在效果图模式下作为风格参考, 排在通道图之后发送, 每张占一个参考图预算名额
- 通道参数(开启对应通道才显示): 深度范围/法向约定/线宽系数/材质边界/AO 遮蔽距离等
- Clamp Output Resolution / Resolution / Count / Vary Batch / Negative Prompt
- 通道组合预设: 见 pass_presets
"""

import bpy
import time


from bpy.types import Context
from bpy.types import Event
from bpy.types import Operator


from ....common.i18n.i18n import iface
from ....common.i18n.i18n import report


from ..utils import AI_RENDER_FINAL_PROMPT_TEXT_NAME
from ..utils import AI_RENDER_PREFIX
from ..utils import AI_RENDER_PROMPT_TEXT_NAME
from .ai_generate import AiRequestMixin
from .image_common import ImageRequestArgs
from ..handlers import activate_image
from ..handlers import activate_pass_image
from ..utils import ai_render_name
from ..utils import api_error
from .image_common import batch_image_worker
from .image_common import batch_request_specs
from .image_common import check_image_service
from ..utils import describe_error
from .image_common import effective_negative_prompt
from .image_common import effective_seed
from ..utils import estimate_prompt_tokens
from .image_common import fail_request
from ..utils import focus_text_editors
from ..utils import format_size
from ..preference import get_prefs
from .image_common import highlighted_image
from .image_common import image_timeout_value
from ..utils import image_to_scaled_png_bytes
from ..utils import resolve_ref_limits
from .image_common import land_generated_images
from ..utils import load_image_from_bytes
from .ai_generate import maybe_auto_name_image
from .image_common import modify_image_worker
from ..utils import next_render_version_name
from ..utils import prompt_stem
from ..utils import prompt_token_budget
from ..utils import render_version_stem
from .image_common import report_image_focus
from .ai_generate import report_text_focus
from ..handlers import reset_wait_scope
from .image_common import resolve_and_notify_size
from .image_common import resolve_image_model
from .image_common import resolve_image_service
from ..utils import resolve_output_size
from .ai_generate import resolve_prompt
from ..utils import sample_visible_depth
from ..utils import unique_ai_name
from ..utils import write_text_block


from .render_send import _PASS_TOGGLES, _build_capture_session, _clamp_edge, _pass_send_bytes, _pass_title, _resolve_service, _write_preview_image, capture_fingerprint, resolve_render_request, store_capture


class CaptureViewRefs(Operator):
    """
    生成通道操作器

    功能: 本地用 EEVEE 在临时场景中渲染场景相机视图, 按通道类型提取所选参考通道
    (主组一帧出合并结果/深度/法向/漫射颜色/AO 与 cryptomatte 各层, 线稿组一帧)并以固定名图像
    数据块在图像编辑器预览; 不调用 AI 服务, 不产生 API 费用.
    按钮文案与所在小节同为"生成通道"(原按钮名为"捕获预览").

    面板点击走 invoke 模态路径: PassCaptureSession 按批渲染, 批与批之间让出主线程,
    面板等待框只显示已等待秒数(与 AI 请求等待同款), Esc 与终止按钮在批间生效退出
    (单帧渲染内部不可中断); execute 直调(脚本/测试)为同步一口气路径, 行为与旧版一致.
    两条路径捕获成功后都把字节写入发送缓存(_PASS_CAPTURE_CACHE)供 Generate Render 消费.
    """

    bl_idname = "ch_ai.capture_view_refs"
    bl_label = "Capture Passes"
    bl_description = "Render the camera view passes locally and preview them in the image editor (no API cost)"
    bl_options = {'REGISTER'}

    _STATUS_TEXT = "Capturing passes... (Esc to cancel)"

    # ---- 共享收尾: 捕获字节写入发送缓存 + 固定名预览图 + 列表高亮与按开关聚焦 ----

    def _commit_capture(self, context: Context, passes: dict, notices: list):
        state = context.window_manager.ch_ai_image_state
        prefs = get_prefs()
        _provider, _base_url, _api_key, limits = _resolve_service(context.window_manager.ch_ai_image_service, prefs)
        # 缓存与指纹的属主在 render_send: 只能经 store_capture 写入
        # (在本模块用 global 重绑定会让读方永远看到旧值, 过期提示静默失效)
        store_capture(passes, capture_fingerprint(state, context.scene, _clamp_edge(state, limits[1])))
        last_image = None
        for name, data in passes.items():
            image, img_err = _write_preview_image(self, name, data)
            if img_err is not None:
                self.report({'WARNING'}, describe_error(img_err))
            elif image is not None:
                last_image = image
        if last_image is not None:
            activate_pass_image(context, last_image.name)
        for notice in notices:
            self.report({'INFO'}, describe_error(notice))
        self.report({'INFO'}, report("Captured {} reference passes").format(len(passes)))

    def execute(self, context: Context):
        if context.scene.camera is None:
            self.report({'WARNING'}, "The scene has no active camera")
            return {'CANCELLED'}
        state = context.window_manager.ch_ai_image_state
        prefs = get_prefs()
        _provider, _base_url, _api_key, limits = _resolve_service(context.window_manager.ch_ai_image_service, prefs)
        # 同步直调路径(脚本/测试): 一口气跑完整个会话, 不走模态进度.
        # 会话内部先查增量缓存: 命中的渲染组免渲, 只按当前解码参数重解码(秒级).
        wanted = {key: getattr(state, attr) for attr, key in _PASS_TOGGLES}
        session = _build_capture_session(context, state, wanted, limits)
        err = session.open()
        if err is None:
            while session.has_pending():
                _frame_notices, frame_err, done = session.render_next_frame()
                if frame_err is not None:
                    err = frame_err
                    break
                if done:
                    break
        passes, notices = {}, list(session.notices)
        if err is None:
            passes, _size = session.collect()
            session.commit_cache()
            notices = list(session.notices)
        session.close()
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if not passes:
            self.report({'WARNING'}, "No passes captured, enable at least one pass")
            return {'CANCELLED'}
        self._commit_capture(context, passes, notices)
        return {'FINISHED'}

    # ---- 模态路径: 按批渲染 + 时间进度(等待框与 AI 请求同款, 只显示秒数) ----

    def invoke(self, context: Context, _event: Event):
        if context.scene.camera is None:
            self.report({'WARNING'}, "The scene has no active camera")
            return {'CANCELLED'}
        state = context.window_manager.ch_ai_image_state
        prefs = get_prefs()
        _provider, _base_url, _api_key, limits = _resolve_service(context.window_manager.ch_ai_image_service, prefs)
        wanted = {key: getattr(state, attr) for attr, key in _PASS_TOGGLES}
        if not any(wanted.values()):
            self.report({'WARNING'}, "Enable at least one pass before capturing")
            return {'CANCELLED'}
        ai_state = context.window_manager.ch_ai_state
        if ai_state.status_capture:
            # 只与另一轮捕获互斥: 捕获是本地渲染, 与生成/修改(及对话/脚本)可并行
            self.report({'WARNING'}, "A pass capture is already running, wait for it to finish first")
            return {'CANCELLED'}
        # 会话内部先查增量缓存: 全部渲染组都命中时无需渲染, 不进模态直接出图
        session = _build_capture_session(context, state, wanted, limits)
        open_err = session.open()
        if open_err is not None:
            session.close()
            self.report({'ERROR'}, describe_error(open_err))
            return {'CANCELLED'}
        if not session.has_pending():
            passes, _size = session.collect()
            notices = list(session.notices)
            session.close()
            if not passes:
                self.report({'WARNING'}, "No passes captured, enable at least one pass")
                return {'CANCELLED'}
            self._commit_capture(context, passes, notices)
            return {'FINISHED'}
        self._session = session
        self._passes_state = state
        self._t0 = time.time()
        self._timer = None
        ai_state.status_capture = self._STATUS_TEXT
        ai_state.wait_capture = 0
        ai_state.cancel_capture = False
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:  # noqa: BLE001 - 挂载失败时回收等待标志(见 handlers.reset_wait_scope)
            session.close()
            self._session = None
            reset_wait_scope(ai_state, 'capture')
            self.report({'ERROR'}, "Failed to start the capture modal")
            return {'CANCELLED'}
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._finish(context, cancelled=True)
            return {'CANCELLED'}
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}
        ai_state = context.window_manager.ch_ai_state
        ai_state.wait_capture = int(time.time() - self._t0)
        if ai_state.cancel_capture:
            # 面板终止按钮(capture scope 标志): 批间生效, 放弃整轮捕获
            ai_state.cancel_capture = False
            self._finish(context, cancelled=True)
            return {'CANCELLED'}
        try:
            _frame_notices, err, done = self._session.render_next_frame()
        except Exception as e:  # noqa: BLE001 - 会话外的意外异常同样走错误收尾
            self._finish(context, error=api_error("Failed to capture the camera passes", e))
            return {'CANCELLED'}
        if err is not None:
            self._finish(context, error=err)
            return {'CANCELLED'}
        if done:
            self._finish(context)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def _finish(self, context: Context, cancelled: bool = False, error=None):
        """批间收尾: 回收会话与计时器, 清等待标志; 成功时提交捕获结果

        顺序要求: collect()/commit_cache() 必须在 session.close() **之前** 完成——
        close() 回收的是渲染环境(临时场景/节点组/临时目录), 但会话的 passes 与渲染键
        仍由后续步骤读取; 依赖"close 恰好没清这些字段"是隐性契约, 故显式前置.
        """
        session = getattr(self, "_session", None)
        if getattr(self, "_timer", None) is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        ai_state = context.window_manager.ch_ai_state
        # 只回收捕获自己的标志: 生成/修改仍可能在并行跑, 全清会抹掉它们的进度与中断位
        reset_wait_scope(ai_state, 'capture')
        if cancelled:
            self.report({'INFO'}, "Pass capture cancelled")
        elif error is not None:
            self.report({'ERROR'}, describe_error(error))
        elif session is not None:
            # 先取结果与写缓存(此时会话状态必然可用), 再回收
            passes, _size = session.collect()
            if not passes:
                self.report({'WARNING'}, "No passes captured, enable at least one pass")
            else:
                # 渲染成功后把本次真正渲过的组写入增量缓存(原始落盘字节 + 各组渲染键),
                # 供下次免渲染重解码
                session.commit_cache()
                self._commit_capture(context, passes, session.notices)
        if session is not None:
            session.close()
            self._session = None


class PickDepthRange(Operator):
    """
    深度拾取操作器

    功能: 按当前场景相机的视锥投网格射线采样可见表面的视空间深度(纯几何投射, 不渲染),
    取命中深度的 2%/98% 分位数回填深度范围(近端白/远端黑的区间锚点), 之后仍可手工修改.

    用途: 深度范围是米制场景单位, 默认 (1, 20) 对多数场景并不贴合——反深度曲线的锚点又在
    近端, 区间偏小时整幅画会被压到灰阶底端而看似"纯黑"; 一键拾取把区间贴到实际可见深度上.
    要求: 场景有活动透视相机, 且相机视锥内有几何.
    """

    bl_idname = "ch_ai.pick_depth_range"
    bl_label = "Pick Depth Range"
    bl_description = "Sample the visible scene depth through the camera view and fill the depth range"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context: Context):
        return context.scene is not None and context.scene.camera is not None

    def execute(self, context: Context):
        near, far, hits, err = sample_visible_depth(context.scene)
        if err is not None:
            self.report({'WARNING'}, describe_error(err))
            return {'CANCELLED'}
        context.scene.ch_ai_capture_params.depth_range = (near, far)
        self.report({'INFO'}, report("Depth range picked from {} samples: {} to {}").format(hits, f"{near:.2f}", f"{far:.2f}"))
        return {'FINISHED'}


class GenerateRender(Operator, AiRequestMixin):
    """
    生成效果图操作器

    功能: 把"生成通道"已捕获的参考通道图(按发送开关勾选, 至少一张)连提示词
    发给 AI 图像服务参考图生图, 输出尺寸取面板分辨率设置(经服务商约束修正),
    结果图按面板开关在图像编辑器展示, 并按偏好目录存盘. 本算子不渲染也不要求活动相机——
    通道捕获一律由"生成通道"按钮完成(严格两步), 缓存缺失时提示先运行通道捕获.

    要求: 发送开关勾选且已捕获的通道至少一张(Combined 为出厂默认勾选, 非强制);
    图像服务偏好已配置.
    """

    bl_idname = "ch_ai.generate_render"
    bl_label = "Generate Render"
    bl_description = "Send the captured passes with your prompt to the AI image service, run pass generation first to capture them"
    bl_options = {'REGISTER'}

    status_text = "Generating render... (Esc to cancel)"
    status_scope = 'image'

    def invoke(self, context: Context, event: Event):
        state = context.window_manager.ch_ai_image_state
        if state.mode != 'RENDER':
            # 防御: 效果图模式才有通道可发, 其它模式由 GenerateTexture 处理
            self.report({'WARNING'}, "Switch to the concept render mode first")
            return {'CANCELLED'}
        prompt = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.render_prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the look you want in the prompt field first")
            return {'CANCELLED'}
        if not check_image_service(self, context.window_manager.ch_ai_image_service):
            return {'CANCELLED'}
        # 命名短名随请求一并快照: 等待期间描述被改动时产物名仍与请求内容一致
        self._stem = prompt_stem(prompt)
        self._prompt = prompt

        prefs = get_prefs()
        sstate = context.window_manager.ch_ai_image_service
        provider, base_url, api_key, limits = _resolve_service(sstate, prefs)
        model = resolve_image_model(sstate, prefs)

        # 两步工作流: 只发送"生成通道"已捕获的通道图(绝不内部渲染, 不要求活动相机——
        # 相机只有捕获需要); 组装与预览算子共用同一函数(resolve_render_request),
        # 保证"预览即发送"; 未捕获直接取消引导, 参数过期/超限截断/提示词超预算只提示不阻断
        err, notices, send_names, style_refs, full_prompt = resolve_render_request(state, context.scene, prompt, provider, limits[0], limits[1])
        if err is not None:
            level, message = err
            self.report({'WARNING'} if level == 'WARNING' else {'ERROR'}, message)
            return {'CANCELLED'}
        # level 是单个字符串, report 第一参数要求集合
        for level, message in notices:
            self.report({level}, message)

        # 参考图数组顺序 = send_names 顺序(与提示词 Image N 一一对应), 风格图排在尾部;
        # 通道字节缓存优先(捕获原始字节零重编码), 缺失时从预览图数据块重编码(主线程)
        ref_images = []
        for name in send_names:
            data, enc_err = _pass_send_bytes(name)
            if enc_err is not None:
                self.report({'ERROR'}, describe_error(enc_err))
                return {'CANCELLED'}
            ref_images.append(data)
        # 风格图编码为 PNG 字节(主线程, RNA 不支持跨线程读取), 排在通道图之后;
        # 最长边超服务商参考图上限时缩放**副本**上传, 用户原图数据块零改动
        for ref in style_refs:
            data, enc_err = image_to_scaled_png_bytes(ref.image, limits[1])
            if enc_err is not None:
                self.report({'ERROR'}, describe_error(enc_err))
                return {'CANCELLED'}
            ref_images.append(data)

        # 输出尺寸: 面板宽高(缩放档按相机分辨率长边回填, 自定义档自由输入)先经服务商/模型
        # 约束修正, 再按张数展开逐张规格表(种子 0 已本地抽取回填, 逐张从基准递增)
        out_w, out_h = resolve_and_notify_size(self, provider, model, state.render_width, state.render_height)
        specs = batch_request_specs(provider, model, out_w, out_h, state.count, effective_seed(state, provider), state.batch_variants)
        # 负向提示仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        neg_prompt = effective_negative_prompt(state, provider)

        # 超时 0 = 使用兜底上限(见 image_timeout_value)
        args = (ImageRequestArgs(base_url, api_key, image_timeout_value(prefs), provider), model, full_prompt, specs, neg_prompt, ref_images)
        if not self._start_request(context, batch_image_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, results, err):
        """逐张落地产物: results 为成功图片字节列表, err 为首个请求错误(部分成功时仅告警)"""
        return land_generated_images(self, context, results, err, name_for=self._next_render_name, prefix=AI_RENDER_PREFIX, prompt=self._prompt)

    def _next_render_name(self) -> str:
        """版本链命名: 同 stem 首版无序号, 之后按创建顺序 " 2"/" 3"

        逐张现算(创建计数即时生效); 提示词无英文词的回落名(纯前缀)走 unique_ai_name,
        自动命名后即脱离版本链计数.
        """
        if self._stem:
            return next_render_version_name(self._stem)
        return unique_ai_name(ai_render_name(self._stem))


class PreviewRenderPrompt(Operator):
    """
    最终提示词预览操作器

    功能: 按 Generate Render 的同一组装口径(共用 resolve_render_request)生成实际发送的
    完整提示词, 写入 AI_Render_Final_Prompt.txt 并把文本编辑器聚焦到该块;
    头部记录 token 估算/预算状态与参考图清单, 参数过期等提示一并注明;
    正文即最终提示词(超硬预算时为自动降档后的精简档, 与真实发送逐字一致).
    勾选发送的通道不可用(缓存与预览图数据块都缺失)时与生成档一致阻断并提醒.
    """

    bl_idname = "ch_ai.preview_render_prompt"
    bl_label = "Full Prompt"
    bl_description = "Show the exact prompt that Generate Render will send, assembled with the " "reference roles and guidance, in the text editor"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_image_state
        prompt = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.render_prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the look you want in the prompt field first")
            return {'CANCELLED'}
        prefs = get_prefs()
        sstate = context.window_manager.ch_ai_image_service
        provider, _base_url, _api_key, limits = _resolve_service(sstate, prefs)
        err, notices, send_names, style_refs, full_prompt = resolve_render_request(state, context.scene, prompt, provider, limits[0], limits[1], require_captured=False)
        if err is not None:
            level, message = err
            self.report({'WARNING'} if level == 'WARNING' else {'ERROR'}, message)
            return {'CANCELLED'}
        # 头部摘要(token 估算与预算状态 + 参考图清单 + 不阻断提示), 正文即发送原文
        budget, hard = prompt_token_budget(provider)
        tokens = estimate_prompt_tokens(full_prompt)
        if budget > 0:
            over = tokens > budget
            lines = [iface("Prompt: about {} tokens / {} budget ({})").format(tokens, budget, iface("over budget, hard truncation") if (over and hard) else iface("over the soft suggestion") if over else iface("within budget"))]
        else:
            lines = [iface("Prompt: about {} tokens (no budget known for this provider)").format(tokens)]
        refs = ", ".join(_pass_title(name) for name in send_names) or "-"
        if style_refs:
            refs += ", " + ", ".join(ref.image.name for ref in style_refs)
        lines.append(iface("References: {}").format(refs))
        lines.extend(message for _level, message in notices)
        text, _err = write_text_block(AI_RENDER_FINAL_PROMPT_TEXT_NAME, "\n".join(lines) + "\n\n" + full_prompt)
        focused, _ = focus_text_editors(context, text)
        report_text_focus(self, focused)
        # level 是单个字符串, report 第一参数要求集合
        for level, message in notices:
            self.report({level}, message)
        return {'FINISHED'}


def _resolve_modify_prompt(text_name: str, inline_prompt: str) -> str:
    """修改指令的提示词解析(与生成相反的单行优先): 单行输入框非空优先, 为空回落长文描述块

    修改是下达具体变更指令, 单行框快捷顺手; 长文块里通常是整体风格描述, 直接复用会把
    风格描述当修改指令发出(且覆盖用户的修改意图), 故只作回落.
    """
    inline = inline_prompt.strip()
    if inline:
        return inline
    block = bpy.data.texts.get(text_name)
    if block is None:
        return ""
    return block.as_string().strip()


class ModifyRender(Operator, AiRequestMixin):
    """
    修改效果图操作器

    功能: 以效果图列表当前高亮的生成产物(AI Render 前缀, 含旧 _bak 备份图)为参考图,
    连同描述发给 AI 图像服务参考图生图; 新图按源图主名归入版本链追加序号
    (被修改版本不改名, 历史版本全部保留在列表中); 输出尺寸取源图尺寸(经服务商约束
    修正, 面板分辨率只管生成). 参考通道预览图(AI Ref: 前缀)不可修改.

    要求: 列表中有高亮的效果图产物; 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.modify_render"
    bl_label = "Modify Render"
    bl_description = "Edit the highlighted generated render with the AI edit model based on the prompt, " "creating a new numbered version in the chain; always a single image"
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Modifying render... (Esc to cancel)"
    status_scope = 'image'

    @classmethod
    def poll(cls, context: Context):
        # 三模式共用一个列表: 高亮项必须是效果图产物(AI Render), 否则按钮置灰
        state = context.window_manager.ch_ai_image_state
        if not 0 <= state.images_active_index < len(state.images):
            return
        return state.images[state.images_active_index].name.startswith(AI_RENDER_PREFIX)

    def invoke(self, context: Context, event: Event):
        state = context.window_manager.ch_ai_image_state
        if state.mode != 'RENDER':
            self.report({'WARNING'}, "Switch to the concept render mode first")
            return {'CANCELLED'}
        # 提示词单行优先(与生成相反), 见 _resolve_modify_prompt
        prompt = _resolve_modify_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.render_prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the change in the prompt field first")
            return {'CANCELLED'}
        # 参考通道预览图是固定名的本地捕获(下次捕获先删后建), 修改它们没有意义, 直接拒绝
        source = highlighted_image(self, state, require_prefix=AI_RENDER_PREFIX)
        if source is None:
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_image_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}
        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        # 编辑源图按参考图上限缩放上传(全尺寸 4K/8K 会超服务端限制并放大内存/流量)
        _count, limit_edge = resolve_ref_limits(provider, prefs)
        source_bytes, err = image_to_scaled_png_bytes(source, limit_edge)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}

        model = resolve_image_model(sstate, prefs)
        # 负向提示仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        neg_prompt = effective_negative_prompt(state, provider)
        # 输出尺寸取源图尺寸(修改是"编辑这张图", 结果与源图同画幅; 面板分辨率只管生成),
        # 超服务商输出约束时按比率就近修正; 源图像素未加载时回落面板宽高
        src_w, src_h = source.size
        if src_w <= 0 or src_h <= 0:
            src_w, src_h = state.render_width, state.render_height
        out_w, out_h = resolve_output_size(provider, model, src_w, src_h)
        size_str = format_size(provider, out_w, out_h)
        self._source_name = source.name
        self._prompt = prompt
        args = (ImageRequestArgs(base_url, api_key, image_timeout_value(prefs), provider), model, prompt.strip(), [source_bytes], size_str, effective_seed(state, provider), neg_prompt)
        if not self._start_request(context, modify_image_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, image_bytes, err):
        if err is not None:
            return fail_request(self, context, self.bl_label, err)
        # 版本链命名: 被修改版本不改名, 新图按源图主名归链追加序号(下一号=现有最大+1);
        # 旧 _bak 备份图作源时按主名归链(见 render_version_stem 的归一),
        # 源图缺失(等待期间被删)回落提示词短名
        stem = render_version_stem(self._source_name)
        if stem:
            name = next_render_version_name(stem)
        else:
            name = unique_ai_name(ai_render_name(prompt_stem(self._prompt)))
        image, img_err = load_image_from_bytes(image_bytes, name)
        if img_err is not None:
            self.report({'ERROR'}, describe_error(img_err))
            return {'CANCELLED'}
        focused = activate_image(context, context.window_manager.ch_ai_image_state, image.name, top=True)
        report_image_focus(self, focused)
        self.report({'INFO'}, report("Render '{}' created").format(image.name))
        maybe_auto_name_image(image.name, self._prompt, AI_RENDER_PREFIX)
        return {'FINISHED'}
