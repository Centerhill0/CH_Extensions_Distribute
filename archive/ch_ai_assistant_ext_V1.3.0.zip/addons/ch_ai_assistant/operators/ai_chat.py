"""
纯文本对话操作模块

与 AI 服务进行纯文本问答, 不生成/修改脚本, 不附带场景上下文.

操作流程:
1. 发送消息: 输入框内容入列消息历史, 连同最近历史(上限截断)送 AI, 回复追加到消息历史;
   已附带脚本时把脚本全文拼进消息头部, 发送后附件自动清空; 请求启动失败时回退刚入列的用户消息
2. 附带脚本: 把脚本列表当前高亮脚本标记为下一条消息的附件(再次点击取消)
3. 查看消息: 把当前高亮消息转出到文本编辑器专用文本块, 便于阅读长回复
4. 提取代码: 把当前高亮消息中的代码围栏内容提取到按功能命名的文本块并置顶高亮
5. 复制消息: 把当前高亮消息复制到系统剪贴板
6. 重用消息: 把当前高亮消息填回输入框(历史不动), 便于编辑后重发
7. 完整提示词: 按发送口径组装下一次将实际发送的完整消息列表(系统 + 历史 + 输入框,
   已附带脚本时含附件), 写入 AI_Chat_Final_Prompt.txt 供核对
8. 重新生成: 摘掉最后一轮问答(AI 回复 + 触发它的用户消息), 输入框有内容则改发输入框内容,
   否则把摘掉的最后一条用户消息原样重发
9. 归档对话: 把全部消息转出为 AI_Chat_Archive_<时间> 文本块并开新对话
10. 删除消息: 删除当前高亮的消息条目
11. 清除输入: 清空消息输入框
12. 清空对话: 确认后清空全部消息历史

每次消息历史变动都经 handlers.dump_chat_history 落入 AI_Chat_History.json 文本块
(随 blend 保存, 载入时恢复).
"""

import re
import time

import bpy
from bpy.types import Context, Event, Operator

from ....common.blender.list_snapshot import set_index_after_removal
from ....common.i18n.i18n import iface, report
from ..handlers import activate_script_top, dump_chat_history
from ..preference import get_prefs
from ..utils import (
    AI_CHAT_CODE_NAME,
    AI_CHAT_FINAL_PROMPT_TEXT_NAME,
    AI_CHAT_TEXT_NAME,
    build_chat_messages,
    chat_attachment_message,
    describe_error,
    ensure_unique_name,
    extract_code_blocks,
    focus_text_editors,
    prompt_stem,
    write_text_block,
)
from .ai_generate import (
    AiRequestMixin,
    check_chat_service,
    chat_request_worker,
    clear_request_error,
    record_request_error,
    report_text_focus,
    snapshot_chat_prefs,
)

# 归档文本块保留份数: 只增不删会让 .blend 随归档次数无界膨胀
_ARCHIVE_KEEP = 8

# 代码内顶层函数/类定义名(只取无缩进的顶层定义, 类方法不算; 提取块按功能命名的首选来源)
_DEF_RE = re.compile(r"^(?:def|class)\s+([A-Za-z_]\w*)", re.MULTILINE)


def _chat_code_name(code: str, description: str) -> str:
    """提取代码按功能命名: 顶层 def/class 名优先(跳过下划线私有名, main 降级到最后),
    回落说明文本关键词, 再回落 Chat_Code"""
    candidates = [n for n in _DEF_RE.findall(code) if not n.startswith("_")]
    chosen = next((n for n in candidates if n != "main"), None)
    if chosen is None and candidates:
        chosen = candidates[0]
    if chosen:
        return f"AI Chat_{chosen}.py"
    stem = prompt_stem(description, words=4)
    if stem:
        return f"AI Chat_{stem}.py"
    return AI_CHAT_CODE_NAME


def _selected_message(op, state) -> tuple | None:
    """取当前高亮消息的 (索引, 条目); 无高亮时经 op 上报并返回 None

    全区间判定(负索引在 RNA 集合语义里会绕回末条, 只判上界会静默选错消息),
    五个消息操作算子共用同一守卫与文案.
    """
    idx = state.chat_active_index
    if not 0 <= idx < len(state.chat_messages):
        op.report({'WARNING'}, "No message selected")
        return None
    return idx, state.chat_messages[idx]


def _send_chat(op, context: Context, message: str) -> bool:
    """把一条用户消息入列并发起对话请求, 返回请求是否成功启动(未启动时回退刚入列的消息)

    已附带脚本时脚本全文拼进消息头部, 请求启动成功后清空附件标志;
    入列与回退都随之持久化(dump_chat_history).
    """
    state = context.window_manager.ch_ai_state
    attached_name = state.chat_script_name
    if attached_name:
        block = bpy.data.texts.get(attached_name)
        if block is not None:
            message = chat_attachment_message(message, block.name, block.as_string())
        else:
            op.report({'WARNING'}, report("Attached script '{}' no longer exists, sending without it").format(attached_name))
    item = state.chat_messages.add()
    item.role = 'USER'
    item.content = message
    state.chat_active_index = len(state.chat_messages) - 1
    history = [("user" if m.role == 'USER' else "assistant", m.content) for m in state.chat_messages[:-1]]
    messages, _ = build_chat_messages(history, message, get_prefs().chat_history_limit)
    if not op._start_request(context, chat_request_worker, snapshot_chat_prefs(context.window_manager.ch_ai_text_service), messages):
        # 请求未启动: 回退刚才入列的用户消息, 附件标志与消息一并保留供重发
        state.chat_messages.remove(len(state.chat_messages) - 1)
        state.chat_active_index = max(0, len(state.chat_messages) - 1)
        dump_chat_history(state)
        return False
    state.chat_script_name = ""
    dump_chat_history(state)
    return True


def _handle_chat_reply(op, context: Context, content, err) -> set:
    """对话响应统一落地: 成功追加 AI 消息并持久化; 失败记录面板错误摘要并找回丢失的附件

    请求启动成功后附件标志已被清空, 线程返回错误时把它恢复(供重发),
    用户已重新附带别的脚本时不覆盖.
    """
    state = context.window_manager.ch_ai_state
    if err is not None:
        record_request_error(context, 'chat', op.bl_label, err)
        attached = getattr(op, "_attached_name", "")
        if attached and not state.chat_script_name:
            state.chat_script_name = attached
        op.report({'ERROR'}, describe_error(err))
        return {'CANCELLED'}
    item = state.chat_messages.add()
    item.role = 'ASSISTANT'
    item.content = content
    state.chat_active_index = len(state.chat_messages) - 1
    state.chat_input = ""
    # 本次请求成功, 上次失败留的错误摘要不再成立
    clear_request_error(context, 'chat')
    dump_chat_history(state)
    return {'FINISHED'}


class ChatSend(Operator, AiRequestMixin):
    """
    发送对话消息操作器

    功能: 把输入框消息与最近对话历史发给 AI 服务,
    回复追加到消息历史, 输入框随即清空; 已附带脚本时脚本全文拼进消息头部.
    """

    bl_idname = "ch_ai.chat_send"
    bl_label = "Send Message"
    bl_description = "Send the message to the AI service and append the reply to the conversation"
    bl_options = {'REGISTER'}

    status_text = "Chatting with AI... (Esc to cancel)"
    # 进度显示在对话面板
    status_scope = 'chat'
    # 本次发送使用的附带脚本名(线程错误时找回附件)
    _attached_name = ""

    def invoke(self, context: Context, event: Event):
        message = context.window_manager.ch_ai_state.chat_input.strip()
        if not message:
            self.report({'WARNING'}, "Type a message first")
            return {'CANCELLED'}
        if not check_chat_service(self, context.window_manager.ch_ai_text_service):
            return {'CANCELLED'}
        self._attached_name = context.window_manager.ch_ai_state.chat_script_name
        if not _send_chat(self, context, message):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        return _handle_chat_reply(self, context, content, err)


class ChatCopyMessage(Operator):
    """
    复制消息操作器

    功能: 把当前高亮消息复制到系统剪贴板(回复常被贴到别处阅读/引用).
    """

    bl_idname = "ch_ai.chat_copy_message"
    bl_label = "Copy"
    bl_description = "Copy the selected message to the clipboard"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        sel = _selected_message(self, state)
        if sel is None:
            return {'CANCELLED'}
        context.window_manager.clipboard = sel[1].content
        self.report({'INFO'}, report("Message copied to the clipboard"))
        return {'FINISHED'}


class ChatReuseMessage(Operator):
    """
    重用消息操作器

    功能: 把当前高亮消息填回输入框(历史不动), 便于编辑后重发.
    """

    bl_idname = "ch_ai.chat_reuse_message"
    bl_label = "Reuse"
    bl_description = "Put the selected message back into the input box to edit and resend, the history is unchanged"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        sel = _selected_message(self, state)
        if sel is None:
            return {'CANCELLED'}
        state.chat_input = sel[1].content
        return {'FINISHED'}


class ChatRegenerate(Operator, AiRequestMixin):
    """
    重新生成操作器

    功能: 点击后摘掉最后一轮问答(AI 回复 + 触发它的用户消息), 再按输入框内容决定发什么:
    输入框为空时把摘掉的最后一条用户消息原样重发, 输入框有内容时改发输入框内容
    (不满意回复与"改口径重发"合并到同一个按钮). 启动失败时把摘掉的最后一轮原样还原.
    """

    bl_idname = "ch_ai.chat_regenerate"
    bl_label = "Regenerate"
    bl_description = "Remove the last AI reply and the last user message, then resend the input " "box message if it has content, otherwise the removed user message"
    bl_options = {'REGISTER'}

    status_text = "Chatting with AI... (Esc to cancel)"
    status_scope = 'chat'
    # 本次重新生成使用的附带脚本名(线程错误时找回附件)
    _attached_name = ""

    def invoke(self, context: Context, event: Event):
        state = context.window_manager.ch_ai_state
        msgs = state.chat_messages
        if len(msgs) < 2 or msgs[len(msgs) - 1].role != 'ASSISTANT':
            self.report({'WARNING'}, "The conversation must end with an AI reply to regenerate")
            return {'CANCELLED'}
        if not check_chat_service(self, context.window_manager.ch_ai_text_service):
            return {'CANCELLED'}
        self._attached_name = state.chat_script_name
        # 摘掉最后一轮问答: 末条 AI 回复 + 前一条触发它的用户消息(先从末条起删, 剩余末条即用户消息)
        user_content = msgs[len(msgs) - 2].content
        assistant_content = msgs[len(msgs) - 1].content
        msgs.remove(len(msgs) - 1)
        msgs.remove(len(msgs) - 1)
        state.chat_active_index = max(0, len(state.chat_messages) - 1)
        # 待发内容: 输入框有内容用输入框, 否则回到摘掉的最后一条用户消息
        message = state.chat_input.strip() or user_content
        if not _send_chat(self, context, message):
            # 请求未启动: 还原摘掉的最后一轮, 历史保持原样(_send_chat 已回退它入列的用户消息)
            item = state.chat_messages.add()
            item.role = 'USER'
            item.content = user_content
            item = state.chat_messages.add()
            item.role = 'ASSISTANT'
            item.content = assistant_content
            state.chat_active_index = len(state.chat_messages) - 1
            dump_chat_history(state)
            return {'CANCELLED'}
        dump_chat_history(state)
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        return _handle_chat_reply(self, context, content, err)


class ChatAttachScript(Operator):
    """
    附带脚本操作器

    功能: 把脚本列表当前高亮脚本标记为下一条消息的附件(再次点击同一脚本取消),
    发送时脚本全文拼进消息头部, 发送后附件自动清空.
    """

    bl_idname = "ch_ai.chat_attach_script"
    bl_label = "Attach Script"
    bl_description = "Pin the selected script from the script list to the next message, " "click the highlighted script again to detach"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        idx = state.scripts_active_index
        # 全区间判据(负索引在 Python 里会绕回末条, 只有上界判断会静默选错脚本)
        if not 0 <= idx < len(state.scripts):
            return {'CANCELLED'}
        name = state.scripts[idx].name
        state.chat_script_name = "" if state.chat_script_name == name else name
        return {'FINISHED'}


class ChatViewPrompt(Operator):
    """
    完整提示词操作器

    功能: 按对话发送的组装口径(系统提示词 + 最近历史 + 输入框内容, 已附带脚本时脚本全文
    拼进消息头部), 把下一次实际会发送的消息列表写入 AI_Chat_Final_Prompt.txt 并聚焦
    文本编辑器; 与 ChatSend 逐字一致(同一组装函数), 供核对发送内容.
    输入框为空时无从发送, 报错提示(与发送同款).
    """

    bl_idname = "ch_ai.chat_view_prompt"
    bl_label = "Full Prompt"
    bl_description = "Show the exact prompt the chat will send, assembled with the recent history " "and the attached script, in the text editor"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        message = state.chat_input.strip()
        if not message:
            self.report({'WARNING'}, "Type a message first")
            return {'CANCELLED'}
        attached_name = state.chat_script_name
        if attached_name:
            block = bpy.data.texts.get(attached_name)
            if block is not None:
                message = chat_attachment_message(message, block.name, block.as_string())
        # 历史即现存全部消息(待发消息尚未入列), 与 _send_chat 的组装口径一致
        history = [("user" if m.role == 'USER' else "assistant", m.content) for m in state.chat_messages]
        messages, _ = build_chat_messages(history, message, get_prefs().chat_history_limit)
        # 头部行说明快照语义, 正文即发送原文([system]/[user]/[assistant] 逐字罗列)
        body = "\n\n".join(f"[{m['role']}]\n{m['content']}" for m in messages)
        text, _err = write_text_block(AI_CHAT_FINAL_PROMPT_TEXT_NAME, iface("Chat final prompt (verbatim)") + "\n\n" + body + "\n")
        focused, _ = focus_text_editors(context, text)
        report_text_focus(self, focused)
        return {'FINISHED'}


class ChatViewMessage(Operator):
    """
    查看对话消息操作器

    功能: 把当前高亮消息写入对话专用文本块并聚焦文本编辑器,
    便于阅读被列表截断的长回复.
    """

    bl_idname = "ch_ai.chat_view_message"
    bl_label = "View Message"
    bl_description = "Open the selected message in the text editor to read long replies"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        sel = _selected_message(self, state)
        if sel is None:
            return {'CANCELLED'}
        text, _ = write_text_block(AI_CHAT_TEXT_NAME, sel[1].content)
        focused, _ = focus_text_editors(context, text)
        report_text_focus(self, focused)
        return {'FINISHED'}


class ChatExtractCode(Operator):
    """
    提取代码操作器

    功能: 把当前高亮消息中的代码围栏内容提取到 AI_Chat_Code.py 文本块并聚焦;
    多个代码块按出现顺序拼接, 消息中无代码块时报错.
    """

    bl_idname = "ch_ai.chat_extract_code"
    bl_label = "Extract Code"
    bl_description = "Extract the code blocks from the selected message into a text block"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        sel = _selected_message(self, state)
        if sel is None:
            return {'CANCELLED'}
        code, description, has_blocks = extract_code_blocks(sel[1].content)
        if not has_blocks:
            self.report({'WARNING'}, "No code block in the selected message")
            return {'CANCELLED'}
        name = ensure_unique_name(_chat_code_name(code, description))
        text, _ = write_text_block(name, code)
        # 置顶到脚本列表第一位并高亮
        activate_script_top(context, text.name)
        self.report({'INFO'}, report("Code extracted to '{}'").format(text.name))
        return {'FINISHED'}


class ChatDeleteMessage(Operator):
    """
    删除对话消息操作器

    功能: 删除当前高亮的对话消息条目(不可撤销), 高亮压回有效范围.
    """

    bl_idname = "ch_ai.chat_delete_message"
    bl_label = "Delete Message"
    bl_description = "Delete the selected chat message"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        sel = _selected_message(self, state)
        if sel is None:
            return {'CANCELLED'}
        idx = sel[0]
        state.chat_messages.remove(idx)
        # 高亮压回有效范围(护栏内写入, 不触发转出回调)
        set_index_after_removal(state, "chat_active_index", len(state.chat_messages), idx)
        dump_chat_history(state)
        return {'FINISHED'}


class ChatClearInput(Operator):
    """
    清除输入操作器

    功能: 清空消息输入框(消息历史不受影响).
    """

    bl_idname = "ch_ai.chat_clear_input"
    bl_label = "Clear Input"
    bl_description = "Clear the message input field"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        context.window_manager.ch_ai_state.chat_input = ""
        return {'FINISHED'}


class ChatArchive(Operator):
    """
    归档对话操作器

    功能: 把全部消息按易读格式转出为 AI_Chat_Archive_<时间> 文本块(随 blend 保存),
    然后清空现役对话开新话题; 单线对话模型的"换话题"出口.
    """

    bl_idname = "ch_ai.chat_archive"
    bl_label = "Archive"
    bl_description = "Write the whole conversation to a text block archive and start a new chat"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        if not state.chat_messages:
            self.report({'WARNING'}, "No messages to archive")
            return {'CANCELLED'}
        stamp = time.strftime("%Y%m%d_%H%M")
        name = f"AI_Chat_Archive_{stamp}"
        num = 2
        while name in bpy.data.texts:
            name = f"AI_Chat_Archive_{stamp}_{num}"
            num += 1
        lines = [f"# AI Chat Archive {time.strftime('%Y-%m-%d %H:%M')}", ""]
        for m in state.chat_messages:
            lines += [f"[{'User' if m.role == 'USER' else 'AI'}]", m.content, ""]
        text, _ = write_text_block(name, "\n".join(lines))
        # 归档块只增不删会让 .blend 无界膨胀: 只保留最近若干份(名称含时间, 字典序即时间序)
        archives = sorted(block.name for block in bpy.data.texts if block.name.startswith("AI_Chat_Archive_"))
        for old_name in archives[:-_ARCHIVE_KEEP]:
            bpy.data.texts.remove(bpy.data.texts[old_name])
        if state.use_auto_open_chat:
            focus_text_editors(context, text)
        state.chat_messages.clear()
        state.chat_active_index = 0
        state.chat_script_name = ""
        dump_chat_history(state)
        self.report({'INFO'}, report("Conversation archived to '{}'").format(text.name))
        return {'FINISHED'}


class ChatClear(Operator):
    """
    清空对话操作器

    功能: 确认后清空全部对话消息历史(不可撤销, 与删除脚本同款确认).
    """

    bl_idname = "ch_ai.chat_clear"
    bl_label = "Clear Chat"
    bl_description = "Delete the whole chat history"
    bl_options = {'REGISTER'}

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_state
        state.chat_messages.clear()
        state.chat_active_index = 0
        state.chat_script_name = ""
        dump_chat_history(state)
        return {'FINISHED'}
