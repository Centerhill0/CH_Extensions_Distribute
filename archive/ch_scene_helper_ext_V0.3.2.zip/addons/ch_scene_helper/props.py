"""
场景助手列表与面板状态模块

提供以下功能:
- SceneHelperState: 五个资源列表的快照集合与活跃索引、选区同步/0 用户开关、
  行内列显示开关、详情子面板展开态与 PBR 镜像枚举
- 材质 PBR 镜像枚举的 update 回调: 坐标输出重建接线 / 投影与融合统一写全部命中纹理
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot

注: 单一状态组覆盖全部五个列表; 列表种类元数据见 scene_state.LIST_SPECS.
"""

from bpy.props import BoolProperty, BoolVectorProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Context, PropertyGroup

from ...common.blender.list_snapshot import ListItem, is_syncing
from .handlers import on_images_index_update, on_sync_toggle, on_zero_user_update
from .scene_state import panel_material
from .utils import detect_pbr_texture_graph, get_pbr_texcoord_pair, is_texcoord_update_suppressed, set_texcoord_output
from .utils._constants import PROJECTION_OPTIONS, TEXCOORD_OPTIONS


def _pbr_textures(context: Context) -> list | None:
    """面板活动材质命中的全部 PBR 图像纹理; 不满足检测条件返回 None"""
    mat = panel_material(context)
    if mat is None:
        return None
    pbr = detect_pbr_texture_graph(mat)
    return list(pbr["tex_by_channel"].values()) if pbr["ok"] else None


def on_pbr_texcoord_update(self, context: Context):
    """坐标输出镜像枚举的 update 回调: 重建 TexCoord -> Mapping 的接线

    真值在节点连接关系里, 本枚举只是镜像; 用户改动下拉 = 换接线(不进 Undo 栈, tooltip 说明).
    面板 draw 期把连接真值写回镜像时经算法层抑制跳过本回调(否则每帧重画都会重建接线).
    """
    if is_texcoord_update_suppressed():
        return
    mat = panel_material(context)
    if mat is None:
        return
    target = get_pbr_texcoord_pair(mat)
    if target is None:
        return
    tex_coord, mapping = target
    set_texcoord_output(tex_coord, mapping, self.pbr_texcoord)


def on_pbr_projection_update(self, context: Context):
    """投影统一控制镜像枚举的 update 回调: 把新投影写进全部命中的图像纹理

    真值散在各 Image Texture 节点的 projection 上, 本枚举只是镜像; 用户改动 = 统一改写
    全部命中纹理. Blend 只在 Box 时有意义: 改到非 Box 时把 Blend 归零(与节点面板一致).
    """
    if is_texcoord_update_suppressed():
        return
    textures = _pbr_textures(context)
    if textures is None:
        return
    for tex in textures:
        tex.projection = self.pbr_projection
        if self.pbr_projection != 'BOX':
            tex.projection_blend = 0.0


def on_pbr_projection_blend_update(self, context: Context):
    """投影融合统一控制的 update 回调: 把新 Blend 写进全部命中的图像纹理"""
    if is_texcoord_update_suppressed():
        return
    textures = _pbr_textures(context)
    if textures is None:
        return
    for tex in textures:
        tex.projection_blend = self.pbr_projection_blend


def on_cameras_show_names_update(self, context: Context):
    """视图相机名称开关的 update 回调: 批量设置场景中全部相机的 show_name

    载入文件后的实况回读走护栏写入(handlers._sync_camera_names_state), 见位即跳过,
    避免回读把用户在 N 面板手动设置的个别相机 show_name 批量覆写.
    """
    if is_syncing():
        return
    for obj in context.scene.objects:
        if obj.type == 'CAMERA':
            obj.show_name = self.cameras_show_names


class SceneHelperState(PropertyGroup):
    """场景助手五个列表的快照与全部 UI 状态(WM 级, 不随 .blend 保存)"""

    # --- 快照与活跃索引(索引只表高亮, 不做场景联动) ---
    cameras: CollectionProperty(type=ListItem)  # type: ignore
    cameras_active_index: IntProperty(default=0)  # type: ignore
    lights: CollectionProperty(type=ListItem)  # type: ignore
    lights_active_index: IntProperty(default=0)  # type: ignore
    materials: CollectionProperty(type=ListItem)  # type: ignore
    materials_active_index: IntProperty(default=0)  # type: ignore
    worlds: CollectionProperty(type=ListItem)  # type: ignore
    worlds_active_index: IntProperty(default=0)  # type: ignore
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_images_index_update)  # type: ignore

    # --- 列表范围与同步 ---
    # 选区同步(选项菜单第 1 位, 世界环境无): 四个面板共用同一个开关
    sync_selection: BoolProperty(name="Sync Selection", default=True, update=on_sync_toggle, description="Highlight the list item of the active object whenever the active object changes")  # type: ignore
    # 显示0用户(选项菜单第 2 位, 无该概念的面板不显示; 世界环境始终显示全部)
    show_zero_user_materials: BoolProperty(name="Show 0 Users", default=False, update=on_zero_user_update, description="Also list materials that have no users (orphans and fake-user only)")  # type: ignore
    show_zero_user_images: BoolProperty(name="Show 0 Users", default=False, update=on_zero_user_update, description="Also list images that have no users (orphans and fake-user only)")  # type: ignore

    # --- 列表内建过滤/排序开关镜像 ---
    # template_list 的漏斗开关存在 UIList 实例上, 算子拿不到; UIList.filter_items 每次绘制时
    # 镜像到这两条向量(顺序同 scene_state.LIST_KINDS), 供"上移/下移"判断显示顺序.
    filter_alpha: BoolVectorProperty(size=5, default=(False, False, False, False, False))  # type: ignore
    filter_reverse: BoolVectorProperty(size=5, default=(False, False, False, False, False))  # type: ignore

    # --- 详情子面板展开态 ---
    show_camera_details: BoolProperty(default=True)  # type: ignore
    show_light_details: BoolProperty(default=True)  # type: ignore
    show_material_details: BoolProperty(default=True)  # type: ignore
    show_pbr_details: BoolProperty(default=True)  # type: ignore

    # --- 行内列显示开关 ---
    cameras_show_lens: BoolProperty(name="Lens", default=False, description="Show the lens column")  # type: ignore
    cameras_show_type: BoolProperty(name="Type", default=False, description="Show the camera type column")  # type: ignore
    cameras_show_names: BoolProperty(name="View Camera Name", default=False, description="Show or hide the names of all cameras in the 3D view (writes each camera's show_name flag, saved with the .blend; the toggle state itself is re-read on file load)", update=on_cameras_show_names_update)  # type: ignore
    lights_show_color: BoolProperty(name="Color", default=True, description="Show the light color column")  # type: ignore
    lights_show_shadow: BoolProperty(name="Shadow", default=False, description="Show the shadow toggle column")  # type: ignore
    materials_show_pass_index: BoolProperty(name="Pass Index", default=False, description="Show the pass index column")  # type: ignore
    materials_show_node_count: BoolProperty(name="Node Count", default=False, description="Show the material node count column")  # type: ignore
    images_show_size: BoolProperty(name="Size", default=True, description="Show the image size column")  # type: ignore
    images_show_filepath: BoolProperty(name="File Path", default=False, description="Show the image file path column")  # type: ignore
    worlds_show_color: BoolProperty(name="Color", default=True, description="Show the world color swatch")  # type: ignore

    # --- 材质 PBR 镜像枚举 ---
    # 坐标输出: 真值在 TexCoord->Mapping 的连接里, 绘制前读进镜像, 用户改动重建接线
    pbr_texcoord: EnumProperty(name="Texture Coordinate", items=TEXCOORD_OPTIONS, default=0, update=on_pbr_texcoord_update, description="Texture coordinate output feeding the Mapping node (edits node links, not undoable; affects all users of this material)")  # type: ignore
    # 投影统一控制: 真值在各 Image Texture 的 projection 上; 全部一致 -> 该值, 不一致时保持镜像原值
    pbr_projection: EnumProperty(name="Projection", items=PROJECTION_OPTIONS, default=0, update=on_pbr_projection_update, description="Projection for all PBR image textures (applied to every texture; not undoable)")  # type: ignore
    # 投影融合: 仅 Box 时显示, 写进全部命中纹理
    pbr_projection_blend: FloatProperty(name="Blend", default=0.0, subtype='FACTOR', min=0.0, max=1.0, update=on_pbr_projection_blend_update, description="Blend for box projection, applied to every PBR image texture (not undoable)")  # type: ignore
