"""
场景数据收集工具模块

收集场景中的灯光/相机/材质/图像/世界环境名称供列表快照使用;
收集结果按列表顺序值排序(顺序值挂数据块自定义属性, 算法见 common.blender.list_order):
有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序).

主要功能:
- collect_scene_material_blocks: 场景物体材质槽里实际使用的材质块(去重, 顺序稳定)
- collect_lights: 灯光物体名枚举
- collect_cameras: 相机物体名枚举
- collect_scene_materials: 材质名枚举(默认只收场景实际使用的, 可选纳入 0 用户材质)
- collect_images: 图像名枚举(默认只收有使用者的, 可选纳入 0 用户)
- collect_worlds: 世界环境名枚举(始终全量)
"""

import bpy
from bpy.types import Scene

from .....common.blender.list_order import order_key


def collect_scene_material_blocks(scene: Scene) -> list:
    """收集场景物体材质槽里实际使用的材质块(按首次出现去重, 排除空槽)"""
    seen = set()
    blocks = []
    for obj in scene.objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or mat.name in seen:
                continue
            seen.add(mat.name)
            blocks.append(mat)
    return blocks


def _sorted_names(blocks: list) -> list:
    """按列表顺序值排序并取名称"""
    return [block.name for block in sorted(blocks, key=order_key)]


def collect_cameras(scene: Scene) -> list:
    """收集场景中的相机物体名, 按列表顺序值排序"""
    return _sorted_names([obj for obj in scene.objects if obj.type == 'CAMERA'])


def collect_lights(scene: Scene) -> list:
    """收集场景中的灯光物体名(只含灯光物体), 按列表顺序值排序"""
    return _sorted_names([obj for obj in scene.objects if obj.type == 'LIGHT'])


def collect_scene_materials(scene: Scene, include_zero_user: bool = False, used_materials: list | None = None) -> list:
    """收集材质名并按列表顺序值排序

    Args:
        scene: 目标场景
        include_zero_user: 为真时收集 bpy.data.materials 全量数据块(含 0 用户/仅假用户)
        used_materials: 可选的场景在用材质块列表(include_zero_user 为假时使用)

    Returns:
        材质名称列表
    """
    if include_zero_user:
        blocks = list(bpy.data.materials)
    elif used_materials is not None:
        blocks = used_materials
    else:
        blocks = collect_scene_material_blocks(scene)
    return _sorted_names(blocks)


def real_user_count(datablock) -> int:
    """数据块的真实使用者数量(扣除假用户)

    users 会把假用户算进去, 故删除确认与"仅列有使用者"都按本函数判断.
    """
    return datablock.users - (1 if datablock.use_fake_user else 0)


def _has_real_users(datablock) -> bool:
    """数据块是否有真实使用者"""
    return real_user_count(datablock) > 0


def collect_images(include_zero_user: bool = False) -> list:
    """收集图像名并按列表顺序值排序

    include_zero_user 为假(默认)时只收有真实使用者的图像; 为真时把 0 用户图像也纳入.
    """
    return _sorted_names([img for img in bpy.data.images if include_zero_user or _has_real_users(img)])


def collect_worlds() -> list:
    """收集全部世界环境名并按列表顺序值排序(始终包含 0 用户世界)"""
    return _sorted_names(list(bpy.data.worlds))
