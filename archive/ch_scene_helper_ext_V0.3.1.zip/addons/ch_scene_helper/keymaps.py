"""
快捷键管理模块

提供以下功能:
- 定义插件的快捷键配置
- 注册和注销快捷键映射

快捷键分组:

饼菜单
- CAMERA_PIE: 相机饼菜单 (Alt + C)
- LIGHT_PIE: 灯光饼菜单 (Alt + L)
"""

import bpy
from bpy.types import KeyMap, KeyMapItem

from ...common.i18n.i18n import iface

# ============================================================
# 快捷键配置数据
# ============================================================
# 分组显示名(偏好设置快捷键列表用): 由组键生成的名称("Camera Pie")是运行时字符串,
# 无法入典, 故在此显式声明; 饼菜单组须保留 "Pie" 结尾(偏好设置按此分列)
group_labels: dict[str, str] = {
    'CAMERA_PIE': "Camera Pie",
    'LIGHT_PIE': "Light Pie",
}

keymap_items: dict[str, list[dict[str, object]]] = {
    # 相机辅助饼菜单 (Alt + C)
    'CAMERA_PIE': [
        {'label': 'Object', 'keymaps_name': '3D View', 'space_type': 'VIEW_3D', 'id_name': 'wm.call_menu_pie', 'type': 'C', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_camera_pie"}},
    ],
    # 灯光饼菜单 (Alt + L)
    'LIGHT_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'L', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_light_pie"}},
    ],
}

# 已注册的快捷键存储字典
# 格式: {分组名: [(显示标签, KeyMap, KeyMapItem), ...]}
addon_keymaps: dict[str, list[tuple[str, KeyMap, KeyMapItem]]] = {}


# ============================================================
# 快捷键注册/注销函数
# ============================================================


def register_keymaps() -> None:
    """
    注册插件的快捷键

    遍历 keymap_items 配置,为每个条目创建键映射和键映射项,
    并存储到 addon_keymaps 字典中以便后续注销.

    幂等: 入口先清掉上一代条目. addon_keymaps 按分组名覆盖写入,
    若不清上一代, 旧 KeyMapItem 会失去句柄但仍在 keyconfigs.addon 中继续生效,
    造成同一快捷键触发多次且再也无法注销.
    """
    unregister_keymaps()

    kc = bpy.context.window_manager.keyconfigs.addon
    if not kc:
        return

    for km_name, km_entries in keymap_items.items():
        entries: list[tuple[str, KeyMap, KeyMapItem]] = []

        for entry in km_entries:
            # 创建键映射
            km = kc.keymaps.new(name=entry['keymaps_name'], space_type=entry.get('space_type', 'EMPTY'))

            # 创建键映射项
            kmi = km.keymap_items.new(
                idname=entry['id_name'],
                type=entry['type'],
                value=entry['value'],
                shift=entry.get('shift', False),
                ctrl=entry.get('ctrl', False),
                alt=entry.get('alt', False),
            )

            # 设置操作属性(如菜单名称)
            if 'properties' in entry:
                for prop, value in entry['properties'].items():
                    setattr(kmi.properties, prop, value)

            # 格式化显示标签(先取译文再加缩进: 前导空格会使 Blender 的精确匹配翻译失效)
            display_label = ' ' * 6 + iface(entry['label'])
            entries.append((display_label, km, kmi))

        # 分组显示名(显式声明, 见 group_labels; 未声明者回退为组键生成名)
        addon_keymaps[group_labels.get(km_name, km_name.capitalize().replace('_', ' '))] = entries


def unregister_keymaps() -> None:
    """
    注销插件的快捷键

    遍历 addon_keymaps 字典,移除所有已注册的键映射项,
    并清空存储字典.

    注意: KeyMapItem/KeyMap 被移除后再访问会抛 ReferenceError(而非 RuntimeError/KeyError),
    用户在偏好"快捷键"页删掉任一条目后即产生这种失效句柄; 必须一并吞掉该异常,
    且 addon_keymaps.clear() 放在 finally 中 —— 否则字典残留失效句柄,
    之后每次禁用都在同一条目再次抛错, 插件再也无法干净禁用.
    """
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        if not kc:
            return

        for km_name, entries in addon_keymaps.items():
            for _, km, kmi in entries:
                try:
                    km.keymap_items.remove(kmi)
                except (RuntimeError, KeyError, ReferenceError):
                    pass
    finally:
        # 清空存储字典(无论移除是否成功, 都不能留下失效句柄)
        addon_keymaps.clear()
