"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(相机设置 / 快捷键页签)
- get_prefs: 取本插件偏好实例

面板分两个页签(照 CH Custom Tools 的既有形态):
- Settings: Camera Settings(切换相机与设为场景相机时的视图对齐)
- Hotkeys: 本插件已注册快捷键列表(饼菜单在右列), 附 rna_keymap_ui 的标准改键控件

注: 列表的"选区同步"与"显示0用户"开关在面板选项菜单内,
状态存 WM 级 SceneHelperState, 不随 .blend 保存.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import AddonPreferences, Context, KeyConfig, UILayout
from rna_keymap_ui import draw_kmi

from .config import __addon_name__
from .keymaps import addon_keymaps


def _draw_hotkey_column(layout: UILayout, title: str, groups: list, kc: KeyConfig) -> None:
    """绘制单列快捷键分组列表"""
    col = layout.box()
    col.label(text=title)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            try:
                draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
            except (ReferenceError, AttributeError, ValueError):
                # 用户在本页删除快捷键后, 保存的 kmi 句柄会失效; 跳过该行而不是让整页绘制崩溃
                split.label(text="(removed)")
        row.separator(factor=1, type='LINE')


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    # ----------相机属性----------
    # 设置为活动相机时,是否将视图对齐到相机
    is_align_view: BoolProperty(name="Is Align View", description="Align the view to the selected camera", default=False)  # type: ignore

    # --------------属性--------------
    # 面板模块切换: 设置 / 快捷键
    settings_tab: EnumProperty(
        name="Settings",
        items=[
            ('PREFERENCES', "Settings", "Scene helper and camera settings", 'PREFERENCES', 0),
            ('HOTKEYS', "Hotkeys", "Registered hotkey list", 'KEYINGSET', 1),
        ],
        default='PREFERENCES',
    )  # type: ignore

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 模块切换按钮(从左到右: 设置 / 快捷键)
        row = layout.row()
        row.prop(self, "settings_tab", expand=True)

        if self.settings_tab == 'PREFERENCES':
            # 相机设置(相机饼菜单与相机面板的切换/设为场景相机共用)
            box = layout.box()
            box.label(text="Camera Settings", icon="CAMERA_DATA")
            box.prop(self, "is_align_view")

        else:
            # 快捷键列表(独立 Ops 在左, 饼菜单在右)
            box = layout.box()
            independent_groups = []
            pie_groups = []
            for name, items in addon_keymaps.items():
                if name.lower().endswith('pie'):
                    pie_groups.append((name, items))
                else:
                    independent_groups.append((name, items))

            columns = box.split(factor=0.5)
            _draw_hotkey_column(columns.column(), "Operators", independent_groups, kc)
            _draw_hotkey_column(columns.column(), "Pie Menus", pie_groups, kc)


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
