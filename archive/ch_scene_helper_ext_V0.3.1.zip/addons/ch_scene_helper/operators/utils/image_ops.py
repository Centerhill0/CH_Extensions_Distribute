"""
图像资源维护算子模块

提供以下功能:
- ImageSelectUsers: 选中材质里引用该图像的全部物体
- ImagePack / ImageUnpack: 打包/解包
- ImageReloadAll / ImageSaveAll: 批量重载与保存
- ImageRename: 按引用文件名重命名
- ImageMerge: 把重复图像(name.001)在节点里并回原图
- ImageReplace: 替换节点里对旧图的引用

算法在 utils.blender.image, 本模块只做上下文交互与报告.
"""

import os

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...scene_state import get_state, highlight_item
from ...utils import find_image_users, merge_duplicate_images, reload_external_images, rename_image_from_file, replace_image_reference, select_only


def _active_image_name(context: Context) -> str:
    """图像列表当前活跃项的真实名; 无有效活跃项或数据块已删时返回空串"""
    state = get_state(context)
    idx = state.images_active_index
    if not 0 <= idx < len(state.images):
        return ""
    name = state.images[idx].src_name
    return name if bpy.data.images.get(name) is not None else ""


def _get_image(op: Operator, name: str, warn: bool = False):
    """按名称取图像; 不存在时按需报告并返回 None"""
    img = bpy.data.images.get(name)
    if img is None and warn:
        op.report({'WARNING'}, report("Image not found"))
    return img


class ImageSelectUsers(Operator):
    """选中材质里引用该图像的全部物体"""

    bl_idname = "ch.image_select_users"
    bl_label = "Select Users"
    bl_description = "Select all objects whose materials use this image"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image")  # type: ignore

    def execute(self, context: Context):
        img = _get_image(self, self.image_name, warn=True)
        if img is None:
            return {'CANCELLED'}
        highlight_item(context, "images", img.name)
        users = find_image_users(context.scene, img)
        if not users:
            self.report({'WARNING'}, report("No objects use this image"))
            return {'FINISHED'}
        select_only(context, users)
        return {'FINISHED'}


class ImagePack(Operator):
    """把图像打包进 .blend"""

    bl_idname = "ch.image_pack"
    bl_label = "Pack Image"
    bl_description = "Pack this image into the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image")  # type: ignore

    def execute(self, context: Context):
        img = _get_image(self, self.image_name)
        if img is None:
            return {'CANCELLED'}
        try:
            img.pack()
        except RuntimeError as e:
            self.report({'WARNING'}, report("Pack failed: {}").format(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class ImageUnpack(Operator):
    """把已打包图像解包到磁盘"""

    bl_idname = "ch.image_unpack"
    bl_label = "Unpack Image"
    bl_description = "Unpack this image to disk"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image")  # type: ignore

    def invoke(self, context: Context, event: Event):
        img = _get_image(self, self.image_name)
        if img is None:
            return {'CANCELLED'}
        # 解包固定写回原始路径, 仅当目标文件已存在、确有覆盖风险时才弹确认
        # (否则每次解包都多一次无意义的点击; 与 ImageReloadAll 的"有脏数据才确认"同口径)
        path = bpy.path.abspath(img.filepath) if img.filepath else ""
        if path and os.path.isfile(path):
            self.report({'WARNING'}, report("Unpacking writes to the original path and may overwrite it"))
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context: Context):
        img = _get_image(self, self.image_name)
        if img is None:
            return {'CANCELLED'}
        try:
            img.unpack(method='USE_ORIGINAL')
        except RuntimeError as e:
            self.report({'WARNING'}, report("Unpack failed: {}").format(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class ImageReloadAll(Operator):
    """重载全部外部图像"""

    bl_idname = "ch.image_reload_all"
    bl_label = "Reload All Images"
    bl_description = "Reload every image that references an external file"

    def invoke(self, context: Context, event: Event):
        dirty = [img for img in bpy.data.images if img.is_dirty and img.filepath]
        if not dirty:
            return self.execute(context)
        # 重载会丢弃内存中未保存的绘制/修改
        self.report({'WARNING'}, report("Reloading discards unsaved image edits"))
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: Context):
        count, _error = reload_external_images()
        screen = getattr(context, "screen", None)
        if screen is not None:
            for area in screen.areas:
                area.tag_redraw()
        self.report({'INFO'}, report("Images reloaded: {}").format(count))
        return {'FINISHED'}


class ImageSaveAll(Operator):
    """保存全部已修改图像"""

    bl_idname = "ch.image_save_all"
    bl_label = "Save All Modified"
    bl_description = "Save every modified image that has a file path"

    def execute(self, context: Context):
        if not any(img.is_dirty and img.filepath for img in bpy.data.images):
            self.report({'WARNING'}, report("No modified images to save"))
            return {'CANCELLED'}
        bpy.ops.image.save_all_modified()
        return {'FINISHED'}


class ImageRename(Operator):
    """把图像名改成引用文件名"""

    bl_idname = "ch.image_rename"
    bl_label = "Rename to File Name"
    bl_description = "Rename the image to the name of the file it references"
    bl_options = {'REGISTER', 'UNDO'}

    image_name: StringProperty(name="Image")  # type: ignore
    keep_extension: BoolProperty(name="Keep Extension", default=True, description="Keep the file extension in the image name")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return bool(_active_image_name(context))

    def invoke(self, context: Context, event: Event):
        if not self.image_name:
            self.image_name = _active_image_name(context)
            if not self.image_name:
                self.report({'WARNING'}, report("No image selected"))
                return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context: Context):
        self.layout.prop(self, "keep_extension")

    def execute(self, context: Context):
        name = self.image_name or _active_image_name(context)
        if not name:
            self.report({'WARNING'}, report("No image selected"))
            return {'CANCELLED'}
        img = _get_image(self, name)
        if img is None:
            return {'CANCELLED'}
        ok, error = rename_image_from_file(img, self.keep_extension)
        if not ok:
            self.report({'WARNING'}, report("Rename failed: {}").format(error))
            return {'CANCELLED'}
        return {'FINISHED'}


class ImageMerge(Operator):
    """把重复图像(名称带 .001 后缀)在节点里并回原图"""

    bl_idname = "ch.image_merge"
    bl_label = "Merge Duplicate Images"
    bl_description = "Point image texture nodes at the original image when they use a duplicate such as name.001"
    bl_options = {'REGISTER', 'UNDO'}

    partition: StringProperty(name="Partition", default=".", description="Character that separates the name from the numeric suffix")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context: Context):
        self.layout.prop(self, "partition")

    def execute(self, context: Context):
        count, error = merge_duplicate_images(self.partition)
        if error:
            self.report({'WARNING'}, report(error))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Image references merged: {}").format(count))
        return {'FINISHED'}


class ImageReplace(Operator):
    """把所有材质图像节点里对旧图的引用换成新图"""

    bl_idname = "ch.image_replace"
    bl_label = "Replace Image"
    bl_description = "Replace every reference to the old image with another image"
    bl_options = {'REGISTER', 'UNDO'}

    old_name: StringProperty(name="Old Image")  # type: ignore
    new_name: StringProperty(name="New Image")  # type: ignore
    all_materials: BoolProperty(name="All Materials", default=True, description="Scan every material instead of the active material only")  # type: ignore

    def invoke(self, context: Context, event: Event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context: Context):
        layout = self.layout
        layout.prop_search(self, "old_name", bpy.data, "images", text="Old")
        layout.prop_search(self, "new_name", bpy.data, "images", text="New")
        layout.prop(self, "all_materials")

    def execute(self, context: Context):
        old = _get_image(self, self.old_name, warn=True)
        new = _get_image(self, self.new_name, warn=True)
        if old is None or new is None:
            return {'CANCELLED'}
        count, error = replace_image_reference(old, new, self.all_materials)
        if error:
            self.report({'WARNING'}, report(error))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Image references replaced: {}").format(count))
        return {'FINISHED'}
