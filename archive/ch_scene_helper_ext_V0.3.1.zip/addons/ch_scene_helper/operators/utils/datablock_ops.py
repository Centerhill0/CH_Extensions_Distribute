"""
数据块与世界环境算子模块

提供以下功能:
- DatablockDelete: 删除图像/世界数据块并立即刷新列表
- WorldUnlink: 解除世界与场景的关联(默认); Shift 点击删除世界数据块
- WorldAssign: 把指定世界指认为场景世界
- WorldNew: 新建世界并指认为场景世界
"""

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import id_collection, resolve_id
from ...utils import real_user_count


def _deletion_guard(op: Operator, context: Context, event: Event | None, datablock) -> set | None:
    """数据块删除前的只读/引用检查, 返回 None 表示可以继续删除

    - 库链接数据: 不可删, 直接取消
    - 仍有真实使用者: 弹确认; 无事件(脚本直调)时 fail-closed 直接取消
    """
    if datablock.library is not None:
        op.report({'ERROR'}, report("Linked data-block cannot be deleted"))
        return {'CANCELLED'}
    users = real_user_count(datablock)
    if users <= 0:
        return None
    op.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
    if event is None:
        return {'CANCELLED'}
    if not isinstance(op, Operator):
        # 无法弹模态的调用载体(如面板冒烟/用例桩): 不给隐式放行, 由调用方显式置 confirmed 续跑
        return {'CANCELLED'}
    op.confirmed = True
    return context.window_manager.invoke_confirm(op, event)


class DatablockDelete(Operator):
    """删除列表中的数据块(图像/世界)"""

    bl_idname = "ch.datablock_delete"
    bl_label = "Delete"
    bl_description = "Delete this data-block"
    bl_options = {'REGISTER', 'UNDO'}

    id_name: StringProperty(name="Name")  # type: ignore
    id_kind: StringProperty(name="Kind")  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        datablock = resolve_id(self.id_kind, self.id_name)
        if datablock is None:
            return {'CANCELLED'}
        blocked = _deletion_guard(self, context, event, datablock)
        if blocked is not None:
            return blocked
        return self.execute(context)

    def execute(self, context: Context):
        datablock = resolve_id(self.id_kind, self.id_name)
        collection = id_collection(self.id_kind)
        if datablock is None or collection is None:
            return {'CANCELLED'}
        # 直调(EXEC_DEFAULT)绕过 invoke: 未确认且仍有使用者时拒绝, 避免静默清空节点引用
        if datablock.library is not None:
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        users = real_user_count(datablock)
        if users > 0 and not self.confirmed:
            self.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
            return {'CANCELLED'}
        collection.remove(datablock, do_unlink=True)
        # 数据块移除与活跃索引夹取统一交给快照重建, 不再按 bpy.data 总数手算(过滤列表会错位)
        refresh_lists()
        return {'FINISHED'}


class WorldUnlink(Operator):
    """解除世界与场景的关联(默认); Shift 点击删除世界数据块"""

    bl_idname = "ch.world_unlink"
    bl_label = "Unlink World"
    bl_description = "Unlink this world from the scene (keep the data-block)\n+Shift: Delete the world data-block directly"
    bl_options = {'REGISTER', 'UNDO'}

    world_name: StringProperty(name="World")  # type: ignore
    delete: BoolProperty(name="Delete", description="Delete the world data-block instead of only unlinking it", default=False)  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.delete = bool(event is not None and event.shift)
        if self.delete:
            world = bpy.data.worlds.get(self.world_name)
            if world is not None:
                blocked = _deletion_guard(self, context, event, world)
                if blocked is not None:
                    return blocked
        return self.execute(context)

    def execute(self, context: Context):
        world = bpy.data.worlds.get(self.world_name)
        if world is None:
            return {'CANCELLED'}
        if self.delete:
            # 直调绕过 invoke: 未确认且有场景仍在引用时拒绝删除
            if world.library is not None:
                self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
                return {'CANCELLED'}
            users = real_user_count(world)
            if users > 0 and not self.confirmed:
                self.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
                return {'CANCELLED'}
            bpy.data.worlds.remove(world, do_unlink=True)
            refresh_lists()
            return {'FINISHED'}
        if context.scene.world is not world:
            self.report({'INFO'}, report("World is not linked to the scene"))
            return {'CANCELLED'}
        context.scene.world = None
        refresh_lists()
        return {'FINISHED'}


class WorldAssign(Operator):
    """把该世界指认为场景世界"""

    bl_idname = "ch.world_assign"
    bl_label = "Assign World"
    bl_description = "Use this world as the scene world"
    bl_options = {'REGISTER', 'UNDO'}

    world_name: StringProperty(name="World")  # type: ignore

    def execute(self, context: Context):
        world = bpy.data.worlds.get(self.world_name)
        if world is None:
            return {'CANCELLED'}
        context.scene.world = world
        return {'FINISHED'}


class WorldNew(Operator):
    """新建世界并指认为场景世界"""

    bl_idname = "ch.world_new"
    bl_label = "New World"
    bl_description = "Create a new world and use it as the scene world"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        world = bpy.data.worlds.new("World")
        context.scene.world = world
        refresh_lists()
        return {'FINISHED'}
