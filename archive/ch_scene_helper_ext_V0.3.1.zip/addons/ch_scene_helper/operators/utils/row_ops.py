"""
列表行内动作算子模块

提供以下功能:
- ObjectSelect: 选中物体(Shift 加选 / Alt 减选), 行内选择按钮
- CameraSetView: 选中相机并切到相机视角
- ObjectIsolate: 隔离查看(视口隔离 / Ctrl 渲染隔离), 再点一次恢复
- FakeUserToggle: 伪用户开关(行内按钮, 图标随状态刷新)

算法与状态访问分别在 utils 与 scene_state, 本模块只做上下文交互与报告.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...scene_state import highlight_item, resolve_id
from ...utils import select_object, select_only
from ._base import TranslatedDescriptionMixin


class ObjectSelect(TranslatedDescriptionMixin, Operator):
    """选中行内物体并高亮该列表项(+Shift 加选 / +Alt 减选)"""

    bl_idname = "ch.object_select"
    bl_label = "Select Object"
    bl_description = "Select this object and highlight its list item\n+Shift: Extend selection\n+Alt: Deselect"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore
    list_kind: EnumProperty(name="List", items=(("cameras", "Cameras", ""), ("lights", "Lights", "")), default="cameras")  # type: ignore

    def execute(self, context: Context):
        return self._select(context, extend=False, deselect=False)

    def invoke(self, context: Context, event: Event):
        return self._select(context, extend=bool(event.shift), deselect=bool(event.alt))

    def _select(self, context: Context, extend: bool, deselect: bool):
        """选中目标物体并高亮列表项(invoke/execute 共用; execute 直调按无修饰键处理)"""
        obj = bpy.data.objects.get(self.obj_name)
        if obj is None:
            return {'CANCELLED'}
        highlight_item(context, self.list_kind, obj.name, 'OBJECT')
        select_object(context, obj, extend=extend, deselect=deselect)
        return {'FINISHED'}


class CameraSetView(Operator):
    """选中相机并切换到该相机视角"""

    bl_idname = "ch.camera_set_view"
    bl_label = "Set View"
    bl_description = "Select this camera and look through it"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore

    def execute(self, context: Context):
        obj = bpy.data.objects.get(self.obj_name)
        if obj is None or obj.type != 'CAMERA':
            self.report({'WARNING'}, report("Camera not found"))
            return {'CANCELLED'}
        select_only(context, [obj])
        context.scene.camera = obj
        space = getattr(context, "space_data", None)
        if space is not None and getattr(space, "type", "") == 'VIEW_3D':
            bpy.ops.view3d.object_as_camera()
        return {'FINISHED'}


class ObjectIsolate(TranslatedDescriptionMixin, Operator):
    """隔离查看: 隐藏同类型其他物体(默认视口隔离, +Ctrl 渲染隔离), 再点一次恢复"""

    bl_idname = "ch.object_isolate"
    bl_label = "Isolate"
    bl_description = "Show only this object among the objects of the same type, click again to restore\n+Ctrl: Isolate in the render"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore
    isolate_render: BoolProperty(name="Isolate Render", default=False, description="Isolate the object in the render instead of the viewport")  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.isolate_render = bool(event.ctrl)
        return self.execute(context)

    def execute(self, context: Context):
        scene = context.scene
        obj = scene.objects.get(self.obj_name)
        if obj is None:
            return {'CANCELLED'}
        others = [other for other in scene.objects if other is not obj and other.type == obj.type]
        attr = "hide_render" if self.isolate_render else "hide_viewport"
        any_visible = any(not getattr(other, attr) for other in others)
        for other in others:
            setattr(other, attr, any_visible)
        setattr(obj, attr, False)
        return {'FINISHED'}


class FakeUserToggle(Operator):
    """切换数据块的伪用户标记(列表行内按钮)"""

    bl_idname = "ch.fake_user_toggle"
    bl_label = "Fake User"
    bl_description = "Keep this data-block saved even when it has no users"
    bl_options = {'REGISTER', 'UNDO'}

    id_name: StringProperty(name="Name")  # type: ignore
    id_kind: StringProperty(name="Kind")  # type: ignore

    def execute(self, context: Context):
        datablock = resolve_id(self.id_kind, self.id_name)
        if datablock is None:
            return {'CANCELLED'}
        datablock.use_fake_user = not datablock.use_fake_user
        return {'FINISHED'}
