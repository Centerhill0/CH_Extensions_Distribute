"""
五个资源面板的选项菜单

公共项顺序: 选区同步(世界环境无) -> 显示0用户(材质/图像) -> 按名称重排序;
其后是各面板的列显示开关与批量工具.

菜单只读/写 WM 级面板状态与算子属性, 不触碰偏好.
"""

from bpy.types import Context, Menu, UILayout

from ...operators.utils.image_ops import ImageMerge, ImageReloadAll, ImageRename, ImageReplace, ImageSaveAll
from ...operators.utils.list_ops import ListSort
from ...operators.utils.material_ops import PassIndexBatch
from ...scene_state import LIST_SPECS, get_state


def draw_common_options(layout: UILayout, state, kind: str) -> None:
    """选项菜单公共项: 选区同步 -> 显示0用户 -> 按名称重排序"""
    spec = LIST_SPECS[kind]
    if spec.supports_sync:
        layout.prop(state, "sync_selection")
    if spec.zero_user_prop:
        layout.prop(state, spec.zero_user_prop)
    layout.operator(ListSort.bl_idname).list_kind = kind


class CameraOptions(Menu):
    """相机面板选项"""

    bl_idname = "CH_MT_scene_camera_options"
    bl_label = "Camera Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "cameras")
        layout.separator()
        layout.prop(state, "cameras_show_lens")
        layout.prop(state, "cameras_show_type")


class LightOptions(Menu):
    """灯光面板选项: 选区同步/重排序 + 行内列显示"""

    bl_idname = "CH_MT_scene_light_options"
    bl_label = "Light Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "lights")
        layout.separator()
        layout.prop(state, "lights_show_color")
        layout.prop(state, "lights_show_shadow")


class MaterialOptions(Menu):
    """材质面板选项: 跟随/0 用户/重排序 + 列显示 + 批量通道索引"""

    bl_idname = "CH_MT_scene_material_options"
    bl_label = "Material Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "materials")
        layout.separator()
        layout.prop(state, "materials_show_pass_index")
        layout.prop(state, "materials_show_node_count")
        layout.separator()
        layout.operator(PassIndexBatch.bl_idname, icon='LINENUMBERS_ON')


class ImageOptions(Menu):
    """图像面板选项: 跟随/0 用户/重排序 + 列显示 + 批量维护"""

    bl_idname = "CH_MT_scene_image_options"
    bl_label = "Image Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "images")
        layout.separator()
        layout.prop(state, "images_show_size")
        layout.prop(state, "images_show_filepath")
        layout.separator()
        layout.operator(ImageReloadAll.bl_idname, icon='FILE_REFRESH')
        layout.operator(ImageSaveAll.bl_idname, icon='FILE_TICK')
        layout.operator(ImageRename.bl_idname, icon='FILE_TEXT')
        layout.operator(ImageMerge.bl_idname, icon='FULLSCREEN_EXIT')
        layout.operator(ImageReplace.bl_idname, icon='FILE_REFRESH')


class WorldOptions(Menu):
    """世界环境面板选项: 重排序 + 颜色列(世界始终显示全部)"""

    bl_idname = "CH_MT_scene_world_options"
    bl_label = "World Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "worlds")
        layout.separator()
        layout.prop(state, "worlds_show_color")
