"""
列表行绘制共享 helper

供五个资源列表(ui/lists/scene_lists.py)使用的行绘制单元:
名称列、缺失条目占位、类型图标、选择/隔离/伪用户按钮、行内三状态开关与材质预览图.

列表行状态均为 draw 期直读真实数据块, 不存在快照里; 其中使用者/隔离图标需要遍历
场景物体或材质节点, 成本随规模线性增长(每行各算一次), 大场景下是本模块的主要绘制开销.
"""

from bpy.types import Context, Object, UILayout

from ...operators.utils.image_ops import ImageSelectUsers
from ...operators.utils.material_ops import MaterialSelectUsers
from ...operators.utils.row_ops import FakeUserToggle, ObjectSelect, ObjectIsolate
from ...utils import find_image_users, material_users

# 行内名称列占比(右侧留给状态开关/使用者数)
NAME_FACTOR = 0.76

# 三列排布所需的最小面板宽度(像素): 更窄时回退纯靠右, 避免列区挤压右侧按钮
SPLIT_MIN_REGION_WIDTH = 300

# 灯光类型 -> 图标
LIGHT_ICONS = {
    'POINT': 'LIGHT_POINT',
    'SUN': 'LIGHT_SUN',
    'SPOT': 'LIGHT_SPOT',
    'AREA': 'LIGHT_AREA',
    'HEMI': 'LIGHT_HEMI',
}


def light_icon(obj: Object | None) -> str:
    """灯光行图标: 按灯光类型取; 失效条目回落通用灯图标"""
    if obj is None or obj.type != 'LIGHT':
        return 'LIGHT'
    return LIGHT_ICONS.get(obj.data.type, 'LIGHT')


def camera_icon(context: Context, obj: Object | None) -> str:
    """相机行图标: 场景相机用实心 VIEW_CAMERA 徽标, 其余用大纲相机图标"""
    is_scene_cam = obj is not None and context.scene.camera == obj
    return 'VIEW_CAMERA' if is_scene_cam else 'VIEW_CAMERA_UNSELECTED'


def draw_object_toggles(row: UILayout, obj: Object) -> None:
    """行内三开关: 禁用选中 / 视口隐藏 / 渲染排除

    均只传 _OFF 基图标: IconToggle 对 CONSECUTIVE RNA 属性会按开关态自动换到 _ON
    字形并加反色高亮; 显式传 _ON 会与自动换算叠加成错误字形.
    """
    row.prop(obj, "hide_select", text="", emboss=False, icon='RESTRICT_SELECT_OFF')
    row.prop(obj, "hide_viewport", text="", emboss=False, icon='RESTRICT_VIEW_OFF')
    row.prop(obj, "hide_render", text="", emboss=False, icon='RESTRICT_RENDER_OFF')


def material_preview_icon(mat) -> int:
    """取材质的预览图图标 id(原生材质列表同款彩色小球), 不可用时返回 0

    本插件的 ListItem 是 PropertyGroup 而非 MaterialSlot, 无法走原生自动路径,
    故显式取 mat.preview.icon_id 并以 icon_value 传入. 预览图由图标系统懒渲染,
    未渲染过时 icon_id 为 0(后台通道实测恒 0), 由调用方回落通用 MATERIAL 图标.
    """
    if mat is None:
        return 0
    preview = mat.preview
    if preview is None:
        try:
            preview = mat.preview_ensure()
        except (RuntimeError, AttributeError):
            return 0
    return getattr(preview, "icon_id", 0) if preview is not None else 0


def can_split_columns(context: Context) -> bool:
    """当前面板宽度是否足够容纳"列区 + 靠右按钮区"

    region 不可用时(后台/无界面)按可分割处理, 保持绘制逻辑一致.
    """
    region = getattr(context, "region", None)
    return region is None or getattr(region, "width", 0) >= SPLIT_MIN_REGION_WIDTH


def draw_name_cell(layout: UILayout, item, icon: str = 'NONE', icon_value: int = 0, name_factor: float = NAME_FACTOR) -> UILayout:
    """行内名称列(无浮雕名称编辑框, 双击写穿真实数据块), 返回右侧状态列布局

    icon_value 与 icon 不能同时传(Blender 只认其中之一): icon_value 非 0 时画预览图,
    否则画 icon. 名称作为左右分界; name_factor 在显示列区时调小, 给右侧留空间.
    """
    split = layout.split(factor=name_factor)
    if icon_value:
        split.prop(item, "name", text="", emboss=False, icon_value=icon_value)
    else:
        split.prop(item, "name", text="", emboss=False, icon=icon)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    return right


def draw_split_columns(layout: UILayout, factor: float = 0.5) -> tuple:
    """把行内右侧区域拆成"列区 + 靠右按钮区"

    列区不设置 alignment(默认左对齐), 只按 split 比例占位;
    靠右按钮区保持 alignment='RIGHT'. 返回 (columns, right).
    """
    split = layout.split(factor=factor)
    columns = split.row(align=True)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    return columns, right


def draw_missing_item(layout: UILayout, item) -> None:
    """快照条目已失效时的整行占位(置灰 + 错误图标 + 旧名称)"""
    layout.enabled = False
    layout.label(text=item.name, icon='ERROR')


def _select_state_icon(context: Context, related_objects: list) -> str:
    """首位"选中关联物体"按钮的图标

    关联物体里含活动物体或有选中项 -> RESTRICT_SELECT_OFF(实心), 否则 RESTRICT_SELECT_ON.
    """
    if not related_objects:
        return 'RESTRICT_SELECT_ON'
    active = context.view_layer.objects.active
    if active is not None and any(obj is active for obj in related_objects):
        return 'RESTRICT_SELECT_OFF'
    return 'RESTRICT_SELECT_OFF' if any(obj.select_get() for obj in related_objects) else 'RESTRICT_SELECT_ON'


def draw_select_button(layout: UILayout, context: Context, obj: Object, list_kind: str) -> None:
    """行内选择按钮(相机/灯光): 选中该物体并高亮列表项(+Shift 加选 / +Alt 减选)"""
    icon = _select_state_icon(context, [obj])
    op = layout.operator(ObjectSelect.bl_idname, text="", icon=icon, emboss=False)
    op.obj_name = obj.name
    op.list_kind = list_kind


def draw_material_select(layout: UILayout, context: Context, mat) -> None:
    """材质的"选中使用者"按钮(三态图标, 点击同时高亮材质列表项)"""
    users = material_users(context.scene, mat)
    icon = _select_state_icon(context, users)
    op = layout.operator(MaterialSelectUsers.bl_idname, text="", icon=icon, emboss=False)
    op.mat_name = mat.name


def draw_image_select(layout: UILayout, context: Context, img) -> None:
    """图像的"选中使用者"按钮(三态图标, 点击同时高亮图像列表项)"""
    users = find_image_users(context.scene, img)
    icon = _select_state_icon(context, users)
    op = layout.operator(ImageSelectUsers.bl_idname, text="", icon=icon, emboss=False)
    op.image_name = img.name


def draw_isolate_button(layout: UILayout, context: Context, obj: Object) -> None:
    """隔离按钮: 未隔离 SOLO_OFF / 已隔离 SOLO_ON(默认视口隔离, +Ctrl 渲染隔离)"""
    others = [other for other in context.scene.objects if other is not obj and other.type == obj.type]
    is_isolated = bool(others) and not obj.hide_viewport and all(other.hide_viewport for other in others)
    icon = 'SOLO_ON' if is_isolated else 'SOLO_OFF'
    op = layout.operator(ObjectIsolate.bl_idname, text="", icon=icon, emboss=False)
    op.obj_name = obj.name


def draw_fake_user_count(row: UILayout, datablock, id_kind: str) -> None:
    """行内伪用户开关 + 紧随其后的两位数使用者数"""
    icon = 'FAKE_USER_ON' if datablock.use_fake_user else 'FAKE_USER_OFF'
    op = row.operator(FakeUserToggle.bl_idname, text="", icon=icon, emboss=False)
    op.id_name = datablock.name
    op.id_kind = id_kind
    row.label(text="{:02d}".format(datablock.users))
