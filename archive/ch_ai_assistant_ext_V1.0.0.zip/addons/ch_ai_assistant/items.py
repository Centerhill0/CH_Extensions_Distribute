"""
插件级静态枚举条目与常量表模块

集中收口各面板与偏好设置的下拉枚举 items 表与档位映射常量(单一来源),
供 props(状态属性)与 preference(偏好属性)两处引用; 本模块只放**纯静态数据**,
不依赖 utils/preference/props, 处于依赖最底层.

列表命名保持 *_items 结尾, 供 i18n 提取器全局扫描(提取器按名字不按位置识别);
"User"/"OpenGL"/"DirectX" 等与 Blender 系统词条同形的名称, 提取/翻译语义不变.

本模块的名字均为跨模块显式导入的公开常量, 故不加下划线前缀
(下划线表示"模块私有", 与此处"单一来源供全局引用"的定位相悖).

服务商枚举 / 候选模型 / 思考档位的 *_items 字面量本体在 utils/provider_registry.py
(保持「xxx_items = [元组字面量]」形态供 i18n 提取器扫描), 偏好/面板需要时直接从
provider_registry 导入, 本模块不再 re-export, 见 docs/provider-registry-design.md.
"""

from .utils.provider_registry import (
    dashscope_t2i_items,
    deepseek_model_items,
    glm_model_items,
    volcengine_t2i_items,
)

# ---- 对话消息角色("User"为 Blender 系统词条, 不入插件词典) ----
CHAT_ROLE_ITEMS = [
    ('USER', "User", ""),
    ('ASSISTANT', "AI", ""),
]

# ---- 服务模式(面板服务覆盖: Global 跟随偏好, 其余覆盖到该服务商) ----
# 图像服务商(纹理/效果图面板共用)
service_mode_items = [
    ('GLOBAL', "Global", "Use the image service configured in the preferences"),
    ('VOLCENGINE', "Volcengine Ark", "Override with the Volcengine Ark service"),
    ('DASHSCOPE', "Alibaba DashScope", "Override with the Alibaba DashScope service"),
]
# 文本服务商(脚本/对话面板共用)
text_service_mode_items = [
    ('GLOBAL', "Global", "Use the text service configured in the preferences"),
    ('DEEPSEEK', "DeepSeek", "Override with the DeepSeek service"),
    ('GLM', "Zhipu GLM", "Override with the Zhipu GLM service"),
]

# ---- 模型候选表(标识即模型名; 偏好下拉与面板覆盖下拉共用单一来源, 自注册表字面量) ----
TEXT_PROVIDER_MODEL_ITEMS = {
    'DEEPSEEK': deepseek_model_items,
    'GLM': glm_model_items,
}
PROVIDER_MODEL_ITEMS = {
    'VOLCENGINE': volcengine_t2i_items,
    'DASHSCOPE': dashscope_t2i_items,
}

# 面板覆盖下拉的"跟随偏好"哨兵档(空串**标识**合法, 空串**赋值**非法, 见 props):
# 仅 service_mode == 'GLOBAL' 时兜底使用
prefs_model_items = [
    ('', "Follow preferences", "Use the model configured in the preferences"),
]
# 偏好模型下拉的"自定义"档: 选中后下方显示模型 ID 输入框
CUSTOM_MODEL_ITEM = ('CUSTOM', "Custom", "Enter a custom model ID manually")

# ---- 脚本注释语言 ----
comment_language_items = [
    ('CHINESE', "Chinese", "Write script comments in Chinese"),
    ('ENGLISH', "English", "Write script comments in English"),
]

# ---- 纹理/图像生成 ----
# 生成模式(面板以 expand=True 展开按钮绘制): 纹理贴图 / 图像
generation_mode_items = [
    ('TEXTURE', "Texture Map", "Generate a material texture map: the prompt is guided toward a tileable texture"),
    ('PHOTO', "Image", "Generate any image from the prompt as-is"),
]
# 纹理贴图模式尺寸预设(方图)
tex_size_preset_items = [
    ('1K', "1K", "Output 1024 x 1024"),
    ('2K', "2K", "Output 2048 x 2048"),
    ('CUSTOM', "Custom", "Free width and height in pixels"),
]
# 图像模式尺寸预设(常用宽高比)
image_size_preset_items = [
    ('1:1', "1:1", "Width to height ratio 1:1"),
    ('16:9', "16:9", "Width to height ratio 16:9, landscape"),
    ('9:16', "9:16", "Width to height ratio 9:16, portrait"),
    ('4:3', "4:3", "Width to height ratio 4:3"),
    ('3:4', "3:4", "Width to height ratio 3:4"),
    ('3:2', "3:2", "Width to height ratio 3:2, landscape"),
    ('2:3', "2:3", "Width to height ratio 2:3, portrait"),
    ('CUSTOM', "Custom", "Free width and height in pixels"),
]
# 纹理贴图模式的方图档位(标识 -> 长边像素)
TEXTURE_PRESET_LONG_EDGES = {'1K': 1024, '2K': 2048}
# 图像模式的常用宽高比(标识 -> 宽/高), 预设回填以 2048 为长边
IMAGE_RATIOS = {
    '1:1': 1.0,
    '16:9': 16 / 9,
    '9:16': 9 / 16,
    '4:3': 4 / 3,
    '3:4': 3 / 4,
    '3:2': 3 / 2,
    '2:3': 2 / 3,
}
IMAGE_LONG_EDGE = 2048

# ---- 效果图输出分辨率 ----
# 缩放档位(标识 -> 倍数); CUSTOM 不在表内
RENDER_SCALE_FACTORS = {'50': 0.5, '75': 0.75, '100': 1.0, '150': 1.5, '200': 2.0}
# 缩放档为相机分辨率长边的百分比, CUSTOM 自由输入宽高
# (比率恒锁相机分辨率而非参考图: 参考图长边封顶 2048 后比率可能与相机设定有细微出入)
render_scale_items = [
    ('50', "50%", "Half of the camera resolution"),
    ('75', "75%", "Three quarters of the camera resolution"),
    ('100', "100%", "Match the camera resolution"),
    ('150', "150%", "One and a half times the camera resolution"),
    ('200', "200%", "Twice the camera resolution"),
    ('CUSTOM', "Custom", "Free width and height in pixels"),
]

# ---- 效果图参考通道参数 ----
# 法向约定("OpenGL"/"DirectX"为专有名词, 系统词条同形不影响显示)
normal_convention_items = [
    ('OPENGL', "OpenGL",
     "Green channel points up, the convention Blender itself uses"),
    ('DIRECTX', "DirectX",
     "Green channel points down, for engines expecting DirectX-style normal maps"),
]
# 深度 8bit 量化映射曲线("Linear"系统词条译"线性"不入典)
depth_curve_items = [
    ('INVERSE', "Inverse Depth",
     "Map by inverse depth (disparity): gray levels concentrate on the near field "
     "where the subject lives, matching AI depth conventions"),
    ('LINEAR', "Linear",
     "Map the near-far range linearly to white and black"),
]
