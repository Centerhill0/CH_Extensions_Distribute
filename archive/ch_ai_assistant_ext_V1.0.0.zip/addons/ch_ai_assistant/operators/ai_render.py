"""
AI 相机效果图操作模块

场景相机视图渲染提取参考通道(合并结果/深度/法向/语义分割/边缘/漫射颜色/AO 按勾选),
连提示词送 AI 图像服务参考图生图(严格两步: 捕获与发送分离, 生成绝不内部渲染,
也不要求活动相机——相机只有捕获需要).

操作流程:
1. 生成通道(CaptureViewRefs): 本地用 EEVEE 在临时场景中分三帧渲染相机视图并提取所选通道
   (合并结果/深度/法向/漫射颜色/AO 共享第一帧, 语义分割与线稿各占一帧, 详见 utils/render_passes),
   以固定名图像数据块预览; 面板点击为模态分帧路径(帧间更新等待秒数, Esc/终止按钮帧间生效),
   execute 直调为同步一口气路径; 捕获成功后字节写入模块级发送缓存 _PASS_CAPTURE_CACHE
   (含参数指纹), 上一轮的通道预览图改名加 "_bak" 后缀保留(偏好份数内)
2. 生成效果图(GenerateRender, 纯发送): 只消费发送缓存——按发送开关(与捕获勾选独立)收集
   已捕获通道 + 风格参考图, 截断到服务商参考图上限(风格图占保底名额), 提示词经
   resolve_render_prompt 组装(通道职责+反泄漏+构图引导, 超硬预算自动降精简档),
   与 PreviewRenderPrompt 共用同一组装函数保证"预览即发送";
   未捕获直接取消并引导"生成通道", 参数指纹过期只提示不阻断
3. 响应处理: 结果图按版本链命名(首版 "AI Render <stem>", 之后 " 2"/" 3" 递增)逐张加载为
   图像数据块(打包) -> 按偏好目录另存 -> 产物置顶到图像列表第一位并聚焦图像编辑器
4. 修改效果图(ModifyRender): 以列表高亮的效果图产物(含旧 _bak 备份图)为参考图做 AI 修改,
   被修改版本不改名, 新图按源图主名归入版本链追加序号; 提示词单行框优先(与生成相反),
   输出尺寸取源图尺寸(面板分辨率只管生成)

支持的选项:
- 捕获通道开关 use_<通道> 与发送通道开关 use_send_<通道> 相互独立:
  捕获控制"生成通道"按钮渲染哪些, 发送控制 Generate Render 发送哪些已捕获通道
  (支持多捕获,挑着发; 通道序一律 PASS_ORDER 参考优先序; 生成不强制 Combined,
  但发送集中至少要有一张已捕获通道图)
- 风格参考图(style_images): 多张外部图排在通道图之后发送, 每张占一个参考图预算名额
  (超服务商最长边时自动缩放副本上传, 原图零改动)
- 通道参数(开启对应通道才显示): 深度范围(近/远场景单位, 深度图按近端白~远端黑映射,
  曲线默认反深度——8bit 灰阶向近场集中, 主体景深细节保留最多, 可切线性;
  深度范围行**内**(数值右侧)另有「深度拾取」按钮: 按相机视锥几何投射采样可见深度并回填范围,
  回填后仍可手改) /
  法向约定(OpenGL 绿通道向上, DirectX 向下) / 线宽系数 / 材质边界(材质之间是否
  生成笔画) / AO 遮蔽距离
- Clamp Output Resolution: 通道输出分辨率钳制开关, 关闭时直接用 Blender 输出分辨率
  (乘 Resolution Scale), 打开后仅在最长边超出**当前服务商**参考图上限时按百分比等比下调
  (宽高比不变); 上限取偏好解析出的当前服务商参考图最长边(跟随官方上限或用户自定义值)
- Resolution: 输出分辨率, 缩放档(相机分辨率长边的 50%-200%)或自定义宽高, 比率恒锁相机分辨率
- Count: 一次生成的张数(1-5), 逐张串行请求(等待文案带 [i/n] 进度), 每张单独计费
- Vary Batch: 张数>1 时每张换宽高比变体与随机种(一次产出多种构图)
- Negative Prompt: 负向提示(仅百炼 Qwen-Image 支持, 其余服务商不下发)
- 通道组合预设: 捕获/发送两组开关的命名快照(存于偏好, 跨会话), 下拉+应用/保存/删除
"""

import re
import time

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import iface, report
from ....common.ui.list_snapshot import set_guarded
from ..handlers import activate_image, activate_pass_image, dump_image_refs, reset_wait_state, sync_images_now
from ..preference import get_prefs
from ..utils import (
    AI_REF_PREFIX,
    AI_RENDER_FINAL_PROMPT_TEXT_NAME,
    AI_RENDER_PREFIX,
    AI_RENDER_PROMPT_TEXT_NAME,
    PASS_ORDER,
    PassCaptureSession,
    capture_render_key,
    recapture_from_raw,
    store_raw_cache,
    ai_render_name,
    api_error,
    capture_camera_passes,
    describe_error,
    estimate_prompt_tokens,
    focus_text_editors,
    format_size,
    image_to_png_bytes,
    image_to_scaled_png_bytes,
    load_image_from_bytes,
    prompt_stem,
    prompt_token_budget,
    request_image,
    render_version_stem,
    next_render_version_name,
    resolve_capture_size,
    resolve_output_size,
    resolve_ref_limits,
    resolve_render_prompt,
    sample_visible_depth,
    save_image_file,
    unique_ai_name,
    write_text_block,
)
from .ai_generate import AiRequestMixin, maybe_auto_name_image, record_request_error, resolve_prompt
from .ai_texture import (
    ImageRequestArgs,
    _batch_request_specs,
    _prune_image_backups,
    check_image_service,
    collect_ref_entries,
    count_unavailable_refs,
    effective_seed,
    modify_image_worker,
    resolve_edit_model,
    resolve_image_service,
)

# 通道键 -> 预览数据块标题(AO 不能走 capitalize, 否则成 "Ao"; 与面板选项标签保持一致)
_PASS_TITLES = {
    'combined': "Combined Result",
    'depth': "Depth",
    'normal': "Normal",
    'segmentation': "Semantic Segmentation",
    'edge': "Line Drawing",
    'diffuse': "Diffuse Color",
    'ao': "AO",
}


def _pass_title(name: str) -> str:
    """通道键转预览标题, 未知键回落 capitalize 兜底"""
    return _PASS_TITLES.get(name, name.capitalize())


def _write_preview_image(op, name: str, image_bytes: bytes) -> tuple:
    """把通道图写为固定名预览图像数据块, 返回 (Image 数据块, 错误信息)

    上一轮的预览图不删除而是改名加 "_bak" 后缀保留(与"修改效果图"对原图的处理一致),
    超出偏好份数的最旧备份随即清理; 重名由 Blender 自动加序号, 新图取回原名.
    """
    datablock_name = f"AI Ref: {_pass_title(name)}"
    old = bpy.data.images.get(datablock_name)
    if old is not None:
        old.name = f"{datablock_name}_bak"
        _prune_image_backups(op, datablock_name, old.name)
    return load_image_from_bytes(image_bytes, datablock_name)


def _resolve_service(sstate, prefs) -> tuple:
    """解析生效图像服务与参考图限制, 返回 (服务商, base_url, api_key, (张数上限, 最长边上限))

    服务商取自共享服务设置(Global 档跟随偏好), 与生成操作器同源;
    限制取偏好的参考图自定义值(仅对偏好中的服务商生效), 面板的"钳制输出分辨率"与
    参考图张数截断共用本结果.
    """
    provider, base_url, api_key = resolve_image_service(sstate, prefs)
    return (provider, base_url, api_key, resolve_ref_limits(provider, prefs))


def _clamp_edge(rstate, limit_edge: int) -> int:
    """按钳制开关解析本次渲染的长边上限(开关关闭或上限为 0 时不钳制)"""
    return limit_edge if rstate.use_clamp_resolution else 0


# ------------------------------------------------------------
# 通道捕获缓存(两步工作流的发送字节权威源)
# ------------------------------------------------------------

# 通道键 -> 发送字节(即"生成通道"按钮捕获的原始字节, JPEG/PNG 零重编码);
# Generate Render 只消费该缓存, 绝不内部渲染(严格两步); Blender 重启后为空(视同未捕获)
_PASS_CAPTURE_CACHE: dict = {}
# 捕获时的参数指纹(capture_fingerprint 的返回值): 发送时与当前面板比对,
# 不一致只提示"预览可能过期"不阻断(场景建模改动无法自动感知, 由作者手动重捕获)
_CAPTURE_FINGERPRINT: tuple | None = None

# 捕获/发送通道开关属性名 -> 通道键(均按 PASS_ORDER 参考优先序派生, 单一来源):
# 捕获开关 use_<key> 控制本地渲染哪些通道, 发送开关 use_send_<key> 控制发送哪些已捕获通道
_PASS_TOGGLES = tuple((f"use_{key}", key) for key in PASS_ORDER)
_SEND_TOGGLES = tuple((f"use_send_{key}", key) for key in PASS_ORDER)


def clear_pass_cache():
    """清空通道捕获缓存与指纹(捕获流程启动前的防御性重置)"""
    _PASS_CAPTURE_CACHE.clear()
    global _CAPTURE_FINGERPRINT
    _CAPTURE_FINGERPRINT = None


def clear_pass_cache_ref(name: str):
    """删除 AI Ref: 前缀预览图后联动清理缓存对应通道(保持"列表里没有 = 不会发送")"""
    if not name.startswith(AI_REF_PREFIX):
        return
    title = name[len(AI_REF_PREFIX):]
    key = next((k for k, t in _PASS_TITLES.items() if t == title), None)
    if key is not None:
        _PASS_CAPTURE_CACHE.pop(key, None)


def capture_fingerprint(rstate, scene, clamp_edge: int) -> tuple:
    """当前捕获参数指纹: 捕获勾选/通道参数/钳制后的捕获尺寸/相机名与世界矩阵

    相机动了或参数变了指纹即变; 捕获分辨率随场景输出分辨率变化, 也一并纳入.
    """
    cap_w, cap_h = resolve_capture_size(scene, clamp_edge)
    cam = scene.camera
    return (
        tuple(getattr(rstate, attr) for attr, _ in _PASS_TOGGLES),
        rstate.ao_distance, tuple(rstate.depth_range), rstate.depth_curve,
        rstate.normal_convention, rstate.edge_width_scale, rstate.use_material_borders,
        (cap_w, cap_h),
        cam.name if cam is not None else "",
        tuple(cam.matrix_world) if cam is not None else (),
    )


def _pass_ref_image(name: str):
    """按通道键取固定名预览图数据块(无则 None)"""
    return bpy.data.images.get(f"AI Ref: {_pass_title(name)}")


def pass_available(name: str) -> bool:
    """通道发送可用性: 发送缓存有字节, 或固定名预览图数据块仍在(可从它重编码)

    缓存(内存)与预览图数据块(随 blend)生命周期不同步——重启后缓存空而预览图还在,
    以"任一存在"为可用, 保证所见即所得(迷你列表里看得到的通道就能发送).
    """
    if name in _PASS_CAPTURE_CACHE:
        return True
    return _pass_ref_image(name) is not None


def _pass_send_bytes(name: str) -> tuple:
    """取通道的发送字节: 缓存命中用捕获原始字节(零重编码), 缺失时从预览图数据块重编码 PNG

    调用时机在主线程(invoke/编码均主线程); 返回 (字节, 错误信息).
    """
    data = _PASS_CAPTURE_CACHE.get(name)
    if data is not None:
        return data, None
    image = _pass_ref_image(name)
    if image is None:
        return None, api_error("The captured pass is missing, run pass generation first")
    return image_to_png_bytes(image)


def collect_send_passes(rstate, scene, limit_edge: int) -> tuple:
    """按发送开关收集可发送的通道(两步工作流的发送集), 返回 (通道键列表, 不可用键列表, 是否过期)

    通道顺序即参考优先序(PASS_ORDER), 与提示词 Image N 描述顺序一致;
    不可用 = 勾选发送但缓存与预览图数据块都缺失(生成与预览都阻断并引导"生成通道");
    过期 = 当前参数指纹与捕获时不一致(仅提示不阻断).
    limit_edge 为当前服务商的参考图最长边上限(钳制口径, 与捕获时一致).
    """
    send_names, missing = [], []
    for attr, key in _SEND_TOGGLES:
        if not getattr(rstate, attr):
            continue
        if pass_available(key):
            send_names.append(key)
        else:
            missing.append(key)
    stale = (_CAPTURE_FINGERPRINT is not None
             and _CAPTURE_FINGERPRINT != capture_fingerprint(
                 rstate, scene, _clamp_edge(rstate, limit_edge)))
    return send_names, missing, stale


def _style_image_bytes(image, limit_edge: int) -> tuple:
    """风格图编码为 PNG 字节(主线程): 最长边超服务商参考图上限时复制缩放后编码再删副本

    缩放只作用于副本, 用户原图数据块零改动(实现已下沉 utils.image_to_scaled_png_bytes).
    """
    return image_to_scaled_png_bytes(image, limit_edge)


def collect_style_images(rstate) -> list:
    """收集生效的风格参考图**引用条目**(生成/预览/面板摘要共用, 单一口径)

    use_send_style 关闭时不发送(也不占参考图名额); 引用悬空或像素未加载的条目剔除.
    返回条目而非数据块: 条目上带用户输入的描述(style_descriptions 组装进提示词).
    收集口径与纹理参考图共用(collect_ref_entries).
    """
    return collect_ref_entries(rstate, "use_send_style", "style_images")


def count_unavailable_style_refs(rstate) -> int:
    """风格参考图引用中不可用的条数(引用悬空或像素未加载, 与 collect_style_images 同口径)

    不可用条目不参与发送; 面板摘要里点名提醒, 让作者知道列表里有"死引用".
    """
    return count_unavailable_refs(rstate, "style_images")


def resolve_render_request(rstate, scene, prompt: str, provider: str,
                           limit_count: int, limit_edge: int,
                           require_captured: bool = True) -> tuple:
    """效果图发送内容组装(GenerateRender 与 PreviewRenderPrompt 共用, 保证预览即发送)

    返回 (错误, 提示列表, 通道键列表, 风格图引用条目列表, 完整提示词):
    错误为 (级别, 消息) 或 None——非 None 时调用方 report 后取消(勾选发送的通道不可用/
    一张已捕获通道都没有/预算名额被风格图占满)——**生成与预览两档对通道存在性的判定
    完全一致**(勾选发送的通道缓存与预览图数据块都缺失即阻断); 提示为不阻断的
    (级别, 消息) 列表(参数过期/超限截断/提示词超预算); 通道顺序即参考优先序,
    风格图永远发送并占保底名额(通道截断到 上限-风格张数, 但至少给通道留一个名额);
    require_captured 只区分"一张已捕获通道都没有"时的行为: 生成档取消并引导,
    预览档继续组装纯提示词.
    """
    send_names, missing, stale = collect_send_passes(rstate, scene, limit_edge)
    style_refs = collect_style_images(rstate)
    notices = []
    if stale:
        notices.append(('WARNING',
                        "Pass parameters changed since the capture, the previews may be outdated"))
    if missing:
        # 勾选发送的通道缓存与预览图数据块都缺失: 生成与预览一致阻断(作者定论)
        return (("WARNING", report("No captured pass for: {}, run pass generation first").format(
            ", ".join(_pass_title(name) for name in missing))),
                notices, [], [], "")
    if require_captured and not send_names:
        # 一张已捕获的发送通道都没有(未勾选任何发送开关)
        return (("WARNING", "Enable at least one captured pass to send, "
                            "run pass generation first"),
                notices, [], [], "")
    if 0 < limit_count < len(send_names) + len(style_refs):
        room = limit_count - len(style_refs)
        if room < 1:
            # 风格图把参考图名额占满, 一张通道图都发不下
            message = report("Provider allows {} reference images, the {} style images "
                             "fill the budget, no room for pass images").format(
                limit_count, len(style_refs))
            if require_captured:
                return ("ERROR", message), notices, [], [], ""
            notices.append(('ERROR', message))
            send_names = []
        else:
            dropped = ", ".join(_pass_title(name) for name in send_names[room:])
            send_names = send_names[:room]
            notices.append(('INFO', report("Provider allows {} reference images, dropped: {}").format(
                limit_count, dropped)))
    style_descriptions = [ref.description for ref in style_refs]
    # 法向约定跟随面板(完整档拼进 normal 条目; 精简档省略)
    full_prompt, over_budget = resolve_render_prompt(prompt, send_names,
                                                     style_descriptions, provider,
                                                     normal_convention=rstate.normal_convention)
    if over_budget:
        budget, _hard = prompt_token_budget(provider)
        notices.append(('WARNING', report("Prompt is about {} tokens, above the {} budget, "
                                          "it may be truncated").format(
            estimate_prompt_tokens(full_prompt), budget)))
    return None, notices, send_names, style_refs, full_prompt


def render_request_worker(op, request_args: ImageRequestArgs, model, prompt, ref_images, specs, negative_prompt):
    """效果图请求后台线程入口(op 模拟 self): 按规格表逐张串行请求并把结果列表写入 op._result

    request_args 是主线程快照的偏好值命名元组(RNA 属性不支持跨线程读取);
    specs 为逐张 (尺寸串, 种子) 规格表(各张同尺寸, 固定种递增), 参考图各张共用,
    中途失败即停止, op._result 固定为 (成功图片字节列表, 首个错误或 None);
    批量时另写 op._batch_total 供 _on_response 组装"已成功 i/n 张"文案.
    """
    try:
        results = []
        err = None
        total = len(specs)
        base_text = op.status_text
        for idx, (size, seed) in enumerate(specs, 1):
            # 批量进度文案(worker 线程写普通属性, modal 主线程每拍回写面板状态)
            op._progress_text = f"{base_text} [{idx}/{total}]" if total > 1 else None
            image_bytes, err = request_image(
                request_args.base_url, request_args.api_key, model, prompt,
                request_args.timeout, provider=request_args.provider,
                size=size, ref_images=ref_images, seed=seed, negative_prompt=negative_prompt)
            if err is not None:
                break
            results.append(image_bytes)
        op._batch_total = total if total > 1 and err is not None else 0
        op._result = (results, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


class CaptureViewRefs(Operator):
    """
    生成通道操作器

    功能: 本地用 EEVEE 在临时场景中分三帧渲染场景相机视图, 按通道类型提取所选参考通道
    (合并结果/深度/法向/漫射颜色/AO 共享第一帧, 语义分割与线稿各占一帧)并以固定名图像
    数据块在图像编辑器预览; 不调用 AI 服务, 不产生 API 费用.
    按钮文案与所在小节同为"生成通道"(原按钮名为"捕获预览").

    面板点击走 invoke 模态路径: PassCaptureSession 逐帧渲染, 帧与帧之间让出主线程,
    面板等待框只显示已等待秒数(与 AI 请求等待同款), Esc 与终止按钮在帧间生效退出
    (单帧渲染内部不可中断); execute 直调(脚本/测试)为同步一口气路径, 行为与旧版一致.
    两条路径捕获成功后都把字节写入发送缓存(_PASS_CAPTURE_CACHE)供 Generate Render 消费.
    """

    bl_idname = "ch_ai.capture_view_refs"
    bl_label = "Capture Passes"
    bl_description = "Render the camera view passes locally and preview them in the image editor (no API cost)"
    bl_options = {'REGISTER'}

    _STATUS_TEXT = "Capturing passes... (Esc to cancel)"

    # ---- 共享收尾: 捕获字节写入发送缓存 + 固定名预览图 + 列表聚焦 ----

    def _commit_capture(self, context: Context, passes: dict, notices: list):
        rstate = context.window_manager.ch_ai_render_state
        prefs = get_prefs()
        _provider, _base_url, _api_key, limits = _resolve_service(
            context.window_manager.ch_ai_render_service, prefs)
        global _CAPTURE_FINGERPRINT
        _PASS_CAPTURE_CACHE.clear()
        _PASS_CAPTURE_CACHE.update(passes)
        _CAPTURE_FINGERPRINT = capture_fingerprint(
            rstate, context.scene, _clamp_edge(rstate, limits[1]))
        last_image = None
        for name, data in passes.items():
            image, img_err = _write_preview_image(self, name, data)
            if img_err is not None:
                self.report({'WARNING'}, img_err)
            elif image is not None:
                last_image = image
        if last_image is not None:
            activate_pass_image(context, last_image.name)
        for notice in notices:
            self.report({'INFO'}, describe_error(notice))
        self.report({'INFO'}, report("Captured {} reference passes").format(len(passes)))

    def execute(self, context: Context):
        if context.scene.camera is None:
            self.report({'WARNING'}, "The scene has no active camera")
            return {'CANCELLED'}
        rstate = context.window_manager.ch_ai_render_state
        prefs = get_prefs()
        _provider, _base_url, _api_key, limits = _resolve_service(
            context.window_manager.ch_ai_render_service, prefs)
        # 增量捕获: 渲染键未变(仅深度范围/曲线/法向约定等解码参数变化)时免渲染,
        # 从缓存的原始落盘字节按当前解码参数重解码(秒级); 未命中回落全量渲染
        wanted = {key: getattr(rstate, attr) for attr, key in _PASS_TOGGLES}
        cached = recapture_from_raw(
            context.scene, wanted, depth_near=rstate.depth_range[0],
            depth_far=rstate.depth_range[1], depth_curve=rstate.depth_curve,
            normal_convention=rstate.normal_convention, ao_distance=rstate.ao_distance,
            edge_width_scale=rstate.edge_width_scale,
            material_borders=rstate.use_material_borders,
            clamp_long_edge=_clamp_edge(rstate, limits[1]))
        if cached is not None:
            passes, _size, notices, err = cached
        else:
            # 同步直调路径(脚本/测试): 一口气跑完整个会话, 不走模态进度
            passes, _size, notices, err = capture_camera_passes(
                context, rstate.use_combined, rstate.use_depth, rstate.use_normal,
                rstate.use_segmentation, rstate.use_edge, rstate.use_diffuse, rstate.use_ao,
                ao_distance=rstate.ao_distance, depth_near=rstate.depth_range[0],
                depth_far=rstate.depth_range[1], depth_curve=rstate.depth_curve,
                normal_convention=rstate.normal_convention,
                edge_width_scale=rstate.edge_width_scale,
                material_borders=rstate.use_material_borders,
                clamp_long_edge=_clamp_edge(rstate, limits[1]))
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if not passes:
            self.report({'WARNING'}, "No passes captured, enable at least one pass")
            return {'CANCELLED'}
        self._commit_capture(context, passes, notices)
        return {'FINISHED'}

    # ---- 模态路径: 分帧渲染 + 时间进度(等待框与 AI 请求同款, 只显示秒数) ----

    def invoke(self, context: Context, _event: Event):
        if context.scene.camera is None:
            self.report({'WARNING'}, "The scene has no active camera")
            return {'CANCELLED'}
        rstate = context.window_manager.ch_ai_render_state
        prefs = get_prefs()
        _provider, _base_url, _api_key, limits = _resolve_service(
            context.window_manager.ch_ai_render_service, prefs)
        wanted = {key: getattr(rstate, attr) for attr, key in _PASS_TOGGLES}
        if not any(wanted.values()):
            self.report({'WARNING'}, "Enable at least one pass before capturing")
            return {'CANCELLED'}
        ai_state = context.window_manager.ch_ai_state
        if getattr(ai_state, "status_render"):
            # render scope 内互斥(捕获与效果图生成共用 render 等待标志): 捕获期间不再发起
            # 本面板生成, 生成期间不捕获; 跨面板请求可并行(文案与 AiRequestMixin 同句, 词条单一来源)
            self.report({'WARNING'}, "An AI request is already running in this panel, wait for it to finish first")
            return {'CANCELLED'}
        # 增量捕获: 渲染键未变(仅解码参数变化)时免渲染重解码, 不进模态直接出图
        cached = recapture_from_raw(
            context.scene, wanted, depth_near=rstate.depth_range[0],
            depth_far=rstate.depth_range[1], depth_curve=rstate.depth_curve,
            normal_convention=rstate.normal_convention, ao_distance=rstate.ao_distance,
            edge_width_scale=rstate.edge_width_scale,
            material_borders=rstate.use_material_borders,
            clamp_long_edge=_clamp_edge(rstate, limits[1]))
        if cached is not None:
            passes, _size, notices, err = cached
            if err is None and passes:
                self._commit_capture(context, passes, notices)
                return {'FINISHED'}
        session = PassCaptureSession(
            context.scene, wanted,
            ao_distance=rstate.ao_distance, depth_near=rstate.depth_range[0],
            depth_far=rstate.depth_range[1], depth_curve=rstate.depth_curve,
            normal_convention=rstate.normal_convention,
            edge_width_scale=rstate.edge_width_scale,
            material_borders=rstate.use_material_borders,
            clamp_long_edge=_clamp_edge(rstate, limits[1]))
        open_err = session.open()
        if open_err is not None:
            session.close()
            self.report({'ERROR'}, describe_error(open_err))
            return {'CANCELLED'}
        self._session = session
        self._passes_state = rstate
        self._wanted = wanted
        self._render_key = capture_render_key(
            context.scene, wanted, rstate.ao_distance, rstate.edge_width_scale,
            rstate.use_material_borders, _clamp_edge(rstate, limits[1]))
        self._t0 = time.time()
        self._timer = None
        ai_state.status_render = self._STATUS_TEXT
        ai_state.wait_render = 0
        ai_state.cancel_render = False
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:  # noqa: BLE001 - 挂载失败时回收等待标志(见 handlers.reset_wait_state)
            session.close()
            self._session = None
            reset_wait_state(ai_state)
            self.report({'ERROR'}, "Failed to start the capture modal")
            return {'CANCELLED'}
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._finish(context, cancelled=True)
            return {'CANCELLED'}
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}
        ai_state = context.window_manager.ch_ai_state
        ai_state.wait_render = int(time.time() - self._t0)
        if ai_state.cancel_render:
            # 面板终止按钮(render scope 标志): 帧间生效, 放弃整轮捕获
            ai_state.cancel_render = False
            self._finish(context, cancelled=True)
            return {'CANCELLED'}
        try:
            _frame_notices, err, done = self._session.render_next_frame()
        except Exception as e:  # noqa: BLE001 - 会话外的意外异常同样走错误收尾
            self._finish(context, error=api_error("Failed to capture the camera passes", e))
            return {'CANCELLED'}
        if err is not None:
            self._finish(context, error=err)
            return {'CANCELLED'}
        if done:
            self._finish(context)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def _finish(self, context: Context, cancelled: bool = False, error=None):
        """帧间收尾: 回收会话与计时器, 清等待标志; 成功时提交捕获结果"""
        session = getattr(self, "_session", None)
        if session is not None:
            session.close()
            self._session = None
        if getattr(self, "_timer", None) is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        ai_state = context.window_manager.ch_ai_state
        reset_wait_state(ai_state)
        if cancelled:
            self.report({'INFO'}, "Pass capture cancelled")
        elif error is not None:
            self.report({'ERROR'}, describe_error(error))
        else:
            passes, _size = session.collect()
            if not passes:
                self.report({'WARNING'}, "No passes captured, enable at least one pass")
                return
            # 渲染成功后写增量缓存(原始落盘字节 + 渲染键), 供下次免渲染重解码
            store_raw_cache(self._render_key, self._wanted, session.passes_raw,
                             session.size, session.notices)
            self._commit_capture(context, passes, session.notices)


class PickDepthRange(Operator):
    """
    深度拾取操作器

    功能: 按当前场景相机的视锥投网格射线采样可见表面的视空间深度(纯几何投射, 不渲染),
    取命中深度的 2%/98% 分位数回填深度范围(近端白/远端黑的区间锚点), 之后仍可手工修改.

    用途: 深度范围是米制场景单位, 默认 (1, 20) 对多数场景并不贴合——反深度曲线的锚点又在
    近端, 区间偏小时整幅画会被压到灰阶底端而看似"纯黑"; 一键拾取把区间贴到实际可见深度上.
    要求: 场景有活动透视相机, 且相机视锥内有几何.
    """

    bl_idname = "ch_ai.pick_depth_range"
    bl_label = "Pick Depth Range"
    bl_description = "Sample the visible scene depth through the camera view and fill the depth range"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context: Context):
        return context.scene is not None and context.scene.camera is not None

    def execute(self, context: Context):
        near, far, hits, err = sample_visible_depth(context.scene)
        if err is not None:
            self.report({'WARNING'}, describe_error(err))
            return {'CANCELLED'}
        context.window_manager.ch_ai_render_state.depth_range = (near, far)
        self.report({'INFO'}, report("Depth range picked from {} samples: {} to {}").format(
            hits, f"{near:.2f}", f"{far:.2f}"))
        return {'FINISHED'}


class GenerateRender(Operator, AiRequestMixin):
    """
    生成效果图操作器

    功能: 把"生成通道"已捕获的参考通道图(按发送开关勾选, 至少一张)连提示词
    发给 AI 图像服务参考图生图, 输出尺寸取面板分辨率设置(经服务商约束修正),
    结果图在图像编辑器展示并按偏好目录存盘. 本算子不渲染也不要求活动相机——
    通道捕获一律由"生成通道"按钮完成(严格两步), 缓存缺失时提示先运行通道捕获.

    要求: 发送开关勾选且已捕获的通道至少一张(Combined 为出厂默认勾选, 非强制);
    图像服务偏好已配置.
    """

    bl_idname = "ch_ai.generate_render"
    bl_label = "Generate Render"
    bl_description = "Send the captured passes with your prompt to the AI image service, run pass generation first to capture them"
    bl_options = {'REGISTER'}

    status_text = "Generating render... (Esc to cancel)"
    status_scope = 'render'

    def invoke(self, context: Context, event: Event):
        rstate = context.window_manager.ch_ai_render_state
        prompt = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, rstate.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the look you want in the prompt field first")
            return {'CANCELLED'}
        if not check_image_service(self, context.window_manager.ch_ai_render_service):
            return {'CANCELLED'}
        # 命名短名随请求一并快照: 等待期间描述被改动时产物名仍与请求内容一致
        self._stem = prompt_stem(prompt)
        self._prompt = prompt

        prefs = get_prefs()
        sstate = context.window_manager.ch_ai_render_service
        provider, base_url, api_key, limits = _resolve_service(sstate, prefs)
        edit_model = resolve_edit_model(sstate, prefs)

        # 两步工作流: 只发送"生成通道"已捕获的通道图(绝不内部渲染, 不要求活动相机——
        # 相机只有捕获需要); 组装与预览算子共用同一函数(resolve_render_request),
        # 保证"预览即发送"; 未捕获直接取消引导, 参数过期/超限截断/提示词超预算只提示不阻断
        err, notices, send_names, style_refs, full_prompt = resolve_render_request(
            rstate, context.scene, prompt, provider, limits[0], limits[1])
        if err is not None:
            level, message = err
            self.report({'WARNING'} if level == 'WARNING' else {'ERROR'}, message)
            return {'CANCELLED'}
        # level 是单个字符串, report 第一参数要求集合
        for level, message in notices:
            self.report({level}, message)

        # 参考图数组顺序 = send_names 顺序(与提示词 Image N 一一对应), 风格图排在尾部;
        # 通道字节缓存优先(捕获原始字节零重编码), 缺失时从预览图数据块重编码(主线程)
        ref_images = []
        for name in send_names:
            data, enc_err = _pass_send_bytes(name)
            if enc_err is not None:
                self.report({'ERROR'}, describe_error(enc_err))
                return {'CANCELLED'}
            ref_images.append(data)
        # 风格图编码为 PNG 字节(主线程, RNA 不支持跨线程读取), 排在通道图之后
        for ref in style_refs:
            data, enc_err = _style_image_bytes(ref.image, limits[1])
            if enc_err is not None:
                self.report({'ERROR'}, describe_error(enc_err))
                return {'CANCELLED'}
            ref_images.append(data)

        # 输出尺寸: 面板宽高(缩放档按相机分辨率长边回填, 自定义档自由输入)先经服务商/模型
        # 约束修正, 再按张数展开逐张规格表(种子 0 已本地抽取回填, 逐张从基准递增)
        out_w, out_h = resolve_output_size(provider, edit_model,
                                           rstate.custom_width, rstate.custom_height)
        if (out_w, out_h) != (rstate.custom_width, rstate.custom_height):
            self.report({'INFO'}, report("Resolution adjusted to {} x {} for the provider limits").format(out_w, out_h))
        specs = _batch_request_specs(provider, edit_model, out_w, out_h,
                                     rstate.count, effective_seed(rstate), rstate.batch_variants)
        # 负向提示仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        from ..utils.provider_registry import get_image_provider
        neg_prompt = rstate.negative_prompt.strip() if get_image_provider(provider).supports_negative_prompt else ""

        # 超时 0 = 不限制(请求层映射为 None 阻塞至响应), 见偏好 image_timeout
        args = (ImageRequestArgs(base_url, api_key, prefs.image_timeout or None, provider),
                edit_model, full_prompt, ref_images, specs, neg_prompt)
        if not self._start_request(context, render_request_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, results, err):
        """逐张落地产物: results 为成功图片字节列表, err 为首个请求错误(部分成功时仅告警)"""
        if not isinstance(results, list):
            results = []
        if err is not None and not results:
            record_request_error(context, 'render', self.bl_label, err)
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if err is not None:
            total = getattr(self, '_batch_total', 0)
            if total > 1:
                # 批量部分成功: 报告成功张数与失败原因(错误摘要仍记录首个错误)
                self.report({'WARNING'}, report("Succeeded {} of {} images, failed: {}").format(
                    len(results), total, describe_error(err)))
            else:
                self.report({'WARNING'}, describe_error(err))
        created = 0
        focused = 0
        for image_bytes in results:
            # 版本链命名: 同 stem 首版无序号, 之后按创建顺序 " 2"/" 3"(逐张创建时计数即时生效);
            # 提示词无英文词的回落名(纯前缀)走 unique_ai_name, 自动命名后即脱离版本链计数
            name = (next_render_version_name(self._stem) if self._stem
                    else unique_ai_name(ai_render_name(self._stem)))
            image, img_err = load_image_from_bytes(image_bytes, name)
            if img_err is not None:
                self.report({'ERROR'}, describe_error(img_err))
                continue
            created += 1
            prefs = get_prefs()
            if prefs.image_save_dir:
                path, save_err = save_image_file(image, prefs.image_save_dir)
                if save_err is not None:
                    self.report({'WARNING'}, save_err)
                else:
                    self.report({'INFO'}, report("Image saved to {}").format(path))
            # 产物置顶到图像列表第一位并聚焦图像编辑器(最后一张留在列表首位)
            focused = activate_image(context, image.name, top=True)
            # 提示词无英文词(名字落到兜底档)时, 异步用全局文本服务取一个英文名
            maybe_auto_name_image(image.name, self._prompt, AI_RENDER_PREFIX)
        if created == 0:
            self.report({'ERROR'}, "AI request finished without a result")
            return {'CANCELLED'}
        if focused == 0:
            self.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
        return {'FINISHED'}


# 参考图引用的目标状态('TEXTURE' 纹理面板参考图 / 'RENDER' 效果图风格参考图):
# 同一组维护操作器按 target 分派(与 SaveImage 的 target 模式一致)
_REF_TARGETS = {
    'TEXTURE': ("ch_ai_texture_state", "ref_images", "ref_images_active_index"),
    'RENDER': ("ch_ai_render_state", "style_images", "style_images_active_index"),
}

# 引用集合的 target 枚举条目(三个维护操作器共用)
_REF_TARGET_ITEMS = [
    ('TEXTURE', "Texture", "The texture and image generator panel"),
    ('RENDER', "Render", "The render panel"),
]


def _ref_collection(context: Context, target: str) -> tuple:
    """按 target 取参考图引用的 (状态组, 集合属性名, 索引属性名)"""
    wm_attr, coll_attr, index_attr = _REF_TARGETS[target]
    state = getattr(context.window_manager, wm_attr)
    return state, coll_attr, index_attr


class LoadStyleImage(Operator):
    """
    加载参考图操作器

    功能: 从磁盘选择图片加载为图像数据块(同路径复用已有块)并追加到参考图列表末尾;
    纹理面板的参考图随 Generate Texture 发送(模型同纯文生图), 效果图面板的风格参考图
    随 Generate Render 排在通道图之后发送, 每张占一个参考图预算名额
    (最长边超服务商上限时自动缩放副本上传, 原图数据块零改动).
    """

    bl_idname = "ch_ai.load_style_image"
    bl_label = "Load Reference Image"
    bl_description = ("Load an image from disk as a reference for AI generation "
                      "(texture panel: sent with the prompt; render panel: sent after the captured passes)")
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')  # type: ignore
    target: EnumProperty(name="Target", description="Which panel's reference list to append",
                         items=_REF_TARGET_ITEMS, default='RENDER')  # type: ignore

    def invoke(self, context: Context, _event: Event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        path = self.filepath.strip()
        if not path:
            return {'CANCELLED'}
        try:
            image = bpy.data.images.load(path, check_existing=True)
        except Exception as e:  # noqa: BLE001 - 路径非法/解码失败统一转成可读报告
            self.report({'ERROR'}, describe_error(api_error("Failed to load the image", e)))
            return {'CANCELLED'}
        state, coll_attr, index_attr = _ref_collection(context, self.target)
        ref = getattr(state, coll_attr).add()
        ref.image = image
        # 直接赋值(不走护栏): 沿用"加载即高亮并按偏好聚焦图像编辑器"的原联动
        setattr(state, index_attr, len(getattr(state, coll_attr)) - 1)
        dump_image_refs()
        return {'FINISHED'}


class ClearPassBackups(Operator):
    """
    清除备份通道操作器

    功能: 一键删除全部通道预览图的 "_bak" 备份副本(重新捕获时上一轮预览图改名保留的
    历史版本, 见 _write_preview_image); 当前预览图与发送缓存不受影响.
    """

    bl_idname = "ch_ai.clear_pass_backups"
    bl_label = "Clear Pass Backups"
    bl_description = "Delete all '_bak' backup copies of the pass previews"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(img.name.startswith(AI_REF_PREFIX) and "_bak" in img.name
                   for img in bpy.data.images)

    def execute(self, context: Context):
        backups = [img for img in bpy.data.images
                   if img.name.startswith(AI_REF_PREFIX) and "_bak" in img.name]
        for img in backups:
            bpy.data.images.remove(img)
        sync_images_now()
        self.report({'INFO'}, report("Deleted {} pass backups").format(len(backups)))
        return {'FINISHED'}


class ClearStyleDescription(Operator):
    """
    清除参考图描述操作器

    功能: 清空当前高亮参考图的描述(该图的提示词职责声明回落通用措辞);
    描述行行尾的清除按钮调用, 与其它描述行的清除按钮同款.
    """

    bl_idname = "ch_ai.clear_style_description"
    bl_label = "Clear Reference Description"
    bl_description = "Clear the description of the highlighted reference image"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(name="Target", description="Which panel's reference list to clear in",
                         items=_REF_TARGET_ITEMS, default='RENDER')  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        for _target, (wm_attr, coll_attr, index_attr) in _REF_TARGETS.items():
            state = getattr(context.window_manager, wm_attr)
            if 0 <= getattr(state, index_attr) < len(getattr(state, coll_attr)):
                return True
        return False

    def execute(self, context: Context):
        state, coll_attr, index_attr = _ref_collection(context, self.target)
        coll = getattr(state, coll_attr)
        idx = getattr(state, index_attr)
        if not 0 <= idx < len(coll):
            self.report({'WARNING'}, "No reference image selected")
            return {'CANCELLED'}
        coll[idx].description = ""
        dump_image_refs()
        return {'FINISHED'}


class RemoveStyleImage(Operator):
    """
    移除参考图操作器

    功能: 把参考图列表当前高亮的引用移除(只移除列表条目, 不删除图像数据块本身);
    被移除的图不再随生成请求发送.
    """

    bl_idname = "ch_ai.remove_style_image"
    bl_label = "Remove Reference Image"
    bl_description = "Remove the highlighted reference image from the list (the image datablock is kept)"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(name="Target", description="Which panel's reference list to remove from",
                         items=_REF_TARGET_ITEMS, default='RENDER')  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        for _target, (wm_attr, coll_attr, index_attr) in _REF_TARGETS.items():
            state = getattr(context.window_manager, wm_attr)
            if 0 <= getattr(state, index_attr) < len(getattr(state, coll_attr)):
                return True
        return False

    def execute(self, context: Context):
        state, coll_attr, index_attr = _ref_collection(context, self.target)
        coll = getattr(state, coll_attr)
        idx = getattr(state, index_attr)
        if not 0 <= idx < len(coll):
            self.report({'WARNING'}, "No reference image selected")
            return {'CANCELLED'}
        coll.remove(idx)
        # 护栏内压回高亮(移除是结构变动, 不需要"点击行聚焦编辑器"联动)
        set_guarded(state, index_attr,
                    min(idx, len(coll) - 1) if len(coll) else 0)
        dump_image_refs()
        return {'FINISHED'}


class PreviewRenderPrompt(Operator):
    """
    最终提示词预览操作器

    功能: 按 Generate Render 的同一组装口径(共用 resolve_render_request)生成实际发送的
    完整提示词, 写入 AI_Render_Final_Prompt.txt 并把文本编辑器聚焦到该块;
    头部记录 token 估算/预算状态与参考图清单, 参数过期等提示一并注明;
    正文即最终提示词(超硬预算时为自动降档后的精简档, 与真实发送逐字一致).
    勾选发送的通道不可用(缓存与预览图数据块都缺失)时与生成档一致阻断并提醒.
    """

    bl_idname = "ch_ai.preview_render_prompt"
    bl_label = "View Full Prompt"
    bl_description = ("Show the exact prompt that Generate Render will send, assembled with the "
                      "reference roles and guidance, in the text editor")
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        rstate = context.window_manager.ch_ai_render_state
        prompt = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, rstate.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the look you want in the prompt field first")
            return {'CANCELLED'}
        prefs = get_prefs()
        sstate = context.window_manager.ch_ai_render_service
        provider, _base_url, _api_key, limits = _resolve_service(sstate, prefs)
        err, notices, send_names, style_refs, full_prompt = resolve_render_request(
            rstate, context.scene, prompt, provider, limits[0], limits[1], require_captured=False)
        if err is not None:
            level, message = err
            self.report({'WARNING'} if level == 'WARNING' else {'ERROR'}, message)
            return {'CANCELLED'}
        # 头部摘要(token 估算与预算状态 + 参考图清单 + 不阻断提示), 正文即发送原文
        budget, hard = prompt_token_budget(provider)
        tokens = estimate_prompt_tokens(full_prompt)
        if budget > 0:
            over = tokens > budget
            lines = [iface("Prompt: about {} tokens / {} budget ({})").format(
                tokens, budget,
                iface("over budget, hard truncation") if (over and hard) else
                iface("over the soft suggestion") if over else iface("within budget"))]
        else:
            lines = [iface("Prompt: about {} tokens (no budget known for this provider)").format(tokens)]
        refs = ", ".join(_pass_title(name) for name in send_names) or "-"
        if style_refs:
            refs += ", " + ", ".join(ref.image.name for ref in style_refs)
        lines.append(iface("References: {}").format(refs))
        lines.extend(message for _level, message in notices)
        text, _err = write_text_block(
            AI_RENDER_FINAL_PROMPT_TEXT_NAME, "\n".join(lines) + "\n\n" + full_prompt)
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        # level 是单个字符串, report 第一参数要求集合
        for level, message in notices:
            self.report({level}, message)
        return {'FINISHED'}


# 通道组合预设覆盖的开关属性名(捕获 + 发送两组, 顺序同 PASS_ORDER 派生)
_PRESET_TOGGLES = tuple(attr for attr, _key in _PASS_TOGGLES) + tuple(attr for attr, _key in _SEND_TOGGLES)


def _sanitize_preset_name(name: str) -> str:
    """预设名清洗为 ASCII: 动态枚举下拉条目经 Blender C 层绘制, 非 ASCII 实测渲染成乱码

    非 ASCII 可打印字符的连续段折叠为单下划线并去掉首尾的 "_"/空格;
    清洗后为空(如纯中文名)返回空串, 由调用方回落序号自动命名.
    """
    return re.sub(r"[^\x20-\x7e]+", "_", name).strip("_ ")


class ApplyPassPreset(Operator):
    """
    应用通道组合预设操作器

    功能: 把偏好下拉中选中的通道组合预设写回面板的捕获/发送两组通道开关;
    预设存于偏好(跨会话), 由 SavePassPreset 保存, DeletePassPreset 删除.
    """

    bl_idname = "ch_ai.apply_pass_preset"
    bl_label = "Apply Pass Preset"
    bl_description = "Apply the selected pass preset to the capture and send toggles"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return len(get_prefs().pass_presets) > 0

    def execute(self, context: Context):
        prefs = get_prefs()
        preset = next((p for p in prefs.pass_presets if p.name == prefs.pass_preset_choice), None)
        if preset is None:
            self.report({'WARNING'}, "No pass preset selected")
            return {'CANCELLED'}
        rstate = context.window_manager.ch_ai_render_state
        for attr in _PRESET_TOGGLES:
            setattr(rstate, attr, getattr(preset, attr))
        return {'FINISHED'}


class SavePassPreset(Operator):
    """
    保存通道组合预设操作器

    功能: 把面板当前的捕获/发送两组通道开关快照存为偏好预设;
    名称留空时按序号自动命名("Preset N"), 重名即覆盖(更新已有预设);
    名称清洗为 ASCII(下拉是动态枚举, 非 ASCII 条目 C 层乱码), 清洗后为空按序号命名;
    保存后下拉自动选中该预设.
    """

    bl_idname = "ch_ai.save_pass_preset"
    bl_label = "Save Pass Preset"
    bl_description = "Save the current capture and send toggles as a named pass preset in the preferences"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(
        name="Name",
        description="Preset name, empty names it automatically, non-ASCII characters fold to underscores",
    )  # type: ignore

    def execute(self, context: Context):
        prefs = get_prefs()
        rstate = context.window_manager.ch_ai_render_state
        name = _sanitize_preset_name(self.name) or f"Preset {len(prefs.pass_presets) + 1}"
        preset = next((p for p in prefs.pass_presets if p.name == name), None)
        if preset is None:
            preset = prefs.pass_presets.add()
        preset.name = name
        for attr in _PRESET_TOGGLES:
            setattr(preset, attr, getattr(rstate, attr))
        prefs.pass_preset_choice = name
        return {'FINISHED'}


class DeletePassPreset(Operator):
    """
    删除通道组合预设操作器

    功能: 从偏好中删除下拉当前选中的通道组合预设(不可恢复); 删除后下拉回落.
    """

    bl_idname = "ch_ai.delete_pass_preset"
    bl_label = "Delete Pass Preset"
    bl_description = "Delete the selected pass preset from the preferences"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return len(get_prefs().pass_presets) > 0

    def execute(self, context: Context):
        prefs = get_prefs()
        idx = next((i for i, p in enumerate(prefs.pass_presets)
                    if p.name == prefs.pass_preset_choice), None)
        if idx is None:
            self.report({'WARNING'}, "No pass preset selected")
            return {'CANCELLED'}
        prefs.pass_presets.remove(idx)
        # 下拉选中值回落: 原条目已随删除消失(动态枚举失效值读回空串), 显式写回首项或占位档
        prefs.pass_preset_choice = prefs.pass_presets[0].name if len(prefs.pass_presets) else 'NONE'
        return {'FINISHED'}


def _resolve_modify_prompt(text_name: str, inline_prompt: str) -> str:
    """修改指令的提示词解析(与生成相反的单行优先): 单行输入框非空优先, 为空回落长文描述块

    修改是下达具体变更指令, 单行框快捷顺手; 长文块里通常是整体风格描述, 直接复用会把
    风格描述当修改指令发出(且覆盖用户的修改意图), 故只作回落.
    """
    inline = inline_prompt.strip()
    if inline:
        return inline
    block = bpy.data.texts.get(text_name)
    if block is None:
        return ""
    return block.as_string().strip()


class ModifyRender(Operator, AiRequestMixin):
    """
    修改效果图操作器

    功能: 以效果图列表当前高亮的生成产物(AI Render 前缀, 含旧 _bak 备份图)为参考图,
    连同描述发给 AI 图像服务参考图生图; 新图按源图主名归入版本链追加序号
    (被修改版本不改名, 历史版本全部保留在列表中); 输出尺寸取源图尺寸(经服务商约束
    修正, 面板分辨率只管生成). 参考通道预览图(AI Ref: 前缀)不可修改.

    要求: 列表中有高亮的效果图产物; 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.modify_render"
    bl_label = "Modify Render"
    bl_description = ("Edit the highlighted generated render with the AI edit model based on the prompt, "
                      "creating a new numbered version in the chain; always a single image")
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Modifying render... (Esc to cancel)"
    status_scope = 'render'

    @classmethod
    def poll(cls, context: Context):
        state = context.window_manager.ch_ai_render_state
        return 0 <= state.images_active_index < len(state.images)

    def invoke(self, context: Context, event: Event):
        rstate = context.window_manager.ch_ai_render_state
        # 提示词单行优先(与生成相反), 见 _resolve_modify_prompt
        prompt = _resolve_modify_prompt(AI_RENDER_PROMPT_TEXT_NAME, rstate.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the change in the prompt field first")
            return {'CANCELLED'}
        if not (0 <= rstate.images_active_index < len(rstate.images)):
            self.report({'WARNING'}, "No image selected")
            return {'CANCELLED'}
        source = bpy.data.images.get(rstate.images[rstate.images_active_index].name)
        if source is None:
            self.report({'WARNING'}, "Image no longer exists")
            return {'CANCELLED'}
        # 参考通道预览图是固定名的本地捕获(下次捕获先删后建), 修改它们没有意义, 直接拒绝
        if not source.name.startswith(AI_RENDER_PREFIX):
            self.report({'WARNING'}, "Only generated renders can be modified")
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_render_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}
        # 源图编码为 PNG 字节(主线程完成, RNA 属性不支持跨线程读取)
        source_bytes, err = image_to_png_bytes(source)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}

        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        edit_model = resolve_edit_model(sstate, prefs)
        # 负向提示仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        from ..utils.provider_registry import get_image_provider
        neg_prompt = rstate.negative_prompt.strip() if get_image_provider(provider).supports_negative_prompt else ""
        # 输出尺寸取源图尺寸(修改是"编辑这张图", 结果与源图同画幅; 面板分辨率只管生成),
        # 超服务商输出约束时按比率就近修正; 源图像素未加载时回落面板宽高
        src_w, src_h = source.size
        if src_w <= 0 or src_h <= 0:
            src_w, src_h = rstate.custom_width, rstate.custom_height
        out_w, out_h = resolve_output_size(provider, edit_model, src_w, src_h)
        size_str = format_size(provider, out_w, out_h)
        self._source_name = source.name
        self._prompt = prompt
        args = (ImageRequestArgs(base_url, api_key, prefs.image_timeout or None, provider),
                edit_model, prompt.strip(), [source_bytes], size_str,
                effective_seed(rstate), neg_prompt)
        if not self._start_request(context, modify_image_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, image_bytes, err):
        if err is not None:
            record_request_error(context, 'render', self.bl_label, err)
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        # 版本链命名: 被修改版本不改名, 新图按源图主名归链追加序号(下一号=现有最大+1);
        # 旧 _bak 备份图作源时按主名归链(见 render_version_stem 的归一),
        # 源图缺失(等待期间被删)回落提示词短名
        stem = render_version_stem(self._source_name)
        if stem:
            name = next_render_version_name(stem)
        else:
            name = unique_ai_name(ai_render_name(prompt_stem(self._prompt)))
        image, img_err = load_image_from_bytes(image_bytes, name)
        if img_err is not None:
            self.report({'ERROR'}, describe_error(img_err))
            return {'CANCELLED'}
        focused = activate_image(context, image.name, top=True)
        if focused == 0:
            self.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
        self.report({'INFO'}, report("Render '{}' created").format(image.name))
        maybe_auto_name_image(image.name, self._prompt, AI_RENDER_PREFIX)
        return {'FINISHED'}
