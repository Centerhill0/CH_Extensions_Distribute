"""
AI 纹理与图像生成操作模块

提示词送 AI 图像服务文生图, 产物无缝化处理(可选)后加载为贴图打包, 不进材质.
生成模式为"图像"时按提示词原样生成任意图像(不加贴图引导, 不做无缝化).
"修改图像"以列表高亮图像为参考图做参考图生图, 原图保留(改名加 _bak 后缀).
加载了参考图且"使用参考图"开启时, 生成走参考图生图(职责声明拼进提示词),
未加载或关闭时走文生图——两种路径共用同一请求管线与同一个模型(纹理组可见下拉).

操作流程:
1. 描述来源: 纹理长文描述块(AI_Texture_Prompt.txt)优先, 为空时取单行输入框
2. invoke: 校验提示词与图像服务配置, 按生成模式组装提示词(无缝平铺引导可选,
   参考图职责声明可选), 自定义分辨率按服务商/模型约束修正后,
   按张数逐张串行请求进入模态等待; 随机种 0 时本地抽取实际种子并回填面板(可复现)
3. modal: 计时器轮询线程结果并刷新面板等待进度, Esc 放弃等待(底层请求不中断, 结果丢弃)
4. 响应处理: 纹理贴图且 Seamless 开启时字节先做本地边缘羽化混合无缝化 -> 逐张加载为
   图像数据块(打包) -> 按偏好目录另存 -> 产物置顶到图像列表并聚焦图像编辑器

支持的选项:
- Texture Map / Image: 生成模式, 命名前缀随模式区分(AI Tex / AI Bmp)
- Seamless: 提示词追加强调版无缝平铺引导 + 产物本地边缘羽化混合保证可平铺(默认开)
- Reference Images: 加载的外部参考图(逐张描述), 开启"使用参考图"后随生成发送
- Negative Prompt: 负向提示词(仅百炼 Qwen-Image 支持, 其余服务商不下发)
- Size/Width/Height: 尺寸预设与自定义宽高(像素), 按服务商支持区间自动修正
- Count: 一次生成的张数(1-5), 逐张串行请求, 每张单独计费, 中途失败即停止
- Vary Batch: 张数>1 时每张换一个宽高比变体与递增随机种, 一次产出多种构图

另含两个图像面板共用与本面板私有的操作器:
- SaveImage / SaveAllImages: 目标列表图像另存为 PNG(两图像面板共用, 按 target 区分)
- PreviewTexturePrompt: 把生成将实际发送的完整提示词写入文本块(供核对, 面板按钮)
- LoadStyleImage / RemoveStyleImage / ClearStyleDescription: 参考图引用维护
  (定义在 ai_render, 按 target 同时服务纹理参考图与效果图风格参考图)
"""

import os
import random
from typing import NamedTuple

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import iface, report
from ..handlers import activate_image
from ..preference import get_prefs
from ..utils import (
    AI_IMAGE_PREFIX,
    AI_TEXTURE_FINAL_PROMPT_TEXT_NAME,
    AI_TEXTURE_PREFIX,
    AI_TEXTURE_PROMPT_TEXT_NAME,
    PROVIDER_DEFAULT_MODELS,
    ai_image_name,
    ai_texture_name,
    api_error,
    build_texture_prompt,
    describe_error,
    format_size,
    focus_text_editors,
    image_to_png_bytes,
    image_to_scaled_png_bytes,
    load_image_from_bytes,
    make_seamless,
    prompt_stem,
    request_image,
    resolve_image_endpoint,
    resolve_output_size,
    resolve_ref_limits,
    sanitize_image_file_name,
    save_image_file,
    unique_ai_name,
    write_text_block,
)
from .ai_generate import (
    AiRequestMixin,
    maybe_auto_name_image,
    record_request_error,
    resolve_prompt,
)


def resolve_image_service(state, prefs) -> tuple:
    """按共享服务设置解析生效图像服务, 返回 (服务商, base_url, api_key)

    state 为图像助手的共享服务设置(AiImageServiceState); Global 跟随偏好服务商,
    覆盖模式端点/密钥取对应服务商的偏好配置.
    """
    provider = prefs.image_provider if state.service_mode == 'GLOBAL' else state.service_mode
    base_url, api_key = resolve_image_endpoint(provider, prefs)
    return provider, base_url, api_key


def resolve_texture_model(state, prefs) -> str:
    """解析生效纹理模型: Global/面板"跟随偏好"档取偏好模型, 覆盖服务商取面板下拉(空 = 该服务商预设默认)"""
    if state.service_mode == 'GLOBAL':
        return prefs.image_model_t2i
    return state.panel_t2i_model or PROVIDER_DEFAULT_MODELS.get(state.service_mode) or prefs.image_model_t2i


def resolve_edit_model(state, prefs) -> str:
    """解析生效编辑模型: Global/面板"跟随偏好"档取偏好模型, 覆盖服务商取面板下拉(空 = 该服务商预设默认)

    仅供**效果图面板侧**使用(其面板下拉绑定本字段, UI 可见); 纹理面板侧一律用
    resolve_texture_model——纹理组的可见下拉绑定 panel_t2i_model, 本函数读的
    panel_edit_model 在纹理侧无 UI 入口(切服务商时被复位值填充, 读了会静默顶掉
    用户的可见选择).
    """
    if state.service_mode == 'GLOBAL':
        return prefs.image_model_edit
    return state.panel_edit_model or PROVIDER_DEFAULT_MODELS.get(state.service_mode) or prefs.image_model_edit


def check_image_service(op, state=None) -> bool:
    """校验生效图像服务已配置(地址与密钥), 未配置时经 op 上报并返回 False

    state 非空时按共享服务设置(含覆盖)检查, 为空时按偏好全局配置检查.
    """
    prefs = get_prefs()
    if state is None:
        provider, base_url, api_key = (prefs.image_provider,) + resolve_image_endpoint(prefs.image_provider, prefs)
    else:
        provider, base_url, api_key = resolve_image_service(state, prefs)
    if not base_url or not api_key:
        op.report({'WARNING'}, "Set the API key of the selected image service in addon preferences first")
        return False
    return True


class ImageRequestArgs(NamedTuple):
    """图像请求后台线程参数快照(主线程组装, RNA 属性不支持跨线程读取)

    按名访问, 消除调用方对元组位置的隐式依赖(service_test 曾用索引解包跳过中间字段).
    """
    base_url: str
    api_key: str
    timeout: int | None
    provider: str


def snapshot_image_prefs() -> ImageRequestArgs:
    """主线程按全局默认服务商快照图像服务配置为命名元组, 供后台线程使用"""
    prefs = get_prefs()
    base_url, api_key = resolve_image_endpoint(prefs.image_provider, prefs)
    return ImageRequestArgs(base_url, api_key, prefs.image_timeout or None, prefs.image_provider)


# 批量多变体的宽高比变体系数(第 0 张保持基础比率, 其后按序轮转换构图)
_VARIANT_FACTORS = (1.0, 1.5, 2.0 / 3.0, 4.0 / 3.0, 0.75)


def effective_seed(state) -> int:
    """取生效随机种: 0(每次随机)时本地抽取实际种子并**回填面板**——服务端随机时客户端
    拿不到种子, 满意结果无法复现; 回填后"再点一次 = 复现", 骰子按钮继续当重新随机
    (纹理与效果图两个面板共用, 生成/修改请求统一走此入口)."""
    if state.seed:
        return state.seed
    state.seed = random.randint(1, 2147483647)
    return state.seed


def collect_ref_entries(state, toggle_attr: str, collection_attr: str) -> list:
    """收集生效的参考图**引用条目**(生成/预览共用, 单一口径; 纹理参考图与效果图风格图共用)

    toggle_attr 对应的开关关闭时不发送; 引用悬空或像素未加载的条目剔除.
    返回条目而非数据块: 条目上带用户输入的描述(组装进提示词职责声明).
    """
    if not getattr(state, toggle_attr):
        return []
    return [ref for ref in getattr(state, collection_attr)
            if ref.image is not None and ref.image.size[0] > 0]


def count_unavailable_refs(state, collection_attr: str) -> int:
    """参考图引用中不可用的条数(引用悬空或像素未加载, 与 collect_ref_entries 同口径)"""
    return sum(1 for ref in getattr(state, collection_attr)
               if ref.image is None or ref.image.size[0] <= 0)


def collect_texture_refs(tex_state) -> list:
    """收集纹理面板生效的参考图条目("使用参考图"关闭时不发送, 口径同效果图风格图)"""
    return collect_ref_entries(tex_state, "use_ref_images", "ref_images")


def _batch_request_specs(provider, model, width, height, count, seed, variants) -> list:
    """按张数展开逐张请求的规格表 [(尺寸串, 种子), ...]

    variants 且张数>1 时每张换一个宽高比变体(总像素不变, 比率乘轮转系数后
    仍经服务商/模型约束修正); 种子从基准逐张递增(避免重图), 首张用基准本身——
    基准由 effective_seed 落地(0 已本地抽取回填), 全部请求可经面板种子复现.
    """
    total = max(1, width * height)
    specs = []
    for idx in range(count):
        if variants and idx:
            factor = _VARIANT_FACTORS[idx % len(_VARIANT_FACTORS)]
            aspect = width / max(1, height) * factor
            vw, vh = resolve_output_size(provider, model,
                                         max(2, round((total * aspect) ** 0.5)),
                                         max(2, round((total / max(aspect, 1e-9)) ** 0.5)))
        else:
            vw, vh = width, height
        spec_seed = (seed + idx) % 2147483647 if idx else seed
        specs.append((format_size(provider, vw, vh), spec_seed))
    return specs


def resolve_texture_prompt(tex_state, prompt: str) -> tuple:
    """按生成模式/无缝/参考图组装实际发送的完整提示词, 返回 (完整提示词, 参考图条目列表)

    GenerateTexture 与 PreviewTexturePrompt 共用(保证预览即发送).
    """
    texture_mode = tex_state.generation_mode == 'TEXTURE'
    seamless = texture_mode and tex_state.use_seamless
    refs = collect_texture_refs(tex_state)
    ref_descriptions = [ref.description for ref in refs]
    full_prompt = build_texture_prompt(
        prompt, seamless, ref_descriptions, kind='texture' if texture_mode else 'image')
    return full_prompt, refs


def texture_request_worker(op, request_args: ImageRequestArgs, model, prompt, specs, negative_prompt, ref_images=None):
    """纹理请求后台线程入口(op 模拟 self): 按规格表逐张串行请求并把结果列表写入 op._result

    request_args 是主线程快照的偏好值命名元组(RNA 属性不支持跨线程读取);
    specs 为逐张 (尺寸串, 种子) 规格表, 中途失败即停止, op._result 固定为
    (成功图片字节列表, 首个错误或 None);
    ref_images 为参考图字节列表(参考图生图路径, 文生图为 None);
    批量时另写 op._batch_total 供 _on_response 组装"已成功 i/n 张"文案.
    """
    try:
        results = []
        err = None
        total = len(specs)
        base_text = op.status_text
        for idx, (size, seed) in enumerate(specs, 1):
            # 批量进度文案(worker 线程写普通属性, modal 主线程每拍回写面板状态)
            op._progress_text = f"{base_text} [{idx}/{total}]" if total > 1 else None
            image_bytes, err = request_image(
                request_args.base_url, request_args.api_key, model, prompt,
                request_args.timeout, provider=request_args.provider,
                size=size, seed=seed, negative_prompt=negative_prompt,
                ref_images=ref_images or None)
            if err is not None:
                break
            results.append(image_bytes)
        op._batch_total = total if total > 1 and err is not None else 0
        op._result = (results, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


class GenerateTexture(Operator, AiRequestMixin):
    """
    生成纹理操作器

    功能: 把描述发给 AI 图像服务, 纹理贴图开关开启时产物做无缝化处理(可选),
    关闭时按提示词原样生成任意图像; 结果加载为贴图打包, 不创建材质不赋物体;
    需要使用时在着色器中新建图像纹理节点选择该贴图.

    要求: 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.generate_texture"
    bl_label = "Generate Texture"
    bl_description = ("Ask the AI image service to generate an image from the prompt and pack it into the blend file, "
                      "the Generation Count option generates several images with one click (each image is billed separately)")
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Generating texture... (Esc to cancel)"
    status_scope = 'texture'

    def invoke(self, context: Context, event: Event):
        tex_state = context.window_manager.ch_ai_texture_state
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, tex_state.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the texture in the prompt field first")
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_texture_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}

        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        # 生成模式与无缝开关随请求一并快照: 等待期间被改动时本单请求行为仍一致;
        # 命名前缀随模式区分(纹理贴图 "AI Tex" / 图像 "AI Bmp"), 等待文案同理
        self._texture_mode = tex_state.generation_mode == 'TEXTURE'
        self._seamless = self._texture_mode and tex_state.use_seamless
        self._namer = ai_texture_name if self._texture_mode else ai_image_name
        self._prefix = AI_TEXTURE_PREFIX if self._texture_mode else AI_IMAGE_PREFIX
        self.status_text = ("Generating texture... (Esc to cancel)" if self._texture_mode
                            else "Generating image... (Esc to cancel)")
        # 提示词组装与预览算子共用同一函数(保证预览即发送): 无缝引导 + 参考图职责声明
        full_prompt, refs = resolve_texture_prompt(tex_state, prompt)
        # 模型统一取纹理组的单一可见下拉(resolve_texture_model): 纹理面板带不带参考图都是
        # 这一个 Model 控件, 曾误读 UI 不可见的 panel_edit_model(切服务商时被复位值填充),
        # 导致"面板选了 Pro,请求却发 Flash"(2026-10-11 实测缺陷, 见 CHANGELOG);
        # 参考图字节主线程编码(超长边按服务商上限缩放副本, 原图零改动), 单张失败跳过并提醒
        model = resolve_texture_model(sstate, prefs)
        ref_images = []
        _count, limit_edge = resolve_ref_limits(provider, prefs)
        for ref in refs:
            data, enc_err = image_to_scaled_png_bytes(ref.image, limit_edge)
            if enc_err is not None:
                self.report({'WARNING'}, describe_error(enc_err))
                continue
            ref_images.append(data)
        if refs and not ref_images:
            self.report({'WARNING'}, "The reference images are unavailable, generating without them")
        # 随机种 0 时本地抽取实际种子并回填面板(可复现); 批量规格表从基准递增
        seed = effective_seed(tex_state)
        # 自定义分辨率按服务商/模型支持的区间修正(CUSTOM 原样下发, 服务端裁决)
        out_w, out_h = resolve_output_size(provider, model, tex_state.custom_width, tex_state.custom_height)
        if (out_w, out_h) != (tex_state.custom_width, tex_state.custom_height):
            self.report({'INFO'}, report("Resolution adjusted to {} x {} for the provider limits").format(out_w, out_h))
        # 负向提示词仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        from ..utils.provider_registry import get_image_provider
        neg_prompt = tex_state.negative_prompt.strip() if get_image_provider(provider).supports_negative_prompt else ""
        # 逐张请求规格表: 批量多变体开启且张数>1 时每张换宽高比变体, 种子从基准递增
        specs = _batch_request_specs(provider, model, out_w, out_h,
                                     tex_state.count, seed, tex_state.batch_variants)
        # 命名短名随请求一并快照: 等待期间描述被改动时产物名仍与请求内容一致
        self._stem = prompt_stem(prompt)
        self._prompt = prompt
        args = (ImageRequestArgs(base_url, api_key, prefs.image_timeout or None, provider),
                model, full_prompt, specs, neg_prompt, ref_images or None)
        if not self._start_request(context, texture_request_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, results, err):
        """逐张落地产物: results 为成功图片字节列表, err 为首个请求错误(部分成功时仅告警)"""
        if not isinstance(results, list):
            results = []
        if err is not None and not results:
            record_request_error(context, 'texture', self.bl_label, err)
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if err is not None:
            total = getattr(self, '_batch_total', 0)
            if total > 1:
                # 批量部分成功: 报告成功张数与失败原因(错误摘要仍记录首个错误)
                self.report({'WARNING'}, report("Succeeded {} of {} images, failed: {}").format(
                    len(results), total, describe_error(err)))
            else:
                self.report({'WARNING'}, describe_error(err))
        created = 0
        focused = 0
        for image_bytes in results:
            if self._seamless:
                # 已计费的生成结果不能因本地后处理失败而丢弃: 失败时沿用原图并提示
                seamless_bytes, seamless_err = make_seamless(image_bytes)
                if seamless_err is not None:
                    self.report({'WARNING'}, seamless_err)
                else:
                    image_bytes = seamless_bytes
            image, img_err = load_image_from_bytes(image_bytes, unique_ai_name(self._namer(self._stem)))
            if img_err is not None:
                self.report({'ERROR'}, describe_error(img_err))
                continue
            created += 1
            prefs = get_prefs()
            if prefs.image_save_dir:
                path, save_err = save_image_file(image, prefs.image_save_dir)
                if save_err is not None:
                    self.report({'WARNING'}, save_err)
                else:
                    self.report({'INFO'}, report("Image saved to {}").format(path))
            # 产物置顶到图像列表并聚焦图像编辑器(最后一张留在列表首位)
            focused = activate_image(context, image.name, top=True)
            # 提示词无英文词(名字落到兜底档)时, 异步用全局文本服务取一个英文名
            maybe_auto_name_image(image.name, self._prompt, self._prefix)
            created_msg = "Texture '{}' created" if self._texture_mode else "Image '{}' created"
            self.report({'INFO'}, report(created_msg).format(image.name))
        if created == 0:
            self.report({'ERROR'}, "AI request finished without a result")
            return {'CANCELLED'}
        if focused == 0:
            self.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
        return {'FINISHED'}


def _prune_image_backups(op, base_name: str, keep_name: str):
    """按偏好上限清理同源图像的旧 "_bak" 备份(数据块级删除, 已存盘文件不受影响)

    base_name 为原图名(未加后缀), keep_name 为刚生成的最新备份名(必保留);
    其余备份按编号后缀从旧到新移除, 只保留偏好份数(上限 - 1)份.
    """
    limit = max(0, get_prefs().image_backup_limit - 1)
    prefix = f"{base_name}_bak"
    backups = [img for img in bpy.data.images
               if (img.name == prefix or img.name.startswith(prefix + ".")) and img.name != keep_name]
    excess = len(backups) - limit
    if excess <= 0:
        return

    def _suffix_num(name: str) -> int:
        tail = name[len(prefix):]
        return int(tail[1:]) if tail.startswith(".") and tail[1:].isdigit() else 0

    for img in sorted(backups, key=lambda img: _suffix_num(img.name))[:excess]:
        op.report({'INFO'}, report("Old backup '{}' removed").format(img.name))
        bpy.data.images.remove(img)


def modify_image_worker(op, request_args: ImageRequestArgs, model, prompt, ref_images, size, seed, negative_prompt):
    """图像修改请求后台线程入口(op 模拟 self): 参考图生图请求并把结果写入 op._result"""
    try:
        image_bytes, err = request_image(
            request_args.base_url, request_args.api_key, model, prompt, request_args.timeout,
            provider=request_args.provider,
            size=size, ref_images=ref_images, seed=seed, negative_prompt=negative_prompt)
        op._result = (image_bytes, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


class ModifyImage(Operator, AiRequestMixin):
    """
    修改图像操作器

    功能: 以纹理列表当前高亮的图像为参考图, 连同描述发给 AI 图像服务参考图生图;
    原图不删除, 改名追加 "_bak" 后缀(前缀不变, 仍留在列表中作为备份),
    新图继承原图原名并置顶聚焦图像编辑器.

    要求: 列表中有高亮图像; 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.modify_image"
    bl_label = "Modify Image"
    bl_description = ("Edit the highlighted image with the AI image model based on the prompt, "
                      "the original is kept and renamed with a '_bak' suffix; "
                      "affected settings: prompt, generation mode, seamless, negative prompt, "
                      "resolution, seed and the panel's Model override; always a single image")
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Modifying image... (Esc to cancel)"
    status_scope = 'texture'

    @classmethod
    def poll(cls, context: Context):
        state = context.window_manager.ch_ai_texture_state
        return 0 <= state.images_active_index < len(state.images)

    def invoke(self, context: Context, event: Event):
        tex_state = context.window_manager.ch_ai_texture_state
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, tex_state.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the change in the prompt field first")
            return {'CANCELLED'}
        if not (0 <= tex_state.images_active_index < len(tex_state.images)):
            self.report({'WARNING'}, "No image selected")
            return {'CANCELLED'}
        source = bpy.data.images.get(tex_state.images[tex_state.images_active_index].name)
        if source is None:
            self.report({'WARNING'}, "Image no longer exists")
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_texture_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}
        # 源图编码为 PNG 字节(主线程完成, RNA 属性不支持跨线程读取)
        source_bytes, err = image_to_png_bytes(source)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}

        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        # 模型取纹理组的单一可见下拉(同 GenerateTexture, 见其注释)
        model = resolve_texture_model(sstate, prefs)
        # 生成模式/无缝/等待文案随请求一并快照
        self._texture_mode = tex_state.generation_mode == 'TEXTURE'
        self._seamless = self._texture_mode and tex_state.use_seamless
        self._namer = ai_texture_name if self._texture_mode else ai_image_name
        full_prompt = build_texture_prompt(prompt, self._seamless) if self._texture_mode else prompt.strip()
        out_w, out_h = resolve_output_size(provider, model, tex_state.custom_width, tex_state.custom_height)
        if (out_w, out_h) != (tex_state.custom_width, tex_state.custom_height):
            self.report({'INFO'}, report("Resolution adjusted to {} x {} for the provider limits").format(out_w, out_h))
        size = format_size(provider, out_w, out_h)
        # 负向提示词仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        from ..utils.provider_registry import get_image_provider
        neg_prompt = tex_state.negative_prompt.strip() if get_image_provider(provider).supports_negative_prompt else ""
        self._source_name = source.name
        self._stem = prompt_stem(prompt)
        args = (ImageRequestArgs(base_url, api_key, prefs.image_timeout or None, provider),
                model, full_prompt, [source_bytes], size, effective_seed(tex_state), neg_prompt)
        if not self._start_request(context, modify_image_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, image_bytes, err):
        if err is not None:
            record_request_error(context, 'texture', self.bl_label, err)
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if self._seamless:
            # 已计费的生成结果不能因本地后处理失败而丢弃: 失败时沿用原图并提示
            seamless_bytes, seamless_err = make_seamless(image_bytes)
            if seamless_err is not None:
                self.report({'WARNING'}, seamless_err)
            else:
                image_bytes = seamless_bytes
        # 原图保留: 改名追加 _bak 后缀(前缀不变仍在列表; 重名由 Blender 自动加序号),
        # 随后按偏好上限清理更早的备份(仅保留最新若干份)
        source = bpy.data.images.get(self._source_name)
        if source is not None:
            source.name = f"{self._source_name}_bak"
            _prune_image_backups(self, self._source_name, source.name)
        else:
            self.report({'INFO'}, report("The source image was deleted while waiting"))
        # 新图继承原图原名(源图缺失时回落提示词短名), 前缀必然保留在对应列表内
        base_name = self._source_name if source is not None else self._namer(self._stem)
        image, img_err = load_image_from_bytes(image_bytes, unique_ai_name(base_name))
        if img_err is not None:
            self.report({'ERROR'}, describe_error(img_err))
            return {'CANCELLED'}
        focused = activate_image(context, image.name, top=True)
        if focused == 0:
            self.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
        created_msg = "Texture '{}' created" if self._texture_mode else "Image '{}' created"
        self.report({'INFO'}, report(created_msg).format(image.name))
        return {'FINISHED'}


class PreviewTexturePrompt(Operator):
    """
    查看完整提示词操作器

    功能: 按生成纹理/图像的组装口径(生成模式口吻 + 无缝引导 + 参考图职责声明),
    把实际会发送的完整提示词写入 AI_Texture_Final_Prompt.txt 并聚焦文本编辑器;
    与 GenerateTexture 逐字一致(同一组装函数), 供核对发送内容.
    """

    bl_idname = "ch_ai.preview_texture_prompt"
    bl_label = "View Full Prompt"
    bl_description = ("Show the exact prompt that Generate Texture will send, assembled with the "
                      "seamless guidance and reference roles, in the text editor")
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        tex_state = context.window_manager.ch_ai_texture_state
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, tex_state.prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the texture in the prompt field first")
            return {'CANCELLED'}
        full_prompt, refs = resolve_texture_prompt(tex_state, prompt)
        mode = "Texture Map" if tex_state.generation_mode == 'TEXTURE' else "Image"
        header = iface("Texture & Image final prompt (verbatim): mode {}, seamless {}, {} reference image(s)") \
            .format(mode, "on" if tex_state.use_seamless else "off", len(refs))
        ref_names = ", ".join(ref.image.name for ref in refs) or "-"
        text, _err = write_text_block(
            AI_TEXTURE_FINAL_PROMPT_TEXT_NAME,
            header + "\nReferences: " + ref_names + "\n\n" + full_prompt + "\n")
        focused, _ = focus_text_editors(context, text)
        if focused == 0:
            self.report({'INFO'}, "No text editor area open, switch an area to the text editor first")
        return {'FINISHED'}


def _save_image_to_path(image, path: str) -> tuple:
    """把图像数据块按用户选择的路径存为 PNG, 返回 (文件路径, 错误信息, 是否避让改名)

    与 save_image_file 的区别: 文件名取用户在文件浏览器里填的名字(选目录时用数据块名).
    目标位置已有同名文件时不覆盖, 自动追加递增序号(-1, -2, ...)另存.
    """
    directory, filename = os.path.split(path)
    if not filename:
        filename = sanitize_image_file_name(image.name)
    if not filename.lower().endswith(".png"):
        filename += ".png"
    path = os.path.join(directory, filename)
    renamed = os.path.exists(path)
    if renamed:
        base, ext = os.path.splitext(path)
        num = 1
        while os.path.exists(path):
            path = f"{base}-{num}{ext}"
            num += 1
    try:
        os.makedirs(directory, exist_ok=True)
        image.filepath_raw = path
        image.file_format = 'PNG'
        image.save()
    except (OSError, RuntimeError) as e:
        return None, api_error("Failed to save image", e), False
    return path, None, renamed


# 保存操作器的目标条目(纹理/效果图主列表/通道预览三个图像列表共用保存按钮)
_save_target_items = [
    ('TEXTURE', "Texture", "The texture image list"),
    ('RENDER', "Render", "The render image list"),
    ('PASS', "Pass Preview", "The render pass preview list"),
]


def _image_list_state(context: Context, target: str):
    """按目标取 (状态属性组, 集合属性名, 高亮索引属性名)

    纹理与效果图主列表用 images/images_active_index; 效果图通道预览迷你列表
    用 pass_images/pass_images_active_index(同一状态属性组上的另一个快照集合).
    """
    wm = context.window_manager
    state = wm.ch_ai_texture_state if target == 'TEXTURE' else wm.ch_ai_render_state
    if target == 'PASS':
        return state, "pass_images", "pass_images_active_index"
    return state, "images", "images_active_index"


class SaveImage(Operator):
    """
    保存图像操作器

    功能: 把图像列表当前高亮的图像另存为 PNG 文件(弹出文件浏览器选择保存位置,
    默认目录取偏好设置的图像保存目录); 列表为空时不可用; 同名不覆盖, 自动追加序号另存.

    支持的目标:
    - TEXTURE: 纹理图像列表(贴图数据块)
    - RENDER: 效果图主列表(生成结果数据块)
    - PASS: 效果图通道预览迷你列表(固定名捕获预览数据块)
    """

    bl_idname = "ch_ai.save_image"
    bl_label = "Save Image"
    bl_description = "Save the highlighted image to a PNG file"
    bl_options = {'REGISTER'}

    # 目标列表由面板按所在面板写死(两个图像列表同款按钮共用一个操作器);
    # 可用性由面板按列表是否为空置灰, 故不设 poll(与 DeleteImage 同)
    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=_save_target_items,
        default='TEXTURE',
    )  # type: ignore
    filepath: StringProperty(
        name="File Path",
        description="Target file path of the saved image",
        subtype='FILE_PATH',
    )  # type: ignore

    def _active_image(self, context: Context):
        """目标列表高亮条目对应的图像数据块(条目标识即数据块名)"""
        state, collection, index_name = _image_list_state(context, self.target)
        items = getattr(state, collection)
        idx = getattr(state, index_name)
        if not (0 <= idx < len(items)):
            return None
        return bpy.data.images.get(items[idx].name)

    def invoke(self, context: Context, event: Event):
        image = self._active_image(context)
        if image is None:
            self.report({'WARNING'}, "No image selected")
            return {'CANCELLED'}
        prefs = get_prefs()
        # 默认路径: 偏好目录 + 图像名(**经 sanitize 清洗**——通道预览图的固定名含冒号,
        # "AI Ref: Depth.png" 在 Windows 会落进 NTFS 备用数据流, 产出无扩展名的坏文件);
        # 偏好未配置时落到系统 home(文件浏览器内可改)
        default_dir = prefs.image_save_dir or bpy.path.abspath("//")
        self.filepath = os.path.join(default_dir, f"{sanitize_image_file_name(image.name)}.png")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        image = self._active_image(context)
        if image is None:
            self.report({'WARNING'}, "Image no longer exists")
            return {'CANCELLED'}
        path, err, renamed = _save_image_to_path(image, bpy.path.abspath(self.filepath))
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if renamed:
            self.report({'INFO'}, report("Same name exists, saved as '{}'").format(os.path.basename(path)))
        self.report({'INFO'}, report("Image saved to {}").format(path))
        return {'FINISHED'}


class SaveAllImages(Operator):
    """
    批量保存图像操作器

    功能: 把列表中的全部图像逐张另存为 PNG 文件(弹出文件浏览器选择目标目录,
    默认目录取偏好设置的图像保存目录); 列表为空时不可用; 已失效条目跳过;
    同名不覆盖, 自动追加序号另存.

    支持的目标: TEXTURE / RENDER / PASS(同 SaveImage).
    """

    bl_idname = "ch_ai.save_all_images"
    bl_label = "Save All Images"
    bl_description = "Save every image in the list to a PNG file each (pick the target directory)"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=_save_target_items,
        default='TEXTURE',
    )  # type: ignore
    directory: StringProperty(
        name="Directory",
        description="Target directory of the saved images",
        subtype='DIR_PATH',
    )  # type: ignore

    def invoke(self, context: Context, event: Event):
        prefs = get_prefs()
        self.directory = prefs.image_save_dir or bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        state, collection, _index_name = _image_list_state(context, self.target)
        directory = bpy.path.abspath(self.directory)
        saved = 0
        renamed = 0
        for item in getattr(state, collection):
            image = bpy.data.images.get(item.name)
            if image is None:
                continue
            # 文件名清洗同上(数据块名可能含冒号, 见 SaveImage.invoke 注释)
            path, err, was_renamed = _save_image_to_path(
                image, os.path.join(directory, f"{sanitize_image_file_name(image.name)}.png"))
            if err is not None:
                self.report({'WARNING'}, describe_error(err))
                continue
            saved += 1
            renamed += 1 if was_renamed else 0
        if saved == 0:
            self.report({'WARNING'}, "No image saved")
            return {'CANCELLED'}
        if renamed:
            self.report({'INFO'}, report("Renamed {} files to avoid overwriting").format(renamed))
        self.report({'INFO'}, report("Saved {} images to {}").format(saved, directory))
        return {'FINISHED'}
