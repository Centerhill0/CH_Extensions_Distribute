"""
AI 效果图面板模块

提供以下功能:
- 图像助手选项卡下的效果图主列表(只含生成结果 "AI Render" 前缀; 空也常驻, 行数随内容自适应;
  点击行按偏好切换图像编辑器, 上移/下移排序; 版本链命名, 被修改版本不改名)
  右侧竖列为自动打开开关 + 上移/下移 + 删除按钮
- 预览区(常驻, 见 ui/panels/preview): 只反映主列表(效果图版本链), 缩略图右侧为纵向的
  保存当前图像/保存全部图像两个按钮, 下方为当前高亮图像的大图预览, 画廊开关展开后改为列表内
  图像的缩略图图标视图
- 生成通道小节(内联可折叠, 默认收起, 整体包在 box 中, **位于 Settings 之上**):
  通道组合预设行(下拉+应用/保存/删除, 存于偏好)
  + 参考通道两列网格(左 4 右 3: Combined/Depth/Normal/Semantic Segmentation | Line Drawing/Diffuse Color/AO)
  + 通道参数 box(开启对应通道才显示: 深度范围(近/远; **同行数值右侧**另有「深度拾取」按钮 ——
    按相机视锥几何投射采样可见深度并回填范围, 回填后仍可手改) + 深度量化曲线, 法向 OpenGL/DirectX
    约定, 线稿宽度系数, AO 遮蔽距离)
  + 通道设置 box(常驻: 输出分辨率钳制开关在首行(深度范围前一行),
    其下为已开启通道的生成参数; 钳制关时直接用 Blender 输出分辨率, 开时超服务商上限等比下调)
  + 通道预览迷你列表(有捕获图才显示, 点击行聚焦图像编辑器回看; 右侧竖列为删除(X)/
    保存当前(FILE_TICK)/保存全部(OUTPUT), 删除联动清理发送缓存对应通道)
- 捕获信息与实际输出标签 + "生成通道"按钮(本地捕获, 不产生费用; 模态分帧渲染,
  等待框只显示秒数): 与本节其余内容同在 box 内, **随生成通道小节折叠**
- 发送通道与设置两个独立小节(各自一个 box, 独立折叠, 默认都收起, **Send Passes 在上**):
  Send Passes: 与捕获勾选独立的发送开关两行(第一行四列/第二行三列) +
  置灰预算摘要与超限截断/未捕获/风格图死引用与空列表警示行;
  Settings: 输出分辨率(缩放档/自定义, 比率恒锁相机分辨率) + 随机种(行尾骰子随机化) +
  生成张数 + 批量多变体(常驻, 仅张数>1 时可用) + 风格参考图开关(紧贴多变体下方,
  开启后显示引用迷你列表与描述行)
- 提示词输入(生成取长文描述块优先; 修改取单行框优先)与 token 预算摘要(右对齐置灰),
  编辑描述/优化提示词/查看完整提示词三个按钮, 修改效果图与生成效果图按钮
- 请求等待进度(仅显示效果图流程), 进度后跟终止按钮
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import (
    ClearPrompt,
    EditPrompt,
    OptimizePrompt,
    RandomizeSeed,
    resolve_prompt,
)
from ...operators.ai_render import (
    ApplyPassPreset,
    CaptureViewRefs,
    ClearPassBackups,
    DeletePassPreset,
    GenerateRender,
    ModifyRender,
    PickDepthRange,
    PreviewRenderPrompt,
    SavePassPreset,
    _PASS_TOGGLES,
    _pass_title,
    _resolve_service,
    collect_send_passes,
    collect_style_images,
    count_unavailable_style_refs,
    resolve_render_request,
)
from ...operators.ai_texture import SaveAllImages, SaveImage, resolve_edit_model
from ...preference import get_prefs
from ...utils import (
    AI_RENDER_PROMPT_TEXT_NAME,
    WARN_EDGE_PX,
    estimate_capture_bytes,
    estimate_prompt_tokens,
    prompt_token_budget,
    resolve_capture_size,
    resolve_output_size,
    resolve_ref_limits,
)
from ...operators.list_ops import DeleteImage
from .blocks import (
    draw_error_box,
    draw_image_list_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_ref_image_list,
    draw_save_tail,
    draw_wait_box,
)
from .preview import draw_preview_box

# 错误摘要最多显示的 traceback 行数(取末尾异常段, 与脚本面板一致)
_ERROR_LINES = 4

# 图像列表显示行数下限(空列表的矮框高度, 与其余列表的实测定值一致)
_IMAGE_ROWS_MIN = 4

# 图像列表显示行数上限(行数随内容增长到该值)
_IMAGE_ROWS = 4


def _size_text(num_bytes: int) -> str:
    """字节数转可读体积文案(不足 1MB 用 KB, 单位不翻译不入典)"""
    if num_bytes >= 1024 * 1024:
        return f"{num_bytes / (1024 * 1024):.1f} MB"
    return f"{num_bytes / 1024:.0f} KB"


def _draw_preview_tail(tail, state):
    """预览区缩略图右侧纵向按钮列: 保存当前高亮图像(FILE_TICK)在上, 保存全部(OUTPUT)在下

    与纹理面板同款的两个按钮(绘制见 ui/panels/blocks), 目标列表 RENDER.
    """
    draw_save_tail(tail, state, 'RENDER')


def _draw_passes(layout, state, scene, provider, prefs):
    """生成通道小节(内联可折叠, 默认收起, 整体包在一个 box 中, 位于 Settings 之上)

    与 Settings 同为内联小节而非 bl_parent_id 子面板: 后者位置由 Blender 决定, 无法插进
    draw 中段. 本小节只放"捕获什么通道, 怎么触发捕获"这两件同族的事,
    输出分辨率等生成参数留给下方的 Settings 小节.

    标题原文用 "Pass Generation" 而非 "Passes": 后者是 Blender 系统词条(译"通道"),
    系统词条不查插件词典, 只能改原文反译成小节名"生成通道".
    """
    box = layout.box()
    header = box.row()
    header.prop(state, "use_show_passes", text="", emboss=False, icon='TRIA_DOWN' if state.use_show_passes else 'TRIA_RIGHT')
    header.label(text="Pass Generation")
    if not state.use_show_passes:
        # 收起态摘要: 已捕获通道数与发送集过期标记, 不展开即可判断能否直接生成
        _draw_passes_header_summary(header, state, scene, provider, prefs)
        return
    # 分栏只作用于本小节(用子列承载), 不影响随后的 Settings/描述/按钮行
    sub = box.column()
    # sub.use_property_split = True

    # 通道组合预设: 一键应用捕获/发送两组开关的命名组合(存于偏好, 跨会话);
    # 下拉选择后点对勾应用, 加号把当前两组开关存为预设(重名覆盖), 叉号删除选中预设
    preset_row = sub.row(align=True)
    preset_row.prop(prefs, "pass_preset_choice", text="")
    preset_row.operator(ApplyPassPreset.bl_idname, text="", icon='CHECKMARK')
    preset_row.operator(SavePassPreset.bl_idname, text="", icon='ADD')
    preset_row.operator(DeletePassPreset.bl_idname, text="", icon='REMOVE')

    # 参考通道: 两列网格(左 4 右 3, 顺序从左列到右列纵向排布; 每项悬停看通道含义)
    grid = sub.row(align=False)
    left = grid.column(align=True)
    right = grid.column(align=True)
    left.prop(state, "use_combined")
    left.prop(state, "use_depth")
    left.prop(state, "use_normal")
    left.prop(state, "use_segmentation")
    right.prop(state, "use_edge")
    right.prop(state, "use_diffuse")
    right.prop(state, "use_ao")
    # 通道设置 box: 钳制开关常驻首行(钳制是捕获侧设置, 无参数通道开启时也有家),
    # 其下只显示已开启通道的生成参数(按通道顺序排布), 整列 property split;
    # 深度范围用二元向量的原生渲染(作者定稿): label 列"深度范围", X/Y 两行子标签
    # 承载 近/远(首=近端白, 次=远端黑), 与其它参数行统一对齐
    pbox = sub.box()
    pcol = pbox.column()
    pcol.use_property_split = True
    # 输出分辨率钳制(仅开关, 深度范围前一行): 关闭时直接用 Blender 输出分辨率(乘
    # Resolution Scale), 打开后仅在最长边超出当前服务商参考图上限时等比下调(标签与实际
    # 渲染同口径, 见 render_passes.resolve_capture_size); 上限即偏好解析出的当前服务商
    # 参考图最长边(填 0 跟随官方上限; 解析结果仍为 0 时表示不限, 不钳制——只有自定义服务商会是 0)
    pcol.prop(state, "use_clamp_resolution")
    if state.use_depth:
        # 深度拾取: 按相机视锥几何投射采样可见深度并回填下面的近/远(回填后仍可手改).
        # 位置在深度范围属性**之后**,**同一行内**: 按钮只有落进**值列**才能与上下数值列
        # 左右对齐, 而落进值列的唯一入口是 Blender 的 `item_prop_split_layout_hack`
        # (interface_layout.cc:1964) —— 它见到**父布局是 Row** 就把该行的
        # `child_items_layout_` 指向 split 的值格 `layout_split->row(true)`, 此后该行内
        # **后续追加的项(含 operator())都进这个值格**(button 走 layout_add_but, 见源码
        # 5976 行同样读 `child_items_layout_`), 于是按钮与 "深度范围" 的数值共用标签列.
        # 两点顺序缺一不可(前两轮踩坑根因):
        # ① `prop()` 必须**先**调用 —— 分裂是 prop() 建立的, 按钮排在它前面时行内还没有
        #    分裂, 按钮退化成整行宽(左边缘顶到面板左边), 正是作者实测的错位;
        # ② 行内**不要**再设 use_property_split —— 分裂由父列 pcol 继承下来
        #    (init_from_parent 复制 PropSep 标志), 行内再设一次会另起一层分裂.
        brow = pcol.row(align=True)
        brow.prop(state, "depth_range")
        brow.operator(PickDepthRange.bl_idname, icon='UV_SYNC_SELECT', text="")
        # 8bit 量化曲线: 反深度(默认)把灰阶向近场集中, 主体景深细节保留最多
        pcol.prop(state, "depth_curve")
    if state.use_normal:
        pcol.prop(state, "normal_convention")
    if state.use_edge:
        pcol.prop(state, "edge_width_scale")
        # 材质边界: 材质之间是否生成笔画(落在 Lineart 修改器 use_material)
        pcol.prop(state, "use_material_borders")
    if state.use_ao:
        pcol.prop(state, "ao_distance")
    # 通道预览迷你列表: 已捕获通道图的回看入口(点击行按偏好聚焦图像编辑器), 不排序;
    # (通道图不进主列表/画廊——列表分离, 回看在面板内即可完成); 无捕获图时不显示;
    # 右侧删除按钮删的是通道预览图数据块(联动清理发送缓存对应通道)
    if state.pass_images:
        list_row = sub.row(align=True)
        list_row.template_list("CH_UL_ai_images", "ch_ai_pass_images", state, "pass_images", state, "pass_images_active_index", rows=max(1, min(len(state.pass_images), 4)))
        # 右侧按钮竖列(全部纵向): 删除(X) / 保存当前通道(FILE_TICK) / 保存全部通道(OUTPUT);
        # 空列表/无高亮时整列置灰
        btn_col = list_row.column(align=False)
        has_sel = 0 <= state.pass_images_active_index < len(state.pass_images)
        del_btn = btn_col.row(align=False)
        del_btn.enabled = has_sel
        op = del_btn.operator(DeleteImage.bl_idname, text="", icon='X')
        op.target = 'PASS'
        # 一键清除备份通道(重新捕获时 _bak 保留的历史版本; 无备份时按钮置灰)
        clear_bak = btn_col.row(align=False)
        clear_bak.operator(ClearPassBackups.bl_idname, text="", icon='LOOP_BACK')
        save_one = btn_col.row(align=False)
        save_one.enabled = has_sel
        op = save_one.operator(SaveImage.bl_idname, text="", icon='FILE_TICK')
        op.target = 'PASS'
        save_all = btn_col.row(align=False)
        save_all.enabled = has_sel
        op = save_all.operator(SaveAllImages.bl_idname, text="", icon='OUTPUT')
        op.target = 'PASS'
    # 捕获信息(实际输出)与实际输出标签下方的生成通道按钮: 随本小节折叠(收起即隐藏)
    _draw_capture_info(sub, state, scene, provider, prefs)
    # 生成通道: 本地渲染所选通道并在图像编辑器预览(不调用 AI 服务, 不产生费用)
    sub.operator(CaptureViewRefs.bl_idname, icon='RENDERLAYERS')
def _draw_passes_header_summary(header, state, scene, provider, prefs):
    """Pass Generation 收起态摘要: 已捕获通道数 + 发送集过期标记(不展开即可判断能否直接生成)"""
    _count, limit_edge = resolve_ref_limits(provider, prefs)
    _send_names, _missing, stale = collect_send_passes(state, scene, limit_edge)
    note = header.row()
    note.enabled = False
    note.label(text=iface("Captured: {}").format(len(state.pass_images)), icon='INFO')
    if stale:
        note.label(text=iface("previews may be outdated"), icon='ERROR')


def _draw_send_content(col, state, scene, provider, prefs):
    """Send Passes 标签的内容(发送开关两行四列 + 预算摘要与警示行), 由合并子面板调用

    摘要与生成操作器同口径: 勾选发送的通道不可用(缓存与预览图都缺失)会阻断,
    这里提前点名; 超限截断与风格图死引用同理提前可见.
    """
    col.use_property_split = False
    # 发送开关两行(第一行四列/第二行三列; 风格参考图开关已移到 Settings 的批量多变体下方)
    row_one = col.row(align=True)
    row_one.prop(state, "use_send_combined", toggle=True)
    row_one.prop(state, "use_send_depth", toggle=True)
    row_one.prop(state, "use_send_normal", toggle=True)
    row_one.prop(state, "use_send_segmentation", toggle=True)
    row_two = col.row(align=True)
    row_two.prop(state, "use_send_edge", toggle=True)
    row_two.prop(state, "use_send_diffuse", toggle=True)
    row_two.prop(state, "use_send_ao", toggle=True)
    _limit_count, _limit_edge = resolve_ref_limits(provider, prefs)
    send_names, missing, _stale = collect_send_passes(state, scene, _limit_edge)
    style_count = len(collect_style_images(state))
    total = len(send_names) + style_count
    info = col.column(align=True)
    info.enabled = False
    row = info.row()
    row.use_property_split = False
    if _limit_count > 0:
        row.label(text=iface("Send {} / {} reference images").format(total, _limit_count), icon='INFO')
    else:
        row.label(text=iface("Send {} reference images").format(total), icon='INFO')
    if 0 < _limit_count < total:
        # 与生成同口径: 风格图占保底名额, 通道截断到 上限-风格张数(名额被占满时点名)
        room = _limit_count - style_count
        if room < 1:
            row = info.row()
            row.use_property_split = False
            row.label(text=iface("The {} style images fill the budget, no room for pass images").format(style_count), icon='ERROR')
        else:
            dropped = ", ".join(_pass_title(name) for name in send_names[room:])
            row = info.row()
            row.use_property_split = False
            row.label(text=iface("Exceeds the provider limit, will drop: {}").format(dropped), icon='ERROR')
    if missing:
        row = info.row()
        row.use_property_split = False
        row.label(text=iface("Not captured yet: {}").format(", ".join(_pass_title(name) for name in missing)), icon='ERROR')
    # 风格图存在性: 引用悬空/像素未加载的条目不参与发送(发送前会剔除), 点名提醒清理;
    # 开关已激活但列表为空同样提醒(否则"激活了却没有风格图被发送"无从察觉)
    if state.use_send_style:
        invalid = count_unavailable_style_refs(state)
        if invalid:
            row = info.row()
            row.use_property_split = False
            row.label(text=iface("{} style reference(s) unavailable, the image is missing").format(invalid), icon='ERROR')
        elif not state.style_images:
            row = info.row()
            row.use_property_split = False
            row.label(text=iface("Style references enabled but the list is empty"), icon='ERROR')


def _draw_capture_info(sub, state, scene, provider, prefs):
    """钳制开关之下的实际输出标签: 像素尺寸 + 落盘体积估算 + 长边超阈值的提醒

    标签与实际渲染同口径(未开钳制即 Blender 输出分辨率乘百分比), 体积为按各通道落盘格式
    的估算值而非精确值; 体积能提前暴露"通道图另作他用时的大体积"(长边超阈值只提醒不禁止).
    """
    _limit_count, limit_edge = resolve_ref_limits(provider, prefs)
    clamp_edge = limit_edge if state.use_clamp_resolution else 0
    cap_w, cap_h = resolve_capture_size(scene, clamp_edge)
    keys = [key for attr, key in _PASS_TOGGLES if getattr(state, attr)]
    estimate = estimate_capture_bytes((cap_w, cap_h), keys)
    info = sub.column(align=True)
    info.enabled = False
    row = info.row()
    row.use_property_split = False
    row.label(text=iface("Capture output: {} x {} ({})").format(cap_w, cap_h, _size_text(estimate)), icon='INFO')
    if max(cap_w, cap_h) > WARN_EDGE_PX:
        row = info.row()
        row.use_property_split = False
        row.label(text=iface("Long edge above {} px, the pass images will be large").format(WARN_EDGE_PX), icon='ERROR')


def _draw_token_summary(col, state, scene, provider, prefs, sstate):
    """提示词 token 摘要(右对齐置灰): 与发送组装同口径(resolve_render_request 预览档)

    超硬预算(百炼, 服务端静默截断)与超软建议(方舟, 模型可能忽略细节)的措辞区分;
    描述为空时不显示(生成/预览时自有引导); 组装失败(预算名额不足等)同样不显示.
    """
    prompt_text = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.prompt)
    if not prompt_text:
        return
    _provider, _base_url, _api_key, limits = _resolve_service(sstate, prefs)
    err, _notices, _names, _styles, full_prompt = resolve_render_request(state, scene, prompt_text, provider, limits[0], limits[1], require_captured=False)
    if err is not None:
        return
    budget, hard = prompt_token_budget(provider)
    tokens = estimate_prompt_tokens(full_prompt)
    note = col.row(align=True)
    note.alignment = 'RIGHT'
    note.enabled = False
    if budget > 0 and tokens > budget:
        if hard:
            note.label(text=iface("Prompt: about {} tokens / {} budget, it will be truncated").format(tokens, budget), icon='ERROR')
        else:
            note.label(text=iface("Prompt: about {} tokens / {} suggestion, the model may miss details").format(tokens, budget), icon='ERROR')
    elif budget > 0:
        note.label(text=iface("Prompt: about {} tokens / {} budget").format(tokens, budget), icon='INFO')
    else:
        note.label(text=iface("Prompt: about {} tokens").format(tokens), icon='INFO')


def _draw_settings_section(layout, state, sstate, prefs, provider, scene):
    """发送通道与设置两个独立小节(各占一个 box, 各自折叠, 默认都收起; **Send Passes 在上**)

    Send Passes 放发送开关与参考图预算摘要; Settings 放输出侧参数(分辨率/随机种/张数/变体)
    与风格参考图开关及引用列表. provider 为面板生效服务商(Global 档取偏好),
    由调用方解析一次后传入, 与生成操作器同源.
    """
    # ---- Send Passes 小节(在 Settings 之上, 作者定论) ----
    box = layout.box()
    header = box.row()
    header.prop(state, "use_show_send", text="", emboss=False, icon='TRIA_DOWN' if state.use_show_send else 'TRIA_RIGHT')
    header.label(text="Send Passes")
    if state.use_show_send:
        col = box.column()
        col.use_property_split = False
        _draw_send_content(col, state, scene, provider, prefs)
    else:
        # 收起态摘要: 将发送的参考图张数与预算占用(与展开层同口径), 不展开即可判断
        limit_count, limit_edge = resolve_ref_limits(provider, prefs)
        send_names, _missing, _stale = collect_send_passes(state, scene, limit_edge)
        total = len(send_names) + len(collect_style_images(state))
        note = header.row()
        note.enabled = False
        if limit_count > 0:
            note.label(text=iface("Send {} / {} reference images").format(total, limit_count), icon='INFO')
        else:
            note.label(text=iface("Send {} reference images").format(total), icon='INFO')
    # ---- Settings 小节(在 Send Passes 之下) ----
    box = layout.box()
    header = box.row()
    header.prop(state, "use_show_settings", text="", emboss=False, icon='TRIA_DOWN' if state.use_show_settings else 'TRIA_RIGHT')
    header.label(text="Settings")
    if state.use_show_settings:
        sub = box.column()
        sub.use_property_split = True
        _draw_settings_content(sub, state, sstate, prefs, provider)


def _draw_settings_content(sub, state, sstate, prefs, provider):
    """Settings 标签的内容(分辨率/随机种/张数/变体), 由 _draw_settings_section 调用"""
    # 尺寸约束取编辑模型(与生成操作器同源): 面板"实际输出"必须与真实下发值同口径
    model = resolve_edit_model(sstate, prefs)

    # 分辨率档位行: 行尾为锁定按钮(图标链扣/断链); 比率恒为相机分辨率比率,
    # 两种档位下都默认锁定(自定义档也锁定, 想改比率须先点断链解锁)
    res_row = sub.row()
    res_row.prop(state, "size_preset")
    lock_wrap = res_row.row()
    lock_wrap.alignment = 'RIGHT'
    lock_wrap.prop(state, "use_size_lock", text="", toggle=True, icon='LINKED' if state.use_size_lock else 'UNLINKED')
    # 宽高两行与实际输出标签紧凑成组(align=True); 宽高常驻显示(缩放档下置灰)
    pair = sub.column(align=True)
    editable = state.size_preset == 'CUSTOM'
    width_row = pair.row()
    width_row.enabled = editable
    width_row.prop(state, "custom_width", text="Width")
    height_row = pair.row()
    height_row.enabled = editable
    height_row.prop(state, "custom_height", text="Height")
    out_w, out_h = resolve_output_size(provider, model, state.custom_width, state.custom_height)
    note = pair.row()
    note.use_property_split = False
    note.alignment = 'RIGHT'
    note.enabled = False
    note.label(text=iface("Actual output: {} x {}").format(out_w, out_h), icon='INFO')

    # 随机种与生成张数各占一行(张数>1 逐张串行请求, 每张单独计费);
    # 种子行尾骰子按钮一键随机化(prop 先调分裂行, 按钮落值列, 与深度拾取同款机制)
    seed_row = sub.row(align=True)
    seed_row.prop(state, "seed")
    op = seed_row.operator(RandomizeSeed.bl_idname, text="", icon='FILE_REFRESH')
    op.target = 'RENDER'
    sub.prop(state, "count")
    # 批量多变体: 常驻显示, 仅张数>1 时可用(每张换宽高比变体与递增随机种, 一次产出多种构图)
    vary_row = sub.row()
    vary_row.enabled = state.count > 1
    vary_row.prop(state, "batch_variants")
    # 风格参考图(紧贴批量多变体下方): 开启后显示引用迷你列表与描述行, 随生成排在通道图之后发送
    sub.prop(state, "use_send_style")
    if state.use_send_style:
        draw_ref_image_list(sub, state, 'RENDER')



@reg_order(3)
class AiRenderPanel(Panel):
    """AI 相机效果图面板"""

    # "Render" 会命中系统词条显示成"渲染", 故用非系统原文 "Render Generator" 走插件词典出"效果图生成器"
    bl_label = "Render Generator"
    bl_idname = "VIEW3D_PT_ch_ai_render"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与 AI 纹理生成器面板共用)
    bl_category = "Image Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_render_state
        prefs = get_prefs()
        layout = self.layout

        # 图像列表(空也常驻, 行数随内容从下限到上限; 快照由 handlers 实时刷新)
        # 右侧竖列: 自动打开开关 + 上移/下移排序(两键之间紧凑) + 删除(绘制见 ui/panels/blocks)
        draw_image_list_row(layout, state, "images", "images_active_index",
                            "ch_ai_render_images", 'RENDER',
                            rows_min=_IMAGE_ROWS_MIN, rows_max=_IMAGE_ROWS)

        # 预览区(常驻): 标题行右侧为保存图像按钮, 大图预览 + 画廊开关(展开为列表内图像的图标视图)
        draw_preview_box(layout, state, iface("No render generated yet"), label_tail=_draw_preview_tail)

        # 生效服务商只解析一次(Global 档取偏好, 覆盖档取面板): 通道小节的钳制上限,
        # Settings 的实际输出与负向提示行的显隐都必须与生成操作器同源
        sstate = wm.ch_ai_render_service
        provider = prefs.image_provider if sstate.service_mode == 'GLOBAL' else sstate.service_mode

        # 生成通道小节: 紧跟预览区(预设 + 通道勾选 + 通道设置 box + 通道预览列表
        # + 捕获信息与生成通道按钮, 全部随小节折叠)
        _draw_passes(layout, state, context.scene, provider, prefs)

        # 设置与发送通道合并子面板(同一 box 内 Settings / Send Passes 两个可切换标签):
        # 位于生成通道小节之下,描述/操作行之上
        _draw_settings_section(layout, state, sstate, prefs, provider, context.scene)

        # 描述输入(长文描述块优先)与操作行: 修改效果图(高亮产物为参考图) / 生成效果图(调用 AI 服务)
        layout.separator()
        col = layout.column(align=False)
        row = col.row(align=True)
        row.prop(state, "prompt", text="Prompt")
        row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE').target = 'RENDER'
        # 负向提示: 仅支持该参数的服务商(当前为百炼)显示, 简短输入设计, 行尾清除按钮
        draw_negative_row(col, state, provider, 'RENDER')
        draw_long_desc_hint(col, AI_RENDER_PROMPT_TEXT_NAME)
        # 提示词 token 摘要(置灰): 与发送组装同口径, 超预算按软/硬措辞区分提醒
        _draw_token_summary(col, state, context.scene, provider, prefs, sstate)
        row = col.row(align=False)
        op = row.operator(EditPrompt.bl_idname, icon='TEXT')
        op.target = 'RENDER'
        # 优化提示词: 效果图面板同样直接走偏好全局文本服务(不读文本助手面板的服务覆盖)
        op = row.operator(OptimizePrompt.bl_idname, icon='SHADERFX')
        op.target = 'RENDER'
        # 最终提示词预览: 在文本编辑器查看实际发送的完整提示词(与生成请求逐字一致)
        row.operator(PreviewRenderPrompt.bl_idname, icon='WORDWRAP_ON')
        # 操作行: 修改在左(高亮效果图产物为参考图), 生成在右
        # (捕获按钮"生成通道"已移入上方同名小节)
        btn_row = col.row(align=False)
        btn_row.operator(ModifyRender.bl_idname, icon='GREASEPENCIL')
        btn_row.operator(GenerateRender.bl_idname, icon='KEY_RETURN')

        # 最近请求错误摘要(末尾异常段), 右侧清除按钮
        draw_error_box(layout, wm, 'RENDER', lines_max=_ERROR_LINES)

        # 等待进度: 面板最下方, 只显示本面板的效果图流程(生成与通道捕获共用 render 等待标志),
        # 完成后自动消失; 进度后跟终止按钮(放弃等待, 后台请求不中断)
        draw_wait_box(layout, wm.ch_ai_state, 'render')
