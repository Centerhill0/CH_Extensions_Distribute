"""
文本助手服务设置面板模块

提供以下功能:
- 文本助手 Tab 顶部的服务设置(默认折叠): 脚本生成器与对话两组的独立服务设置
- 每组: 服务模式(全局/覆盖服务商)与覆盖模型; Global 跟随偏好设置
- 覆盖时端点/密钥取对应服务商的偏好配置; 任一模式缺密钥面板内警示
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...preference import get_prefs
from ...utils.provider_registry import get_text_provider
from .blocks import draw_key_warning


def _key_attr(provider: str) -> str:
    """按文本服务商取偏好密钥字段名: 预设商查注册表, CUSTOM/未知回落通用 api_key 字段"""
    p = get_text_provider(provider)
    return p.api_key_attr if p is not None else "api_key"


def _draw_text_group(layout, state, title: str, icon: str):
    """绘制一个文本面板的服务设置组(服务商 + 覆盖模型)"""
    box = layout.box()
    box.label(text=title, icon=icon)
    col = box.column(align=False)
    col.prop(state, "service_mode", text="Provider")
    if state.service_mode == 'GLOBAL':
        draw_key_warning(col, get_prefs(), _key_attr(get_prefs().provider))
        # Global 档生效模型置灰明示(与偏好参考图限制的 Effective 行同款): 面板里看不到
        # 偏好当前配的是哪个模型, 覆盖档没有这个问题(下拉即生效值)
        note = col.row(align=True)
        note.alignment = 'RIGHT'
        note.enabled = False
        note.label(text=iface("Effective model: {}").format(get_prefs().model or "-"), icon='INFO')
    else:
        draw_key_warning(col, get_prefs(), _key_attr(state.service_mode))
        col.prop(state, "panel_model", text="Model")
    # 思考档位: 档位表按生效服务商定制(DeepSeek 三档 / GLM 开关 / 其余 low-medium-high)
    col.prop(state, "thinking", text="Thinking Level")


@reg_order(1)
class AiTextServicePanel(Panel):
    """文本助手服务设置面板"""

    bl_label = "Text Service"
    bl_idname = "VIEW3D_PT_ch_ai_text_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 文本助手选项卡(与脚本生成器/对话面板共用)
    bl_category = "Text Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        layout = self.layout
        wm = context.window_manager

        # 脚本生成器与对话各自独立的服务设置
        _draw_text_group(layout, wm.ch_ai_script_service, "Script Generator", 'CONSOLE')
        _draw_text_group(layout, wm.ch_ai_chat_service, "Chat", 'COMMUNITY')
