"""
面板共享绘制块模块(非面板)

文本助手与图像助手各面板重复使用的绘制块, 单一来源(两图像面板绘制去重的落点):
- draw_image_list_row: 图像列表行 + 右侧竖列(自动打开/排序/删除)
- draw_save_tail: 预览区缩略图右侧的保存按钮列
- draw_error_box: 最近请求错误摘要盒(ClearError 按钮)
- draw_wait_box: 等待进度盒(进度文案 + 秒数 + 中断按钮)
- draw_negative_row: 负向提示行(仅支持该参数的服务商显示)
- draw_long_desc_hint: 长文描述提示行(内容首行预览)
- draw_ref_image_list: 参考图引用迷你列表 + 加载/移除按钮 + 描述行(开关与显隐由调用方控制)
各面板只传自己的状态属性与 target, 绘制逻辑不再逐面板复制.
"""

import bpy
from bpy.types import UILayout

from .....common.i18n.i18n import iface
from ...operators.ai_generate import CancelRequest, ClearPrompt
from ...operators.ai_render import (
    _REF_TARGETS,
    ClearStyleDescription,
    LoadStyleImage,
    RemoveStyleImage,
)
from ...operators.ai_texture import SaveAllImages, SaveImage
from ...operators.list_ops import DeleteImage, MoveListItem
from ...operators.script_actions import ClearError
from ...utils.provider_registry import get_image_provider


def draw_image_list_row(layout: UILayout, state, collection: str, index_prop: str,
                        list_key: str, target: str, rows_min: int = 4, rows_max: int = 4):
    """图像列表行 + 右侧竖列(自动打开开关/上移/下移排序/删除): 纹理与效果图面板共用

    target 即 MoveListItem/DeleteImage 的目标列表('TEXTURE'/'RENDER'),
    自动打开开关为两侧共用的同一偏好(use_auto_open_images).
    """
    from ...preference import get_prefs
    items = getattr(state, collection)
    has_items = len(items) > 0
    row = layout.row(align=True)
    row.template_list("CH_UL_ai_images", list_key, state, collection, state, index_prop,
                      rows=max(rows_min, min(len(items), rows_max)))
    col = row.column(align=False)
    col.prop(get_prefs(), "use_auto_open_images", text="", icon='IMAGE_DATA', toggle=True)
    reorder = col.column(align=True)
    up_row = reorder.row(align=True)
    up_row.enabled = has_items
    op = up_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_UP')
    op.target, op.direction = target, 'UP'
    down_row = reorder.row(align=True)
    down_row.enabled = has_items
    op = down_row.operator(MoveListItem.bl_idname, text="", icon='TRIA_DOWN')
    op.target, op.direction = target, 'DOWN'
    del_row = col.row(align=True)
    del_row.enabled = has_items
    op = del_row.operator(DeleteImage.bl_idname, text="", icon='X')
    op.target = target


def draw_save_tail(tail: UILayout, state, target: str):
    """预览区缩略图右侧纵向按钮列: 保存当前高亮图像(FILE_TICK)在上, 保存全部(OUTPUT)在下

    保存操作器两面板共用, 目标列表由 target 区分; 列表为空时整列置灰.
    """
    tail.enabled = len(state.images) > 0
    tail.operator(SaveImage.bl_idname, text="", icon='FILE_TICK').target = target
    tail.operator(SaveAllImages.bl_idname, text="", icon='OUTPUT').target = target


def draw_error_box(layout: UILayout, wm, target: str, lines_max: int = 4):
    """最近请求错误摘要盒(标题 + 详情末尾几行 + 清除按钮), scope 由 target 推导

    适用于错误摘要按 last_error_<scope>/last_error_<scope>_detail 存储的面板
    (chat/texture/render); 脚本面板的运行错误字段不同, 由面板自行绘制.
    """
    ai_state = wm.ch_ai_state
    scope = target.lower()
    title = getattr(ai_state, f"last_error_{scope}")
    if not title:
        return
    box = layout.box()
    header = box.row()
    header.label(text=iface("Last error: {}").format(title), icon='ERROR')
    op = header.operator(ClearError.bl_idname, text="", icon='X')
    op.target = target
    detail = getattr(ai_state, f"last_error_{scope}_detail")
    for line in detail.strip().splitlines()[-lines_max:]:
        box.label(text=line)


def draw_wait_box(layout: UILayout, ai_state, scope: str):
    """等待进度盒: 进度文案 + 已等待秒数 + 中断按钮(scope: script/chat/texture/render)"""
    status = getattr(ai_state, f"status_{scope}")
    if not status:
        return
    box = layout.box()
    row = box.row()
    row.label(text=status, icon='TIME')
    wait = getattr(ai_state, f"wait_{scope}")
    if wait > 0:
        row.label(text=f"{wait}s")
    op = row.operator(CancelRequest.bl_idname, text="", icon='CANCEL')
    op.target = scope.upper()


def draw_negative_row(col: UILayout, state, provider: str, target: str):
    """负向提示行(仅支持该参数的服务商显示), 行尾清除按钮

    是否支持由服务商注册表能力开关(supports_negative_prompt)决定, 不硬编码服务商名.
    """
    if not get_image_provider(provider).supports_negative_prompt:
        return
    neg_row = col.row(align=True)
    neg_row.prop(state, "negative_prompt", text="Negative Prompt")
    op = neg_row.operator(ClearPrompt.bl_idname, text="", icon='CANCEL_LARGE')
    op.target, op.negative = target, True


def draw_long_desc_hint(col: UILayout, text_name: str):
    """长文描述提示行(右对齐置灰, 顺带展示内容首行): 三个生成面板共用

    长文块对用户不可见且静默优先于单行输入, 残留旧描述时看到内容即可发现
    "发的不是我输入的"; 无长文块或为空时不画.
    """
    prompt_text = bpy.data.texts.get(text_name)
    if prompt_text is None or not prompt_text.as_string().strip():
        return
    first_line = next((ln.strip() for ln in prompt_text.as_string().splitlines() if ln.strip()), "")
    if len(first_line) > 48:
        first_line = first_line[:48] + "..."
    note = col.row(align=True)
    note.alignment = 'RIGHT'
    note.enabled = False
    note.label(text=iface("Using long description: {}").format(first_line), icon='INFO')


def draw_ref_image_list(col: UILayout, state, target: str, rows_max: int = 3):
    """参考图引用迷你列表 + 加载/移除按钮 + 高亮条目描述行(调用方负责开关与显隐条件)

    纹理面板参考图(target='TEXTURE', 开关 use_ref_images 位于 Settings 的无缝贴图下方)与
    效果图风格参考图(target='RENDER', 开关 use_send_style 位于 Settings 的批量多变体下方)
    共用; 开关开启时才由调用方绘制本函数; 点击列表行按偏好聚焦图像编辑器(索引属性 update);
    引用集合存于 WM, 变动经 handlers.dump_image_refs 持久化.
    """
    # 集合/索引属性名取自 operators.ai_render 的 _REF_TARGETS(单一来源):
    # (状态组属性名, 集合属性名, 索引属性名), 此处只用后两项
    _wm_attr, collection, index_prop = _REF_TARGETS[target]
    items = getattr(state, collection)
    # 独立关闭属性分栏: 列表与描述行按值列排版, 不受父级 property_split 影响
    wrap = col.column()
    wrap.use_property_split = False
    row = wrap.row(align=True)
    row.template_list("CH_UL_ai_style_refs", f"ch_ai_refs_{target.lower()}",
                      state, collection, state, index_prop,
                      rows=max(1, min(len(items), rows_max)))
    btns = row.column(align=True)
    load_op = btns.operator(LoadStyleImage.bl_idname, text="", icon='ADD')
    load_op.target = target
    remove_op = btns.operator(RemoveStyleImage.bl_idname, text="", icon='REMOVE')
    remove_op.target = target
    # 描述行: 高亮条目存在且图像在位时显示(拼进提示词的职责声明), 行尾清除按钮
    index = getattr(state, index_prop)
    if 0 <= index < len(items):
        active = items[index]
        if active.image is not None:
            desc_row = wrap.row(align=True)
            desc_row.prop(active, "description", text="Description")
            clear_op = desc_row.operator(ClearStyleDescription.bl_idname, text="", icon='CANCEL_LARGE')
            clear_op.target = target


def draw_key_warning(col: UILayout, prefs, key_attr: str):
    """该服务商密钥未配置时在面板内警示(右对齐置灰)

    文本与图像服务设置面板共用; key_attr 为偏好上的密钥字段名(由调用方按服务商映射),
    为空(未知服务商无对应密钥字段)时跳过.
    """
    if key_attr and not getattr(prefs, key_attr):
        row = col.row(align=True)
        row.alignment = 'RIGHT'
        row.enabled = False
        row.label(text="No API key for this service in the preferences", icon='ERROR')
