# 服务商扩展 Checklist

> 本文档是「新增 / 修改一个模型服务商」的**防遗漏底稿**。
> 记录了当前 `ch_ai_assistant` 中「服务商相关的全部参数、限制与行为差异」。
> 新增服务商时，请逐项核对下表，确保每一处都同步更新——漏任何一处，都会造成
> 「该服务商在偏好里可选，但某个参数 / 限制 / 行为错乱」的隐性 bug。

## 适用范围

- **图像服务商**：火山方舟（Volcengine Ark）、阿里百炼（Alibaba DashScope）、自定义（Custom）
- **文本服务商**：DeepSeek、智谱 GLM、自定义（Custom）

---

> **现状说明（2026-10-12 起，服务商知识已注册表化）**：下述一、二部分的「参数 / 说明 / 坑」
> 是**全量差异清单**（语义不变，仍是加商时的防遗漏依据）；但「当前位置」列是**注册表化之前**的
> 历史散落位置，现已全部收口到 `utils/provider_registry.py` 的 dataclass 字段。
> **表中所列 `REF_IMAGE_LIMITS` / `PROMPT_TOKEN_BUDGETS` / `OUTPUT_LIMITS` /
> `_DEFAULT_REF_LIMITS` / `_KEY_ATTRS` 等常量名在现行代码中已不存在**，仅为标注历史落点，
> 请勿按名查找。现行字段 ↔ 旧位置的逐项映射见
> [`provider-registry-design.md` §4](provider-registry-design.md)。
> 实际加商步骤见下方**第三部分**（只需改 2 处）。

---

## 一、图像服务商 —— 全量差异清单

### 1. 接入层（端点 / 密钥 / 模型）

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 1.1 | 端点 base_url | `utils/image_client.py` · `PROVIDER_ENDPOINTS` | 预设商固定端点，CUSTOM 走偏好输入 |
| 1.2 | 密钥属性名 | `utils/image_client.py` · `resolve_image_endpoint` | ~~if 链取 `volcengine_api_key` / `dashscope_api_key` / 通用~~ 已查表化：`get_image_provider(...).api_key_attr` |
| 1.3 | 默认模型（文生图） | `utils/image_client.py` · `PROVIDER_DEFAULT_MODELS` | 轻量档 |
| 1.4 | 默认模型（图生图/编辑） | 同上 | 当前与文生图同值，但**字段分离** |
| 1.5 | 候选模型表 | `items.py` · `PROVIDER_MODEL_ITEMS` | 含 `volcengine_t2i_items` / `dashscope_t2i_items` |
| 1.6 | 枚举档显示名 / 描述 | `items.py` · `image_provider_items` | 偏好下拉 + 面板覆盖下拉共用 |

### 2. 请求体构造（`request_image`）

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 2.1 | 请求 URL 路径后缀 | `utils/image_client.py` · `request_image` | 百炼 `/services/aigc/multimodal-generation/generation`，其余 `/images/generations` |
| 2.2 | 请求体构造 | `_dashscope_payload` / `_volcengine_payload` | 两家结构不同 |
| 2.3 | `response_format`（b64） | 同上 | 方舟 / 自定义有，百炼无 |
| 2.4 | `watermark` | 同上 | 方舟 / 百炼有（False），**CUSTOM 显式剔除** |
| 2.5 | `seed` | 同上 | 方舟 / 百炼有，**CUSTOM 显式剔除** |
| 2.6 | `negative_prompt` | `_dashscope_payload` | 仅百炼下发，其余**不下发**（非传空串） |
| 2.7 | 响应解析路径 | `_extract_dashscope_image` / `_extract_item_image` | 百炼 content 结构 vs OpenAI images 结构 |
| 2.8 | 图片下载 | 同上 | 百炼只回 URL（24h 有效，须下载）；方舟 b64 |

> ⚠️ **关键坑 1**：CUSTOM 不是「多传参数」，而是「**少传** `response_format` / `watermark` / `seed`」。
> 新增商时若只按「正向下发」设计，会漏掉这个「负向剔除」。

### 3. 输出尺寸约束（`resolve_output_size`）

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 3.1 | 尺寸修正算法 | `_resolve_seedream_size` / `_resolve_qwen_size` | CUSTOM 原样下发 |
| 3.2 | 单边 min / max | `_SEEDREAM_DIM_*` / `_QWEN_DIM_*` | |
| 3.3 | 总像素 min / max | `_seedream_total_range` | **模型级**细分（4.0 / 4.5 / 5.0-lite / 5.0-pro 各不同） |
| 3.4 | 宽高比上限 | `_SEEDREAM_ASPECT_MAX` / `_QWEN_ASPECT_MAX` | |
| 3.5 | 取偶 / 对齐 | 各 `_resolve_*_size` | Seedream 取偶、Qwen 对齐 16 倍数 |
| 3.6 | 固定档回落 | `_QWEN_PRESETS` | qwen-image-max/plus 仅 5 档 |
| 3.7 | `format_size` 分隔符 | `format_size` | 百炼 `*`，其余 `x` |

> ⚠️ **关键坑 2**：总像素是**模型级**差异（不只是服务商级）。注册表若只到「服务商」粒度，
> 必须把 `resolve_size` 保留为**函数回调**，否则丢失 Seedream 各档的细分。

### 4. 参考图限制

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 4.1 | 参考图张数上限 | `REF_IMAGE_LIMITS` | 方舟 14 / 百炼 3 / CUSTOM 0（不限） |
| 4.2 | 参考图最长边 | 同上 | 6000 / 3072 / 0 |
| 4.3 | 未知商兜底 | `_DEFAULT_REF_LIMITS` | (0, 0) 不臆断 |
| 4.4 | 偏好自定义「逐字段覆盖」 | `ref_image_limits` | 0 = 跟随官方上限 |

### 5. 提示词预算

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 5.1 | token 预算上限 | `PROMPT_TOKEN_BUDGETS` | 方舟 600 / 百炼 800 / CUSTOM 0 |
| 5.2 | 是否硬截断 | 同上 | 百炼硬截断（自动降精简档） |

### 6. 偏好面板联动（`preference.py`）

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 6.1 | 预设回填 | `_IMAGE_PRESETS` | 端点 + 文生图 / 图生图模型 |
| 6.2 | 密钥显示分支 | `draw` | ~~`key_attr = "volcengine_api_key" if ... else ...`~~ 已查表化：`get_image_provider(...).api_key_attr` |
| 6.3 | 切换商清零参考图限制 | `_apply_image_preset` | `image_ref_count/edge = 0` |
| 6.4 | 输出限制提醒文案 | `draw` · `output_limits(...)` | |
| 6.5 | 参考图生效值提示 | `draw` · `ref_image_limits(...)` | |

### 7. 面板覆盖层（`props.py` + 操作器）

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 7.1 | 覆盖模型下拉候选 | `props.py` · `_panel_t2i_model_items` / `_panel_edit_model_items` | `PROVIDER_MODEL_ITEMS.get(service_mode)` |
| 7.2 | 覆盖模型复位 | `props.py` · `_reset_image_panel_models` | 切服务商复位表首项 |
| 7.3 | 生效模型兜底链 | `ai_texture.py` · `resolve_texture_model` / `resolve_edit_model` | `PROVIDER_DEFAULT_MODELS.get(...)` |

### 8. 负向提示词支持（散落在操作器）

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| 8.1 | 是否下发 negative_prompt | `ai_texture.py`（生成+修改）、`ai_render.py`（生成+修改）、`ui/panels/blocks.py` 共 **5 处** | ~~硬编码 `provider == 'DASHSCOPE'`~~ 已查表化：`get_image_provider(provider).supports_negative_prompt` |

> ⚠️ **关键坑 3（已解决）**：负向提示「是否支持」原散在 4 个操作器 + 1 处 UI 里硬编码
> `provider == 'DASHSCOPE'`，新增商时易漏改。注册表化后统一为能力开关
> `supports_negative_prompt`（含 UI 层 blocks.py 一处此前漏改，已收口），新商只需在
> `ImageProvider` 记录里填 `supports_negative_prompt=True/False`，不再有 4 处分支。

---

## 二、文本服务商 —— 全量差异清单

| # | 参数 | 当前位置 | 说明 |
| --- | --- | --- | --- |
| T1 | 端点 | `utils/ai_client.py` · `CHAT_PROVIDER_ENDPOINTS` | |
| T2 | 密钥属性名 | `resolve_chat_endpoint` | ~~if 链~~ 已查表化：`get_text_provider(...).api_key_attr` |
| T3 | 默认模型 | `CHAT_PROVIDER_DEFAULT_MODELS` | 轻量档 |
| T4 | 候选模型表 | `items.py` · `TEXT_PROVIDER_MODEL_ITEMS` | |
| T5 | 思考档位表 | `props.py` · `_thinking_items_for` | DeepSeek 4 档 / GLM 3 档 / 通用 3 档 |
| T6 | 思考参数组装 | `ai_client.py` · `build_thinking_extras` | GLM 恒 enabled / DeepSeek off→disabled / 通用 reasoning_effort |
| T7 | 脚本输出额度策略 | `ai_generate.py` · `_script_max_tokens` | DeepSeek None / GLM 65536 / 其余 8192 |
| T8 | 测试策略 | `service_test.py` · `_text_test_worker` | DeepSeek 查余额 / 其余 ping |
| T9 | 偏好预设 | `preference.py` · `_PRESETS` | 端点 + 默认模型 |
| T10 | 模型下拉候选 | `preference.py` · `_text_model_choice_items_fn` | |

> ⚠️ **关键坑 4（已解决）**：`_thinking_items_for`（T5）与 `build_thinking_extras`（T6）原各自维护
> 「DeepSeek / GLM / 通用」的分支，且**档位标识必须一致**（`thinking` 值既是档位表标识、
> 又是 `reasoning_effort` 参数值）。注册表化后已合并为 `TextProvider.thinking_items` +
> `build_thinking_extras` 单字段对（档位标识由 `thinking_items` 统一定义），
> `props._thinking_items_for` 与 `ai_client.build_thinking_extras` 均退化为薄委托，不再漂移。

---

## 三、新增服务商的完整操作步骤（已注册表化，2026-10-12 起）

> 服务商知识已收敛到 `utils/provider_registry.py`（见 provider-registry-design.md）。
> 现在**加一个服务商只需改 2 处**（都在 provider_registry.py），其余代码自动生效：

### 新增图像服务商 X

1. `utils/provider_registry.py`：
   - 加一组 `*_items` 枚举字面量（`x_provider_item` + `x_t2i_items`，**保持 List 字面量形态供 i18n 提取**）
   - 加一条 `ImageProvider(...)` 记录到 `IMAGE_PROVIDERS`，引用上述字面量，
     填好 base_url / api_key_attr / default_model_* / ref_* / token_* / resolve_size /
     size_sep / output_limits / endpoint_path / build_payload / parse_response / supports_*
2. 若 `api_key_attr` 指向新密钥字段：在 `preference.py` 加对应 `StringProperty(subtype='PASSWORD')`

### 新增文本服务商 X

1. `utils/provider_registry.py`：
   - 加一组 `*_items` 枚举字面量（枚举档 + 候选模型 + 思考档，均 List 字面量）
   - 加一条 `TextProvider(...)` 记录到 `TEXT_PROVIDERS`，引用上述字面量，
     填好 base_url / api_key_attr / default_model / build_thinking_extras / script_max_tokens / test_strategy
2. 若 `api_key_attr` 指向新密钥字段：在 `preference.py` 加对应 `StringProperty(subtype='PASSWORD')`

> 以下为**重构前的历史步骤**（保留备查，不再适用）：

<details>
<summary>历史步骤（注册表化之前）</summary>

### 新增图像服务商 X（旧）

1. `items.py`：`image_provider_items` 加枚举档；`PROVIDER_MODEL_ITEMS` 加 `X 的候选模型表`
2. `utils/image_client.py`：
   - `PROVIDER_ENDPOINTS`、`PROVIDER_DEFAULT_MODELS` 加 X
   - `REF_IMAGE_LIMITS`、`PROMPT_TOKEN_BUDGETS`、`OUTPUT_LIMITS` 加 X
   - 新增 `_resolve_x_size` 并接入 `resolve_output_size` 的 if 分支
   - 新增 `_x_payload` 并接入 `request_image` 的 URL / payload / 解析分支
3. `preference.py`：`_IMAGE_PRESETS` 加 X；`draw` 加 `key_attr` 分支；`resolve_image_endpoint` 加 if 分支
4. `props.py`：无（覆盖层通过 `PROVIDER_MODEL_ITEMS` 自动生效）
5. 若支持负向提示：4 处操作器里的 `provider == 'DASHSCOPE'` 改为支持集合判断

### 新增文本服务商 X（旧）

1. `items.py`：`TEXT_PROVIDER_MODEL_ITEMS` 加 X 候选表；`provider_items` 加枚举档（如需要）
2. `utils/ai_client.py`：`CHAT_PROVIDER_ENDPOINTS`、`CHAT_PROVIDER_DEFAULT_MODELS` 加 X；
   `build_thinking_extras` 加 if 分支；`resolve_chat_endpoint` 加 if 分支
3. `preference.py`：`_PRESETS` 加 X；`draw` 加 `key_attr` 分支
4. `props.py`：`_thinking_items_for` 加 X 档位表
5. `ai_generate.py`：`_script_max_tokens` 加 X 额度策略
6. `service_test.py`：`_text_test_worker` 加 X 测试策略分支

</details>
