"""
快捷键管理模块

提供以下功能:
- 定义插件的快捷键配置
- 注册和注销快捷键映射

快捷键分组:

独立Ops
- CODE_EXECUTE: 代码执行操作 (Ctrl + F3)
- SWITCH_LANGUAGE: 语言切换 (Button 5)

- SYMMETRIZE: 对称操作 (Alt + X)
- MATERIAL_PICKER: 材质拾取和分配操作 (物体模式与网格编辑模式 Alt + Shift + E)

饼菜单
- MODES_PIE: 模式切换饼菜单 (Tab)
- EDIT_PIE: 物体编辑模式饼菜单 (Shift + Q)
- SELECT_PIE: 选择饼菜单 (Ctrl + W)
- OVERLAYS_PIE: 叠加层显示饼菜单 (Ctrl + Alt + Z)
- DELETE_PIE: 删除饼菜单 (X)
- CLEAN_UP_PIE: 清理饼菜单 (Shift + X)
- ALIGN_PIE: 对齐饼菜单 (Ctrl + Alt + A)
- ADD_MODIFIER_PIE: 修改器饼菜单 (Alt + K)
- CURSOR_AND_ORIGIN_PIE: 游标和原点饼菜单 (Shift + S)
- TEMP_EDITOR_PIE: 临时编辑器饼菜单 (\\)


其它功能扩展:(无需注册)
- ShadingExpandPie (Z)
- ExtrudeMenuExpand (网格编辑模式Alt + E)
    - Hole Extrude
    - Wedge Extrude
"""

from typing import Dict, List, Tuple, Any

from bpy.types import KeyMap, KeyMapItem

from ...common.blender.keymaps import register_keymap_table, unregister_keymap_storage

# ============================================================
# 快捷键配置数据
# ============================================================
# 分组显示名(偏好设置快捷键列表用): 由组键生成的名称("Code execute")是运行时字符串,
# 无法入典, 故在此显式声明; 饼菜单组须保留 "Pie" 结尾(偏好设置按此分列)
group_labels: Dict[str, str] = {
    'CODE_EXECUTE': "Code Execute",
    'SWITCH_LANGUAGE': "Switch Language",
    'SYMMETRIZE': "Symmetrize",
    'MATERIAL_PICKER': "Material Picker",
    'MODES_PIE': "Modes Pie",
    'EDIT_PIE': "Edit Pie",
    'SELECT_PIE': "Select Pie",
    'OVERLAYS_PIE': "Overlays Pie",
    'DELETE_PIE': "Delete Pie",
    'CLEAN_UP_PIE': "Clean Up Pie",
    'ALIGN_PIE': "Align Pie",
    'ADD_MODIFIER_PIE': "Add Modifier Pie",
    'CURSOR_AND_ORIGIN_PIE': "Cursor And Origin Pie",
    'TEMP_EDITOR_PIE': "Temp Editor Pie",
}

keymap_items: Dict[str, List[Dict[str, Any]]] = {
    # 代码执行 (Ctrl + F3)
    'CODE_EXECUTE': [
        {'label': 'Window', 'keymaps_name': 'Window', 'id_name': "ch.code_execute", 'type': 'F3', 'value': 'PRESS', 'ctrl': True},
    ],
    # 语言切换 (鼠标侧键5)
    'SWITCH_LANGUAGE': [
        {'label': 'Window', 'keymaps_name': 'Window', 'id_name': "ch.switch_language", 'type': 'BUTTON5MOUSE', 'value': 'PRESS'},
    ],
    # 对称操作 (Alt + X)
    'SYMMETRIZE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'ch.object_symmetrize', 'type': 'X', 'value': 'PRESS', 'alt': True},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'ch.editmesh_symmetrize', 'type': 'X', 'value': 'PRESS', 'alt': True},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'ch.editcurve_symmetrize', 'type': 'X', 'value': 'PRESS', 'alt': True},
    ],
    # 材质拾取和分配操作 (Alt + Shift + E)
    'MATERIAL_PICKER': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'ch.material_picker', 'type': 'E', 'value': 'PRESS', 'alt': True, 'shift': True},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'ch.material_picker', 'type': 'E', 'value': 'PRESS', 'alt': True, 'shift': True},
    ],
    # 模式切换饼菜单 (Tab)
    'MODES_PIE': [
        {'label': '3D View', 'keymaps_name': 'Object Non-modal', 'id_name': 'ch.modes_toggle', 'type': 'TAB', 'value': 'PRESS'},
        {'label': 'Image & UV Editor', 'keymaps_name': 'Image', 'space_type': 'IMAGE_EDITOR', 'id_name': 'wm.call_menu_pie', 'type': 'TAB', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_imageuv_modes_switch_pie"}},
    ],
    # 编辑模式饼菜单 (Shift + Q)
    'EDIT_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_object_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editcurve_pie"}},
        {'label': 'Edit_Armature', 'keymaps_name': 'Armature', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editarmature_pie"}},
        {'label': 'Pose', 'keymaps_name': 'Pose', 'id_name': 'wm.call_menu_pie', 'type': 'Q', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_pose_pie"}},
    ],
    # 选择饼菜单 (Ctrl + W)
    'SELECT_PIE': [
        {'label': 'Select Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_object_select_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_select_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_editcurve_select_pie"}},
        {'label': 'Edit_Armature', 'keymaps_name': 'Armature', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_editarmature_select_pie"}},
        {'label': 'Pose', 'keymaps_name': 'Pose', 'id_name': 'wm.call_menu_pie', 'type': 'W', 'value': 'PRESS', 'ctrl': True, 'properties': {'name': "VIEW3D_MT_ch_pose_select_pie"}},
    ],
    # 覆盖显示饼菜单 (Ctrl + Alt + Z)
    'OVERLAYS_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_object_overlays_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_overlays_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_editcurve_overlays_pie"}},
        {'label': 'Edit_Armature', 'keymaps_name': 'Armature', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_armature_overlays_pie"}},
        {'label': 'Pose', 'keymaps_name': 'Pose', 'id_name': 'wm.call_menu_pie', 'type': 'Z', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_armature_overlays_pie"}},
    ],
    # 删除饼菜单 (X)
    'DELETE_PIE': [
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_editmesh_delete_pie"}},
        {'label': 'Edit_Curve', 'keymaps_name': 'Curve', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_editcurve_delete_pie"}},
    ],
    # 清理饼菜单 (Shift + X)
    'CLEAN_UP_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_object_cleanup_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'X', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_cleanup_pie"}},
    ],
    # 对齐饼菜单 (Ctrl + Alt + A)
    'ALIGN_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'A', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_object_align_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'A', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_editmesh_align_pie"}},
        {'label': 'Node', 'keymaps_name': 'Node Editor', 'space_type': 'NODE_EDITOR', 'id_name': 'wm.call_menu_pie', 'type': 'A', 'value': 'PRESS', 'ctrl': True, 'alt': True, 'properties': {'name': "NODE_MT_ch_node_align_pie"}},
    ],
    # 相机辅助饼菜单 (Alt + C) 与灯光饼菜单 (Alt + L) 已迁至 ch_scene_helper 插件
    # 添加修改器饼菜单 (Alt + K)
    'ADD_MODIFIER_PIE': [
        {'label': 'Object', 'keymaps_name': 'Object Mode', 'id_name': 'wm.call_menu_pie', 'type': 'K', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_add_modifier_pie"}},
        {'label': 'Edit_Mesh', 'keymaps_name': 'Mesh', 'id_name': 'wm.call_menu_pie', 'type': 'K', 'value': 'PRESS', 'alt': True, 'properties': {'name': "VIEW3D_MT_ch_add_modifier_pie"}},
    ],
    # 游标和原点饼菜单 (Shift + S)
    'CURSOR_AND_ORIGIN_PIE': [
        {'label': '3D View', 'keymaps_name': '3D View', 'space_type': 'VIEW_3D', 'id_name': 'wm.call_menu_pie', 'type': 'S', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_cursor_and_origin_pie"}},
        {'label': 'Edit_Grease_Pencil', 'keymaps_name': 'Grease Pencil Edit Mode', 'id_name': 'wm.call_menu_pie', 'type': 'S', 'value': 'PRESS', 'shift': True, 'properties': {'name': "VIEW3D_MT_ch_cursor_and_origin_pie"}},
    ],
    # 临时编辑器饼菜单 (Back Slash)
    'TEMP_EDITOR_PIE': [
        {'label': 'Window', 'keymaps_name': 'Window', 'space_type': 'EMPTY', 'id_name': 'wm.call_menu_pie', 'type': 'BACK_SLASH', 'value': 'PRESS', 'properties': {'name': "VIEW3D_MT_ch_open_temp_editor_pie"}},
    ],
}

# 已注册的快捷键存储字典(注册引擎写入, 偏好"快捷键"页读取)
# 格式: {分组名: [(显示标签, KeyMap, KeyMapItem), ...]}
addon_keymaps: Dict[str, List[Tuple[str, KeyMap, KeyMapItem]]] = {}


# ============================================================
# 快捷键注册/注销函数(引擎在 common/blender/keymaps.py, 表数据是插件资产留在本文件)
# ============================================================


def register_keymaps() -> None:
    """
    注册插件的快捷键

    遍历 keymap_items 配置,为每个条目创建键映射和键映射项,
    并存储到 addon_keymaps 字典中以便后续注销.

    幂等: 入口先清掉上一代条目. addon_keymaps 按分组名覆盖写入,
    若不清上一代, 旧 KeyMapItem 会失去句柄但仍在 keyconfigs.addon 中继续生效,
    造成同一快捷键触发多次且再也无法注销.
    """
    unregister_keymaps()
    register_keymap_table(keymap_items, group_labels, addon_keymaps)


def unregister_keymaps() -> None:
    """
    注销插件的快捷键: 移除 addon_keymaps 内全部键映射项并清空存储字典
    (失效句柄容错与 finally 清空的必要性见 common 键位引擎 docstring)
    """
    unregister_keymap_storage(addon_keymaps)
