"""
脚本列表模块

文本助手选项卡下脚本生成器的 UIList(类名含 _UL_ 标记: Blender 注册约定, 类名即
template_list 的查找 id).内建名称过滤与排序控件行(标准过滤行为见 common.ui.list_snapshot);
行内名称以无浮雕文本绘制, 双击可编辑并写穿到文本数据块.
"""

from bpy.types import Context, UIList, UILayout

from .....common.ui.list_snapshot import ListItem, StandardFilterMixin


class CH_AI_UL_scripts(StandardFilterMixin, UIList):
    """脚本列表"""

    def draw_item(self, context: Context, layout: UILayout, data, item: ListItem, icon: str, active_data, active_propname: str, idx: int):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="", emboss=False, icon='TEXT')
        else:  # GRID: 图标视图下只画一个占位图标(名称在缩略图标签里)
            layout.alignment = 'CENTER'
            layout.label(text="", icon='TEXT')
