"""
AI 图像请求共享基础设施

纹理生成(ai_texture)与效果图生成(ai_render)两条操作链共用的中立工具:
图像服务解析,参考图收集,批量请求规格表,后台线程入口,备份清理等.

单列一个模块是为了消除效果图侧反向导入纹理模块私有符号的依赖倒置
(原 ai_render 从 ai_texture import _batch_request_specs / _prune_image_backups 等);
本模块不定义任何操作器, 操作器分别留在各自的业务模块.
"""

import random
from typing import NamedTuple

import bpy
from bpy.types import Context

from ....common.i18n.i18n import report
from ..preference import get_prefs
from ..utils import (
    api_error,
    describe_error,
    format_size,
    request_image,
    resolve_image_endpoint,
    resolve_output_size,
)
from ..utils.image_client import resolve_panel_image_model
from ..utils.provider_registry import effective_provider, get_image_provider
from .ai_generate import clear_request_error, record_request_error

# ---- 图像列表目标解析(参考图维护 / 保存 / 删除算子共用的单一映射) ----
# target -> (状态组属性名, 集合属性名, 索引属性名); 参考图列表与主图像列表是两组不同集合,
# 故 TEXTURE 键在两表中分别指向 ref_images 与 images.
REF_TARGET_STATES = {
    'TEXTURE': ("ch_ai_texture_state", "ref_images", "ref_images_active_index"),
    'RENDER': ("ch_ai_render_state", "style_images", "style_images_active_index"),
}
_IMAGE_LIST_STATES = {
    'TEXTURE': ("ch_ai_texture_state", "images", "images_active_index"),
    'RENDER': ("ch_ai_render_state", "images", "images_active_index"),
    'PASS': ("ch_ai_render_state", "pass_images", "pass_images_active_index"),
}


def _resolve_target_state(context, target: str, table: dict) -> tuple:
    wm_attr, coll_attr, index_attr = table[target]
    return getattr(context.window_manager, wm_attr), coll_attr, index_attr


def resolve_ref_state(context, target: str) -> tuple:
    """按 target 取参考图引用的 (状态组, 集合属性名, 索引属性名)(纹理参考图 / 效果图风格图)"""
    return _resolve_target_state(context, target, REF_TARGET_STATES)


def resolve_image_list_state(context, target: str) -> tuple:
    """按 target 取图像列表的 (状态组, 集合属性名, 索引属性名)(纹理/效果图主列表 + 通道预览)"""
    return _resolve_target_state(context, target, _IMAGE_LIST_STATES)


def any_ref_highlighted(context) -> bool:
    """任一参考图列表有高亮条目(参考图清除/移除按钮的可用性条件, 两处 poll 共用)"""
    for wm_attr, coll_attr, index_attr in REF_TARGET_STATES.values():
        state = getattr(context.window_manager, wm_attr)
        if 0 <= getattr(state, index_attr) < len(getattr(state, coll_attr)):
            return True
    return False


def resolve_image_service(state, prefs) -> tuple:
    """按共享服务设置解析生效图像服务, 返回 (服务商, base_url, api_key)

    state 为图像助手的共享服务设置(AiImageServiceState); Global 跟随偏好服务商,
    覆盖模式端点/密钥取对应服务商的偏好配置.
    """
    provider = effective_provider(state, prefs, 'image')
    base_url, api_key = resolve_image_endpoint(provider, prefs)
    return provider, base_url, api_key


def resolve_edit_model(state, prefs) -> str:
    """解析生效编辑模型(薄封装, 兜底链单一来源见 utils.resolve_panel_image_model)

    仅供**效果图面板侧**使用(其面板下拉绑定 panel_edit_model, UI 可见); 纹理面板侧一律用
    resolve_texture_model(留在 ai_texture)——纹理组的可见下拉绑定 panel_t2i_model, 本函数读的
    panel_edit_model 在纹理侧无 UI 入口(切服务商时被复位值填充, 读了会静默顶掉
    用户的可见选择).
    """
    return resolve_panel_image_model(state, prefs, "panel_edit_model", "image_model_edit")


def check_image_service(op, state=None) -> bool:
    """校验生效图像服务已配置(地址与密钥), 未配置时经 op 上报并返回 False

    state 非空时按共享服务设置(含覆盖)检查, 为空时按偏好全局配置检查.
    """
    prefs = get_prefs()
    if state is None:
        provider, base_url, api_key = (prefs.image_provider,) + resolve_image_endpoint(prefs.image_provider, prefs)
    else:
        provider, base_url, api_key = resolve_image_service(state, prefs)
    if not base_url or not api_key:
        op.report({'WARNING'}, "Set the API key of the selected image service in addon preferences first")
        return False
    return True


class ImageRequestArgs(NamedTuple):
    """图像请求后台线程参数快照(主线程组装, RNA 属性不支持跨线程读取)

    按名访问, 消除调用方对元组位置的隐式依赖(service_test 曾用索引解包跳过中间字段).
    """
    base_url: str
    api_key: str
    timeout: int | None
    provider: str


def snapshot_image_prefs() -> ImageRequestArgs:
    """主线程按全局默认服务商快照图像服务配置为命名元组, 供后台线程使用"""
    prefs = get_prefs()
    base_url, api_key = resolve_image_endpoint(prefs.image_provider, prefs)
    return ImageRequestArgs(base_url, api_key, prefs.image_timeout or None, prefs.image_provider)


# 批量多变体的宽高比变体系数(第 0 张保持基础比率, 其后按序轮转换构图)
_VARIANT_FACTORS = (1.0, 1.5, 2.0 / 3.0, 4.0 / 3.0, 0.75)


def effective_seed(state, provider: str) -> int:
    """取生效随机种: 0(每次随机)时本地抽取实际种子并**回填面板**——服务端随机时客户端
    拿不到种子, 满意结果无法复现; 回填后"再点一次 = 复现", 骰子按钮继续当重新随机
    (纹理与效果图两个面板共用, 生成/修改请求统一走此入口).

    不支持 seed 的服务商(如方舟 Seedream: 官方参数表无该字段, 实测同种子两次结果不同)
    不做"抽取并回填"——回填的唯一目的是复现, 服务端不认种子时属误导; 直接回传面板值
    (其种子行本就不绘制, 值恒为 0).
    """
    if not get_image_provider(provider).supports_seed:
        return state.seed
    if state.seed:
        return state.seed
    state.seed = random.randint(1, 2147483647)
    return state.seed


def effective_negative_prompt(state, provider: str) -> str:
    """生效负向提示: 仅 supports_negative_prompt 的服务商下发(如百炼 Qwen-Image), 其余返回空串"""
    if not get_image_provider(provider).supports_negative_prompt:
        return ""
    return state.negative_prompt.strip()


def resolve_and_notify_size(op, provider: str, model: str, width: int, height: int) -> tuple:
    """按服务商/模型约束修正输出尺寸; 被修正时经 op 上报 INFO, 返回修正后尺寸

    纹理生成与效果图生成的共用入口(自定义分辨率按服务商/模型支持区间修正,
    CUSTOM 原样下发由服务端裁决); 修改效果图取源图尺寸, 不走此函数.
    """
    out_w, out_h = resolve_output_size(provider, model, width, height)
    if (out_w, out_h) != (width, height):
        op.report({'INFO'}, report("Resolution adjusted to {} x {} for the provider limits").format(out_w, out_h))
    return out_w, out_h


def collect_ref_entries(state, toggle_attr: str, collection_attr: str) -> list:
    """收集生效的参考图**引用条目**(生成/预览共用, 单一口径; 纹理参考图与效果图风格图共用)

    toggle_attr 对应的开关关闭时不发送; 引用悬空或像素未加载的条目剔除.
    返回条目而非数据块: 条目上带用户输入的描述(组装进提示词职责声明).
    """
    if not getattr(state, toggle_attr):
        return []
    return [ref for ref in getattr(state, collection_attr)
            if ref.image is not None and ref.image.size[0] > 0]


def count_unavailable_refs(state, collection_attr: str) -> int:
    """参考图引用中不可用的条数(引用悬空或像素未加载, 与 collect_ref_entries 同口径)"""
    return sum(1 for ref in getattr(state, collection_attr)
               if ref.image is None or ref.image.size[0] <= 0)


def batch_request_specs(provider, model, width, height, count, seed, variants) -> list:
    """按张数展开逐张请求的规格表 [(尺寸串, 种子), ...]

    variants 且张数>1 时每张换一个宽高比变体(总像素不变, 比率乘轮转系数后
    仍经服务商/模型约束修正); 种子从基准逐张递增(避免重图), 首张用基准本身——
    基准由 effective_seed 落地(0 已本地抽取回填), 支持 seed 的服务商每张请求均可经面板
    种子复现; 不支持者(方舟)种子位不下发, 变体只剩比率(见 provider_registry.supports_seed).
    """
    total = max(1, width * height)
    specs = []
    for idx in range(count):
        if variants and idx:
            factor = _VARIANT_FACTORS[idx % len(_VARIANT_FACTORS)]
            aspect = width / max(1, height) * factor
            vw, vh = resolve_output_size(provider, model,
                                         max(2, round((total * aspect) ** 0.5)),
                                         max(2, round((total / max(aspect, 1e-9)) ** 0.5)))
        else:
            vw, vh = width, height
        spec_seed = (seed + idx) % 2147483647 if idx else seed
        specs.append((format_size(provider, vw, vh), spec_seed))
    return specs


def prune_image_backups(op, base_name: str, keep_name: str):
    """按偏好上限清理同源图像的旧 "_bak" 备份(数据块级删除, 已存盘文件不受影响)

    base_name 为原图名(未加后缀), keep_name 为刚生成的最新备份名(必保留);
    其余备份按编号后缀从旧到新移除, 只保留偏好份数(上限 - 1)份.
    """
    limit = max(0, get_prefs().image_backup_limit - 1)
    prefix = f"{base_name}_bak"
    backups = [img for img in bpy.data.images
               if (img.name == prefix or img.name.startswith(prefix + ".")) and img.name != keep_name]
    excess = len(backups) - limit
    if excess <= 0:
        return

    def _suffix_num(name: str) -> int:
        tail = name[len(prefix):]
        return int(tail[1:]) if tail.startswith(".") and tail[1:].isdigit() else 0

    for img in sorted(backups, key=lambda img: _suffix_num(img.name))[:excess]:
        op.report({'INFO'}, report("Old backup '{}' removed").format(img.name))
        bpy.data.images.remove(img)


def batch_image_worker(op, request_args: ImageRequestArgs, model, prompt, specs, negative_prompt, ref_images=None):
    """批量图像请求后台线程入口(op 模拟 self): 按规格表逐张串行请求并把结果列表写入 op._result

    request_args 是主线程快照的偏好值命名元组(RNA 属性不支持跨线程读取);
    specs 为逐张 (尺寸串, 种子) 规格表, 中途失败即停止, op._result 固定为
    (成功图片字节列表, 首个错误或 None);
    ref_images 为参考图字节列表(参考图生图/效果图参考图路径, 文生图为 None);
    批量时另写 op._batch_total 供 _on_response 组装"已成功 i/n 张"文案.
    """
    try:
        results = []
        err = None
        total = len(specs)
        base_text = op.status_text
        for idx, (size, seed) in enumerate(specs, 1):
            # 批量进度文案(worker 线程写普通属性, modal 主线程每拍回写面板状态)
            op._progress_text = f"{base_text} [{idx}/{total}]" if total > 1 else None
            image_bytes, err = request_image(
                request_args.base_url, request_args.api_key, model, prompt,
                request_args.timeout, provider=request_args.provider,
                size=size, ref_images=ref_images, seed=seed, negative_prompt=negative_prompt)
            if err is not None:
                break
            results.append(image_bytes)
        op._batch_total = total if total > 1 and err is not None else 0
        op._result = (results, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


def modify_image_worker(op, request_args: ImageRequestArgs, model, prompt, ref_images, size, seed, negative_prompt):
    """图像修改请求后台线程入口(op 模拟 self): 参考图生图请求并把结果写入 op._result"""
    try:
        image_bytes, err = request_image(
            request_args.base_url, request_args.api_key, model, prompt, request_args.timeout,
            provider=request_args.provider,
            size=size, ref_images=ref_images, seed=seed, negative_prompt=negative_prompt)
        op._result = (image_bytes, err)
    except Exception as e:
        op._result = (None, api_error("The request thread crashed", e))


def _report_request_error(op, context, scope: str, label: str, err) -> None:
    """把一次请求错误记入对应面板的错误摘要并翻译上报(单张收尾与批量上报共用)"""
    record_request_error(context, scope, label, err)
    op.report({'ERROR'}, describe_error(err))


def fail_request(op, context, scope: str, label: str, err) -> set:
    """单张请求失败的统一收尾: 记录并上报错误, 返回 CANCELLED

    效果图与纹理的生成/修改单张路径共用(仅 scope 与 bl_label 不同).
    """
    _report_request_error(op, context, scope, label, err)
    return {'CANCELLED'}


def report_batch_errors(op, context, scope: str, results, err) -> bool:
    """逐张请求的错误上报头, 返回 True 表示应终止(调用方回 {'CANCELLED'})

    全失败(无任何成功结果)时记录错误并终止; 部分成功时按 op._batch_total 报告"已成功 i/n 张"
    并返回 False(调用方继续落地产物). 错误摘要始终记录首个请求错误.
    纹理生成与效果图生成共用(两面板仅 scope 不同).
    """
    if err is None:
        return False
    if not results:
        _report_request_error(op, context, scope, op.bl_label, err)
        return True
    total = getattr(op, '_batch_total', 0)
    if total > 1:
        # 批量部分成功: 报告成功张数与失败原因(错误摘要仍记录首个错误)
        op.report({'WARNING'}, report("Succeeded {} of {} images, failed: {}").format(
            len(results), total, describe_error(err)))
    else:
        op.report({'WARNING'}, describe_error(err))
    return False


def finish_image_landing(op, context: Context, scope: str, created: int, focused: int) -> set:
    """逐张落地后的收尾, 返回操作器结果集

    无成功产物时报错并 CANCELLED; 未聚焦到图像编辑器时提示(产物已在, 只是没可见区域);
    有成功产物时清掉上次失败留的错误摘要(成功与失败在面板上区分明确).
    纹理生成与效果图生成共用(两面板收尾完全一致, 仅 scope 不同).
    """
    if created == 0:
        op.report({'ERROR'}, "AI request finished without a result")
        return {'CANCELLED'}
    clear_request_error(context, scope)
    if focused == 0:
        op.report({'INFO'}, "No image editor area open, switch an area to the image editor to see the result")
    return {'FINISHED'}
