"""Cryptomatte 语义分割解码模块(纯函数, 不 import bpy)

把渲染出的 Cryptomatte 通道解码为「每对象一色」的语义分割图, 替代原先的
材质覆盖方案(Object Info.Random 覆盖材质 + 纯黑世界), 从而不再触碰用户材质与场景世界.

算法来源(本机 Blender 5.1.2 C 源码, 只读 D:\\Development\\BlenderProject\\blender):
- intern/cryptomatte.cc:353      cryptomatte_determine_identifier -> BLI_hash_mm3(name, len, 0)
- intern/cryptomatte.cc:566      add_ID 取 &id.name[2] —— **哈希的是裸名**, 不含两字符类型前缀
- blenkernel/BKE_cryptomatte.hh:79 CryptomatteHash::float_encoded() —— 按位重解释为 float32

落盘布局(每层一个 EXR, 单层 RGBA 32bit):
- R = 槽位 1 的哈希浮点, G = 槽位 1 的覆盖率
- B = 槽位 2 的哈希浮点, A = 槽位 2 的覆盖率
故一层可承载两个对象; Blender 固定三层(实测无 cryptomatte_levels 属性), 写几层由落盘节点数决定.

注意 float_encoded 的指数被 clamp 到 1..254, 因此「浮点 -> 原始哈希」在边界上不可逆;
解码一律走「由名字算出编码浮点再比对」的方向, 该方向无歧义.

主要功能:
- mm3_x86_32 / float_encoded / name_hash / encoded_name_hash: 哈希与编码
- palette_color: 由名字哈希稳定导出的可区分配色
- decode_segmentation: 各层像素数组 -> 语义分割图 + 未匹配统计
"""

import colorsys
import struct

import numpy as np

# 一层 EXR 内的通道布局: (哈希通道, 覆盖率通道) 两组
SLOT_HASH_CHANNELS = (0, 2)
SLOT_COVERAGE_CHANNELS = (1, 3)
# Blender 固定的 Cryptomatte 层数(实测无 cryptomatte_levels 属性可调)
MAX_CRYPTO_SLOTS = 3
# 覆盖率低于该值视为无覆盖(浮点噪声容限)
COVERAGE_EPS = 1e-6
# 调色板的最小明度/饱和度, 避免出现接近纯黑(与背景混淆)或过灰的颜色
_PALETTE_VAL_MIN = 0.55
_PALETTE_SAT_MIN = 0.55
# 黄金角, 用于把哈希打散到色相环上
_GOLDEN_RATIO_CONJ = 0.6180339887498949


def mm3_x86_32(data: bytes, seed: int = 0) -> int:
    """MurmurHash3 x86_32 —— Blender BLI_hash_mm3 的逐位复刻

    Blender 侧调用为 BLI_hash_mm3(name, len, 0)(见 cryptomatte.cc:353),
    故 seed 默认 0; 返回值按 uint32 截断.
    """
    c1, c2 = 0xCC9E2D51, 0x1B873593
    length = len(data)
    h1 = seed & 0xFFFFFFFF
    nblocks = length // 4
    for i in range(nblocks):
        k1 = struct.unpack_from("<I", data, i * 4)[0]
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = ((k1 << 15) | (k1 >> 17)) & 0xFFFFFFFF
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
        h1 = ((h1 << 13) | (h1 >> 19)) & 0xFFFFFFFF
        h1 = (h1 * 5 + 0xE6546B64) & 0xFFFFFFFF
    tail = data[nblocks * 4:]
    k1 = 0
    if len(tail) >= 3:
        k1 ^= tail[2] << 16
    if len(tail) >= 2:
        k1 ^= tail[1] << 8
    if len(tail) >= 1:
        k1 ^= tail[0]
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = ((k1 << 15) | (k1 >> 17)) & 0xFFFFFFFF
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
    h1 ^= length
    h1 ^= h1 >> 16
    h1 = (h1 * 0x85EBCA6B) & 0xFFFFFFFF
    h1 ^= h1 >> 13
    h1 = (h1 * 0xC2B2AE35) & 0xFFFFFFFF
    h1 ^= h1 >> 16
    return h1


def float_encoded(hash_value: int) -> float:
    """把 32bit 哈希编码为落盘用的 float —— BKE_cryptomatte.hh:79 的逐位复刻

    取哈希的低 23 位作尾数,23..30 位作指数(夹到 1..254, 避开 NaN/Inf 与 0),
    31 位作符号, 再按位重解释为 float32.
    指数被夹过, 故该映射不是双射(边界指数不可逆); 解码方向一律由名字正向计算.
    """
    mantissa = hash_value & ((1 << 23) - 1)
    exponent = (hash_value >> 23) & 0xFF
    exponent = max(1, min(254, exponent))
    sign = (hash_value >> 31) & 1
    bits = (sign << 31) | (exponent << 23) | mantissa
    return struct.unpack("<f", struct.pack("<I", bits))[0]


def name_hash(name: str) -> int:
    """物体名 -> 32bit 哈希(裸名, 不带两字符类型前缀 —— 见 cryptomatte.cc:566)"""
    return mm3_x86_32(name.encode("utf-8"), 0)


def encoded_name_hash(name: str) -> float:
    """物体名 -> 落盘浮点(直接与 EXR 像素比对用)"""
    return float_encoded(name_hash(name))


def palette_color(name: str) -> tuple:
    """由名字哈希稳定导出 RGB uint8 三元组

    色相走黄金角打散, 饱和度与明度取哈希的高位做扰动, 保证不同名字得到的颜色
    既分散又可区分; 明度下限避免与纯黑背景混淆.同名跨次捕获结果恒定.
    """
    h = name_hash(name)
    hue = ((h & 0xFFFF) / 65536.0 + _GOLDEN_RATIO_CONJ) % 1.0
    sat = _PALETTE_SAT_MIN + ((h >> 16) & 0xFF) / 255.0 * (1.0 - _PALETTE_SAT_MIN)
    val = _PALETTE_VAL_MIN + ((h >> 24) & 0xFF) / 255.0 * (1.0 - _PALETTE_VAL_MIN)
    r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
    return (int(round(r * 255)), int(round(g * 255)), int(round(b * 255)))


def decode_segmentation(slot_arrays, names, antialias: bool = False) -> tuple:
    """把 Cryptomatte 各层像素解码为语义分割图

    slot_arrays 为逐层的 HxWxC float32 数组(C >= 4), 顺序即层序(00, 01, 02...);
    names 为参与分割的名字列表(调用方按依据给出, 见 render_passes._segmentation_names).

    antialias 决定边缘怎么处理(两者都用覆盖率通道):
    - False(默认, 硬分配): 每像素取覆盖率最大的那个对象的**纯色**, 边缘是阶梯;
    - True(管线启用的档): 按覆盖率把各对象色**加权平均**, 边缘得到过渡色 ——
      与旧「材质覆盖」方案由渲染器抗锯齿得到的效果等价(那层平滑本是渲染器给的).
    注意加权只在**已匹配到名字**的对象之间归一化: 未匹配的覆盖率不参与,
    免得把画面整体压暗(未匹配像素保持黑, 并由未解析占比暴露出来).

    返回 (分割图 HxWx3 uint8, 未解析像素占比, 错误信息):
    - 未解析 = 该像素有覆盖(任一层覆盖率 > 0)但未匹配到任何给出的名字 ——
      常见成因是所选依据下确实没有对应名字(如按材质分割而物体没有材质), 调用方据此提示;
      **口径按像素而非按对象**: 像素只要有**任一**槽位匹配到名字就不计未解析, 哪怕另一个
      槽位有未列名的覆盖. 这是有意取舍(见 tests 的 test_antialias_normalizes_by_matched_
      coverage_only): 本数值用于量化"整片没解析出来的面积", 不用于反映重叠边缘的小面积
      归属偏差 —— 边缘偏差由覆盖率择优处理(硬分配取最大者/抗锯齿按覆盖率加权).
    - 失败时返回 (None, 0.0, 错误信息).
    """
    arrays = [a for a in (slot_arrays or []) if a is not None]
    if not arrays:
        return None, 0.0, "No cryptomatte layers were captured"
    first = np.asarray(arrays[0])
    if first.ndim != 3 or first.shape[2] < 4:
        return None, 0.0, "The cryptomatte layer has an unexpected channel layout"
    height, width = first.shape[0], first.shape[1]

    name_list = [n for n in (names or []) if n]
    palette = {n: palette_color(n) for n in name_list}
    encoded = {n: encoded_name_hash(n) for n in name_list}
    # 名字 -> 调色板下标, 由「编码浮点」直接反查: 避免逐名全图比对(那是 O(名数 × 像素),
    # 物体多时会明显变慢); 下面只对**像素里实际出现过**的哈希值做反查, 唯一值通常只有几十个.
    lookup = {float(encoded[n]): idx for idx, n in enumerate(name_list)}
    palette_rgb = (np.array([palette[n] for n in name_list], dtype=np.uint8)
                   if name_list else np.zeros((0, 3), dtype=np.uint8))

    out = np.zeros((height, width, 3), dtype=np.uint8)
    covered = np.zeros((height, width), dtype=bool)
    matched = np.zeros((height, width), dtype=bool)
    # 硬分配用: 每像素当前胜出者的覆盖率(重叠处取覆盖率最大者, 而非遍历顺序决定)
    best_cov = np.zeros((height, width), dtype=np.float32)
    # 抗锯齿用: 覆盖率加权的颜色累加与权重累加
    acc = np.zeros((height, width, 3), dtype=np.float32)
    weight = np.zeros((height, width), dtype=np.float32)

    for arr in arrays:
        arr = np.asarray(arr)
        if arr.shape[:2] != (height, width) or arr.shape[2] < 4:
            return None, 0.0, "The cryptomatte layers have inconsistent sizes"
        for hash_ch, cov_ch in zip(SLOT_HASH_CHANNELS, SLOT_COVERAGE_CHANNELS):
            coverage = arr[..., cov_ch]
            # 槽位有效 = 哈希非零 **且** 覆盖率 > 0. 实测 Blender 对**空槽**写的是
            # hash=0 且 coverage=1(把"什么都没有"也记成满覆盖): 只按覆盖率判, 整片背景
            # 都会被算成"有覆盖却没匹配到名字", 未解析占比虚高到 76%(实测), 提示失去意义.
            covered |= (arr[..., hash_ch] != 0.0) & (coverage > COVERAGE_EPS)
            if not name_list:
                continue
            flat = np.ascontiguousarray(arr[..., hash_ch]).reshape(-1)
            uniq, inverse = np.unique(flat, return_inverse=True)
            index_map = np.array([lookup.get(float(u), -1) for u in uniq], dtype=np.int32)
            cand = index_map[inverse.reshape(-1)].reshape(height, width)
            hit = cand >= 0
            if not hit.any():
                continue
            matched |= hit
            if antialias:
                take = hit & (coverage > COVERAGE_EPS)
                if take.any():
                    w = coverage[take]
                    acc[take] += palette_rgb[cand[take]].astype(np.float32) * w[:, None]
                    weight[take] += w
            else:
                take = hit & (coverage > best_cov)
                if take.any():
                    out[take] = palette_rgb[cand[take]]
                    best_cov[take] = coverage[take]

    if antialias:
        solid = weight > COVERAGE_EPS
        if solid.any():
            blended = acc[solid] / weight[solid, None]
            out[solid] = np.clip(blended + 0.5, 0, 255).astype(np.uint8)

    total = height * width
    unmatched_ratio = float((covered & ~matched).sum()) / total if total else 0.0
    return out, unmatched_ratio, None
