"""
相机视图参考通道提取工具模块(EEVEE 单引擎 · 临时文件中转管线)

以 EEVEE 在一个临时场景中渲染场景相机视图, 提取七种参考通道. 渲染按**渲染组**组织,
组是「一次渲染调用」与「缓存失效」的共同单位(见 GROUP_VIEW_LAYER / GROUP_OUTPUTS):
- 主组(用户世界): 合并结果(Combined)/深度(Depth)/法向(Normal)/漫射颜色(Diffuse Color)/
  AO(Ambient Occlusion), 共享用户世界与相机, 合并结果套用用户色彩管理;
- 主组(附加出线): 语义分割由 Cryptomatte 出图 —— 勾选分割时主组额外落盘若干层
  crypto_NN.exr(每层两个对象槽位), 解码期在 Python 内按所选依据(物体/材质/资产)合成
  「每对象一色 + 纯黑背景」的分割图, 全程不建覆盖材质, 也不改用户世界;
- 线稿组(场景线条画): 场景级蜡笔(LINEART_SCENE)开启视图层蜡笔通道, **原样**输出 Grease
  Pencil 通道, 白底黑线在 Python 内按 1-alpha 映射(合成器内做算术不可信, 见 _build_capture_group).

两组默认在**同一次渲染调用**里一起落盘(各占一个视图层); 线稿组靠集合排除把自己从主组隔开,
故合并结果不被线稿污染. 未失效的组可由增量缓存直接复用, 只重渲真正需要的那一组.

落盘机制(5.1.2 实证要点, 详见 memories/blender-compositor-5x-file-output.md):
File Output 节点的 format.media_type 默认是 MULTI_LAYER_IMAGE, 该档下 file_format 被锁死为
OPEN_EXR_MULTILAYER,所有输入并被合并进同一个 .exr; 必须先设 media_type='IMAGE' 才能
逐通道独立指定格式.故本模块"一个通道一个 File Output 节点", 逐通道落盘到
%TEMP%/ch_ai_assistant_pass_capture/<本次唯一目录>/, 读入内存后立即删除:
- 合并结果/漫射颜色 -> JPEG(体积小, 走 Blender 编码), AO -> PNG 8bit;
- 语义分割 -> 若干层 crypto_NN.exr 32bit(哈希是按位重解释的浮点, 任何有损环节都会摧毁 ID),
  解码期自编码 PNG, 因此该通道**完全不进 Blender 色彩管线**;
- 深度/法向 -> 单层 EXR 16bit(需回读原始浮点: 深度背景为 camera.clip_end 远超 1,
  法向是**带符号原始向量**而非 (n+1)/2, 写 LDR 会被钳成 0), 回读后在 numpy 内完成
  映射与编码(深度按用户近/远区间映射为灰阶, 法向按 (n+1)/2 编码, DIRECTX 约定反绿通道);
- 线稿 -> PNG 8bit, 但渲染写出的像素 RGB 恒为 0,笔画信息**全在 alpha**, 故回读 alpha 后
  按 1-alpha 映射为黑线白底再自编码 PNG.
渲染自身不写静帧(write_still=False): 通道文件由 File Output 节点落盘, 与静帧写盘无关,
故一次捕获只产出 7 份通道文件(实测).

用户场景零修改: 临时场景只关联(引用)用户集合/相机/世界, 全部改动都落在临时场景与临时
视图层上; 分割走 Cryptomatte 后**既不写用户物体的 obj.color, 也不建覆盖材质/覆盖世界**
(更早的实现两者都做); 蜡笔对象经上下文覆写在临时场景内创建并在 finally 中回收,
用户侧的集合成员,选中集与活动物体均不被改动.

临时文件生命周期(用户 2026-10-10 定论): 每次捕获前先清扫本插件自有临时根目录下的旧目录,
捕获中"渲染写出 -> 读入内存/打包 -> 立即删除", 删除一律尽力而为(Windows 上刚写出的图片
常被杀软实时扫描/索引器/缩略图预览瞬时占用而抛 WinError 32, 短延时重试一次, 仍失败即放弃,
绝不允许打断捕获流程); 只动自家目录, 不碰 %TEMP% 中他人的文件.

主要功能:
- capture_camera_passes: 渲染相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)
- sample_visible_depth: 按相机视锥几何投射采样可见深度, 返回 (近端, 远端, 命中数, 错误信息),
  供面板「深度拾取」一键回填深度范围(不渲染)
"""

import os
import shutil
import struct
import tempfile
import time
import zlib

import numpy as np

import bpy

from .cryptomatte import decode_segmentation
from .errors import api_error

# 草稿渲染采样(AO 通道 EEVEE 5.1 实证可出数据, 无需切 Cycles)
_EEVEE_SAMPLES = 16
# 钳制长边的防御性硬上限(实际钳制值由偏好里当前服务商的参考图上限决定)
_CLAMP_EDGE_MAX = 8192
# 目标分辨率提醒阈值(公开): 长边超过该值时面板打提醒标签——通道图可能另作他用, 不禁止只提醒
WARN_EDGE_PX = 2048
# 本插件自有临时根目录名(清扫只针对该目录, 绝不触碰 %TEMP% 中他人文件)
_TMP_ROOT_NAME = "ch_ai_assistant_pass_capture"
# JPEG 输出质量(参考图用途, 90 在体积与细节间平衡)
_JPEG_QUALITY = 90
# 自编码 PNG 的 zlib 压缩等级(深度/法向/线稿三个回读通道走自编码)
_PNG_COMPRESS = 6
# 蜡笔线稿基准宽度(世界单位 radius, 作者定标 0.01), 线稿宽度缩放系数乘在其上;
# 自适应换算(按分辨率/视野目标 1.5px)实测产出过细的头发丝线, 作者判定观感倒退已废弃
_EDGE_RADIUS_FALLBACK = 0.01
# 蜡笔 Lineart 修改器 radius 的钳制区间(避免极端场景下线过粗/过细)
_EDGE_RADIUS_MIN = 0.001
_EDGE_RADIUS_MAX = 0.1

# ---- 线稿预设(映射到 Lineart 修改器的线条类型开关) ----
# 出厂默认实测(5.1.2, 见 .zcode/tmp/probe_lineart.py): use_contour / use_loose / use_crease /
# use_edge_mark / use_intersection 全为 True, use_shadow / use_light_contour 为 False.
# 故"标准"档即**明写这组出厂默认**, 与改造前的行为逐位一致(旧实现根本不碰这些开关).
EDGE_PRESET_STANDARD = 'STANDARD'
EDGE_PRESET_CONTOUR = 'CONTOUR'
EDGE_PRESET_SHADED = 'SHADED'
EDGE_PRESET_HARDSURFACE = 'HARDSURFACE'
EDGE_PRESET_DEFAULT = EDGE_PRESET_STANDARD
EDGE_PRESETS = {
    # 轮廓 + 折痕 + 边标记 + 孤立边 + 相交线(等价修改器出厂状态)
    EDGE_PRESET_STANDARD: {
        'use_contour': True, 'use_loose': True, 'use_crease': True,
        'use_edge_mark': True, 'use_intersection': True,
        'use_shadow': False, 'use_light_contour': False,
    },
    # 只要物体外轮廓, 画面最干净
    EDGE_PRESET_CONTOUR: {
        'use_contour': True, 'use_loose': False, 'use_crease': False,
        'use_edge_mark': False, 'use_intersection': False,
        'use_shadow': False, 'use_light_contour': False,
    },
    # 标准 + 投影线 + 光源轮廓线(风格化)
    EDGE_PRESET_SHADED: {
        'use_contour': True, 'use_loose': True, 'use_crease': True,
        'use_edge_mark': True, 'use_intersection': True,
        'use_shadow': True, 'use_light_contour': True,
    },
    # 轮廓 + 折痕 + 相交线(去孤立边与边标记), 适合机械/硬表面
    EDGE_PRESET_HARDSURFACE: {
        'use_contour': True, 'use_loose': False, 'use_crease': True,
        'use_edge_mark': False, 'use_intersection': True,
        'use_shadow': False, 'use_light_contour': False,
    },
}

# 深度拾取的采样网格(列, 行): 向相机视锥投网格射线取命中深度的分位数作区间锚点(不渲染)
_DEPTH_PICK_GRID = (64, 48)
# 深度拾取的分位锚点(%): 近端 2%,远端 98%——两端各钳掉 2% 极值, 保住主体层次
_DEPTH_PICK_NEAR_PCT = 2.0
_DEPTH_PICK_FAR_PCT = 98.0
# 深度拾取的最少命中数: 低于该值认为没框到几何(如相机对空), 不出区间只报提示
_DEPTH_PICK_MIN_HITS = 8

# 通道参考优先序(与面板排序,提示词通道描述一致; 公开导出供生成期截断与发送顺序共用)
PASS_ORDER = ('combined', 'depth', 'normal', 'segmentation', 'edge', 'diffuse', 'ao')

# 通道落盘规格: 通道键 -> (文件格式, 位深, 是否套用场景色彩管理的 view transform)
#   只有合并结果套 view transform(遵循用户色彩管理, 作者 2026-10-10 定案 A4);
#   其余一律不套: 深度/法向是数据通道(套 view transform 会被压色), 语义分割是必须原值落盘的
#   语义色块, 漫射颜色/AO 是给 AI 看的色彩底图(套用户 look 会整体偏色).
#   注意该标志**必须同时写到 File Output 节点与其 item 上**——item 打开 override_node_format
#   后以 item 自己的 save_as_render 为准(默认 True), 只写节点级会被无视, 见 _add_output_node.
_PASS_FORMATS = {
    'combined': ('JPEG', '8', True),
    'depth': ('OPEN_EXR', '16', False),
    'normal': ('OPEN_EXR', '16', False),
    'diffuse': ('JPEG', '8', False),
    'ao': ('PNG', '8', False),
    'segmentation': ('PNG', '8', False),
    'edge': ('PNG', '8', False),
}

# ---- Cryptomatte 语义分割(取代材质覆盖方案) ----
# 分割通道不再由独立帧直出: 主组在需要分割时额外落盘若干**层** cryptomatte, 每层是 RGBA
# 32bit, 装两个对象槽位(R=哈希1 G=覆盖率1 B=哈希2 A=覆盖率2); 解码期在 Python 内合成
# 「每对象一色 + 纯黑背景」的分割图(见 utils/cryptomatte.py).
# 层数写满 3 层(实测无 cryptomatte_levels 属性可调): 原先的材质覆盖方案对每像素重叠对象数
# 没有上限, 层数不足会让重叠处静默取到错误对象 —— 宁可多写临时文件, 也不引入行为回退.
# 代价: 每层 32bit EXR 在 1024² 约 16.8 MB,2048² 约 67 MB, 只在开启分割时才落盘.
CRYPTO_SLOT_COUNT = 3
CRYPTO_SLOT_KEYS = tuple(f"crypto_{i:02d}" for i in range(CRYPTO_SLOT_COUNT))
# 分割依据: Cryptomatte 的三条 ID 通道, 各自对应一组 RLayers 出线与一个视图层 pass 开关.
# 通道键(crypto_NN)与依据无关, 只是槽位序号 —— 依据本身进主组渲染键(开哪条 pass 不同).
CRYPTO_SOURCE_OBJECT = 'OBJECT'
CRYPTO_SOURCE_MATERIAL = 'MATERIAL'
CRYPTO_SOURCE_ASSET = 'ASSET'
CRYPTO_SOURCE_SOCKETS = {
    CRYPTO_SOURCE_OBJECT: tuple(f"CryptoObject{i:02d}" for i in range(CRYPTO_SLOT_COUNT)),
    CRYPTO_SOURCE_MATERIAL: tuple(f"CryptoMaterial{i:02d}" for i in range(CRYPTO_SLOT_COUNT)),
    CRYPTO_SOURCE_ASSET: tuple(f"CryptoAsset{i:02d}" for i in range(CRYPTO_SLOT_COUNT)),
}
CRYPTO_SOURCE_PASS_ATTR = {
    CRYPTO_SOURCE_OBJECT: 'use_pass_cryptomatte_object',
    CRYPTO_SOURCE_MATERIAL: 'use_pass_cryptomatte_material',
    CRYPTO_SOURCE_ASSET: 'use_pass_cryptomatte_asset',
}
# 分割依据出厂默认: 按物体分块(每个物体一个 ID, 名字表必然覆盖被渲到的物体).
# 与 props.cryptomatte_source 的 default 必须同口径 —— 本常量是"调用方未显式传参"时的
# 兜底(生产路径恒显式传参, 见 ai_render 的 CaptureViewRefs), 两者不一致会变成影子默认.
# 注意: 按**材质**分块时, 物体**没有材质**的像素匹配不到任何名字而保持黑色. 其哈希并非 0
# (实测 Blender 5.1.2: 无材质物体在 material 通道得到 -515791044739072.0 这类非零值,
# 见 .zcode/memory/2026-10-13.md), 因此这些像素计入"有覆盖却未匹配", 由未解析占比提示暴露.
CRYPTO_SOURCE_DEFAULT = CRYPTO_SOURCE_OBJECT
# 未解析像素占比超过该值即写一条提示(口径按像素: 该像素有覆盖却一个给出的名字都没匹配上;
# 常见成因是所选依据下确实没有对应名字, 如按材质分割而物体没有材质)
_SEG_UNMATCHED_WARN = 0.01
_PASS_FORMATS.update({key: ('OPEN_EXR', '32', False) for key in CRYPTO_SLOT_KEYS})

# 文件格式 -> 扩展名(File Output 按 node format 补扩展名, 读回时据此拼路径)
_EXTENSIONS = {'JPEG': '.jpg', 'PNG': '.png', 'OPEN_EXR': '.exr'}

# ---- 渲染组: 组是「一次渲染调用」与「缓存失效」的共同单位 ----
# 每组绑定一个视图层与一组出线. 组与组之间的场景态(蜡笔集合成员)互不干扰,
# 因此多个组可以在**同一次渲染调用**里一起出图; 也可用 render(layer=...) 只渲其中一组.
GROUP_MAIN = 'main'
# 线稿视图层: 只有它包含蜡笔集合, 主组按集合排除掉蜡笔, 合并结果因而不被线稿污染.
GROUP_LINEART = 'lineart'

# 组 -> 视图层名(在临时场景内新建, 用户场景不受影响)
GROUP_VIEW_LAYER = {
    GROUP_MAIN: "VL_Main",
    GROUP_LINEART: "VL_LineArt",
}
# 组 -> 该组的通道与来源出线(RLayers 输出名)
GROUP_OUTPUTS = {
    GROUP_MAIN: (
        ('combined', 'Image'),
        ('depth', 'Depth'),
        ('normal', 'Normal'),
        ('diffuse', 'Diffuse Color'),
        ('ao', 'Ambient Occlusion'),
    ),
    GROUP_LINEART: (('edge', 'Grease Pencil'),),
}
# 蜡笔对象所属集合名(主组按集合排除它, 线稿组包含它)
LINEART_COLLECTION = "CH_AI_LineArt"


def _crypto_slots_used(crypto_slots: int) -> int:
    """把落盘层数夹到合法区间(1..CRYPTO_SLOT_COUNT)"""
    try:
        value = int(crypto_slots)
    except (TypeError, ValueError):
        return CRYPTO_SLOT_COUNT
    return max(1, min(CRYPTO_SLOT_COUNT, value))


def _group_entries(group: str, wanted: dict, crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                   crypto_slots: int = CRYPTO_SLOT_COUNT) -> tuple:
    """该组本次需要的出线(通道键, 出线名)表

    主组按逐通道勾选过滤(可能为空), 勾选分割时再追加所选依据对应的 cryptomatte 各层;
    线稿组是整体开关, 关闭即整组不出线. 空表意味着该组本次无需渲染.
    """
    if group == GROUP_MAIN:
        entries = tuple(item for item in GROUP_OUTPUTS[group] if wanted.get(item[0]))
        if wanted.get('segmentation'):
            sockets = CRYPTO_SOURCE_SOCKETS.get(crypto_source,
                                                CRYPTO_SOURCE_SOCKETS[CRYPTO_SOURCE_DEFAULT])
            slots = _crypto_slots_used(crypto_slots)
            entries += tuple(zip(CRYPTO_SLOT_KEYS[:slots], sockets[:slots]))
        return entries
    if group == GROUP_LINEART:
        return GROUP_OUTPUTS[group] if wanted.get('edge') else ()
    return ()


def _eevee_engine_id() -> str | None:
    """EEVEE 草稿引擎 id: 4.2+ 为 BLENDER_EEVEE_NEXT, 旧版为 BLENDER_EEVEE, 均无则 None

    注意: RenderSettings.engine 的枚举表是惰性维护的(后台加载时只列举当前档),
    故这里不能靠 enum_items 判定可用性, 改为直接尝试赋值探测(见 _is_engine_usable).
    """
    for engine_id in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        if _is_engine_usable(engine_id):
            return engine_id
    return None


def _is_engine_usable(engine_id: str) -> bool:
    """探测引擎在本构建是否可用: 往一个临时场景的 RenderSettings 上尝试赋值

    enum_items 惰性(后台只列举当前档), 故不能靠枚举表判定; 赋值失败必然不可用,
    赋值成功即认为可用(真正的渲染失败仍由捕获期异常兜底转成错误信息).
    """
    tmp = None
    try:
        tmp = bpy.data.scenes.new("CH_AI_EngineProbe")
        tmp.render.engine = engine_id
        return tmp.render.engine == engine_id
    except (TypeError, ValueError):
        return False
    except Exception:  # noqa: BLE001 - 探测场景建不出来等异常一律按不可用处理
        return False
    finally:
        if tmp is not None:
            bpy.data.scenes.remove(tmp)


# ---------------------------------------------------------------- 临时目录

def _tmp_root() -> str:
    """本插件自有临时根目录(所有捕获目录都建在其下, 便于只清扫自家的残留)"""
    return os.path.join(tempfile.gettempdir(), _TMP_ROOT_NAME)


def _drop_path(path) -> None:
    """尽力而为地删除文件/目录: 失败即放弃, 绝不影响捕获流程

    Windows 上刚写出的图片常被杀软实时扫描/索引器/缩略图预览瞬时占用,
    os.remove/rmtree 会抛 PermissionError(WinError 32); 短延时重试一次, 仍失败静默放弃.
    宿主系统是否会自动清理 %TEMP% 不可依赖(存储感知默认多在磁盘不足时触发且可关闭,
    %TEMP% 也没有"保留 N 天自动删除"的默认策略), 故主动收口.
    """
    if not path:
        return
    for attempt in (0, 1):
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            return
        except FileNotFoundError:
            return
        except OSError:
            if attempt == 0:
                time.sleep(0.05)
    return


def _sweep_tmp_root() -> None:
    """清扫本插件临时根目录下上一次捕获遗留的子目录(只动自家目录)

    删除失败/进程崩溃留下的残骸不允许跨次累积: 每次捕获开头先清一遍,
    即便上一次因占用没删干净, 也不会被本次捕获读到(每次捕获用全新唯一子目录).
    """
    root = _tmp_root()
    try:
        names = os.listdir(root)
    except OSError:
        return
    for name in names:
        _drop_path(os.path.join(root, name))


def _new_tmp_dir() -> str:
    """建本次捕获的唯一临时子目录(唯一目录可杜绝读到上一次残留的陈旧文件)"""
    root = _tmp_root()
    os.makedirs(root, exist_ok=True)
    return tempfile.mkdtemp(prefix="cap_", dir=root)


# ---------------------------------------------------------------- 分辨率

def _render_size(rd) -> tuple:
    """实际渲染像素尺寸(分辨率乘百分比)"""
    scale = rd.resolution_percentage / 100.0
    return max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale))


def _clamped_percentage(rd, clamp_long_edge: int) -> int:
    """分辨率百分比: 钳制开启且长边超上限时等比下调, 否则沿用原值

    未开启钳制时直接用 Blender 输出属性(resolution_x/y 乘 resolution_percentage);
    开启后只在**超过上限**时钳制, 且经百分比等比缩放保证宽高比不变
    (渲染只支持整数百分比, 故结果可能略小于上限, 不会超过).
    """
    percentage = rd.resolution_percentage
    if clamp_long_edge <= 0:
        return percentage
    long_edge = max(rd.resolution_x, rd.resolution_y)
    if long_edge <= 0 or long_edge * percentage / 100.0 <= clamp_long_edge:
        return percentage
    return max(1, min(percentage, int(clamp_long_edge * 100 / long_edge)))


def _sane_clamp(clamp_long_edge) -> int:
    """规范化钳制上限: 非法值按不钳制, 并夹到防御性硬上限"""
    try:
        value = int(clamp_long_edge)
    except (TypeError, ValueError):
        return 0
    return min(max(value, 0), _CLAMP_EDGE_MAX)


def resolve_capture_size(scene, clamp_long_edge) -> tuple:
    """本次捕获会实际渲染的像素尺寸(宽, 高)

    面板标签与真实输出同口径: 未开启钳制时即 Blender 输出分辨率乘 resolution_percentage,
    开启后仅在超出上限时经百分比等比下调. 场景不可用时回落 (0, 0).
    """
    rd = getattr(scene, "render", None)
    if rd is None:
        return (0, 0)
    percentage = _clamped_percentage(rd, _sane_clamp(clamp_long_edge))
    scale = percentage / 100.0
    return (max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale)))


def estimate_capture_bytes(size, keys, crypto_slots: int = CRYPTO_SLOT_COUNT) -> int:
    """估算所选通道落盘总体积(字节), 仅用于面板提示, 非精确值

    依据各通道的落盘规格估算每像素字节数: EXR 未压缩(实测 format.compression 对输出体积
    无影响)按 RGBA 四位深算, PNG/JPEG 为实测经验系数(通道图多为平涂/线稿, 压缩率较高);
    真实体积随画面复杂度浮动, 故面板文案标为估算.
    语义分割按当前 crypto_slots 展开成对应层数的 32bit EXR(层数变了估算要跟着变).
    """
    width, height = size if size else (0, 0)
    pixels = max(0, int(width) * int(height))
    if not pixels:
        return 0
    total = 0.0
    for key in keys:
        # 语义分割的实际落盘是若干层 32bit EXR(最终那张 PNG 由解码期在内存里生成, 不落盘)
        actual_keys = (CRYPTO_SLOT_KEYS[:_crypto_slots_used(crypto_slots)]
                       if key == 'segmentation' else (key,))
        for actual in actual_keys:
            spec = _PASS_FORMATS.get(actual)
            if spec is None:
                continue
            image_format, color_depth, _save_as_render = spec
            if image_format == 'OPEN_EXR':
                total += pixels * (8.0 if color_depth == '16' else 16.0)
            elif image_format == 'JPEG':
                total += pixels * 0.3
            else:
                total += pixels * 1.0
    return int(total)


# ---------------------------------------------------------------- 临时场景

def _link_user_scene(tmp, scene) -> None:
    """把用户场景的集合与主集合物体关联进临时场景(引用共享, 不复制)"""
    for col in scene.collection.children:
        tmp.collection.children.link(col)
    for obj in scene.collection.objects:
        tmp.collection.objects.link(obj)


def _copy_render_common(tmp, scene, clamp_long_edge: int) -> None:
    """拷贝渲染公共项: 分辨率(按钳制上限等比下调百分比)/帧/胶片/水印

    帧必须跟随原场景: 临时场景默认停在第 1 帧, 不拷则动场景(关键帧/驱动/约束)捕获到的是首帧画面.
    """
    rd, src = tmp.render, scene.render
    rd.resolution_x = src.resolution_x
    rd.resolution_y = src.resolution_y
    rd.resolution_percentage = _clamped_percentage(src, clamp_long_edge)
    rd.film_transparent = False
    rd.use_stamp = False
    tmp.frame_start = scene.frame_start
    tmp.frame_end = scene.frame_end
    tmp.frame_current = scene.frame_current


def _copy_color_management(tmp, scene) -> None:
    """把用户场景的色彩管理拷到临时场景(只有合并结果会套用)

    合并结果走 File Output 的 save_as_render=True, 套的是**临时场景**的 view transform,
    故必须把用户设置搬过来, 否则会落到临时场景的出厂默认(AgX).
    其余通道靠 item 级 save_as_render=False 跳过色彩管理(见 _add_output_node), 不受影响.
    """
    try:
        vs_src, vs_dst = scene.view_settings, tmp.view_settings
        vs_dst.view_transform = vs_src.view_transform
        try:
            vs_dst.look = vs_src.look
        except TypeError:
            pass  # 个别 look 枚举缺档时保留默认
        vs_dst.exposure = vs_src.exposure
        vs_dst.gamma = vs_src.gamma
    except Exception:  # noqa: BLE001 - 老构建缺属性时退回临时场景默认色彩管理
        pass


def _enable_passes(vl, group: str, wanted: dict, ao_distance: float,
                   crypto_source: str = CRYPTO_SOURCE_OBJECT) -> None:
    """按组开启该视图层的渲染通道(AO 遮蔽距离落在视图层而非场景, 5.1 实证)

    各组只开自己需要的通道: 主组按勾选开(勾选分割时再开所选依据的 cryptomatte 通道),
    线稿组只要蜡笔通道.
    """
    if group == GROUP_LINEART:
        try:
            vl.use_pass_grease_pencil = True
        except AttributeError:
            pass  # 引擎注册表无该 RNA 属性时跳过, 通道缺失在提取期兜底
        return
    vl.use_pass_combined = True
    if group == GROUP_MAIN and wanted.get('segmentation'):
        attr = CRYPTO_SOURCE_PASS_ATTR.get(crypto_source,
                                           CRYPTO_SOURCE_PASS_ATTR[CRYPTO_SOURCE_DEFAULT])
        try:
            # 语义分割由 Cryptomatte 承担: 它只编码 ID, 与材质无关, 故无需任何覆盖
            setattr(vl, attr, True)
        except (AttributeError, TypeError):
            pass  # 该构建没有 cryptomatte 通道时跳过, 分割缺失在解码期兜底
    if wanted['depth']:
        vl.use_pass_z = True
    if wanted['normal']:
        vl.use_pass_normal = True
    if wanted['diffuse']:
        vl.use_pass_diffuse_color = True
    if wanted['ao']:
        try:
            vl.use_pass_ambient_occlusion = True
            vl.eevee.ambient_occlusion_distance = ao_distance
        except AttributeError:
            pass  # 引擎注册表无该 RNA 属性时跳过, 通道缺失在提取期兜底


# ---------------------------------------------------------------- 渲染组视图层

def _ensure_view_layers(tmp, groups) -> dict:
    """按需要的组准备临时场景的视图层, 返回 {组: 视图层}, 并设置蜡笔集合的排除关系

    主组按集合排除蜡笔集合(它不该看到线稿), 线稿组包含之.
    蜡笔集合即使不存在也先建好并挂到场景主集合下, 免得后续每处都要判空.
    """
    if LINEART_COLLECTION not in tmp.collection.children:
        col = bpy.data.collections.new(LINEART_COLLECTION)
        tmp.collection.children.link(col)

    layers = {}
    for group, name in GROUP_VIEW_LAYER.items():
        if group not in groups:
            continue
        vl = tmp.view_layers.get(name)
        if vl is None:
            # 首个视图层沿用默认层并改名, 避免多出一个空的 "ViewLayer"
            if len(tmp.view_layers) == 1 and tmp.view_layers[0].name == "ViewLayer":
                vl = tmp.view_layers[0]
                vl.name = name
            else:
                vl = tmp.view_layers.new(name)
        layers[group] = vl

    for group, vl in layers.items():
        lc = vl.layer_collection.children.get(LINEART_COLLECTION)
        if lc is not None:
            lc.exclude = group != GROUP_LINEART
    return layers


def _move_to_lineart_collection(tmp, gp) -> None:
    """把蜡笔对象挪进线稿专用集合

    主组的视图层按集合排除该集合, 线稿组包含它 —— 这是「一次渲染既能得到干净的
    合并结果,又能得到线稿」的关键: 蜡笔若留在场景主集合里, 所有视图层都会看到它.
    """
    if gp is None:
        return
    col = tmp.collection.children.get(LINEART_COLLECTION)
    if col is None:
        return
    for user_col in list(gp.users_collection):
        user_col.objects.unlink(gp)
    col.objects.link(gp)


# ---------------------------------------------------------------- 合成节点

def _add_output_node(ng, tmp_dir: str, key: str):
    """建一个通道落盘节点(一个通道一个节点, 逐通道独立格式)

    必须先设 format.media_type='IMAGE': 默认档 MULTI_LAYER_IMAGE 会把 file_format
    锁死为 OPEN_EXR_MULTILAYER 并把所有输入并进同一个 .exr;
    EXR 位深只在**节点级**设置(item 级 color_depth 实测被忽略).

    save_as_render 则相反, **必须写到 item 上**: item 打开 override_node_format 后,
    落盘时的颜色管理以 item 自己的 save_as_render 为准(其默认值是 True), 节点上那个被
    完全无视 —— 这正是"除合并结果外其余通道仍被套上用户 view transform"的成因
    (实测: 同一场景把用户 view transform 在 Standard/AgX/Filmic 间切换, 分割图统计随
    之变化 0.6658/0.5934/0.6204, 而它本应恒等). 节点级保留为显式意图声明, item 级才生效.
    """
    image_format, color_depth, save_as_render = _PASS_FORMATS[key]
    fo = ng.nodes.new("CompositorNodeOutputFile")
    fo.directory = tmp_dir
    fo.file_name = ""  # 文件名只取区间名, 避免与节点名拼接成 combined_combined
    fo.save_as_render = save_as_render
    fo.format.media_type = 'IMAGE'
    fo.format.file_format = image_format
    try:
        fo.format.color_depth = color_depth
    except TypeError:
        pass  # 该格式不支持该位深时用默认档
    if image_format == 'JPEG':
        try:
            fo.format.quality = _JPEG_QUALITY
        except Exception:  # noqa: BLE001 - 老构建无 quality 时用默认质量
            pass
    # 落点通过节点的 inputs 建(它就是 items 列表), item 对象没有 socket 属性
    it = fo.file_output_items.new('RGBA', key)
    it.override_node_format = True
    it.save_as_render = save_as_render  # ← 实际生效的那一份(见上)
    it.format.media_type = 'IMAGE'
    it.format.file_format = image_format
    try:
        it.format.color_depth = color_depth
    except (TypeError, AttributeError):
        pass
    return fo


def _build_capture_group(tmp, tmp_dir: str, layer_entries: tuple) -> tuple:
    """构建合成节点组: 每组一个 RLayers(绑定其视图层) -> 该组每通道一个 File Output

    layer_entries 为 ((视图层, 出线表), ...), 出线表即 GROUP_OUTPUTS[组];
    多个视图层可以在同一次渲染调用里各自落盘(实测), 故节点组一次建全.
    返回 (节点组, 缺失通道提示列表); 出线在当前引擎不存在时跳过该通道并记提示,
    不打断整次捕获. 树根仍需一个 NodeGroupOutput 让渲染正常产出合成结果(它是节点树
    必需的输出接口), 但渲染自身不写盘(见 _render_frame), 一次捕获只产出通道文件.
    合成器里**不做任何数学**: 需要变形的通道(深度/法向/线稿)一律原样落盘后在 Python 内
    处理——实测本管线的 AlphaOver 会把纯白底洗成 0.769 灰, 且不同连线给出逐字节相同的
    结果, 节点内做算术不可信.
    提示用 api_error 的"常量标题 + 动态通道键"形态(utils 内不做翻译查询, 由交互层
    describe_error 翻译标题后拼接通道键, 见 errors 模块头注释).
    """
    ng = bpy.data.node_groups.new("CH_AI_PassCapture", 'CompositorNodeTree')
    tmp.compositing_node_group = ng
    ng.interface.new_socket(name="Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    go = ng.nodes.new("NodeGroupOutput")
    missing = []
    root_linked = False
    for vl, entries in layer_entries:
        rl = ng.nodes.new("CompositorNodeRLayers")
        rl.scene = tmp
        rl.layer = vl.name
        if not root_linked and rl.outputs.get("Image") is not None:
            # 树根的输出接口取第一个有 Image 出线的组(线稿组只开蜡笔通道, 没有可用 Image)
            ng.links.new(rl.outputs["Image"], go.inputs[0])
            root_linked = True
        for key, socket_name in entries:
            sock = rl.outputs.get(socket_name)
            if sock is None:
                missing.append((key, api_error(
                    "The pass is not available from this engine, it was skipped", key)))
                continue
            fo = _add_output_node(ng, tmp_dir, key)
            ng.links.new(sock, fo.inputs[0])
    return ng, missing


def _drop_node_group(ng) -> None:
    """回收本帧的合成节点组(用完即释放: 临时场景虽会整体回收, 但提前删掉更干净)

    失败一律静默: 节点组已随场景回收,或本帧根本没建起来, 都不该影响捕获流程.
    """
    if ng is None:
        return
    try:
        bpy.data.node_groups.remove(ng)
    except Exception:  # noqa: BLE001 - 已随场景回收时忽略
        pass


def _render_frame(tmp, vl, tmp_dir: str, layer: str | None = None) -> tuple:
    """渲染一次, 返回错误信息

    layer 非空时只渲染该视图层(实测: 其它视图层的 File Output **不会**被写出),
    用于「只有一组失效」时避免连带重渲另一组.
    write_still=False: 通道文件由合成器的 File Output 节点落盘, 与静帧写盘无关(实测),
    故不写静帧——省掉每帧一次整幅 PNG 编码与落盘(一次捕获原本要多写 3 次 render_still.png).
    filepath 仍指向本次临时目录: 万一将来这里改回要写静帧, 落点也不会外泄到用户工程目录.
    """
    tmp.render.filepath = os.path.join(tmp_dir, "render_still")
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=vl):
            if layer:
                bpy.ops.render.render(write_still=False, layer=layer)
            else:
                bpy.ops.render.render(write_still=False)
    except RuntimeError as e:
        return api_error("Render failed", e)
    return None


def _pass_file(tmp_dir: str, key: str, image_format: str):
    """定位通道落盘文件(扩展名由节点格式决定; 找不到精确名时按前缀兜底)"""
    ext = _EXTENSIONS.get(image_format, '.png')
    exact = os.path.join(tmp_dir, key + ext)
    if os.path.isfile(exact):
        return exact
    try:
        names = os.listdir(tmp_dir)
    except OSError:
        return None
    for name in names:
        if name.startswith(key) and name != "render_still.png":
            return os.path.join(tmp_dir, name)
    return None


# ---------------------------------------------------------------- 像素读取与编码

def _read_bytes(path: str) -> tuple:
    """读文件字节(通道图的最终产出即该文件的字节)"""
    try:
        with open(path, "rb") as f:
            return f.read(), None
    except OSError as e:
        return None, api_error("Failed to read the captured pass", e)


def _read_pass_pixels(path: str) -> tuple:
    """把通道文件(单层 EXR 或 PNG)读回 HxWxC float32 数组, 返回 (数组, 错误信息)

    深度/法向/线稿三个通道需要像素级后处理, 故回读原始值:
    深度背景为 camera.clip_end(远超 1, 写 LDR 会被钳), 法向是带符号原始向量(写 LDR
    负数被钳成 0 会整张全黑), 线稿的信息全在 alpha(见 _edge_bytes).
    色彩空间设 Non-Color 以取回文件里的原值(不做线性->sRGB 往返; alpha 不受色彩空间影响).
    """
    try:
        img = bpy.data.images.load(path, check_existing=False)
    except RuntimeError as e:
        return None, api_error("Failed to load the captured pass", e)
    try:
        try:
            img.colorspace_settings.name = 'Non-Color'
        except Exception:  # noqa: BLE001 - 老构建无该色彩空间时按默认读回
            pass
        width, height = img.size
        if width == 0 or height == 0:
            return None, api_error("Captured pass is empty")
        buf = np.empty(width * height * img.channels, dtype=np.float32)
        img.pixels.foreach_get(buf)
        return buf.reshape(height, width, img.channels), None
    finally:
        try:
            bpy.data.images.remove(img)
        except Exception:  # noqa: BLE001 - 数据块已被外部清理时忽略
            pass


def _read_crypto_slot(raw: bytes) -> tuple:
    """把一层 Cryptomatte 的原始 EXR 字节读回为 HxWxC float32 数组, 返回 (数组, 错误信息)

    与 _decode_raw 的差别: 那条路要的是**最终字节**(只有深度/法向/线稿需要映射),
    这里要的是**像素本身** —— 哈希与覆盖率都在浮点里, 必须原值读回(故全程 32bit float).
    """
    fd, tmp_path = tempfile.mkstemp(suffix=".exr", prefix="ch_ai_crypto_")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as f:
            f.write(raw)
        return _read_pass_pixels(tmp_path)
    finally:
        _drop_path(tmp_path)


def _quantize(arr: np.ndarray) -> np.ndarray:
    """0-1 浮点数组四舍五入量化为 uint8"""
    return (np.clip(arr, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def _encode_png(rows: np.ndarray) -> bytes:
    """HxWx3/4 uint8 数组编码为内存 PNG 字节(纯 zlib, 不落盘)

    深度/法向是回读 EXR 后在 numpy 内映射出来的, 没有现成文件可读, 故按 PNG 规范手工组块:
    IHDR(8bit RGB/RGBA) + IDAT(逐行前置过滤字节 0 的 zlib 流) + IEND.
    Blender 像素缓冲行序自下而上(原点左下), PNG 行序自上而下, 编码前须上下翻转,
    否则成图整体倒置(实测); 两通道共用本编码器, 翻转一次即全体修正.
    """
    height, width = rows.shape[:2]
    channels = rows.shape[2]
    color_type = 2 if channels == 3 else 6
    rows = rows[::-1]
    raw = b"".join(b"\x00" + rows[y].tobytes() for y in range(height))

    def chunk(tag: bytes, payload: bytes) -> bytes:
        return (struct.pack(">I", len(payload)) + tag + payload
                + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", width, height, 8, color_type, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", zlib.compress(raw, _PNG_COMPRESS))
            + chunk(b"IEND", b""))


def _gray_to_rgb(gray01: np.ndarray) -> np.ndarray:
    """0-1 灰度(HxW)展开为 HxWx3"""
    return np.repeat(gray01[..., None], 3, axis=2)


def _depth_gray(pixels: np.ndarray, near: float, far: float, curve: str = 'LINEAR',
                background: float | None = None) -> np.ndarray:
    """EEVEE 深度(视空间 Z 米制, 背景 = camera.clip_end)按用户区间映射: 近端->1 远端->0

    线性曲线: 区间均分 256 级灰阶; 反深度曲线(INVERSE): 按 1/z(视差)在近端/远端锚定后
    线性化, 灰阶级数向近场集中(近处每米分到的级数远多于远景), 主体景深细节保留最多,
    与 ControlNet/MiDaS 等深度惯例一致; 深度值是米制距离, 背景像素(>= clip_end)置 0;
    近于近端的物体全部钳为 1, 远于远端的全部钳为 0(远端填 0 即"前景为 1 背景为 0"的目标语义);
    区间倒置时自动对调, 过窄/过近按 1e-6 兜底避免除零.
    """
    z = pixels[..., 0]
    if far < near:
        near, far = far, near
    if curve == 'INVERSE':
        near_safe = max(near, 1e-6)
        far_safe = max(far, near_safe + 1e-6)
        denom = 1.0 / near_safe - 1.0 / far_safe
        disp = 1.0 / np.maximum(z, 1e-6)
        depth = (disp - 1.0 / far_safe) / denom
    else:
        span = max(far - near, 1e-6)
        depth = 1.0 - (z - near) / span
    if background and background > 0:
        # EEVEE 的深度背景恒为 camera.clip_end(实测 clip_end=1000 -> 1000.55),
        # 几何体不会超出 clip_end, 故 >= 该值即为背景(留 0.1% 容差吸收浮点误差)
        depth = np.where(z >= background * 0.999, 0.0, depth)
    return np.clip(depth, 0.0, 1.0)


def _normal_bytes(pixels: np.ndarray, convention: str) -> bytes:
    """法向通道: 原始带符号向量 -> (n+1)/2 标准法线编码(背景法向 0 编码后为中灰)"""
    n = np.clip(pixels[..., :3], -1.0, 1.0).astype(np.float32, copy=True)
    if convention == 'DIRECTX':
        # DirectX 约定绿通道向下: 反转 G 后再做 (n+1)/2
        # (与 Blender 法向贴图节点对 DirectX 的处理一致, 即反转绿通道)
        n[..., 1] = -n[..., 1]
    return _encode_png(_quantize(n * 0.5 + 0.5))


def _edge_bytes(pixels: np.ndarray) -> bytes:
    """线稿通道: 笔画信息全在 alpha -> 按 1-alpha 映射为黑线白底

    实测本管线渲染写出的 Grease Pencil 通道像素 RGB 恒为 0,笔画信息全在 alpha
    (alpha 峰值 0.667, 抗锯齿边缘介于 0 与峰值之间); 故"白底黑线" = 灰阶 1-alpha:
    无笔画处 alpha=0 -> 纯白, 笔画核心处 alpha 最大 -> 最暗, 线性映射天然带抗锯齿.
    极少数构建若只回读 RGB(无 alpha 通道), 退化为按亮度取反(此时信息已在亮度里).
    """
    if pixels.shape[2] >= 4:
        line = 1.0 - pixels[..., 3]
    else:
        line = 1.0 - pixels[..., :3].mean(axis=2)
    return _encode_png(_gray_to_rgb(_quantize(line)))


def _decode_raw(key: str, raw: bytes, *, depth_near: float, depth_far: float,
                depth_curve: str, normal_convention: str,
                depth_background: float | None) -> tuple:
    """把通道的**原始落盘字节**转成最终参考图字节, 返回 (字节, 错误信息)

    深度/法向/线稿需要像素级后处理(原始字节写临时文件回读像素后在 numpy 内映射):
    深度按用户近/远区间映射灰阶, 法向按 (n+1)/2 编码, 线稿按 1-alpha 映射白底黑线;
    其余通道的原始字节即最终字节(直接返回).
    """
    if key not in ('depth', 'normal', 'edge'):
        return raw, None
    fd, tmp_path = tempfile.mkstemp(suffix=_EXTENSIONS[_PASS_FORMATS[key][0]],
                                    prefix="ch_ai_redecode_")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as f:
            f.write(raw)
        pixels, err = _read_pass_pixels(tmp_path)
        if err is not None:
            return None, err
        if key == 'depth':
            gray = _quantize(_depth_gray(pixels, depth_near, depth_far, depth_curve,
                                         depth_background))
            return _encode_png(_gray_to_rgb(gray)), None
        if key == 'normal':
            return _normal_bytes(pixels, normal_convention), None
        return _edge_bytes(pixels), None
    finally:
        _drop_path(tmp_path)


def _decode_pass(key: str, path: str, *, depth_near: float, depth_far: float,
                 depth_curve: str, normal_convention: str,
                 depth_background: float | None) -> tuple:
    """把某通道的落盘文件转成最终参考图字节, 返回 (原始落盘字节, 最终字节, 错误信息)

    原始字节供增量捕获缓存(解码参数变化时免渲染重解码, 见 lookup_group_cache);
    色彩空间设 Non-Color 取回文件原值(见 _read_pass_pixels).
    """
    raw, err = _read_bytes(path)
    if err is not None:
        return None, None, err
    final, err = _decode_raw(key, raw, depth_near=depth_near, depth_far=depth_far,
                             depth_curve=depth_curve,
                             normal_convention=normal_convention,
                             depth_background=depth_background)
    return raw, final, err


def _collect_frame(tmp_dir: str, entries: tuple, missing: list, passes: dict,
                   decode_kwargs: dict, passes_raw: dict | None = None) -> list:
    """把一帧落盘的通道文件读成最终参考图字节写入 passes, 返回本帧提示消息列表

    entries 为 (通道键, 出线名) 表; missing 为本帧节点组已报出的缺失通道(不重复报告);
    逐通道的任何一步失败都只跳过该通道并追加提示, 不打断整次捕获;
    passes_raw 不为 None 时同步记录各通道的**原始落盘字节**(增量捕获缓存用,
    解码参数变化时免渲染重解码, 见 lookup_group_cache).
    """
    notices = []
    for key, _socket in entries:
        if any(key == skipped for skipped, _ in missing):
            continue
        path = _pass_file(tmp_dir, key, _PASS_FORMATS[key][0])
        if path is None:
            notices.append(api_error("The pass was not written by the render, it was skipped", key))
            continue
        raw, data, err = _decode_pass(key, path, **decode_kwargs)
        if err is not None:
            notices.append(api_error("The captured pass could not be read, it was skipped", key))
            continue
        passes[key] = data
        if passes_raw is not None and raw is not None:
            passes_raw[key] = raw
    return notices


# ---------------------------------------------------------------- 蜡笔线稿

def _add_edge_gp(tmp, width_scale: float, material_borders: bool,
                 edge_preset: str = EDGE_PRESET_DEFAULT) -> tuple:
    """添加场景级蜡笔(LINEART_SCENE)并设置线宽与线条类型, 返回 (GP 对象, 提示消息或 None)

    线宽基准取 _EDGE_RADIUS_FALLBACK(固定 0.01 世界单位 radius), 再乘用户的宽度缩放系数;
    线条类型按 edge_preset 落到修改器的 use_contour/use_loose/use_crease/use_edge_mark/
    use_intersection/use_shadow/use_light_contour(见 EDGE_PRESETS);
    材质边界开关落在 Lineart 修改器 use_material(控制材质之间是否生成笔画,
    默认关与修改器出厂默认一致).

    用户场景零修改(含选择态): 添加操作器默认把蜡笔链到**当前活动集合**并夺走选中集与
    活动物体(属用户场景侧, 实测确认), 故用 temp_override 把 scene/view_layer/collection
    三件套都指向临时场景——落点直接进临时场景主集合, 用户侧的选择态与活动物体原样保留.
    下方解绑/链接仍保留为兜底: 覆写未被操作器采纳的构建上依旧落回用户集合, 需要搬移.
    落点固定为原点: 场景级线稿的笔画经物体变换补偿(实测两种落点的**世界坐标完全一致**),
    落点与出图无关, 不再沿用探测期遗留的视口坐标.
    """
    known = set(bpy.data.objects)
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=tmp.view_layers[0],
                                       collection=tmp.collection):
            bpy.ops.object.grease_pencil_add(type='LINEART_SCENE', align='WORLD',
                                             location=(0.0, 0.0, 0.0), scale=(1, 1, 1))
    except Exception:  # noqa: BLE001 - 物体上下文不可用(编辑模式等)时跳过边缘通道
        return None, "Failed to add the line art grease pencil, the edge pass was skipped"
    # 按对象增量取新建的蜡笔: 覆写下活动物体落在临时场景视图层, 走全局 active 取不到
    gp = next((obj for obj in bpy.data.objects if obj not in known), None)
    if gp is None:
        return None, "The line art grease pencil was not created, the edge pass was skipped"
    for col in list(gp.users_collection):
        col.objects.unlink(gp)
    tmp.collection.objects.link(gp)
    mod = gp.modifiers.get("Lineart")
    if mod is not None:
        # 固定基准线宽(0.01 世界单位)乘用户缩放系数, 钳到安全区间
        if hasattr(mod, "radius"):
            mod.radius = float(np.clip(_EDGE_RADIUS_FALLBACK * width_scale,
                                       _EDGE_RADIUS_MIN, _EDGE_RADIUS_MAX))
        # 材质边界: 材质之间是否生成笔画(开关缺失的旧构建按修改器默认)
        try:
            mod.use_material = bool(material_borders)
        except AttributeError:
            pass
        # 线条类型预设: 逐个落到修改器开关, 缺失的开关按修改器默认(不报错)
        for flag, value in EDGE_PRESETS.get(edge_preset,
                                            EDGE_PRESETS[EDGE_PRESET_DEFAULT]).items():
            try:
                setattr(mod, flag, value)
            except AttributeError:
                pass
    return gp, None


def _remove_gp(gp) -> None:
    """回收蜡笔对象,数据块, 以及线条画自动挂上的材质

    实测 bpy.data.grease_pencils.remove() **不清材质**: 场景线条画会给蜡笔数据挂一个名为
    Black 的材质, 只删对象与数据块会在 bpy.data.materials 里留下 Black / Black.001 ...
    残骸(每次捕获 +1), 故先按材质槽快照, 删完数据块后再回收用户数归零的那些.
    只回收本次新建且已无人引用的材质, 绝不触碰用户材质(users > 0 一律跳过).
    """
    if gp is None:
        return
    data = gp.data
    mats = list(getattr(data, "materials", ()) or ()) if data is not None else []
    try:
        bpy.data.objects.remove(gp, do_unlink=True)
    except Exception:  # noqa: BLE001 - 对象已不存在时忽略
        pass
    if data is not None:
        try:
            bpy.data.grease_pencils.remove(data)
        except Exception:  # noqa: BLE001 - 数据块已被连带删除时忽略
            pass
    for mat in mats:
        if mat is None:
            continue
        try:
            if mat.users == 0:
                bpy.data.materials.remove(mat)
        except Exception:  # noqa: BLE001 - 材质已被连带回收时忽略
            pass


# ---------------------------------------------------------------- 语义分割覆盖

# ---------------------------------------------------------------- 深度拾取

def sample_visible_depth(scene, grid: tuple = _DEPTH_PICK_GRID) -> tuple:
    """按相机视锥网格采样可见表面的视空间深度, 返回 (近端, 远端, 命中数, 错误信息)

    只做几何投射(复用 depsgraph 的求值场景与 BVH), **不渲染**, 故可一键"取景":
    取命中深度的 2%/98% 分位数作区间锚点, 两端各钳掉 2% 的极值, 避免个别极近/极远像素
    把区间拉爆,主体层次反被压扁(反深度曲线对 near 尤其敏感: near 偏小会把整幅画压到灰阶底端).

    深度口径与深度通道严格一致——**相机视空间 Z(米制)**而非到相机的欧氏距离, 二者在画面
    边角差异明显; 相机裁剪范围外的几何不参与(裁剪掉的东西不会出现在通道图里).
    仅支持透视相机: 正交/全景相机的视锥语义不同, 直接报错交由用户手填, 不做半对的猜测.

    取景结果只写到面板的深度范围属性上, 之后仍可手工修改; 采样网格与分位数见模块常量.
    """
    camera = getattr(scene, "camera", None)
    cam_data = getattr(camera, "data", None)
    if camera is None or cam_data is None or camera.type != 'CAMERA':
        return None, None, 0, api_error("The scene has no active camera")
    if getattr(cam_data, "type", 'PERSP') != 'PERSP':
        return None, None, 0, api_error("Depth picking supports perspective cameras only")
    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        frame = cam_data.view_frame(scene=scene)
    except Exception as e:  # noqa: BLE001 - 取景面/求值场景不可得时转成提示
        return None, None, 0, api_error("Failed to pick the depth range", e)
    columns, rows = max(2, int(grid[0])), max(2, int(grid[1]))
    mw = camera.matrix_world
    mw_inv = mw.inverted()
    origin = mw.translation
    clip_start = float(getattr(cam_data, "clip_start", 0.0))
    clip_end = float(getattr(cam_data, "clip_end", 0.0))
    depths = []
    for iy in range(rows):
        v = (iy + 0.5) / rows
        for ix in range(columns):
            u = (ix + 0.5) / columns
            # 视景面四角双线性插值取本根射线的目标点(view_frame 已含 sensor_fit/shift)
            target = (frame[0] * (1.0 - u) * (1.0 - v) + frame[1] * u * (1.0 - v)
                      + frame[2] * u * v + frame[3] * (1.0 - u) * v)
            to_target = (mw @ target) - origin
            if to_target.length_squared == 0.0:
                continue
            # ray_cast 返回 6 元组, 前两项即 (是否命中, 命中点世界坐标)
            hit, location = scene.ray_cast(depsgraph, origin, to_target.normalized())[:2]
            if not hit:
                continue
            depth = -(mw_inv @ location).z
            if depth <= 0.0 or depth < clip_start or (clip_end > 0.0 and depth > clip_end):
                continue
            depths.append(depth)
    if len(depths) < _DEPTH_PICK_MIN_HITS:
        return None, None, len(depths), api_error("No geometry was found inside the camera view")
    arr = np.asarray(depths, dtype=np.float64)
    near = float(np.percentile(arr, _DEPTH_PICK_NEAR_PCT))
    far = float(np.percentile(arr, _DEPTH_PICK_FAR_PCT))
    if far - near < 1e-4:
        # 极浅场景(单层平面/几何深度几乎一致): 撑开一点跨度, 否则映射退化成一片同色
        pad = max(near * 0.01, 1e-3)
        near, far = max(near - pad, 0.0), far + pad
    return round(near, 3), round(far, 3), len(depths), None


# ---------------------------------------------------------------- 主入口

class PassCaptureSession:
    """相机通道捕获会话(可按批驱动): open 建临时场景 -> render_next_frame 逐批渲染收集 -> close 回收

    供 CaptureViewRefs 的模态算子按批驱动(批与批之间让出主线程更新等待进度);
    capture_camera_passes 是一次性薄封装(open + 逐批 + close 一口气跑完, 供脚本与测试直调).
    批序列: 主组(合并结果/深度/法向/漫射颜色/AO, 用户世界; 勾选分割时附加 cryptomatte 各层)
    -> 线稿组(场景线条画); 未命中增量缓存的组才进批, 故常见情形只有一批, 甚至一批都不渲.
    单次渲染仍是同步阻塞的, 会话只把批与批之间交还给调用方.
    wanted 为通道键 -> 是否捕获; 其余参数与 capture_camera_passes 同名同义.
    """

    def __init__(self, scene, wanted: dict, *, ao_distance: float = 1.0,
                 depth_near: float = 1.0, depth_far: float = 20.0,
                 depth_curve: str = 'LINEAR', normal_convention: str = 'OPENGL',
                 edge_width_scale: float = 1.0, material_borders: bool = False,
                 edge_preset: str = EDGE_PRESET_DEFAULT,
                 clamp_long_edge: int = 0, reuse_cache: bool = True,
                 render_samples: int = _EEVEE_SAMPLES,
                 crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                 crypto_slots: int = CRYPTO_SLOT_COUNT,
                 smooth_seg_edges: bool = False):
        self._scene = scene
        self._reuse_cache = reuse_cache
        self._wanted = dict(wanted)
        self._ao_distance = ao_distance
        self._depth_near, self._depth_far = depth_near, depth_far
        self._depth_curve = depth_curve
        self._normal_convention = normal_convention
        self._edge_width_scale = edge_width_scale
        self._material_borders = material_borders
        self._edge_preset = edge_preset
        self._clamp_long_edge = _sane_clamp(clamp_long_edge)
        try:
            self._render_samples = max(1, int(render_samples))
        except (TypeError, ValueError):
            self._render_samples = _EEVEE_SAMPLES
        self._crypto_source = crypto_source
        self._crypto_slots = _crypto_slots_used(crypto_slots)
        # 解码参数(不进渲染键): 切换它只重解码, 不触发任何渲染
        self._smooth_seg_edges = bool(smooth_seg_edges)
        # 生命周期状态: 渲染批次定义(每批为该批要渲的组列表)与待渲染批次下标
        self._batches = []
        self._pending = []
        self._layers = {}
        # 增量缓存: 各组渲染键,命中缓存的组,本次真正渲过的组
        self._keys = {}
        self.reused_groups = []
        self._rendered_groups = []
        self.passes: dict = {}
        self.passes_raw: dict = {}
        self.notices: list = []
        self.size = None
        self._tmp = None
        self._ng = None
        self._gp = None
        self._tmp_dir = None
        self._decode_kwargs = None
        self._opened = False
        self._closed = False

    def open(self):
        """建立临时场景与公共渲染设置, 返回错误信息(None 成功; 失败时已自行回收)"""
        if self._opened or self._closed:
            return api_error("The capture session has already been started")
        scene = self._scene
        if scene.camera is None:
            return api_error("The scene has no active camera")
        engine_id = _eevee_engine_id()
        if engine_id is None:
            return api_error("The EEVEE engine is not available in this build")
        try:
            _sweep_tmp_root()
            self._tmp_dir = _new_tmp_dir()
            tmp = bpy.data.scenes.new("CH_AI_PassCapture")
            self._tmp = tmp
            _link_user_scene(tmp, scene)
            tmp.world = scene.world
            tmp.camera = scene.camera
            _copy_render_common(tmp, scene, self._clamp_long_edge)
            _copy_color_management(tmp, scene)
            tmp.render.engine = engine_id
            try:
                tmp.eevee.taa_render_samples = self._render_samples
            except AttributeError:
                pass  # 引擎注册表无该属性时用默认采样
            tmp.render.image_settings.file_format = 'PNG'
            self.size = _render_size(tmp.render)
            depth_background = None
            cam_data = getattr(scene.camera, "data", None)
            if cam_data is not None and hasattr(cam_data, "clip_end"):
                depth_background = float(cam_data.clip_end)
            # 解码参数: 只有深度用区间/曲线, 只有法向用约定, 线稿只按 alpha 映射(其余通道直接取字节)
            self._decode_kwargs = dict(depth_near=self._depth_near, depth_far=self._depth_far,
                                       depth_curve=self._depth_curve,
                                       normal_convention=self._normal_convention,
                                       depth_background=depth_background)
            # 渲染批次: 每批一次渲染调用, 批内各视图层在同一次调用里各自落盘
            # - 主组 + 线稿组: 两者的场景态互不干扰(蜡笔只进线稿组的集合), 故可同批
            # - 线稿组: 需蜡笔对象与集合排除, 单独一批且该批只渲这一个视图层
            # 增量缓存: 先按组算渲染键, 命中的组直接复用原始字节(免渲染), 只把未命中的排进批次
            groups = needed_groups(self._wanted)
            self._keys = {group: group_render_key(
                group, scene, ao_distance=self._ao_distance,
                edge_width_scale=self._edge_width_scale,
                material_borders=self._material_borders,
                edge_preset=self._edge_preset,
                clamp_long_edge=self._clamp_long_edge,
                render_samples=self._render_samples,
                crypto_source=self._crypto_source,
                crypto_slots=self._crypto_slots) for group in groups}
            reused = (lookup_group_cache(self._keys, self._wanted, self._crypto_source,
                                         self._crypto_slots) if self._reuse_cache else {})
            for group, raw in reused.items():
                self.passes_raw.update(raw)
                self.notices.extend(_decode_collected(
                    raw, _group_entries(group, self._wanted, self._crypto_source,
                                        self._crypto_slots),
                    self.passes, self._decode_kwargs))
            self.reused_groups = sorted(reused)
            stale = [group for group in groups if group not in reused]
            # 未失效的组不进批次; 都失效时合成一批(多个视图层在同一次渲染调用里各自落盘)
            self._batches = [stale] if stale else []
            self._pending = list(range(len(self._batches)))
            self._opened = True
        except Exception as e:  # noqa: BLE001 - 建场任一步的意外异常统一转成错误信息
            self.close()
            return api_error("Failed to prepare the pass capture", e)
        return None

    def _prepare_batch(self, index: int) -> tuple:
        """准备第 index 批: 建所需视图层,按组开通道,装配该批特有的场景态

        返回 (视图层表, 是否跳过渲染). 视图层**按批按需创建** —— 场景里存在但本批不需要的
        视图层也会被 blend 一并渲染, 故跑主组那批时线稿视图层尚未建出来,
        从而不会被顺带渲染(线稿组只在它自己那一批创建).
        """
        tmp = self._tmp
        groups = self._batches[index]
        layers = _ensure_view_layers(tmp, groups)
        self._layers.update(layers)
        skip = False
        for group in groups:
            _enable_passes(layers[group], group, self._wanted, self._ao_distance,
                           self._crypto_source)
            if group == GROUP_LINEART:
                self._gp, gp_notice = _add_edge_gp(tmp, self._edge_width_scale,
                                                   self._material_borders,
                                                   self._edge_preset)
                if gp_notice is not None:
                    # 蜡笔建不出来(编辑模式等)时跳过本批渲染, 只留提示
                    self.notices.append(gp_notice)
                    skip = True
                else:
                    _move_to_lineart_collection(tmp, self._gp)
        return layers, skip

    def render_next_frame(self) -> tuple:
        """渲染下一批并收集其通道, 返回 (本批新增提示, 错误信息, 是否全部完成)

        单次渲染内部同步阻塞; 错误时调用方应 close 放弃(已完成的批次不 commit).
        """
        if not self._opened or self._closed:
            return [], api_error("The capture session is not open"), True
        if not self._pending:
            return [], None, True
        index = self._pending.pop(0)
        tmp, tmp_dir = self._tmp, self._tmp_dir
        try:
            layers, skip = self._prepare_batch(index)
            groups = self._batches[index]
            if not skip:
                entries = tuple((layers[group],
                                 _group_entries(group, self._wanted, self._crypto_source,
                                                self._crypto_slots))
                                for group in groups)
                # 单组批用 layer= 精确限定视图层; 多组批此时场景里恰好只有这些视图层
                layer_name = layers[groups[0]].name if len(groups) == 1 else None
                self._ng, missing = _build_capture_group(tmp, tmp_dir, entries)
                self.notices.extend(msg for _, msg in missing)
                err = _render_frame(tmp, layers[groups[0]], tmp_dir, layer=layer_name)
                if err is not None:
                    return [], err, False
                for group in groups:
                    self.notices.extend(_collect_frame(
                        tmp_dir,
                        _group_entries(group, self._wanted, self._crypto_source,
                                       self._crypto_slots),
                        missing, self.passes, self._decode_kwargs, self.passes_raw))
                self._rendered_groups.extend(groups)
                _drop_node_group(self._ng)
                self._ng = None
        except Exception as e:  # noqa: BLE001 - 渲染/收集任一步的意外异常统一转成错误信息
            return [], api_error("Failed to capture the camera passes", e), False
        return [], None, not self._pending

    def has_pending(self) -> bool:
        """是否还有未渲染的批次(全部命中增量缓存时为 False, 调用方可直接提交)"""
        return bool(self._pending)

    def commit_cache(self) -> None:
        """把本次真正渲染过的组写入增量缓存(未重渲的组保留原有条目)

        只在渲染成功后调用; 失败路径不写, 免得把半份结果当有效缓存.
        """
        raw_by_group = {}
        for group in self._rendered_groups:
            raw = {channel: self.passes_raw[channel]
                   for channel, _socket in _group_entries(group, self._wanted,
                                                          self._crypto_source,
                                                          self._crypto_slots)
                   if channel in self.passes_raw}
            if raw:
                raw_by_group[group] = raw
        if raw_by_group:
            store_group_cache(self._keys, raw_by_group, self.size, self.notices)

    def collect(self) -> tuple:
        """收集最终通道字典(按参考优先序排列), 返回 (通道字典, 参考图尺寸)"""
        self._decode_segmentation()
        ordered = {key: self.passes[key] for key in PASS_ORDER if key in self.passes}
        return ordered, self.size

    def _decode_segmentation(self) -> None:
        """把 Cryptomatte 各层原始字节合成为 segmentation 通道的 PNG 字节

        名字取用户场景的全部物体: cryptomatte 只哈希被渲染到的物体, 多给的候选名不会命中,
        无副作用. 逐层读回像素后交给 utils.cryptomatte 做哈希反查(同像素按覆盖率择优).
        这一整段是**解码期**工作, 不触发任何渲染.
        """
        if not self._wanted.get('segmentation'):
            return
        raw_layers = [self.passes_raw.get(key) for key in CRYPTO_SLOT_KEYS]
        if not any(raw_layers):
            self.notices.append(api_error(
                "The pass is not available from this engine, it was skipped", 'segmentation'))
            return
        arrays = []
        for raw in raw_layers:
            if raw is None:
                continue
            arr, err = _read_crypto_slot(raw)
            if err is not None:
                self.notices.append(api_error(
                    "The captured pass could not be read, it was skipped", 'segmentation'))
                return
            arrays.append(arr)
        names = _segmentation_names(self._scene, self._crypto_source)
        # 边缘是否抗锯齿由解码参数决定(出厂关闭=台阶, 打开=按覆盖率加权平均成平滑过渡)
        image, unmatched, err = decode_segmentation(arrays, names,
                                                    antialias=self._smooth_seg_edges)
        if err is not None or image is None:
            self.notices.append(api_error(
                "The captured pass could not be read, it was skipped", 'segmentation'))
            return
        if unmatched > _SEG_UNMATCHED_WARN:
            # 口径**按像素**: 该像素有覆盖却一个给出的名字都没匹配上(不是"某个槽位没匹配上").
            # 常见成因是该依据下确实没有对应名字(如按材质分割而物体没有材质), 那些像素保持黑.
            # 注意: 像素只要**任一**槽位匹配到名字就不计未解析 —— 故本提示反映的是"整片未解析
            # 的面积", 不反映重叠边缘的小面积归属错误(边缘按覆盖率择优, 见 cryptomatte 模块).
            self.notices.append(api_error(
                "Part of the segmentation map did not match any name in the chosen source, "
                "those pixels stay black", f"{unmatched * 100:.1f}%"))
        self.passes['segmentation'] = _encode_png(image)

    def close(self):
        """回收临时场景/蜡笔/临时目录(幂等, 用户场景零残留)

        只回收**渲染环境**, 不动收集结果: passes / passes_raw / _keys / notices / size
        在 close() 之后仍可读(调用方按 collect -> commit_cache -> close 的顺序使用).
        若将来要在此清空它们, 必须同步调整 ai_render.CaptureViewRefs._finish 的调用序.
        """
        if self._closed:
            return
        self._closed = True
        _drop_node_group(self._ng)
        self._ng = None
        tmp = self._tmp
        if tmp is not None:
            try:
                bpy.data.scenes.remove(tmp)
            except Exception:  # noqa: BLE001 - 已回收时忽略
                pass
        self._tmp = None
        self._layers = {}
        _remove_gp(self._gp)
        self._gp = None
        _drop_path(self._tmp_dir)
        self._tmp_dir = None


# ---- 增量捕获缓存(按渲染组分别缓存原始落盘字节) ----
# 组是缓存失效的最小单位: 改线宽只让线稿组失效,改 AO 距离只让主组失效, 两者互不牵连.
# 「本次要哪些通道」刻意**不进渲染键** —— 改由子集判定(所需通道 ⊆ 该组已产出通道)负责,
# 于是取消一个通道不再触发重渲(旧实现里那条子集检查被精确相等判定挡成了死代码).
# 解码参数(深度区间/曲线/法线约定)本就不入键, 改它们只重解码,不重渲.
_PASS_RAW_CACHE: dict | None = None
# 缓存原始字节总量上限(超出即整体丢弃, 退化为下次全量渲染).
# 缓存规模本身**有界**(最多 main/lineart 两个组, 各组通道固定), 这里是病态防护:
# 实测 2048² 下三层 cryptomatte 约 201 MB, 加深度/法向 EXR 约 280 MB —— 上限给 512 MB
# 不会在常规分辨率触发, 又能挡住 4K/8K 把内存吃满.
_RAW_CACHE_MAX_BYTES = 512 * 1024 * 1024
# 通道键 -> 所属渲染组(cryptomatte 各层归主组), 用于按组拆分缓存
_CHANNEL_GROUP = {key: group for group, entries in GROUP_OUTPUTS.items() for key, _ in entries}
_CHANNEL_GROUP.update({key: GROUP_MAIN for key in CRYPTO_SLOT_KEYS})


def group_of_channel(key: str) -> str | None:
    """通道键所属的渲染组(未知键返回 None)"""
    return _CHANNEL_GROUP.get(key)


def needed_groups(wanted: dict) -> list:
    """本次需要的渲染组(按批次顺序: 主组在前, 线稿组在后)"""
    return [group for group in (GROUP_MAIN, GROUP_LINEART) if _group_entries(group, wanted)]


def _color_management_key(scene) -> tuple:
    """用户色彩管理的关键项

    只有**合并结果**通道遵循用户色彩管理(其余通道 save_as_render=False 已隔离), 故它只进
    主组键. 漏掉它会导致「改了 view transform 却命中缓存,合并结果不跟着变」——
    实测该回归由 test_capture_passes 的「合并结果随 view transform 变化」断言抓出.
    """
    settings = getattr(scene, "view_settings", None)
    if settings is None:
        return ()
    return (settings.view_transform, settings.look, settings.exposure, settings.gamma)


def group_render_key(group: str, scene, *, ao_distance: float = 1.0,
                     edge_width_scale: float = 1.0, material_borders: bool = False,
                     edge_preset: str = EDGE_PRESET_DEFAULT,
                     clamp_long_edge: int = 0, render_samples: int = _EEVEE_SAMPLES,
                     crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                     crypto_slots: int = CRYPTO_SLOT_COUNT) -> tuple:
    """某组的**渲染键**: 只含改变该组渲染结果的参数

    刻意不含「本次要哪些通道」(由子集判定负责), 也**不含其它组的参数** ——
    线宽不进主组键,AO 距离不进线稿组键, 这样改一个参数只影响它真正影响的那个组.
    公共项(钳制后尺寸/相机名/相机世界矩阵)两组都含: 它们会改变任何一组的渲染结果.
    采样数两组都含: 两组共享同一个场景采样数.
    """
    cap_w, cap_h = resolve_capture_size(scene, _sane_clamp(clamp_long_edge))
    cam = scene.camera
    common = ((cap_w, cap_h), cam.name if cam is not None else "",
              tuple(cam.matrix_world) if cam is not None else (), render_samples)
    if group == GROUP_MAIN:
        # 主组是唯一有通道遵循用户色彩管理的组(合并结果), 故色彩管理必须进它的键;
        # 分割依据与落盘层数只影响主组(它们决定主组开哪条 pass,出几层)
        return ((ao_distance, crypto_source, _crypto_slots_used(crypto_slots))
                + _color_management_key(scene) + common)
    if group == GROUP_LINEART:
        # 线稿走 alpha 映射(save_as_render=False), 与色彩管理无关
        return (edge_width_scale, material_borders, edge_preset) + common
    return common


def lookup_group_cache(keys: dict, wanted: dict, crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                       crypto_slots: int = CRYPTO_SLOT_COUNT) -> dict:
    """按组查缓存, 返回可复用的 {组: {通道键: 原始落盘字节}}

    命中条件: 该组渲染键与缓存一致, **且**本次所需通道 ⊆ 该组已产出通道(子集判定).
    子集判定是「取消一个通道不重渲」得以成立的关键.
    """
    cached = (_PASS_RAW_CACHE or {}).get("groups", {})
    reused = {}
    for group, key in keys.items():
        entry = cached.get(group)
        if not entry or entry.get("key") != key:
            continue
        needed = {channel for channel, _socket in _group_entries(group, wanted,
                                                                 crypto_source, crypto_slots)}
        raw = entry.get("raw") or {}
        if needed and needed <= set(raw):
            reused[group] = dict(raw)
    return reused


def store_group_cache(keys: dict, raw_by_group: dict, size, notices) -> None:
    """把本次渲染产出的各组原始字节并入缓存(未重渲的组保留原有条目)"""
    global _PASS_RAW_CACHE
    groups = dict((_PASS_RAW_CACHE or {}).get("groups", {}))
    for group, raw in raw_by_group.items():
        if raw:
            groups[group] = {"key": keys.get(group), "raw": dict(raw)}
    if not groups:
        _PASS_RAW_CACHE = None
        return
    total = sum(len(blob) for entry in groups.values() for blob in entry["raw"].values())
    if total > _RAW_CACHE_MAX_BYTES:
        # 超上限即**整体丢弃**(不留半份): 下次捕获走全量渲染, 绝不静默留一个"看似命中,
        # 实则缺通道"的缓存. 缓存规模本身有界(最多两个组, 各组通道固定), 这里是病态防护.
        _PASS_RAW_CACHE = None
        return
    _PASS_RAW_CACHE = {"groups": groups, "size": size, "notices": list(notices)}


def clear_raw_cache() -> None:
    """清空增量缓存(载入新 .blend 时调用, 防跨文件误用上一份场景的原始字节)"""
    global _PASS_RAW_CACHE
    _PASS_RAW_CACHE = None


def _segmentation_names(scene, crypto_source: str) -> list:
    """该分割依据下参与解码的名字表

    与 Blender 侧的哈希口径严格对应(`cryptomatte.cc:564` 的 `add_ID` 取 `&id.name[2]`,
    即**去掉两字符类型前缀的裸名**):
    - OBJECT: 场景物体名;
    - MATERIAL: 数据块里的全部材质名(于是同材质的物体同色);
    - ASSET: 资产根物体名 —— 沿父级链走到顶(`cryptomatte.cc:255` 同款算法).
    多给的候选名不会命中, 无副作用(解码只对像素里实际出现过的哈希做反查).
    """
    if crypto_source == CRYPTO_SOURCE_MATERIAL:
        return [material.name for material in bpy.data.materials if material.name]
    if crypto_source == CRYPTO_SOURCE_ASSET:
        roots = []
        for obj in scene.objects:
            root = obj
            while root.parent is not None:
                root = root.parent
            if root.name:
                roots.append(root.name)
        return roots
    return [obj.name for obj in scene.objects if obj.name]


def _decode_collected(raw_map: dict, entries: tuple, passes: dict, decode_kwargs: dict) -> list:
    """把**已有的**原始字节解码为最终字节(免渲染路径复用缓存时用), 返回提示列表

    与 _collect_frame 的分工: 那条路从落盘文件读原始字节, 这条路直接拿缓存里的字节,
    解码逻辑共用 _decode_raw.
    """
    notices = []
    for channel, _socket in entries:
        raw = raw_map.get(channel)
        if raw is None:
            notices.append(api_error(
                "The pass is not available from this engine, it was skipped", channel))
            continue
        final, err = _decode_raw(channel, raw, **decode_kwargs)
        if err is not None:
            notices.append(api_error(
                "The captured pass could not be read, it was skipped", channel))
            continue
        passes[channel] = final
    return notices


def capture_camera_passes(context, use_combined: bool, use_depth: bool, use_normal: bool,
                          use_segmentation: bool, use_edge: bool, use_diffuse: bool,
                          use_ao: bool, *, ao_distance: float = 1.0,
                          depth_near: float = 1.0, depth_far: float = 20.0,
                          depth_curve: str = 'LINEAR',
                          normal_convention: str = 'OPENGL', edge_width_scale: float = 1.0,
                          material_borders: bool = False,
                          edge_preset: str = EDGE_PRESET_DEFAULT,
                          clamp_long_edge: int = 0, render_samples: int = _EEVEE_SAMPLES,
                          crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                          crypto_slots: int = CRYPTO_SLOT_COUNT,
                          smooth_seg_edges: bool = False) -> tuple:
    """渲染场景相机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)

    PassCaptureSession 的一次性薄封装: open + 逐批渲染 + close 一口气跑完
    (供脚本与测试直调; 模态算子改用会话按批驱动, 在批间更新进度).
    通道字典按参考优先序排列: {'combined': 字节, 'depth': 字节, 'normal': 字节,
    'segmentation': 字节, 'edge': 字节, 'diffuse': 字节, 'ao': 字节};
    size 为 (宽, 高) 即本次渲染的实际像素尺寸(各通道一致);
    提示消息为 api_error 对象(常量标题 + 动态通道键), 由交互层 describe_error 翻译后上报.
    全部通道由 EEVEE 出: 合并结果/深度/法向/漫射颜色/AO 一帧(用户世界), 语义分割一帧
    由 Cryptomatte 解码得到), 线稿一帧(场景线条画); 引擎不可用或通道缺失时跳过并写提示消息.
    通道参数: ao_distance 为 AO 遮蔽计算距离; depth_near/depth_far 为深度图白/黑映射区间
    (场景单位), depth_curve 选线性/反深度量化曲线(反深度把 8bit 灰阶向近端集中, 主体景深
    细节保留最多); normal_convention 选 OpenGL/DirectX(差异在绿通道方向); edge_width_scale
    为线稿宽度缩放系数, material_borders 控制线稿的材质之间是否生成笔画;
    clamp_long_edge 为输出长边钳制上限(<=0 表示不钳制, 直接用 Blender 输出分辨率乘百分比).
    """
    wanted = {'combined': use_combined, 'depth': use_depth, 'normal': use_normal,
              'diffuse': use_diffuse, 'ao': use_ao,
              'segmentation': use_segmentation, 'edge': use_edge}
    session = PassCaptureSession(
        context.scene, wanted,
        ao_distance=ao_distance, depth_near=depth_near, depth_far=depth_far,
        depth_curve=depth_curve, normal_convention=normal_convention,
        edge_width_scale=edge_width_scale, material_borders=material_borders,
        edge_preset=edge_preset,
        clamp_long_edge=clamp_long_edge, render_samples=render_samples,
        crypto_source=crypto_source, crypto_slots=crypto_slots,
        smooth_seg_edges=smooth_seg_edges)
    err = session.open()
    if err is not None:
        session.close()
        return {}, None, session.notices, err
    while session.has_pending():
        _frame_notices, frame_err, done = session.render_next_frame()
        if frame_err is not None:
            session.close()
            return {}, session.size, session.notices, frame_err
        if done:
            break
    ordered, size = session.collect()
    session.commit_cache()
    session.close()
    return ordered, size, session.notices, None
