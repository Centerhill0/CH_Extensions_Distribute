"""
实时同步处理器模块

提供以下功能:
- sync_scripts_now: 脚本列表快照立即刷新(供脚本写入后调用)
- sync_images_now: 纹理/效果图两个图像列表快照立即刷新(供图像生成后调用)
- move_list_item: 列表高亮条目上移/下移(排序写进数据块自定义属性, 持久且跨机)
- activate_script_top: 生成/提取/写回后置顶该脚本并同步快照, 按偏好聚焦并高亮
- activate_image: 图像生成/捕获预览后同步快照, 把图像列表高亮指向该图并聚焦图像编辑器
  (top=True 时先把新产物置顶到列表第一位, 纹理与效果图生成共用)
- select_image_by_name: 按数据块名选中图像(预览区缩略图选中联动, 与点击列表行同款)
- gallery_visible_items / select_gallery_value: 缩略图可见项(过滤+上限)与选中值回写(仅写可见项)
- 脚本/对话/图像列表活跃索引 update 回调: 点击行按偏好聚焦编辑器或切换图像编辑器
- open_chat_message: 按偏好把当前高亮对话消息转出到 AI_Chat.txt 并聚焦文本编辑器
- dump_chat_history: 对话历史写入 AI_Chat_History.json 文本块(对话存于 WM, 每次变动后落块随 blend 保存)
- dump_image_refs / dump_capture_params: 参考图引用(JSON 文本块)与效果图捕获参数(场景自定义属性)持久化
- load_post 处理器: 快照存于 WM 跨文件保留, 载入后立即对齐; 对话/参考图按当前文件恢复, 捕获参数从场景恢复
- 周期计时器: 兜底刷新(文本块/图像数据块增删改不触发 depsgraph)
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接
- 快照重建与重入护栏机制见 common.ui.list_snapshot
"""

import bpy
from bpy.types import Context

from ...common.ui.list_snapshot import is_syncing, rebuild_if_changed, set_guarded, set_index
from .preference import get_prefs
from .utils import (
    AI_CHAT_HISTORY_NAME,
    AI_CHAT_TEXT_NAME,
    AI_IMAGE_REFS_NAME,
    AI_IMAGE_PREFIX,
    AI_REF_PREFIX,
    AI_RENDER_PREFIX,
    AI_SCRIPT_PREFIX,
    AI_TEXTURE_PREFIX,
    focus_image_editors,
    focus_text_editors,
    parse_chat_history,
    parse_image_refs,
    serialize_chat_history,
    serialize_image_refs,
    write_text_block,
)

# 脚本列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0

# 列表排序键的数据块自定义属性名(随 blend 保存, 跨机一致)
_ORDER_KEY = "ch_ai_order"

# 等待状态三件组(scope -> status_<scope>/wait_<scope>/cancel_<scope>)的作用域全集,
# 与 ai_generate 的 status_scope 取值一致('test' 供偏好连通性测试用, 无面板进度与中断按钮)
_WAIT_SCOPES = ("script", "chat", "texture", "render", "test")


def _datablock(names_kind: str, name: str):
    """按列表种类取条目对应的真实数据块"""
    if names_kind == 'TEXT':
        return bpy.data.texts.get(name)
    return bpy.data.images.get(name)


def _sorted_names(names: list, names_kind: str) -> list:
    """按数据块自定义属性 ch_ai_order 排序(未排序条目按名序排后, 稳定)"""
    def key(name: str):
        block = _datablock(names_kind, name)
        order = block.get(_ORDER_KEY) if block is not None else None
        return (0, order, name) if order is not None else (1, 0, name)
    return sorted(names, key=key)


def _prefixed_names(collection, prefixes: tuple, names_kind: str) -> list:
    """按前缀过滤数据块名并排序(列表快照的名收集单一入口; prefixes 走 startswith 元组匹配)"""
    names = [b.name for b in collection if b.name.startswith(prefixes)]
    return _sorted_names(names, names_kind)


def _script_names() -> list:
    """脚本列表名称序列(仅 AI 前缀脚本; 长文描述块与对话查看块无此前缀, 天然排除)"""
    return _prefixed_names(bpy.data.texts, (AI_SCRIPT_PREFIX,), 'TEXT')


def _texture_image_names() -> list:
    """纹理面板图像列表的名称序列(生成贴图 "AI Tex" 与图像 "AI Bmp" 前缀过滤;
    前缀含尾随分隔符, 回落名是纯前缀本身)"""
    return _prefixed_names(bpy.data.images, (AI_TEXTURE_PREFIX, AI_IMAGE_PREFIX), 'IMAGE')


def _render_image_names() -> list:
    """效果图主列表的名称序列(仅生成结果 "AI Render" 前缀; 通道预览图走 _pass_image_names)"""
    return _prefixed_names(bpy.data.images, (AI_RENDER_PREFIX,), 'IMAGE')


def _pass_image_names() -> list:
    """效果图通道预览迷你列表的名称序列(固定名捕获预览 "AI Ref: " 前缀过滤)"""
    return _prefixed_names(bpy.data.images, (AI_REF_PREFIX,), 'IMAGE')


def move_list_item(target: str, direction: str) -> bool:
    """列表高亮条目与相邻条目交换排序位置, 返回是否移动

    target: 'SCRIPT'/'TEXTURE'/'RENDER'(与算子枚举标识一致); direction: 'UP'/'DOWN'.
    首次移动时把当前顺序全量写入数据块自定义属性(此后移动为纯交换),
    快照顺序随 _sorted_names 反映, 排序持久且不随快照重建丢失.
    """
    wm = bpy.context.window_manager
    if target == 'SCRIPT':
        state, idx_name, kind, names = wm.ch_ai_state, "scripts_active_index", 'TEXT', _script_names()
        getter = lambda n: bpy.data.texts.get(n)
    elif target == 'TEXTURE':
        state, idx_name, kind, names = wm.ch_ai_texture_state, "images_active_index", 'IMAGE', _texture_image_names()
        getter = lambda n: bpy.data.images.get(n)
    elif target == 'RENDER':
        state, idx_name, kind, names = wm.ch_ai_render_state, "images_active_index", 'IMAGE', _render_image_names()
        getter = lambda n: bpy.data.images.get(n)
    else:
        return False

    idx = getattr(state, idx_name)
    j = idx - 1 if direction == 'UP' else idx + 1
    if not (0 <= idx < len(names)) or not (0 <= j < len(names)):
        return False
    blocks = [getter(n) for n in names]
    if any(b is None for b in blocks):
        return False
    # 首次移动: 全量分配显式排序号(缺省用当前显示位置), 之后移动即纯交换
    for pos, block in enumerate(blocks):
        if block.get(_ORDER_KEY) is None:
            block[_ORDER_KEY] = pos
    a, b = blocks[idx], blocks[j]
    a[_ORDER_KEY], b[_ORDER_KEY] = b[_ORDER_KEY], a[_ORDER_KEY]
    # 立即重建快照反映新顺序(不等计时器节拍), 高亮跟随移动后的条目(护栏内写入, 不触发点击回调)
    if kind == 'TEXT':
        sync_scripts_now()
    else:
        sync_images_now()
    set_index(state, idx_name, j)
    return True


def reset_wait_state(state):
    """清空 AI 请求等待标志(各面板的进度文案/已等待秒数/中断标志三件组)

    等待状态只由等待模态清理, 而模态按窗口持有: 等待期间载入 .blend 或关闭承载窗口会让模态
    被丢弃, 标志却留在 WM 里 → 之后所有请求都被"已有请求在跑"永久拒绝, 只能重启 Blender.
    故 load_post 与模态挂载失败时都调用本函数回收(全 scope 一并清).
    """
    for scope in _WAIT_SCOPES:
        setattr(state, f"status_{scope}", "")
        setattr(state, f"wait_{scope}", 0)
        setattr(state, f"cancel_{scope}", False)


def sync_scripts_now():
    """立即重建脚本列表快照(生成/调试写入文本块后调用, 不等计时器节拍)"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())


def sync_images_now():
    """立即重建纹理与效果图两个图像列表快照(图像生成/捕获预览后调用, 不等计时器节拍)

    效果图侧同时重建通道预览迷你列表快照(AI Ref: 前缀);
    重建后把缩略图选中值对齐到当前高亮项: 条目被删除/改名导致快照变化时,
    缩略图的选中态不会停在已不存在的名字上.
    """
    wm = bpy.context.window_manager
    rebuild_if_changed(wm.ch_ai_texture_state, "images", "images_active_index",
                       'IMAGE', _texture_image_names())
    rebuild_if_changed(wm.ch_ai_render_state, "images", "images_active_index",
                       'IMAGE', _render_image_names())
    rebuild_if_changed(wm.ch_ai_render_state, "pass_images", "pass_images_active_index",
                       'IMAGE', _pass_image_names())
    for state_attr in ("ch_ai_texture_state", "ch_ai_render_state"):
        _align_gallery_to_index(getattr(wm, state_attr))


def _align_gallery_to_index(state):
    """把缩略图选中值对齐到列表当前高亮项(护栏内写入, 不触发缩略图回调)"""
    idx = state.images_active_index
    if not 0 <= idx < len(state.images):
        return
    select_gallery_value(state, state.images[idx].name)


def gallery_visible_items(state) -> list:
    """预览区缩略图当前可见的列表条目: 按名称过滤(不区分大小写) + 显示条数上限截断

    顺序即列表快照顺序(生成置顶后新产物在前), 故上限截断保留的是列表前若干项.
    """
    pattern = state.gallery_filter.strip().lower()
    limit = state.gallery_limit
    visible = []
    for item in state.images:
        if pattern and pattern not in item.name.lower():
            continue
        visible.append(item)
        if limit > 0 and len(visible) >= limit:
            break
    return visible


def select_gallery_value(state, name: str) -> bool:
    """把缩略图选中值指向该图像(仅当它在当前过滤/上限下可见; 护栏内写入, 不触发回调)

    不在候选表内的标识写进动态枚举会抛 TypeError(控制台留 traceback), 故先判可见性;
    返回是否写入(未写入表示该图当前在缩略图视野外, 选中态保持原样, 不影响列表高亮).
    """
    if state.gallery_image == name:
        return False
    if not any(item.name == name for item in gallery_visible_items(state)):
        return False
    set_guarded(state, "gallery_image", name)
    return True


def _highlight_image(state, name: str, collection: str = "images",
                     index_name: str = "images_active_index") -> bool:
    """把图像列表高亮与预览区画廊选中值指向该图(护栏内写入, 不触发点击联动), 返回是否命中

    collection/index_name 支持通道迷你列表(pass_images)复用; 画廊选中值仅主列表同步.
    """
    items = getattr(state, collection)
    idx = next((i for i, item in enumerate(items) if item.name == name), None)
    if idx is None:
        return False
    set_index(state, index_name, idx)
    if collection == "images":
        # 缩略图选中值与列表高亮保持同步(被过滤/上限挡住时不写, 见 select_gallery_value)
        select_gallery_value(state, name)
    return True


def select_image_by_name(context: Context, state, name: str) -> bool:
    """按数据块名选中图像: 高亮列表条目并按偏好切换图像编辑器, 返回是否命中

    供预览区画廊的选中回调调用(与点击列表行同款联动, 只是来源是画廊缩略图).
    """
    if not _highlight_image(state, name):
        return False
    if get_prefs().use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focus_image_editors(context, image)
    return True


def activate_image(context: Context, name: str, top: bool = False) -> int:
    """图像生成/捕获预览后: 同步快照, 把图像列表高亮指向该图并聚焦图像编辑器

    top=True 时先置顶(排序号取当前最小减一, 与脚本列表同款: 新产物排列表第一位,
    不随名称序下沉); 返回聚焦到的图像编辑器区域数(0 表示没有打开的图像编辑器, 由调用方提示).
    """
    if top:
        image = bpy.data.images.get(name)
        if image is not None:
            orders = [i.get(_ORDER_KEY) for i in bpy.data.images if i.get(_ORDER_KEY) is not None]
            image[_ORDER_KEY] = (min(orders) - 1) if orders else 0
    sync_images_now()
    image = bpy.data.images.get(name)
    focused = 0
    if image is not None:
        focused, _ = focus_image_editors(context, image)
    for state_attr in ("ch_ai_texture_state", "ch_ai_render_state"):
        _highlight_image(getattr(context.window_manager, state_attr), name)
    return focused


def activate_pass_image(context: Context, name: str):
    """通道预览捕获后: 同步快照, 把通道迷你列表高亮指向该图并聚焦图像编辑器

    通道预览图(AI Ref: 前缀)不进效果图主列表(列表分离), 高亮走迷你列表;
    与 activate_image 的 top 置顶不同, 迷你列表顺序由快照(名称排序)决定, 无置顶.
    """
    sync_images_now()
    state = context.window_manager.ch_ai_render_state
    _highlight_image(state, name, collection="pass_images", index_name="pass_images_active_index")
    image = bpy.data.images.get(name)
    if image is not None:
        focus_image_editors(context, image)


def activate_script_top(context: Context, name: str):
    """提取代码落块后: 置顶(排序号设为当前最小减一), 同步快照, 按偏好聚焦并高亮该脚本"""
    block = bpy.data.texts.get(name)
    if block is None:
        return
    orders = [b.get(_ORDER_KEY) for b in bpy.data.texts if b.get(_ORDER_KEY) is not None]
    block[_ORDER_KEY] = (min(orders) - 1) if orders else 0
    sync_scripts_now()
    if get_prefs().use_auto_open_scripts:
        focus_text_editors(context, block)
    state = context.window_manager.ch_ai_state
    for idx, item in enumerate(state.scripts):
        if item.name == name:
            set_index(state, "scripts_active_index", idx)
            return


def on_scripts_index_update(self, context: Context):
    """脚本列表活跃索引回调: 开关开启时, 用户点击行把文本编辑器聚焦到该脚本"""
    if not get_prefs().use_auto_open_scripts:
        return
    if is_syncing() or not 0 <= self.scripts_active_index < len(self.scripts):
        return
    text = bpy.data.texts.get(self.scripts[self.scripts_active_index].name)
    if text is not None:
        focus_text_editors(context, text)


def open_chat_message(context: Context, state):
    """按偏好把当前高亮对话消息写入 AI_Chat.txt 并聚焦文本编辑器

    供对话活跃索引 update 回调(点击列表行)与回复写入后的联动调用;
    转出后完整内容在文本编辑器阅读, 列表行内仅显示首行.
    """
    if not get_prefs().use_auto_open_chat:
        return
    idx = state.chat_active_index
    if not 0 <= idx < len(state.chat_messages):
        return
    text, _ = write_text_block(AI_CHAT_TEXT_NAME, state.chat_messages[idx].content)
    focus_text_editors(context, text)


def on_chat_index_update(self, context: Context):
    """对话消息活跃索引回调: 开关开启时, 用户点击行把该消息转出到文本编辑器"""
    open_chat_message(context, self)


def on_image_index_update(self, context: Context):
    """纹理/效果图图像列表活跃索引回调: 用户点击行时同步缩略图选中态, 并按偏好切换图像编辑器

    缩略图选中值与"自动打开图像"偏好无关(列表切换后缩略图的选中态必须跟着走),
    编辑器切换才受偏好控制.
    """
    if is_syncing() or not 0 <= self.images_active_index < len(self.images):
        return
    name = self.images[self.images_active_index].name
    # 缩略图选中态跟到点击的条目(护栏内写入, 不触发缩略图回调造成二次聚焦)
    select_gallery_value(self, name)
    if get_prefs().use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focus_image_editors(context, image)


def on_pass_index_update(self, context: Context):
    """通道预览迷你列表活跃索引回调: 点击行按偏好把图像编辑器切换到该通道预览图

    与主列表点击同款偏好控制; 迷你列表不联动缩略图画廊(通道图不进主列表与画廊).
    """
    if is_syncing() or not 0 <= self.pass_images_active_index < len(self.pass_images):
        return
    if not get_prefs().use_auto_open_images:
        return
    image = bpy.data.images.get(self.pass_images[self.pass_images_active_index].name)
    if image is not None:
        focus_image_editors(context, image)


def _focus_ref_mini_list(state, context: Context, coll_attr: str, index_attr: str) -> None:
    """参考图迷你列表点击联动: 按偏好把图像编辑器切到高亮的参考图(缺图占位条目跳过)"""
    if is_syncing() or not 0 <= getattr(state, index_attr) < len(getattr(state, coll_attr)):
        return
    if not get_prefs().use_auto_open_images:
        return
    ref = getattr(state, coll_attr)[getattr(state, index_attr)]
    if ref.image is not None:
        focus_image_editors(context, ref.image)


def on_ref_index_update(self, context: Context):
    """纹理面板参考图迷你列表活跃索引回调: 点击行按偏好把图像编辑器切换到该参考图

    与效果图风格参考图迷你列表同款(缺图占位条目跳过; 描述行随高亮切换由面板 draw 跟随).
    """
    _focus_ref_mini_list(self, context, "ref_images", "ref_images_active_index")


def on_style_index_update(self, context: Context):
    """风格参考图迷你列表活跃索引回调: 点击行按偏好把图像编辑器切换到该风格图

    与通道迷你列表同款(描述行随高亮切换由面板 draw 自动跟随, 无需在此处理).
    """
    _focus_ref_mini_list(self, context, "style_images", "style_images_active_index")


# ------------------------------------------------------------
# 对话历史持久化(随 blend 保存, 载入恢复)
# ------------------------------------------------------------


def dump_chat_history(state) -> None:
    """把当前对话历史写入 AI_Chat_History.json 文本块(随 blend 保存)

    对话消息存于 WM 本不随 blend 保存, 重启即失; 每次变动后调用本函数落块,
    载入时经 _on_load_post 恢复. 全程兜住异常: 持久化失败不影响对话本身.
    """
    try:
        pairs = [(m.role, m.content) for m in state.chat_messages]
        write_text_block(AI_CHAT_HISTORY_NAME, serialize_chat_history(pairs, state.chat_active_index))
    except Exception:
        pass


def _restore_chat(state) -> None:
    """用当前 blend 的持久化对话历史替换 WM 对话(对话逐文件独立, 随文件切换/载入恢复)"""
    block = bpy.data.texts.get(AI_CHAT_HISTORY_NAME)
    parsed = parse_chat_history(block.as_string()) if block is not None else None
    state.chat_messages.clear()
    state.chat_script_name = ""
    if parsed is None:
        state.chat_active_index = 0
        return
    messages, active = parsed
    for role, content in messages:
        item = state.chat_messages.add()
        item.role = role
        item.content = content
    state.chat_active_index = active


# ------------------------------------------------------------
# 参考图引用与捕获参数持久化(随 blend 保存, 载入恢复)
# ------------------------------------------------------------

# 恢复期间静默 dump(条目描述的 update 回调在重建时会触发)
_restore_refs_in_progress = False

# 效果图捕获参数的场景自定义属性键(随 blend 保存; props 的 update 回调写入, 此处恢复)
_CAPTURE_PARAMS_KEY = "ch_ai_capture_params"


def dump_image_refs() -> None:
    """把两组参考图引用写入 AI_Image_Refs.json 文本块(随 blend 保存, 载入时恢复)

    纹理面板参考图与效果图风格参考图同文件分节; 描述编辑(条目 update 回调)与
    结构变动(加载/移除/清描述)都会触发; 恢复期间静默. 全程兜住异常:
    持久化失败不影响引用本身.
    """
    if _restore_refs_in_progress:
        return
    try:
        wm = bpy.context.window_manager
        texture_refs = [(ref.image.name if ref.image is not None else "", ref.description)
                        for ref in wm.ch_ai_texture_state.ref_images]
        render_refs = [(ref.image.name if ref.image is not None else "", ref.description)
                       for ref in wm.ch_ai_render_state.style_images]
        write_text_block(AI_IMAGE_REFS_NAME, serialize_image_refs(texture_refs, render_refs))
    except Exception:
        pass


def _restore_image_refs() -> None:
    """从 AI_Image_Refs.json 恢复两组参考图引用(按数据块名找回图像, 缺失保条目占位)

    无存档块的文件一律清空现役引用: 引用指向的图像数据块本就属于旧文件,
    载入新文件后指针必然悬空, 留着只会误导.
    """
    global _restore_refs_in_progress
    block = bpy.data.texts.get(AI_IMAGE_REFS_NAME)
    parsed = parse_image_refs(block.as_string()) if block is not None else None
    texture_refs, render_refs = parsed if parsed is not None else ([], [])
    wm = bpy.context.window_manager
    _restore_refs_in_progress = True
    try:
        for state, collection, index_name, refs in (
                (wm.ch_ai_texture_state, "ref_images", "ref_images_active_index", texture_refs),
                (wm.ch_ai_render_state, "style_images", "style_images_active_index", render_refs)):
            coll = getattr(state, collection)
            coll.clear()
            for name, description in refs:
                item = coll.add()
                item.image = bpy.data.images.get(name) if name else None
                item.description = description
            set_guarded(state, index_name, 0)
    finally:
        _restore_refs_in_progress = False


def capture_params_snapshot(rstate) -> dict:
    """把场景绑定的捕获参数收为可序列化 dict(场景自定义属性写入与恢复共用一表)"""
    return {
        "depth_range": [rstate.depth_range[0], rstate.depth_range[1]],
        "depth_curve": rstate.depth_curve,
        "normal_convention": rstate.normal_convention,
        "edge_width_scale": rstate.edge_width_scale,
        "use_material_borders": rstate.use_material_borders,
        "ao_distance": rstate.ao_distance,
    }


def dump_capture_params(rstate, scene) -> None:
    """把场景绑定的捕获参数写入场景自定义属性(随 blend 保存; props 的 update 回调触发)"""
    scene[_CAPTURE_PARAMS_KEY] = capture_params_snapshot(rstate)


def restore_capture_params(scene) -> None:
    """从场景自定义属性恢复效果图捕获参数(载入时调用; 场景无存档时保持出厂默认)

    场景属性读回的是 IDProperty 组/数组而非原生 dict/list, 先归一化再逐项校验
    类型与枚举合法值, 护栏内写回(护栏避免 update 回调再触发场景回写).
    """
    stored = scene.get(_CAPTURE_PARAMS_KEY)
    if stored is None:
        return
    try:
        stored = dict(stored)
    except (TypeError, ValueError):
        return
    rstate = bpy.context.window_manager.ch_ai_render_state
    depth = stored.get("depth_range")
    if depth is not None:
        try:
            depth = [float(v) for v in depth]
        except (TypeError, ValueError):
            depth = None
    if depth and len(depth) == 2:
        set_guarded(rstate, "depth_range", (depth[0], depth[1]))
    curve = stored.get("depth_curve")
    if curve in ('INVERSE', 'LINEAR'):
        set_guarded(rstate, "depth_curve", curve)
    convention = stored.get("normal_convention")
    if convention in ('OPENGL', 'DIRECTX'):
        set_guarded(rstate, "normal_convention", convention)
    scale = stored.get("edge_width_scale")
    if isinstance(scale, (int, float)) and scale > 0:
        set_guarded(rstate, "edge_width_scale", float(scale))
    borders = stored.get("use_material_borders")
    if isinstance(borders, bool):
        set_guarded(rstate, "use_material_borders", borders)
    distance = stored.get("ao_distance")
    if isinstance(distance, (int, float)) and distance >= 0:
        set_guarded(rstate, "ao_distance", float(distance))


# ------------------------------------------------------------
# 文件 -> 列表同步
# ------------------------------------------------------------


def _sync_all():
    """全量同步: 有变化才重建脚本与两个图像列表快照"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())
    sync_images_now()


def _on_load_post(*_args):
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐; 对话/参考图按文件恢复,
    捕获参数从场景自定义属性恢复, 等待标志一并回收(模态已失效)

    另清两个跨文件不失效的模块级全局状态(延迟导入以避开 handlers<->operators 循环依赖):
    - 通道捕获发送缓存(_PASS_CAPTURE_CACHE)与参数指纹: 不重启 Blender 载入另一文件时,
      旧文件的通道字节仍在缓存, 会被误判为"已捕获"而把上个场景的通道图当参考图发出,
      必须随文件切换清空.
    - 自动命名待办表(_auto_name_pending): 残留的旧文件命名结果落地时会按名找回图像,
      找不到即静默跳过(无害), 但随文件切换清掉更干净.
    """
    try:
        wm = bpy.context.window_manager
        reset_wait_state(wm.ch_ai_state)
        _restore_chat(wm.ch_ai_state)
        _restore_image_refs()
        restore_capture_params(bpy.context.scene)
        # 跨文件失效的模块级缓存: 发送缓存/指纹与自动命名待办一并回收
        from .operators.ai_render import clear_pass_cache
        from .operators.ai_generate import clear_auto_name_pending
        clear_pass_cache()
        clear_auto_name_pending()
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _sync_timer():
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register():
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister():
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
