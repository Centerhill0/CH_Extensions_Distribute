# 服务商注册表重构 —— 设计文档

> 状态：**已实施**（方案 A，2026-10-12）。
> 目标：把散落在 8 个文件、约 30 处 `if provider == 'XXX'` 分支的服务商知识，
> 收敛为**每服务商一条声明式记录**，加商从「改 8 处」变为「加 1 条 + 改 1 处枚举字面量」。

## 关键约束：i18n 提取器要求 `*_items` 必须是 List 字面量

`.zcode/i18n_sweep.py`（第 141 行）只识别「`xxx_items` 名字 ← `ast.List`/`ast.Tuple` 字面量」。
任何推导式 / 字典 / 函数调用派生的 `*_items` 都会被提取器跳过，导致该英文文案从插件词典
消失、中文界面退化显示英文。

因此最终采用**方案 A（方向反转）**：
- 服务商枚举 / 候选模型 / 思考档位的 `*_items` **字面量本体放在 `utils/provider_registry.py`**
  （保持 `xxx_items = [元组字面量]` 形态，供提取器扫描）。
- dataclass 记录的 `thinking_items` 字段引用这些字面量（`tuple(xxx_items)`）；候选模型表则由
  `items.py` 直接引用同名元组（不进 dataclass）。
- `items.py` / `preference.py` 需要时**直接从 `provider_registry` 导入**这些 `*_items` 名
  （`items.py` 仅 re-export 供本地 `*_MODEL_ITEMS` 表使用的候选模型字面量，不再转发枚举/思考档）。

**收益权衡**：行为类知识（尺寸修正 / 请求体 / 响应解析 / thinking 组装 / 额度 / 测试策略 /
能力开关）已从 8 处收敛到 1 处 dataclass；枚举字面量因 i18n 硬约束保留为 `*_items` 字面量。
「加商」需改两处：注册表加一条记录 + 注册表加一组 `*_items` 枚举字面量。

---

## 1. 背景与问题

现状诊断见 `provider-extension-checklist.md`。核心问题：

- 服务商知识被切成 **7 类**，用独立的 `if provider == 'XXX'` 串联，跨 **8 个文件**
- 存在 **4 个非平凡坑**（见 §5），任何重构遗漏都会引入隐性 bug
- 加一个商需要记住并同时改动 8 处，漏一处即错乱

---

## 2. 目标与非目标

**目标：**
- 加商 = 在注册表加一条记录，其余代码全部「查表」
- 消除 §5 中 4 个坑的重复 / 漂移风险

**非目标：**
- **不改任何现有行为**（逻辑等价重构）
- 不引入第三方依赖（保持纯标准库 `dataclass`）
- 不改 `CUSTOM` 的既有语义（保留其「无约束 + 负向剔除」特例）

---

## 3. 字段设计

### 3.1 图像服务商 `ImageProvider`

> **注意**：本节为**字段设计稿**。最终实施采用「方案 A（方向反转）」后，枚举显示名与
> 描述（原 `label` / `description` 字段）**不进入 dataclass**——它们由 `*_items` 枚举字面量
> 承载（i18n 提取器硬约束要求 `*_items` 保持 List 字面量形态）。故 `provider_registry.py`
> 中两个 dataclass 的**实际字段**比下表少 `label` / `description` 两项，其余一致。

```python
# 新文件: utils/provider_registry.py（或并入 image_client.py 顶部，见 §7 讨论）
from dataclasses import dataclass
from typing import Callable

@dataclass(frozen=True)
class ImageProvider:
    key: str                      # 'VOLCENGINE' | 'DASHSCOPE' | 'CUSTOM'
    # ---- 接入 ----
    base_url: str                 # 端点（CUSTOM 为 ''）
    api_key_attr: str             # 偏好密钥属性名
    default_model_t2i: str
    default_model_edit: str       # 与 t2i 分字段（坑 4）
    # ---- 参考图 ----
    ref_count: int                # 张数上限（0 = 不限）
    ref_edge: int                 # 最长边（0 = 不限）
    # ---- 提示词 ----
    token_budget: int             # 0 = 不估算
    token_hard: bool              # 是否硬截断
    # ---- 输出尺寸 ----
    resolve_size: Callable        # (model, w, h) -> (w, h)，保留函数回调（坑 2）
    size_sep: str                 # 'x' | '*'
    output_limits: tuple | None   # 面板提醒用（最严格模型汇总）
    # ---- 请求 ----
    endpoint_path: str            # 请求路径后缀
    build_payload: Callable       # 请求体构造（承载 CUSTOM 负向剔除，坑 1）
    parse_response: Callable      # 响应解析
    # ---- 能力开关（标志位只在下述位置生效，缺消费点的字段不产生运行时行为）----
    supports_negative_prompt: bool  # 请求侧单口 effective_negative_prompt（4 个操作器调用）+ UI draw_negative_row
    supports_seed: bool             # UI 种子行 + image_common.effective_seed（是否本地抽取回填）
    supports_watermark: bool        # 暂无读取方（行为硬编码在 build_payload 内）
    supports_response_format: bool  # 暂无读取方（行为硬编码在 build_payload 内）
```

### 3.2 文本服务商 `TextProvider`

```python
@dataclass(frozen=True)
class TextProvider:
    key: str
    base_url: str
    api_key_attr: str
    default_model: str
    thinking_items: tuple         # 档位表（合并坑 3 的 T5）
    build_thinking_extras: Callable  # (thinking) -> dict（合并坑 3 的 T6）
    script_max_tokens: int | None     # 输出额度策略（T7）
    test_strategy: str            # 'balance' | 'ping'（T8）
```

---

## 4. 字段 ↔ 现状映射表（逐项可追溯）

### 图像侧

| 注册表字段 | 现状来源（文件 · 符号） | 迁移后 |
| --- | --- | --- |
| （枚举显示名/描述） | `provider_registry.py` · `image_provider_items` 字面量 | 由 `*_items` 字面量承载，不进 dataclass |
| `base_url` | `image_client.py` · `PROVIDER_ENDPOINTS` | 查表 |
| `api_key_attr` | `resolve_image_endpoint` if 链 | 查表 |
| `default_model_t2i` / `default_model_edit` | `PROVIDER_DEFAULT_MODELS` | 查表（两字段） |
| （候选模型表） | `items.py` · `PROVIDER_MODEL_ITEMS` | 由 `items.py` 直接引用注册表同名元组（不进 dataclass） |
| `ref_count` / `ref_edge` | `REF_IMAGE_LIMITS` + `_DEFAULT_REF_LIMITS` | 查表（兜底并入 `CUSTOM` 记录） |
| `token_budget` / `token_hard` | `PROMPT_TOKEN_BUDGETS` | 查表 |
| `resolve_size` | `resolve_output_size` if 链 + `_resolve_*_size` | 改 `PROVIDERS[p].resolve_size(...)` |
| `size_sep` | `format_size` | 查表 |
| `output_limits` | `OUTPUT_LIMITS` | 查表 |
| `endpoint_path` / `build_payload` / `parse_response` | `request_image` 内 if 链 | 查表 |
| `supports_negative_prompt` | 4 处操作器 + 1 处 UI(`blocks.py`) 的 `provider == 'DASHSCOPE'` | 查表（请求侧经 `image_common.effective_negative_prompt` 单口，UI 侧 `draw_negative_row`） |
| （生效服务商解析） | `resolve_image_service` / `props.py` 覆盖下拉等 **8+ 处**的「`GLOBAL` 则取偏好，否则取面板」 | 查表（`effective_provider(state, prefs, 'image')` 单口） |

### 文本侧

| 注册表字段 | 现状来源 | 迁移后 |
| --- | --- | --- |
| `base_url` / `api_key_attr` | `CHAT_PROVIDER_ENDPOINTS` + `resolve_chat_endpoint` | 查表 |
| `default_model` | `CHAT_PROVIDER_DEFAULT_MODELS` | 查表 |
| （候选模型表） | `items.py` · `TEXT_PROVIDER_MODEL_ITEMS` | 由 `items.py` 直接引用注册表同名元组（不进 dataclass） |
| `thinking_items` | `props.py` · `_thinking_items_for` | 查表 |
| `build_thinking_extras` | `ai_client.py` · `build_thinking_extras` | 查表 |
| `script_max_tokens` | `ai_generate.py` · `_script_max_tokens` | 查表 |
| `test_strategy` | `service_test.py` · `_text_test_worker` | 查表 |
| （生效服务商解析） | `ai_generate.py` / `ui/panels/ai_text_service.py` 等处的「`GLOBAL` 则取偏好，否则取面板」 | 查表（`effective_provider(state, prefs, 'text')` 单口） |

---

## 5. 四个关键坑的规避方案

| 坑 | 风险 | 规避 |
| --- | --- | --- |
| **坑 1** CUSTOM 负向剔除 | 只按「正向下发」设计会漏掉 CUSTOM 少传 `response_format`/`watermark`/`seed` | `build_payload` 保留为回调；`supports_*` 三个能力开关显式表达 |
| **坑 2** Seedream 模型级总像素 | 服务商粒度注册表会丢失 4.0/4.5/5.0-lite/pro 的细分 | `resolve_size` 保留为**函数回调**，不做纯数据 |
| **坑 3** thinking 知识重复 | `_thinking_items_for` 与 `build_thinking_extras` 两处各自维护，档位标识可能漂移 | 合并为 `thinking_items` + `build_thinking_extras` 单字段对，档位标识由 `thinking_items` 统一定义 |
| **坑 4** t2i/edit 双默认模型 | 若合并为一个字段，会重新引入 2026-10-11 已修过的「面板选了 Pro、请求发 Flash」缺陷 | `default_model_t2i` 与 `default_model_edit` **保持两字段分离** |

---

## 6. 迁移步骤（建议顺序）

1. 新建 `utils/provider_registry.py`，定义两个 dataclass + 三条图像记录 + 两条文本记录 + `CUSTOM` 兜底记录
2. `items.py`：`image_provider_items` / `provider_items` / 两个 `*_MODEL_ITEMS` 改为**从注册表生成**
3. `image_client.py`：`resolve_output_size` / `request_image` / `ref_image_limits` / `prompt_token_budget` / `output_limits` / `format_size` 退化为查表
4. `ai_client.py`：`resolve_chat_endpoint` / `build_thinking_extras` 退化为查表
5. `preference.py`：`_PRESETS` / `_IMAGE_PRESETS` 从注册表派生；`draw` 的 `key_attr` 分支改查 `api_key_attr`
6. `props.py`：`_thinking_items_for` 改查表
7. `ai_generate.py`：`_script_max_tokens` 改查表
8. `service_test.py`：`_text_test_worker` 改查 `test_strategy`
9. 4 处负向提示判断改查 `supports_negative_prompt`
10. 回归测试（见 §8）

---

## 7. 已定决策（实施结果）

1. **文件组织**：✅ 独立 `utils/provider_registry.py`——它横跨文本/图像两侧，是新的「最底层」。
2. **dataclass vs 纯 dict**：✅ `dataclass(frozen=True)`——字段名自文档化，拼错字段名会直接报错。
3. **重构范围**：✅ 图像 + 文本两侧一起做，一次性收干净。
4. **提示词外置**（后续追加）：✅ 独立 `utils/prompts.py`，加版本号 + 契约自检（见 README 开发者指南）。
5. **生效服务商 / 模型兜底链的单口**（2026-10-12 全量审查落地批次 B/C）：✅ 新增
   `provider_registry.effective_provider(state, prefs, kind)`——「`GLOBAL` 取偏好、覆盖档取面板」
   的分支原散落 8+ 处，现收敛为图像 / 文本各一处单口；新增
   `image_client.resolve_panel_image_model(state, prefs, panel_attr, fallback_attr)`——模型兜底链
   单口，面板侧两个薄封装（`image_common.resolve_edit_model` / `ai_texture.resolve_texture_model`）
   只承载「读哪个字段」的差异。两者均为**内部协作 API**，不列入 `utils/__init__.py` 的 `__all__`，
   消费方走深路径导入。

---

## 8. 回归测试清单（已全部通过）

- [x] 三个图像商（方舟 / 百炼 / 自定义）的 `resolve_output_size` 结果与重构前**逐像素一致**
- [x] `request_image` 对三家请求体与重构前**逐字段一致**（尤其 CUSTOM 的负向剔除）
- [x] 文本侧 `build_thinking_extras` 对 DeepSeek / GLM / 通用的输出一致
- [x] 偏好面板下拉 / 覆盖下拉的候选表与重构前一致
- [x] `_apply_image_preset` / `_apply_preset` 回填行为一致
- [x] 负向提示判断在新商 / 旧商上的表现一致（已查表化 `supports_negative_prompt`）
- [x] 参考图限制、token 预算、输出限制提醒文案一致
- [x] 真机热重载 + 全功能回归通过（作者实测）
