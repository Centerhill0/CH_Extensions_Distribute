"""
数据块与世界环境算子模块

提供以下功能:
- DatablockDelete: 删除图像/世界/集合数据块并立即刷新列表
  (集合默认只删集合, +Shift 删除层级: 内部物体与子集合一并删)
- WorldUnlink: 解除世界与场景的关联(默认); Shift 点击删除世界数据块
- WorldAssign: 把指定世界指认为场景世界
- WorldNew: 新建世界并指认为场景世界
- CollectionNew: 新建灯光集合(CLS_NN_ 编号命名, 挂到 Lights 集合下)
"""

import re

import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import highlight_item, id_collection, resolve_id
from ...utils import LIGHTS_COLLECTION_NAME, LIGHT_COLLECTION_PREFIX, real_user_count, relink_collection_contents, remove_collection_hierarchy
from ._base import deletion_guard


class DatablockDelete(Operator):
    """删除列表中的数据块(图像/世界/集合)"""

    bl_idname = "ch.datablock_delete"
    bl_label = "Delete"
    bl_description = "Delete this data-block\n+Shift: For collections, also delete the objects and child collections inside"
    bl_options = {'REGISTER', 'UNDO'}

    id_name: StringProperty(name="Name")  # type: ignore
    id_kind: StringProperty(name="Kind")  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore
    hierarchy: BoolProperty(name="Delete Hierarchy", description="Also delete the objects and child collections inside the collection", default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        datablock = resolve_id(self.id_kind, self.id_name)
        if datablock is None:
            return {'CANCELLED'}
        self.hierarchy = self.id_kind == 'COLLECTION' and event is not None and event.shift
        if self.hierarchy:
            # 层级删除连带删内部物体与子集合, 确认文案须说清破坏范围(通用 users 文案只提清引用)
            blocked = deletion_guard(self, context, event, datablock, users_msg="Collection hierarchy delete also removes the objects and child collections inside ({} users)")
        else:
            blocked = deletion_guard(self, context, event, datablock)
        if blocked is not None:
            return blocked
        return self.execute(context)

    def execute(self, context: Context):
        datablock = resolve_id(self.id_kind, self.id_name)
        collection = id_collection(self.id_kind)
        if datablock is None or collection is None:
            return {'CANCELLED'}
        # 直调(EXEC_DEFAULT)绕过 invoke: 未确认且仍有使用者时拒绝, 避免静默清空节点引用
        if datablock.library is not None:
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        users = real_user_count(datablock)
        if users > 0 and not self.confirmed:
            self.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
            return {'CANCELLED'}
        if self.hierarchy and self.id_kind == 'COLLECTION':
            # 大纲"删除层级"语义: 集合内的物体与子集合一并删除(默认只删集合数据块)
            remove_collection_hierarchy(datablock)
        elif self.id_kind == 'COLLECTION':
            # 只删集合数据块: 内部物体先改挂 Lights(或场景集合), 否则会孤儿化并从场景消失
            fallback = context.scene.collection.children.get(LIGHTS_COLLECTION_NAME)
            if fallback is None or fallback is datablock:
                fallback = context.scene.collection
            relink_collection_contents(datablock, fallback)
            collection.remove(datablock, do_unlink=True)
        else:
            collection.remove(datablock, do_unlink=True)
        # 数据块移除与活跃索引夹取统一交给快照重建, 不再按 bpy.data 总数手算(过滤列表会错位)
        refresh_lists()
        return {'FINISHED'}


class CollectionActivateToggle(Operator):
    """勾选/取消勾选灯光集合的激活标记(勾选的集合过滤灯光列表, 可多选, 全不勾选显示全部)"""

    bl_idname = "ch.collection_activate_toggle"
    bl_label = "Activate Collection"
    bl_description = "Toggle this collection as the lights list filter (none checked shows all lights)"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(name="Collection")  # type: ignore

    def execute(self, context: Context):
        coll = bpy.data.collections.get(self.collection_name)
        if coll is None:
            return {'CANCELLED'}
        coll.ch_lights_active = not coll.ch_lights_active
        return {'FINISHED'}


class CollectionIsolate(Operator):
    """隔离灯光集合(在灯光集合之间隐藏其它集合, 再点恢复; +Ctrl 渲染隔离)"""

    bl_idname = "ch.collection_isolate"
    bl_label = "Isolate"
    bl_description = "Isolate this light collection among the light collections (hide the others), click again to restore\n+Ctrl: Isolate in the render"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(name="Collection")  # type: ignore
    isolate_render: BoolProperty(name="Isolate Render", default=False, description="Isolate the collection in the render instead of the viewport")  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.isolate_render = bool(event is not None and event.ctrl)
        return self.execute(context)

    def execute(self, context: Context):
        coll = bpy.data.collections.get(self.collection_name)
        if coll is None:
            return {'CANCELLED'}
        siblings = [c for c in bpy.data.collections if c.name.startswith(LIGHT_COLLECTION_PREFIX) and c is not coll]
        attr = "hide_render" if self.isolate_render else "hide_viewport"
        any_visible = any(not getattr(c, attr) for c in siblings)
        for sibling in siblings:
            setattr(sibling, attr, any_visible)
        setattr(coll, attr, False)
        return {'FINISHED'}


class WorldUnlink(Operator):
    """解除世界与场景的关联(默认); Shift 点击删除世界数据块"""

    bl_idname = "ch.world_unlink"
    bl_label = "Unlink World"
    bl_description = "Unlink this world from the scene (keep the data-block)\n+Shift: Delete the world data-block directly"
    bl_options = {'REGISTER', 'UNDO'}

    world_name: StringProperty(name="World")  # type: ignore
    delete: BoolProperty(name="Delete", description="Delete the world data-block instead of only unlinking it", default=False)  # type: ignore
    confirmed: BoolProperty(options={'HIDDEN'}, default=False)  # type: ignore

    def invoke(self, context: Context, event: Event):
        self.delete = bool(event is not None and event.shift)
        if self.delete:
            world = bpy.data.worlds.get(self.world_name)
            if world is not None:
                blocked = deletion_guard(self, context, event, world)
                if blocked is not None:
                    return blocked
        return self.execute(context)

    def execute(self, context: Context):
        world = bpy.data.worlds.get(self.world_name)
        if world is None:
            return {'CANCELLED'}
        if self.delete:
            # 直调绕过 invoke: 未确认且有场景仍在引用时拒绝删除
            if world.library is not None:
                self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
                return {'CANCELLED'}
            users = real_user_count(world)
            if users > 0 and not self.confirmed:
                self.report({'WARNING'}, report("Data-block is used by {} users, deleting it clears them").format(users))
                return {'CANCELLED'}
            bpy.data.worlds.remove(world, do_unlink=True)
            refresh_lists()
            return {'FINISHED'}
        if context.scene.world is not world:
            self.report({'INFO'}, report("World is not linked to the scene"))
            return {'CANCELLED'}
        context.scene.world = None
        refresh_lists()
        return {'FINISHED'}


class WorldAssign(Operator):
    """把该世界指认为场景世界"""

    bl_idname = "ch.world_assign"
    bl_label = "Assign World"
    bl_description = "Use this world as the scene world"
    bl_options = {'REGISTER', 'UNDO'}

    world_name: StringProperty(name="World")  # type: ignore

    def execute(self, context: Context):
        world = bpy.data.worlds.get(self.world_name)
        if world is None:
            return {'CANCELLED'}
        context.scene.world = world
        return {'FINISHED'}


class WorldNew(Operator):
    """新建世界并指认为场景世界"""

    bl_idname = "ch.world_new"
    bl_label = "New World"
    bl_description = "Create a new world and use it as the scene world"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        world = bpy.data.worlds.new("World")
        context.scene.world = world
        refresh_lists()
        return {'FINISHED'}


class CollectionNew(Operator):
    """新建灯光集合(CLS_NN_ 编号命名, 挂到 Lights 集合下)"""

    bl_idname = "ch.collection_new"
    bl_label = "New Collection"
    bl_description = "Create a new light collection (auto-numbered CLS_NN_) inside the Lights collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        # 编号自动检测: 取现存 CLS_NN 的最大序号 +1(两位数, 用户命名跟在序号的下划线后,
        # 双击重命名补写, 如 CLS_01_主光)
        numbers = []
        for coll in bpy.data.collections:
            matched = re.match(re.escape(LIGHT_COLLECTION_PREFIX) + r"(\d+)", coll.name)
            if matched is not None:
                numbers.append(int(matched.group(1)))
        new_coll = bpy.data.collections.new("{}{:02d}_".format(LIGHT_COLLECTION_PREFIX, max(numbers, default=0) + 1))
        # 全部放进 Lights 集合(场景集合根下, 没有则创建; 颜色标 COLOR_03 便于辨识)
        lights_coll = context.scene.collection.children.get(LIGHTS_COLLECTION_NAME)
        if lights_coll is None:
            lights_coll = bpy.data.collections.new(LIGHTS_COLLECTION_NAME)
            lights_coll.color_tag = 'COLOR_03'
            context.scene.collection.children.link(lights_coll)
        elif lights_coll.color_tag == 'NONE':
            # 旧版本创建的无色 Lights 集合补上颜色标, 不覆写用户显式选过的颜色
            lights_coll.color_tag = 'COLOR_03'
        lights_coll.children.link(new_coll)
        refresh_lists()
        # 高亮新建项(重名由 Blender 自动加后缀, 按真实名定位)
        highlight_item(context, "light_collections", new_coll.name)
        return {'FINISHED'}
