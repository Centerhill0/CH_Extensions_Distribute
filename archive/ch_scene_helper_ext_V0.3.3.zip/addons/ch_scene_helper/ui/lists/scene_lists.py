"""
场景助手资源列表模块

UIList(类名含 _UL_ 标记, 类名即 template_list 查找 id):
相机 / 灯光 / 材质 / 世界环境 / 图像 五个主列表, 外加灯光集合(CLS_ 前缀)管理列表.
数据源是 WM 级快照(SceneHelperState), 顺序由快照序决定(按 ch_scene_order 排序).

主要功能:
- 行内只有名称与状态/参数控件, 详情统一由列表面板下方的可折叠子面板显示
- 名称经快照条目的 name 属性编辑并写穿到真实数据块, 双击才进入编辑
- 名称过滤 / 字母排序 / 反序由 common.blender.list_snapshot.StandardFilterMixin 提供
  (字母排序关闭时保持快照序, 反序最后统一应用)
- 首个图标统一为"选中关联物体": 点击会选中关联物体并高亮该列表项
- 伪用户按钮统一为算子切换(图标按当前状态绘制, 点击即时刷新)
"""

import bpy
from bpy.types import Context, UIList, UILayout

from .....common.blender.list_snapshot import StandardFilterMixin, standard_filter
from ...operators.utils.datablock_ops import CollectionActivateToggle, CollectionIsolate, WorldAssign
from ...operators.utils.image_ops import ImagePack, ImageUnpack
from ...operators.utils.material_ops import MaterialActivateToggle, MaterialMerge
from ...operators.utils.row_ops import CameraSetView
from ...scene_state import LIST_KINDS, STATE_PROP, block_for_item, get_state
from ...utils import LIGHT_COLLECTION_PREFIX, scene_collection_names
from ._rows import (
    camera_icon,
    can_split_columns,
    draw_fake_user_count,
    draw_image_select,
    draw_isolate_button,
    draw_missing_item,
    draw_name_cell,
    draw_object_toggles,
    draw_select_button,
    light_icon,
    material_preview_icon,
)

# 图像来源 -> 行图标
_IMAGE_SOURCE_ICONS = {
    'MOVIE': 'FILE_MOVIE',
    'SEQUENCE': 'RENDERLAYERS',
    'VIEWER': 'RESTRICT_RENDER_ON',
    'GENERATED': 'SELECT_SET',
}


def _mirror_filter_flags(context: Context, ulist, propname: str) -> None:
    """把 UIList 漏斗开关镜像到 WM 状态(供"上移/下移"按显示顺序换算)

    template_list 的漏斗状态只存在于 UIList 实例上, 算子无法读取; 每次绘制列表时镜像
    到 scene_state 的 filter_alpha/filter_reverse 向量. 重写 filter_items 的列表
    (如灯光列表的激活过滤)必须同样调用本函数, 否则排序开关对移动算子不可见.
    """
    state = getattr(context.window_manager, STATE_PROP, None)
    if state is not None and propname in LIST_KINDS:
        idx = LIST_KINDS.index(propname)
        state.filter_alpha[idx] = bool(ulist.use_filter_sort_alpha)
        state.filter_reverse[idx] = bool(ulist.use_filter_sort_reverse)


class _SceneFilterMixin(StandardFilterMixin):
    """内建过滤/排序 + 把开关镜像到 WM 状态"""

    def filter_items(self, context: Context, data, propname: str):
        _mirror_filter_flags(context, self, propname)
        return super().filter_items(context, data, propname)


def _draw_material_row(context: Context, layout: UILayout, item, mat) -> None:
    """材质行: 激活(联动场景选中) / 合并材质 / 名称(预览图) / 通道索引 / 节点数 / 伪用户 / 使用者数"""
    state = get_state(context)
    row = layout.row(align=True)
    op = row.operator(MaterialActivateToggle.bl_idname, text="", icon='RESTRICT_SELECT_OFF' if mat.ch_material_active else 'RESTRICT_SELECT_ON', emboss=False)
    op.mat_name = mat.name
    op = row.operator(MaterialMerge.bl_idname, text="", icon='IMPORT', emboss=False)
    op.mat_name = mat.name
    show_pass_index = state.materials_show_pass_index
    show_node_count = state.materials_show_node_count
    split_columns = (show_pass_index or show_node_count) and can_split_columns(context)
    sub = draw_name_cell(row, item, icon='MATERIAL', icon_value=material_preview_icon(mat), name_factor=0.4 if split_columns else None)
    if split_columns:
        if show_pass_index:
            sub.prop(mat, "pass_index", text="")
        if show_node_count:
            count = len(mat.node_tree.nodes) if mat.node_tree else 0
            sub.label(text="{:02d}".format(count), icon='NODE')
    draw_fake_user_count(sub, mat, 'MATERIAL')


class CH_UL_scene_cameras(_SceneFilterMixin, UIList):
    """相机列表(场景快照), 行内: 选择 / 相机视角 / 名称 / 焦距 / 类型 / 视口与渲染开关"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        obj = block_for_item(context, "cameras", item)
        if obj is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        draw_select_button(row, context, obj, "cameras")
        op = row.operator(CameraSetView.bl_idname, text="", icon=camera_icon(context, obj), emboss=False)
        op.obj_name = obj.name
        show_columns = state.cameras_show_lens or state.cameras_show_type
        split_columns = show_columns and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else None)
        cam = obj.data
        if split_columns:
            if state.cameras_show_lens:
                if cam.lens_unit == 'FOV':
                    sub.prop(cam, "angle", text="", emboss=False)
                else:
                    sub.prop(cam, "lens", text="", emboss=False)
            if state.cameras_show_type:
                sub.prop(cam, "type", text="", emboss=False)
        draw_object_toggles(sub, obj)


class CH_UL_scene_materials(_SceneFilterMixin, UIList):
    """材质列表(场景快照), 行内: 选择使用者 / 赋予 / 名称(预览图) / 通道索引 / 节点数 / 假用户"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        mat = bpy.data.materials.get(item.src_name)
        if mat is None:
            draw_missing_item(layout, item)
            return
        _draw_material_row(context, layout, item, mat)


class CH_UL_scene_lights(_SceneFilterMixin, UIList):
    """灯光列表(场景快照), 行内: 选择 / 类型 / 名称 / 颜色 / 阴影 / 隔离 / 视口与渲染开关

    激活的灯光集合(ch_lights_active)作为语义过滤: 只显示挂在其内(含子集合)的灯光,
    全不激活时显示场景全部.
    """

    def filter_items(self, context: Context, data, propname: str):
        # 直调 standard_filter 而非 super(): 本方法被 e2e 以 MethodType 绑到鸭子实例上运行,
        # 零参 super() 要求真实子类实例; 行为与 StandardFilterMixin.filter_items 逐字一致.
        # 漏斗开关镜像不可省(见 _mirror_filter_flags), 漏掉会让排序开关对移动算子不可见.
        _mirror_filter_flags(context, self, propname)
        flt_flags, flt_neworder = standard_filter(self, data, propname)
        active = [coll for coll in bpy.data.collections if getattr(coll, "ch_lights_active", False)]
        if active:
            # 有效范围 = 各激活集合的子树; 集合外灯光按位清可见标志(与名称过滤叠加)
            effective: set = set()
            for coll in active:
                effective |= scene_collection_names(coll)
            for idx, item in enumerate(getattr(data, propname)):
                obj = context.scene.objects.get(item.src_name)
                if obj is None or not any(c.name in effective for c in obj.users_collection):
                    flt_flags[idx] &= ~self.bitflag_filter_item
        return flt_flags, flt_neworder

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        obj = block_for_item(context, "lights", item)
        if obj is None:
            draw_missing_item(layout, item)
            return
        light = obj.data
        row = layout.row(align=True)
        draw_select_button(row, context, obj, "lights")
        row.prop(light, "type", text="", icon=light_icon(obj), icon_only=True, emboss=False)
        show_columns = state.lights_show_color or state.lights_show_shadow
        split_columns = show_columns and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else None)
        if split_columns:
            if state.lights_show_color:
                sub.prop(light, "color", text="")
            if state.lights_show_shadow:
                sub.prop(light, "use_shadow", text="", icon='GHOST_ENABLED' if light.use_shadow else 'GHOST_DISABLED', emboss=False)
        draw_isolate_button(sub, context, obj)
        draw_object_toggles(sub, obj)


class CH_UL_scene_light_collections(_SceneFilterMixin, UIList):
    """灯光集合列表(CLS_ 前缀集合快照), 行内: 激活过滤 / 名称 / 隔离 / 视口与渲染开关"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        coll = bpy.data.collections.get(item.src_name)
        if coll is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        # 行首激活图标用 CHECKBOX 对: 语义是"过滤开关"而非选中, 与其它列表的 RESTRICT_SELECT 区分
        op = row.operator(CollectionActivateToggle.bl_idname, text="", icon='CHECKBOX_HLT' if coll.ch_lights_active else 'CHECKBOX_DEHLT', emboss=False)
        op.collection_name = coll.name
        # 名称格不带图标(与灯光行同款): 行内图标会占掉名称的宽度, 窄面板时集合名比
        # 灯光名更早截断; 无列行走原生行布局——名称吃掉行尾按钮之外的全部宽度,
        # 隔离/视口/渲染三个图标按钮恒宽贴右缘(见 draw_name_cell)
        right = draw_name_cell(row, item)
        # 隔离(在灯光集合之间, 同款三态 SOLO 图标) + 视口/渲染全局开关(与灯光行同款)
        siblings = [c for c in bpy.data.collections if c.name.startswith(LIGHT_COLLECTION_PREFIX) and c is not coll]
        is_isolated = bool(siblings) and not coll.hide_viewport and all(c.hide_viewport for c in siblings)
        op = right.operator(CollectionIsolate.bl_idname, text="", icon='SOLO_ON' if is_isolated else 'SOLO_OFF', emboss=False)
        op.collection_name = coll.name
        right.prop(coll, "hide_viewport", text="", emboss=False, icon='RESTRICT_VIEW_OFF')
        right.prop(coll, "hide_render", text="", emboss=False, icon='RESTRICT_RENDER_OFF')


class CH_UL_scene_images(_SceneFilterMixin, UIList):
    """图像列表(图像数据块快照), 行内: 选择使用者 / 来源图标 / 名称 / 路径 / 尺寸 / 伪用户 / 打包解包"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        img = bpy.data.images.get(item.src_name)
        if img is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        draw_image_select(row, context, img)
        row.label(text="", icon=_IMAGE_SOURCE_ICONS.get(img.source, 'IMAGE_DATA'))
        # 列区只在**本行确实有内容**时占用宽度: Render Result / Viewer Node 这类无像素、
        # 无文件路径的内置图像若仍按 0.3 分列, 空列区会挤掉名称并把右侧按钮压到角落.
        # 尺寸判据用 img.size 而非 has_data: 图像懒加载时 has_data 为 False 但 size 仍可读
        # (从文件头解析), 此时尺寸应照常显示.
        show_size = bool(state.images_show_size and img.size[0] > 0)
        show_path = bool(state.images_show_filepath and img.filepath)
        split_columns = (show_size or show_path) and can_split_columns(context)
        sub = draw_name_cell(row, item, name_factor=0.3 if split_columns else None)
        if split_columns:
            if show_size:
                sub.label(text="{} x {}".format(img.size[0], img.size[1]))
            if show_path:
                sub.prop(img, "filepath", text="", emboss=False)
        draw_fake_user_count(sub, img, 'IMAGE')
        if img.packed_file is not None:
            op = sub.operator(ImageUnpack.bl_idname, text="", icon='PACKAGE', emboss=False)
        else:
            op = sub.operator(ImagePack.bl_idname, text="", icon='UGLYPACKAGE', emboss=False)
        op.image_name = img.name
        if img.has_data:
            sub.label(text="", icon='BLANK1')
        elif img.filepath:
            sub.label(text="", icon='MARKER')
        else:
            sub.label(text="", icon='ERROR')


class CH_UL_scene_worlds(_SceneFilterMixin, UIList):
    """世界环境列表(世界数据块快照), 行内: 指派 / 名称 / 颜色 / 伪用户 / 使用者数"""

    def draw_item(self, context: Context, layout: UILayout, data, item, icon: str, active_data, active_propname: str, idx: int):
        state = get_state(context)
        world = bpy.data.worlds.get(item.src_name)
        if world is None:
            draw_missing_item(layout, item)
            return
        row = layout.row(align=True)
        active = context.scene.world is world
        op = row.operator(WorldAssign.bl_idname, text="", icon='RESTRICT_SELECT_OFF' if active else 'RESTRICT_SELECT_ON', emboss=False)
        op.world_name = world.name
        split_columns = state.worlds_show_color and can_split_columns(context)
        sub = draw_name_cell(row, item, icon='WORLD', name_factor=0.5 if split_columns else None)
        if split_columns:
            sub.prop(world, "color", text="")
        draw_fake_user_count(sub, world, 'WORLD')
