"""
实时同步处理器模块

提供以下功能:
- depsgraph_update_post / load_post 处理器: 场景资源列表实时刷新与"选区同步"高亮;
  载入文件后回读相机 show_name 实况对齐"视图相机名称"开关
- refresh_lists: 公开的"立即重建快照"入口(供不触发 depsgraph 的算子主动调用)
- on_sync_toggle / on_zero_user_update: 面板状态开关的 update 回调
- on_images_index_update: 图像列表行点击时把图像编辑器切换到该图
- 周期计时器: 兜底刷新
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接

注:
- 列表活跃索引没有 update 回调 —— 点击名称只切换高亮, 选中物体由列表首按钮算子负责;
- "选区同步"只在**活动物体(或其活动材质)变化时**回写高亮, 用户手动点其它行不会被
  定时器顶回;
- 五种列表的集合/索引/开关统一取自 scene_state.LIST_SPECS;
- depsgraph 更新按 0.1s 合并窗口延迟刷新(见 _on_depsgraph_update), 避免拖动参数时逐帧全量采集;
- **已知限制**: WM 级状态组是单份, 多窗口查看不同场景时会互相覆盖(修复需按窗口分桶,
  属独立工程); 当前只保证"不处理其它场景的 depsgraph 更新".
"""

import bpy

from ...common.blender.list_snapshot import is_syncing, rebuild_if_changed, set_guarded, set_index
from .scene_state import LIST_SPECS, get_state, highlight_item
from .utils import (
    LIGHT_COLLECTION_PREFIX,
    collect_cameras,
    collect_images,
    collect_light_collections,
    collect_lights,
    collect_scene_material_blocks,
    collect_scene_materials,
    collect_worlds,
    first_image_of_material,
    focus_image_editors,
    sync_active_camera_resolution,
)

# 列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0
# depsgraph 更新的合并窗口(秒): 拖动参数/播放动画时 depsgraph 每帧触发, 逐次全量采集会卡顿
_DEBOUNCE_SECONDS = 0.1

# 上一次已跟进的活动状态 (物体名, 活动材质名); 变化时才回写各列表高亮
_LAST_ACTIVE: tuple = ("", "")
# 上一次已跟进的活动集合名(灯光集合列表 ↔ 大纲活动层集合联动); 变化时才回写
_LAST_ACTIVE_LIGHT_COLL: str = ""
# 已挂起一次延迟刷新(合并窗口内的重复更新只排一次)
_debounce_pending = False


def reset_sync_cache() -> None:
    """清空"已同步的活动状态"缓存(选区同步开关切换/载入文件后重新开始同步)"""
    global _LAST_ACTIVE, _LAST_ACTIVE_LIGHT_COLL
    _LAST_ACTIVE = ("", "")
    _LAST_ACTIVE_LIGHT_COLL = ""


def on_sync_toggle(self, context) -> None:
    """选区同步开关的 update 回调: 重置缓存, 让下一轮同步重新对齐"""
    reset_sync_cache()


def on_zero_user_update(self, context) -> None:
    """ "显示0用户"开关的 update 回调: 立即重建快照(开关只改收集范围)"""
    refresh_lists()


def on_images_index_update(self, context) -> None:
    """图像列表活跃索引回调: 点击行时把图像编辑器切换到该图

    程序化写入(快照重建/高亮回写/移动条目)均在 common.list_snapshot 的护栏内,
    见 is_syncing 即跳过, 避免同步过程抢走用户的图像编辑器.
    """
    if is_syncing():
        return
    idx = self.images_active_index
    if not 0 <= idx < len(self.images):
        return
    image = bpy.data.images.get(self.images[idx].src_name)
    if image is not None:
        focus_image_editors(context, image)


def _collect_lists(state) -> dict:
    """收集各资源列表的目标名称序列

    场景材质槽每轮只扫描一次: 材质列表直接复用该结果.
    """
    scene = bpy.context.scene
    used_materials = collect_scene_material_blocks(scene)
    return {
        "cameras": (collect_cameras(scene), None),
        "lights": (collect_lights(scene), None),
        "light_collections": (collect_light_collections(scene), None),
        "materials": (collect_scene_materials(scene, state.show_zero_user_materials, used_materials), None),
        "worlds": (collect_worlds(), None),
        "images": (collect_images(state.show_zero_user_images), None),
    }


def tag_3d_views() -> None:
    """标记所有 3D 视图与大纲管理器区域重绘(程序化写入不触发刷新, 需显式 tag)

    供算子/回调在写入视口相关状态后调用(隔离屏蔽世界、列表高亮回写等).
    """
    for window in bpy.context.window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type in {'VIEW_3D', 'OUTLINER'}:
                area.tag_redraw()


def _sync_selection(context, state) -> None:
    """活动物体(或其活动材质)变化时, 按选区同步开关回写高亮

    只在"活动状态"变化时执行: 用户点其它行只改高亮, 不会被下一轮重建顶回.
    写入索引后显式 tag 重绘: 程序化属性写入不触发面板刷新, 否则高亮变化要等
    鼠标划过面板才可见.
    """
    global _LAST_ACTIVE
    act_obj = context.view_layer.objects.active
    if act_obj is None:
        _LAST_ACTIVE = ("", "")
        return
    act_mat = act_obj.active_material
    active = (act_obj.name, act_mat.name if act_mat is not None else "")
    if active == _LAST_ACTIVE:
        return
    _LAST_ACTIVE = active
    if not state.sync_selection:
        return
    highlight_item(context, "cameras", act_obj.name)
    _follow_light(context, act_obj)
    if act_mat is not None:
        highlight_item(context, "materials", act_mat.name)
        image = first_image_of_material(act_mat)
        if image is not None:
            highlight_item(context, "images", image.name)
    tag_3d_views()


def _follow_light(context, act_obj) -> None:
    """灯光列表跟进: 活动物体是灯光时高亮该灯光"""
    if act_obj.type == 'LIGHT':
        highlight_item(context, "lights", act_obj.name, 'OBJECT')


def _sync_light_collection_highlight(context) -> None:
    """大纲管理器的活动集合变化时, 灯光集合列表高亮跟随(仅限 CLS_ 前缀集合)

    面板点击行经 props 回调设活动层集合, 走到这里时名字一致即 no-op, 不会互相顶回;
    大纲里选中的集合若不带前缀则不碰列表高亮.
    """
    global _LAST_ACTIVE_LIGHT_COLL
    view_layer = getattr(context, "view_layer", None)
    active_coll = getattr(getattr(view_layer, "active_layer_collection", None), "collection", None)
    name = active_coll.name if active_coll is not None and active_coll.name.startswith(LIGHT_COLLECTION_PREFIX) else ""
    if name == _LAST_ACTIVE_LIGHT_COLL:
        return
    _LAST_ACTIVE_LIGHT_COLL = name
    if not name:
        return
    highlight_item(context, "light_collections", name)
    tag_3d_views()


def _sync_all() -> None:
    """全量同步: 有变化才重建各列表快照, 按选区同步开关回写高亮, 并按场景相机同步独立分辨率"""
    context = bpy.context
    state = get_state(context)
    collected = _collect_lists(state)
    for kind, spec in LIST_SPECS.items():
        names, kinds = collected[kind]
        rebuild_if_changed(state, spec.collection, spec.index, spec.item_kind, names, kinds)
    _sync_selection(context, state)
    _sync_light_collection_highlight(context)
    # 场景相机变化(含 Ctrl+Numpad0/大纲等原生路径)与覆写值变化都经此兜底, 幂等无反馈环
    sync_active_camera_resolution(bpy.context.scene)


def _sync_all_safe() -> None:
    """全量同步, 吞掉"插件注销窗口期 WM 属性已摘除"类异常(各入口共用)"""
    try:
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _debounced_sync() -> None:
    """合并窗口到期: 清挂起位并做一次全量同步"""
    global _debounce_pending
    _debounce_pending = False
    _sync_all_safe()
    return None


def _on_depsgraph_update(scene=None, depsgraph=None) -> None:
    """depsgraph 更新回调: 只跟进当前窗口场景, 并按合并窗口延迟刷新

    多窗口下 WM 状态仍是单份(见模块 docstring 的已知限制), 但至少不把其它场景的
    更新算进来; 连续更新(拖动参数/动画)在窗口内只排一次刷新.
    """
    global _debounce_pending
    current = getattr(bpy.context, "scene", None)
    if scene is not None and current is not None and scene != current:
        return
    if _debounce_pending:
        return
    _debounce_pending = True
    try:
        bpy.app.timers.register(_debounced_sync, first_interval=_DEBOUNCE_SECONDS)
    except (ValueError, RuntimeError):
        # 注册失败(注销窗口期/计时器不可用)时不能把挂起位留在 True, 否则同步永久停摆
        _debounce_pending = False


def _sync_camera_names_state(state) -> None:
    """文件加载后回读相机 show_name 实况, 对齐"视图相机名称"开关

    开关是 WM 级不随文件保存, 而 show_name 写在相机对象上随 .blend 保存;
    不回读会错位成"相机名仍显示、开关却是关". 全部相机都显示才记为开;
    混合状态记为关但不清除 —— 回读经 set_guarded 护栏写入, 不触发批量覆写.
    """
    cameras = [obj for obj in bpy.context.scene.objects if obj.type == 'CAMERA']
    set_guarded(state, "cameras_show_names", bool(cameras) and all(obj.show_name for obj in cameras))


def _on_load_post(*_args) -> None:
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐新场景并重置跟进缓存

    活跃索引是 WM 级、跨文件保留的旧值, 新文件条目完全不同; 归零后再按名跟随/夹取,
    避免"打开新文件后高亮停在一个任意行". 另回读相机 show_name 实况对齐
    "视图相机名称"开关(开关 WM 级不随文件保存, 见 _sync_camera_names_state);
    场景侧分辨率覆写状态随 .blend 保存, 载入后先按场景相机对齐一次输出分辨率.
    """
    reset_sync_cache()
    try:
        sync_active_camera_resolution(bpy.context.scene)
    except (ReferenceError, AttributeError):
        pass
    try:
        state = get_state(bpy.context)
        for spec in LIST_SPECS.values():
            set_index(state, spec.index, 0)
        _sync_camera_names_state(state)
    except (ReferenceError, AttributeError):
        pass
    _sync_all_safe()


def _on_undo_post(*_args) -> None:
    """撤销/重做回调: 顺序值写在数据块自定义属性上, 不触发 depsgraph, 需主动重建"""
    reset_sync_cache()
    _sync_all_safe()


def refresh_lists() -> None:
    """立即重建列表快照并回写高亮

    供"写自定义属性(不触发 depsgraph, 5.1.2 实测)"的算子主动调用, 如列表排序值写入.
    """
    _sync_all_safe()


def _sync_timer() -> float:
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register() -> None:
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    for handlers_list in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_post not in handlers_list:
            handlers_list.append(_on_undo_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister() -> None:
    global _debounce_pending
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for handlers_list in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_post in handlers_list:
            handlers_list.remove(_on_undo_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
    if bpy.app.timers.is_registered(_debounced_sync):
        bpy.app.timers.unregister(_debounced_sync)
    _debounce_pending = False
