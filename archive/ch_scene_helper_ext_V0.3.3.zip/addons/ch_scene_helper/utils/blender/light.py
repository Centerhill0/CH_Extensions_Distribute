"""
灯光工具模块

提供灯光能量批量缩放与灯光隔离的世界屏蔽算法(交互层算子见 operators/object/light.py
与 operators/utils/row_ops.py).
"""

from bpy.types import Scene, World


def scale_lights_energy(objects: list, factor: float) -> int:
    """把一组灯光物体的能量乘以系数(结果钳制为非负), 返回实际缩放的灯光数

    Args:
        objects: 待处理物体列表(非灯光物体自动跳过)
        factor: 能量乘数(0 清空, 1 不变)

    Returns:
        实际被缩放的灯光物体数
    """
    count = 0
    for obj in objects:
        if obj is None or obj.type != 'LIGHT':
            continue
        obj.data.energy = max(obj.data.energy * factor, 0.0)
        count += 1
    return count


def lights_viewport_isolated(scene: Scene) -> bool:
    """灯光是否处于视口隔离态(多于一个灯光且恰好一个可见, 其余 hide_viewport)"""
    lights = [obj for obj in scene.objects if obj.type == 'LIGHT']
    visible = [obj for obj in lights if not obj.hide_viewport]
    return len(lights) > 1 and len(visible) == 1


def set_world_output_muted(world: World, mute: bool) -> int:
    """把世界输出节点全部接入端连线的屏蔽位统一置为 mute, 返回本次改动的连线数

    隔离灯光时屏蔽世界环境光用: link.is_muted 即视口里 Ctrl 点击连线头的静音语义.
    静音/恢复后显式 update_tag: 程序化改连线屏蔽位不触发着色器重估, 视口会停留在旧画面.
    """
    if world is None or world.node_tree is None:
        return 0
    count = 0
    for node in world.node_tree.nodes:
        if node.type != 'OUTPUT_WORLD':
            continue
        for socket in node.inputs:
            for link in socket.links:
                if link.is_muted != mute:
                    link.is_muted = mute
                    count += 1
    if count:
        world.node_tree.update_tag()
    return count


def apply_light_isolate_world_mute(scene: Scene, isolate_active: bool, mute_enabled: bool) -> int:
    """按灯光隔离态与"屏蔽世界"开关把世界屏蔽位归位, 返回改动连线数

    - 隔离生效且开关开 -> 屏蔽全部接入端连线
    - 其余情况(取消隔离/开关关) -> 全部恢复: 按作者口径"取消隔离后恢复",
      不区分屏蔽来源(用户手动静音的连线也会被恢复)
    """
    return set_world_output_muted(scene.world, isolate_active and mute_enabled)
