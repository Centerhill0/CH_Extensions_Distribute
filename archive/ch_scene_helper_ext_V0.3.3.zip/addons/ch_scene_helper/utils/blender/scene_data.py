"""
场景数据收集工具模块

收集场景中的灯光/相机/材质/图像/世界环境名称供列表快照使用;
收集结果按列表顺序值排序(顺序值挂数据块自定义属性, 算法见 common.blender.list_order):
有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序).

主要功能:
- collect_scene_material_blocks: 场景物体材质槽里实际使用的材质块(去重, 顺序稳定)
- collect_lights: 灯光物体名枚举
- collect_cameras: 相机物体名枚举
- collect_scene_materials: 材质名枚举(默认只收场景实际使用的, 可选纳入 0 用户材质)
- collect_images: 图像名枚举(默认只收有使用者的, 可选纳入 0 用户)
- collect_light_collections: CLS_ 前缀集合名枚举(灯光集合管理列表)
- collect_worlds: 世界环境名枚举(始终全量)
"""

import bpy
from bpy.types import Scene

from .....common.blender.list_order import order_key


def collect_scene_material_blocks(scene: Scene) -> list:
    """收集场景物体材质槽里实际使用的材质块(按首次出现去重, 排除空槽)"""
    seen = set()
    blocks = []
    for obj in scene.objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or mat.name in seen:
                continue
            seen.add(mat.name)
            blocks.append(mat)
    return blocks


def _sorted_names(blocks: list) -> list:
    """按列表顺序值排序并取名称"""
    return [block.name for block in sorted(blocks, key=order_key)]


def collect_cameras(scene: Scene) -> list:
    """收集场景中的相机物体名, 按列表顺序值排序"""
    return _sorted_names([obj for obj in scene.objects if obj.type == 'CAMERA'])


def collect_lights(scene: Scene) -> list:
    """收集场景中的灯光物体名(只含灯光物体), 按列表顺序值排序"""
    return _sorted_names([obj for obj in scene.objects if obj.type == 'LIGHT'])


def collect_scene_materials(scene: Scene, include_zero_user: bool = False, used_materials: list | None = None) -> list:
    """收集材质名并按列表顺序值排序

    Args:
        scene: 目标场景
        include_zero_user: 为真时收集 bpy.data.materials 全量数据块(含 0 用户/仅假用户)
        used_materials: 可选的场景在用材质块列表(include_zero_user 为假时使用)

    Returns:
        材质名称列表
    """
    if include_zero_user:
        blocks = list(bpy.data.materials)
    elif used_materials is not None:
        blocks = used_materials
    else:
        blocks = collect_scene_material_blocks(scene)
    return _sorted_names(blocks)


def real_user_count(datablock) -> int:
    """数据块的真实使用者数量(扣除假用户)

    users 会把假用户算进去, 故删除确认与"仅列有使用者"都按本函数判断.
    """
    return datablock.users - (1 if datablock.use_fake_user else 0)


def _find_layer_collection(layer_coll, coll):
    """在层集合树里找到包裹目标集合的 LayerCollection, 找不到返回 None"""
    if layer_coll.collection is coll:
        return layer_coll
    for child in layer_coll.children:
        found = _find_layer_collection(child, coll)
        if found is not None:
            return found
    return None


def set_active_collection(view_layer, coll) -> bool:
    """把集合设为视图层的活动层集合(大纲管理器随之高亮该集合), 不在视图层中返回 False

    大纲管理器的集合选中态没有 RNA API, 活动层集合是唯一可编程的"选中"通道.
    """
    found = _find_layer_collection(view_layer.layer_collection, coll)
    if found is None:
        return False
    view_layer.active_layer_collection = found
    return True


def relink_collection_contents(coll, fallback) -> int:
    """把集合(含子集合)内"删除后将失去全部场景挂载"的物体改挂到 fallback, 返回改挂数

    默认删除集合时保证灯光等内部物体在场景中仍可见(只删集合数据块, 物体不孤儿化);
    在删除子树之外仍有挂载的物体不动, 库链接物体同样可改挂(链接操作不受只读限制).
    """
    collections_out: list = []
    objects_out: list = []
    _collect_hierarchy(coll, collections_out, objects_out)
    subtree_ids = {c.name for c in collections_out}
    fallback_name = fallback.name
    relinked = 0
    seen: set = set()
    for obj in objects_out:
        if obj.name in seen:
            continue
        seen.add(obj.name)
        outside = [c for c in obj.users_collection if c.name not in subtree_ids and c.name != fallback_name]
        if not outside and fallback_name not in {c.name for c in obj.users_collection}:
            fallback.objects.link(obj)
            relinked += 1
    return relinked


def _collect_hierarchy(coll, collections_out: list, objects_out: list) -> None:
    """递归收集集合自身、全部子集合与物体(子级在前, 供删除时先深后浅)"""
    for child in list(coll.children):
        _collect_hierarchy(child, collections_out, objects_out)
    collections_out.append(coll)
    objects_out.extend(coll.objects)


def remove_collection_hierarchy(coll) -> int:
    """删除集合及其内部全部物体与子集合(大纲"删除层级"语义), 返回删除的物体数

    仅删可写数据: 库链接的物体/集合跳过; 物体挂在多个集合时按 Blender 物体语义
    整体删除, 去重避免同一物体被二次移除.
    """
    collections_out: list = []
    objects_out: list = []
    _collect_hierarchy(coll, collections_out, objects_out)
    removed_names: set = set()
    count = 0
    for obj in objects_out:
        if obj.library is None and obj.name not in removed_names:
            removed_names.add(obj.name)
            bpy.data.objects.remove(obj)
            count += 1
    for child_coll in collections_out:
        if child_coll.library is None:
            bpy.data.collections.remove(child_coll)
    return count


def _has_real_users(datablock) -> bool:
    """数据块是否有真实使用者"""
    return real_user_count(datablock) > 0


def collect_images(include_zero_user: bool = False) -> list:
    """收集图像名并按列表顺序值排序

    include_zero_user 为假(默认)时只收有真实使用者的图像; 为真时把 0 用户图像也纳入.
    """
    return _sorted_names([img for img in bpy.data.images if include_zero_user or _has_real_users(img)])


# 灯光集合的命名前缀(灯光集合管理列表只收该前缀的集合)
LIGHT_COLLECTION_PREFIX = "CLS_"

# 灯光集合的父集合名(CollectionNew 自动创建/挂靠, DatablockDelete 默认改挂回退)
LIGHTS_COLLECTION_NAME = "Lights"


def scene_collection_names(root) -> set:
    """集合树里可达的全部集合名(从给定根集合递归下钻; 传场景集合即大纲可达集)"""
    names: set = set()

    def walk(coll):
        names.add(coll.name)
        for child in coll.children:
            walk(child)

    walk(root)
    return names


def collect_light_collections(scene: Scene) -> list:
    """收集场景内 CLS_ 前缀的集合名(灯光集合管理列表), 按列表顺序值排序

    只收大纲管理器可达的集合: 数据块存在但未链接进场景的不列(作者 2026-10-24 定).
    """
    reachable = scene_collection_names(scene.collection)
    return _sorted_names([coll for coll in bpy.data.collections if coll.name.startswith(LIGHT_COLLECTION_PREFIX) and coll.name in reachable])


def collection_objects_recursive(coll) -> list:
    """集合及其子集合内的全部物体(去重, 保持层级序)"""
    collections_out: list = []
    objects_out: list = []
    _collect_hierarchy(coll, collections_out, objects_out)
    seen: set = set()
    result = []
    for obj in objects_out:
        if obj.name not in seen:
            seen.add(obj.name)
            result.append(obj)
    return result


def collect_worlds() -> list:
    """收集全部世界环境名并按列表顺序值排序(始终包含 0 用户世界)"""
    return _sorted_names(list(bpy.data.worlds))
