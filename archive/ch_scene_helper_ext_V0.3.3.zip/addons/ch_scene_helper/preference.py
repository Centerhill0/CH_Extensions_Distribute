"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(相机设置 / 快捷键)
- get_prefs: 取本插件偏好实例

面板为左右两列布局(不再分页签):
- 左列: Camera Settings(相机参数占位, 后续参数加在此处)
- 右列: 本插件已注册的快捷键列表(饼菜单), 附 rna_keymap_ui 的标准改键控件

注: 列表的"选区同步"与"显示0用户"开关在面板选项菜单内,
状态存 WM 级 SceneHelperState, 不随 .blend 保存.
"""

import bpy
from bpy.types import AddonPreferences, Context, KeyConfig, UILayout
from rna_keymap_ui import draw_kmi

from .config import __addon_name__
from .keymaps import addon_keymaps


def _draw_hotkey_column(layout: UILayout, title: str, icon: str, groups: list, kc: KeyConfig) -> None:
    """绘制单列快捷键分组列表"""
    col = layout.box()
    col.label(text=title, icon=icon)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            try:
                draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
            except (ReferenceError, AttributeError, ValueError):
                # 用户在本页删除快捷键后, 保存的 kmi 句柄会失效; 跳过该行而不是让整页绘制崩溃
                split.label(text="(removed)")
        row.separator(factor=1, type='LINE')


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 左右两列: 左列参数设置, 右列快捷键(仅饼菜单, 无独立操作项)
        columns = layout.split(factor=0.4)

        # 左列: 相机设置(参数占位, 后续相机参数加在此处)
        left = columns.column()
        box = left.box()
        box.label(text="Camera Settings", icon="CAMERA_DATA")
        placeholder = box.row()
        placeholder.active = False
        placeholder.label(text="No camera settings yet")

        # 右列: 快捷键列表(饼菜单)
        right = columns.column()
        pie_groups = []
        for name, items in addon_keymaps.items():
            if name.lower().endswith('pie'):
                pie_groups.append((name, items))
        _draw_hotkey_column(right, "Hotkeys", "KEY_COMMAND", pie_groups, kc)


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
