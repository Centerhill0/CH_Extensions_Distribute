"""
倒角/圆角转换操作模块

提供倒角(Chamfer)与圆角(Fillet)之间的相互转换工具:
- ChamferToFillet: 倒角转圆角
- FilletToChamfer: 圆角转倒角
- Unchamfer: 倒角转硬边
- Unfillet: 圆角转硬边(先融合为倒角面再收拢)

通用模态快捷键:
- H: 切换手柄方法(FACE/LOOP)
- S: 切换锐度标记(Sharp)
- B: 切换倒角权重标记(Bevel), ALT+滚轮调整数值
- W: 切换滑动/宽度调整模式, ALT+W 重置
- R: 反转轨道(仅单面模式)
- 滚轮: 调整分段数
- T: 张力调整模式, Z/X/C/V 张力预设, A 平均张力
- P: 投射循环, E: Freestyle切换, F: 封孔切换
"""

__all__ = ["ChamferToFillet", "FilletToChamfer", "Unchamfer", "Unfillet"]

import logging
import math

import bpy
import bmesh
from bmesh.types import (
    BMesh,
)
from bpy.types import Operator, Context, Object, Event, VertexGroup
from bpy.props import IntProperty, FloatProperty, BoolProperty, EnumProperty

from .....common.i18n.i18n import iface, report

from ...items import fuse_method_items, handle_method_items, tension_preset_items

from ...utils import (
    get_zoom_factor,
    get_average_position,
    get_length_unit_data,
    ensure_default_data_layers,
    get_custom_data_layers,
    build_mesh_graph,
    init_sweeps,
    get_loops,
    change_width,
    create_face_intersection_handles,
    create_loop_intersection_handles,
    create_splines,
    fuse_surface,
    set_sweep_sharps_and_bweights,
    clear_rail_sharps_and_bweights,
    scroll,
    scroll_up,
    step_enum,
    navigation_passthrough,
    ignore_events,
    draw_status_item,
    format_adaptive_precision,
    force_ui_update,
    get_2_rails_from_chamfer,
    get_sweeps_from_fillet,
    fillet_to_chamfer,
    set_rail_sharps_and_bweights,
    unchamfer_loop_intersection,
    unchamfer_face_intersection,
    set_sharps_and_bweights,
)
from ...modal_base import ModalOperatorMixin

_logger = logging.getLogger(__name__)


# ============================================================
# ChamferToFillet 倒角转圆角
# ============================================================


def _new_snapshot_bm(obj: Object) -> BMesh:
    """构建用于撤销/恢复初始状态的网格快照"""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.normal_update()
    return bm


def _apply_init_bm(init_bm: BMesh, obj: Object) -> None:
    """物体模式下把初始快照写回物体网格(带模式切换)"""
    bpy.ops.object.mode_set(mode='OBJECT')
    init_bm.to_mesh(obj.data)
    bpy.ops.object.mode_set(mode='EDIT')


def _new_work_bm(obj: Object) -> BMesh:
    """物体模式下构建工作BMesh(独立所有权, 成功后 to_mesh 回写并 free)"""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.normal_update()
    bm.select_mode = {'FACE'}
    bm.verts.ensure_lookup_table()
    # faces 表同样必须 ensure: from_mesh 不建查找表, 模态缓存的 _modal_faces 按索引
    # 取面(bm.faces[i])会抛 "outdated internal index table"(探针实证)
    bm.faces.ensure_lookup_table()
    return bm


def _prepare_edge_layers(bm: BMesh) -> tuple:
    """确保默认数据层, 返回 (顶点组, 倒角权重层, 全部边层列表)

    crease=False: 本流程只写倒角权重, 折痕层无人读写——经 to_mesh 写回会给用户网格
    持久新增全 0 的 crease_edge 层(hole_extrude 同款顾虑, 见其 invoke 注释), 不建.
    """
    vg, bw = ensure_default_data_layers(bm, crease=False)
    return vg, bw, [bw] + get_custom_data_layers(bm)


class ChamferToFillet(Operator, ModalOperatorMixin):
    """
    切角转圆角操作器

    功能: 将选中的切角面转换为圆角
    - 支持FUSE和BRIDGE两种转换方法
    - 支持实时预览和参数调整
    - 支持张力,宽度,分段数等参数调整

    要求: 网格编辑模式下有选中的四边形面
    """

    bl_idname = "ch.chamfer_to_fillet"
    bl_label = "Chamfer to Fillet"
    bl_description = "Convert chamfer to fillet"
    bl_options = {'REGISTER', 'UNDO'}

    method: EnumProperty(name="Method", items=fuse_method_items, default="FUSE", description="How the fillet surface is built from the chamfer faces")  # type: ignore
    handle_method: EnumProperty(name="Handle Method", items=handle_method_items, default="FACE", description="Whether the handles follow face borders or edge loops")  # type: ignore
    segments: IntProperty(name="Segments", default=6, min=0, max=30, description="Number of segments across the fillet surface")  # type: ignore
    tension: FloatProperty(name="Tension", default=0.7, min=0.01, max=4, step=0.1, description="Tension of the fillet curve; higher values bulge outward")  # type: ignore
    tension_preset: EnumProperty(name="Tension Presets", items=tension_preset_items, default="CUSTOM", description="Pick a common tension value, or keep the custom tension")  # type: ignore
    average: BoolProperty(name="Average Tension", default=False, description="Average the tension across all selected chamfers")  # type: ignore
    force_projected_loop: BoolProperty(name="Projected Loops", default=False, description="Project the rail loops onto the surface instead of following them")  # type: ignore
    width: FloatProperty(name="Adjust Width", default=0.0, step=0.1, subtype='DISTANCE', description="Width offset applied to the fillet rails")  # type: ignore
    cap_holes: BoolProperty(name="Cap Holes", default=True, description="Fill the open ends of the fillet surface")  # type: ignore
    cap_dissolve_angle: FloatProperty(name="Dissolve Angle", min=0.0, max=math.pi, default=math.radians(10), precision=0, subtype='ANGLE', description="Dissolve cap edges whose face angle is within this value of 0 or 180 degrees")  # type: ignore
    smooth: BoolProperty(name="Shade Smooth", default=False, description="Shade the generated surface smooth")  # type: ignore
    reverse: BoolProperty(name="Reverse", default=False, description="Reverse the direction of the conversion")  # type: ignore
    use_freestyle: BoolProperty(name="Use Freestyle", default=True, description="Mark the generated edges for Freestyle")  # type: ignore

    # --- 模态状态 ---
    cyclic: BoolProperty(name="Cyclic", description="Is loop faces", default=False, options={'HIDDEN'})  # type: ignore
    single: BoolProperty(name="Single", description="Is single face", default=False, options={'HIDDEN'})  # type: ignore
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    allow_modal_width: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    allow_modal_tension: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return any(f.select for f in bm.faces)

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_obj.update_from_editmode()

        self.width = 0
        self.reverse = False
        self.force_projected_loop = False
        self.allow_modal_width = False
        self.allow_modal_tension = False

        self.init = True
        self.mat_index = 0
        self.single = False

        # 模态期拓扑/选区恒定(每事件由同一快照重建工作网格): 网格图与选中面索引只在
        # 首事件构建, 后续事件复用——大网格每事件全量重建图是拖动卡顿主因
        self._modal_graph = None
        self._modal_graph_size = None
        self._sel_face_idx = None

        self.init_bm = _new_snapshot_bm(self.act_obj)

        depth_location = self.act_obj.matrix_world @ get_average_position([v.co for v in self.init_bm.verts if v.select])
        self.factor = get_zoom_factor(context, depth_location)

        self.init_mouse_position(event)

        try:
            ret = self._fuse_modal(self.act_obj)
        except Exception:
            # invoke 期即退化(如初始几何就报错): 此时状态栏/处理器尚未注册, 只需收敛快照资源
            _logger.exception("Chamfer invoke failed")
            self.report({'ERROR'}, "Chamfer failed, see the system console for details")
            self.init_bm.free()
            self.init_bm = None
            return {'CANCELLED'}

        if not ret:
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        # 初始化状态栏
        self.init_status(context, func=_draw_chamfer_to_fillet_status(self))
        # 设置初始header文本
        self.update_header_text(context)
        # 初始化模态处理器
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 最小收敛并退出, 否则每个后续事件都抛 AttributeError 且模态永不收敛
            self._abort_without_area(context)
            return {'CANCELLED'}

        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()

        events = ['R', 'S', 'F', 'Z', 'X', 'C', 'V', 'W', 'T', 'A', 'P', 'E', 'M', 'H']
        if any([self.allow_modal_width, self.allow_modal_tension]):
            events.append('MOUSEMOVE')

        if event.type in events or scroll(event):
            if event.type == 'MOUSEMOVE':
                wrapped = self.wrap_mouse_position(context, event)
                if self.pass_through:
                    self.pass_through = False
                elif not wrapped and (self.allow_modal_width or self.allow_modal_tension):
                    if getattr(self, '_first_mouse_move', True):
                        self._first_mouse_move = False
                        self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y
                    else:
                        if self.allow_modal_width:
                            divisor = 100 if event.shift else 1 if event.ctrl else 10
                            delta_x = event.mouse_x - self.last_mouse_x
                            delta_width = delta_x / divisor * self.factor
                            self.width += delta_width
                            self.last_mouse_x = event.mouse_x

                        if self.allow_modal_tension:
                            divisor = 1000 if event.shift else 10 if event.ctrl else 100
                            delta_y = event.mouse_y - self.last_mouse_y
                            delta_tension = delta_y / divisor
                            self.tension_preset = "CUSTOM"
                            self.tension += delta_tension
                            self.last_mouse_y = event.mouse_y

            elif scroll(event):
                self._handle_scroll(event)
            else:
                self._handle_key_press(context, event)

            try:
                self.update_header_text(context)
                ret = self._fuse_modal(self.act_obj)

                if not ret:
                    self.finish(context)
                    return {'FINISHED'}
            except Exception:
                # 不得静默吞成 FINISHED: 否则用户看到"操作无声结束, 网格停在半成品",
                # 且控制台无任何线索. 记录并上报, 由 report 通道呈现给用户.
                # utils 抛错时 _fuse_modal 可能已切到 OBJECT 模式: 切回, 别把用户留在那里
                _logger.exception("%s modal failed", type(self).__name__)
                self.report({'ERROR'}, "Chamfer failed, see the system console for details")
                if context.mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                self.finish(context)
                return {'CANCELLED'}

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if any([self.allow_modal_width, self.allow_modal_tension]):
                self.allow_modal_width = False
                self.allow_modal_tension = False
            else:
                self.finish(context)
                return {'FINISHED'}

        elif event.type in {'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _handle_scroll(self, event: Event):
        """处理滚轮事件"""
        direction = 1 if scroll_up(event) else -1

        if self.method == "FUSE" and event.alt:
            self.cap_dissolve_angle += math.radians(5) * direction
        else:
            self.segments += direction

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.value != "PRESS":
            return

        if event.type == 'M':
            self.method = step_enum(self.method, fuse_method_items, 1)
            return

        if event.type == 'R':
            self.reverse = not self.reverse
            return

        fuse_only_keys = {
            'H': lambda: setattr(self, 'handle_method', step_enum(self.handle_method, handle_method_items, 1)),
            'S': lambda: setattr(self, 'smooth', not self.smooth),
            'F': lambda: setattr(self, 'cap_holes', not self.cap_holes),
            'P': lambda: setattr(self, 'force_projected_loop', not self.force_projected_loop),
            'E': lambda: setattr(self, 'use_freestyle', not self.use_freestyle),
        }

        if self.method == "FUSE":
            if event.type == 'W':
                if event.alt:
                    self.allow_modal_width = False
                    self.width = 0
                else:
                    self.allow_modal_width = not self.allow_modal_width
                    if self.allow_modal_width:
                        self._first_mouse_move = True
            elif event.type == 'A' and self.handle_method == "FACE":
                self.average = not self.average
            elif event.type in fuse_only_keys:
                fuse_only_keys[event.type]()

        common_keys = {
            'T': lambda: (setattr(self, 'allow_modal_tension', not self.allow_modal_tension), setattr(self, '_first_mouse_move', True) if self.allow_modal_tension else None),
            'X': lambda: setattr(self, 'tension_preset', "0.7"),
            'C': lambda: setattr(self, 'tension_preset', "1"),
            'V': lambda: setattr(self, 'tension_preset', "1.33"),
            'Z': lambda: setattr(self, 'tension_preset', "0.55"),
        }

        if event.type in common_keys:
            common_keys[event.type]()

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; 轨道提取与融合依赖的编辑模式面选择由 invoke 建立
        # (act_obj.update_from_editmode 同步后经 _fuse_modal 记录), 无交互状态时下面重建的快照
        # 取自未同步的 obj.data, 写回后会清空面选择, 使 _fuse_execute 的 max() 收到空序列抛 ValueError,
        # 故干净取消而非崩溃.
        # 不可复入 invoke 重建: invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # F9 重做走持久实例, init 与 init_bm 均存在, 不受此守卫影响
        if not hasattr(self, 'init'):
            self.report({'WARNING'}, "Chamfer to Fillet requires interactive viewport input and cannot be executed directly")
            return {'CANCELLED'}

        act_obj = context.active_object

        if not hasattr(self, 'init_bm') or self.init_bm is None:
            self.init_bm = _new_snapshot_bm(act_obj)

        if self.init_bm:
            _apply_init_bm(self.init_bm, act_obj)

        self._fuse_execute(act_obj)
        return {'FINISHED'}

    def finish(self, context: Context, cancel=False):
        """完成操作,清理资源

        Args:
            context: Blender上下文
            cancel: 是否为取消操作,取消时恢复初始状态
        """
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        if cancel:
            _apply_init_bm(self.init_bm, self.act_obj)
            self.init_bm.free()
            self.init_bm = None
        # 确认路径保留快照, 供F9 redo的execute恢复初始状态重算

        self.act_obj.update_from_editmode()

        force_ui_update(context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        row = layout.row(align=True)
        row.prop(self, "method")

        layout.prop(self, "segments")

        if self.method == "FUSE":
            row = layout.row(align=True)
            row.prop(self, "handle_method", expand=True)

            layout.prop(self, "force_projected_loop")
            row = layout.row()
            row.enabled = not self.force_projected_loop
            row.prop(self, "use_freestyle")
            layout.prop(self, "smooth")
            row = layout.row()
            row.enabled = not self.cyclic
            row.prop(self, "cap_holes")
            row = layout.row()
            row.enabled = not self.cyclic
            row.prop(self, "cap_dissolve_angle")
            layout.prop(self, "width")
        layout.prop(self, "tension")

        if self.method == "FUSE":
            if self.handle_method == "FACE":
                layout.prop(self, "average")

        if self.single:
            layout.prop(self, "reverse")

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        tension_text = format_adaptive_precision(self.tension, 2)

        text = f"Segments: {self.segments + 1} | Tension: {tension_text}"

        if self.method == "FUSE":
            unit_symbol, factor = get_length_unit_data(context)
            width_text = format_adaptive_precision(self.width * factor, 3)
            text += f" | Width: {width_text} {unit_symbol}"

            if not self.cyclic:
                text += f" | Dissolve: {math.degrees(self.cap_dissolve_angle):.0f}°"

        context.area.header_text_set(text)

    def _clean_up(self, bm: BMesh, faces: list):
        """清理原始切角面"""
        bmesh.ops.delete(bm, geom=faces, context='FACES')

    def _fuse_core(self, bm: BMesh, act_obj: Object, faces: list, rails: list, cyclic: bool, edge_layers: list, vg: VertexGroup) -> bool:
        """
        执行切角转圆角的核心几何操作

        Args:
            bm: BMesh对象
            act_obj: 活动对象
            faces: 选中的面列表
            rails: 轨道顶点对列表
            cyclic: 是否为循环选择
            edge_layers: 边数据层列表
            vg: 顶点组

        Returns:
            bool: 是否成功(失败时网格未被修改)
        """
        if self.method == "FUSE":
            return self._fuse_method(bm, act_obj, rails, edge_layers, faces, vg)
        elif self.method == "BRIDGE":
            self._bridge_method(bm, act_obj, rails, edge_layers, faces)
        return True

    def _fuse_modal(self, act_obj: Object) -> bool:
        """
        模态模式下的切角转圆角操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        if self.tension_preset != "CUSTOM":
            self.tension = float(self.tension_preset)

        if self.segments == 0:
            return True

        bpy.ops.object.mode_set(mode='OBJECT')

        try:
            if self.init_bm:
                self.init_bm.to_mesh(act_obj.data)

            bm = _new_work_bm(act_obj)
        except Exception:
            bpy.ops.object.mode_set(mode='EDIT')
            raise

        # utils 几何步骤抛错时工作 bm 必须释放且模式切回, 否则用户被留在 OBJECT 模式且内存泄漏
        try:
            vg, _, edge_layers = _prepare_edge_layers(bm)

            faces = self._modal_faces(bm)

            if getattr(self, 'init', False):
                self.init = False
                self.single = len(faces) == 1
                self.smooth = any(f.smooth for f in faces)

                matindices = [f.material_index for f in faces]
                self.mat_index = max(set(matindices), key=matindices.count)

            # 网格图首事件构建后复用(顶点/边数作指纹守卫): 工作网格每事件由同一快照
            # 重建, 拓扑与选区恒定, 图(含其中的选中态)逐事件恒等.
            # 约束: 指纹只含顶点/边计数, 成立前提是"模态期拓扑与选区不变"——若将来允许
            # 模态中途改拓扑或选区, 须把面数与选区一并纳入指纹, 否则会复用陈旧图与索引
            graph_size = (len(bm.verts), len(bm.edges))
            if self._modal_graph is None or self._modal_graph_size != graph_size:
                self._modal_graph = build_mesh_graph(bm)
                self._modal_graph_size = graph_size

            if not self._rails_and_fuse(bm, act_obj, faces, edge_layers, vg, mesh_graph=self._modal_graph):
                # bm 交由 finally 统一释放(此处再 free 会与 finally 双释放)
                return False

            bm.to_mesh(act_obj.data)
        finally:
            if 'bm' in locals():
                bm.free()
            bpy.ops.object.mode_set(mode='EDIT')

        if self.method == "BRIDGE":
            bpy.ops.mesh.bridge_edge_loops(number_cuts=self.segments, smoothness=self.tension, interpolation='SURFACE')

        return True

    def _fuse_execute(self, act_obj: Object) -> bool:
        """
        直接执行模式下的切角转圆角操作

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        if self.segments <= 0:
            return False

        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.select_mode = {'FACE'}
        bm.verts.ensure_lookup_table()

        vg, _, edge_layers = _prepare_edge_layers(bm)

        faces = [f for f in bm.faces if f.select]

        self.single = len(faces) == 1

        matindices = [f.material_index for f in faces]
        self.mat_index = max(set(matindices), key=matindices.count)

        if not self._rails_and_fuse(bm, act_obj, faces, edge_layers, vg):
            return False

        bmesh.update_edit_mesh(act_obj.data)

        if self.method == "BRIDGE":
            bpy.ops.mesh.bridge_edge_loops(number_cuts=self.segments, smoothness=self.tension, interpolation='SURFACE')

        return True

    def _modal_faces(self, bm: BMesh) -> list:
        """模态期的选区面列表: 首事件缓存选中索引, 之后按索引直取

        每事件的 [f for f in bm.faces if f.select] 是 O(全网格) RNA 读; 工作网格每事件
        由同一快照重建, 选区恒等且索引恒定, 按索引取是 O(选中数).
        """
        if self._sel_face_idx is None:
            self._sel_face_idx = [f.index for f in bm.faces if f.select]
        return [bm.faces[i] for i in self._sel_face_idx]

    def _rails_and_fuse(self, bm: BMesh, act_obj: Object, faces: list, edge_layers: list, vg, mesh_graph: dict | None = None) -> bool:
        """
        提取轨道并执行FUSE融合(公共流程, 供模态与直接执行两种模式复用)

        Args:
            bm: BMesh对象
            act_obj: 活动对象
            faces: 选中的面列表
            edge_layers: 边数据层列表
            vg: 顶点组
            mesh_graph: 调用方已构建的网格图(模态路径复用, 免逐事件全量重建); None 时现算

        Returns:
            bool: 是否成功
        """
        mg = build_mesh_graph(bm) if mesh_graph is None else mesh_graph

        ret, err = get_2_rails_from_chamfer(bm, mg, faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        return self._fuse_core(bm, act_obj, faces, rails, cyclic, edge_layers, vg)

    def _fuse_method(self, bm: BMesh, act_obj: Object, rails: list, edge_layers: list, faces: list, vg: VertexGroup) -> bool:
        """
        FUSE方法: 使用贝塞尔曲线生成圆角

        Returns:
            bool: 是否成功(失败时网格未被修改, 报错后由调用方中止)
        """
        sweeps = init_sweeps(bm, act_obj, rails, freestyle=self.use_freestyle)

        _, err = get_loops(edge_layers, sweeps, force_projected=self.force_projected_loop)
        if err:
            self.report({'WARNING'}, report(err))
            return False

        if self.width != 0:
            _, err = change_width(sweeps, self.width)
            if err:
                self.report({'WARNING'}, report(err))
                return False

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=self.tension, average=self.average)
        elif self.handle_method == "LOOP":
            create_loop_intersection_handles(sweeps, self.tension)

        spline_sweeps = create_splines(bm, sweeps, self.segments)
        self._clean_up(bm, faces)
        fuse_surface(bm, spline_sweeps, self.smooth, self.mat_index, self.cap_holes, math.degrees(self.cap_dissolve_angle), self.cyclic)

        set_sweep_sharps_and_bweights(bm, edge_layers, sweeps, spline_sweeps, vg=vg)
        clear_rail_sharps_and_bweights(bm, edge_layers, rails, self.cyclic)
        return True

    def _bridge_method(self, bm: BMesh, act_obj: Object, rails: list, edge_layers: list, faces: list):
        """BRIDGE方法: 使用Blender内置桥接功能"""
        for f in bm.faces:
            f.select = False

        bmesh.ops.delete(bm, geom=faces, context='FACES')
        clear_rail_sharps_and_bweights(bm, edge_layers, rails, self.cyclic, select=True)


def _draw_chamfer_to_fillet_status(op: ChamferToFillet):
    """
    返回 ChamferToFillet 操作的状态栏绘制回调函数

    Args:
        op: ChamferToFillet 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='M', text=iface(op.method.capitalize()), gap=1)
        draw_status_item(row, key='MMB_SCROLL', text="Segments")

        if op.single:
            draw_status_item(row, active=op.reverse, key='R', text="Reverse")

        if op.method == "FUSE":
            draw_status_item(row, key='H', text=iface("Handle({})").format(iface(op.handle_method.capitalize())))

            draw_status_item(row, active=op.force_projected_loop, key='P', text="Projected Loops", gap=3)
            draw_status_item(row, active=op.use_freestyle and not op.force_projected_loop, key='E', text="Freestyle")
            draw_status_item(row, active=op.smooth, key='S', text="Smooth")

            if not op.cyclic:
                draw_status_item(row, active=op.cap_holes, key='F', text="Cap Holes", gap=3)
                if op.cap_holes:
                    draw_status_item(row, key=['ALT', 'MMB_SCROLL'], text="Dissolve Angle")

            draw_status_item(row, active=op.allow_modal_width, key=['W', 'MOVE'], text="Adjust Width", gap=3)
            if op.allow_modal_width:
                draw_status_item(row, key=['ALT', 'W'], text="Reset")

        draw_status_item(row, active=op.allow_modal_tension, key=['T', 'MOVE'], text="Tension", gap=3)
        draw_status_item(row, key='Z', text="0.55")
        draw_status_item(row, key='X', text="0.7")
        draw_status_item(row, key='C', text="1.0")
        draw_status_item(row, key='V', text="1.33")

        if op.method == "FUSE":
            if op.handle_method == "FACE":
                draw_status_item(row, active=op.average, key='A', text="Average Tension")

    return draw


# ============================================================
# FilletToChamfer 圆角转倒角
# ============================================================
class FilletToChamfer(Operator):
    """
    圆角转倒角操作器

    功能: 将选中的圆角面转换为倒角面
    - 支持标记锐度和倒角权重
    - 自动提取轨道边

    要求: 网格编辑模式下有选中的圆角面
    """

    bl_idname = "ch.fillet_to_chamfer"
    bl_label = "Fillet to Chamfer"
    bl_description = "Convert fillet to chamfer"
    bl_options = {'REGISTER', 'UNDO'}

    mark_sharp: BoolProperty(name="Mark Sharp", default=False, description="Mark the generated edges sharp")  # type: ignore
    mark_bevel_weight: BoolProperty(name="Mark Bevel Weight", default=False, description="Write a bevel weight on the generated edges")  # type: ignore
    bevel_weight: FloatProperty(name="Bevel Weight", default=1.0, min=0.0, max=1.0, subtype='FACTOR', description="Bevel weight written to the generated edges")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return any(f.select for f in bm.faces)

    def execute(self, context: Context):
        obj = context.active_object
        me_data = obj.data

        bm = bmesh.from_edit_mesh(me_data)
        bm.normal_update()
        bm.select_mode = {'FACE'}

        bm.verts.ensure_lookup_table()
        bw = ensure_default_data_layers(bm, crease=False)[1]
        mg = build_mesh_graph(bm)
        faces = [f for f in bm.faces if f.select]

        sweeps, err = get_sweeps_from_fillet(bm, mg, faces)

        if not err:
            chamfer_faces, err = fillet_to_chamfer(bm, sweeps)

        if not err:
            chamfer_mg = build_mesh_graph(bm)
            ret, err = get_2_rails_from_chamfer(bm, chamfer_mg, chamfer_faces, False)

        if not err:
            chamfer_rails, cyclic = ret
            set_rail_sharps_and_bweights(bm, bw, chamfer_rails, cyclic, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)
            bmesh.update_edit_mesh(me_data)
        else:
            self.report({'WARNING'}, err)

        return {'FINISHED'}

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "mark_sharp")

        row = layout.row(align=True, heading="Mark Bevel Weight")
        row.prop(self, "mark_bevel_weight", text="")
        sub_row = row.row(align=True)
        sub_row.enabled = self.mark_bevel_weight
        sub_row.prop(self, "bevel_weight", text="")


# ============================================================
# 倒角/圆角转硬边 公共基类
# ============================================================
class _UnchamferBase(ModalOperatorMixin):
    """
    倒角转硬边公共基类

    提供交互流程(模态/直接执行), 属性与清理逻辑, 以及统一的去倒角核心流程;
    子类只按需覆盖 _get_target_faces 插入前置几何转换(Unfillet 先把圆角面转成倒角面).
    """

    handle_method: EnumProperty(name="Handle Method", items=handle_method_items, default="FACE", description="Whether the handles follow face borders or edge loops")  # type: ignore
    slide: FloatProperty(name="Slide", default=0, min=-1, max=1, subtype='FACTOR', description="Slide the new edge along the adjacent faces")  # type: ignore
    reverse: BoolProperty(name="Reverse", default=False, description="Reverse the direction of the conversion")  # type: ignore
    mark_sharp: BoolProperty(name="Mark Sharp", default=True, description="Mark the generated edges sharp")  # type: ignore
    mark_bevel_weight: BoolProperty(name="Mark Bevel Weight", default=False, description="Write a bevel weight on the generated edges")  # type: ignore
    bevel_weight: FloatProperty(name="Bevel Weight", default=1, min=0, max=1, subtype='FACTOR', description="Bevel weight written to the generated edges")  # type: ignore

    # --- 模态状态 ---
    cyclic: BoolProperty(name="Cyclic", description="Is loop faces", default=False, options={'HIDDEN'})  # type: ignore
    single: BoolProperty(name="Single", description="Is single face", default=False, options={'HIDDEN'})  # type: ignore
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    allow_modal_slide: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return any(f.select for f in bm.faces)

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        self.act_obj.update_from_editmode()

        self.slide = 0
        self.reverse = False
        self.allow_modal_slide = False
        self.init = True

        self.init_bm = _new_snapshot_bm(self.act_obj)

        depth_location = self.act_obj.matrix_world @ get_average_position([v.co for v in self.init_bm.verts if v.select])
        self.factor = get_zoom_factor(context, depth_location)

        self.init_mouse_position(event)

        try:
            ret = self._core_modal(self.act_obj)
        except Exception:
            # invoke 期即退化(如初始几何就报错): 此时状态栏/处理器尚未注册, 只需收敛快照资源
            # (对照 ChamferToFillet.invoke 的兜底; _core_modal 内层 try 之外仍有 mode_set/to_mesh)
            _logger.exception("Chamfer invoke failed")
            self.report({'ERROR'}, "Chamfer failed, see the system console for details")
            self.init_bm.free()
            self.init_bm = None
            return {'CANCELLED'}
        if not ret:
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        self.init_status(context, func=_draw_unchamfer_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 最小收敛并退出, 否则每个后续事件都抛 AttributeError 且模态永不收敛
            self._abort_without_area(context)
            return {'CANCELLED'}

        context.area.tag_redraw()

        events = ['H', 'S', 'B', 'W', 'R']
        if self.allow_modal_slide:
            events.append('MOUSEMOVE')

        if event.type in events or scroll(event):
            if event.type == 'MOUSEMOVE':
                wrapped = self.wrap_mouse_position(context, event)
                if self.pass_through:
                    self.pass_through = False
                elif self.allow_modal_slide and not wrapped:
                    divisor = 1000 if event.shift else 10 if event.ctrl else 100
                    delta_x = event.mouse_x - self.last_mouse_x
                    self.slide += delta_x / divisor

                if not wrapped:
                    self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y

            elif scroll(event):
                self._handle_scroll(event)
            else:
                self._handle_key_press(context, event)

            try:
                self.update_header_text(context)
                ret = self._core_modal(self.act_obj)

                if not ret:
                    self.finish(context)
                    return {'FINISHED'}
            except Exception:
                # 不得静默吞成 FINISHED: 否则用户看到"操作无声结束, 网格停在半成品",
                # 且控制台无任何线索. 记录并上报, 由 report 通道呈现给用户.
                # utils 抛错时 _core_modal 可能已切到 OBJECT 模式: 切回, 别把用户留在那里
                _logger.exception("%s modal failed", type(self).__name__)
                self.report({'ERROR'}, "Chamfer failed, see the system console for details")
                if context.mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                self.finish(context)
                return {'CANCELLED'}

        elif navigation_passthrough(event, alt=True, wheel=False):
            self.pass_through = True
            return {'PASS_THROUGH'}

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if self.allow_modal_slide:
                self.allow_modal_slide = False
            else:
                self.finish(context)
                return {'FINISHED'}

        elif event.type in {'SPACE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self.finish(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.finish(context, cancel=True)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _handle_scroll(self, event: Event):
        """处理滚轮事件"""
        if event.alt:
            direction = 1 if scroll_up(event) else -1
            self.bevel_weight = max(0, min(1, self.bevel_weight + 0.1 * direction))

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.value != "PRESS":
            return

        key_actions = {
            'H': lambda: setattr(self, 'handle_method', step_enum(self.handle_method, handle_method_items, 1)),
            'S': lambda: setattr(self, 'mark_sharp', not self.mark_sharp),
            'B': lambda: setattr(self, 'mark_bevel_weight', not self.mark_bevel_weight),
            'R': lambda: setattr(self, 'reverse', not self.reverse),
        }

        if event.type in key_actions:
            key_actions[event.type]()
        elif event.type == 'W':
            if event.alt:
                self.allow_modal_slide = False
                self.slide = 0
            else:
                self.allow_modal_slide = not self.allow_modal_slide
                if self.allow_modal_slide:
                    # 重启用拖动: 基线重置到当前位置, 否则首帧增量是 invoke 以来的全量位移
                    self.last_mouse_x, self.last_mouse_y = event.mouse_x, event.mouse_y

    def execute(self, context: Context):
        # 同 ChamferToFillet.execute 的直调守卫: 无交互状态时重建的快照取自未同步的 obj.data,
        # _apply_init_bm 会把该状态经模式往返写回(丢弃编辑缓冲中未同步的改动), 故干净取消
        if not hasattr(self, 'init') or not hasattr(self, 'init_bm') or self.init_bm is None:
            self.report({'WARNING'}, "Unchamfer requires interactive viewport input and cannot be executed directly")
            return {'CANCELLED'}

        act_obj = context.active_object

        _apply_init_bm(self.init_bm, act_obj)

        # 失败必须回滚: _unchamfer_core 失败前 _clean_up 已删倒角面, _core_execute 就地编辑
        # 活动网格(不经工作 bm), 不回滚会把破坏态留给 F9 重做(与模态路径的工作 bm 丢弃不同)
        if not self._core_execute(act_obj):
            _apply_init_bm(self.init_bm, act_obj)
            self._report_intersection_error()
            self.report({'WARNING'}, "Unchamfer failed, mesh restored to initial state")
            return {'CANCELLED'}
        return {'FINISHED'}

    def finish(self, context: Context, cancel: bool = False):
        """
        完成操作,清理资源

        Args:
            context: Blender上下文
            cancel: 是否为取消操作,取消时恢复初始状态
        """
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)

        if cancel:
            _apply_init_bm(self.init_bm, self.act_obj)
            self.init_bm.free()
            self.init_bm = None
        # 确认路径保留快照, 供F9 redo的execute恢复初始状态重算

        self.act_obj.update_from_editmode()
        force_ui_update(context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        row = layout.row(align=True)
        row.prop(self, "handle_method", expand=True)

        if self.handle_method == "FACE":
            layout.prop(self, "slide")

        row = layout.row(align=True, heading="Mark Bevel Weight")
        row.prop(self, "mark_bevel_weight", text="")
        sub_row = row.row(align=True)
        sub_row.enabled = self.mark_bevel_weight
        sub_row.prop(self, "bevel_weight", text="")

        layout.prop(self, "mark_sharp")
        if self.single:
            layout.prop(self, "reverse")

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        parts = []

        if self.handle_method == "FACE":
            parts.append(f"Slide: {format_adaptive_precision(self.slide, 2)}")

        if self.mark_bevel_weight:
            parts.append(f"Bevel Weight: {self.bevel_weight:.1f}")

        context.area.header_text_set(" | ".join(parts) if parts else None)

    def _clean_up(self, bm: BMesh, faces: list, double_verts: list | None = None):
        """
        清理原始倒角面

        Args:
            bm: BMesh对象
            faces: 要删除的面列表
            double_verts: 需要合并的重叠顶点列表
        """
        bmesh.ops.delete(bm, geom=faces, context='FACES')

        if double_verts:
            bmesh.ops.remove_doubles(bm, verts=double_verts, dist=0.00001)

            two_edged_verts = [v for v in double_verts if v.is_valid and len(v.link_edges) == 2]
            if two_edged_verts:
                bmesh.ops.dissolve_verts(bm, verts=two_edged_verts)

    def _report_intersection_error(self):
        """报告交点计算错误"""
        if self.single:
            self.report({'WARNING'}, "Loop edges don't intersect. You can't unchamfer in this direction! Try toggling Reverse.")
        else:
            self.report({'WARNING'}, "Loop edges don't intersect.")

    def _get_target_faces(self, bm: BMesh, act_obj: Object) -> tuple[list, bool]:
        """
        获取待转换的目标面(子类可覆盖, 以便在取面之前插入前置几何转换)

        Args:
            bm: BMesh对象
            act_obj: 活动对象

        Returns:
            (目标面列表, 是否成功)
        """
        return [f for f in bm.faces if f.select], True

    def _init_selection_state(self, faces: list, apply_init: bool = False):
        """
        按目标面初始化单面状态; 模态首帧另需按面平滑态推断锐度标记

        Args:
            faces: 目标面列表
            apply_init: 是否为模态首帧(为True时消费 self.init 并推断锐度)
        """
        self.single = len(faces) == 1

        if apply_init and getattr(self, 'init', False):
            self.init = False
            self.mark_sharp = any(f.smooth for f in faces)

    def _unchamfer_core(self, bm: BMesh, act_obj: Object, faces: list, bw, edge_layers: list) -> bool:
        """
        倒角面转硬边的核心几何流程: 提取轨道 -> 计算手柄交点 -> 清理原面 -> 标记锐度与权重

        Args:
            bm: BMesh对象
            act_obj: 活动对象
            faces: 目标面列表
            bw: 倒角权重层
            edge_layers: 边数据层列表

        Returns:
            bool: 是否成功(失败时已上报; 网格可能已被局部修改, 由调用方决定回滚)
        """
        mg = build_mesh_graph(bm)

        ret, err = get_2_rails_from_chamfer(bm, mg, faces, self.reverse)

        if err:
            self.report({'WARNING'}, err)
            return False

        rails, cyclic = ret
        self.cyclic = cyclic

        sweeps = init_sweeps(bm, act_obj, rails)

        _, err = get_loops(edge_layers, sweeps)
        if err:
            self.report({'WARNING'}, report(err))
            return False

        if self.handle_method == "FACE":
            create_face_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_face_intersection(bm, sweeps, slide=self.slide)
        else:
            create_loop_intersection_handles(sweeps, tension=1)
            double_verts = unchamfer_loop_intersection(bm, sweeps)

        self._clean_up(bm, faces, double_verts)

        if not double_verts:
            self._report_intersection_error()
            return False

        set_sharps_and_bweights([e for e in bm.edges if e.select], bw, self.mark_sharp, self.mark_bevel_weight, self.bevel_weight)
        return True

    def _core_modal(self, act_obj: Object) -> bool:
        """
        模态模式下的核心转换: 回写初始快照 -> 构建独立工作网格 -> 核心流程 -> 写回并释放

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        bpy.ops.object.mode_set(mode='OBJECT')

        if self.init_bm:
            self.init_bm.to_mesh(act_obj.data)

        # 任何分支(含快照构建与 utils 抛错)都必须释放工作 bm 并切回编辑模式, 否则用户被留在 OBJECT 模式且内存泄漏
        bm = None
        try:
            bm = _new_work_bm(act_obj)

            _, bw, edge_layers = _prepare_edge_layers(bm)

            faces, ok = self._get_target_faces(bm, act_obj)
            if not ok:
                return False

            self._init_selection_state(faces, apply_init=True)

            if not self._unchamfer_core(bm, act_obj, faces, bw, edge_layers):
                return False

            bm.to_mesh(act_obj.data)
            return True
        finally:
            if bm is not None:
                bm.free()
            bpy.ops.object.mode_set(mode='EDIT')

    def _core_execute(self, act_obj: Object) -> bool:
        """
        直接执行模式下的核心转换: 就地编辑网格(不经过快照回写)

        Args:
            act_obj: 活动对象

        Returns:
            bool: 操作是否成功
        """
        bm = bmesh.from_edit_mesh(act_obj.data)
        bm.normal_update()
        bm.select_mode = {'FACE'}
        bm.verts.ensure_lookup_table()

        _, bw, edge_layers = _prepare_edge_layers(bm)

        faces, ok = self._get_target_faces(bm, act_obj)
        if not ok:
            return False

        self._init_selection_state(faces)

        if not self._unchamfer_core(bm, act_obj, faces, bw, edge_layers):
            return False

        bmesh.update_edit_mesh(act_obj.data)
        return True


# ============================================================
# Unchamfer 倒角转硬边
# ============================================================
class Unchamfer(Operator, _UnchamferBase):
    """
    倒角转硬边操作器

    功能: 将选中的倒角面转换为硬边
    - 支持FACE和LOOP两种手柄方法
    - 支持实时预览和参数调整
    - 支持滑动,锐度,倒角权重等参数调整

    要求: 网格编辑模式下有选中的倒角面
    """

    bl_idname = "ch.unchamfer"
    bl_label = "Unchamfer"
    bl_description = "Reconstruct hard edge from Chamfer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        if context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(context.active_object.data)
            return any(f.select for f in bm.faces) or any(e.select for e in bm.edges)


def _draw_unchamfer_status(op):
    """
    返回 Unchamfer/Unfillet 共用的状态栏绘制回调函数

    Args:
        op: 操作器实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, key='H', text=iface("Handle({})").format(iface(op.handle_method.capitalize())), gap=1)

        draw_status_item(row, active=op.mark_sharp, key='S', text="Sharp", gap=3)
        draw_status_item(row, active=op.mark_bevel_weight, key='B', text="Bevel Weight")
        if op.mark_bevel_weight:
            draw_status_item(row, key=['ALT', 'MMB_SCROLL'], text=f"({op.bevel_weight:.1f})")

        if op.handle_method == "FACE":
            draw_status_item(row, active=op.allow_modal_slide, key=['W', 'MOVE'], text="Slide", gap=3)
            draw_status_item(row, active=op.allow_modal_slide, key=['ALT', 'W'], text="Reset")

        if op.single:
            draw_status_item(row, active=op.reverse, key='R', text="Reverse")

    return draw


# ============================================================
# Unfillet 圆角转硬边
# ============================================================
class Unfillet(Operator, _UnchamferBase):
    """
    圆角转硬边操作器

    功能: 将选中的圆角面转换为硬边
    - 支持FACE和LOOP两种手柄方法
    - 支持实时预览和参数调整
    - 支持滑动,锐度,倒角权重等参数调整

    要求: 网格编辑模式下有选中的圆角面
    """

    bl_idname = "ch.unfillet"
    bl_label = "Unfillet"
    bl_description = "Reconstruct hard edge from Fillet by using Unfuse + Unchamfer in sequence"
    bl_options = {'REGISTER', 'UNDO'}

    def _get_target_faces(self, bm: BMesh, act_obj: Object) -> tuple[list, bool]:
        """
        将圆角面先转换为倒角面, 再交由基类按倒角面走统一的去倒角流程

        Args:
            bm: BMesh对象
            act_obj: 活动对象

        Returns:
            (倒角面列表, 是否成功)
        """
        mg = build_mesh_graph(bm)
        initial_faces = [f for f in bm.faces if f.select]

        initial_sweeps, err = get_sweeps_from_fillet(bm, mg, initial_faces)

        if err:
            self.report({'WARNING'}, err)
            return [], False

        chamfer_faces, err = fillet_to_chamfer(bm, initial_sweeps)

        if err:
            self.report({'WARNING'}, err)
            return [], False

        return chamfer_faces, True
