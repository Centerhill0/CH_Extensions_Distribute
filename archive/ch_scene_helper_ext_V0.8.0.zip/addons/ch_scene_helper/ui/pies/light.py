"""
灯光饼菜单模块

提供灯光模式下的操作饼菜单.
包含调节灯光基本属性,可见性,灯光链接,阴影链接等.
"""

from bpy.types import Menu, Context, UILayout

from ...operators.object.light_rig import (
    LightCopy,
    LightInstanceCopy,
    LightControllerSet,
    LightControllerRemove,
    LightRigAdjust,
    LightRigParamsReset,
)


def _pie_operator(row: UILayout, operator_cls, **kwargs) -> None:
    """饼菜单按钮: 显式标记"按视口活动灯解析目标"

    算子缺省跟灯光面板的活跃行(面板入口口径); 饼菜单以视口活动灯为操作对象, 两者的锚点在
    "选区同步"关闭或面板行被手动挪开后分叉, 故由入口显式声明(作者 2026-10-30 定).
    按钮沿用 UILayout 默认的 operator_context(INVOKE_DEFAULT)——模态类算子靠它进入交互,
    不要改成 EXEC_DEFAULT(那会触发算子的"需在 3D 视图交互执行"守卫).
    """
    props = row.operator(operator_cls.bl_idname, **kwargs)
    props.use_viewport_target = True


class LightPie(Menu):
    """
    灯光饼菜单

    提供添加不同类型灯光的快捷选项.
    支持点光源,太阳光源,聚光灯和区域光源.
    """

    bl_idname = "VIEW3D_MT_ch_light_pie"
    bl_label = "CH Light Pie"
    bl_description = "Light Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and context.active_object is not None and context.active_object.type == 'LIGHT' and context.scene.render.engine != 'BLENDER_WORKBENCH'

    def draw(self, context: Context):
        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()
        obj = context.active_object
        light = obj.data

        # 左:灯光的操作(全部按"视口活动灯"解析目标, 与面板入口的"面板活跃行"区分)
        col = pie.column()
        row = col.row(align=True)
        _pie_operator(row, LightCopy, text="Copy Light", icon='DUPLICATE')
        row.separator(factor=0.3)
        _pie_operator(row, LightInstanceCopy, text="Instance Copy", icon='SEQ_STRIP_DUPLICATE')
        row = col.row(align=True)
        _pie_operator(row, LightControllerSet, text="Set Controller", icon='LIGHTPROBE_PLANE')
        row.separator(factor=0.3)
        _pie_operator(row, LightControllerRemove, text="Remove Controller", icon='UNLINKED')
        row = col.row(align=True)
        _pie_operator(row, LightRigAdjust, icon='ORIENTATION_GIMBAL')
        row.separator(factor=0.3)
        _pie_operator(row, LightRigParamsReset, icon='FILE_REFRESH')

        # 右:
        pie.separator()

        # 下:灯光开关
        col = pie.column()
        col.ui_units_x = 11

        row = col.row()
        row.label(text="Light Settings")
        sub_col = row.box().column(align=False)

        sub_row = sub_col.row(align=True)
        sub_row.prop(light, "normalize")
        if light.type in {'POINT', 'SPOT'}:
            sub_row.prop(light, "use_soft_falloff")
        sub_col.prop(light, "use_shadow", text="Cast Shadow")

        row = col.row()
        row.label(text="Visibility")
        sub_col = row.box().column(align=False)

        row = sub_col.row(align=True)
        row.prop(obj, "visible_camera", text="Camera")
        row.prop(obj, "visible_volume_scatter", text="Volume Scatter")
        row = sub_col.row(align=True)
        row.prop(obj, "visible_diffuse", text="Diffuse")
        row.prop(obj, "visible_glossy", text="Glossy")
        row.prop(obj, "visible_transmission", text="Transmission")

        # 上:灯光链接/阴影链接
        col = pie.column()
        col.ui_units_x = 11

        row = col.row()
        row.label(text="Light Linking")
        sub = row.box().row(align=False)
        sub.operator("object.light_linking_receivers_link", text="Include").link_state = 'INCLUDE'
        sub.operator("object.light_linking_receivers_link", text="Exclude").link_state = 'EXCLUDE'

        row = col.row()
        row.label(text="Shadow Linking")
        sub = row.box().row(align=False)
        sub.operator("object.light_linking_blockers_link", text="Include").link_state = 'INCLUDE'
        sub.operator("object.light_linking_blockers_link", text="Exclude").link_state = 'EXCLUDE'
