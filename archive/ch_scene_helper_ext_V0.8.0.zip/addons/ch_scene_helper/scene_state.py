"""
场景助手列表状态访问模块

集中管理 WM 级 SceneHelperState 的读取、列表种类元数据、快照条目到真实数据块
的解析, 以及活跃索引/高亮写入. UI、算子和 handlers 都经本模块取状态, 不再各自
硬编码 WM 属性名或列表字段.

主要功能:
- get_state: 取 WM 级状态组
- LIST_SPECS: 六种资源列表的元数据注册表(五主列表 + 灯光集合附属列表; 集合/索引/条目类型/解析函数/开关)
- blocks_for / active_item / active_block / block_for_item: 快照条目与数据块互查
- highlight_item: 按真实名(+ 类型)定位并写活跃索引
- panel_material: 材质面板活动材质
- resolve_id / id_collection: 数据块类型 -> bpy.data 集合
- ordered_camera_objects: 按列表顺序取相机物体(供上一/下一相机)
"""

from dataclasses import dataclass
from typing import Any, Callable

import bpy
from bpy.types import Context

from ...common.blender.list_snapshot import set_index_by_name
from .utils import LIGHT_COLLECTION_PREFIX, is_runtime_image, scene_collection_names

# WM 级状态组属性名(状态组类型见 props.SceneHelperState)
STATE_PROP = "ch_scene_helper_state"

# 数据块类型标签 -> bpy.data 集合属性名(伪用户/数据块删除按类型解析)
_ID_COLLECTION_ATTRS = {
    'OBJECT': "objects",
    'MATERIAL': "materials",
    'IMAGE': "images",
    'WORLD': "worlds",
    'COLLECTION': "collections",
}


def get_state(context: Context):
    """取本插件的 WM 级列表状态组"""
    return getattr(context.window_manager, STATE_PROP)


def id_collection(kind: str):
    """数据块类型标签 -> bpy.data 集合; 未知类型返回 None"""
    attr = _ID_COLLECTION_ATTRS.get(kind)
    return getattr(bpy.data, attr, None) if attr is not None else None


def resolve_id(kind: str, name: str, linked: bool = False):
    """按数据块类型标签与名称取数据块; 未知类型或不存在返回 None

    linked 为真时按库链接标记消歧(同名本地/链接对): 名称命中的块与期望库链接态不符时,
    改遍历同名块(复制链接资源即产生同名本地副本, bpy.data 按名查找恒命中本地块).
    """
    collection = id_collection(kind)
    if collection is None:
        return None
    datablock = collection.get(name)
    if datablock is None:
        return None
    if bool(datablock.library) == bool(linked):
        return datablock
    for candidate in collection:
        if candidate.name == name and bool(candidate.library) == bool(linked):
            return candidate
    return None


def _resolve_by_library(collection, item):
    """按名称取数据块; 同名本地/链接对(复制链接资源即产生)按行标记消歧, 都不匹配返回 None

    bpy.data 按名称裸查恒命中本地块, 快照行必须带 linked 标记才能区分同名对.
    """
    block = collection.get(item.src_name)
    if block is None:
        return None
    item_linked = bool(getattr(item, "linked", False))
    if bool(block.library) == item_linked:
        return block
    for candidate in collection:
        if candidate.name == item.src_name and bool(candidate.library) == item_linked:
            return candidate
    return None


def _resolve_object(context: Context, item):
    """相机/灯光行 -> 场景物体(同名本地/链接对按行标记消歧)"""
    obj = context.scene.objects.get(item.src_name)
    if obj is None:
        return None
    item_linked = bool(getattr(item, "linked", False))
    if bool(obj.library) == item_linked:
        return obj
    for candidate in context.scene.objects:
        if candidate.name == item.src_name and bool(candidate.library) == item_linked:
            return candidate
    return None


def _resolve_material(context: Context, item):
    """材质行 -> 材质数据块(同名本地/链接对按行标记消歧)"""
    return _resolve_by_library(bpy.data.materials, item)


def _resolve_image(context: Context, item):
    """图像行 -> 图像数据块(同名本地/链接对按行标记消歧)"""
    return _resolve_by_library(bpy.data.images, item)


def _resolve_world(context: Context, item):
    """世界环境行 -> 世界数据块(同名本地/链接对按行标记消歧)"""
    return _resolve_by_library(bpy.data.worlds, item)


def _resolve_collection(context: Context, item):
    """灯光集合行 -> 集合数据块(同名本地/链接对按行标记消歧)"""
    return _resolve_by_library(bpy.data.collections, item)


@dataclass(frozen=True)
class ListSpec:
    """一种资源列表的元数据

    Attributes:
        name: 列表种类标识(同时作为算子 list_kind 的枚举标识)
        collection: 状态组里的快照集合属性名
        index: 状态组里的活跃索引属性名
        item_kind: 条目的默认数据块类型标签
        resolve: 快照条目 -> 真实数据块(失效返回 None)
        supports_sync: 是否参与"选区同步"
        zero_user_prop: "显示0用户"开关的属性名; None 表示该列表无此开关
    """

    name: str
    collection: str
    index: str
    item_kind: str
    resolve: Callable[[Context, Any], Any]
    supports_sync: bool = False
    zero_user_prop: str | None = None
    # 该列表的收集函数支持"显示库链接"过滤(材质/世界/图像), 选项菜单据此决定画不画开关
    supports_linked_filter: bool = False


# 列表种类注册表: 顺序即面板顺序(相机 -> 灯光 -> 材质 -> 世界环境 -> 图像;
# 灯光集合是灯光面板的附属列表, 紧随灯光之后).
# 所有"哪种列表用哪个集合/索引/开关"的判定都从这里取, 不再散落在各模块.
LIST_SPECS = {
    "cameras": ListSpec("cameras", "cameras", "cameras_active_index", 'OBJECT', _resolve_object, supports_sync=True),
    "lights": ListSpec("lights", "lights", "lights_active_index", 'OBJECT', _resolve_object, supports_sync=True),
    "light_collections": ListSpec("light_collections", "light_collections", "light_collections_active_index", 'COLLECTION', _resolve_collection),
    "materials": ListSpec("materials", "materials", "materials_active_index", 'MATERIAL', _resolve_material, supports_sync=True, zero_user_prop="show_zero_user_materials", supports_linked_filter=True),
    "worlds": ListSpec("worlds", "worlds", "worlds_active_index", 'WORLD', _resolve_world, zero_user_prop="show_zero_user_worlds", supports_linked_filter=True),
    "images": ListSpec("images", "images", "images_active_index", 'IMAGE', _resolve_image, supports_sync=True, zero_user_prop="show_zero_user_images", supports_linked_filter=True),
}


LIST_KINDS = tuple(LIST_SPECS)


def filter_sort_flags(state, kind: str) -> tuple:
    """列表内建过滤/排序开关(由 UIList.filter_items 镜像到 WM 状态)

    Returns:
        (字母排序开启, 反序开启); 未镜像过时按关闭处理
    """
    idx = LIST_KINDS.index(kind)
    return bool(state.filter_alpha[idx]), bool(state.filter_reverse[idx])


def blocks_for(context: Context, kind: str) -> list:
    """按快照顺序返回真实数据块列表(失效条目为 None, 与快照按下标对齐)"""
    spec = LIST_SPECS[kind]
    state = get_state(context)
    return [spec.resolve(context, item) for item in getattr(state, spec.collection)]


def all_blocks_for(context: Context, kind: str) -> list:
    """该种类的**全部**候选数据块(不受"显示0用户"等过滤影响), 用于顺序值物化

    排序/移动只改写可见子集的顺序值会让被隐藏的条目保留旧值并与新值冲突
    (打开"显示0用户"后插到列表中部). 物化前取全量, 保证值域唯一.
    库链接数据不可写自定义属性, 一律排除.
    """
    scene = context.scene
    if kind == "cameras":
        blocks = [obj for obj in scene.objects if obj.type == 'CAMERA']
    elif kind == "lights":
        blocks = [obj for obj in scene.objects if obj.type == 'LIGHT']
    elif kind == "materials":
        blocks = list(bpy.data.materials)
    elif kind == "worlds":
        blocks = list(bpy.data.worlds)
    elif kind == "images":
        # 运行期图像(Render Result / 合成器 Viewer)不参与列表排序, 判据与 0 用户过滤共用
        blocks = [img for img in bpy.data.images if not is_runtime_image(img)]
    elif kind == "light_collections":
        # 灯光集合列表只管理大纲可达的 CLS_ 前缀集合(排序范围同样只限前缀内)
        reachable = scene_collection_names(scene.collection)
        blocks = [coll for coll in bpy.data.collections if coll.name.startswith(LIGHT_COLLECTION_PREFIX) and coll.name in reachable]
    else:
        return []
    return [block for block in blocks if getattr(block, "library", None) is None]


def block_for_item(context: Context, kind: str, item):
    """单条快照条目 -> 真实数据块(失效返回 None)"""
    return LIST_SPECS[kind].resolve(context, item)


def active_item(context: Context, kind: str):
    """该列表的活跃快照条目; 无有效活跃项返回 None"""
    spec = LIST_SPECS[kind]
    state = get_state(context)
    collection = getattr(state, spec.collection)
    idx = getattr(state, spec.index)
    return collection[idx] if 0 <= idx < len(collection) else None


def active_block(context: Context, kind: str):
    """该列表活跃条目对应的真实数据块; 无有效项/已失效返回 None"""
    item = active_item(context, kind)
    return None if item is None else LIST_SPECS[kind].resolve(context, item)


def highlight_item(context: Context, kind: str, name: str, item_kind: str = "") -> bool:
    """把列表活跃索引指向命中条目(名称 + 可选类型), 返回是否命中

    活跃索引经 common.list_snapshot 的护栏写入, 不触发列表 update 回调.
    """
    spec = LIST_SPECS[kind]
    state = get_state(context)
    return set_index_by_name(state, spec.collection, spec.index, name, item_kind)


def panel_material(context: Context):
    """材质面板活动条目对应的材质(同名本地/链接对按行标记消歧); 无有效条目返回 None"""
    item = active_item(context, "materials")
    return None if item is None else LIST_SPECS["materials"].resolve(context, item)


def ordered_camera_objects(context: Context) -> list:
    """按快照顺序取场景相机物体; 快照尚未建立时退回视图层内按名称排序

    相机列表的顺序由 ch_scene_order 决定, 不按名称; 快照存在但全部失效时同样回退.
    同名本地/链接相机两行按行标记消歧(与列表行内算子同口径), 不能按名称裸查.
    """
    state = getattr(context.window_manager, STATE_PROP, None)
    if state is not None:
        ordered = [LIST_SPECS["cameras"].resolve(context, item) for item in state.cameras]
        ordered = [obj for obj in ordered if obj is not None and obj.type == 'CAMERA']
        if ordered:
            return ordered
    return sorted((obj for obj in context.view_layer.objects if obj.type == 'CAMERA'), key=lambda obj: obj.name)
