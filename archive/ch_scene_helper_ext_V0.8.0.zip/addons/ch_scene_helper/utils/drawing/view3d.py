"""
3D 视图叠加绘制模块

模态轨迹预览的 GPU 绘制层: 世界坐标折线(逐顶点渐变色) / 屏幕像素级实心圆点 /
绘制处理器注册(带异常自停). 绘制阶段固定 POST_VIEW——该阶段视图的投影/模型矩阵
已就位, 直接传世界坐标即可, 不必自行装载矩阵(与 ch_utils_tools 的
utils/drawing/gpu.py 同源口径).

主要功能:
- gradient_by_distance: 按到锚点的距离衰减颜色的饱和度与明度(轨迹线"近灯亮、远灯暗")
- draw_polyline: 世界坐标折线(可闭合), 颜色逐顶点插值
- draw_discs: 按屏幕像素直径绘制实心圆点(圆面朝向相机, 缩放视图时直径不变)
- register_view_draw: 注册 3D 视图绘制回调, 返回处理器句柄
- unregister_view_draw / remove_all_view_draws: 摘除单个 / 清空全部残留处理器
"""

from colorsys import hsv_to_rgb, rgb_to_hsv
from math import cos, pi, sin

import bpy
import gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

# 内置着色器缓存: 模态每帧绘制, from_builtin 每次都会新建包装对象
_polyline_shader = None
_solid_shader = None

# 已注册处理器句柄: 供插件注销时兜底摘除(模态异常退出留下的回调)
_handles: list = []

# 圆盘边数: 5~10 像素直径下 12 边已看不出折角, 同时压住单帧顶点数
_DISC_SEGMENTS = 12


def _shader(kind: str):
    """取内置着色器(首次创建后缓存): 'polyline' 平滑色折线, 'solid' 实色面片"""
    global _polyline_shader, _solid_shader
    if kind == 'polyline':
        if _polyline_shader is None:
            _polyline_shader = gpu.shader.from_builtin('POLYLINE_SMOOTH_COLOR')
        return _polyline_shader
    if _solid_shader is None:
        _solid_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    return _solid_shader


def _scale_saturation_value(color: tuple, factor: float) -> tuple:
    """按 HSV 的 S / V 分量同时缩放颜色(色相不变), factor 为饱和度与明度的共同倍率"""
    hue, saturation, value = rgb_to_hsv(color[0], color[1], color[2])
    return hsv_to_rgb(hue, min(max(saturation * factor, 0.0), 1.0), min(max(value * factor, 0.0), 1.0))


def gradient_by_distance(points, anchor, color, min_factor: float = 0.5) -> list[tuple]:
    """按到 anchor 的距离对 color 的饱和度与明度做衰减, 返回与 points 等长的颜色序列

    距锚点最近的采样点保持原色(饱和度与明度都等于入参 color), 最远的点把饱和度与明度
    同时乘 min_factor——按"最近~最远"区间归一, 故折线离散不会让灯所在处偏色(轨迹是
    采样折线, 灯位通常落在两个采样点之间); 色相全程不变.

    Args:
        points: 世界坐标点序列
        anchor: 锚点世界坐标(灯光当前位置)
        color: 基准色 RGB 三元组
        min_factor: 最远处的饱和度与明度倍率(0.5 即两者都减半)
    Returns:
        与 points 等长的 RGB 三元组序列
    """
    if not points:
        return []
    distances = [(point - anchor).length for point in points]
    nearest = min(distances)
    span = max(distances) - nearest
    if span <= 1e-9:
        return [tuple(color)] * len(points)
    return [_scale_saturation_value(color, 1.0 - (1.0 - min_factor) * ((distance - nearest) / span)) for distance in distances]


def draw_polyline(points, colors, width: float = 1.5, alpha: float = 1.0, xray: bool = True, closed: bool = False) -> None:
    """在 3D 视图绘制一条世界坐标折线, 颜色按顶点插值(可做渐变)

    Args:
        points: 世界坐标点序列(少于 2 点直接跳过)
        colors: 与 points 等长的 RGB 三元组序列
        width: 线宽(像素)
        alpha: 透明度
        xray: True 关闭深度测试(始终显示在前), False 由场景几何遮挡
        closed: 是否首尾闭合(圆环/大圆用 True)
    """
    if len(points) < 2 or len(colors) != len(points):
        return
    coords = list(points)
    vertex_colors = [(color[0], color[1], color[2], alpha) for color in colors]
    if closed:
        coords.append(coords[0])
        vertex_colors.append(vertex_colors[0])
    indices = [(index, index + 1) for index in range(len(coords) - 1)]
    # 状态用后即复位: 同一帧后续的视图绘制(网格/叠加)依赖默认的深度测试与混合状态
    gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
    gpu.state.blend_set('ALPHA')
    shader = _shader('polyline')
    shader.bind()
    shader.uniform_float("lineWidth", width)
    shader.uniform_float("viewportSize", gpu.state.scissor_get()[2:])
    batch = batch_for_shader(shader, 'LINES', {"pos": coords, "color": vertex_colors}, indices=indices)
    batch.draw(shader)
    gpu.state.blend_set('NONE')
    gpu.state.depth_test_set('NONE')


def draw_discs(points, sizes_px, colors, alpha: float = 1.0, xray: bool = True, region=None, region_data=None) -> None:
    """按屏幕像素直径绘制实心圆点, 圆面朝向相机(缩放视图时直径不变)

    内置点着色器画的是方点(无 AA 圆形变体), 故用三角扇拼圆盘: 半径按"该点所在深度的
    像素当量"换算, 屏幕直径即 sizes_px 像素. 像素当量需视图投影(region / region_data),
    缺任一项时跳过绘制; 同色圆点合并成一次绘制.

    Args:
        points: 圆心世界坐标序列
        sizes_px: 与 points 等长的直径(像素)
        colors: 与 points 等长的 RGB 三元组序列
        alpha: 透明度
        xray: True 关闭深度测试(始终显示在前), False 由场景几何遮挡
        region: 3D 视图区域(与 region_data 一起用于求像素当量)
        region_data: 该区域的 RegionView3D
    """
    if not points or region is None or region_data is None:
        return
    if not (len(points) == len(sizes_px) == len(colors)):
        return
    # 投影必须与当前绘制视口一致(多视图/上下文过期时宁可不画, 也不把圆点画到错位置)
    viewport = tuple(round(value) for value in gpu.state.scissor_get()[2:])
    if abs(viewport[0] - round(region.width)) > 1 or abs(viewport[1] - round(region.height)) > 1:
        return
    rotation = region_data.view_matrix.to_3x3().inverted()
    right = rotation @ Vector((1.0, 0.0, 0.0))
    up = rotation @ Vector((0.0, 1.0, 0.0))
    # 按颜色分组(预览里至多 4 种: 轨迹色 + X/Y/Z 轴线色), 每组一次绘制
    groups: dict = {}
    for center, size_px, color in zip(points, sizes_px, colors):
        screen = view3d_utils.location_3d_to_region_2d(region, region_data, center)
        edge = view3d_utils.location_3d_to_region_2d(region, region_data, center + right)
        if screen is None or edge is None:
            continue
        pixels_per_unit = (edge - screen).length
        if pixels_per_unit <= 0.0:
            continue
        radius = size_px * 0.5 / pixels_per_unit
        key = (round(color[0], 5), round(color[1], 5), round(color[2], 5))
        coords, indices = groups.setdefault(key, ([], []))
        base = len(coords)
        coords.append(center)
        for index in range(_DISC_SEGMENTS):
            angle = 2.0 * pi * index / _DISC_SEGMENTS
            coords.append(center + (right * cos(angle) + up * sin(angle)) * radius)
        for index in range(_DISC_SEGMENTS):
            indices.append((base, base + 1 + index, base + 1 + (index + 1) % _DISC_SEGMENTS))
    if not groups:
        return
    gpu.state.depth_test_set('NONE' if xray else 'LESS_EQUAL')
    gpu.state.blend_set('ALPHA')
    shader = _shader('solid')
    shader.bind()
    for key, (coords, indices) in groups.items():
        if not indices:
            continue
        # 实色着色器只有 uniform color: 逐组下发颜色(组内同色, 视觉上与逐点定色等价)
        shader.uniform_float("color", (key[0], key[1], key[2], alpha))
        batch = batch_for_shader(shader, 'TRIS', {"pos": coords}, indices=indices)
        batch.draw(shader)
    gpu.state.blend_set('NONE')
    gpu.state.depth_test_set('NONE')


def register_view_draw(draw_func) -> object:
    """注册 3D 视图绘制回调, 返回处理器句柄

    draw_func 为无参可调用(自行读偏好与物体变换): 绘制回调里没有可信的 bpy.context,
    故不派发上下文参数. 回调内抛异常只置停用标志并停止绘制, 不在绘制过程中摘除处理器
    (绘制期摘处理器有崩溃风险), 摘除统一由模态收尾或插件注销执行.

    Args:
        draw_func: 无参绘制回调
    Returns:
        处理器句柄(交 unregister_view_draw 摘除)
    """
    state = {"alive": True}

    def draw():
        if not state["alive"]:
            return
        try:
            draw_func()
        except Exception:  # noqa: BLE001 - 回调内异常必须吞掉, 否则每帧向控制台刷错
            state["alive"] = False

    handle = bpy.types.SpaceView3D.draw_handler_add(draw, (), 'WINDOW', 'POST_VIEW')
    _handles.append(handle)
    return handle


def unregister_view_draw(handle) -> None:
    """摘除绘制处理器(重复摘除或所属窗口已关闭时静默跳过)"""
    if handle is None:
        return
    if handle in _handles:
        _handles.remove(handle)
    try:
        bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
    except (ValueError, ReferenceError):
        pass


def remove_all_view_draws() -> None:
    """清空全部残留处理器(插件注销时调用)"""
    for handle in list(_handles):
        unregister_view_draw(handle)
