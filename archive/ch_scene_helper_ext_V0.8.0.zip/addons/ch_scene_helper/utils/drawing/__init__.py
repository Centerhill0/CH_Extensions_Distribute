"""
绘制子包

模态轨迹预览的 GPU 绘制能力; 公共 API 经本 __init__ 再导出至 utils 顶层命名空间,
未在此列出的模块成员为子包内部协作 API.
"""

from .view3d import draw_discs, draw_polyline, gradient_by_distance, register_view_draw, remove_all_view_draws, unregister_view_draw

__all__ = [
    "gradient_by_distance",
    "draw_polyline",
    "draw_discs",
    "register_view_draw",
    "unregister_view_draw",
    "remove_all_view_draws",
]
