"""
算法层工具模块 (utils)

为交互层提供算法与封装, 依赖方向为: operators/ui -> utils -> common.

子包结构:
- blender/: Blender API 封装 (材质动作/灯光/场景数据收集/选中/算子可用性);
  列表顺序见 common/blender/list_order.py(两插件共用)
- drawing/: 模态轨迹预览的 GPU 绘制 (3D 视图折线/像素级圆点/处理器注册)

公共 API: 各子包 __init__ 显式再导出的名字经星号导入汇聚于此;
未列出的模块成员为 utils 内部协作 API, 不进入本命名空间.
"""

from .blender import *
from .drawing import *
