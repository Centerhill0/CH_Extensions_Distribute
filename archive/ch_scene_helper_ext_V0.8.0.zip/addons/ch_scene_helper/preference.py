"""
偏好设置模块

提供以下功能:
- CHSceneHelperPreferences: 插件偏好(灯光控制模态参数 / 快捷键)
- get_prefs: 取本插件偏好实例

面板为左右两列布局(不再分页签):
- 左列: Light Control(灯光控制模态的区域归一幅度与精确比率 + 轨迹预览总开关与线型参数,
  线型参数仅在总开关打开时绘制)
- 右列: 本插件已注册的快捷键列表(饼菜单 + 灯光控制), 附 rna_keymap_ui 的标准改键控件

注: 列表的"选区同步"与"显示0用户"开关在面板选项菜单内,
状态存 WM 级 SceneHelperState, 不随 .blend 保存.
"""

from math import radians

import bpy
from bpy.types import AddonPreferences, Context, KeyConfig, UILayout
from rna_keymap_ui import draw_kmi

from .config import __addon_name__
from .keymaps import addon_keymaps


def _draw_hotkey_column(layout: UILayout, title: str, icon: str, groups: list, kc: KeyConfig) -> None:
    """绘制单列快捷键分组列表"""
    col = layout.box()
    col.label(text=title, icon=icon)
    for name, keymap_items in groups:
        row = col.column(align=True)
        row.label(text=name)
        for label, km, kmi in keymap_items:
            split = row.split(factor=0.2)
            c = split.column()
            c.active = False
            c.label(text=label)
            try:
                draw_kmi(km.keymap_items, kc, km, kmi, split, 0)
            except (ReferenceError, AttributeError, ValueError):
                # 用户在本页删除快捷键后, 保存的 kmi 句柄会失效; 跳过该行而不是让整页绘制崩溃
                split.label(text="(removed)")
        row.separator(factor=1, type='LINE')


class CHSceneHelperPreferences(AddonPreferences):
    """场景助手偏好设置"""

    bl_idname = __addon_name__

    # 灯光控制模态的区域归一幅度与 Shift 精确比率
    light_rig_angle_sweep: bpy.props.FloatProperty(
        name="Angle Sweep",
        description="Rotation for azimuth / elevation while the mouse crosses the full region width (modal L)",
        subtype='ANGLE',
        default=radians(180.0),
        min=0.0,
    )  # type: ignore
    light_rig_power_span: bpy.props.FloatProperty(
        name="Power Span",
        description="Brightness change while the mouse crosses the full region width (modal L)",
        subtype='POWER',
        default=1000.0,
        min=0.0,
    )  # type: ignore
    light_rig_distance_span: bpy.props.FloatProperty(
        name="Distance Span",
        description="Distance change while the mouse crosses the full region width (modal L)",
        subtype='DISTANCE',
        default=5.0,
        min=0.0,
    )  # type: ignore
    light_rig_shift_factor: bpy.props.FloatProperty(
        name="Precise Factor",
        description="Adjustment rate multiplier while Shift is held (modal L)",
        subtype='FACTOR',
        default=0.5,
        min=0.01,
        max=1.0,
    )  # type: ignore

    # 模态 A/D 档的轨迹预览(方位圆环 + 高度大圆): 总开关与线型参数
    light_rig_show_preview: bpy.props.BoolProperty(
        name="Trajectory Preview",
        description="Draw the trajectory preview (azimuth ring and elevation great circle) in the 3D view while adjusting (modal L, A and D modes)",
        default=True,
    )  # type: ignore
    light_rig_preview_azimuth_color: bpy.props.FloatVectorProperty(
        name="Azimuth Track Color",
        description="Color of the horizontal azimuth ring, the radius line and the plain tick marks",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 0.0),
    )  # type: ignore
    light_rig_preview_elevation_color: bpy.props.FloatVectorProperty(
        name="Elevation Track Color",
        description="Color of the elevation great circle",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0.0, 1.0, 1.0),
    )  # type: ignore
    light_rig_preview_line_width: bpy.props.FloatProperty(
        name="Track Line Width",
        description="Preview line width in pixels; the tick dots are three times this diameter, the four axis ticks five times",
        subtype='PIXEL',
        default=2.0,
        min=0.5,
        max=5.0,
    )  # type: ignore
    light_rig_preview_show_ticks: bpy.props.BoolProperty(
        name="Reference Ticks",
        description="Draw tick dots on both tracks; the four axis ticks (0/90/180/270 degrees) use the X/Y/Z axis colors and a larger diameter",
        default=True,
    )  # type: ignore
    # 键名由 light_rig_preview_tick_step 改为 ..._tick_angle: 从"整数度"改成 ANGLE 子类型
    # (内部弧度、界面显示度). 沿用旧键会让已存的 15 被当成 15 弧度并钳到上限 90°, 故换名
    # 让新键按默认值 30° 起步
    light_rig_preview_tick_angle: bpy.props.FloatProperty(
        name="Tick Interval",
        description="Degrees between tick marks on the trajectory",
        subtype='ANGLE',
        default=radians(30.0),
        min=radians(1.0),
        max=radians(90.0),
    )  # type: ignore
    light_rig_preview_xray: bpy.props.BoolProperty(
        name="Always in Front",
        description="Draw the preview over the scene objects; turn off to let the geometry hide it",
        default=True,
    )  # type: ignore

    def draw(self, context: Context):
        kc = context.window_manager.keyconfigs.addon
        layout = self.layout

        # 左右两列: 左列参数设置, 右列快捷键(饼菜单 + 灯光控制)
        columns = layout.split(factor=0.4)

        # 左列: 灯光控制模态参数
        left = columns.column()
        box = left.box()
        box.label(text="Light Control", icon='ORIENTATION_GIMBAL')
        box.use_property_split = True
        box.use_property_decorate = False
        box.prop(self, "light_rig_angle_sweep", text="Angle Sweep")
        box.prop(self, "light_rig_power_span", text="Power Span")
        box.prop(self, "light_rig_distance_span", text="Distance Span")
        box.prop(self, "light_rig_shift_factor", text="Precise Factor")
        # 轨迹预览开关紧跟精确比率; 关闭时整组线型参数**不绘制**(而非置灰, 作者 2026-10-30 定)
        box.prop(self, "light_rig_show_preview")
        if self.light_rig_show_preview:
            box = box.box()
            box.prop(self, "light_rig_preview_xray", text="Always in Front")
            box.prop(self, "light_rig_preview_azimuth_color", text="Azimuth Track Color")
            box.prop(self, "light_rig_preview_elevation_color", text="Elevation Track Color")
            box.prop(self, "light_rig_preview_line_width", text="Track Line Width")
            box.prop(self, "light_rig_preview_show_ticks", text="Reference Ticks")
            if self.light_rig_preview_show_ticks:
                box.prop(self, "light_rig_preview_tick_angle", text="Tick Interval")

        # 右列: 快捷键列表(饼菜单 + 灯光控制)
        right = columns.column()
        groups = [(name, items) for name, items in addon_keymaps.items()]
        _draw_hotkey_column(right, "Hotkeys", "KEY_COMMAND", groups, kc)


def get_prefs() -> CHSceneHelperPreferences:
    return bpy.context.preferences.addons[__addon_name__].preferences
