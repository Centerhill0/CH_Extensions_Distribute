"""灯光控制器 rig 操作器模块

"空物体控制器(父级) + 面光源"rig 的全套交互:
- LightAdd: 添加灯光壳算子(默认弹原生灯光选择面板; +Shift/+Ctrl/+Alt 直接建 rig)
- LightCopy / LightInstanceCopy: 复制灯光(数据独立副本) / 实例复制(共享灯光数据)
- LightControllerSet: 给活动灯光设置控制器(无控制器则绑定, 已有则挪位重设)
- LightRigParamsReset: 把活动灯光 rig 的四参数(方位/高度/距离/自旋转)恢复默认值
- LightControllerRemove: 摘除活动灯光的控制器
- LightRigAdjust: L 键模态, 调灯光方位/距离/功率与控制器吸附对齐

操作流程:
- 面板按钮族(复制/实例/设置控制器/摘控制器/重置参数)作用于灯光面板的活跃灯光行;
- 灯光饼菜单(Alt+L)复用同一批算子, 但按"视口活动灯"解析目标(隐藏属性 use_viewport_target):
  面板与饼菜单的锚点不同, 由入口显式声明, 避免选中同步关闭或面板行被挪开后两边分叉;
- 模态算子按"选到灯光或控制器或二者都选中"解析 rig, 从任一侧进入都能操作整套;
- 模态 A 档与 D 档在 3D 视图叠加轨迹预览(方位圆环 + 高度大圆 + 半径连线 + 刻度圆点),
  颜色按到灯光的距离做饱和度衰减, 线宽/刻度/遮挡与开关读偏好, 只画不改数据;
- rig 硬性约束: 一个控制器只挂一个灯光子级(作者 2026-10-28 定).

快捷键:
- L: LightRigAdjust(仅物体模式, 选区里有 rig; 键位见 keymaps.py 的 LIGHT_RIG 组)
- 面板"+"按钮的修饰键: +Shift 选中集第一个非灯光物体 / +Ctrl 游标 / +Alt 世界原点
"""

import bpy
from math import degrees

from mathutils import Matrix, Vector
from bpy.props import BoolProperty
from bpy.types import Context, Event, Object, Operator

from .....common.i18n.i18n import iface, report
from ...handlers import refresh_lists, set_sync_suppressed
from ...modal_base import ModalOperatorMixin, draw_status_item, force_statusbar_redraw, force_ui_update, ignore_events, navigation_passthrough
from ...scene_state import active_block, highlight_item
from ...utils import (
    add_controller,
    align_controller_y,
    collect_light_blocks,
    copy_light_rig,
    create_light_rig,
    draw_discs,
    draw_polyline,
    get_controller_azimuth,
    get_controller_elevation,
    get_light_distance,
    gradient_by_distance,
    is_selectable,
    raycast_surface,
    reflection_direction,
    remove_controller,
    reset_controller,
    reset_light_self_rotation,
    resolve_rig,
    rig_controller_of,
    rig_init_distance,
    rig_trajectory,
    rig_trajectory_ticks,
    set_controller_azimuth,
    set_controller_elevation,
    set_light_distance,
)
from ..utils._base import TranslatedDescriptionMixin
from ...preference import get_prefs
from ...utils._constants import RIG_DEFAULT_ELEVATION

# 模态的调节模式键(A 为基础档; S/D 为按住式, 松开回落到 A)
_AXIS_KEYS = ('A', 'S', 'D')

# 按住式调节键(作者 2026-10-30 定): 按住期间生效, 松开即回基础档 A
_HOLD_KEYS = ('S', 'D')

# 显示轨迹预览的档位: 方位/高度(A)与距离(D)共用同一条球面轨迹, 两档都显示
_PREVIEW_AXES = ('A', 'D')

# 轨迹预览线透明度: 轨迹线压过背景但不遮模型; 刻度圆点是实心参考点, 用不透明
_PREVIEW_LINE_ALPHA = 0.85
_PREVIEW_SPOKE_ALPHA = 0.5
_TICK_ALPHA = 1.0
# 刻度圆点直径 = 轨迹线宽的倍数; 正轴刻度再放大(作者 2026-10-30 定: 3 倍 / 5 倍)
_TICK_DIAMETER_SCALE = 3.0
_AXIS_TICK_DIAMETER_SCALE = 5.0
# 轨迹线渐变: 灯光处保持偏好色的饱和度与明度, 距灯光最远处两者都衰减到该倍率
# (作者 2026-10-30 定: 一半)
_FAR_SCALE = 0.5
# 正轴刻度(0/90/180/270)的颜色: X 红 / Y 绿 / Z 蓝, 取与 Blender 轴向 gizmo 同色系的实心色
_AXIS_TICK_COLORS = {"X": (0.95, 0.25, 0.25), "Y": (0.35, 0.85, 0.25), "Z": (0.25, 0.5, 0.95)}


def _draw_rig_status(op):
    """模态状态栏: 组合键提示(绘制风格对齐 chamfer.py 的 ChamferToFillet;

    作者 2026-10-29 定: 不画算子标题, 导航三键后跟 A/S/D 模式键, 再 Shift/Ctrl/Alt)
    """

    def draw(self, context: Context):
        row = self.layout.row(align=True)
        draw_status_item(row, key='LMB', text=iface("Finish"))
        draw_status_item(row, key='MMB', text=iface("Viewport Navigation"))
        draw_status_item(row, key='RMB', text=iface("Cancel"))
        draw_status_item(row, key='A', text=iface("Azimuth/Elevation"), gap=1)
        draw_status_item(row, key='S', text=iface("Brightness"))
        draw_status_item(row, key='D', text=iface("Distance"))
        draw_status_item(row, key='SHIFT', text=iface("Precise"), gap=1)
        draw_status_item(row, key='CTRL', text=iface("Snap Normal"))
        draw_status_item(row, key='ALT', text=iface("Snap Reflect"))

    return draw


def _preview_projection(op) -> tuple:
    """绘制期取当前 3D 视图的投影来源(区域 + RegionView3D), 供像素级圆点换算

    绘制回调里没有可信的 bpy.context: 先按当前上下文取, 取不到再回落到模态所在区域
    自身的 WINDOW 区域(圆点直径只与视图尺寸/朝向有关, 与画布无关). 两者都不可得返回
    (None, None), 由绘制层跳过圆点——宁可不画也不画错位置.
    """
    context = bpy.context
    region = getattr(context, 'region', None)
    region_data = getattr(context, 'region_data', None)
    if region is not None and region_data is not None:
        return region, region_data
    area = getattr(op, 'area', None)
    if area is not None:
        for area_region in area.regions:
            if area_region.type == 'WINDOW':
                return area_region, area_region.data
    return None, None


def _panel_light(context: Context):
    """灯光面板活跃条目对应的灯光物体; 无有效条目/类型不符返回 None"""
    obj = active_block(context, "lights")
    return obj if obj is not None and obj.type == 'LIGHT' else None


def _viewport_light(context: Context):
    """视口活动物体是灯光时返回它, 否则 None"""
    active = context.view_layer.objects.active
    return active if active is not None and active.type == 'LIGHT' else None


def _target_light(context: Context, use_viewport_target: bool):
    """按入口解析操作目标灯: 饼菜单取视口活动灯, 面板取面板活跃行

    两个入口的锚点本就不同——面板按钮操作"灯光面板的活跃行", 饼菜单以"视口活动灯"为
    操作对象; 选中同步关闭或面板行被手动挪开后两者会分叉, 故由入口显式声明(隐藏属性
    use_viewport_target, 饼菜单置 True)。视口活动物体不是灯光时回退面板行, 与面板入口
    同口径(饼菜单自身的 poll 已保证活动物体是灯光, 此处兜底直调/异常路径).
    """
    if use_viewport_target:
        light = _viewport_light(context)
        if light is not None:
            return light
    return _panel_light(context)


def _candidate_lights(context: Context) -> list:
    """按钮可用性判定用的目标候选: 视口活动灯 + 面板活跃灯(去重, 不含 None)

    poll 在 UI 绘制期执行, 拿不到入口标记(那是 UI 按钮带上、invoke 才生效的属性), 故
    按候选集判"按钮是否可用"; 真正的操作目标由 _target_light 按入口再定.
    """
    candidates = []
    for light in (_viewport_light(context), _panel_light(context)):
        if light is not None and light not in candidates:
            candidates.append(light)
    return candidates


class ViewportTargetMixin:
    """饼菜单入口标记: True 时按视口活动灯解析目标, False(缺省)跟灯光面板活跃行

    只由 ui/pies/light.py 置位; 隐藏项不进 F9 面板, 与 LightAdd 的 is_shift/is_ctrl/is_alt
    同一约定(入口靠隐藏布尔属性传给算子, 供 execute/invoke 分流).
    """

    use_viewport_target: BoolProperty(
        name="Viewport Target",
        default=False,
        options={'HIDDEN'},
        description="Resolve the target from the viewport active light (set by the light pie menu)",
    )  # type: ignore


def _linked_guard(op: Operator, light: Object) -> bool:
    """execute 直调路径的库链接复查(规范 10.2): poll 拦得住 GUI, 直调绕过 poll

    返回 True 表示已报告并应取消.
    """
    if light.library is not None:
        op.report({'WARNING'}, report("Linked lights cannot be edited"))
        return True
    return False


def _first_selected_non_light(context: Context, exclude: Object | None = None) -> Object | None:
    """选中集里按名字序的第一个非灯光物体; 可排除指定物体(如被操作的灯光自身)

    "控制器落点"的统一口径(作者 2026-10-30 定): 默认点击与 +Shift 同义都取这个目标,
    只认选中集里的非灯光物体——活动物体若是灯光, 落到它上面毫无意义.
    """
    return next((obj for obj in sorted(context.selected_objects, key=lambda obj: obj.name) if obj is not exclude and obj.type != 'LIGHT'), None)


def _resolve_rig_position(context: Context, light: Object, is_ctrl: bool, is_alt: bool, op: Operator) -> Vector | None:
    """解析控制器摆放位置; 无法确定时报警告并返回 None

    默认与 +Shift 同义 = 选中集里第一个**非灯光**物体(按名字序; 没有则提示取消, 作者
    2026-10-30 定——活动物体是灯光时它不会是合法落点, 故不以活动物体为准, +Shift 因此
    不再需要独立分支, 其 RNA 属性仅为兼容既有调用而保留); +Ctrl = 游标; +Alt = 世界原点.
    """
    if is_alt:
        return Vector((0.0, 0.0, 0.0))
    if is_ctrl:
        return context.scene.cursor.location.copy()
    target = _first_selected_non_light(context, light)
    if target is None:
        op.report({'WARNING'}, report("Select a target object to place the controller at"))
        return None
    return target.matrix_world.translation.copy()


def _resolve_adjust_rig(context: Context, use_viewport_target: bool = False) -> tuple[Object, Object] | None:
    """模态算子的 rig 解析: 饼菜单入口先取视口活动灯, 其余按选区优先 + 面板活跃灯光回退

    灯光方位折叠区按"面板活跃行"显示/编辑属性, 模态若只认选区会出现"属性可编辑
    而唤起按钮置灰"的口径分裂(审查 P2); 回退路径让按钮与属性行同口径.
    视口活动灯没有控制器时不在此改判(仍回退选区/面板), 避免"按钮可用却静默取消"
    ——活动灯无控制器时选区里可能另有可调 rig(作者 2026-10-30 定).
    """
    if use_viewport_target:
        light = _viewport_light(context)
        if light is not None:
            controller = rig_controller_of(light)
            if controller is not None:
                return (light, controller)
    rig = resolve_rig(context)
    if rig is not None:
        return rig
    light = _panel_light(context)
    if light is not None:
        controller = rig_controller_of(light)
        if controller is not None:
            return (light, controller)
    return None


class LightAdd(TranslatedDescriptionMixin, Operator):
    """添加灯光: 默认弹原生灯光选择面板, +Shift/+Ctrl/+Alt 直接创建带控制器的面光源"""

    bl_idname = "ch.light_add"
    bl_label = "Add Light"
    bl_description = (
        "Add a light with the native picker (cursor placement and the redo panel are kept)\n"
        "+Shift: Add an area light with a controller empty placed at the first selected non-light object\n"
        "+Ctrl: Add an area light with a controller empty placed at the 3D cursor\n"
        "+Alt: Add an area light with a controller empty placed at the world origin"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_shift: BoolProperty(name="Shift", default=False, options={'HIDDEN'}, description="Place the controller at the first selected non-light object (set by +Shift)")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def invoke(self, context: Context, event: Event):
        self.is_shift = bool(event is not None and event.shift)
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        if self.is_shift or self.is_ctrl or self.is_alt:
            return self.execute(context)
        # 无修饰键: 原样转发原生(INVOKE_DEFAULT 保住弹窗与 F9 调整面板, ImageOpen 同款壳)
        return bpy.ops.object.light_add('INVOKE_DEFAULT')

    def execute(self, context: Context):
        if not (self.is_shift or self.is_ctrl or self.is_alt):
            # 直调无修饰键: 与原生直调同口径在游标处建普通灯(不进弹窗);
            # 非物体模式直调时原生 poll 失败会抛 RuntimeError, 先行拦截(审查 P3)
            if context.mode != 'OBJECT':
                return {'CANCELLED'}
            return bpy.ops.object.light_add('EXEC_DEFAULT')
        if self.is_shift:
            # 与"设置控制器"的默认落点同口径(作者 2026-10-30 定): 选中集里第一个非灯光物体
            target = _first_selected_non_light(context)
            if target is None:
                self.report({'WARNING'}, report("Select a target object to place the controller at"))
                return {'CANCELLED'}
            position = target.matrix_world.translation.copy()
        elif self.is_ctrl:
            position = context.scene.cursor.location.copy()
        else:
            position = Vector((0.0, 0.0, 0.0))
        light, _controller = create_light_rig(context, position)
        # 新建项高亮(与 CreateAlignCamera 同口径): 先同步快照再按名定位
        refresh_lists()
        highlight_item(context, "lights", light.name)
        return {'FINISHED'}


class LightCopy(ViewportTargetMixin, TranslatedDescriptionMixin, Operator):
    """复制灯光: 把活动灯光连同控制器整套复制, 灯光数据为独立副本"""

    bl_idname = "ch.light_copy"
    bl_label = "Copy Light"
    bl_description = "Duplicate the active light with its controller empty (the light data-block is copied)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(light.library is None and rig_controller_of(light) is not None for light in _candidate_lights(context))

    def execute(self, context: Context):
        light = _target_light(context, self.use_viewport_target)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        pair = copy_light_rig(context, light, shared_data=False)
        if pair is None:
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        new_light = pair[0]
        refresh_lists()
        highlight_item(context, "lights", new_light.name)
        self.report({'INFO'}, report("Light rig copied: {}").format(new_light.name))
        return {'FINISHED'}


class LightInstanceCopy(ViewportTargetMixin, TranslatedDescriptionMixin, Operator):
    """实例复制: 复制活动灯光的 rig 层级但共享灯光数据块(改功率/颜色全联动)"""

    bl_idname = "ch.light_instance_copy"
    bl_label = "Instance Copy"
    bl_description = "Duplicate the active light with its controller empty while sharing the light data-block (power and color edits affect every instance)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(light.library is None and rig_controller_of(light) is not None for light in _candidate_lights(context))

    def execute(self, context: Context):
        light = _target_light(context, self.use_viewport_target)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        pair = copy_light_rig(context, light, shared_data=True)
        if pair is None:
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        new_light = pair[0]
        refresh_lists()
        highlight_item(context, "lights", new_light.name)
        self.report({'INFO'}, report("Light instance created: {}").format(new_light.name))
        return {'FINISHED'}


class LightControllerSet(ViewportTargetMixin, TranslatedDescriptionMixin, Operator):
    """设置控制器: 无控制器的活动灯光绑定控制器; 已有控制器则挪到新位置重设"""

    bl_idname = "ch.light_controller_set"
    bl_label = "Set Controller"
    bl_description = (
        "Attach a controller empty to the active light without one, or move the existing controller to a new position and re-aim the light at it (the light keeps its world position; the self rotation resets to 0; the controller goes to the first selected non-light object)\n"
        "+Shift: Same as the default location\n"
        "+Ctrl: Place the controller at the 3D cursor\n"
        "+Alt: Place the controller at the world origin"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_shift: BoolProperty(name="Shift", default=False, options={'HIDDEN'}, description="Place the controller at the first selected non-light object (set by +Shift)")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        # 无控制器(添加路径)或有本地控制器(重设路径)都可用; 链接灯光/链接控制器不可编辑
        for light in _candidate_lights(context):
            if light.library is not None:
                continue
            controller = rig_controller_of(light)
            if controller is None or controller.library is None:
                return True
        return False

    def invoke(self, context: Context, event: Event):
        # is_shift 与默认落点同义, 不再读入(属性保留仅为兼容脚本/快捷键传参)
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        return self.execute(context)

    def execute(self, context: Context):
        light = _target_light(context, self.use_viewport_target)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        position = _resolve_rig_position(context, light, self.is_ctrl, self.is_alt, self)
        if position is None:
            return {'CANCELLED'}
        if rig_controller_of(light) is None:
            # 添加路径: 绑定控制器并转身瞄准, 控制器入选中集给即时视觉反馈
            controller = add_controller(context, light, position)
            context.view_layer.update()
            if is_selectable(context, controller):
                controller.select_set(True)
            refresh_lists()
            highlight_item(context, "lights", light.name)
            self.report({'INFO'}, report("Controller added: {}").format(controller.name))
            return {'FINISHED'}
        # 重设路径: 控制器挪到新位置并重新瞄准(灯光保位, 自旋转归零)
        result = reset_controller(context, light, position)
        if result == "none":
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        if result == "linked":
            self.report({'WARNING'}, report("Linked controller empties cannot be edited"))
            return {'CANCELLED'}
        refresh_lists()
        highlight_item(context, "lights", light.name)
        self.report({'INFO'}, report("Controller reset: {}").format(result))
        return {'FINISHED'}


class LightControllerRemove(ViewportTargetMixin, TranslatedDescriptionMixin, Operator):
    """移除控制器: 摘除活动灯光的控制器父级(灯光保世界变换)并删除空物体"""

    bl_idname = "ch.light_controller_remove"
    bl_label = "Remove Controller"
    bl_description = "Remove the controller empty from the active light (the light keeps its world transform)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return any(light.library is None and rig_controller_of(light) is not None for light in _candidate_lights(context))

    def execute(self, context: Context):
        light = _target_light(context, self.use_viewport_target)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        result = remove_controller(light)
        if result == "none":
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        refresh_lists()
        highlight_item(context, "lights", light.name)
        if result == "removed":
            self.report({'INFO'}, report("Controller removed"))
        elif result == "linked":
            self.report({'INFO'}, report("Linked controller kept, only the parent binding was removed"))
        else:
            self.report({'INFO'}, report("Controller has other children, kept as a regular empty"))
        return {'FINISHED'}


class LightRigParamsReset(ViewportTargetMixin, TranslatedDescriptionMixin, Operator):
    """重置参数: 活动灯光 rig 的方位角/高度角/距离/自旋转恢复默认值(直接写变换)"""

    bl_idname = "ch.light_rig_params_reset"
    bl_label = "Reset Parameters"
    bl_description = "Reset the rig parameters of the active light to their defaults (azimuth 0, elevation 45 degrees, distance back to the rig's initial distance recorded at creation, self rotation 0; rigs without the recorded initial distance fall back to the 5 m default)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        # 方位/高度角要写控制器变换: 链接灯光与链接控制器都不可重置(与四钮口径一致)
        for light in _candidate_lights(context):
            if light.library is not None:
                continue
            controller = rig_controller_of(light)
            if controller is not None and controller.library is None:
                return True
        return False

    def execute(self, context: Context):
        light = _target_light(context, self.use_viewport_target)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        controller = rig_controller_of(light)
        if controller is None:
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        if controller.library is not None:
            self.report({'WARNING'}, report("Linked controller empties cannot be edited"))
            return {'CANCELLED'}
        # 四参数默认值: 方位角 0 / 高度角 RIG_DEFAULT_ELEVATION / 距离 = 创建时记录的
        # 初始距离(旧 rig 回退面板默认) / 自旋转 0(顺带整体归位瞄准姿态)
        set_controller_azimuth(controller, 0.0)
        set_controller_elevation(controller, RIG_DEFAULT_ELEVATION)
        set_light_distance(light, rig_init_distance(light))
        reset_light_self_rotation(light)
        self.report({'INFO'}, report("Light rig parameters reset"))
        return {'FINISHED'}


class LightControllersRemoveAll(TranslatedDescriptionMixin, Operator):
    """移除所有控制器: 把当前灯光列表内全部灯光的控制器批量摘除(灯保位并解锁旋转)"""

    bl_idname = "ch.light_controllers_remove_all"
    bl_label = "Remove All Controllers"
    bl_description = "Remove the controller empty from every light in the current lights list (each light keeps its world position and its rotation is unlocked; linked or shared controller empties are kept, only the parent bindings are removed)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        scene = context.scene
        view_layer = context.view_layer
        # 与四钮同口径: 库链接灯不计入(链接控制器不可解绑)
        return any(light.library is None and rig_controller_of(light) is not None for light in collect_light_blocks(scene, view_layer))

    def execute(self, context: Context):
        lights = collect_light_blocks(context.scene, context.view_layer)
        removed = 0
        unbound = 0
        for light in lights:
            if light.library is not None:
                # 链接灯跳过(会话内解绑库资产重载即复原, 与四钮置灰口径一致)
                continue
            result = remove_controller(light)
            if result == "removed":
                removed += 1
            elif result in {"linked", "shared"}:
                # 链接/共挂的控制器只解绑不删(与单个移除同口径), 计入"仅解绑"
                unbound += 1
        if not removed and not unbound:
            self.report({'INFO'}, report("No lights with controllers"))
            return {'CANCELLED'}
        refresh_lists()
        self.report({'INFO'}, report("Controllers removed: {}, bindings only removed: {}").format(removed, unbound))
        return {'FINISHED'}


class LightRigAdjust(ModalOperatorMixin, ViewportTargetMixin, TranslatedDescriptionMixin, Operator):
    """灯光控制模态: A 档调方位/高度, S/D 按住调亮度与距离, Ctrl/Alt 吸附对齐控制器"""

    bl_idname = "ch.light_rig_adjust"
    bl_label = "Light Control"
    bl_description = (
        "Adjust the light rig interactively\n"
        "+A/S/D: A is the base mode — mouse X/Y for azimuth / elevation; hold S (mouse X for brightness) or D (mouse X for distance), releasing the key returns to A\n"
        "+Shift: Precise adjustment (half the rate)\n"
        "+Ctrl: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the surface normal (leaves the adjustment mode; press A/S/D to resume)\n"
        "+Alt: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the reflection line of the current view's virtual camera (the scene camera in a camera view; the clicked point becomes the highlight position)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and _resolve_adjust_rig(context) is not None

    def execute(self, context: Context):
        # 模态算子直调守卫(规范 10.2): report WARNING + CANCELLED, 不复入 invoke
        self.report({'WARNING'}, report("This operator runs interactively in the 3D view"))
        return {'CANCELLED'}

    def invoke(self, context: Context, event: Event):
        rig = _resolve_adjust_rig(context, self.use_viewport_target)
        if rig is None:
            return {'CANCELLED'}
        self.rig_light: Object = rig[0]
        self.rig_controller: Object = rig[1]
        if context.region_data is None:
            # 后台无视图: 交互不成立, 走直调守卫口径
            return self.execute(context)
        # --- 模态状态 ---
        # 取消还原快照: 控制器/灯光的 basis 与功率(父级逆不受模态影响, basis 还原即世界还原)
        self.init_controller_mx: Matrix = self.rig_controller.matrix_basis.copy()
        self.init_light_mx: Matrix = self.rig_light.matrix_basis.copy()
        self.init_energy: float = self.rig_light.data.energy
        # 调节模式: A 为常驻基础档, S/D 为按住式(见 _HOLD_KEYS), 进入默认 A 档
        self.axis: str = 'A'
        self.held_axes: set = set()
        self.pass_through = False
        self.init_mouse_position(event)
        self.init_status(context, func=_draw_rig_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context)
        self.init_view_draw(self._draw_preview)
        force_ui_update(context)
        # 模态调值只写变换, 不改任何列表成员: 挂起 handlers 的全量列表同步(否则每次
        # 调值的 depsgraph 更新都会触发 0.1s 一次的六列表全量重建, 是模态卡顿主因);
        # 置位放在 RUNNING_MODAL 前一行, 消掉 invoke 尾部异常的泄漏窗口(审查 P1)
        set_sync_suppressed(True)
        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        try:
            return self._modal_dispatch(context, event)
        except Exception:
            # 模态期异常(如灯/控制器被外部删除): Blender 直接摘除模态算子且不再走
            # _finish——必须在此复位同步抑制与状态栏, 否则全量同步静默停摆(审查 P1);
            # 收敛动作逐一兜住, 收敛自身失败不掩盖原异常
            set_sync_suppressed(False)
            try:
                self.finish_status()
                self.finish_modal_handlers()
                self.finish_view_draw()
                force_statusbar_redraw(context)
            except Exception:
                pass
            return {'CANCELLED'}

    def _modal_dispatch(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 先数据级还原(不依赖 area, 与 ESC 取消同语义——否则已做
            # 的调整漏进下一次无关操作的 undo 步), 再最小收敛退出
            self._restore()
            set_sync_suppressed(False)
            self._abort_without_area(context)
            force_statusbar_redraw(context)
            return {'CANCELLED'}
        if event.type == 'WINDOW_DEACTIVATE':
            # 窗口失活时按键松开事件会送到别处: 按住集必须清空, 否则 S/D 档卡在按住态
            # (回到窗口后鼠标一动就继续改功率/距离, 直到重按 A/S/D; L1 审查 P2)
            self.held_axes.clear()
            if self.axis in _HOLD_KEYS:
                self.axis = 'A'
            return {'RUNNING_MODAL'}
        if ignore_events(event):
            return {'RUNNING_MODAL'}
        context.area.tag_redraw()
        return self._handle_modal_events(context, event)

    def _handle_modal_events(self, context: Context, event: Event):
        if event.type == 'MOUSEMOVE':
            return self._handle_mouse_move(context, event)
        if navigation_passthrough(event, alt=True):
            # 视图导航(MMB 旋转等): 事件交给导航系统, 下一帧 MOUSEMOVE 重置基线
            self.pass_through = True
            return {'PASS_THROUGH'}
        if event.value == 'PRESS' or (event.value == 'RELEASE' and event.type in _HOLD_KEYS):
            # 松开事件只对按住式调节键有意义(A 为基础档, 松开不改变档位)
            return self._handle_key_press(context, event)
        return {'RUNNING_MODAL'}

    def _handle_mouse_move(self, context: Context, event: Event):
        if self.pass_through:
            # 视图导航结束: 重置基线, 本帧不做任何调整
            self.pass_through = False
            self.init_mouse_position(event)
            return {'RUNNING_MODAL'}
        if event.ctrl or event.alt:
            # 吸附档: 进入即退出调节模式(置 None)——松开 Ctrl/Alt 后鼠标移动不再调值,
            # 须重新按 A/S/D 才恢复(作者 2026-10-29 定)
            self.axis = None
            self._handle_controller_move(context, event)
        elif self.axis is not None:
            # 调值态光标到区域边缘跳到对侧(作者要求): 包裹帧跳过调值, 基线已在包裹内重置
            if self.wrap_mouse_position(context, event):
                return {'RUNNING_MODAL'}
            self._handle_light_axis(context, event)
        self.init_mouse_position(event)
        self.update_header_text(context)
        return {'RUNNING_MODAL'}

    def _reflection_view_point(self, context: Context) -> Vector:
        """反射模式的观察点: 相机视图用场景相机, 其余用 3D 视图的虚拟相机视点

        (作者 2026-10-29 修正口径——反射线 = 虚拟相机指向表面点的矢量经表面反射;
        逐帧现算, 模态中导航后仍跟随当前视角).
        """
        rv3d = context.region_data
        if rv3d.view_perspective == 'CAMERA' and context.scene.camera is not None:
            return context.scene.camera.matrix_world.translation
        return rv3d.view_matrix.inverted().translation.copy()

    def _handle_controller_move(self, context: Context, event: Event) -> None:
        """控制器调整: 射线吸附表面; +Ctrl 法线对齐 / +Alt 反射对齐(同按 Alt 优先)

        对齐轴为控制器局部 +Y(rig 几何约定灯在局部 +Y 轴上, 作者 2026-10-29 修正).
        """
        result = raycast_surface(context, (event.mouse_region_x, event.mouse_region_y))
        if result is None:
            return
        hit, normal = result
        _loc, rot, scale = self.rig_controller.matrix_basis.decompose()
        self.rig_controller.matrix_basis = Matrix.Translation(hit) @ rot.to_matrix().to_4x4() @ Matrix.Diagonal(scale.to_4d())
        if event.alt:
            align_controller_y(self.rig_controller, reflection_direction(self._reflection_view_point(context), hit, normal))
        elif event.ctrl:
            align_controller_y(self.rig_controller, normal)

    def _handle_light_axis(self, context: Context, event: Event) -> None:
        """按当前模式把鼠标增量写进 rig(区域归一幅度与 Shift 精确比率读偏好设置)"""
        prefs = get_prefs()
        delta_x = event.mouse_x - self.last_mouse_x
        delta_y = event.mouse_y - self.last_mouse_y
        factor = prefs.light_rig_shift_factor if event.shift else 1.0
        step_x = delta_x * factor / max(context.region.width, 1)
        step_y = delta_y * factor / max(context.region.height, 1)
        light = self.rig_light
        controller = self.rig_controller
        if self.axis == 'A':
            set_controller_azimuth(controller, get_controller_azimuth(controller) + step_x * prefs.light_rig_angle_sweep)
            set_controller_elevation(controller, get_controller_elevation(controller) + step_y * prefs.light_rig_angle_sweep)
        elif self.axis == 'D':
            set_light_distance(light, get_light_distance(light) + step_x * prefs.light_rig_distance_span)
        else:
            # 功率按绝对幅度增减(归一化), 0 起步自然可用; 链接灯的数据块不改写
            # (与四钮"库链接灯光不可编辑"口径一致, 变换类调节不受影响)
            if light.library is None:
                light.data.energy = max(0.0, light.data.energy + step_x * prefs.light_rig_power_span)

    def _handle_key_press(self, context: Context, event: Event):
        if event.type in _AXIS_KEYS:
            return self._handle_axis_key(event)
        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            self._finish(context)
            return {'FINISHED'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._restore()
            self._finish(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _handle_axis_key(self, event: Event):
        """A/S/D 的按下与松开: A 为常驻基础档, S/D 为按住式, 松开回落到 A

        吸附档(axis 为 None)不在此恢复——松开 Ctrl/Alt 后仍须重按 A/S/D 才继续调值
        (作者 2026-10-29 定), 故松开事件只在档位仍有效时回落.
        """
        if event.value == 'RELEASE':
            self.held_axes.discard(event.type)
            if self.axis is not None:
                self.axis = self._held_axis()
            return {'RUNNING_MODAL'}
        if event.type == 'A':
            # 按 A 即回基础档: 清空按住集, 避免仍按着的 S/D 把档位顶回去
            self.held_axes.clear()
        else:
            self.held_axes.add(event.type)
        self.axis = self._held_axis()
        return {'RUNNING_MODAL'}

    def _held_axis(self) -> str:
        """按住中的键决定档位(D 优先于 S), 都没按住则基础档 A"""
        if 'D' in self.held_axes:
            return 'D'
        if 'S' in self.held_axes:
            return 'S'
        return 'A'

    def update_header_text(self, context: Context) -> None:
        """header 只显数值(规范 5.3): 四属性实时值, 角度带 °, 距离/亮度按场景单位走 Blender 单位串"""
        unit_system = context.scene.unit_settings.system
        distance_text = bpy.utils.units.to_string(unit_system, 'LENGTH', get_light_distance(self.rig_light), precision=2).strip()
        brightness_text = bpy.utils.units.to_string(unit_system, 'POWER', self.rig_light.data.energy, precision=1)
        text = iface("Azimuth: {}  Elevation: {}  Distance: {}  Brightness: {}").format(
            "{:.1f}°".format(degrees(get_controller_azimuth(self.rig_controller))),
            "{:.1f}°".format(degrees(get_controller_elevation(self.rig_controller))),
            distance_text,
            brightness_text,
        )
        context.area.header_text_set(text)

    def _draw_preview(self) -> None:
        """A/D 档轨迹预览: 方位圆环 + 高度大圆 + 半径连线 + 刻度圆点

        轨迹线颜色按"到灯光的距离"做饱和度与明度衰减(灯处等于偏好色, 最远处两者减半);
        偏好每帧现读(开关/颜色/线宽/刻度/遮挡改完即时生效). 只读变换不改数据, 不触发
        depsgraph 变更, 也不进撤销栈; 灯或控制器被外部删除时读取即抛 ReferenceError,
        由绘制层吞掉并停用, 不影响模态本身.
        """
        if self.axis not in _PREVIEW_AXES:
            return
        prefs = get_prefs()
        if not prefs.light_rig_show_preview:
            return
        trajectory = rig_trajectory(self.rig_light)
        if trajectory is None:
            return
        ring, meridian, position = trajectory
        center = self.rig_controller.matrix_world.translation
        azimuth_color = tuple(prefs.light_rig_preview_azimuth_color)
        elevation_color = tuple(prefs.light_rig_preview_elevation_color)
        width = prefs.light_rig_preview_line_width
        xray = prefs.light_rig_preview_xray
        draw_polyline(ring, gradient_by_distance(ring, position, azimuth_color, _FAR_SCALE), width=width, alpha=_PREVIEW_LINE_ALPHA, xray=xray, closed=True)
        draw_polyline(meridian, gradient_by_distance(meridian, position, elevation_color, _FAR_SCALE), width=width, alpha=_PREVIEW_LINE_ALPHA, xray=xray, closed=True)
        # 半径连线: 控制器 -> 灯, 表达当前距离与方位(环本身穿过灯位, 连线只作提示)
        draw_polyline((center, position), (azimuth_color, azimuth_color), width=width, alpha=_PREVIEW_SPOKE_ALPHA, xray=xray)
        if not prefs.light_rig_preview_show_ticks:
            return
        # 刻度间隔属性是 ANGLE 子类型(内部弧度), 几何层按度取角, 故在此换算
        ring_ticks, meridian_ticks = rig_trajectory_ticks(self.rig_light, degrees(prefs.light_rig_preview_tick_angle))
        # 圆点直径是像素量, 需视图投影换算世界半径; 取不到投影时绘制层自行跳过
        region, region_data = _preview_projection(self)
        for ticks, track_color in ((ring_ticks, azimuth_color), (meridian_ticks, elevation_color)):
            points = []
            sizes = []
            colors = []
            for point, axis in ticks:
                axis_color = _AXIS_TICK_COLORS.get(axis) if axis else None
                points.append(point)
                sizes.append(width * (_AXIS_TICK_DIAMETER_SCALE if axis_color else _TICK_DIAMETER_SCALE))
                colors.append(axis_color if axis_color else track_color)
            draw_discs(points, sizes, colors, alpha=_TICK_ALPHA, xray=xray, region=region, region_data=region_data)

    def _restore(self) -> None:
        """取消路径: 控制器变换 / 灯光局部变换 / 功率整体还原到 invoke 快照"""
        self.rig_controller.matrix_basis = self.init_controller_mx
        self.rig_light.matrix_basis = self.init_light_mx
        self.rig_light.data.energy = self.init_energy

    def _finish(self, context: Context) -> None:
        """收尾(生命周期调用序): 状态栏 -> 模态处理器 -> header 清除 -> UI 刷新"""
        set_sync_suppressed(False)
        self.finish_status()
        self.finish_modal_handlers()
        self.finish_view_draw()
        context.area.header_text_set(None)
        # 状态栏区域显式重绘: 恢复 statusbar.draw 后不 tag 会残留旧自绘内容
        force_statusbar_redraw(context)
        force_ui_update(context)
