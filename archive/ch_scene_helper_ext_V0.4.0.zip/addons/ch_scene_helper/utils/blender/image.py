"""
图像工具模块

场景助手图像列表的纯算法: 重命名、批量重载、节点引用替换、重复图像合并与使用者查询.
交互与报告由 operators/utils/image_ops.py 承担, 本模块不碰上下文与 report.

主要功能:
- rename_image_from_file: 把图像名改成所引用文件名
- reload_external_images: 重载全部引用外部文件的图像
- replace_image_reference: 把材质图像节点里对某图的引用换成另一张
- unlink_image_references: 把材质图像节点里对某图的引用置空(用户归 0, 保留数据块)
- merge_duplicate_images: 把 name.001/name.002 这类重复图在节点里并回无编号的原图
- find_image_users: 场景中通过材质图像节点引用该图像的物体
- first_image_of_material: 材质节点树里第一个图像纹理节点的图像
- focus_image_editors: 把所有图像编辑器区域切换到指定图像(列表行点击联动)

注: 合并只改节点引用, 不清除重复数据块(清理由用户的 Purge 流程决定).
"""

import os
from collections.abc import Iterator

import bpy
from bpy.types import Context, Image


def _iter_tex_image_nodes(materials) -> Iterator:
    """遍历一批材质的全部图像纹理节点(只含节点树的材质; use_nodes 已弃用恒真)"""
    for mat in materials:
        if mat.node_tree is None:
            continue
        for node in mat.node_tree.nodes:
            if node.type == 'TEX_IMAGE':
                yield node


def _material_uses_image(mat, img: Image) -> bool:
    """材质节点树里是否有图像纹理节点引用该图像"""
    return any(node.image is img for node in _iter_tex_image_nodes([mat]))


def rename_image_from_file(img: Image, keep_extension: bool = True) -> tuple:
    """把图像名改成其引用文件名(去掉目录), 返回 (是否成功, 错误信息)

    keep_extension 为假时去掉扩展名; 渲染结果图固定保留 "Render Result" 不改.
    """
    if img is None:
        return False, "image not found"
    # 按类型守卫: source 枚举(FILE/SEQUENCE/MOVIE/GENERATED/VIEWER/TILED)从无 RENDER_RESULT
    if img.type == 'RENDER_RESULT':
        return False, "render result cannot be renamed"
    name = bpy.path.basename(img.filepath_raw or img.filepath)
    if not name:
        return False, "image has no file path"
    if not keep_extension:
        name = os.path.splitext(name)[0]
    try:
        img.name = name
    except (RuntimeError, ValueError) as e:
        return False, str(e)
    return True, None


def reload_external_images() -> tuple:
    """重载全部引用外部文件的图像, 返回 (重载数量, 错误信息)"""
    count = 0
    for img in bpy.data.images:
        if not img.filepath:
            continue
        try:
            img.reload()
        except RuntimeError:
            continue
        count += 1
    return count, None


def replace_image_reference(old: Image, new: Image, all_materials: bool = True) -> tuple:
    """把图像节点里对 old 的引用换成 new, 返回 (替换数量, 错误信息)

    all_materials 为真时扫描全部材质, 否则只扫描活动物体的活动材质.
    """
    if old is None or new is None:
        return 0, "image not found"
    materials = bpy.data.materials if all_materials else _active_materials()
    count = 0
    for node in _iter_tex_image_nodes(materials):
        if node.image is old:
            node.image = new
            count += 1
    return count, None


def unlink_image_references(img: Image) -> tuple:
    """把全部材质图像节点里对该图像的引用置空, 返回 (清空节点数, 错误信息)

    与 replace_image_reference 同口径扫全部材质; 只摘材质节点引用(相机背景图/
    世界/合成器等其它引用不碰, 作者 2026-10-27 定): 用户归 0 的图像由 Blender
    按零用户规则处理(无伪用户则在保存时被清理).
    """
    if img is None:
        return 0, "image not found"
    count = 0
    for node in _iter_tex_image_nodes(bpy.data.materials):
        if node.image is img:
            node.image = None
            count += 1
    return count, None


def _active_materials() -> list:
    """活动物体的活动材质列表(无活动物体时为空)"""
    obj = bpy.context.view_layer.objects.active
    if obj is None or obj.active_material is None:
        return []
    return [obj.active_material]


def first_image_of_material(mat):
    """取材质节点树里第一个图像纹理节点的图像; 无则返回 None"""
    for node in _iter_tex_image_nodes([mat] if mat is not None else []):
        if node.image is not None:
            return node.image
    return None


def find_image_users(scene, img: Image) -> list:
    """场景中通过材质图像节点引用该图像的物体列表(按场景物体顺序, 天然去重)"""
    if img is None:
        return []
    materials = {mat for mat in bpy.data.materials if _material_uses_image(mat, img)}
    if not materials:
        return []
    return [obj for obj in scene.objects if any(slot.material in materials for slot in obj.material_slots)]


def focus_image_editors(context: Context, image: Image) -> int:
    """把所有窗口的图像编辑器区域切换到指定图像, 返回聚焦区域数

    列表行点击时调用; 没有图像编辑器区域时返回 0, 不抛异常.
    """
    focused = 0
    for window in context.window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = image
                focused += 1
    return focused


def merge_duplicate_images(partition: str = ".") -> tuple:
    """把 name.001/name.002 这类重复图的节点引用并回无编号原图, 返回 (替换数量, 错误信息)

    判据: 名称按 partition 右分割, 尾段全数字且其前缀存在同名图像时视为重复.
    partition 为空是非法输入(空分隔符会让 rpartition 抛 ValueError), 直接返回错误.
    """
    if not partition:
        return 0, "empty separator"
    count = 0
    for node in _iter_tex_image_nodes(bpy.data.materials):
        if node.image is None:
            continue
        base, _sep, tail = node.image.name.rpartition(partition)
        if not base or not tail.isnumeric():
            continue
        original = bpy.data.images.get(base)
        if original is None or original is node.image:
            continue
        node.image = original
        count += 1
    return count, None
