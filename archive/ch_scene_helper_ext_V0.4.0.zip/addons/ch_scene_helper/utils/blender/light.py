"""
灯光工具模块

提供灯光能量批量缩放、灯光/灯光集合的隔离态判定与世界屏蔽算法
(交互层算子见 operators/object/light.py 与 operators/utils/{row,datablock}_ops.py).
"""

import bpy
from bpy.types import Scene, World

from .scene_data import LIGHT_COLLECTION_PREFIX


def scale_lights_energy(objects: list, factor: float) -> int:
    """把一组灯光物体的能量乘以系数(结果钳制为非负), 返回实际缩放的灯光数

    Args:
        objects: 待处理物体列表(非灯光物体自动跳过)
        factor: 能量乘数(0 清空, 1 不变)

    Returns:
        实际被缩放的灯光物体数
    """
    count = 0
    for obj in objects:
        if obj is None or obj.type != 'LIGHT':
            continue
        obj.data.energy = max(obj.data.energy * factor, 0.0)
        count += 1
    return count


def world_output_muted(world: World) -> bool:
    """世界输出节点的接入端连线是否已全部屏蔽(存在连线且全部 is_muted)

    没有世界/没有节点树/根本没有连线时返回 False: 无法用屏蔽位表示"世界已屏蔽",
    此时隔离不进入世界屏蔽分支(见 apply_light_isolate_world_mute).
    """
    if world is None or world.node_tree is None:
        return False
    found = False
    for node in world.node_tree.nodes:
        if node.type != 'OUTPUT_WORLD':
            continue
        for socket in node.inputs:
            for link in socket.links:
                found = True
                if not link.is_muted:
                    return False
    return found


def lights_viewport_isolated(scene: Scene) -> bool:
    """灯光是否处于视口隔离态

    多灯: 恰好一盏可见且其余 hide_viewport; 只有一个灯光时没有可隐藏的同类物体,
    隔离态只能由世界屏蔽位体现(单灯隔离 = 屏蔽世界, 见 world_output_muted).
    """
    lights = [obj for obj in scene.objects if obj.type == 'LIGHT']
    visible = [obj for obj in lights if not obj.hide_viewport]
    if len(lights) > 1:
        return len(visible) == 1
    return len(lights) == 1 and world_output_muted(scene.world)


def light_collections_isolated(scene: Scene) -> bool:
    """灯光集合是否处于隔离态(多集合: 恰好一个可见; 只有一个集合时看世界屏蔽位)"""
    collections = [coll for coll in bpy.data.collections if coll.name.startswith(LIGHT_COLLECTION_PREFIX)]
    visible = [coll for coll in collections if not coll.hide_viewport]
    if len(collections) > 1:
        return len(visible) == 1
    return len(collections) == 1 and world_output_muted(scene.world)


def lights_isolated_by_hiding(scene: Scene) -> bool:
    """多灯隐藏型隔离态: 恰好一盏可见且其余 hide_viewport(不含单灯的屏蔽位口径)

    世界屏蔽位是灯光/灯光集合两个隔离特性共用的单槽, 单灯/单集合的隔离态就存在位里,
    读位分不清归属(可能是对方隔离挂的, 也可能是自己上次隔离留下的). 隔离算子的聚合
    归位(把对方隔离态并入屏蔽判定)因此只信 hide 位, 见 row_ops.ObjectViewportToggle 与
    datablock_ops.CollectionViewportToggle; 开关判定仍用全口径(见 lights_viewport_isolated).
    """
    lights = [obj for obj in scene.objects if obj.type == 'LIGHT']
    visible = [obj for obj in lights if not obj.hide_viewport]
    return len(lights) > 1 and len(visible) == 1


def light_collections_isolated_by_hiding() -> bool:
    """多集合隐藏型隔离态: CLS_ 集合多于一个且恰好一个可见(单集合的屏蔽位口径不算)"""
    collections = [coll for coll in bpy.data.collections if coll.name.startswith(LIGHT_COLLECTION_PREFIX)]
    visible = [coll for coll in collections if not coll.hide_viewport]
    return len(collections) > 1 and len(visible) == 1


def set_world_output_muted(world: World, mute: bool) -> int:
    """把世界输出节点全部接入端连线的屏蔽位统一置为 mute, 返回本次改动的连线数

    隔离灯光时屏蔽世界环境光用: link.is_muted 即视口里 Ctrl 点击连线头的静音语义.
    静音/恢复后显式 update_tag: 程序化改连线屏蔽位不触发着色器重估, 视口会停留在旧画面.
    """
    if world is None or world.node_tree is None:
        return 0
    count = 0
    for node in world.node_tree.nodes:
        if node.type != 'OUTPUT_WORLD':
            continue
        for socket in node.inputs:
            for link in socket.links:
                if link.is_muted != mute:
                    link.is_muted = mute
                    count += 1
    if count:
        world.node_tree.update_tag()
    return count


def apply_light_isolate_world_mute(scene: Scene, isolate_active: bool, mute_enabled: bool) -> int:
    """按灯光隔离态与"屏蔽世界"开关把世界屏蔽位归位, 返回改动连线数

    - 隔离生效且开关开 -> 屏蔽全部接入端连线
    - 其余情况(取消隔离/开关关) -> 全部恢复: 按作者口径"取消隔离后恢复",
      不区分屏蔽来源(用户手动静音的连线也会被恢复)
    """
    return set_world_output_muted(scene.world, isolate_active and mute_enabled)
