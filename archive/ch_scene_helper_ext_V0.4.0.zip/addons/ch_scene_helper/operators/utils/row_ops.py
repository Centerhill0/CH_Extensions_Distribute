"""
列表行内动作算子模块

提供以下功能:
- ObjectSelect: 选中物体(Shift 加选 / Alt 减选), 行内选择按钮
- CameraSetView: 选中相机并切到相机视角
- ObjectViewportToggle / ObjectRenderToggle: 行内"在视图中禁用/在渲染中禁用"开关
  (+Ctrl 隔离同类, 再点恢复)
- FakeUserToggle: 伪用户开关(行内按钮, 图标随状态刷新)

算法与状态访问分别在 utils 与 scene_state, 本模块只做上下文交互与报告.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report
from ...handlers import tag_3d_views
from ...scene_state import blocks_for, get_state, highlight_item, resolve_id
from ...utils import apply_light_isolate_world_mute, light_collections_isolated_by_hiding, select_object, select_only, sync_active_camera_resolution, world_output_muted
from ._base import TranslatedDescriptionMixin


class ObjectSelect(TranslatedDescriptionMixin, Operator):
    """选中行内物体并高亮该列表项(+Shift 切换选中/减选)"""

    bl_idname = "ch.object_select"
    bl_label = "Select Object"
    bl_description = "Select this object and highlight its list item\n+Shift: Toggle selection"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore
    list_kind: EnumProperty(name="List", items=(("cameras", "Cameras", ""), ("lights", "Lights", "")), default="cameras")  # type: ignore

    def execute(self, context: Context):
        return self._select(context, toggle=False)

    def invoke(self, context: Context, event: Event):
        return self._select(context, toggle=bool(event.shift))

    def _select(self, context: Context, toggle: bool):
        """独占选中/切换选中(invoke/execute 共用; execute 直调按独占处理)

        高亮跟随活动项: 减选非活动项时高亮留在活动项行; 减选活动项时活动与高亮
        一起跳回列表序中前一个仍选中的项(没有则清空活动物体, 高亮留在原行).
        全部取消选中是合法状态(+Shift 逐个减选即可清空, 作者 2026-10-24 定).
        """
        obj = bpy.data.objects.get(self.obj_name)
        if obj is None:
            return {'CANCELLED'}
        if not toggle:
            select_object(context, obj)
            highlight_item(context, self.list_kind, obj.name, 'OBJECT')
        elif obj.select_get():
            select_object(context, obj, deselect=True)
            self._jump_back(context, obj)
        else:
            select_object(context, obj, extend=True)
            highlight_item(context, self.list_kind, obj.name, 'OBJECT')
        return {'FINISHED'}

    def _jump_back(self, context: Context, obj) -> None:
        """减选的是活动项: 活动物体与列表高亮跳回列表序中最近的仍选中项

        优先取前一个, 前方没有则取后方最近的(否则减选列表首个选中项时无目标,
        高亮会留在已减选行); 没有任何剩余选中项则清空活动物体, 高亮留在原行.
        """
        if context.view_layer.objects.active is not obj:
            act = context.view_layer.objects.active
            if act is not None:
                highlight_item(context, self.list_kind, act.name, 'OBJECT')
            return
        prev = None
        after = None
        passed = False
        for block in blocks_for(context, self.list_kind):
            if block is None:
                continue
            if block is obj:
                passed = True
                continue
            if not block.select_get():
                continue
            if not passed:
                prev = block
            elif after is None:
                after = block
        target = prev if prev is not None else after
        if target is not None:
            context.view_layer.objects.active = target
            highlight_item(context, self.list_kind, target.name, 'OBJECT')
        else:
            context.view_layer.objects.active = None


class CameraSetView(Operator):
    """选中相机并切换到该相机视角"""

    bl_idname = "ch.camera_set_view"
    bl_label = "Set View"
    bl_description = "Select this camera and look through it"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty(name="Name")  # type: ignore

    def execute(self, context: Context):
        obj = bpy.data.objects.get(self.obj_name)
        if obj is None or obj.type != 'CAMERA':
            self.report({'WARNING'}, report("Camera not found"))
            return {'CANCELLED'}
        select_only(context, [obj])
        context.scene.camera = obj
        # 独立分辨率即时跟随(改场景相机的其它路径由 handlers 兜底, 此处求即时)
        sync_active_camera_resolution(context.scene)
        space = getattr(context, "space_data", None)
        if space is not None and getattr(space, "type", "") == 'VIEW_3D' and bpy.ops.view3d.object_as_camera.poll():
            bpy.ops.view3d.object_as_camera()
        return {'FINISHED'}


class _ObjectDisableMixin:
    """行内禁用开关的共享实现(普通混入类, 不参与注册); attr 由子类指定

    视口/渲染拆成两个算子类是必须的: 同一行画两个同 bl_idname 的按钮, 重绘时按钮
    按名字匹配复用旧属性, 后画按钮设的标志会串到先画按钮上(2026-10-27 作者实测).
    """

    attr = "hide_viewport"
    # 普通缺省值: 直调(EXEC_DEFAULT)绕过 invoke 时 isolate 可读(子类 RNA 声明在注册时接管)
    isolate = False

    def invoke(self, context: Context, event: Event):
        self.isolate = bool(event is not None and event.ctrl)
        return self.execute(context)

    def execute(self, context: Context):
        scene = context.scene
        obj = scene.objects.get(self.obj_name)
        if obj is None:
            return {'CANCELLED'}
        attr = self.attr
        if not self.isolate:
            setattr(obj, attr, not getattr(obj, attr))
            return {'FINISHED'}
        # +Ctrl 隔离: 目标态 = 其余同类里还有可见项 -> 隐藏它们; 已全部隐藏 -> 恢复
        others = [other for other in scene.objects if other is not obj and other.type == obj.type]
        isolate_active = any(not getattr(other, attr) for other in others)
        for other in others:
            setattr(other, attr, isolate_active)
        setattr(obj, attr, False)
        if obj.type == 'LIGHT':
            if not others:
                # 场景只有这一盏灯: 没有同类可隐藏, 视口/渲染两档隔离都落到世界上(按世界
                # 屏蔽位记住隔离态, 再点一次即恢复), 见 utils.blender.light.world_output_muted
                isolate_active = not world_output_muted(scene.world)
            # 开关状态见 props.lights_mute_world(与灯光集合隔离共用), 恢复口径见
            # utils.apply_light_isolate_world_mute; 聚合归位同时尊重集合侧仍生效的隔离
            # (只信 hide 位口径, 归属说明见 utils.lights_isolated_by_hiding)
            apply_light_isolate_world_mute(scene, isolate_active or light_collections_isolated_by_hiding(), get_state(context).lights_mute_world)
            # 静音连线不触发着色器重估与视口重绘, 显式刷新
            tag_3d_views()
        return {'FINISHED'}


class ObjectViewportToggle(_ObjectDisableMixin, TranslatedDescriptionMixin, Operator):
    """行内"在视图中禁用"开关, +Ctrl 隔离同类(隐藏其余同类, 再点恢复)"""

    bl_idname = "ch.object_disable_viewport"
    bl_label = "Disable in Viewport"
    bl_description = "Toggle viewport visibility for this object\n+Ctrl: Show only this object among the objects of the same type (isolate), click again to restore"
    bl_options = {'REGISTER', 'UNDO'}

    attr = "hide_viewport"
    obj_name: StringProperty(name="Name")  # type: ignore
    isolate: BoolProperty(options={'HIDDEN'}, default=False, description="Isolate among the same-type objects instead of toggling (set by +Ctrl)")  # type: ignore


class ObjectRenderToggle(_ObjectDisableMixin, TranslatedDescriptionMixin, Operator):
    """行内"在渲染中禁用"开关, +Ctrl 隔离同类(排除其余同类渲染, 再点恢复)"""

    bl_idname = "ch.object_disable_render"
    bl_label = "Disable in Render"
    bl_description = "Toggle render exclusion for this object\n+Ctrl: Render only this object among the objects of the same type (isolate), click again to restore"
    bl_options = {'REGISTER', 'UNDO'}

    attr = "hide_render"
    obj_name: StringProperty(name="Name")  # type: ignore
    isolate: BoolProperty(options={'HIDDEN'}, default=False, description="Isolate among the same-type objects instead of toggling (set by +Ctrl)")  # type: ignore


class FakeUserToggle(Operator):
    """切换数据块的伪用户标记(列表行内按钮)"""

    bl_idname = "ch.fake_user_toggle"
    bl_label = "Fake User"
    bl_description = "Keep this data-block saved even when it has no users"
    bl_options = {'REGISTER', 'UNDO'}

    id_name: StringProperty(name="Name")  # type: ignore
    id_kind: StringProperty(name="Kind")  # type: ignore

    def execute(self, context: Context):
        datablock = resolve_id(self.id_kind, self.id_name)
        if datablock is None:
            return {'CANCELLED'}
        datablock.use_fake_user = not datablock.use_fake_user
        return {'FINISHED'}
