"""
灯光辅助操作器模块

提供以下功能:
- LightEnergyScale: 对选中灯光的能量批量乘以系数(布光收尾的整体曝光调整)
- LightOrganize: 灯光整理, 把灯光集合之外的灯光物体移入最新创建的灯光集合
"""

from bpy.props import FloatProperty
from bpy.types import Context, Operator

from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import highlight_item
from ...utils import collect_stray_lights, create_light_collection, move_objects_to_collection, newest_light_collection, scale_lights_energy


class LightEnergyScale(Operator):
    """把全部选中灯光的能量乘以系数(F9 面板可调因子, UNDO 可撤销)"""

    bl_idname = "ch.light_energy_scale"
    bl_label = "Energy Scale"
    bl_description = "Scale the energy of all selected lights by a factor"
    bl_options = {'REGISTER', 'UNDO'}

    factor: FloatProperty(name="Factor", description="Multiplier applied to the energy of each selected light", default=1.0, min=0.0, soft_max=10.0)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and any(obj.type == 'LIGHT' for obj in context.selected_objects)

    def execute(self, context: Context):
        lights = [obj for obj in context.selected_objects if obj.type == 'LIGHT']
        count = scale_lights_energy(lights, self.factor)
        if count == 0:
            self.report({'WARNING'}, report("No lights selected"))
            return {'CANCELLED'}
        self.report({'INFO'}, report("Energy scaled: {} lights").format(count))
        return {'FINISHED'}


class LightOrganize(Operator):
    """灯光整理: 把灯光集合之外的灯光物体(不含被排除集合内的)移入最新创建的灯光集合"""

    bl_idname = "ch.light_organize"
    bl_label = "Organize Lights"
    bl_description = "Move every light outside the light collections into the newest light collection (one is created first when there is no light collection)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        scene = context.scene
        # 先判"有活可干"能避免为了空整理凭空建集合(无集合时新建的 CLS_01_ 本身不含灯光, 顺序无影响)
        lights = collect_stray_lights(scene, context.view_layer)
        if not lights:
            self.report({'INFO'}, report("No lights outside the light collections"))
            return {'CANCELLED'}
        target = newest_light_collection(scene)
        if target is None:
            target = create_light_collection(scene)
        count = move_objects_to_collection(lights, target)
        refresh_lists()
        highlight_item(context, "light_collections", target.name)
        self.report({'INFO'}, report("Moved {} lights into {}").format(count, target.name))
        return {'FINISHED'}
