"""
五个资源面板的选项菜单

公共项顺序: 选区同步(世界环境无) -> 按名称重排序(SORTALPHA) -> 显示0用户(材质/图像);
整理动作(相机整理/灯光整理)紧跟公共项, 其后再是各面板的状态开关与列显示开关.
菜单里的 layout.separator() 本身就画横线(非饼菜单下 Auto 即 SeprLine), 不必写 type='LINE'.

菜单只读/写 WM 级面板状态与算子属性, 不触碰偏好.
"""

from bpy.types import Context, Menu, UILayout

from ...operators.object.camera import CameraOrganize
from ...operators.object.light import LightOrganize
from ...operators.utils.image_ops import ImageMerge, ImageReloadAll, ImageRename, ImageReplace, ImageSaveAll
from ...operators.utils.list_ops import ListSort
from ...operators.utils.material_ops import PassIndexBatch
from ...scene_state import LIST_SPECS, get_state


def draw_common_options(layout: UILayout, state, kind: str) -> None:
    """选项菜单公共项: 选区同步 -> 按名称重排序 -> 显示0用户"""
    spec = LIST_SPECS[kind]
    if spec.supports_sync:
        layout.prop(state, "sync_selection")
    layout.operator(ListSort.bl_idname, icon='SORTALPHA').list_kind = kind
    if spec.zero_user_prop:
        layout.prop(state, spec.zero_user_prop)


class CameraOptions(Menu):
    """相机面板选项: 公共项 + 相机整理 + 行内列显示"""

    bl_idname = "CH_MT_scene_camera_options"
    bl_label = "Camera Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "cameras")
        layout.operator(CameraOrganize.bl_idname, icon='IMPORT')
        layout.separator()
        layout.prop(state, "cameras_show_lens")
        layout.prop(state, "cameras_show_type")
        layout.separator()
        layout.prop(state, "cameras_show_names")


class LightOptions(Menu):
    """灯光面板选项: 公共项 + 屏蔽世界 + 行内列显示"""

    bl_idname = "CH_MT_scene_light_options"
    bl_label = "Light Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "lights")
        layout.prop(state, "lights_mute_world")
        layout.separator()
        layout.prop(state, "lights_show_color")
        layout.prop(state, "lights_show_shadow")


class CollectionOptions(Menu):
    """灯光集合列表选项: 公共项 + 灯光整理 + 屏蔽世界"""

    bl_idname = "CH_MT_scene_collection_options"
    bl_label = "Collection Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "light_collections")
        layout.operator(LightOrganize.bl_idname, icon='IMPORT')
        # 屏蔽世界与灯光列表共用同一个开关(props.lights_mute_world), 两处各显示一次
        layout.prop(state, "lights_mute_world")


class MaterialOptions(Menu):
    """材质面板选项: 跟随/0 用户/重排序 + 列显示 + 批量通道索引"""

    bl_idname = "CH_MT_scene_material_options"
    bl_label = "Material Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "materials")
        layout.separator()
        layout.prop(state, "materials_show_pass_index")
        layout.prop(state, "materials_show_node_count")
        layout.separator()
        layout.operator(PassIndexBatch.bl_idname, icon='LINENUMBERS_ON')


class ImageOptions(Menu):
    """图像面板选项: 跟随/0 用户/重排序 + 列显示 + 批量维护"""

    bl_idname = "CH_MT_scene_image_options"
    bl_label = "Image Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "images")
        layout.separator()
        layout.operator(ImageReloadAll.bl_idname, icon='FILE_REFRESH')
        # 原生全局语义: 以所选目录重映射全场景缺失的外部文件(区别于行内单图重定位)
        layout.operator("file.find_missing_files", icon='FILE_FOLDER')
        layout.operator(ImageSaveAll.bl_idname, icon='FILE_TICK')
        layout.operator(ImageRename.bl_idname, icon='FILE_TEXT')
        layout.operator(ImageMerge.bl_idname, icon='FULLSCREEN_EXIT')
        layout.operator(ImageReplace.bl_idname, icon='FILE_REFRESH')


class WorldOptions(Menu):
    """世界环境面板选项: 重排序 + 颜色列(世界始终显示全部)"""

    bl_idname = "CH_MT_scene_world_options"
    bl_label = "World Options"

    def draw(self, context: Context):
        state = get_state(context)
        layout = self.layout
        draw_common_options(layout, state, "worlds")
        layout.separator()
        layout.prop(state, "worlds_show_color")
