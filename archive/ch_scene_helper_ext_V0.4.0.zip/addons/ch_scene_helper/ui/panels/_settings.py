"""
资源设置绘制模块

灯光/相机/材质设置区与 PBR 设置子面板的共享绘制实现.
抽出的目的是让折叠头/参数区/PBR 三项只有一份实现.

主要功能:
- setup_param_box: 参数子面板 box 的统一排版(property split + 去装饰)
- draw_details_section: 可折叠详情子面板的统一骨架(折叠头 + box + 内容回调)
- draw_bsdf_slots / draw_slot_placeholder_row: 材质基础参数区
- draw_light_settings / draw_camera_settings: 活动灯光/相机设置
- draw_material_pbr: 材质面板的 PBR 设置子面板(坐标输出 + 投影统一控制)
"""

from bpy.types import Context, UILayout

from .....common.i18n.i18n import iface
from ...scene_state import panel_material
from ...utils import (
    detect_pbr_texture_graph,
    get_pbr_texcoord_pair,
    get_surface_bsdf,
    get_texcoord_output,
    resolve_bsdf_slots,
    suppress_texcoord_updates,
)
from ...utils._constants import NO_SLIDER_SOCKETS, TEXCOORD_OPTIONS

# 已接线占位行的上游节点名截断上限(每帧布局, 长名会拖慢侧栏)
_UPSTREAM_NAME_MAX = 24

# 坐标输出下拉的合法标识集合(绘制期判真值是否落在候选项内)
_TEXCOORD_IDS = frozenset(option[0] for option in TEXCOORD_OPTIONS)


def truncate_node_name(name: str) -> str:
    """截断过长的上游节点名(首 _UPSTREAM_NAME_MAX 字符 + ...)"""
    return name if len(name) <= _UPSTREAM_NAME_MAX else name[:_UPSTREAM_NAME_MAX] + "..."


def setup_param_box(box: UILayout) -> None:
    """参数子面板 box 的统一排版口径

    - use_property_split: 属性名进左列、控件进右列, 与原生属性面板同观感
    - use_property_decorate = False: 去掉行尾的动画/覆盖等装饰点
    """
    box.use_property_split = True
    box.use_property_decorate = False


def draw_subpanel_header(layout: UILayout, state, prop_name: str, title: str) -> bool:
    """无框折叠头(三角箭头 + 标题文本), 返回是否展开

    口径: prop(text="", emboss=False) 只画三角, 标题用 label 紧跟其后;
    展开态存面板状态组(SceneHelperState).
    """
    opened = getattr(state, prop_name)
    header = layout.row()
    header.prop(state, prop_name, text="", emboss=False, icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
    header.label(text=iface(title))
    return opened


def draw_details_section(layout: UILayout, state, prop_name: str, title: str, draw_body) -> None:
    """可折叠详情子面板: 未展开直接返回; 展开时画 box 并交给 draw_body"""
    if not draw_subpanel_header(layout, state, prop_name, title):
        return
    draw_body(layout.box())


def draw_texcoord_row(col: UILayout, ui_state, tex_coord, mapping) -> None:
    """PBR 设置第一行: 坐标输出下拉(Generated/UV/Object)

    真值在连接关系里(TexCoord 的哪个输出口接到 Mapping.Vector): 绘制前把真值写进镜像枚举,
    再画下拉; 用户改动经 props.on_pbr_texcoord_update 重建接线. draw 期写镜像必须抑制
    update 回调(否则每帧重画都会触发一次接线重建).
    真值不在三项候选内(如 Camera/Window/Reflection)时画置灰只读行.
    """
    current = get_texcoord_output(tex_coord, mapping)
    if current not in _TEXCOORD_IDS:
        row = col.row()
        row.enabled = False
        row.alignment = 'RIGHT'
        row.label(text=iface("Texture Coordinate"), icon='NODE_SOCKET_COLLECTION')
        row.label(text=current)
        return
    with suppress_texcoord_updates():
        ui_state.pbr_texcoord = current
    col.prop(ui_state, "pbr_texcoord")


def draw_texture_projection(col: UILayout, ui_state, textures: list) -> None:
    """PBR 设置第二行: 所有 PBR 图像纹理的投影统一控制

    - 绘制前读真值: 全部图一致 -> 写回镜像; 不一致 -> 保持镜像原值不动
    - 用户改动 -> 统一写全部命中纹理(非 Box 时 Blend 归零)
    - Box 时追加 Blend 行(镜像 FloatProperty, 同样统一写全部图)
    """
    values = {tex.projection for tex in textures}
    if len(values) == 1:
        with suppress_texcoord_updates():
            ui_state.pbr_projection = values.pop()
    col.prop(ui_state, "pbr_projection")
    if ui_state.pbr_projection == 'BOX':
        with suppress_texcoord_updates():
            ui_state.pbr_projection_blend = textures[0].projection_blend
        col.prop(ui_state, "pbr_projection_blend")


def draw_material_pbr(layout: UILayout, context: Context, ui_state) -> None:
    """材质面板的 PBR 设置子面板(材质设置之下, 同构折叠头)

    可见性: 取不到 Surface 直连的白名单节点、或 PBR 五步检测不过时整块不出现.
    """
    mat = panel_material(context)
    if mat is None or get_surface_bsdf(mat) is None:
        return
    pbr = detect_pbr_texture_graph(mat)
    if not pbr["ok"]:
        return

    def draw_body(box: UILayout) -> None:
        setup_param_box(box)
        pair = get_pbr_texcoord_pair(mat)
        col = box.column()
        if pair is not None:
            draw_texcoord_row(col, ui_state, *pair)
        draw_texture_projection(col, ui_state, list(pbr["tex_by_channel"].values()))

    draw_details_section(layout, ui_state, "show_pbr_details", "PBR Settings", draw_body)


def draw_slot_placeholder_row(col: UILayout, socket) -> None:
    """已接线插槽的占位行: 图标 + 属性名靠右 + 置灰

    已接线的插槽写 default_value 会被渲染忽略, 画可编辑控件会让用户"拖了没反应".
    """
    row = col.row()
    row.enabled = False
    row.alignment = 'RIGHT'
    row.label(text=socket.name, icon='NODE_SOCKET_COLLECTION')
    upstream = socket.links[0].from_node.name if socket.links else ""
    row.label(text=truncate_node_name(upstream))


def draw_bsdf_slots(box: UILayout, node) -> None:
    """材质基础参数区: 按固定语义序一行一个属性

    - 未接线: prop 正常控件; 颜色带 slider; 金属度/粗糙度带 slider;
      Emission Strength 与 IOR 不用滑条(RNA hard 范围过大, 一拖数值就飞)
    - 已接线: 占位行
    """
    setup_param_box(box)
    col = box.column()
    for _semantic, socket, is_linked in resolve_bsdf_slots(node):
        if is_linked:
            draw_slot_placeholder_row(col, socket)
            continue
        use_slider = socket.type == 'RGBA' or (socket.type == 'VALUE' and socket.name not in NO_SLIDER_SOCKETS)
        col.prop(socket, "default_value", text=socket.name, slider=use_slider)


def draw_light_settings(box: UILayout, obj, context: Context) -> None:
    """灯光设置(传灯光物体, 因为 Cycles 的 lightgroup/spread 挂在物体与数据块两处)

    结构顺序固定: Temperature -> Color -> Power -> 类型属性 -> 阴影/引擎项.
    """
    light = obj.data
    setup_param_box(box)
    col = box.column()
    row = col.row(align=True, heading="Temperature")
    row.prop(light, "use_temperature", text="")
    sub = row.row()
    sub.active = light.use_temperature
    sub.prop(light, "temperature", text="")

    col.prop(light, "color", text="Color" if not light.use_temperature else "Tint")
    col.prop(light, "energy")
    col.prop(light, "exposure")

    if light.type in {'POINT', 'SPOT'}:
        row = col.row(align=True)
        row.prop(light, "shadow_soft_size", text="Radius")
        if light.type == 'SPOT':
            row.prop(light, "spot_size", text="Spot Size")
            row.prop(light, "spot_blend")
    elif light.type == 'SUN':
        col.prop(light, "angle")
    elif light.type == 'AREA':
        row = col.row(align=True)
        row.prop(light, "shape")
        if light.shape in {'SQUARE', 'DISK'}:
            row.prop(light, "size")
        elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
            row.prop(light, "size", text="Size X")
            row.prop(light, "size_y")

    if context.scene.render.engine == 'BLENDER_EEVEE':
        col.prop(light, "use_shadow", text="Cast Shadow")
    elif context.scene.render.engine == 'CYCLES':
        if light.type == 'AREA':
            col.prop(light, "spread")
        col.prop(obj, "lightgroup", text="Light Group")


def draw_camera_settings(box: UILayout, obj, context: Context) -> None:
    """相机设置: Independent Resolution -> Lens -> Clip -> Sensor -> Safe Areas -> Background Images -> DOF

    传物体而非相机数据: 独立分辨率属性组挂在物体上(随 .blend 保存).
    """
    cam = obj.data
    setup_param_box(box)
    # 独立分辨率: 每相机独立的输出分辨率, 该相机为场景相机时覆写场景输出(镜头行上方);
    # 开关用 prop 绘制以参与 use_property_split 两列布局(operator 按钮会占满整行),
    # 开启时的初始化与即时同步走属性 update 回调(props.on_camera_resolution_update)
    col = box.column()
    settings = obj.ch_resolution
    col.prop(settings, "use_independent")
    if settings.use_independent:
        col.prop(settings, "res_x", text="X")
        col.prop(settings, "res_y", text="Y")

    row = col.row(align=True)
    row.prop(cam, "lens_unit")
    if cam.lens_unit == 'MILLIMETERS':
        row.prop(cam, "lens")
    else:
        row.prop(cam, "angle")

    row = col.row(align=True)
    row.prop(cam, "clip_start", text="Clip")
    row.prop(cam, "clip_end", text="")

    col = col.column()
    col.prop(cam, "sensor_width", text="Sensor")
    col.prop(cam, "show_safe_areas", text="Safe Areas")
    col.prop(cam, "show_background_images", text="Background Images")

    col.prop(cam.dof, "use_dof", text="DOF")
    if cam.dof.use_dof:
        col.row().prop(cam.dof, "focus_object")
        row = col.row()
        row.active = cam.dof.focus_object is None
        row.prop(cam.dof, "focus_distance")
        # 取景器算子的路径以 context.scene.camera 为落点: 面板活动相机不是场景相机时
        # 画出来会改到另一台相机的焦点距离, 故只在两者一致时提供.
        scene_camera = context.scene.camera
        if scene_camera is not None and scene_camera.data == cam:
            op = row.operator("ui.eyedropper_depth", icon='EYEDROPPER', text="")
            op.prop_data_path = 'scene.camera.data.dof.focus_distance'
        col.row().prop(cam.dof, "aperture_fstop")
