"""
偏好设置模块

面板为左右两列, 按服务划分: 左列文本服务(接入配置 + 文本生成参数含编辑器联动),
右列图像服务(接入配置 + 图像生成参数含图像编辑器联动)

提供以下功能:
- AI 服务接入配置: 服务商预设(DeepSeek/智谱/自定义), API 地址, 密钥, 模型, 温度, 超时
- 文本生成参数: 脚本注释语言, 对话上下文条数, 脚本输出上限, 对话修改备份份数, 场景上下文开关
- 图像服务接入配置: 服务商预设(火山方舟/阿里百炼/自定义), API 地址, 密钥, 文生图/图生图模型, 超时, 产物存盘目录
- 图像输入输出限制: 参考图张数与最长边(默认即官方上限, 可自定义), 输出图像限制提醒
- 文本编辑器联动: 自动在文本编辑器打开脚本产物/对话消息的开关(面板内亦有快捷开关)
- 图像编辑器联动: 自动在图像编辑器打开列表图像的开关(面板内亦有快捷开关)
"""

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Context, PropertyGroup

from ...common.i18n.i18n import iface
from .config import __addon_name__
from .items import (
    CUSTOM_MODEL_ITEM,
    PROVIDER_MODEL_ITEMS,
    TEXT_PROVIDER_MODEL_ITEMS,
    comment_language_items,
)
from .utils.image_client import output_limits, ref_image_limits
from .utils.provider_registry import (
    IMAGE_PROVIDERS,
    TEXT_PROVIDERS,
    get_image_provider,
    get_text_provider,
    image_provider_items,
    provider_items,
)

# 服务商预设: 条目标识 -> (base_url, 默认模型); CUSTOM 不回填, 由用户手动填写
# 自服务商注册表派生(单一来源, 避免与 ai_client 的端点/默认模型两处漂移)
_PRESETS = {key: (p.base_url, p.default_model) for key, p in TEXT_PROVIDERS.items()}

# 图像服务商预设: 条目标识 -> (base_url, 文生图默认模型, 图生图默认模型); CUSTOM 不回填
# 文生图与图生图用同一模型, 两栏同填; 具体取值见服务商注册表(现为各服务商的轻量档)
_IMAGE_PRESETS = {key: (p.base_url, p.default_model_t2i, p.default_model_edit) for key, p in IMAGE_PROVIDERS.items() if p.base_url}  # CUSTOM 无端点不回填

# 连通性测试算子的 bl_idname 常量: 偏好 draw 与算子类共用(偏好→算子会循环导入, 以常量单向引用)
TEST_TEXT_OP = "ch_ai.test_text_service"
TEST_IMAGE_OP = "ch_ai.test_image_service"


def _image_model_items_fn(self, context):
    """图像模型下拉条目按图像服务商动态切换(纹理 t2i 与编辑两档共用), 末尾追加自定义档"""
    return PROVIDER_MODEL_ITEMS.get(self.image_provider, []) + [CUSTOM_MODEL_ITEM]


def _text_model_choice_items_fn(self, context):
    """文本模型偏好下拉条目按文本服务商动态切换(CUSTOM 无候选, 只出自定义档), 末尾追加自定义档"""
    return TEXT_PROVIDER_MODEL_ITEMS.get(self.provider, []) + [CUSTOM_MODEL_ITEM]


def _apply_preset(self, _context):
    """切换服务商预设时回填 API 地址与模型, 并对齐模型选择器(预设模型名须在条目内)"""
    preset = _PRESETS.get(self.provider)
    if preset is not None:
        self.base_url, self.model = preset
        self.model_choice = self.model


def _apply_model_choice(self, _context):
    """下拉选择模型: 回填实际模型名(自定义档保留手输名不动, 供输入框编辑)"""
    if self.model_choice != 'CUSTOM':
        self.model = self.model_choice


def _apply_image_preset(self, _context):
    """切换图像服务商预设时回填 API 地址与文生图/图生图模型, 并对齐两个模型选择器
    (预设模型名须在下拉条目内, 否则 RNA 赋值报错); 参考图限制一并清零"""
    preset = _IMAGE_PRESETS.get(self.image_provider)
    if preset is not None:
        self.image_base_url, self.image_model_t2i, self.image_model_edit = preset
        self.image_t2i_choice = self.image_model_t2i
        self.image_edit_choice = self.image_model_edit
    # 参考图限制清零 = 回到"跟随该服务商的官方上限"(0 的语义, 见 image_client.ref_image_limits):
    # 甲服务商上自定义过的数字不能顺手安到乙头上(可能比乙的官方上限还松), 故切服务商即清
    self.image_ref_count, self.image_ref_edge = 0, 0


def _apply_t2i_choice(self, _context):
    """下拉选择纹理模型: 回填实际模型名(自定义档保留手输名不动)"""
    if self.image_t2i_choice != 'CUSTOM':
        self.image_model_t2i = self.image_t2i_choice


def _apply_edit_choice(self, _context):
    """下拉选择编辑模型: 回填实际模型名(自定义档保留手输名不动)"""
    if self.image_edit_choice != 'CUSTOM':
        self.image_model_edit = self.image_edit_choice


def _draw_service_test(layout, op_idname: str, result: str, ok: bool):
    """绘制服务连通性测试行: 左对齐的测试按钮 + 结果提示(结果为空时不画)

    result/ok 取自 ch_service_test 状态属性(文本与图像各有一对)
    """
    # property_split 下 operator 会拉伸满行, 左对齐行让其收缩为内容宽度
    btn_row = layout.row()
    btn_row.alignment = 'LEFT'
    btn_row.operator(op_idname, text="Test", icon='PLAY')
    if result:
        res_row = btn_row.row(align=True)
        res_row.enabled = False
        res_row.label(text=result, icon='CHECKMARK' if ok else 'ERROR')


class AiPassPreset(PropertyGroup):
    """效果图通道组合预设: 名称 + 捕获/发送两组通道开关的快照(存于偏好, 跨会话跨机)"""

    use_combined: BoolProperty(default=True)  # type: ignore
    use_depth: BoolProperty(default=True)  # type: ignore
    use_normal: BoolProperty()  # type: ignore
    use_segmentation: BoolProperty()  # type: ignore
    use_edge: BoolProperty()  # type: ignore
    use_diffuse: BoolProperty()  # type: ignore
    use_ao: BoolProperty()  # type: ignore
    use_send_combined: BoolProperty(default=True)  # type: ignore
    use_send_depth: BoolProperty(default=True)  # type: ignore
    use_send_normal: BoolProperty()  # type: ignore
    use_send_segmentation: BoolProperty()  # type: ignore
    use_send_edge: BoolProperty()  # type: ignore
    use_send_diffuse: BoolProperty()  # type: ignore
    use_send_ao: BoolProperty()  # type: ignore


# 预设下拉条目(动态枚举): 遍历偏好存储的预设; 空表给占位档(不给 default, 首项即默认)
def _pass_preset_items(self, _context):
    """通道组合预设下拉条目: 预设名为标识与标签(用户可在保存时命名), 空表给占位档"""
    if not self.pass_presets:
        return [('NONE', "No presets", "Save the current pass toggles as a preset first")]
    return [(p.name, p.name, "Apply this pass preset") for p in self.pass_presets]


class AiAssistantPreferences(AddonPreferences):
    """AI 助手偏好设置(左列文本服务, 右列图像服务)"""

    # 必须与 __addon_name__ 一致, Blender 据此定位偏好面板
    bl_idname = __addon_name__

    # ---- 效果图通道组合预设(存于偏好, 跨会话): 捕获/发送两组勾选的命名快照 ----
    pass_presets: CollectionProperty(type=AiPassPreset)  # type: ignore
    pass_preset_choice: EnumProperty(
        name="Pass Preset",
        description="Saved pass toggle combinations, apply one to both capture and send toggles",
        items=_pass_preset_items,
    )  # type: ignore

    provider: EnumProperty(name="Provider", items=provider_items, default='DEEPSEEK', update=_apply_preset)  # type: ignore
    # OpenAI 兼容接口基地址, 请求时拼接 /chat/completions
    base_url: StringProperty(
        name="API Base URL",
        description="OpenAI-compatible API endpoint, e.g. https://api.deepseek.com",
        default="https://api.deepseek.com",
    )  # type: ignore
    api_key: StringProperty(
        name="API Key",
        description="Secret key for the custom text service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    deepseek_api_key: StringProperty(
        name="DeepSeek API Key",
        description="Secret key of the DeepSeek service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    glm_api_key: StringProperty(
        name="GLM API Key",
        description="Secret key of the Zhipu GLM service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    # 模型选择器: 预设服务商下为下拉(动态候选, 末档"自定义"选中后下方输入框可手输名),
    # CUSTOM 服务商下隐藏下拉改用输入框(见 draw)
    model_choice: EnumProperty(
        name="Model",
        description="Select the chat model",
        items=_text_model_choice_items_fn,
        update=_apply_model_choice,
    )  # type: ignore
    model: StringProperty(
        name="ID",
        description="Chat model name, e.g. deepseek-flash",
        default="deepseek-flash",
    )  # type: ignore
    temperature: FloatProperty(
        # 用 "Sampling Temperature" 而非常见词 "Temperature": 避开 Blender 自带翻译对常见词的遮蔽
        name="Sampling Temperature",
        description="Sampling randomness: 0 is the most deterministic, higher is more creative. 0-0.3 recommended for scripts",
        default=0.0,
        min=0.0,
        max=2.0,
        precision=1,
    )  # type: ignore
    comment_language: EnumProperty(
        name="Comment Language",
        description="Language of the comments written in generated and modified scripts",
        items=comment_language_items,
        default='CHINESE',
    )  # type: ignore
    # 脚本类请求输出上限(含思考链): 0 = 按服务商自动策略(DeepSeek 省略用服务端默认, GLM 65536, 其余 8192)
    script_max_tokens: IntProperty(
        name="Script Output Limit",
        description="Upper limit of output tokens (not characters) for script requests, thinking output included. 0 uses the per-provider automatic strategy: omitted for DeepSeek (server default), 65536 for GLM and 8192 for the other providers. Setting a larger value is safe because billing follows actual usage; too small a value may cut the answer off",
        default=0,
        min=0,
        max=131072,
    )  # type: ignore
    # 对话上下文条数: 随每次发送携带的最近历史消息数(0 表示只发当前消息)
    chat_history_limit: IntProperty(
        name="Chat History Limit",
        description="Number of recent chat messages sent to the AI as conversation context, 0 sends only the current message",
        default=20,
        min=0,
        max=200,
    )  # type: ignore
    # 对话修改每脚本保留的 "_bak" 备份份数: 超出时移除最旧备份(与图像侧 Edit Backups per Image 同语义)
    revise_backup_limit: IntProperty(
        name="Revise Backups per Script",
        description="How many '_bak' backups Revise Script keeps per script, older backups are removed when exceeded",
        default=1,
        min=1,
        max=10,
    )  # type: ignore
    # 文本请求单次超时秒数: 对话与脚本类请求统一由本项控制, 无隐性加成, 请求失败不自动重试
    timeout: IntProperty(
        name="Timeout (s)",
        description="Request timeout in seconds for all text requests, chat and script generation alike",
        default=300,
        min=5,
        max=600,
    )  # type: ignore
    use_context: BoolProperty(
        name="Include Scene Context",
        description="Send Blender version and scene/selection info with the script requests: " "generate, debug and revise (chat and prompt optimization are not affected)",
        default=True,
    )  # type: ignore
    # 编辑器联动开关(侧栏面板内亦有快捷开关): 是否自动把产物/所选条目送入文本编辑器
    use_auto_open_scripts: BoolProperty(
        name="Auto Open Scripts",
        description="Show generated, debugged and revised scripts, and the script clicked in the list, in the text editor automatically",
        default=True,
    )  # type: ignore
    use_auto_open_chat: BoolProperty(
        name="Auto Open Chat",
        description="Show the chat message clicked in the list and new replies in the text editor automatically",
        default=True,
    )  # type: ignore
    # 图像编辑器联动开关(纹理/效果图两面板内亦有快捷开关): 是否自动把列表点击的图像送入图像编辑器
    use_auto_open_images: BoolProperty(
        name="Auto Open Images",
        description="Show the texture or render clicked in the list in the image editor automatically",
        default=True,
    )  # type: ignore

    # ---- 图像服务偏好(右列; 与文本服务分开配置密钥, 互不影响) ----
    image_provider: EnumProperty(
        name="Provider",
        description="Provider of the AI image service",
        items=image_provider_items,
        default='VOLCENGINE',
        update=_apply_image_preset,
    )  # type: ignore
    image_base_url: StringProperty(
        name="API Base URL",
        description="Base URL of the image API, e.g. https://ark.cn-beijing.volces.com/api/v3",
        default="https://ark.cn-beijing.volces.com/api/v3",
    )  # type: ignore
    image_api_key: StringProperty(
        name="API Key",
        description="Secret key for the custom image service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    volcengine_api_key: StringProperty(
        name="Volcengine API Key",
        description="Secret key of the Volcengine Ark image service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    dashscope_api_key: StringProperty(
        name="DashScope API Key",
        description="Secret key of the Alibaba DashScope image service, stored locally in Blender preferences",
        subtype='PASSWORD',
    )  # type: ignore
    # 纹理模型: 预设服务商下为模型下拉(标识即模型名), Custom 服务商下为输入框(见 draw)
    # default=0 而非字符串标识: 动态枚举(items 为回调)的 default 只能是**整数下标**
    # (写字符串标识会在 register 期抛 TypeError: 'default' can only be an integer when 'items'
    # is a function, 整个偏好类注册失败).下标 0 在两套候选表里都是**轻量档**
    # (方舟 Seedream 5.0 Flash / 百炼 Qwen-Image 3.0), 与 image_model_t2i 出厂默认同源:
    # 出厂走便宜档, 需旗舰档时在偏好下拉或面板覆盖里显式选择
    image_t2i_choice: EnumProperty(
        name="Texture & Image Generation Model",
        description="Select the model used for texture and image generation",
        items=_image_model_items_fn,
        default=0,
        update=_apply_t2i_choice,
    )  # type: ignore
    image_model_t2i: StringProperty(
        name="ID",
        description="Image model name used for text-to-image texture generation",
        default="doubao-seedream-5-0-flash-260915",
    )  # type: ignore
    # 编辑模型: 预设服务商下为模型下拉, Custom 服务商下为输入框(见 draw); default 口径同纹理下拉
    image_edit_choice: EnumProperty(
        name="Render Generation Model",
        description="Select the model used for render generation and image editing",
        items=_image_model_items_fn,
        default=0,
        update=_apply_edit_choice,
    )  # type: ignore
    image_model_edit: StringProperty(
        name="ID",
        description="Image model name used for reference-image concept renders",
        default="doubao-seedream-5-0-flash-260915",
    )  # type: ignore
    # 图像请求单次超时秒数: 0 = 不设时间限制(请求层映射为 None 阻塞至响应)——
    # 效果图重绘常超 3 分钟, 统一默认不限; 非 0 时到时即断, 请求失败不自动重试
    image_timeout: IntProperty(
        name="Timeout (s)",
        description="Request timeout in seconds for image generation requests, " "0 means no time limit",
        default=0,
        min=0,
        max=600,
    )  # type: ignore
    # 自动命名: 提示词取不出英文短名(如纯中文提示词)时, 用全局文本服务起一个简短英文名
    use_auto_name: BoolProperty(
        name="Auto Name",
        description="When a prompt has no English words (so the generated name falls back to the generic one), ask the global text service for a short English name and rename the new image with it; failures keep the generic name",
        default=True,
    )  # type: ignore
    # 生成图片的存盘目录: 留空时图片仅打包进 blend 文件
    image_save_dir: StringProperty(
        name="Image Save Directory",
        description="Directory to save generated images as files, empty keeps them packed in the blend only",
        subtype='DIR_PATH',
    )  # type: ignore
    # 每图保留的 "_bak" 备份份数: 修改图像(纹理面板)与效果图通道预览图各按此上限保留,
    # 超出时移除最旧备份(仅删数据块, 已存盘文件不受影响)
    image_backup_limit: IntProperty(
        name="Edit Backups per Image",
        description="How many '_bak' backups Modify Image and the render pass previews keep per image, older backups are removed when exceeded",
        default=1,
        min=1,
        max=10,
    )  # type: ignore
    # 参考图上传限制(张数, 最长边像素): 填 0 即**跟随当前服务商的官方上限**(自定义服务商为
    # 0/0, 那里的 0 就是不限); 填正数即该项自定义(可收紧或放宽). 不存"官方数字快照"是为了
    # 升级安全: 换服务商时由 _apply_image_preset 清零回到跟随官方, 不会把甲的限制安到乙头上.
    # 效果图面板的"钳制输出分辨率"与参考图张数截断都据此取值(见 image_client.ref_image_limits)
    image_ref_count: IntProperty(
        name="Reference Images",
        description="Maximum number of reference images sent to the image service, " "0 follows the provider's official limit",
        default=0,
        min=0,
        max=64,
    )  # type: ignore
    image_ref_edge: IntProperty(
        name="Reference Long Edge",
        description="Maximum long edge in pixels of an uploaded reference image, the output " "resolution clamp follows it; 0 follows the provider's official limit",
        default=0,
        min=0,
        max=32768,
        subtype='PIXEL',
    )  # type: ignore

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.alignment = 'CENTER'

        # 左右两列按服务划分: 文本与图像各自的服务接入与生成参数(编辑器联动并入生成盒内),
        # 避免按功能分列时图像专属参数与文本参数混排
        split = layout.split()
        col_text = split.column()
        col_image = split.column()

        # ---- 左列 文本服务 ----
        box = col_text.box()
        box.label(text="Text Service", icon="PREFERENCES")
        box.prop(self, "provider")
        if self.provider == 'CUSTOM':
            box.prop(self, "base_url")
            box.prop(self, "api_key")
            box.prop(self, "model")
        else:
            key_attr = get_text_provider(self.provider).api_key_attr
            box.prop(self, key_attr)
            # 下拉与模型 ID 紧贴成对(align 列消除对间空距): 自定义档显示可编辑输入框,
            # 其余档显示置灰备注行(实际模型 ID)
            pair = box.column(align=True)
            pair.prop(self, "model_choice")
            if self.model_choice == 'CUSTOM':
                pair.prop(self, "model")
            else:
                note = pair.row()
                note.enabled = False
                note.prop(self, "model", text=" ", emboss=False)
        # 连通性测试: DeepSeek 附带余额查询, 其余发 max_tokens=16 的 ping
        ts = context.window_manager.ch_service_test
        _draw_service_test(box, TEST_TEXT_OP, ts.text_result, ts.text_ok)

        box = col_text.box()
        box.label(text="Text Generation", icon="SETTINGS")
        box.prop(self, "temperature")
        box.prop(self, "comment_language")
        box.prop(self, "chat_history_limit")
        box.prop(self, "script_max_tokens")
        box.prop(self, "revise_backup_limit")
        box.prop(self, "timeout")
        box.prop(self, "use_context")
        # 编辑器联动开关并入本盒, 以分隔行与生成参数区隔
        box.prop(self, "use_auto_open_scripts")
        box.prop(self, "use_auto_open_chat")

        # ---- 右列 图像服务 ----
        # 模型控件按服务商切换: 预设服务商显示模型下拉(下方禁用文本行备注实际模型名, 与下拉同列对齐),
        # Custom 显示手输名输入框
        box = col_image.box()
        box.label(text="Image Service", icon="IMAGE_DATA")
        box.prop(self, "image_provider")
        if self.image_provider == 'CUSTOM':
            box.prop(self, "image_base_url")
            box.prop(self, "image_api_key")
            box.prop(self, "image_model_t2i")
            box.prop(self, "image_model_edit")
        else:
            key_attr = get_image_provider(self.image_provider).api_key_attr
            box.prop(self, key_attr)
            # 下拉与模型 ID 紧贴成对(align 列消除对间空距): 自定义档显示可编辑输入框,
            # 其余档显示置灰备注行(实际模型 ID)
            pair = box.column(align=True)
            pair.prop(self, "image_t2i_choice")
            if self.image_t2i_choice == 'CUSTOM':
                pair.prop(self, "image_model_t2i")
            else:
                note = pair.row()
                note.enabled = False
                note.prop(self, "image_model_t2i", text=" ", emboss=False)
            pair = box.column(align=True)
            pair.prop(self, "image_edit_choice")
            if self.image_edit_choice == 'CUSTOM':
                pair.prop(self, "image_model_edit")
            else:
                note = pair.row()
                note.enabled = False
                note.prop(self, "image_model_edit", text=" ", emboss=False)
        # 连通性测试: 发一次最小尺寸(1K)生成, 产生一次生成费用(见算子悬停说明)
        _draw_service_test(box, TEST_IMAGE_OP, ts.image_result, ts.image_ok)

        box = col_image.box()
        box.label(text="Image Generation", icon="SETTINGS")
        box.prop(self, "image_save_dir")
        box.prop(self, "image_backup_limit")
        box.prop(self, "image_timeout")
        # 参考图上传限制(默认即官方上限, 可自定义): 效果图面板的"钳制输出分辨率"与
        # 参考图张数截断据此取值; 其下为该服务商的输出图像限制提醒(两服务商同一模板, 数值
        # 直接取自 utils 的约束常量, 免得提醒与真实约束漂移)
        box.prop(self, "image_ref_count")
        box.prop(self, "image_ref_edge")
        box.prop(self, "use_auto_name")
        box.prop(self, "use_auto_open_images")

        # 跟随官方的语义提示 + **当前生效值**(0 在界面上看不出到底是多少, 故把解析结果明示)
        box.separator(type='LINE')
        col = box.column(align=False)
        note = col.row()
        note.enabled = False
        note.label(text="Reference limits: 0 follows the provider's official limit", icon='INFO')
        count, edge = ref_image_limits(self.image_provider, (self.image_ref_count, self.image_ref_edge))
        unlimited = iface("Unlimited")
        note = col.row()
        note.use_property_split = False
        note.enabled = False
        note.label(text=iface("Effective limits: {} images, long edge {}").format(count if count > 0 else unlimited, f"{edge} px" if edge > 0 else unlimited))
        limits = output_limits(self.image_provider)
        if limits is not None:
            side_min, side_max, total_min, total_max, aspect_max = limits
            note = col.row()
            note.use_property_split = False
            note.enabled = False
            note.label(text=iface("Output limits: side {} to {} px, aspect ratio up to {}:1").format(side_min, side_max, aspect_max))
            note = col.row()
            note.use_property_split = False
            note.enabled = False
            note.label(text=iface("Total pixels {} to {} (strictest model of the provider)").format(f"{total_min:,}", f"{total_max:,}"))


def get_prefs() -> AiAssistantPreferences:
    """获取插件偏好设置实例"""
    return bpy.context.preferences.addons[__addon_name__].preferences
