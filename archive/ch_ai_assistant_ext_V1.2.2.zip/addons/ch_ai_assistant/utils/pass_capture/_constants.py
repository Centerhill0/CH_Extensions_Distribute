"""通道捕获的常量与声明式表(采样/钳制/线稿预设/深度拾取/落盘规格/渲染组)

兼放**子包内共用的小工具函数**(组归属解析 / 可选 RNA 属性写入 / 数据块尽力回收)
与**本文件数据的 import 期自检**(`_check_pass_domain`, 见文末):
它们与本文件的声明式表同属"依赖栈底,无插件内依赖"的一层, 各子模块直接用,
免得为几行工具再开一个模块.

本模块无插件内依赖, 是 pass_capture 子包的依赖栈底.
"""


_EEVEE_SAMPLES = 16


_CLAMP_EDGE_MAX = 8192


WARN_EDGE_PX = 2048


_JPEG_QUALITY = 90


_PNG_COMPRESS = 6


# 蜡笔线稿基准宽度(世界单位 radius, 作者定标 0.01), 实际线宽由该基准乘用户宽度系数得到.
# **勿改回自适应换算**: 曾按"分辨率/视野目标 1.5px"自适应换算, 实测产出过细的头发丝线,
# 作者判定观感倒退, 已废弃 —— 这里是定标常数, 不是待优化项.
_EDGE_RADIUS_FALLBACK = 0.01


_EDGE_RADIUS_MIN = 0.001


_EDGE_RADIUS_MAX = 0.1


EDGE_PRESET_STANDARD = 'STANDARD'


EDGE_PRESET_CONTOUR = 'CONTOUR'


EDGE_PRESET_SHADED = 'SHADED'


EDGE_PRESET_HARDSURFACE = 'HARDSURFACE'


EDGE_PRESET_DEFAULT = EDGE_PRESET_STANDARD


EDGE_PRESETS = {
    # 轮廓 + 折痕 + 边标记 + 孤立边 + 相交线(等价修改器出厂状态)
    EDGE_PRESET_STANDARD: {
        'use_contour': True, 'use_loose': True, 'use_crease': True,
        'use_edge_mark': True, 'use_intersection': True,
        'use_shadow': False, 'use_light_contour': False,
    },
    # 只要物体外轮廓, 画面最干净
    EDGE_PRESET_CONTOUR: {
        'use_contour': True, 'use_loose': False, 'use_crease': False,
        'use_edge_mark': False, 'use_intersection': False,
        'use_shadow': False, 'use_light_contour': False,
    },
    # 标准 + 投影线 + 光源轮廓线(风格化)
    EDGE_PRESET_SHADED: {
        'use_contour': True, 'use_loose': True, 'use_crease': True,
        'use_edge_mark': True, 'use_intersection': True,
        'use_shadow': True, 'use_light_contour': True,
    },
    # 轮廓 + 折痕 + 相交线(去孤立边与边标记), 适合机械/硬表面
    EDGE_PRESET_HARDSURFACE: {
        'use_contour': True, 'use_loose': False, 'use_crease': True,
        'use_edge_mark': False, 'use_intersection': True,
        'use_shadow': False, 'use_light_contour': False,
    },
}


_DEPTH_PICK_GRID = (64, 48)


_DEPTH_PICK_NEAR_PCT = 2.0


_DEPTH_PICK_FAR_PCT = 98.0


_DEPTH_PICK_MIN_HITS = 8


PASS_ORDER = ('combined', 'depth', 'normal', 'segmentation', 'edge', 'diffuse', 'ao')


_PASS_FORMATS = {
    'combined': ('JPEG', '8', True),
    'depth': ('OPEN_EXR', '16', False),
    'normal': ('OPEN_EXR', '16', False),
    'diffuse': ('JPEG', '8', False),
    'ao': ('PNG', '8', False),
    'segmentation': ('PNG', '8', False),
    'edge': ('PNG', '8', False),
}


# 分割的 cryptomatte 落盘层数. **3 是下限而非可调项**: 实测无 cryptomatte_levels 属性可调,
# 而原先的材质覆盖方案对"每像素重叠对象数"没有上限, 层数不足会让重叠处**静默取到错误对象**
# —— 宁可多写临时文件, 也不引入行为回退. 代价: 每层 32bit EXR 1024²≈16.8 MB / 2048²≈67 MB.
CRYPTO_SLOT_COUNT = 3


CRYPTO_SLOT_KEYS = tuple(f"crypto_{i:02d}" for i in range(CRYPTO_SLOT_COUNT))


CRYPTO_SOURCE_OBJECT = 'OBJECT'


CRYPTO_SOURCE_MATERIAL = 'MATERIAL'


CRYPTO_SOURCE_ASSET = 'ASSET'


CRYPTO_SOURCE_SOCKETS = {
    CRYPTO_SOURCE_OBJECT: tuple(f"CryptoObject{i:02d}" for i in range(CRYPTO_SLOT_COUNT)),
    CRYPTO_SOURCE_MATERIAL: tuple(f"CryptoMaterial{i:02d}" for i in range(CRYPTO_SLOT_COUNT)),
    CRYPTO_SOURCE_ASSET: tuple(f"CryptoAsset{i:02d}" for i in range(CRYPTO_SLOT_COUNT)),
}


CRYPTO_SOURCE_PASS_ATTR = {
    CRYPTO_SOURCE_OBJECT: 'use_pass_cryptomatte_object',
    CRYPTO_SOURCE_MATERIAL: 'use_pass_cryptomatte_material',
    CRYPTO_SOURCE_ASSET: 'use_pass_cryptomatte_asset',
}


# 出厂分割依据. **必须与 props.cryptomatte_source 的 default 同口径**:
# 两者不一致会变成"影子默认"(面板显示一档,实际按另一档跑). 另注: 无材质物体在 material
# 通道得到的是 -515791044739072.0 这类**非零**哈希(2026-10-13 实测), 故它会因不在名字表内
# 而计入"有覆盖却未匹配",像素保持黑 —— 不是"哈希为 0".
CRYPTO_SOURCE_DEFAULT = CRYPTO_SOURCE_OBJECT


_SEG_UNMATCHED_WARN = 0.01

# 分割通道的落盘规格按层追加(crypto_NN 与普通通道同样是 32bit EXR, 只是键名由层数派生)
_PASS_FORMATS.update({key: ('OPEN_EXR', '32', False) for key in CRYPTO_SLOT_KEYS})

_EXTENSIONS = {'JPEG': '.jpg', 'PNG': '.png', 'OPEN_EXR': '.exr'}


GROUP_MAIN = 'main'


GROUP_LINEART = 'lineart'


GROUP_VIEW_LAYER = {
    GROUP_MAIN: "VL_Main",
    GROUP_LINEART: "VL_LineArt",
}


GROUP_OUTPUTS = {
    GROUP_MAIN: (
        ('combined', 'Image'),
        ('depth', 'Depth'),
        ('normal', 'Normal'),
        ('diffuse', 'Diffuse Color'),
        ('ao', 'Ambient Occlusion'),
    ),
    GROUP_LINEART: (('edge', 'Grease Pencil'),),
}


LINEART_COLLECTION = "CH_AI_LineArt"


def _crypto_slots_used(crypto_slots: int) -> int:
    """把落盘层数夹到合法区间(1..CRYPTO_SLOT_COUNT)"""
    try:
        value = int(crypto_slots)
    except (TypeError, ValueError):
        return CRYPTO_SLOT_COUNT
    return max(1, min(CRYPTO_SLOT_COUNT, value))


def _group_entries(group: str, wanted: dict, crypto_source: str = CRYPTO_SOURCE_DEFAULT,
                   crypto_slots: int = CRYPTO_SLOT_COUNT) -> tuple:
    """该组本次需要的出线(通道键, 出线名)表

    主组按逐通道勾选过滤(可能为空), 勾选分割时再追加所选依据对应的 cryptomatte 各层;
    线稿组是整体开关, 关闭即整组不出线. 空表意味着该组本次无需渲染.
    """
    if group == GROUP_MAIN:
        entries = tuple(item for item in GROUP_OUTPUTS[group] if wanted.get(item[0]))
        if wanted.get('segmentation'):
            sockets = CRYPTO_SOURCE_SOCKETS.get(crypto_source,
                                                CRYPTO_SOURCE_SOCKETS[CRYPTO_SOURCE_DEFAULT])
            slots = _crypto_slots_used(crypto_slots)
            entries += tuple(zip(CRYPTO_SLOT_KEYS[:slots], sockets[:slots]))
        return entries
    if group == GROUP_LINEART:
        return GROUP_OUTPUTS[group] if wanted.get('edge') else ()
    return ()


def set_attr_safe(obj, attr: str, value, exceptions=(AttributeError,)) -> bool:
    """尽力设置一个可选 RNA 属性, 返回是否设置成功

    本管线要兼容多个 Blender 构建: 某些通道/修改器属性在旧构建上不存在,
    设置它会抛 AttributeError. 这类缺失**不阻断捕获**(该通道随后在提取/解码期兜底),
    故统一在此吞掉, 免得每处各写一遍 try 与同样的理由注释.
    """
    try:
        setattr(obj, attr, value)
        return True
    except exceptions:
        return False


def drop_silently(remove_fn, item, **kwargs) -> bool:
    """尽力回收一个数据块, 返回是否成功

    清理是**尽力而为**: 目标可能已被连带删除(删蜡笔对象时其数据块/材质会一并消失),
    失败只说明"已经没了", 绝不允许因此打断捕获流程或残留错误.
    """
    try:
        remove_fn(item, **kwargs)
        return True
    except Exception:  # noqa: BLE001 - 清理失败一律忽略(见上)
        return False


def _check_pass_domain() -> None:
    """**本文件**通道域自检(import 期执行一次): 落盘规格与渲染组归属必须与通道序同域

    校验三项: ① `_PASS_FORMATS` 的键集恰为 `PASS_ORDER` + `CRYPTO_SLOT_KEYS`;
    ② `GROUP_OUTPUTS` 里的通道键不超出 `PASS_ORDER`; ③ 两个渲染组都已在 `GROUP_OUTPUTS` 声明.

    同一通道域在别处另有手写表(`prompts.PASS_ROLES` / `render_send._PASS_TITLES`),
    各有各的自检,**本函数不校验它们**. 注意 `EDGE_PRESETS` 按**预设名**(STANDARD 等)查表,
    不是按通道键, 故不在本自检范围内.
    漏改的表现是某通道被静默跳过(不报错), 故在此断言钉死.
    """
    declared = set(PASS_ORDER)
    if set(_PASS_FORMATS) != declared | set(CRYPTO_SLOT_KEYS):
        raise AssertionError(
            f"_PASS_FORMATS 键集与 PASS_ORDER + CRYPTO_SLOT_KEYS 不一致: "
            f"缺 {declared - set(_PASS_FORMATS)}, 多 {set(_PASS_FORMATS) - declared}")
    outputs = {key for entries in GROUP_OUTPUTS.values() for key, _ in entries}
    if outputs - declared:
        raise AssertionError(f"GROUP_OUTPUTS 含 PASS_ORDER 之外的通道键: {outputs - declared}")
    missing = {group for group in (GROUP_MAIN, GROUP_LINEART) if group not in GROUP_OUTPUTS}
    if missing:
        raise AssertionError(f"GROUP_OUTPUTS 缺少渲染组: {missing}")


_check_pass_domain()
