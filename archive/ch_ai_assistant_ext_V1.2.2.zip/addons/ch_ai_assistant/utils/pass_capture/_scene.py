"""临时场景与合成节点树: 视图层分组, 逐通道 File Output, 单次渲染调用
"""


import bpy
import os


from ..errors import api_error


from ._constants import CRYPTO_SOURCE_DEFAULT, CRYPTO_SOURCE_OBJECT, CRYPTO_SOURCE_PASS_ATTR, GROUP_LINEART, GROUP_MAIN, GROUP_VIEW_LAYER, LINEART_COLLECTION, _EXTENSIONS, _JPEG_QUALITY, _PASS_FORMATS, set_attr_safe


from ._size import _clamped_percentage


def _eevee_engine_id() -> str | None:
    """EEVEE 草稿引擎 id: 4.2+ 为 BLENDER_EEVEE_NEXT, 旧版为 BLENDER_EEVEE, 均无则 None

    注意: RenderSettings.engine 的枚举表是惰性维护的(后台加载时只列举当前档),
    故这里不能靠 enum_items 判定可用性, 改为直接尝试赋值探测(见 _is_engine_usable).
    """
    for engine_id in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        if _is_engine_usable(engine_id):
            return engine_id
    return None


def _is_engine_usable(engine_id: str) -> bool:
    """探测引擎在本构建是否可用: 往一个临时场景的 RenderSettings 上尝试赋值

    enum_items 惰性(后台只列举当前档), 故不能靠枚举表判定; 赋值失败必然不可用,
    赋值成功即认为可用(真正的渲染失败仍由捕获期异常兜底转成错误信息).
    """
    tmp = None
    try:
        tmp = bpy.data.scenes.new("CH_AI_EngineProbe")
        tmp.render.engine = engine_id
        return tmp.render.engine == engine_id
    except (TypeError, ValueError):
        return False
    except Exception:  # noqa: BLE001 - 探测场景建不出来等异常一律按不可用处理
        return False
    finally:
        if tmp is not None:
            bpy.data.scenes.remove(tmp)


def _link_user_scene(tmp, scene) -> None:
    """把用户场景的集合与主集合物体关联进临时场景(引用共享, 不复制)"""
    for col in scene.collection.children:
        tmp.collection.children.link(col)
    for obj in scene.collection.objects:
        tmp.collection.objects.link(obj)


def _copy_render_common(tmp, scene, clamp_long_edge: int) -> None:
    """拷贝渲染公共项: 分辨率(按钳制上限等比下调百分比)/帧/胶片/水印

    帧必须跟随原场景: 临时场景默认停在第 1 帧, 不拷则动场景(关键帧/驱动/约束)捕获到的是首帧画面.
    """
    rd, src = tmp.render, scene.render
    rd.resolution_x = src.resolution_x
    rd.resolution_y = src.resolution_y
    rd.resolution_percentage = _clamped_percentage(src, clamp_long_edge)
    rd.film_transparent = False
    rd.use_stamp = False
    tmp.frame_start = scene.frame_start
    tmp.frame_end = scene.frame_end
    tmp.frame_current = scene.frame_current


def _copy_color_management(tmp, scene) -> None:
    """把用户场景的色彩管理拷到临时场景(只有合并结果会套用)

    合并结果走 File Output 的 save_as_render=True, 套的是**临时场景**的 view transform,
    故必须把用户设置搬过来, 否则会落到临时场景的出厂默认(AgX).
    其余通道靠 item 级 save_as_render=False 跳过色彩管理(见 _add_output_node), 不受影响.
    """
    try:
        vs_src, vs_dst = scene.view_settings, tmp.view_settings
        vs_dst.view_transform = vs_src.view_transform
        try:
            vs_dst.look = vs_src.look
        except TypeError:
            pass  # 个别 look 枚举缺档时保留默认
        vs_dst.exposure = vs_src.exposure
        vs_dst.gamma = vs_src.gamma
    except Exception:  # noqa: BLE001 - 老构建缺属性时退回临时场景默认色彩管理
        pass


def _enable_passes(vl, group: str, wanted: dict, ao_distance: float,
                   crypto_source: str = CRYPTO_SOURCE_OBJECT) -> None:
    """按组开启该视图层的渲染通道(AO 遮蔽距离落在视图层而非场景, 5.1 实证)

    各组只开自己需要的通道: 主组按勾选开(勾选分割时再开所选依据的 cryptomatte 通道),
    线稿组只要蜡笔通道.
    """
    if group == GROUP_LINEART:
        # 引擎注册表无该 RNA 属性时跳过, 通道缺失在提取期兜底
        set_attr_safe(vl, "use_pass_grease_pencil", True)
        return
    vl.use_pass_combined = True
    if group == GROUP_MAIN and wanted.get('segmentation'):
        attr = CRYPTO_SOURCE_PASS_ATTR.get(crypto_source,
                                           CRYPTO_SOURCE_PASS_ATTR[CRYPTO_SOURCE_DEFAULT])
        # 语义分割由 Cryptomatte 承担: 它只编码 ID, 与材质无关, 故无需任何覆盖;
        # 该构建没有 cryptomatte 通道时跳过, 分割缺失在解码期兜底
        set_attr_safe(vl, attr, True, (AttributeError, TypeError))
    if wanted['depth']:
        vl.use_pass_z = True
    if wanted['normal']:
        vl.use_pass_normal = True
    if wanted['diffuse']:
        vl.use_pass_diffuse_color = True
    if wanted['ao']:
        try:
            vl.use_pass_ambient_occlusion = True
            vl.eevee.ambient_occlusion_distance = ao_distance
        except AttributeError:
            pass  # 引擎注册表无该 RNA 属性时跳过, 通道缺失在提取期兜底


def _layer_collection_of(vl, col):
    """在该视图层的集合树里按**数据块身份**取 LayerCollection(不按名字)

    名字不可作身份: `bpy.data.collections.new()` 遇重名会自动加 `.001` 后缀,
    而 `layer_collection.children` 又是按名字索引的 —— 按名字回查会在重名时**静默取不到**.
    """
    for lc in vl.layer_collection.children:
        if lc.collection == col:
            return lc
    return None


def _ensure_view_layers(tmp, groups, lineart_col=None) -> tuple:
    """按需要的组准备临时场景的视图层, 返回 ({组: 视图层}, 线稿集合), 并设置集合排除关系

    主组按集合排除蜡笔集合(它不该看到线稿), 线稿组包含之. 线稿集合每次**新建**并返回
    数据块本身, 后续一律按身份使用它.

    **为什么必须按身份而不是按名字**(2026-10-15 用户实测缺陷, 已由红基线复现):
    临时场景会被 `_link_user_scene` 链入用户的子集合, 若用户恰好有同名集合, 按名字取会
    **误取用户的集合**(把蜡笔塞进用户集合, 还把用户的集合从主组排除掉); 更常见的是上一次
    捕获的集合以 0 用户形态留在 `bpy.data.collections` 里没被回收, 于是本次新建被改名成
    `.001`, 而按名字回查**取不到** → 集合排除与蜡笔搬移**双双静默失效** →
    蜡笔留在场景主集合里, 两个视图层都能看到它, **合并结果被叠上线稿**.
    """
    if lineart_col is None:
        lineart_col = bpy.data.collections.new(LINEART_COLLECTION)
        tmp.collection.children.link(lineart_col)

    layers = {}
    for group, name in GROUP_VIEW_LAYER.items():
        if group not in groups:
            continue
        vl = tmp.view_layers.get(name)
        if vl is None:
            # 首个视图层沿用默认层并改名, 避免多出一个空的 "ViewLayer"
            if len(tmp.view_layers) == 1 and tmp.view_layers[0].name == "ViewLayer":
                vl = tmp.view_layers[0]
                vl.name = name
            else:
                vl = tmp.view_layers.new(name)
        layers[group] = vl

    for group, vl in layers.items():
        lc = _layer_collection_of(vl, lineart_col)
        if lc is not None:
            lc.exclude = group != GROUP_LINEART
    return layers, lineart_col


def _move_to_lineart_collection(lineart_col, gp) -> None:
    """把蜡笔对象挪进线稿专用集合(集合由 _ensure_view_layers 新建并返回, 按身份传入)

    主组的视图层按集合排除该集合, 线稿组包含它 —— 这是「一次渲染既能得到干净的
    合并结果,又能得到线稿」的关键: 蜡笔若留在场景主集合里, 所有视图层都会看到它.
    """
    if gp is None or lineart_col is None:
        return
    for user_col in list(gp.users_collection):
        user_col.objects.unlink(gp)
    lineart_col.objects.link(gp)


def _add_output_node(ng, tmp_dir: str, key: str):
    """建一个通道落盘节点(一个通道一个节点, 逐通道独立格式)

    必须先设 format.media_type='IMAGE': 默认档 MULTI_LAYER_IMAGE 会把 file_format
    锁死为 OPEN_EXR_MULTILAYER 并把所有输入并进同一个 .exr;
    EXR 位深只在**节点级**设置(item 级 color_depth 实测被忽略).

    save_as_render 则相反, **必须写到 item 上**: item 打开 override_node_format 后,
    落盘时的颜色管理以 item 自己的 save_as_render 为准(其默认值是 True), 节点上那个被
    完全无视 —— 这正是"除合并结果外其余通道仍被套上用户 view transform"的成因
    (实测: 同一场景把用户 view transform 在 Standard/AgX/Filmic 间切换, 分割图统计随
    之变化 0.6658/0.5934/0.6204, 而它本应恒等). 节点级保留为显式意图声明, item 级才生效.
    """
    image_format, color_depth, save_as_render = _PASS_FORMATS[key]
    fo = ng.nodes.new("CompositorNodeOutputFile")
    fo.directory = tmp_dir
    fo.file_name = ""  # 文件名只取区间名, 避免与节点名拼接成 combined_combined
    fo.save_as_render = save_as_render
    fo.format.media_type = 'IMAGE'
    fo.format.file_format = image_format
    try:
        fo.format.color_depth = color_depth
    except TypeError:
        pass  # 该格式不支持该位深时用默认档
    if image_format == 'JPEG':
        try:
            fo.format.quality = _JPEG_QUALITY
        except Exception:  # noqa: BLE001 - 老构建无 quality 时用默认质量
            pass
    # 落点通过节点的 inputs 建(它就是 items 列表), item 对象没有 socket 属性
    it = fo.file_output_items.new('RGBA', key)
    it.override_node_format = True
    it.save_as_render = save_as_render  # ← 实际生效的那一份(见上)
    it.format.media_type = 'IMAGE'
    it.format.file_format = image_format
    try:
        it.format.color_depth = color_depth
    except (TypeError, AttributeError):
        pass
    return fo


def _build_capture_group(tmp, tmp_dir: str, layer_entries: tuple) -> tuple:
    """构建合成节点组: 每组一个 RLayers(绑定其视图层) -> 该组每通道一个 File Output

    layer_entries 为 ((视图层, 出线表), ...), 出线表即 GROUP_OUTPUTS[组];
    多个视图层可以在同一次渲染调用里各自落盘(实测), 故节点组一次建全.
    返回 (节点组, 缺失通道提示列表); 出线在当前引擎不存在时跳过该通道并记提示,
    不打断整次捕获. 树根仍需一个 NodeGroupOutput 让渲染正常产出合成结果(它是节点树
    必需的输出接口), 但渲染自身不写盘(见 _render_frame), 一次捕获只产出通道文件.
    合成器里**不做任何数学**: 需要变形的通道(深度/法向/线稿)一律原样落盘后在 Python 内
    处理——实测本管线的 AlphaOver 会把纯白底洗成 0.769 灰, 且不同连线给出逐字节相同的
    结果, 节点内做算术不可信.
    提示用 api_error 的"常量标题 + 动态通道键"形态(utils 内不做翻译查询, 由交互层
    describe_error 翻译标题后拼接通道键, 见 errors 模块头注释).
    """
    ng = bpy.data.node_groups.new("CH_AI_PassCapture", 'CompositorNodeTree')
    tmp.compositing_node_group = ng
    ng.interface.new_socket(name="Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    go = ng.nodes.new("NodeGroupOutput")
    missing = []
    root_linked = False
    for vl, entries in layer_entries:
        rl = ng.nodes.new("CompositorNodeRLayers")
        rl.scene = tmp
        rl.layer = vl.name
        if not root_linked and rl.outputs.get("Image") is not None:
            # 树根的输出接口取第一个有 Image 出线的组(线稿组只开蜡笔通道, 没有可用 Image)
            ng.links.new(rl.outputs["Image"], go.inputs[0])
            root_linked = True
        for key, socket_name in entries:
            sock = rl.outputs.get(socket_name)
            if sock is None:
                missing.append((key, api_error(
                    "The pass is not available from this engine, it was skipped", key)))
                continue
            fo = _add_output_node(ng, tmp_dir, key)
            ng.links.new(sock, fo.inputs[0])
    return ng, missing


def _drop_node_group(ng) -> None:
    """回收本帧的合成节点组(用完即释放: 临时场景虽会整体回收, 但提前删掉更干净)

    失败一律静默: 节点组已随场景回收,或本帧根本没建起来, 都不该影响捕获流程.
    """
    if ng is None:
        return
    try:
        bpy.data.node_groups.remove(ng)
    except Exception:  # noqa: BLE001 - 已随场景回收时忽略
        pass


def _render_frame(tmp, vl, tmp_dir: str, layer: str | None = None) -> tuple:
    """渲染一次, 返回错误信息

    layer 非空时只渲染该视图层(实测: 其它视图层的 File Output **不会**被写出),
    用于「只有一组失效」时避免连带重渲另一组.
    write_still=False: 通道文件由合成器的 File Output 节点落盘, 与静帧写盘无关(实测),
    故不写静帧——省掉每帧一次整幅 PNG 编码与落盘(一次捕获原本要多写 3 次 render_still.png).
    filepath 仍指向本次临时目录: 万一将来这里改回要写静帧, 落点也不会外泄到用户工程目录.
    """
    tmp.render.filepath = os.path.join(tmp_dir, "render_still")
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=vl):
            if layer:
                bpy.ops.render.render(write_still=False, layer=layer)
            else:
                bpy.ops.render.render(write_still=False)
    except RuntimeError as e:
        return api_error("Render failed", e)
    return None


def _pass_file(tmp_dir: str, key: str, image_format: str):
    """定位通道落盘文件(扩展名由节点格式决定; 找不到精确名时按前缀兜底)"""
    ext = _EXTENSIONS.get(image_format, '.png')
    exact = os.path.join(tmp_dir, key + ext)
    if os.path.isfile(exact):
        return exact
    try:
        names = os.listdir(tmp_dir)
    except OSError:
        return None
    for name in names:
        if name.startswith(key) and name != "render_still.png":
            return os.path.join(tmp_dir, name)
    return None
