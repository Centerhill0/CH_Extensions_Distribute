"""
"_bak" 备份环清理工具模块

图像数据块与文本块共用同一套备份环策略: 按偏好上限保留最新若干份, 其余按名称序号
从旧到新移除. 两种数据块的差异只在遍历集合,删除 API 与提示文案, 故把"选哪些该删"
这一算法收口为单一实现; 删除与上报由调用方按自身文案逐个执行
(utils 内不做 report, 且报告与删除的先后顺序属调用方的可观测行为).

主要功能:
- expired_backups: 选出超出上限的旧备份数据块, 返回 (数据块列表, 错误信息)
"""


def expired_backups(collection, base: str, keep_name: str, limit: int) -> tuple:
    """选出超出保留上限的旧备份数据块, 返回 (数据块列表, 错误信息)

    collection 为待遍历的数据块集合(bpy.data.images / bpy.data.texts);
    base 为原名干(不含 "_bak" 后缀), keep_name 为刚生成的最新备份名(必保留);
    limit 为保留份数(调用方自偏好解析, 不足 1 份时按 0 处理).

    名字为 <base>_bak 或 <base>_bak.<序号> 的条目视作备份, 按序号从旧到新排序后取
    超限的前若干项; 序号缺失或非数字的按最旧处理(兼容旧版带 .py 的备份名).
    本函数只做筛选不执行删除, 故错误信息恒为 None; 保留该返回位是为守住 utils
    "失败经 (结果, 错误信息) 元组表达" 的口径(见 utils 包组织规范).
    """
    prefix = f"{base}_bak"
    backups = [block for block in collection
               if (block.name == prefix or block.name.startswith(prefix + "."))
               and block.name != keep_name]
    excess = len(backups) - max(0, limit)
    if excess <= 0:
        return [], None

    def _suffix_num(name: str) -> int:
        tail = name[len(prefix):]
        return int(tail[1:]) if tail.startswith(".") and tail[1:].isdigit() else 0

    return sorted(backups, key=lambda item: _suffix_num(item.name))[:excess], None
