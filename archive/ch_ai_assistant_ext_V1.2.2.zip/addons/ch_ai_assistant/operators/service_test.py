"""
服务连通性测试操作模块

偏好设置中文本服务与图像服务的连通性测试, 结果写入 WM 状态供偏好面板常驻显示.

操作流程:
1. 文本服务: DeepSeek 走官方余额接口(不产生费用, 顺带显示账户余额);
   其余服务商发 max_tokens=16 的 ping 请求
2. 图像服务: 发一次最小尺寸(1K)的文生图请求——会产生一次生成费用(按钮悬停说明)
3. invoke: 校验对应服务配置与联网权限, 启动后台测试线程进入模态等待
4. modal: 计时器轮询线程结果, Esc 放弃等待
5. 响应处理: 结果(成功描述或错误文本)写入 ch_service_test 状态并 report
"""

from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import report
from ..preference import TEST_IMAGE_OP, TEST_TEXT_OP, get_prefs
from ..utils import (
    api_error,
    describe_error,
    fetch_deepseek_balance,
    format_size,
    ping_chat,
    request_image,
)
from ..utils.provider_registry import get_text_provider
from .ai_generate import AiRequestMixin, ChatRequestArgs, check_chat_service, snapshot_chat_prefs
from .image_common import ImageRequestArgs, check_image_service, snapshot_image_prefs


def _text_test_worker(op, chat_args: ChatRequestArgs):
    """文本服务测试后台线程入口: 按服务商测试策略(余额查询/最小 ping)分派, 结果写入 op._result"""
    try:
        p = get_text_provider(chat_args.provider)
        if p is not None and p.test_strategy == 'balance':
            result, err = fetch_deepseek_balance(chat_args.base_url, chat_args.api_key,
                                                 chat_args.timeout)
        else:
            result, err = ping_chat(chat_args.base_url, chat_args.api_key, chat_args.model,
                                    chat_args.timeout, chat_args.provider)
        op._result = (result, err)
    except Exception as e:
        op._result = (None, api_error("The test thread crashed", e))


def _image_test_worker(op, image_args: ImageRequestArgs, model, prompt, size):
    """图像服务测试后台线程入口: 发一次最小尺寸生成请求, 结果写入 op._result"""
    try:
        image_bytes, err = request_image(image_args.base_url, image_args.api_key, model, prompt,
                                         image_args.timeout, provider=image_args.provider, size=size)
        if err is None:
            op._result = ("OK (one minimal image was generated, a generation fee applies)", None)
        else:
            op._result = (None, err)
    except Exception as e:
        op._result = (None, api_error("The test thread crashed", e))


def _finish_service_test(op, ts, ok_attr: str, result_attr: str, content, err) -> set:
    """服务测试响应统一落地: 写面板状态(成功标志 + 结果文本)并上报, 返回结果集

    文本与图像两个测试算子共用; ok_attr/result_attr 各自的面板字段名(text_*/image_*).
    """
    setattr(ts, ok_attr, err is None)
    setattr(ts, result_attr, describe_error(content if err is None else err))
    if err is not None:
        op.report({'ERROR'}, describe_error(err))
        return {'CANCELLED'}
    op.report({'INFO'}, report("Service test passed: {}").format(content))
    return {'FINISHED'}


class TestTextService(Operator, AiRequestMixin):
    """
    测试文本服务操作器

    功能: 验证对话服务连通与密钥(DeepSeek 查询账户余额, 其余服务商发
    max_tokens=16 的 ping 请求); 结果写入面板状态并 report.
    """

    bl_idname = TEST_TEXT_OP
    bl_label = "Test Text Service"
    bl_description = "Test the text service: query the DeepSeek balance or send a minimal ping"
    bl_options = {'REGISTER'}

    status_text = "Testing text service... (Esc to cancel)"
    status_scope = 'test'

    def invoke(self, context: Context, event: Event):
        if not check_chat_service(self):
            return {'CANCELLED'}
        chat_args = snapshot_chat_prefs()
        if not self._start_request(context, _text_test_worker, chat_args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        return _finish_service_test(self, context.window_manager.ch_service_test,
                                    "text_ok", "text_result", content, err)


class TestImageService(Operator, AiRequestMixin):
    """
    测试图像服务操作器

    功能: 验证图像服务连通与密钥(发一次最小尺寸(1K)的文生图请求,
    产生一次生成费用); 结果写入面板状态并 report.
    """

    bl_idname = TEST_IMAGE_OP
    bl_label = "Test Image Service"
    bl_description = ("Test the image service with one minimal 1K generation "
                      "(a generation fee applies)")
    bl_options = {'REGISTER'}

    status_text = "Testing image service... (Esc to cancel)"
    status_scope = 'test'

    def invoke(self, context: Context, event: Event):
        if not check_image_service(self):
            return {'CANCELLED'}
        image_args = snapshot_image_prefs()
        model = get_prefs().image_model_t2i
        size = format_size(image_args.provider, 1024, 1024)
        if not self._start_request(context, _image_test_worker, image_args,
                                   model, "a simple neutral gray square, minimal connectivity test",
                                   size):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, content, err):
        return _finish_service_test(self, context.window_manager.ch_service_test,
                                    "image_ok", "image_result", content, err)
