"""
图像预览区绘制模块(非面板)

纹理与图像生成器与效果图三个面板共用的预览区: 缩略图控件(尺寸/名称标签/名称过滤/显示上限) +
列表内全部图像的缩略图图标视图(Blender 的 template_icon_view).

缩略图条目取自各面板自己的图像列表快照(见 props.gallery_visible_items), 因此天然只含本面板
的产物(纹理面板不含效果图与参考通道图, 效果图面板不含纹理贴图); 缩略图与列表高亮双向实时
同步: 点缩略图即把列表高亮切到对应图像(见 handlers.select_image_by_name), 点列表行或生成
置顶时缩略图选中态同步回写.
"""

from bpy.types import UILayout

from .....common.i18n.i18n import iface
from ...handlers import gallery_visible_items

# 缩略图弹出预览相对网格缩略图的放大倍数(template_icon_view 的 scale_popup)
_POPUP_FACTOR = 1.6


def draw_preview_box(layout: UILayout, state, empty_hint: str, label_tail=None):
    """绘制预览区(常驻): 标题行(最右侧挂保存按钮列) + 缩略图图标视图/空态提示 + 缩略图控件子面板

    empty_hint 为列表为空时的提示文案(由调用面板按自己的产物类型给出, 经 iface 翻译);
    两个图像面板共用本函数, 面板状态由调用方传入;
    label_tail 为可选回调(接收**标题行最右侧的按钮行**与面板状态), 供调用面板挂按钮
    (如两个图像面板的保存按钮). 该按钮行**常驻且位置恒定**——挂在"Preview"标题行最右侧,
    与有无缩略图无关(缩略图侧横向宽度随张数变化, 挂在那里会让按钮左右偏移); 不可用时
    由各面板的置灰逻辑统一置灰(见 blocks.draw_save_tail), 不整列消失.
    """
    box = layout.box()
    head = box.row()
    head.label(text="Preview", icon='IMAGE_DATA')
    # 保存按钮行(常驻, 右对齐于标题行): 位置与缩略图/空态提示无关, 恒定贴在面板最右侧
    if label_tail is not None:
        save_row = head.row(align=True)
        save_row.alignment = 'RIGHT'
        label_tail(save_row, state)
    visible = gallery_visible_items(state) if len(state.images) else []
    if len(state.images) == 0:
        note = box.row()
        note.alignment = 'CENTER'
        note.enabled = False
        note.label(text=empty_hint, icon='INFO')
    elif not visible:
        note = box.row()
        note.alignment = 'CENTER'
        note.enabled = False
        note.label(text=iface("No thumbnail matches the filter"), icon='INFO')
    else:
        # 缩略图图标视图: 条目来自状态组的动态枚举(标识与标签为数据块名, 悬停说明为像素尺寸)
        view_row = box.row(align=False)
        view_row.template_icon_view(state, "gallery_image", show_labels=state.gallery_labels,
                                    scale=state.gallery_scale,
                                    scale_popup=state.gallery_scale * _POPUP_FACTOR)
    _draw_controls(box, state)


def _draw_controls(box, state):
    """缩略图控件子面板(默认收起): 标题只有展开箭头, 展开后两行紧凑控件

    第一行"名称过滤框 + 名称标签图标钮"(标签开关紧跟搜索框), 第二行"尺寸滑块 / 显示上限"
    (两个都带文字标签, 供不从悬停说明也能一眼识别); 控件只影响缩略图显示,
    与列表本身的过滤/排序控件互不影响.
    """
    header = box.row()
    header.prop(state, "use_show_controls", text="", emboss=False,
                icon='TRIA_DOWN' if state.use_show_controls else 'TRIA_RIGHT')
    header.label(text="Controls")
    if not state.use_show_controls:
        return
    col = box.column(align=True)
    # 第一行: 名称过滤框(占主宽) + 名称标签图标钮
    row = col.row(align=True)
    row.prop(state, "gallery_filter", text="", icon='VIEWZOOM')
    row.prop(state, "gallery_labels", text="", icon='TEXT', toggle=True)
    # 第二行: 尺寸滑块 / 显示上限
    row = col.row(align=True)
    row.prop(state, "gallery_scale", text="Size", slider=True)
    row.prop(state, "gallery_limit", text="Max Shown")
