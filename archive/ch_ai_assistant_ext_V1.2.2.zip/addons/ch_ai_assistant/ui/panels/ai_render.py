"""
AI 效果图面板模块

图像助手选项卡下的效果图面板, 自上而下四段:
1. 效果图主列表(只含生成结果 "AI Render" 前缀; 右侧竖列为自动打开开关 + 排序 + 删除)
   + 预览区(见 preview.draw_preview_box)
2. 生成通道小节(内联可折叠, 默认收起, 位于 Settings 之上):
   通道组合预设行 + 参考通道两列网格(左 4 右 3) + 通道参数 box(仅显示已开启通道的参数)
   + 通道迷你列表(常驻, 右侧为删除/保存当前/保存全部) + 捕获信息与"生成通道"按钮;
   全部随本小节折叠
3. 设置与发送通道合并小节(单折叠头 Settings, 默认收起): 先输出侧设置(分辨率/随机种/
   张数/多变体/风格参考图开关), 再以"发送通道:"标签领起发送开关与预算摘要
4. 描述输入与操作行(修改效果图 / 生成效果图), 其后为错误摘要与等待进度
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt, resolve_prompt
from ...operators.ai_render import (
    CaptureViewRefs,
    GenerateRender,
    ModifyRender,
    PickDepthRange,
    PreviewRenderPrompt,
)
from ...operators.pass_presets import ApplyPassPreset, DeletePassPreset, SavePassPreset
from ...operators.render_send import (
    _PASS_TOGGLES,
    _pass_title,
    _resolve_service,
    ClearPassBackups,
    captured_pass_count,
    collect_send_passes,
    collect_style_images,
    count_unavailable_style_refs,
    resolve_render_request,
)
from ...operators.ai_texture import SaveAllImages, SaveImage
from ...operators.image_common import resolve_edit_model
from ...operators.list_ops import DeleteImage
from ...preference import get_prefs
from ...utils import (
    AI_RENDER_PROMPT_TEXT_NAME,
    WARN_EDGE_PX,
    estimate_capture_bytes,
    estimate_prompt_tokens,
    prompt_token_budget,
    resolve_capture_size,
    resolve_ref_limits,
)
from ...utils.provider_registry import effective_provider
from .blocks import (
    draw_operator,
    draw_error_box,
    draw_fold_header,
    draw_greyed_row,
    draw_image_list_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_output_settings,
    draw_reference_list,
    draw_save_tail,
    draw_wait_box,
)
from .preview import draw_preview_box

# 通道迷你列表的行数下限(空列表的矮框高度)
_PASS_ROWS_MIN = 4


def _size_text(num_bytes: int) -> str:
    """字节数转可读体积文案(不足 1MB 用 KB, 单位不翻译不入典)"""
    if num_bytes >= 1024 * 1024:
        return f"{num_bytes / (1024 * 1024):.1f} MB"
    return f"{num_bytes / 1024:.0f} KB"


# --------------------------------------------------------------------------- 生成通道小节


def _draw_pass_preset_row(sub, prefs) -> None:
    """通道组合预设行: 下拉 + 应用(对勾) / 保存(加号) / 删除(叉号), 预设存于偏好跨会话"""
    row = sub.row(align=True)
    row.prop(prefs, "pass_preset_choice", text="")
    draw_operator(row, ApplyPassPreset.bl_idname, None, 'CHECKMARK', text="")
    draw_operator(row, SavePassPreset.bl_idname, None, 'ADD', text="")
    draw_operator(row, DeletePassPreset.bl_idname, None, 'REMOVE', text="")


def _draw_pass_grid(sub, state) -> None:
    """参考通道两列网格(左 4 右 3, 纵向排布; 每项悬停看通道含义)"""
    grid = sub.row(align=False)
    left = grid.column(align=True)
    right = grid.column(align=True)
    left.prop(state, "use_combined")
    left.prop(state, "use_depth")
    left.prop(state, "use_normal")
    left.prop(state, "use_segmentation")
    right.prop(state, "use_edge")
    right.prop(state, "use_diffuse")
    right.prop(state, "use_ao")


def _draw_pass_params(sub, state) -> None:
    """通道设置 box: 常驻开关(钳制/采样数) + 已开启通道各自的生成参数

    整列属性分栏; 参数按通道顺序排布, 只显示已开启通道的项.
    """
    pbox = sub.box()
    pcol = pbox.column()
    pcol.use_property_split = True
    # 输出分辨率钳制与渲染采样数为常驻项(与具体通道无关)
    pcol.prop(state, "use_clamp_resolution")
    pcol.prop(state, "render_samples")
    if state.use_depth:
        # 深度拾取按钮必须排在 depth_range 属性**之后**且**同一行内**: 只有落在值列才能
        # 与上下数值列左右对齐.prop() 先调以建立行内分裂, 之后追加的按钮即落进值格;
        # 行内不要再设 use_property_split(分裂已由父列继承, 再设会另起一层).
        brow = pcol.row(align=True)
        brow.prop(state, "depth_range")
        draw_operator(brow, PickDepthRange.bl_idname, None, 'UV_SYNC_SELECT', text="")
        pcol.prop(state, "depth_curve")
    if state.use_normal:
        pcol.prop(state, "normal_convention")
    if state.use_segmentation:
        pcol.prop(state, "cryptomatte_source")
        pcol.prop(state, "crypto_slots")
        pcol.prop(state, "smooth_seg_edges")
    if state.use_edge:
        # 先选画什么线(预设), 再调多宽(系数); 末项为材质之间是否出笔画
        pcol.prop(state, "edge_preset")
        pcol.prop(state, "edge_width_scale")
        pcol.prop(state, "use_material_borders")
    if state.use_ao:
        pcol.prop(state, "ao_distance")


def _draw_pass_list(sub, state) -> None:
    """通道迷你列表(常驻): 右侧竖列为保存当前 / 保存全部 / 清除备份 / 删除

    通道图不进主列表与画廊(列表分离), 回看在面板内完成; 删除联动清理发送缓存对应通道.
    """
    sub.label(text="Pass List:", icon='IMAGE_DATA')
    list_row = sub.row(align=True)
    list_row.template_list("CH_UL_ai_images", "ch_ai_pass_images", state, "pass_images", state, "pass_images_active_index", rows=max(_PASS_ROWS_MIN, len(state.pass_images)))
    has_sel = 0 <= state.pass_images_active_index < len(state.pass_images)
    btn_col = list_row.column(align=False)
    save_one = btn_col.row(align=False)
    save_one.enabled = has_sel
    draw_operator(save_one, SaveImage.bl_idname, 'PASS', 'FILE_TICK', text="")
    save_all = btn_col.row(align=False)
    save_all.enabled = has_sel
    draw_operator(save_all, SaveAllImages.bl_idname, 'PASS', 'OUTPUT', text="")
    # 一键清除重新捕获时保留的 "_bak" 备份(无备份时按钮自身置灰)
    draw_operator(btn_col.row(align=False), ClearPassBackups.bl_idname, None, 'TRACKING_CLEAR_BACKWARDS', text="")
    del_btn = btn_col.row(align=False)
    del_btn.enabled = has_sel
    draw_operator(del_btn, DeleteImage.bl_idname, 'PASS', 'X', text="")


def _draw_capture_info(sub, state, scene, provider, prefs) -> None:
    """捕获输出标签: 像素尺寸 + 落盘体积估算 + 长边超阈值的提醒

    标签与实际渲染同口径(未开钳制即 Blender 输出分辨率乘百分比); 体积为按各通道落盘格式
    的估算值, 能提前暴露"通道图另作他用时的大体积"(超阈值只提醒不禁止).
    """
    _limit_count, limit_edge = resolve_ref_limits(provider, prefs)
    clamp_edge = limit_edge if state.use_clamp_resolution else 0
    cap_w, cap_h = resolve_capture_size(scene, clamp_edge)
    keys = [key for attr, key in _PASS_TOGGLES if getattr(state, attr)]
    estimate = estimate_capture_bytes((cap_w, cap_h), keys, state.crypto_slots)
    draw_greyed_row(sub, iface("Capture output: {} x {} ({})").format(cap_w, cap_h, _size_text(estimate)))
    if max(cap_w, cap_h) > WARN_EDGE_PX:
        draw_greyed_row(sub, iface("Long edge above {} px, the pass images will be large").format(WARN_EDGE_PX), icon='ERROR')


def _draw_passes_header_summary(header, state, scene, provider, prefs) -> None:
    """生成通道小节收起态摘要: 已捕获通道数 + 发送集过期标记(不展开即可判断能否直接生成)"""
    _count, limit_edge = resolve_ref_limits(provider, prefs)
    _send_names, _missing, stale = collect_send_passes(state, scene, limit_edge)
    note = header.row()
    note.enabled = False
    note.label(text=iface("Captured: {}").format(captured_pass_count()), icon='INFO')
    if stale:
        note.label(text=iface("previews may be outdated"), icon='ERROR')


def _draw_passes(layout, state, scene, provider, prefs) -> None:
    """生成通道小节(内联可折叠, 默认收起)

    与 Settings 同为内联可折叠小节而非 bl_parent_id 子面板: 后者位置由 Blender 决定,
    无法插进 draw 中段.本小节只放"捕获什么通道,怎么触发捕获"这两件同族的事.
    标题原文用 "Pass Generation" 而非 "Passes"(后者是系统词条, 只能改原文反译).
    """
    box = layout.box()
    header = draw_fold_header(box, state, "use_show_passes", "Pass Generation")
    if not state.use_show_passes:
        _draw_passes_header_summary(header, state, scene, provider, prefs)
        return
    sub = box.column()
    _draw_pass_preset_row(sub, get_prefs())
    _draw_pass_grid(sub, state)
    sub.separator(type='LINE')
    _draw_pass_params(sub, state)
    sub.separator(type='LINE')
    _draw_pass_list(sub, state)
    _draw_capture_info(sub, state, scene, provider, prefs)
    # 生成通道: 本地渲染所选通道并在图像编辑器预览(不调用 AI 服务, 不产生费用)
    draw_operator(sub, CaptureViewRefs.bl_idname, None, 'RENDERLAYERS')


# --------------------------------------------------------------------------- 发送通道段


def _draw_send_content(col, state, scene, provider, prefs) -> None:
    """发送通道段: 发送开关两行 + 预算摘要与各类警示行

    摘要与生成操作器同口径(勾选发送但缓存与预览图都缺失的通道会阻断, 这里提前点名);
    超限截断与风格图死引用同理提前可见.
    """
    col.use_property_split = False
    row_one = col.row(align=True)
    row_one.prop(state, "use_send_combined", toggle=True)
    row_one.prop(state, "use_send_depth", toggle=True)
    row_one.prop(state, "use_send_normal", toggle=True)
    row_one.prop(state, "use_send_segmentation", toggle=True)
    row_two = col.row(align=True)
    row_two.prop(state, "use_send_edge", toggle=True)
    row_two.prop(state, "use_send_diffuse", toggle=True)
    row_two.prop(state, "use_send_ao", toggle=True)

    _limit_count, _limit_edge = resolve_ref_limits(provider, prefs)
    send_names, missing, _stale = collect_send_passes(state, scene, _limit_edge)
    style_count = len(collect_style_images(state))
    total = len(send_names) + style_count
    info = col.column(align=True)
    info.enabled = False
    if _limit_count > 0:
        draw_greyed_row(info, iface("Send {} / {} reference images").format(total, _limit_count))
    else:
        draw_greyed_row(info, iface("Send {} reference images").format(total))
    if 0 < _limit_count < total:
        # 与生成同口径: 风格图占保底名额, 通道截断到"上限 - 风格张数"(被占满时点名)
        room = _limit_count - style_count
        if room < 1:
            draw_greyed_row(info, iface("The {} style images fill the budget, " "no room for pass images").format(style_count), icon='ERROR')
        else:
            dropped = ", ".join(_pass_title(name) for name in send_names[room:])
            draw_greyed_row(info, iface("Exceeds the provider limit, will drop: {}").format(dropped), icon='ERROR')
    if missing:
        draw_greyed_row(info, iface("Not captured yet: {}").format(", ".join(_pass_title(name) for name in missing)), icon='ERROR')
    # 风格图存在性: 引用悬空/像素未加载的条目不参与发送, 点名提醒清理;
    # 开关已激活但列表为空同样提醒(否则"激活了却没有风格图被发送"无从察觉)
    if state.use_send_style:
        invalid = count_unavailable_style_refs(state)
        if invalid:
            draw_greyed_row(info, iface("{} style reference(s) unavailable, " "the image is missing").format(invalid), icon='ERROR')
        elif not state.style_images:
            draw_greyed_row(info, iface("Style references enabled but the list is empty"), icon='ERROR')


def _draw_settings_content(sub, state, sstate, prefs, provider) -> None:
    """Settings 段的内容(输出分辨率 / 随机种 / 张数 / 多变体 / 风格参考图开关)"""
    # 尺寸约束取编辑模型(与生成操作器同源): 面板"实际输出"必须与真实下发值同口径
    model = resolve_edit_model(sstate, prefs)
    # 效果图侧宽高恒随档位 CUSTOM 可编辑, 锁定按钮恒可用(与纹理面板仅这两个条件不同)
    draw_output_settings(sub, state, provider, model, 'RENDER', editable=state.size_preset == 'CUSTOM', lock_enabled=True)
    sub.prop(state, "use_send_style")
    if state.use_send_style:
        draw_reference_list(sub, state, 'RENDER')


def _draw_settings_section(layout, state, sstate, prefs, provider, scene) -> None:
    """设置与发送通道合并小节(单折叠头 Settings, 默认收起, 整体一个 box)

    展开先画输出侧设置, 再以"发送通道:"标签领起发送开关与预算摘要; 单一折叠头统辖两段,
    收起即整段隐藏(收起态在标题行右侧给一行发送张数/预算摘要).
    provider 为面板生效服务商, 由调用方解析一次后传入, 与生成操作器同源.
    """
    box = layout.box()
    header = draw_fold_header(box, state, "use_show_settings", "Settings")
    if not state.use_show_settings:
        limit_count, limit_edge = resolve_ref_limits(provider, prefs)
        send_names, _missing, _stale = collect_send_passes(state, scene, limit_edge)
        total = len(send_names) + len(collect_style_images(state))
        note = header.row()
        note.enabled = False
        note.label(text=(iface("Send {} / {} reference images").format(total, limit_count) if limit_count > 0 else iface("Send {} reference images").format(total)), icon='INFO')
        return
    sub = box.column()
    sub.use_property_split = True
    _draw_settings_content(sub, state, sstate, prefs, provider)
    box.separator(type='LINE')
    col = box.column(align=True)
    col.label(text="Send Passes:", icon='RENDERLAYERS')
    send_col = box.column()
    send_col.use_property_split = False
    _draw_send_content(send_col, state, scene, provider, prefs)


# --------------------------------------------------------------------------- 提示词摘要


def _draw_token_summary(col, state, scene, provider, prefs, sstate) -> None:
    """提示词 token 摘要(置灰右对齐): 与发送组装同口径(resolve_render_request 预览档)

    超硬预算(百炼, 服务端静默截断)与超软建议(方舟, 模型可能忽略细节)措辞区分;
    描述为空时不显示; 组装失败(预算名额不足等)同样不显示.
    """
    prompt_text = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.prompt)
    if not prompt_text:
        return
    _provider, _base_url, _api_key, limits = _resolve_service(sstate, prefs)
    err, _notices, _names, _styles, full_prompt = resolve_render_request(state, scene, prompt_text, provider, limits[0], limits[1], require_captured=False)
    if err is not None:
        return
    budget, hard = prompt_token_budget(provider)
    tokens = estimate_prompt_tokens(full_prompt)
    if budget > 0 and tokens > budget:
        if hard:
            draw_greyed_row(col, iface("Prompt: about {} tokens / {} budget, " "it will be truncated").format(tokens, budget), icon='ERROR')
        else:
            draw_greyed_row(col, iface("Prompt: about {} tokens / {} suggestion, " "the model may miss details").format(tokens, budget), icon='ERROR')
    elif budget > 0:
        draw_greyed_row(col, iface("Prompt: about {} tokens / {} budget").format(tokens, budget))
    else:
        draw_greyed_row(col, iface("Prompt: about {} tokens").format(tokens))


# --------------------------------------------------------------------------- 面板


@reg_order(3)
class AiRenderPanel(Panel):
    """AI 相机效果图面板"""

    # "Render" 会命中系统词条显示成"渲染", 故用 "Render Generator" 走插件词典出"效果图生成器"
    bl_label = "Render Generator"
    bl_idname = "VIEW3D_PT_ch_ai_render"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # 图像助手选项卡(与 AI 纹理生成器面板共用)
    bl_category = "Image Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_render_state
        prefs = get_prefs()
        layout = self.layout
        scene = context.scene

        # 效果图主列表 + 预览区(常驻, 标题行右侧为保存按钮)
        draw_image_list_row(layout, state, "images", "images_active_index", "ch_ai_render_images", 'RENDER')
        draw_preview_box(layout, state, iface("No render generated yet"), label_tail=lambda tail, s: draw_save_tail(tail, s, 'RENDER'))

        # 生效服务商只解析一次: 通道小节的钳制上限,Settings 的实际输出与负向提示行的
        # 显隐都必须与生成操作器同源
        sstate = wm.ch_ai_render_service
        provider = effective_provider(sstate, prefs, 'image')

        _draw_passes(layout, state, scene, provider, prefs)
        _draw_settings_section(layout, state, sstate, prefs, provider, scene)

        # ---- 描述输入与操作行 ----
        layout.separator(type='LINE')
        col = layout.column(align=False)
        prompt_row = col.row(align=True)
        prompt_row.prop(state, "prompt", text="Prompt")
        draw_operator(prompt_row, ClearPrompt.bl_idname, 'RENDER', 'CANCEL_LARGE', text="")
        draw_negative_row(col, state, provider, 'RENDER')
        draw_long_desc_hint(col, AI_RENDER_PROMPT_TEXT_NAME)
        _draw_token_summary(col, state, scene, provider, prefs, sstate)
        row = col.row(align=True)
        draw_operator(row, EditPrompt.bl_idname, 'RENDER', 'TEXT')
        row.separator(factor=0.5)
        draw_operator(row, OptimizePrompt.bl_idname, 'RENDER', 'SHADERFX')
        row.separator(factor=0.5)
        draw_operator(row, PreviewRenderPrompt.bl_idname, None, 'WORDWRAP_ON')
        # 操作行: 修改在左(高亮效果图产物为参考图), 生成在右
        # (捕获按钮"生成通道"已移入上方同名小节)
        row = col.row(align=True)
        draw_operator(row, ModifyRender.bl_idname, None, 'GREASEPENCIL')
        row.separator(factor=0.5)
        draw_operator(row, GenerateRender.bl_idname, None, 'KEY_RETURN')

        # ---- 末尾两段: 错误摘要 / 等待进度 ----
        # (生成与通道捕获共用 render 等待标志)
        draw_error_box(layout, wm, 'RENDER')
        draw_wait_box(layout, wm.ch_ai_state, 'render')
