# ch_ai_assistant 完全重构方案（去重 / 简化 / 可读性）

> ## ✅ 已实施（2026-10-15，`ch_ai_assistant` 未发布段）
>
> 本方案已**全部实施完毕**（S1–S7），实施记录见根 `CHANGELOG.md` `[未发布]` 段与
> `.agents/log/2026-10-15.md`。本文自此转为**实施记录**：下文「计划/预估」类表述保留原样
> 以供考古，**实际结果与偏差**见文末「§11 实施结果与偏差」。
> **按 AGENTS「文档同步口径」：本文隔一版移入 `.agents/log/archive/`。**
>
> ---

> 状态（原始）：**计划中**。基线：`ch_ai_assistant` 1.1.1，`gate.py --quick` 7/7 PASS。
>
> **硬约束（用户指令）**：不引入任何新的用户可见功能。等价重构，行为逐位不变——不改 UI 元素与
> 顺序、不改默认值、不改英文文案（词典键）、不改提示词正文、不改命名规则、不改持久化格式。
>
> **必须符合工作区开发文档规范**：`AGENTS.md`（硬红线 / 16 条框架约定 / 收尾落盘 /
> 文档同步口径）、`.agents/skills/blender-addon-code-style`（§5/§8/§10/§11/§13/§15）、
> `.agents/skills/code-review`（新会话 + 两轮制）、`.agents/skills/addon-feature-porting`
> （描述债 / 删除边界 / shim 下线条件）。方案对规范的符合性见 §5「规范义务清单」。
>
> 本文件实施后须按 AGENTS「文档同步口径」改写为事实记录，并加「已实施于 X.Y.Z，仅考古」横幅；
> 隔一版移 `log/archive/`。

---

## 0. 一句话

`ch_ai_assistant` 已达 1.1.1 且功能定稿，但 12473 行（非空 10781）里有**成体系的重复**与
**成体系的复杂**：AST 扫描出 1783 个去重字符串字面量中 **172 个出现 ≥3 次**；
**71 处「守卫 + 报告 + 取消」样板散布在 46 个函数**；`target` 分派在 **3 个文件里形成
6 条 if/elif 梯子**；同一个**7 键通道域在 5 处各自手写 dict 字面量**（加一个通道要改 5 处）；
**13 行的 `PassCaptureSession(...)` 构造逐字重复两次**；`render_passes.py` 单文件（1546 行）
扛「临时目录 + 分辨率 + 视图层 + 节点树 + 像素编解码 + 蜡笔 + 缓存 + 会话 + 入口」九件事。

本方案把它们收敛为**少量单一出口 + 清晰的文件边界 + 加载期契约断言**，不改任何外部行为。

---

## 1. 基线与范围

### 1.1 规模盘点（**总行数**口径；括注非空行数）

> 口径：总行数 = 物理行数（CRLF 计数）。**数行一律用 `io.open`**——PowerShell 的
> `Measure-Object -Line` 静默跳过空行（实测 `render_passes.py` 报 1358、实际 1546），
> 首版曾因此把总数误报为 10767。

| 文件 | 总行 | 非空 | 备注 |
| --- | --- | --- | --- |
| `utils/render_passes.py` | 1546 | 1358 | 单文件九职责，**最大热点** |
| `operators/ai_render.py` | 1153 | 991 | 单文件 12 个算子 + 模块级发送状态 |
| `props.py` | 1056 | 962 | 两状态组字段部分同构（C6，判不做） |
| `operators/ai_generate.py` | 757 | 641 | |
| `i18n/dictionary.py` | 655 | 653 | 词条（不重构） |
| `handlers.py` | 598 | 486 | |
| `utils/provider_registry.py` | 559 | 477 | 已注册表化，**不动** |
| `operators/ai_texture.py` | 536 | 473 | |
| `preference.py` | 494 | 450 | |
| `operators/ai_chat.py` | 494 | 414 | |
| `utils/ai_client.py` | 451 | 376 | |
| `operators/script_actions.py` | 425 | 358 | |
| `ui/panels/ai_render.py` | 391 | 338 | |
| 其余 29 个文件 | 2915 | 1998 | |
| **合计（42 个 .py）** | **12473** | **10781** | |

### 1.2 门禁基线与档位

`python .agents/tools/gate.py --quick` → **7/7 PASS**（语法 / ruff+pyflakes / review_check /
static_audit / scan_invoke_execute / icon_check / E2E 层1）。

> **档位规则（本方案特别声明）**：**凡新增 / 移动 / 拆分文件（尤其新增目录）必须跑全量档**。
> 理由是 `verify_blender_load`、E2E 层2 utils、E2E 层3 ops 三项**不在 `--quick` 内**，
> 与本方案是否改 RNA 无关——新目录缺 `__init__.py` 会让 Operator **静默不注册**（见 §5 P0-4），
> 只有 `verify_blender_load` 能抓。AGENTS 约定 15 只讲了「改 RNA」这一条触发条件，
> 此处是**另一条独立触发**。`--quick` 仅适用于 S7 纯文档批。
>
> 注：`--quick` 为 7 项；全量档为 10 项（`MEMORY.md` 记的「10 项」指全量档），二者不冲突。

### 1.3 明确「不动」的清单（防误伤）

| 项 | 理由 |
| --- | --- |
| 全部 RNA 属性声明（名称 / default / min / max / items / description / update） | 改 description 会连动词典；改 default 语义即改行为 |
| `utils/provider_registry.py` 的 dataclass 字段与 `*_items` 字面量 | i18n 提取器硬约束（必须保持 List 字面量形态） |
| `items.py` / `preference.py` 的 `*_items` List 字面量形态 | 同上 |
| `i18n/dictionary.py` 词条原文 | 词条键必须与源码字符串逐字符一致 |
| `utils/prompts.py` 提示词正文 | 改措辞即改生成质量（契约自检已锁锚点） |
| `_pass_title` / `_PASS_TITLES` 的英文标题文案 | 是**数据块名**（`AI Ref: Depth`），改名会让旧 blend 的预览图失联 |
| `last_error_*` / `status_*` / `wait_*` / `cancel_*` 动态属性名前缀协议 | 改枚举/映射会引入间接层，收益为负（本轮实测判不做） |
| `{'CANCELLED'}` / `'WARNING'` / `'INFO'` / `'FINISHED'` / `'REGISTER'` 等 Blender API 枚举 | 非业务重复，抽常量反而降低可读性 |

---

## 2. 重复代码清单（逐条取证；数字均为 AST 实测）

### D1 · 「守卫 + 报告 + 取消」样板与同族操作器前导

**总量（AST 实测，口径：`if` 体内恰有 `report(...)` 与 `return {'CANCELLED'}`）**：
**71 处，散布在 46 个函数**。最长梯子：

| 守卫数 | 位置 |
| --- | --- |
| **5** | `operators/ai_render.py:1085` `ModifyRender.invoke` |
| **5** | `operators/ai_render.py:459` `CaptureViewRefs.invoke` |
| **4** | `operators/ai_texture.py:256` `ModifyImage.invoke` |
| **4** | `operators/ai_render.py:634` `GenerateRender.invoke` |
| 3 | `operators/ai_render.py:409` `CaptureViewRefs.execute`、`operators/ai_generate.py:382` `_handle_modal` |

**重复文案（≥2 处，非 D1 已列）**：

| 文案 | 次数 | 位置 |
| --- | --- | --- |
| `"No message selected"` | **5** | `ai_chat.py:186,208,351,377,408` |
| `"No passes captured, enable at least one pass"` | **3** | `ai_render.py:452,501,570` |
| `"Type a message first"` / `"An AI request is already running…"` / `"AI request cancelled…"` / `"AI request finished without a result"` / `"Type what script you need…"` / `"The scene has no active camera"` / `"Describe the look…"` / `"No reference image selected"` / `"No pass preset selected"` / `"Describe the change…"` / `"Describe the texture…"` | 各 2 | 见 `grep` |

**已确认的核心重复族**（AST 精确计数）：

| 文案 | 次数 |
| --- | --- |
| `"No text editor area open, switch an area to the text editor first"` | **7**（`ai_chat:331,357`、`ai_generate:624,717,754`、`ai_render:932`、`ai_texture:363`） |
| `"Script no longer exists"` | 5（`script_actions:135,170,184,271,344`） |
| `"No image selected"` | 4（`ai_render:1093`、`ai_texture:263,453`、`list_ops:100`） |
| `"Image no longer exists"` | 4（`ai_render:1097`、`ai_texture:267,467`、`list_ops:104`） |
| `"No image editor area open, switch an area to the image editor to see the result"` | 3（`ai_render:1150`、`ai_texture:326`、`image_common:322`） |

**结构化重复（比字符串更值得处理）**：

1. **「取高亮图像 → 存在性守卫 → 校验服务 → 编码 PNG → 发请求」前导**：
   `ai_texture.py:258-276`（`ModifyImage.invoke`）与 `ai_render.py:1088-1110`（`ModifyRender.invoke`）。
   **图像存在性守卫三连在两侧连续出现且逐字一致**（`ai_render:1092-1102` 与
   `ai_texture:262-268`）。
   > **精确界定（避免过度声称）**：二者**没有任何 ≥4 行的公共连续块**（difflib 实测），
   > 共享形态是**逐句守卫模式**而非连续代码块；中段有 **6 处真实语义分歧**：
   > ① 提示词优先级**相反**（纹理 `resolve_prompt` 长文块优先 / 效果图 `_resolve_modify_prompt`
   > 单行框优先）；② 效果图多一道 `startswith(AI_RENDER_PREFIX)` 前缀守卫；③ 模型解析不同
   > （`resolve_texture_model` / `resolve_edit_model`）；④ 尺寸口径不同（纹理按面板宽高 /
   > 效果图取源图尺寸并在 0 时回落面板）；⑤ 纹理快照 `_texture_mode`/`_seamless`/`_namer`
   > 并组装 `build_texture_prompt`，效果图全无；⑥ 快照字段不同（`_stem` vs `_prompt`）。
   > 故 S2 正确表述是**「共享前导守卫、中段各自保留」**。

2. **「逐张落地产物」响应段**：`ai_texture.py:200-226` 与 `ai_render.py:704-725` 共享三步
   （保存目录写盘 / `activate_image(top=True)` / `maybe_auto_name_image`）。
   > **第 4 步不共享**：纹理在循环内 `report("Texture/Image '{}' created")`，
   > **效果图循环内不 report**；另纹理载入前多一段可选 `make_seamless`、两者命名规则不同。
   > 共享件必须接受**逐张 report 回调**与**载入前字节变换钩子**两个参数。

3. **聚焦失败提示**：`if focused == 0: self.report({'INFO'}, "No … editor area open…")`
   ——图像侧 3 处 + 文本侧 7 处各自内联。

**处置**：`operators/image_common.py` 增设
- `image_existence_guard(op, state, collection, index_name, require_prefix=None) -> Image | None`
  （合并「No image selected」/「Image no longer exists」/「Only generated renders…」三连，
  `require_prefix` 供效果图侧可选）
- `land_generated_images(op, context, scope, results, name_factory, prefix, *,
  transform=None, report_each=None) -> set`
- `focus_image_or_hint(op, context, name) -> int` / `focus_text_or_hint(op, context, text) -> int`
- `require(op, condition, message, level='WARNING') -> bool` 简化最长的两条梯子

**注意**：所有 `report` 文案必须**保持英文原句逐字符不变**（词典键），故出口内部引用同一
字符串常量，常量值即现状原文。**不得**改写任何文案——否则 i18n 词典失配。

### D2 · `_bak` 备份环两份

**证据**：`image_common.prune_image_backups:208-228`（12 行代码）与
`script_actions._prune_script_backups:50-71`（12 行代码）。

> **精确界定**：AST 去 docstring 后逐行比对，**行相同率 50%**；存在一个 **6 行公共块**
> （`excess = len(backups) - limit` → `if excess <= 0: return` → `_suffix_num` 定义 →
> `sorted(...)[:excess]` 循环）。**全部差异恰好落在 4 个类别内**：
> ① 遍历集合（`bpy.data.images` vs `bpy.data.texts`）；② 上限来源
> （`image_backup_limit` vs `revise_backup_limit`）；③ report 文案；④ 删除 API。
> 首版称「差异仅在集合 / 文案 / 删除 API 三项」——**漏列第 ② 项**；本次补齐。
> 结论不变：算法骨架同构、差异可参数化，**合并成立**。

**处置**：抽 `utils/` 新模块（**返回元组，遵守 §10 强制约定**）：
```python
def prune_backups(collection, base: str, keep_name: str, limit: int
                  ) -> tuple[list[str], str | None]:
    """返回 (被删名字列表, 错误信息)。失败时错误信息非 None。"""
```
> **【规范订正】** 首版设计为 `-> list[str]`，**违反** `blender-addon-code-style` §10
> 「utils 内禁止 `self`/`report()`；**算法失败统一返回 `(结果, 错误信息)` 元组**
> （成功时错误信息 `None`）」。删除 API 有真实失败面（数据块被占用等），裸列表无从表达。
> 且 `code-review` 技能已记录先例：「把规约强制的 `(结果, 错误信息)` 元组返回误判为过度设计」。
> 两个调用方解包后各自 report（文案与 scope 不同）。

### D3 · `target` 分派梯子（6 条，跨 3 个文件）

**AST 实测**：

| 位置 | 臂数 |
| --- | --- |
| `handlers.py:108` `move_list_item` | 3（SCRIPT/TEXTURE/RENDER）+ 嵌套 2 |
| `operators/script_actions.py:377` `ClearError.execute` | 3（TEXTURE/RENDER/CHAT）+ 嵌套 2 |
| `operators/ai_generate.py:505` `ClearPrompt.execute` | 2（TEXTURE/RENDER）+ 2（SCRIPT/TEXTURE） |

> **首版低估**：只说「`handlers.move_list_item` 的 if/elif 链又一次重复」，实际
> **共 6 条梯子跨 3 个文件、dispatch 同一个 `target` 变量**。`script_actions` 与
> `ai_generate` 的两组同族梯子首版完全未提。

**处置（分两步，避免过度设计）**：
- **R3a（低风险）**：`handlers.move_list_item` 内部 if/elif 等价改写为模块内私有表。
- **R3b（中风险，可选）**：`script_actions.ClearError.execute` 与
  `ai_generate.ClearPrompt.execute` 的「`(状态组, 字段前缀)`」分派改写为查表。
  **注意**：`ClearError` 的 SCRIPT 分支走 `_clear_error`（三字段），其余走
  `last_error_<scope>`/`_detail` 两字段——**不是同一形状**，需按「字段名列表」参数化，
  不可强行统一为单字段。

> **【首版订正】** 首版称「改查 `image_common` 的同一张表」——**实测不可行**：
> `image_common` 两张表（`REF_TARGET_STATES:35` / `_IMAGE_LIST_STATES:39`）
> **都没有 `SCRIPT` 行**、**没有 `kind`（'TEXT'/'IMAGE'）**、**没有 getter**、
> **没有名字收集器**；且 `REF_TARGET_STATES` 指向 `ref_images`/`style_images`，
> 与 `move_list_item` 要的 `images` **不是同一个集合**（两者都是 `TEXTURE`/`RENDER` 键，
> 指向不同集合——这是本项最大陷阱）。故**不去动 `image_common` 的表**，
> 只在各文件内部收敛。

### D4 · 尺寸联动护栏两份（`props.py`）——**默认不做**

**证据**：`_on_tex_*`（`props.py:337-409`）与 `_on_render_*`（`props.py:479-545`）。
机器实测两个函数对相似度：纹理宽/高联动 **87.5%**、效果图宽/高联动 **83.3%**、
纹理档位/模式 **83.3%**。

> **分支结构本身不同**（首版称「同构」不准确）：
> ① 护栏进入方式相反——`_on_tex_lock_update` **有条件**进入、两分支各自包护栏；
> `_on_render_lock_update` **无条件**进入、在护栏内分派。
> ② 解锁时行为相反——纹理宽/高回调**提前 return**（不改档位）；
> 效果图**恒先**置 `size_preset='CUSTOM'` 再按锁定条件同步。
> ③ 比率来源不同（纹理取当前宽高 / 效果图取 `camera_ratio(context)`）。
> ④ 夹取常量写法不同（字面量 `256/4096` vs `_RENDER_DIM_MIN/MAX`，值相同）。
> ⑤ `_apply_render_size_preset` 额外调 `resolve_output_size`。

**处置**：**默认不做**（`props.py` 是作者手工调校区）。若作者要求收敛，**只收最无争议的一段**：
宽/高回调的「`round(other / ratio)` + 夹取」表达式（4 处 → 1 个辅助函数），
护栏结构与档位副作用一律不动。收益约 −10 行，风险接近零。

### D5 · 7 键通道域在 5 处各自手写（**新发现，首版漏 2 处**）

**AST 实测**：字典字面量的键集**恰好等于** 7 个通道键的，出现在 **5 处**：

| 位置 | 用途 |
| --- | --- |
| `operators/ai_render.py:113` | `_PASS_TITLES`（通道键 → 预览标题／数据块名） |
| `utils/prompts.py:182` | `PASS_ROLES`（通道键 → 提示词角色说明） |
| `utils/prompts.py:200` | `PASS_ROLES_COMPACT`（精简档角色说明） |
| `utils/render_passes.py:135` | `_PASS_FORMATS`（通道键 → 落盘规格） |
| `utils/render_passes.py:1520` | `wanted` 字典字面量（本次要哪些通道） |

另 `EDGE_PRESETS`（`render_passes.py:93,99,105,111`）有 4 个 7 键 dict，属同类。

> **首版判「不做」并漏 `prompts.py` 两处**。复核后改判：**统一表仍不做**（各表性质不同：
> 显示名 / 提示词 / 落盘规格 / 布尔开关），但**问题不是"表该不该合一"，而是"同一个键域在
> 5 个模块各自手写、加删通道要改 5 处"**——`PASS_ORDER` 已是**顺序**的单一来源，
> **键集却不是**。故新增一条**零行为改动的加载期断言**锁住键集一致（仿
> `provider_registry._check_registry` 先例），防漏改。

**处置**：在 `render_passes.py` 加 `_check_pass_domain()`（模块 import 时执行一次）：
断言 `_PASS_TITLES`（经延迟导入或改由 `PASS_ORDER` 派生）、`PASS_ROLES`、
`PASS_ROLES_COMPACT`、`_PASS_FORMATS` 的键集均等于 `set(PASS_ORDER)`；不一致即
`raise AssertionError`（与 `prompts._check_contract` 同款先例）。
> **实现细节**：`ai_render._PASS_TITLES` 与 `prompts.PASS_ROLES*` 属不同模块，断言需在各
> 自模块内做（避免 utils 反向依赖 operators——AGENTS §12 层级红线）。落点：
> `prompts.py` 内断言 `PASS_ROLES`/`PASS_ROLES_COMPACT` 键集相等；
> `render_passes.py` 内断言 `_PASS_FORMATS` 覆盖 `PASS_ORDER`；
> `ai_render.py` 内断言 `_PASS_TITLES` 覆盖 `PASS_ORDER`。

### D6 · 薄封装链

**证据**：`ai_render._resolve_service:143`、`_clamp_edge:154`、`_style_image_bytes:277-282`、
`ai_texture.resolve_texture_model:93-95`、`image_common.resolve_edit_model:81-89`、
`ai_generate.resolve_text_service:94-107`、`props._thinking_items_for:224-226`。

**处置**：
- `_style_image_bytes:277-282`（纯转发 + 1 个调用点）→ **可内联**（理由：单调用点 + 纯转发；
  注：它带 3 行 docstring，首版称「无注释」不实）。
- `props._thinking_items_for:224-226`（`list(thinking_items_for(p))`，2 个调用点
  `props.py:219` / `:232`）→ **判不做**（两处都在 RNA 回调链上，内联反而摊平语义层次）。
- **其余薄封装判不做**——2026-10-12 全量审查已把「兜底链单口」定为
  `resolve_panel_image_model`，这些是刻意的薄封装。

**新发现 — `build_thinking_extras` 双份定义**：
`utils/ai_client.py:87` 与 `utils/provider_registry.py:522` **同名同签名**，且
`ai_client` 那份是**纯转发**（`return _registry_thinking_extras(provider, thinking)`）。
→ **删除 `ai_client.py` 那一份**，调用点直接导入注册表版本（零风险；
`ai_client` 已 `from .provider_registry import build_thinking_extras as _registry_thinking_extras`，
改为直接 re-export 即可）。

---

## 3. 复杂逻辑清单（逐条取证）

### C1 · `render_passes.py` 单文件九职责（**1546 行**）——**最大项**

按分节注释（`^# ----…----`）与定义锚点实测：

| 段 | 行范围 | 职责 |
| --- | --- | --- |
| 模块 docstring + 导入 | 1-61 | 含 48 行机制说明 docstring |
| 常量区 | 64-208 | 采样/钳制/线稿预设/深度拾取/通道格式/组与视图层 |
| 临时目录 | 274-326 | `_tmp_root` / `_drop_path` / `_sweep_tmp_root` / `_new_tmp_dir` |
| 尺寸与体积 | 328-403 | `_render_size` / `_clamped_percentage` / `_sane_clamp` / `resolve_capture_size` / `estimate_capture_bytes` |
| 临时场景 | 406-486 | `_link_user_scene` / `_copy_render_common` / `_copy_color_management` / `_enable_passes` |
| 视图层 | 488-533 | `_ensure_view_layers` / `_move_to_lineart_collection` |
| 合成节点与渲染 | 535-666 | `_add_output_node` / `_build_capture_group` / `_drop_node_group` / `_render_frame` / `_pass_file` |
| 像素编解码 | 668-890 | `_read_bytes` / `_read_pass_pixels` / `_read_crypto_slot` / `_quantize` / `_encode_png` / `_gray_to_rgb` / `_depth_gray` / `_normal_bytes` / `_edge_bytes` / `_decode_raw` / `_decode_pass` / `_collect_frame` |
| 蜡笔线稿 | 892-978 | `_add_edge_gp` / `_remove_gp`（976/978 为遗留空分节注释，见下） |
| 深度拾取 | 980-1038 | `sample_visible_depth` |
| 会话 | 1043-1331 | `PassCaptureSession` |
| 增量缓存 | 1333-1443 | `_PASS_RAW_CACHE` / `group_render_key` / `lookup_group_cache` / `store_group_cache` / `clear_raw_cache` |
| 名字与解码复用 | 1446-1489 | `_segmentation_names` / `_decode_collected` |
| 主入口 | 1492-1546 | `capture_camera_passes` |

**发现的两处遗留冗余**：
- `render_passes.py:976` `# ---- 语义分割覆盖 ----` 与 `:978` `# ---- 深度拾取 ----`
  之间**夹着一个空分节注释**——「语义分割覆盖」一节内容已在 D9 清理中删除，只剩标题行。
  （**删除须走 §5 P1-6 的确认流程**，不可直接删。）
- 模块 docstring 第 4-15 行详述渲染组机制——**拆分后必须迁移**，见 §5 P1-7（描述债）。

**处置（拆为同包私有子模块；`utils/__init__.py` 公共 API 不变）**：

```text
utils/pass_capture/
├── __init__.py        # 公共 API 唯一声明点（__all__ + 显式具名导入；8 个公共名）
├── _constants.py      # 常量（逐项判定见 §5 P2-3）
├── _tmpdir.py         # _tmp_root / _drop_path / _sweep_tmp_root / _new_tmp_dir
├── _size.py           # 尺寸与体积估算
├── _scene.py          # 临时场景、视图层、节点树、渲染调用
├── _pixels.py         # 读回 / 编码 / 三通道映射
├── _lineart.py        # 蜡笔添加与回收
├── _cache.py          # 按组增量缓存
├── _session.py        # PassCaptureSession
└── _depth_pick.py     # sample_visible_depth
```

> **公共名是 8 个，不是 6 个**（AST 实测 `utils/__init__.py:151-160`）：
> `PASS_ORDER`、`WARN_EDGE_PX`、`PassCaptureSession`、`capture_camera_passes`、
> `clear_raw_cache`、`estimate_capture_bytes`、`resolve_capture_size`、`sample_visible_depth`。

**风险与缓解**：这是最大改动面，且 1.1.1 通道管线刚经 3 批实测。缓解：
① 纯移动，不重写任何函数体；② **兼容层必须存活**（见下方 P0 警告）；③ 逐批跑全量档 +
`.agents/tools/verify/test_capture_passes.py`；④ 作者热重载实测。

> ### ⚠️ P0 警告：兼容再导出层会**静默失效**验证脚本
>
> 首版称「保留 `utils/render_passes.py` 为兼容层，使全部现有导入路径零改动」。
> **实测两处反证**：
>
> 1. **插件内**其实**没有任何**模块直接导入 `utils.render_passes`——全部走
>    `from ..utils import (...)`（`utils/__init__.py:151` 是唯一导入点）。故 shim 在插件内
>    保的是一个**没人用的路径**。
> 2. **插件外有真实消费者**：`.agents/tools/verify/test_capture_passes.py:51`
>    以**模块串** `_resolve("utils.render_passes")` 导入，并访问 **9 个私有名/常量**：
>    `_render_frame:176,197`、`_drop_path:177,198`、`_PASS_FORMATS:217`、`_EXTENSIONS:220`、
>    `_read_pass_pixels:545`、`_tmp_root:540,633`、`_sweep_tmp_root:584`、
>    `CRYPTO_SLOT_KEYS:215`、`CRYPTO_SOURCE_DEFAULT:279`；`test_capture_gui.py:54-56` 同款。
>    「仅再导出公共名」的 shim **不带这些私有名** → 首个属性访问即 `AttributeError`。
>
> 3. **更隐蔽的是"静默假通过"**（已用最小可执行模型实证）：该脚本**monkeypatch**
>    `rp._render_frame` 来**统计渲染次数**（`:176,197`）。拆分后调用点在 `_session.py`，
>    其 `from ._scene import _render_frame` 绑定的是**自己的全局副本**——
>    patch shim 属性**根本拦不到**。结果是**脚本照常跑完并打印 PASS，而渲染计数断言
>    等于没测**。方案 §5 恰把该脚本列为 S5 唯一后台行为验证 → **等于自毁验证手段**。
>
> **处置（二选一，推荐后者）**：
> - (a) shim **逐名转发**上述 9 个私有名/常量 + 8 个公共名（为外部脚本永久背私有名债务）；
> - (b) **同步改写这两个 verify 脚本**，把 `_resolve("utils.render_passes")` 的 monkeypatch
>   目标改到**实际定义处**（拆分后为 `utils.pass_capture._scene` / `_session`），
>   并显式标注「拆分后 patch 目标已迁移」。
>
> 二者都必须**先修改 verify 脚本并确认其在新布局下仍能抓住一个真实缺陷**（例如临时注入
> 一次多余渲染，确认脚本报 FAIL），否则无法证明它还有效。**shim 的删除条件**（AGENTS /
> porting 技能要求明确下线条件）：拆分后经**一轮作者热重载实测 + 全量门禁通过**即删除，
> 不留长期死代码。

### C2 · `ai_render.py` 单文件 12 个算子（1153 行）

**实测类与行号**（全部核对无误）：
`CaptureViewRefs:362-578`、`PickDepthRange:581-610`、`GenerateRender:613-725`、
`LoadStyleImage:743-782`、`ClearPassBackups:785-810`、`ClearStyleDescription:813-842`、
`RemoveStyleImage:845-877`、`PreviewRenderPrompt:880-936`、`ApplyPassPreset:952-978`、
`SavePassPreset:981-1012`、`DeletePassPreset:1015-1041`、`ModifyRender:1059-1153`。

**处置（**扁平方案**，作者 2026-10-15 定案）**：**不建 `operators/render/` 子包**，在
`operators/` 下平铺 3 个新文件：

```text
operators/
├── ai_render.py       # 留守 5 个核心算子：GenerateRender / ModifyRender /
│                      # CaptureViewRefs / PickDepthRange / PreviewRenderPrompt
├── pass_presets.py    # ApplyPassPreset / SavePassPreset / DeletePassPreset
│                      # + _PRESET_TOGGLES + _sanitize_preset_name
├── style_refs.py      # LoadStyleImage / RemoveStyleImage / ClearStyleDescription + _REF_TARGET_ITEMS
└── render_send.py     # 发送集组装与缓存状态：_PASS_TITLES / _pass_title / clear_pass_cache /
                       # clear_pass_cache_ref / pass_available / captured_pass_count / _pass_ref_image /
                       # _pass_send_bytes / capture_fingerprint / collect_send_passes /
                       # collect_style_images / count_unavailable_style_refs / resolve_render_request
                       # + 模块级 _PASS_CAPTURE_CACHE / _CAPTURE_FINGERPRINT
```

> **为何扁平优于子包（复核新增结论）**：
> | | 子包 `operators/render/` | **扁平（采纳）** |
> | --- | --- | --- |
> | 目录深度 | 2 | 1（不变） |
> | 引用 `common` 点数 | **4→5，须改 7 行** | **不变（仍 4 点）** |
> | 新目录 `__init__.py` | **必须加，否则算子静默不注册** | 不需要 |
> | 风险来源 | 点数写错（层1 抓不到）+ 注册断裂 | 无 |
>
> **故扁平方案同时消除 §5 P0-1（点数）与 P0-4（注册）对本批的适用性**——
> 这两项仍保留在 §5 中，因为 S5 的 `utils/pass_capture/` 依旧需要 `__init__.py`。
>
> **依赖方向已核**：`ai_render.py → render_send.py → image_common.py`，单向无环
> （AST 实测：`render_send`/`pass_presets`/`style_refs` 三组被移动符号**均不回指**留守符号）。
>
> ### ⚠️ P0 警告 2：模块级 `global` 重绑定会静默失效（拆分特有陷阱）
>
> 本文件有**两个模块级可变状态**：`_PASS_CAPTURE_CACHE`（dict）与
> `_CAPTURE_FINGERPRINT`（tuple|None）。二者在拆分后的行为**不同**，且都极易踩：
>
> | 状态 | 现状写入方式 | 拆到 `render_send` 后的后果 |
> | --- | --- | --- |
> | `_PASS_CAPTURE_CACHE` | **原地变更**（`.clear()` / `.update()` / `.pop()`） | ✅ 安全（原地变更跨模块可见） |
> | `_CAPTURE_FINGERPRINT` | **重绑定**（`ai_render.py:391-395` 的 `global _CAPTURE_FINGERPRINT; _CAPTURE_FINGERPRINT = ...`） | ❌ **BUG：重绑定只改 `ai_render` 自己的名字，`render_send` 里的仍为 `None`** |
>
> **已用最小可执行模型实证**：
> ```
> BEFORE（同一模块）      : read_stale() = True   -> 正确
> AFTER（朴素拆分）       : render_send._CAPTURE_FINGERPRINT = None
>                           render_send.read_stale() = False
>                           -> 「通道预览可能过期」警告从此永不触发（无报错、门禁全绿）
> FIX（在属主模块内 setter）: read_stale() = True  -> 正确
> ```
>
> **后果**：`resolve_render_request`（`render_send.py`）读 `_CAPTURE_FINGERPRINT` 判 `stale`，
> 而 `CaptureViewRefs._commit_capture`（留在 `ai_render.py`）写它——**写读分居两模块后
> stale 恒为 False**，属**用户可见功能退化**（违反本轮硬约束），且无任何测试会报错。
>
> **强制处置（S4 实施铁律）**：`_CAPTURE_FINGERPRINT` 的**唯一写入点**必须是
> `render_send.py` 内的 setter（如 `set_capture_fingerprint(fp)` /
> `reset_capture_fingerprint()`），`ai_render.py` **一律不得**对该名写 `global`；
> `_PASS_CAPTURE_CACHE` 可继续原地变更，但**写入也应经 `render_send` 提供的函数**，
> 以统一口径、避免未来有人改成重绑定。
> **验证方式**：改完后必须实测「改动深度参数 → 生成通道 → 生成效果图」是否仍出现
> 过期提示（作者 GUI 实测项，见 §4.2 检查点 1 与 §4.1 S4 行）。

> **保留的子包方案（备选）**：若日后 `operators/` 需按 `ch_utils_tools` 那样分子包，
> 再按上表把 4 个文件整体下移一级并逐条改点数——**本轮不做**。

**必须同步改的 4 个导入点**（首版只列了 2 个）：

| # | 位置 | 导入内容 | 首版 |
| --- | --- | --- | --- |
| 1 | `handlers.py:569` | `clear_pass_cache`（函数内延迟导入） | ✅ |
| 2 | `ui/panels/ai_render.py:21-39` | 4 算子 + 私有名 `_PASS_TOGGLES`/`_pass_title`/`_resolve_service` + 5 公共名 | ✅ |
| 3 | `operators/list_ops.py:15` | `clear_pass_cache_ref` | ❌ **漏** |
| 4 | `ui/panels/blocks.py:25` | `ClearStyleDescription, LoadStyleImage, RemoveStyleImage` | ❌ **漏** |

> **后果**：首版拆分方案声明的改动文件不含 #3/#4，**照该范围实施会直接打断插件加载**。
> **实施纪律**：动手前**必须重新做一次全树导入点扫描**（`grep 'ai_render import'`），
> 不依赖本表快照——静态清单会随批次漂移（`scan_invoke_execute` 的同款教训）。

**新增发现 — 13 行构造逐字重复两次**：`ai_render.py:420`（`execute`）与 `:478`（`invoke`）
的 `PassCaptureSession(...)` 全参数构造 **AST 实测相似度 100%**（13 行）→ 抽
`_build_capture_session(context, rstate, wanted, limits) -> PassCaptureSession`。

### C3 · 属性容错与级联回收的 try/except 族（**首版计数错误**）

**AST 实测**（`utils/render_passes.py`，19 个单语句 try 中该文件占 13 个）：

| 函数 | try 数 | handlers |
| --- | --- | --- |
| `_add_edge_gp` | **3**（**2 AttributeError + 1 宽 Exception**） | `:910 Exception`、`:931 AttributeError`、`:938 AttributeError` |
| `_remove_gp` | **3**（全宽 `Exception`） | `:957`、`:962`、`:969` |
| `_enable_passes` | **2**（AttributeError） | `:458`、`:479` |

> **【订正】** 首版称 `_add_edge_gp` 有「4 处 `try/except AttributeError`」——**实测 3 个 try
> （2 AttributeError + 1 宽 Exception）**；且**完全未提** `_remove_gp` 的 3 处同类级联回收
> 与 `_enable_passes` 的 2 处。合计该族 **8 处**，首版只覆盖 3 处。

**处置**：抽 `_run_safe(fn, *args, exceptions=(AttributeError,)) -> bool`（逐项成功即 True），
覆盖 `_add_edge_gp`(3) + `_remove_gp`(3) + `_enable_passes`(2) = **8 处**。
**语义严格保持**：仍「缺失即跳过、不报错」。

### C4 · `PassCaptureSession.open`（`render_passes.py:1103-1170`，68 行）

一次函数内完成 10+ 个顺序相关副作用（场景校验 → 引擎探测 → 清临时根 → 建临时场景 →
链接用户场景 → 拷渲染公共项 → 拷色彩管理 → 设引擎与采样 → 算解码参数 → 算渲染键 →
查缓存 → 解码命中组 → 排批次）。

**处置**：按「准备环境 / 解析缓存 / 排批次」抽 3 个私有方法，`open()` 退化为 3 次调用 +
统一异常收口。**不改变任何步骤顺序**。

### C5 · 「删除条目 + 压回索引」守卫（**3 处，非 4 处**）

**AST 实测**（`set_index`/`set_guarded` + 夹取表达式，多行感知）：

| 位置 | 代码 |
| --- | --- |
| `operators/ai_chat.py:412` `ChatDeleteMessage.execute` | `set_index(state, 'chat_active_index', min(idx, len(state.chat_messages) - 1) if state.chat_messages else 0)` |
| `operators/ai_render.py:874` `RemoveStyleImage.execute` | `set_guarded(state, index_attr, min(idx, len(coll) - 1) if len(coll) else 0)` |
| `operators/list_ops.py:112` `DeleteImage.execute` | `set_index(state, index_name, min(idx, len(remaining) - 1) if len(remaining) else 0)` |

> **【订正】** 首版列 4 处，其中 `image_common.prune_image_backups` **实测不含该模式**（误列）。
> 另 `handlers.py:297` 是 `set_index` 但**无夹取表达式**，不属此族。
> 故 **3 处**，收益约 −12 行。

**处置**：抽 `remove_and_clamp(state, coll_attr, coll, index_attr, idx) -> None`。
**收益中等、成本低**，并入 S1。

### C6 · `props.py` 两状态组字段同构 —— **判不做**（理由经复核更强）

**AST/逐字段实测**（`AiTextureState` 24 属性 / `AiRenderState` 51 属性，19 个同名）：

| 分类 | 字段 | 实测 |
| --- | --- | --- |
| **真正逐字重复（5）** | `lock_ratio` / `count` / `batch_variants` / `negative_prompt` / `seed` | 声明与 description 完全一致 |
| **description 不同（2）** | `size_preset` / `use_size_lock` | 效果图强调「to the camera resolution」 |
| **声明写法不同（2）** | `custom_width` / `custom_height` | 字面量 `256/4096` vs `_RENDER_DIM_MIN/MAX`（值同） |
| 另有 | `size_preset` 的 `items` 回调不同（动态 `_tex_size_preset_items_fn` vs 静态 `render_scale_items`，效果图多 `default='100'`）；全部 `update` 回调不同 | — |

> **【订正】** 首版称九个属性「逐字重复（description 完全一致）」——**只有 5 个成立**；
> 且首版引用的 `count` description 原文与词典键不一致（实际为
> "How many images **to generate in one run (1-5)**…"，见 `props.py:610/933` 与
> `dictionary.py:335`）——而本方案恰恰声明 description 冻结，自证尤须准确。

**处置**：**判不做**。`PropertyGroup` 不支持属性继承；去重唯一手段是共享子组，
但那会**改 RNA 路径**（`state.count` → `state.output.count`），须连动全部读写点。
**且 4 个属性的 description/写法本就有差异**，「去重」会抹平真实差异。

---

## 4. 实施顺序与提交策略（**作者 2026-10-15 定案：一次重构完成、单次提交**）

> **决策**：作者要求**一次重构做完、只提交一次**。故下表的工作项是**实施顺序**
> （内部里程碑，便于出问题时二分定位），**不是 N 次提交**——全部完成后**单次提交**，
> 由作者执行，作者热重载实测**一轮**。

### 4.1 实施顺序（单次提交内的里程碑）

| 序 | 内容 | 改动文件 | 预估净减 | 风险 | 验证 |
| --- | --- | --- | --- | --- | --- |
| **S1** | D2 备份环合一（返回元组）+ C5 删除压回合一 + D6 删 `ai_client.build_thinking_extras` 重复定义 + `_style_image_bytes` 内联 | `image_common.py` / `script_actions.py` / `ai_texture.py` / `list_ops.py` / `ai_chat.py` / `ai_render.py` / `ai_client.py` / 新增 `utils/_backup.py` | ~85 | 低 | 全量档 |
| **S2** | D1 守卫样板收敛（含图像存在性守卫三连 / 5 条最长梯子 / 聚焦提示）+ 13 行构造去重 ——**须保留 6 处中段分歧与逐张 report 差异** | `image_common.py` / `ai_texture.py` / `ai_render.py` / `ai_generate.py` / `ai_chat.py` | ~150 | 中 | 全量档 |
| **S3** | D3 梯子收敛：`handlers` 内部表 + `script_actions`/`ai_generate` 的 target 分派（作者已定"纳入"） | `handlers.py` / `script_actions.py` / `ai_generate.py` | ~25 | 低-中 | 全量档 |
| **S4** | C2 `ai_render.py` **扁平**拆分（3 新文件）+ **4 个导入点**同步 + **`_CAPTURE_FINGERPRINT` setter 铁律**（见 §3 C2 P0 警告 2） | 新增 3 文件 / `ui/panels/ai_render.py` / `ui/panels/blocks.py` / `operators/list_ops.py` / `handlers.py` | ~0（纯移动） | 中 | 全量档 + **导入点复扫** |
| **S5** | C1 `render_passes.py` 完整拆分（`utils/pass_capture/` 十文件）+ `__init__.py` + **verify 脚本改造与有效性自证**（见 §3 C1 P0 警告 1）+ docstring 迁移 + 描述债清理 | 新增 10 文件 / `render_passes.py` / `utils/__init__.py` / `.agents/tools/verify/test_capture_passes.py` | ~0 | **高** | 全量档 + verify 脚本**有效性自证** |
| **S6** | C3 try 族收敛（8 处）+ C4 `open` 方法化 + D5 键域加载期断言 | `render_passes.py`(拆分后为 `pass_capture/*`) / `prompts.py` / `ai_render.py` | ~60 | 中 | 全量档 |
| **S7** | 文档同步（穷尽枚举，见 §5 P1-10）+ 收尾落盘（CHANGELOG / 日志 / 状态卡，见 §5 P1-9） | 见 §5 P1-9 / P1-10 清单 | — | 低 | `--quick` |

**顺序理由**：S1/S3 低风险→S2 收益最大→S4/S5 纯移动（S5 风险最高，放 S4 之后借其验证经验）
→S6 依赖新布局→S7 收尾。

### 4.2 单次提交的前提条件（**不可省略**）

作者选择"一次做完再提交"，代价是**回退粒度变粗**、且**累计改动面大**。为守住风险，以下为
提交前的**硬性检查点**（不满足则不得提交）：

| # | 检查点 | 依据 |
| --- | --- | --- |
| 1 | 每个里程碑（S1–S6）**各自跑一次 `gate.py` 全量档**，不得只在末尾跑一次 | 中途断裂要当场发现，否则末尾一次报错难定位 |
| 2 | **`uicheck/run_check.py` 必须在提交前跑**——它对比 `git HEAD`；一旦提交，基线变成自身、检查**空转** | `uicheck/run_check.py:29-40` |
| 3 | **全树导入点复扫**（`grep` 所有 `import` 语句），不依赖方案快照 | §3 C2 表（首版漏 2 处） |
| 4 | **verify 脚本有效性自证**：故意注入一处缺陷（如让渲染多跑一次），确认脚本**报 FAIL**，再撤回 | §5 P0-2 |
| 5 | `python .agents/tools/check/fix_punctuation.py`（新增 15 个文件的注释标点） | AGENTS 约定 9 |
| 6 | `unittest discover -s tests` 全绿 | 纯函数等价性 |

**删除动作**仍需按 §5 P1-6 的清单**先说清范围**（作者已回复"允许删除"，实施时按清单整块执行，
不作"去掉一部分"式裁剪）。

### 4.3 行数预期（诚实口径）

合计约 **−320 行（占总行数 ~2.6%）**。
**本轮价值主要在结构清晰度、差异集中与契约可验证，不在行数削减**——避免按「能减很多行」验收。

### 4.4 代码审查（提交之后）

作者已定：**全部重构完成并通过后，由作者另开新会话审查**（满足 `code-review` 技能
「**必须新会话执行**」硬约束；L2/L3 视同大批次，建议两轮制）。
AI 不在本会话内自审充当该环节（见 §5 P1-8）。

---

## 5. 规范义务清单（本方案对工作区文档的符合性）

> 本节是 **AGENTS / 技能硬约束的落地清单**。标注 **P0** = 不满足则实施即断裂或验证失效。

### P0-1 相对导入点数（首版完全未提）

**执法规则**（`.agents/e2e/cases/static.py:165-166`）：
```python
depth = len(f.relative_to(plugin_root).parts) - 1
expected_dots = depth + 3
```
即 **引用 `common` 的点数 = 文件相对插件根层级 + 3**。
（AGENTS 框架约定 6 写的「层级 + 1」是**点数基数**表述，skill §13 写的「+1」是**层级**表述；
**一律以 `depth + 3` 为准**，勿照抄 "+1" 以免算错。）

| 新文件 | depth | 引用 `common` 需 | 现状 |
| --- | --- | --- | --- |
| ~~`operators/render/*.py`~~ | — | — | **已改扁平方案，本项对本批不适用**（见 §3 C2） |
| `utils/pass_capture/*.py` | 2 | 5 点 | 源文件**无 `common` 导入** → 无改写需求 |
| `utils/_backup.py` | 1 | 4 点 | 新增（若需引用 common） |

**同族点数**：引用同级兄弟 **1 点**（`from .pass_presets import ...`）；
引用 `operators/` 下兄弟 **2 点**（`from ..image_common import ...`）；
引用 `utils` 公共 API **2 点**（`operators/` 下）。

> **采纳扁平方案后，P0-1 对本批的适用面大幅缩小**：`operators/` 下 3 个新文件
> **depth 仍为 1**，引用 `common` 仍是 **4 点（不变）**，无需改写任何点数。
> `utils/_backup.py` 在 `utils/` 下（depth 1）同样是 4 点。
> 仅 `utils/pass_capture/*.py`（depth 2）需 5 点，**而这些文件当前不存在、不引用 `common`**
> ——即**本批实际没有一处需要改点数**。此项保留在清单内，是因为它仍是**新增二级目录时的
> 通用铁律**（`render_passes.py` 若将来引用 `common`，或日后把 `operators/` 也子包化时必用）。

> **⚠️ 次级风险（门禁抓不到）**：`static.py:152` 明文「插件内部的相对导入**不做点数硬校验**」。
> 即**同级/兄弟导入写错，E2E 层1 全绿，只有真实加载才炸**。
> → 故 S4/S5 **必跑全量档**由 `verify_blender_load` 兜底。

### P0-2 兼容 shim 的私有名转发 / verify 脚本改造（**作者已定：改写 verify 脚本**）

见 §3 C1 的 **P0 警告 1**（含 monkeypatch 静默假通过的实证）。
**采纳方案 (b)**：**改写** `.agents/tools/verify/test_capture_passes.py` 与
`test_capture_gui.py` 的 monkeypatch 目标，指向拆分后的**实际定义处**
（`utils.pass_capture._scene` / `_session`），而非在 shim 上永久转发 9 个私有名。
**且必须先证明脚本在新布局下仍能抓住一个真实缺陷**（见 §4.2 检查点 4）。

### P0-3 验证命令路径（首版笔误）

首版写 `.agents/test_capture_passes.py`（**不存在**）。真实路径：
`.agents/tools/verify/test_capture_passes.py`（后台档，AI 可跑）；
`.agents/tools/verify/test_capture_gui.py`（**GUI 档，归作者**）。

### P0-4 新增目录必须带 `__init__.py`

`utils/pass_capture/` **须有 `__init__.py`**（扁平方案下 `operators/` 不新增目录，故不涉及）。
否则 `common/class_loader`（`auto_load.py` 递归 `pkgutil.iter_modules`）**不发现其中类** →
**静默不注册、无任何报错**（AGENTS 框架约定 1；本批该目录只放函数、不放类，但缺包标记仍会
使 `from .pass_capture import ...` 在打包布局下失效）。此项**只有全量档
`verify_blender_load` 能抓**——这是「新增文件必跑全量档」的独立理由（与 RNA 无关）。

### P0-5 D2 返回约定改元组

见 §2 D2（`prune_backups -> tuple[list[str], str | None]`）。

### P1-6 删除清单（**作者已授权删除**，按整块执行）

AGENTS「硬红线·文件删除」：按**整块确认边界**（整函数/整分支）确认，不得「去掉一部分」逼近；
本机经 AI 执行的删除**一律路由到回收站，不得声称「已真删」**（确需真删由作者在 WorkBuddy 之外执行）。

**已授权删除清单**（作者 2026-10-15 回复「允许删除」）：

| # | 项 | 位置 | 性质 |
| --- | --- | --- | --- |
| 1 | 空分节注释 `# ---- 语义分割覆盖 ----` | `render_passes.py:976` | 死注释（内容已在 D9 清理中删除） |
| 2 | `_style_image_bytes` 函数体（内联后） | `ai_render.py:277-282` | 单调用点 + 纯转发 |
| 3 | `ai_client.build_thinking_extras` 重复定义 | `ai_client.py:87-96` | 纯转发到注册表（保留注册表那份） |
| 4 | `_add_edge_gp` / `_remove_gp` / `_enable_passes` 的 8 处 try 块 | `render_passes.py` | 收敛为 `_run_safe` 调用 |
| 5 | `ai_render.py:420` / `:478` 的重复 13 行构造 | `ai_render.py` | 抽 `_build_capture_session` |

> **说明**：第 4、5 项是**等价改写**（原语句被替换为新调用），不是净删除；
> 第 1、2、3 项是净删除。全部改动均在**同一次提交**内，由作者实测验证。

### P1-7 描述债清理（门禁查不到）

`addon-feature-porting` 明文：删除/移动机制后必须清「描述债」，**拿被删机制名全树 grep**，
逐个改写或显式标注「该机制已删除」——判据不是「能不能跑」而是「读起来是否还成立」。

**实测需处理的引用**（`render_passes` / `ai_render` 相关注释与 docstring）：

| 位置 | 内容 |
| --- | --- |
| `render_passes.py:4-15` | **模块 docstring 的渲染组机制说明 → 拆分后必须迁入 `pass_capture/__init__.py`（或 `_session.py`）**，否则原文件变 shim 后该说明失去承载位置 |
| `props.py:781`、`:844`、`:873` | 三处注释指向 `render_passes.CRYPTO_SOURCE_DEFAULT` / `_EDGE_RADIUS_FALLBACK` / `resolve_capture_size` |
| `i18n/dictionary.py:605`、`:631` | 分块注释提到 `render_passes` |
| `operators/ai_render.py:11` | 模块 docstring 提到 `utils/render_passes` |
| `utils/cryptomatte.py:126` | docstring 提到 `render_passes._segmentation_names` |
| `utils/__init__.py:151` | 导入行（若 shim 保留则不改） |
| `addons/ch_ai_assistant/README.md:20`、`:32`、`:57-60` | 目录树与分层叙述 |
| `addons/ch_ai_assistant/docs/pass-capture-refactor.md:294`、`:302`、`:489` | **同目录同主题三处**按 `utils/render_passes.py` 单文件描述结构与迁移面 |
| `.agents/memories/ai-assistant-status.md:52-62` | 「关键实现位置」以 `utils/render_passes.py` 为锚（INDEX 注明「改 ch_ai_assistant 前」必读） |

> 首版把模块 docstring 判为「不建议改」——**复核后撤销**：C1 拆分后原文件变 shim，
> docstring 失去承载位置，构成典型描述债，**必须迁移**。

### P1-8 代码审查须新会话 + 两轮制

`code-review` 技能硬约束：「**必须新会话执行**」（先例：恢复期 22 行重复段，写代码的会话
查不出，跨会话审核报出）；L3 为**两轮制**（一轮审 + 一轮对结论复核排误报）。

本方案 S1~S6 触及 42 个 `.py`、新增约 14 个文件，落在 **L2**（大批次完成）甚至 L3 射程。
→ 审查**必须另起新会话**执行，产出 P0–P3 清单；P0–P2 走 `bugfix-discipline` 全流程。
> **本方案自身的两轮复核（含独立子代理对抗性核验）作用于「方案文档」，不构成对「改动代码」
> 的审查**——不能替代新会话审查。
> 注：`collaboration.md` 记「审查非提交/发布阻塞项」，故审查不阻塞提交，但**必须排期**（作者已定：另开新会话）。

### P1-9 收尾落盘义务（S7 必须执行）

| # | 义务 | 依据 |
| --- | --- | --- |
| 1 | `CHANGELOG.md` `[未发布]` 记条目（S1~S6 含代码修改**必须记**；S7 纯文档不记） | AGENTS「日常改动收尾」 |
| 2 | `.agents/MEMORY.md` 状态卡「**上次会话**」区**覆写**（零叙事） | AGENTS「收尾强制落盘」 |
| 3 | 状态卡「**待落盘**」清单（`[去向] 内容` 一行一条，写不完的） | 同上 |
| 4 | `.agents/log/<日期>.md` **当日日志补记**（一行一事：主题 → 结果 → 落盘位置指针，备注 ≤5 行） | AGENTS「文档体系」 |
| 5 | **memories 归位**：至少 `ai-assistant-status.md`（关键实现位置）；判定
`blender-compositor-5x-file-output.md`（渲染组/File Output 机制引用点） | INDEX 路由 |
| 6 | §5.1 复核方法学教训做**去向判定**（通用判据上浮技能/AGENTS，一轮性过程只留日志） | 落盘路由第 1 问 |
| 7 | 提示作者实测；提交等用户明确指令 | AGENTS 硬红线 |

### P1-10 文档穷尽枚举（S7）

AGENTS「文档同步口径」：**先穷尽枚举**（`glob **/*.md` + `*.toml`/`*.ini`），
**再逐份判定**「本轮改动是否影响它」，**不允许凭记忆挑**。（全仓 `.md` 共 34 份。）

| 文档 | 判定 | 是否已列 |
| --- | --- | --- |
| `addons/ch_ai_assistant/README.md`（`:7-55` 目录树 + `:20`/`:32` + `:57-60` 分层叙述） | **必改** | ✅ |
| `addons/ch_ai_assistant/docs/pass-capture-refactor.md`（`:294`/`:302`/`:489`） | **必改** | ❌ **首版漏** |
| `.agents/memories/ai-assistant-status.md`（`:52-62`，INDEX 指定必读） | **必改** | ❌ **首版漏** |
| 本方案 `refactor-plan.md` | **必改**（加「已实施于 X.Y.Z，仅考古」横幅） | ✅ |
| `.agents/MEMORY.md` 状态卡 / `CHANGELOG.md` / `.agents/log/<日期>.md` | **必改** | ❌ 首版漏 |
| `AGENTS.md` | 需判定（本方案未引入新规则 → 判不改） | ❌ 未列 |
| `.agents/memories/blender-compositor-5x-file-output.md` | 需判定 | ❌ 未列 |
| `.agents/tools/README.md`、`.agents/gen/*`、`.agents/skills/*`、`addons/ch_utils_tools/**`、`wheels/README.md`、`blender_manifest.toml`、`config.ini` | 需显式判定「不受影响」 | ❌ 未列 |

### P2-11 `utils` 包组织形态（§10）

- `utils/pass_capture/__init__.py` 用 `__all__` + **显式具名导入**声明公共 API，
  是公共/内部边界的**唯一声明点**（skill §10）。
- **`pass_capture/*.py` 子模块不写模块级 `__all__`**（skill §5 utils 例外 + §10）。
- 与上游 `utils/__init__.py` 的衔接：该文件现状为**逐名显式再导出**
  （`:151-160`，非 §10 的 `from .子包 import *`）——**本方案不改这个形态**
  （改它属行为面扩大，须单独立项）。
- **与 §11 否决案的划界**：skill §11 记「用户否决过『顶层改纯再导出 shim』方案，后续勿再提议」
  （2026-09-24，针对 `ch_utils_tools` 的 `constants.py`/`mappings.py` **原地掏空**）。
  本项是**内容搬家后在原子模块位置留转发入口**，插件与文件均不同、方向相反，
  故**不在否决射程内**；但仍按下线条件（§3 C1）按期删除，不长期留存。

### P2-12 常量收口逐项判定（§11）

skill §11：「仅一处调用且写死无修改价值的常量**不提取**」。
`pass_capture/_constants.py` 只收 **多处引用或可能调参**者：

| 够格收口 | 依据 |
| --- | --- |
| `PASS_ORDER` / `WARN_EDGE_PX` / `EDGE_PRESETS` / `GROUP_VIEW_LAYER` / `GROUP_OUTPUTS` / `CRYPTO_*` 系列 / `_EEVEE_SAMPLES` | 多处引用或跨子包可见 |

| 不提取，留在使用它的子模块内 | 依据 |
| --- | --- |
| `_CLAMP_EDGE_MAX` / `_TMP_ROOT_NAME` / `_PNG_COMPRESS` / `_JPEG_QUALITY` / `_DEPTH_PICK_*` / `_SEG_UNMATCHED_WARN` | 单处或单子包内写死，无调参价值 |

### P2-13 新文件版式（§5 / §1.1）

~15 个新增 `.py` 一律按 skill §5 版式（Operator 文件：模块文档 → `__all__` → 导入 →
常量 → 辅助函数 → 类；Utils 文件：模块文档 → 导入 → 常量 → 公共函数 → 内部辅助函数）
+ §1.1 模块 docstring 格式；**注释与 docstring 标点一律英文**（AGENTS 约定 9），
收尾跑 `python .agents/tools/check/fix_punctuation.py`。

---

## 6. 「不引入用户可见功能」的闭合校验

用户指令的核心约束。本方案**承诺零用户可见变化**，逐项对照：

| 维度 | 本方案是否触碰 | 校验手段 |
| --- | --- | --- |
| UI 元素 / 位置 / 顺序 / 图标 / 置灰条件 | **不触碰**（S4 只改导入路径；S6 不改面板） | `python .agents/uicheck/run_check.py`（**须在提交前跑**——它对比 `git HEAD`，已提交即基线失效、检查空转） |
| RNA 属性（名 / default / min / max / items / description / update） | **不触碰** | `verify_blender_load`（全量档） |
| 英文文案（词典键） | **不触碰**（D1 出口内部复用现状原文常量） | `static_audit` 的 i18n 覆盖率 + `i18n_sweep` |
| 提示词正文 | **不触碰** | `prompts._check_contract`（import 时自检） |
| 命名规则 / 版本链 / 持久化 JSON | **不触碰** | `tests/test_ch_ai_*.py` + `verify/test_capture_passes.py` |
| 渲染管线行为（通道内容 / 渲染次数） | **不触碰**（纯移动） | `verify/test_capture_passes.py` 的逐项断言（**有效性须自证**，见 P0-2） |
| 响应/请求体（服务商参数） | **不触碰** | `tests/test_ch_ai_provider_registry.py` |

**等价性验证（逐位比对）**：对关键纯函数用固定输入，在**同一 Blender 后台会话**里
改动前后各跑一次，比对输出字节：`_depth_gray` / `_normal_bytes` / `_edge_bytes` /
`_encode_png` / `resolve_output_size` / `decode_segmentation` / `next_render_version_name` /
`render_version_stem` / `prune_backups`。

---

## 7. 明确的非目标

1. 不新增/删除/重命名任何用户可见 UI 元素、属性、按钮、图标。
2. 不改任何英文文案、提示词正文、命名规则、持久化格式。
3. 不改 UI 元素位置与顺序。
4. 不改 `provider_registry.py` 的 dataclass 字段与 `*_items` 字面量形态。
5. 不改 `items.py` / `preference.py` 的 `*_items` List 字面量形态（i18n 硬约束）。
6. 不顺手对齐 `utils/__init__.py` 的汇聚写法（属行为面扩大，须单独立项）。
7. 不引入第三方依赖。
8. 不解决 §8 已定论不做的历史项。

---

## 8. 已定论不做（勿在本轮重提）

出处：`.agents/log/2026-10-12.md` / `2026-10-13.md`、`docs/pass-capture-refactor.md` §4.6。

| 项 | 定论 |
| --- | --- |
| `unmatched_ratio` 由「按像素」改「按槽位」 | 放弃改语义，只补文档 + 断言钉死 |
| `capture_camera_passes` 判死代码 | 实为主行为测试套件入口（20+ 处调用），**保留** |
| `lock_ratio` 上限冲突 / `chat_active_index` 负索引 | 判过度设计/当前不可达，**不改** |
| 危险预检可被 `execute` 直调绕过 | 已审计的刻意取舍，**不改** |
| `supports_watermark` / `supports_response_format` 无消费点 | 留待独立立项 |
| UIList GRID 基类 / `AiRequestMixin` 样板收敛 | 判不做 |
| 通道捕获重构 §4.6 的第二/第三梯队参数 | 一律不做 |

**本轮复核后新判不做**（含理由，防未来重提）：

| 项 | 理由 |
| --- | --- |
| D4 尺寸护栏骨架 | 分支结构本身相反（护栏进入方式 / 解锁时是否改档），属作者手工调校区 |
| C6 props 字段同构 | 9 个属性只 5 个逐字重复；去重须改 RNA 路径 |
| D5 派生表统一为一张表 | 各表性质不同；**改判为加零行为加载期断言**（见 D5 处置） |
| D6 `props._thinking_items_for` 内联 | 2 个调用点都在 RNA 回调链上，内联摊平语义层次 |
| `'CANCELLED'`(109) / `'WARNING'`(77) / `'INFO'`(51) 等 API 枚举抽常量 | 非业务重复 |
| `default=False/''/0` 默认参数去重 | 无语义关联，数值巧合 |
| `{'1K':1024,'2K':2048}` 双份（`items.py:109` / `image_client.py:32`） | 仅 2 处 2 行；`items.py` 受 i18n 硬约束 |
| `_GROUPS` 同名碰撞（两个 service 面板） | 值不同、职责不同，去重已完成 |
| `last_error_*` / `status_*` / `wait_*` / `cancel_*` 前缀协议改枚举 | 引入间接层，收益为负 |
| `2147483647` 哨兵值收口 | 5 处语义不同（RNA max ×2 / 随机抽取 ×2 / 取模 ×1） |

---

## 9. 作者决策记录（2026-10-15，**全部已定**）

| # | 议题 | 作者决策 | 落地位置 |
| --- | --- | --- | --- |
| 1 | `render_passes.py` 完整拆分（原 R6） | **做**（完整档，`utils/pass_capture/` 十文件） | §4.1 S5；§3 C1 |
| 2 | 兼容 shim 处置（原 P0-2） | **按 AI 建议**＝改写 verify 脚本的 monkeypatch 目标，并**自证有效性** | §3 C1 P0 警告 1；§4.2 检查点 4 |
| 3 | 删除作者源码（原 P1-6 清单） | **允许删除**（按清单整块执行，不作「去掉一部分」式裁剪） | §5 P1-6 |
| 4 | `script_actions`/`ai_generate` 的 target 梯子（原 R3b） | **纳入** | §4.1 S3；§2 D3 |
| 5 | 批次粒度 | **一次重构完成、单次提交**；审查在全部完成并通过后由作者另开新会话 | §4（全节）；§4.4 |
| 附 | `operators/render/` 子包 vs 扁平 | **按 AI 建议**＝**扁平**（3 个新文件平铺 `operators/`，消除点数与注册两项风险） | §3 C2 |
| 附 | `utils/__init__.py` 汇聚写法 | **保持不动**（不对齐 §10 的 `import *`，避免行为面扩大） | §5 P2-11；§7 第 6 条 |

**复核后已内部定论**（作者未反对）：D4 默认不做、C6 判不做、D5 改为加**加载期断言**、
D6 仅内联 `_style_image_bytes`、删除 `ai_client.build_thinking_extras` 重复定义。

**实施中如遇方案未覆盖的取舍**：AI 按「等价重构 + 不引入用户可见功能 + 符合规范」三条原则
自主决策并在最终汇报中**逐条披露**（含被否决的方案与被否原因），不中途反复请示。

---

## 10. 本轮复核方法学教训（待落盘，去向见 §5 P1-9 第 6 项）

| # | 教训 | 实测出处 |
| --- | --- | --- |
| 1 | **`Measure-Object -Line` 漏计空行**（`render_passes.py` 报 1358、实际 1546）——数行一律 `io.open`/`ReadAllLines` | 首版总行数 10767 实为 12473 |
| 2 | **一份文档混用两种计数口径**，会让复核者误判为「写于旧版本」——数字必须**在表头写明口径** | 首版 §1.1 |
| 3 | **「唯一入口 / 唯一引用点」必须机器枚举**，不能凭阅读记忆（首版漏 2 个导入点，照其范围实施会打断加载） | `list_ops.py:15`、`ui/panels/blocks.py:25` |
| 4 | **判「同构 / 逐字重复」前必须逐字段机器比对**（首版称 9 属性逐字重复，实测 5 个；且引用的 description 与词典键不符） | C6 |
| 5 | **「薄封装可内联」要看调用点是否在 RNA 回调链上**，不能只看函数体短 | D6 `_thinking_items_for` |
| 6 | **兼容 shim 会静默破坏 monkeypatch 型测试**——`from X import f` 绑定到导入方全局，patch 转发位置拦不到；症状是**测试照常 PASS 却什么都没测**（已用最小可执行模型实证） | C1 P0 警告 1 |
| 7 | **相对导入点数规则是 `depth + 3`**（执法代码），与 AGENTS「+1」/skill「+1」的两种表述不可混用；且**插件内部相对导入不受层1静态校验**，写错只有真实加载才炸 | `static.py:165-166` / `:152` |
| 8 | 守卫扫描须匹配 `ast.Set`——`return {'CANCELLED'}` 是**集合**不是字典（首轮脚本匹配 `ast.Dict` 得 0 命中） | 本轮工具编写 |
| 9 | **拆分含模块级可变状态的文件时，`global` 重绑定会与新属主失联**——`_CAPTURE_FINGERPRINT` 若移到 `render_send.py` 而写入仍在 `ai_render.py` 用 `global`，读方恒见 `None`，**「预览过期」警告静默失效**且门禁全绿；dict 的原地变更（`.clear()/.update()`）反而安全。**拆分含可变状态的模块前必须先做此判定** | §3 C2 P0 警告 2（已实证） |
| 10 | **子包 vs 扁平应先算风险账**：多一级目录 = 相对导入点数改写 + 新目录 `__init__.py`（缺则类静默不注册），两者均为**门禁抓不到**的风险；职责切分不必以目录层级为代价 | §3 C2 扁平方案 |

---

## 11. 实施结果与偏差（2026-10-15，**事实**）

> 本节是**事后记录**：上文 §1–§10 的「计划/预估」保留原样供考古，与本节冲突处**以本节为准**。

### 11.1 实施清单（S1–S7 全部完成）

| 序 | 内容 | 结果 |
| --- | --- | --- |
| S1 | D2 备份环合一（`utils/_backup.py`）+ C5 删除压回合一（`handlers.set_index_after_removal`）+ D6 删 `build_thinking_extras` 双份 + `_style_image_bytes` 内联 | 完成 |
| S2 | D1 守卫样板：`report_text_focus` / `report_image_focus`（各 7 / 3 处→1）+ `highlighted_image`（3 处→1）+ `land_generated_images`（逐张落地循环，带 `transform`/`report_each` 钩子）+ `_build_capture_session`（13 行→1） | 完成 |
| S3 | D3 `target` 分派：`handlers._REORDER_TARGETS`、`script_actions._ERROR_FIELDS`、`ai_generate._PROMPT_TARGET_STATES`（6 条梯子→表驱动） | 完成 |
| S4 | C2 `ai_render.py` **扁平**拆分（`render_send` / `pass_presets` / `style_refs`）+ 4 个导入点同步 + `_CAPTURE_FINGERPRINT` setter 铁律 | 完成 |
| S5 | C1 `utils/pass_capture/` 子包（10 内部模块 + `__init__.py`）+ 机制 docstring 迁移 + 两个 verify 脚本改造与自证 | 完成 |
| S6 | D5 三处加载期契约断言 + C3 try 族 7 处收敛（`set_attr_safe` / `drop_silently`）+ C4 `open()` 拆两阶段 | 完成 |
| S7 | 描述债清理 + 文档同步 + CHANGELOG + 日志 + 状态卡 | 完成 |

### 11.2 验证结果（均为实跑）

| 检查 | 结果 |
| --- | --- |
| `gate.py` **全量档** | **10/10 PASS**（含 `verify_blender_load` / E2E 层2 utils / 层3 ops） |
| `uicheck/run_check.py` | **PASS**（界面元素一个不少、顺序未变） |
| `tools/verify/test_capture_passes.py`（真实 Blender 后台） | **RESULT: PASS** |
| verify 脚本**有效性自证** | 注入多余渲染 → `FAIL (2)`；撤回 → `PASS`（证明 monkeypatch 仍拦截、断言仍敏感） |
| `unittest discover -s tests` | 77 tests OK |
| `fix_punctuation.py` | 0 待转换（含顺手清掉原 `render_passes.py` 遗留的中文标点） |
| 全树导入点复扫 | 389 个导入名 **0 未解析** |
| `i18n_sweep`（**不在门禁内**，须手工跑） | 候选 769 → 756、**未覆盖 0**、f-string 0、词典重复 0、孤儿 20（不变） |

### 11.2.1 「零用户可见变化」的**量化**证明（复核轮补测）

承诺「无用户可见变化」不能只靠"看着没改"，故逐面用机器比对（HEAD vs 现状）：

| 维度 | 方法 | 结果 |
| --- | --- | --- |
| **RNA 属性声明** | AST dump 全部 `*Property(...)` 调用后逐串比对 | `props.py` 122 条、`preference.py` 48 条 **完全一致**；`items.py` 0 条 |
| **算子/面板类属性** | 比对 `bl_idname`/`bl_label`/`bl_description`/`bl_options`/`bl_icon`/`bl_category`/`bl_space_type`/`bl_region_type` | 53 个类 **0 处差异** |
| **report 级别** | 提取全部 `(level, message)` 对并比对 | **0 处级别回归**（WARNING 未变 ERROR）；调用数 142 → 127 |
| **词典键** | `dictionary.py` 逐行 diff | 仅 **2 行注释**变更，键**逐字节未动** |
| **提示词正文** | 长字符串字面量集合比对 | **0 条被移除**；新增 3 条均为开发者自检的 `AssertionError` 文案（非 UI） |
| **i18n 候选量的减少** | 用 sweep 自身的 `extract_candidates` 在 HEAD 源码与现状上分别取多重集后求差 | 减少 **13 条 occurrence**，逐条可归因（见下），且**新增 0 条** |

**13 条减少的逐条归因**（即"去重"的可见后果，全部为重复文案收敛为单口）：
`"No text editor area open…"` 7→1（−6）、`"No image editor area open…"` 3→1（−2）、
`"No image selected"` 4→2（−2）、`"Image no longer exists"` 4→2（−2）、
`"Image saved to {}"` 3→2（−1，两面板共用落地循环）。
**关键不变量**：`未覆盖 0`（无文案失去翻译）+ `孤儿 20 不变`（无词典键变成死条目）
+ **新增 0**（未引入任何新文案）——三者同时成立才说明这次减少是"去重"而非"丢文案"。

> **说明**：`"No image selected"` / `"Image no longer exists"` 各保留 2 处而非 1 处是**有意**的：
> `SaveImage` 的 invoke/execute 按"未选中/数据块已删"分别给不同文案，合并会改变用户在不同
> 阶段看到的提示，故保留原样（见 §11.4）。

### 11.3 实施中发现的**新缺陷**（方案未预见，均已修）

1. **AST 提取漏顶层 `Expr` 语句**：`_PASS_FORMATS.update({...crypto...})` 与
   `_CHANNEL_GROUP.update({...crypto...})` 是裸调用语句（非 def/class/assign），
   我的提取脚本未收集 → 前者致 `KeyError: 'crypto_00'`、后者致分割通道失去组归属。
   **由 `test_capture_passes.py` 抓获**（纯静态门禁全绿）。
2. **子包内相对导入未加深**：模板把 `.errors` / `.cryptomatte` 原样搬入子包，
   在子包内解析为 `pass_capture.errors` → **插件加载即失败**。**由真实 Blender 加载抓获**。
3. **`global` 重绑定失联**（§3 C2 P0 警告 2 预告的风险**真实存在**）：拆分后
   `_CAPTURE_FINGERPRINT` 若仍由 `ai_render` 写入则读方恒见旧值 → 已改经 `store_capture()`。

**复核轮自查出的两条**（作者新会话审查时可直接核对）：

4. **自检写法不一致**（已修）：三处通道域自检中，`prompts` 与 `pass_capture/_constants`
   用 `raise AssertionError`，而 `render_send` 原用裸 `assert` —— 已统一为
   `_check_pass_domain()` + `raise AssertionError`（与既有 `_check_contract` 先例一致）。
5. **`utils/pass_capture/_cache.py::group_of_channel` 无任何调用方**（**非本轮引入**）：
   实测 HEAD 的 `render_passes.py` 中它同样只有定义、无引用（1 处 = 定义自身），
   本轮**原样保留**未动。属存量死代码，是否删除交作者定（AGENTS 文件删除红线：
   删除范围以作者明确列出为准）。

### 11.4 与计划的偏差（须知晓）

| 项 | 计划 | 实际 | 原因 |
| --- | --- | --- | --- |
| `operators/` 是否建子包 | 先拟 `operators/render/` 子包 | **扁平**（3 个新文件平铺） | 消除相对导入点数改写与新目录注册两项**门禁抓不到**的风险（§3 C2） |
| D6 `props._thinking_items_for` | 曾拟内联 | **不内联** | 两个调用点都在 RNA 回调链上（§8 已记） |
| D4 尺寸护栏 / C6 props 字段 | 曾拟收敛 | **不做** | 分支结构本身不同 / 去重须改 RNA 路径（§8 已记） |
| D5「派生表合一」 | 曾判不做 | 改为**加载期断言** | 5 张表用途不同不宜合并，但缺一致性守卫（§2 D5） |
| C3 覆盖处数 | 方案 §3 C3 记「8 处」 | 实际收敛 **7 处** | `_enable_passes` 的 AO 是**双语句同 try**，拆成两次单语句调用会改变"第一句失败即跳过第二句"的语义，故保留原样 |
| 净减行数 | 估 −320 行 | **实际 +364 行**（12515 → 12879，文件 42 → 56） | 预估只算了"重复消除的收益"，**没算拆分的头部开销**：每个新模块的 docstring + import 头是固定成本（旧 `render_passes.py` 1546 → 子包 1677，+131 全是头部）。**重复确实消除了，但总行数未减**——本轮收益在结构清晰度与差异集中，不在行数 |
| shim（兼容再导出层） | 曾拟保留并写下线条件 | **不保留** | 全树只有 3 个消费者（`utils/__init__.py` + 2 个 verify 脚本），改完即无需 shim，避免长期背私有名转发债 |

### 11.5 独立核验结果（**新上下文**的两个对抗性核验，2026-10-15 复核轮）

> 按 `code-review` 技能「必须新会话执行」，**本节的核验不构成对代码的正式审查**（见 §11.6 遗留）。
> 两个核验代理与本会话不共享上下文，任务设定为"**找缺陷**"而非"确认无误"。

**核验 A（全量 diff 对抗性审计）——结论：无 P0/P1/P2**，8 项"看着像行为变更"的改动逐一验为等价。
其独立复现了 §11.2.1 的字面量计数表（数字与本文一致），并独立验出：217 个类属性 0 差异、
0 未用导入、221 条相对导入 0 未解析、3 条 HEAD 模块级裸调用语句全部有对应（即 CHANGELOG 自认的
丢码陷阱在**最终态已修好**）。提出 5 项 P3：

| # | P3 发现 | 处置 |
| --- | --- | --- |
| A1 | 我新增的 `pass_capture/_constants.py` 自检 docstring **谎称**"5 张按通道键查表的表在此钉死"，并把按**预设名**查表的 `EDGE_PRESETS` 列为通道键表 | **已修**：改为准确的"**本文件**三项校验 + 明确声明不校验别处" |
| A2 | 我新增的 `prompts._check_pass_domain` docstring 把包含方向**写反**（代码断言 `LEAK ⊆ PASS_ROLES`，docstring 说"都在反泄漏表域内"） | **已修**：按代码实际断言重写 |
| A3 | **5 处**残留 `render_passes` 指称（`tests/` 3 处 + verify 脚本 2 处，其中 2 处是纯注释故 grep 不到） | **已修**：全部改为新位置；并确认全树 `.py` 已 0 命中 |
| A4 | 拆分丢了常量旁的**理由注释**，最要紧 3 条：`CRYPTO_SLOT_COUNT = 3` 为何是**下限**、`_RAW_CACHE_MAX_BYTES` 的 512MB 定标、`_EDGE_RADIUS_FALLBACK` 那条**"试过自适应换算、观感倒退已废弃"** | **已修**：3 条全部复原（另补 `CRYPTO_SOURCE_DEFAULT` 的"影子默认"警告） |
| A5 | CHANGELOG 称"**纯移动，不改任何函数体**"，与同条目自列的 4 处函数体改动自相矛盾 | **已修**：改为"函数体逐字节搬移，仅下列几处为等价改写"并列出 4 处 |

**核验 B（拆分等价性 + 证伪尝试）——结论：语义基本等价，但测出 1 处真实差异（P1 级）**：

| 检查 | 结果 |
| --- | --- |
| 顶层符号 | 原文件符号 **0 缺失**（严格超集）；原 2 条模块级裸调用**全部保真** |
| 函数体归一化比对 | 58 个共有对象 **54/58 逐字节相同**；4 处差异全部为有意的 helper 抽取 |
| 常量取值 | **39/39 完全相等**（type+value，两边真执行） |
| 全局态归属 | 每名**恰好 1 个 owner**，无越权 `global`，无 dotted access → 无陈旧读 |
| 导入环 | 包内 **CYCLES: NONE**；import 期无跨模块命名空间读 |
| `open()` 差分搜索 | **48/48 场景 OLD==NEW**（16 故障注入 × 3 前置状态） |
| `set_attr_safe` / `drop_silently` | 28 组 / 7 组差分 **DIVERGENT=0**（异常元组逐站点保真） |
| **`_unused` 抽取** | **DIVERGENT=2** —— 见下 |

- **核验 B 抓获的真实缺陷（P1，已修）**：我在 `_lineart._unused` 里多写了 `int()`，
  把原式 `block.users == 0` 变成 `int(block.users) == 0` → `users == 0.5` / `'0'` 时
  原实现**跳过**回收、我的实现**执行**回收（该调用点不在 try 内，差异会真外泄）。
  真实 bpy 的 `.users` 是整型，该分支**不可达**，但等价性不该依赖这个假设。
  **已改回 `block.users == 0` 并加注释说明"勿加 int()"**，并已用差分表复验修好。
- 核验 B 声明的**未能证明项**（如实转录）：未在真实 Blender 进程内跑；`.users` 非整数分支的
  可达性无法排除（按 RNA 类型声明判为不可达）；未覆盖 bpy/numpy 版本相关运行时差异。
  其中"未在真实 Blender 内跑"由本会话的 `test_capture_passes.py` 实跑补上。
- 核验 B 报的 `ai_generate ↔ script_actions` 导入环：**已核实为 HEAD 既有**（两向 import
  在 HEAD 同时存在），与本次拆分无关。

### 11.6 遗留（交作者）

- **GUI 实测**：**已通过**（作者热重载实测，生成通道全流程 / 纹理生成 / 修改图像 / 修改效果图 /
  对话 / 脚本生成与调试 / 通道预设增删 / 参考图维护，2026-10-15）。
- **提交**：由作者提交（AGENTS 硬红线，AI 不自行 commit；本次不推送）。
- **代码审查**：**已完成**（2026-10-15 由新上下文审查代理执行 L2 批次深度审查，
  独立跑了全量 gate.py 10/10 + HEAD↔现状逐函数体比对）。结论：**P0/P1/P2 无**，
  仅 2 项 P3 交作者拍板：① `pass-capture-refactor.md` 历史文档 8↔9 公共名口径漂移
  （已补横幅 ③）；② `_style_image_bytes` 内联后风格图字节路径分散两处直调（判不做，
  见下）。§11.5 的两个核验代理仍不构成审查，本条才是正式 `code-review` 结论。
- **本轮未做**（已判不做，见 §8）：D4 尺寸护栏骨架、C6 props 字段去重、`utils/__init__.py`
  汇聚写法对齐 §10 的 `import *`。
- **交作者裁定的 2 项**（核验提出，作者 2026-10-15 已定案并处置）：
  ① `pass_capture/_cache.py::group_of_channel` 为**存量死代码**（HEAD 亦无调用方）——**已删除**；
  ② `_check_pass_domain` 在 3 个模块各一份（各校验自己的表，模块私有、无交叉引用）——
  保留各自私有（无交叉引用，收敛为共用件反而引入跨模块耦合，收益为负）。
  另：CHANGELOG 登记的 `capture_fingerprint` 不含场景内容同族项——**已修**：
  `_scene_content_key` 提升为第 9 个公共名 `scene_content_key` 并纳入指纹（作者定案）。
- **审查 P3-2 判不做**（留档防重提）：`_style_image_bytes` 内联后，风格图字节路径分散在
  `style_refs.py` 收集与 `ai_render.GenerateRender` 组装两处直调 `image_to_scaled_png_bytes`。
  行为等价（缩放只作用副本），但未来若加风格图后处理钩子需两处同步。收益≈成本，
  **不做**（不为此引入单口，避免行为面扩大）。
- **环境说明**：核验 A 报告其会话内 `gate.py --quick` 为 6/7，唯一 FAIL 是其 Python 缺 `ruff`
  模块（环境缺口，非代码问题）；本会话全量档 **10/10**。
