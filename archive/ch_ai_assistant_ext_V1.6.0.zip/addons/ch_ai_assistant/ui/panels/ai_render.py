"""
图像生成器 · 效果图模式绘制段模块

不是面板: 由 ui/panels/ai_image.py 的合并面板在效果图模式下调用, 只画效果图专属内容——
- draw_pass_section: 生成通道段(通道预设下拉 / 通道两列网格 / 通道参数 / 通道迷你列表
  (行首发送勾选框) / 发送预算计数行 / 捕获输出估算与"生成通道"按钮), 整体融入
  Settings 子面板(分隔线以下, 无独立折叠小节)
- draw_render_prompt: 描述 / token 摘要 / 提示词工具 / 修改效果图·生成

公共设置(输出尺寸行 / 参考图 / 随机种 / 张数 / 负向提示)与列表、预览区都在合并面板里
(输出尺寸行由合并面板按 _SIZE_FIELDS 换字段组直接走共享 draw_size_settings, 本模块
不再包一层), 本模块不重复绘制; 发送通道的独立开关段已随行首勾选框移除, 只保留段尾的
发送预算计数行.
"""

from bpy.types import UILayout

from .....common.i18n.i18n import iface
from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt, resolve_prompt
from ...operators.ai_render import (
    CaptureViewRefs,
    GenerateRender,
    ModifyRender,
    PickDepthRange,
    PreviewRenderPrompt,
)
from ...operators.pass_presets import PassPresetsMenu
from ...operators.render_send import (
    _PASS_TOGGLES,
    _resolve_service,
    ClearPassBackups,
    collect_ref_images,
    collect_send_passes,
    resolve_render_request,
)
from ...operators.ai_texture import SaveAllImages, SaveImage
from ...operators.list_ops import DeleteImage
from ...utils import (
    AI_RENDER_PROMPT_TEXT_NAME,
    WARN_EDGE_PX,
    estimate_capture_bytes,
    estimate_prompt_tokens_cached,
    prompt_token_budget,
    resolve_capture_size,
    resolve_ref_limits,
)
from .blocks import (
    draw_greyed_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_operator,
    draw_right_aligned,
)

# 通道迷你列表的行数下限(空列表的矮框高度)与显示上限(裁决⑮: 备份多时面板不被拉长, 超出行内滚动)
_PASS_ROWS_MIN = 4
_PASS_ROWS_MAX = 10


def _size_text(num_bytes: int) -> str:
    """字节数转可读体积文案(不足 1MB 用 KB, 单位不翻译不入典)"""
    if num_bytes >= 1024 * 1024:
        return f"{num_bytes / (1024 * 1024):.1f} MB"
    return f"{num_bytes / 1024:.0f} KB"


# --------------------------------------------------------------------------- 生成通道小节


def _draw_pass_grid(sub, state) -> None:
    """参考通道两列网格(左 4 右 3, 纵向排布; 每项悬停看通道含义)"""
    grid = sub.row(align=False)
    left = grid.column(align=True)
    right = grid.column(align=True)
    left.prop(state, "use_combined")
    left.prop(state, "use_depth")
    left.prop(state, "use_normal")
    left.prop(state, "use_segmentation")
    right.prop(state, "use_edge")
    right.prop(state, "use_diffuse")
    right.prop(state, "use_ao")


def _draw_pass_params(sub, state, cstate) -> None:
    """通道设置 box: 常驻开关两行(钳制在面板状态/采样数在场景参数组) + 已开启通道各自的生成参数

    整列属性分栏; 参数按通道顺序排布, 只显示已开启通道的项.
    通道勾选(use_*)是面板状态(state), 通道生成参数是场景挂载的 RNA 组(cstate).
    """
    pbox = sub.box()
    pbox.use_property_split = True
    # 场景挂载的参数属可动画 ID 属性, 默认会画出行尾动画修饰钮(菱形);
    # 这些是生成参数不是动画目标, 关掉修饰(rna_prop_ui 画自定义属性同款处理)
    pbox.use_property_decorate = False
    # 钳制开关(面板状态)为通道生成专属, 采样数(场景参数)为常驻项(与具体通道无关):
    # 两行都是与具体通道无关的常驻设置, 钳制在采样上方(作者指定次序)
    pcol = pbox.column()
    pcol.prop(state, "use_clamp_resolution")
    pcol.prop(cstate, "render_samples")
    if state.use_depth:
        # 深度拾取按钮必须排在 depth_range 属性**之后**且**同一行内**: 只有落在值列才能
        # 与上下数值列左右对齐.prop() 先调以建立行内分裂, 之后追加的按钮即落进值格;
        # 行内不要再设 use_property_split(分裂已由父列继承, 再设会另起一层).
        pcol = pbox.column()
        brow = pcol.row(align=True)
        brow.prop(cstate, "depth_range")
        sub_row = brow.row()
        sub_row.scale_y = 2
        draw_operator(sub_row, PickDepthRange.bl_idname, None, 'UV_SYNC_SELECT', text="")
        pcol.row().prop(cstate, "depth_curve", expand=True)
    if state.use_normal:
        pcol = pbox.column()
        pcol.row().prop(cstate, "normal_convention", expand=True)
    if state.use_segmentation:
        pcol = pbox.column()
        pcol.row().prop(cstate, "cryptomatte_source", expand=True)
        pcol.prop(cstate, "crypto_slots")
        pcol.prop(cstate, "smooth_seg_edges")
    if state.use_edge:
        pcol = pbox.column()
        # 先选画什么线(预设), 再调多宽(系数); 末项为材质之间是否出笔画
        pcol.prop(cstate, "edge_preset")
        pcol.prop(cstate, "edge_width_scale")
        pcol.prop(cstate, "use_material_borders")
    if state.use_ao:
        pcol = pbox.column()
        pcol.prop(cstate, "ao_distance")


def _draw_pass_list(sub, state) -> None:
    """通道迷你列表(常驻): 右侧竖列为保存当前 / 保存全部 / 清除备份 / 删除

    通道图不进主列表与画廊(列表分离), 回看在面板内完成; 删除联动清理发送缓存对应通道.
    """
    sub.label(text="Pass List:", icon='IMAGE_DATA')
    list_row = sub.row(align=True)
    list_row.template_list("CH_UL_ai_images", "ch_ai_pass_images", state, "pass_images", state, "pass_images_active_index", rows=max(_PASS_ROWS_MIN, min(len(state.pass_images), _PASS_ROWS_MAX)))
    has_sel = 0 <= state.pass_images_active_index < len(state.pass_images)
    btn_col = list_row.column(align=False)
    save_one = btn_col.row(align=False)
    save_one.enabled = has_sel
    draw_operator(save_one, SaveImage.bl_idname, 'PASS', 'FILE_TICK', text="")
    save_all = btn_col.row(align=False)
    save_all.enabled = has_sel
    draw_operator(save_all, SaveAllImages.bl_idname, 'PASS', 'OUTPUT', text="")
    # 一键清除重新捕获时保留的 "_bak" 备份(无备份时按钮自身置灰)
    draw_operator(btn_col.row(align=False), ClearPassBackups.bl_idname, None, 'TRACKING_CLEAR_BACKWARDS', text="")
    del_btn = btn_col.row(align=False)
    del_btn.enabled = has_sel
    draw_operator(del_btn, DeleteImage.bl_idname, 'PASS', 'X', text="")


def _draw_capture_info(sub, state, cstate, scene, provider, prefs) -> None:
    """捕获输出标签: 像素尺寸 + 落盘体积估算 + 长边超阈值的提醒

    标签与实际渲染同口径(未开钳制即 Blender 输出分辨率乘百分比); 体积为按各通道落盘格式
    的估算值, 能提前暴露"通道图另作他用时的大体积"(超阈值只提醒不禁止).
    """
    _limit_count, limit_edge = resolve_ref_limits(provider, prefs)
    clamp_edge = limit_edge if state.use_clamp_resolution else 0
    cap_w, cap_h = resolve_capture_size(scene, clamp_edge)
    keys = [key for attr, key in _PASS_TOGGLES if getattr(state, attr)]
    estimate = estimate_capture_bytes((cap_w, cap_h), keys, cstate.crypto_slots)
    draw_greyed_row(sub, iface("Capture output: {} x {} ({})").format(cap_w, cap_h, _size_text(estimate)), align='LEFT')
    if max(cap_w, cap_h) > WARN_EDGE_PX:
        draw_greyed_row(sub, iface("Long edge above {} px, the pass images will be large").format(WARN_EDGE_PX), icon='ERROR', align='LEFT')


def draw_pass_section(layout: UILayout, scene, state, provider: str, prefs) -> None:
    """生成通道段(仅效果图模式, 整体融入 Settings 子面板: 分隔线以下, 无独立折叠小节)

    "捕获什么通道, 怎么触发捕获"与"发送哪些通道"同段安置: 发送选择收在通道迷你列表
    行首勾选框(见 ui/lists/images.py), 段尾保留发送预算计数行.
    标题原文用 "Pass Generation" 而非 "Passes"(后者是系统词条, 只能改原文反译);
    标题行最右侧挂通道预设下拉(内置 base/all 两档, 图标同原生格式预设).
    """
    layout.separator(type='LINE')
    head = layout.column(align=True)
    row = head.row(align=True)
    row.label(text="Pass Generation", icon='RENDERLAYERS')
    preset_row = draw_right_aligned(row)
    preset_row.menu(PassPresetsMenu.bl_idname, text="", icon='PRESET')
    sub = layout.column()
    sub.use_property_split = False
    _draw_pass_grid(sub, state)
    sub.separator(type='LINE')
    _draw_pass_params(sub, state, scene.ch_ai_capture_params)
    sub.separator(type='LINE')
    _draw_pass_list(sub, state)
    _draw_send_hint(sub, state, scene, provider, prefs)
    _draw_capture_info(sub, state, scene.ch_ai_capture_params, scene, provider, prefs)
    # 生成通道: 本地渲染所选通道并在图像编辑器预览(不调用 AI 服务, 不产生费用)
    draw_operator(sub, CaptureViewRefs.bl_idname, None, 'RENDERLAYERS')


# --------------------------------------------------------------------------- 发送预算计数行


def _draw_send_hint(col, state, scene, provider, prefs) -> None:
    """发送预算计数行(置灰, 左对齐): 已勾选通道与风格参考图合计的"将发送 N 张参考图"

    发送通道段移除后面板仅保留本行; 勾选但未捕获的通道不计数(生成时会被阻断并点名),
    超限截断与参考图死引用同样改由生成操作的 report 兜底提示. 与下方捕获输出行同靠左.
    """
    limit_count, _limit_edge = resolve_ref_limits(provider, prefs)
    # 计数行丢弃 stale 值, 关掉指纹计算(全场景扫描) —— 每帧重绘都不该付这笔开销
    send_names, _missing, _stale = collect_send_passes(state, scene, _limit_edge, check_stale=False)
    style_count = len(collect_ref_images(state, for_draw=True))
    total = len(send_names) + style_count
    info = col.column(align=True)
    info.enabled = False
    if limit_count > 0:
        draw_greyed_row(info, iface("Send {} / {} reference images").format(total, limit_count), align='LEFT')
    else:
        draw_greyed_row(info, iface("Send {} reference images").format(total), align='LEFT')


# --------------------------------------------------------------------------- 提示词摘要


def _draw_token_summary(col, state, scene, provider, prefs, sstate) -> None:
    """提示词 token 摘要(置灰右对齐): 与发送组装同口径(resolve_render_request 预览档)

    超硬预算(百炼, 服务端静默截断)与超软建议(方舟, 模型可能忽略细节)措辞区分;
    描述为空时不显示; 组装失败(预算名额不足等)同样不显示.
    """
    prompt_text = resolve_prompt(AI_RENDER_PROMPT_TEXT_NAME, state.render_prompt)
    if not prompt_text:
        return
    _provider, _base_url, _api_key, limits = _resolve_service(sstate, prefs)
    # token 摘要只用到组装出的提示词(notices 一并丢弃), 关掉指纹计算(全场景扫描);
    # "预览可能过期"提示由真正发送/预览算子路径负责
    err, _notices, _names, _styles, full_prompt = resolve_render_request(state, scene, prompt_text, provider, limits[0], limits[1], require_captured=False, check_stale=False)
    if err is not None:
        return
    budget, hard = prompt_token_budget(provider)
    # 缓存版: 逐字符估算纯 Python 扫描是本行主导成本, draw 每帧重绘都跑(MB 级长文可感)
    tokens = estimate_prompt_tokens_cached(full_prompt)
    if budget > 0 and tokens > budget:
        if hard:
            draw_greyed_row(col, iface("Prompt: about {} tokens / {} budget, " "it will be truncated").format(tokens, budget), icon='ERROR')
        else:
            draw_greyed_row(col, iface("Prompt: about {} tokens / {} suggestion, " "the model may miss details").format(tokens, budget), icon='ERROR')
    elif budget > 0:
        draw_greyed_row(col, iface("Prompt: about {} tokens / {} budget").format(tokens, budget))
    else:
        draw_greyed_row(col, iface("Prompt: about {} tokens").format(tokens))


# --------------------------------------------------------------------------- 描述与操作


def draw_render_prompt(layout: UILayout, state, scene, provider: str, prefs, sstate) -> None:
    """效果图描述与操作行: 描述框 + 负向 + 长文提示 + token 摘要 + 提示词工具 + 修改/生成

    长文描述块与完整提示词块按效果图分开(AI_Render_Prompt.txt / AI_Render_Final_Prompt.txt).
    """
    layout.separator(type='LINE')
    col = layout.column(align=False)
    prompt_row = col.row(align=True)
    prompt_row.prop(state, "render_prompt", text="Prompt")
    draw_operator(prompt_row, ClearPrompt.bl_idname, 'RENDER', 'CANCEL_LARGE', text="")
    draw_negative_row(col, state, provider, 'RENDER')
    draw_long_desc_hint(col, AI_RENDER_PROMPT_TEXT_NAME)
    _draw_token_summary(col, state, scene, provider, prefs, sstate)
    row = col.row(align=True)
    draw_operator(row, EditPrompt.bl_idname, 'RENDER', 'TEXT')
    row.separator(factor=0.5)
    draw_operator(row, OptimizePrompt.bl_idname, 'RENDER', 'SHADERFX')
    row.separator(factor=0.5)
    draw_operator(row, PreviewRenderPrompt.bl_idname, None, 'WORDWRAP_ON')
    # 操作行: 修改在左(高亮效果图产物为参考图), 生成在右
    # (捕获按钮"生成通道"已移入上方 Settings 内的生成通道段)
    row = col.row(align=True)
    draw_operator(row, ModifyRender.bl_idname, None, 'GREASEPENCIL')
    row.separator(factor=0.5)
    draw_operator(row, GenerateRender.bl_idname, None, 'KEY_RETURN')
