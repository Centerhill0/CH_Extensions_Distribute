"""
图像生成器 · 图像侧(材质贴图 / 图像)绘制段模块

不是面板: 由 ui/panels/ai_image.py 的合并面板按当前模式调用, 只画图像侧的专属内容——
- draw_image_settings: 输出尺寸(1K/2K 方图或画幅比率) + 无缝(仅材质贴图模式显示)
- draw_reference_count: 参考图发送计数行(仅图像侧两种模式, 渲染侧自带发送预算行)
- draw_channel_section: 材质通道段(仅材质贴图模式, 两步工作流第二步:
  颜色源行/贴图无缝/通道勾选网格/生成按钮/材质贴图产物迷你列表)
- draw_image_prompt: 描述 / 负向 / 长文提示 / 三个提示词工具 / 修改图像·生成

设置小节的外壳(折叠头与公共段)在合并面板里, 本模块只提供模式专属段.
"""

from bpy.types import UILayout

from .....common.i18n.i18n import iface
from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt
from ...operators.ai_texture import (
    ClearChannelSource,
    GenerateTexture,
    GenerateTextureChannels,
    LoadChannelSource,
    ModifyImage,
    PreviewTexturePrompt,
    SaveAllImages,
    SaveImage,
    channel_source_available,
)
from ...operators.channel_presets import MaterialChannelPresetsMenu
from ...operators.image_common import collect_ref_entries
from ...operators.list_ops import DeleteImage
from ...utils import AI_TEXTURE_PROMPT_TEXT_NAME, TEXTURE_CHANNEL_KEYS, resolve_ref_limits
from .blocks import (
    IMAGE_SIZE_FIELDS,
    TEX_SIZE_FIELDS,
    draw_greyed_row,
    draw_long_desc_hint,
    draw_negative_row,
    draw_operator,
    draw_right_aligned,
    draw_size_settings,
)

# 材质贴图迷你列表的行数下限(空列表的矮框高度)与显示上限(超出行内滚动, 与渲染侧通道列表同款)
_TEX_ROWS_MIN = 4
_TEX_ROWS_MAX = 10


def draw_image_settings(layout: UILayout, state, provider: str, model: str) -> None:
    """图像侧输出尺寸段: 分辨率 + 实际输出(材质贴图与图像各一套字段, 切模式互不覆盖)

    - 材质贴图: 1K/2K 方图 + 自定义(锁定钮仅自定义档可用);
    - 图像: 常用宽高比 + 自定义;
    两档宽高恒可编辑(切档位经回填联动, 手动改值即回落自定义档).
    provider/model 由合并面板解析后传入(尺寸约束与实际下发值同口径);
    无缝贴图与张数等项由合并面板按固定次序插在本段之后.
    """
    if state.mode == 'IMAGE':
        draw_size_settings(layout, state, IMAGE_SIZE_FIELDS, provider, model, lock_enabled=True)
        return
    draw_size_settings(layout, state, TEX_SIZE_FIELDS, provider, model, lock_enabled=state.tex_size_preset == 'CUSTOM')


def draw_reference_count(sub: UILayout, state, provider: str, prefs) -> None:
    """参考图发送计数行(置灰左对齐): 勾选激活的参考图条目数 vs 服务商张数上限

    与效果图侧发送预算行同口径; 渲染模式的计数含通道图, 由渲染段自带, 不在此重复.
    """
    limit_count, _edge = resolve_ref_limits(provider, prefs)
    total = len(collect_ref_entries(state, "use_ref_images", "ref_images", for_draw=True))
    info = sub.column(align=True)
    info.enabled = False
    if limit_count > 0:
        draw_greyed_row(info, iface("Send {} / {} reference images").format(total, limit_count), align='LEFT')
    else:
        draw_greyed_row(info, iface("Send {} reference images").format(total), align='LEFT')


def draw_channel_section(layout: UILayout, state, provider: str, prefs) -> None:
    """材质通道段(仅材质贴图模式, 整体融入 Settings: 分隔线以下, 无独立折叠小节)

    两步工作流第二步: 以颜色贴图为源派生勾选的通道贴图. 标题行最右侧挂通道预设下拉
    (内置 base/all 两档, 与渲染侧通道预设同款); 颜色源行左对齐, 行末为磁盘载入与
    清除(回落列表高亮)按钮; "贴图无缝"声明发送的颜色贴图可平铺与否(其它通道天然与之一致,
    说明随提示词发送只为生成准确), 收在通道网格下方的参数 box(同渲染侧钳制项样式);
    生成按钮在无有效源或未勾选任何通道时置灰; 段尾为材质贴图产物迷你列表
    (AI Tex 前缀: 颜色贴图/通道贴图/修改备份同列, 不进主列表).
    """
    layout.separator(type='LINE')
    head = layout.column(align=True)
    row = head.row(align=True)
    row.label(text="Material Channels", icon='TEXTURE')
    preset_row = draw_right_aligned(row)
    preset_row.menu(MaterialChannelPresetsMenu.bl_idname, text="", icon='PRESET')
    sub = layout.column()
    source_row = sub.row(align=True)
    source_row.prop(state, "channel_source")
    draw_operator(source_row, LoadChannelSource.bl_idname, None, 'FILE_FOLDER', text="")
    clear_wrap = source_row.row(align=False)
    clear_wrap.enabled = state.channel_source is not None
    draw_operator(clear_wrap, ClearChannelSource.bl_idname, None, 'X', text="")
    grid = sub.row(align=False)
    # 两列网格按列序排布(作者定): 左列自上而下 金属度/糙度/法向, 右列 凹凸/置换/AO
    left = grid.column(align=True)
    right = grid.column(align=True)
    left.prop(state, "use_channel_metallic")
    left.prop(state, "use_channel_roughness")
    left.prop(state, "use_channel_normal")
    right.prop(state, "use_channel_bump")
    right.prop(state, "use_channel_displacement")
    right.prop(state, "use_channel_ao")
    # 分隔线口径与渲染侧生成通道段一致: 网格 | 参数 box | 列表 | 生成按钮(收尾) 各自成簇
    sub.separator(type='LINE')
    # 通道参数 box(样式同渲染侧"钳制输出分辨率"所在的通道参数段): "贴图无缝"声明
    # 发送的颜色贴图本身可平铺与否, 其它通道天然与之一致
    pbox = sub.box()
    pbox.use_property_split = True
    pbox.use_property_decorate = False
    pbox.prop(state, "use_channel_seamless")
    sub.separator(type='LINE')
    _draw_tex_list(sub, state)
    # 生成按钮在列表下方收尾(与渲染侧"生成通道"按钮同款), 无有效源或未勾选任何通道时置灰
    gen_row = sub.row(align=True)
    gen_row.enabled = channel_source_available(state) and any(getattr(state, f"use_channel_{key}") for key in TEXTURE_CHANNEL_KEYS)
    draw_operator(gen_row, GenerateTextureChannels.bl_idname, None, 'KEY_RETURN')


def _draw_tex_list(sub: UILayout, state) -> None:
    """材质贴图产物迷你列表(常驻): 右侧竖列为保存当前 / 保存全部 / 删除

    与渲染侧通道列表同款(target 'TEX' 区分); AI Tex 前缀产物(颜色贴图/通道贴图/修改备份)
    收在此列表, 不进主列表与画廊; 点击行跟随颜色源并按面板开关聚焦图像编辑器.
    """
    sub.label(text="Channel List:", icon='IMAGE_DATA')
    list_row = sub.row(align=True)
    list_row.template_list("CH_UL_ai_images", "ch_ai_tex_images", state, "tex_images", state, "tex_images_active_index", rows=max(_TEX_ROWS_MIN, min(len(state.tex_images), _TEX_ROWS_MAX)))
    has_sel = 0 <= state.tex_images_active_index < len(state.tex_images)
    btn_col = list_row.column(align=False)
    save_one = btn_col.row(align=False)
    save_one.enabled = has_sel
    draw_operator(save_one, SaveImage.bl_idname, 'TEX', 'FILE_TICK', text="")
    save_all = btn_col.row(align=False)
    save_all.enabled = has_sel
    draw_operator(save_all, SaveAllImages.bl_idname, 'TEX', 'OUTPUT', text="")
    del_btn = btn_col.row(align=False)
    del_btn.enabled = has_sel
    draw_operator(del_btn, DeleteImage.bl_idname, 'TEX', 'X', text="")


def draw_image_prompt(layout: UILayout, state, provider: str) -> None:
    """图像侧描述与操作行: 描述框 + 负向提示 + 长文提示 + 提示词工具 + 修改/生成

    长文描述块与完整提示词块按图像侧分开(AI_Texture_Prompt.txt / AI_Texture_Final_Prompt.txt),
    与效果图模式互不覆盖.
    """
    layout.separator(type='LINE')
    col = layout.column(align=False)
    prompt_row = col.row(align=True)
    prompt_row.prop(state, "tex_prompt", text="Prompt")
    draw_operator(prompt_row, ClearPrompt.bl_idname, 'TEXTURE', 'CANCEL_LARGE', text="")
    # 负向提示: 仅支持该参数的服务商显示(简短输入, 行尾清除按钮)
    draw_negative_row(col, state, provider, 'TEXTURE')
    draw_long_desc_hint(col, AI_TEXTURE_PROMPT_TEXT_NAME)
    # 编辑描述 / 优化提示词(读 AI 服务面板的文本服务设置) / 完整提示词(与发送逐字一致)
    row = col.row(align=True)
    draw_operator(row, EditPrompt.bl_idname, 'TEXTURE', 'TEXT')
    row.separator(factor=0.5)
    draw_operator(row, OptimizePrompt.bl_idname, 'TEXTURE', 'SHADERFX')
    row.separator(factor=0.5)
    draw_operator(row, PreviewTexturePrompt.bl_idname, None, 'WORDWRAP_ON')
    # 修改图像在左(以高亮图像为参考图), 生成在右(名称随模式动态显示)
    # (文案直接写在调用处而非先取变量: 按钮文字是用户可见元素, 静态上应可查)
    row = col.row(align=True)
    draw_operator(row, ModifyImage.bl_idname, None, 'GREASEPENCIL')
    row.separator(factor=0.5)
    draw_operator(row, GenerateTexture.bl_idname, None, 'KEY_RETURN', text="Generate Texture" if state.mode == 'TEXTURE' else "Generate Image")
