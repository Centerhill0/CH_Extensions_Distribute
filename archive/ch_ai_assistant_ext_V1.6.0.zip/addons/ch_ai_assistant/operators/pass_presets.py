"""
通道预设下拉菜单模块

效果图模式"生成通道"标题行右侧的预设下拉(图标与原生输出属性格式预设同款), 提供两档
内置预设整组写回捕获开关: base = 只勾选合并结果与深度(出厂默认勾选), all = 全部通道.
预设为内置定值不落盘, 无自定义增删; 发送选择收在通道列表行首勾选框
(见 items.pass_send_attr), 不进预设.
菜单条目名仿原生预设的条目口径(预设名是数据不是文案), 保持原样不翻译.
"""

from bpy.types import Context
from bpy.types import Menu
from bpy.types import Operator
from bpy.props import StringProperty


from .render_send import _PASS_TOGGLES

# 内置通道预设: 键为菜单条目名, 值为捕获开关组的整组取值
# (base 对齐出厂默认勾选: 合并结果 + 深度, 其余全关)
_BUILTIN_PRESETS = {
    "base": {attr: key in ("combined", "depth") for attr, key in _PASS_TOGGLES},
    "all": {attr: True for attr, _key in _PASS_TOGGLES},
}

_PRESET_ORDER = ("base", "all")


class ApplyPassPreset(Operator):
    """
    应用通道预设操作器

    功能: 把指定内置通道预设的捕获开关取值整组写回面板; 预设项由 PassPresetsMenu
    菜单列出, 条目经 preset 属性下发应用档.
    """

    bl_idname = "ch_ai.apply_pass_preset"
    bl_label = "Apply Pass Preset"
    bl_description = "Apply the pass preset to the capture toggles"
    bl_options = {'REGISTER', 'UNDO'}

    # 经菜单条目回填的载荷(用户不可见, 按运行期状态口径带 HIDDEN, 不必补 description)
    preset: StringProperty(name="Preset", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        toggles = _BUILTIN_PRESETS.get(self.preset)
        if toggles is None:
            self.report({'WARNING'}, "Unknown pass preset")
            return {'CANCELLED'}
        state = context.window_manager.ch_ai_image_state
        for attr, value in toggles.items():
            setattr(state, attr, value)
        return {'FINISHED'}


class PassPresetsMenu(Menu):
    """
    通道预设下拉菜单

    功能: 列出内置通道预设条目(base/all), 落 ApplyPassPreset 应用到捕获通道开关;
    菜单按钮挂在"生成通道"标题行右侧, 图标与原生格式预设同款(icon='PRESET').
    """

    bl_idname = "CH_AI_MT_pass_presets"
    bl_label = "Channel Presets"

    def draw(self, _context):
        layout = self.layout
        for name in _PRESET_ORDER:
            op = layout.operator(ApplyPassPreset.bl_idname, text=name)
            op.preset = name
