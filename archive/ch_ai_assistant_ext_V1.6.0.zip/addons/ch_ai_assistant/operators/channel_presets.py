"""
材质通道预设下拉菜单模块

材质贴图模式"材质通道"标题行右侧的预设下拉(与效果图通道预设同款交互), 提供两档
内置预设整组写回通道勾选: base = 粗糙度+金属度+法向, all = 全部六通道.
预设为内置定值不落盘, 无自定义增删.
菜单条目名仿原生预设的条目口径(预设名是数据不是文案), 保持原样不翻译.
"""

from bpy.types import Context
from bpy.types import Menu
from bpy.types import Operator
from bpy.props import StringProperty


from ..utils import TEXTURE_CHANNEL_KEYS

# 内置材质通道预设: 键为菜单条目名, 值为勾选的通道键集
# (base 覆盖材质常驻三通道: 粗糙度/金属度/法向)
_BUILTIN_PRESETS = {
    "base": ('roughness', 'metallic', 'normal'),
    "all": TEXTURE_CHANNEL_KEYS,
}

_PRESET_ORDER = ("base", "all")


class ApplyChannelPreset(Operator):
    """
    应用材质通道预设操作器

    功能: 把指定内置材质通道预设的勾选取值整组写回面板; 预设项由 MaterialChannelPresetsMenu
    菜单列出, 条目经 preset 属性下发应用档.
    """

    bl_idname = "ch_ai.apply_channel_preset"
    bl_label = "Apply Channel Preset"
    bl_description = "Apply the material channel preset to the channel toggles"
    bl_options = {'REGISTER', 'UNDO'}

    # 经菜单条目回填的载荷(用户不可见, 按运行期状态口径带 HIDDEN, 不必补 description)
    preset: StringProperty(name="Preset", options={'HIDDEN'})  # type: ignore

    def execute(self, context: Context):
        keys = _BUILTIN_PRESETS.get(self.preset)
        if keys is None:
            self.report({'WARNING'}, "Unknown channel preset")
            return {'CANCELLED'}
        state = context.window_manager.ch_ai_image_state
        for key in TEXTURE_CHANNEL_KEYS:
            setattr(state, f"use_channel_{key}", key in keys)
        return {'FINISHED'}


class MaterialChannelPresetsMenu(Menu):
    """
    材质通道预设下拉菜单

    功能: 列出内置材质通道预设条目(base/all), 落 ApplyChannelPreset 应用到通道勾选;
    菜单按钮挂在"材质通道"标题行右侧, 图标与原生格式预设同款(icon='PRESET').
    """

    bl_idname = "CH_AI_MT_material_channel_presets"
    bl_label = "Channel Presets"

    def draw(self, _context):
        layout = self.layout
        for name in _PRESET_ORDER:
            op = layout.operator(ApplyChannelPreset.bl_idname, text=name)
            op.preset = name
