"""
提示词模板集中模块(单一来源)

集中管理「静态,跨流复用」的提示词正文, 供 ai_client(文本/脚本)与 image_client(图像)引用.
提示词是插件与模型交互的"契约", 改动会直接影响生成质量与下游解析, 故:

- 每条提示词带语义说明注释(改什么/为什么), 措辞只可重构不可改语义;
- 输出格式契约的锚点关键字与解析端正则通过共享常量 SCRIPT_NAME_ANCHOR 绑定, 防漂移;
- 模块级 VERSION 记录提示词整体版本, 便于追踪提示词变更历史;
- 模块级契约自检(_check_contract)在 import 时断言锚点一致性, 改错立即报错.

收口边界(刻意为之): 只收「静态提示词数据」(system 提示词 / 无缝后缀 / 通道角色表等),
**不收**「带变量插值的用户消息组装」(如 build_debug_messages 的 "Find the bug...",
build_texture_prompt 的 "Image N: ..." 重绘句)——那些指令与变量填充点紧耦合,
抽成常量反而割裂"改一句"的上下文, 故留在各自 client 的组装函数里内联.

组织: 文本/脚本侧(System/Body/OutputContract/Optimize/AutoName), 图像侧(Texture/Render).
"""

import re

# 提示词整体版本号: 提示词正文有语义性改动时递增(纯注释/排版调整可不递增).
# v1: 从 ai_client/image_client 外置到本模块, 加契约锚点自检(初始版本).
VERSION = 1

# ---------------------------------------------------------------------------
# 契约锚点: 输出格式契约里要求模型写出的命名行关键字, 也是解析端正则匹配的关键字.
# 二者必须一致, 由 _check_contract 保证. 单独抽常量即"单一来源", 改关键字只改这一处.
# ---------------------------------------------------------------------------
SCRIPT_NAME_ANCHOR = "script-name"


def _check_contract() -> None:
    """契约自检: 锚点关键字须同时出现在契约正文与解析正则里, 任一漂移立即抛错

    若提示词里改用了别的命名行关键字(如 name-line), 而正则仍匹配 script-name,
    会导致模型按新契约输出,解析端却匹配不到, 脚本名解析静默失效.
    """
    if SCRIPT_NAME_ANCHOR not in SYSTEM_PROMPT_OUTPUT_CONTRACT:
        raise AssertionError("输出契约未包含 SCRIPT_NAME_ANCHOR 锚点")
    if not NAME_LINE_RE.match(f"# {SCRIPT_NAME_ANCHOR}: demo.py"):
        raise AssertionError("命名行解析正则与 SCRIPT_NAME_ANCHOR 锚点不一致")


# ---------------------------------------------------------------------------
# 文本 / 脚本周提示词
# ---------------------------------------------------------------------------

# 系统提示词正文: 任务与风格要求在前; 输出格式契约单独成块固定于 system 消息末尾——
# 模型对 system 尾部内容的遵循度更高, 且契约是解析端(extract_script_name/strip_code_fences)
# 依赖的锚点, 措辞只可重构不可改语义
SYSTEM_PROMPT_BODY = (
    "Write a complete, self-contained Python script using the bpy API. "
    "Prefer APIs available in this Blender version and avoid APIs removed before it. "
    "The script must import bpy by itself and run directly in Blender's text editor. "
    "Prefer simple and robust code, with short comments for key steps."
)

# 输出格式契约(生成/调试/修改三条脚本流共用), 分条列出并置于 system 末尾.
# 命名行关键字来自 SCRIPT_NAME_ANCHOR 共享常量(见文件头契约说明)
SYSTEM_PROMPT_OUTPUT_CONTRACT = (
    "Output format:\n"
    "1. The response must start with a single comment line in the exact form "
    f"'# {SCRIPT_NAME_ANCHOR}: <short_name>.py', where <short_name> is a short snake_case name "
    "describing what the script does.\n"
    "2. After that line, output the complete script, starting with a short module "
    "docstring (one or two lines) briefly describing the script's purpose.\n"
    "3. No explanations and no markdown code fences."
)

# 注释语言指令: 按偏好键取用, 未知值回落英文
COMMENT_LANGUAGE_DIRECTIVES = {
    'CHINESE': "Write all code comments in Chinese.",
    'ENGLISH': "Write all code comments in English.",
}

# 纯文本对话系统提示词: 不生成脚本文件, 按提问语言作答
CHAT_SYSTEM_PROMPT = "You are a helpful Blender assistant. " "Answer in plain text, concise and accurate. " "Reply in the same language as the user's message. " "Only include short code snippets when they are explicitly asked for."

# 自动命名系统提示词: 由提示词给出简短英文 snake_case 名(数据块名/列表/缩略图标签都要 ASCII,
# 非 ASCII 会在缩略图标签上乱码, 故只接受 ASCII 字母数字下划线)
AUTO_NAME_SYSTEM = (
    "You name images for a Blender asset library. "
    "Given the user's description of an image, reply with ONLY a short English snake_case name "
    "describing it, at most four words (for example: light_oak_wood_planks). "
    "Use ASCII letters, digits and underscores only: no quotes, no punctuation, no explanation."
)


# ---------------------------------------------------------------------------
# 提示词优化系统提示词
# 把粗略需求改写成清晰完整的需求描述, 只输出优化后的描述本身.
# 按优化目标分派: 文本面板改写成"需求描述"(给脚本生成用), 图像面板改写成"画面描述"
# (给文生图/图生图用) —— 二者语义不同, 用同一个脚本口吻的系统提示词会把贴图描述
# 改写成"编写一个脚本生成..."的脚本需求(实测缺陷).
# 每条完整内联,独立可读(提示词需逐字微调, 不抽共享片段以保持"改一句不牵连他句").
# ---------------------------------------------------------------------------

PROMPT_OPTIMIZE_SYSTEM = (
    "You are a Blender scripting assistant. "
    "Rewrite the user's request into a clear, complete and unambiguous description "
    "of the script they need: expected behaviour, objects and data involved, and any "
    "useful details. Output ONLY the optimized description text, "
    "no explanations, no markdown. Reply in the same language as the user's message."
)

# 材质贴图提示词优化: 产出给文生图模型用的材质贴图画面描述(不涉及脚本/场景物体)
TEXTURE_PROMPT_OPTIMIZE_SYSTEM = (
    "You are an assistant that writes prompts for a text-to-image model. "
    "The image to produce is a material texture (albedo map) for 3D rendering, "
    "not a rendered scene: describe the surface itself - material type, color, pattern, "
    "grain, wear and fine detail - so it fills the whole frame as a flat texture. "
    "Never mention cameras, lights, scenes, objects, code, scripts or file formats. "
    "Rewrite the user's request into such a prompt: clear, complete and unambiguous. "
    "Output ONLY the optimized description text, no explanations, no markdown. "
    "Reply in the same language as the user's message."
)

# 通用图像提示词优化: 产出给文生图模型用的任意图像描述("材质贴图"关闭即图像模式时使用,
# 不再导向材质贴图画面)
IMAGE_PROMPT_OPTIMIZE_SYSTEM = (
    "You are an assistant that writes prompts for a text-to-image model. "
    "Rewrite the user's request into a clear, complete and unambiguous description "
    "of the picture to generate: subject, scene, composition, art style, lighting "
    "and mood, with useful detail. It can be any kind of photo or image. "
    "Never mention code, scripts or file formats. "
    "Output ONLY the optimized description text, no explanations, no markdown. "
    "Reply in the same language as the user's message."
)

# 效果图提示词优化: 产出给图生图模型用的风格描述(构图由参考图决定, 不重复描述物体摆放)
RENDER_PROMPT_OPTIMIZE_SYSTEM = (
    "You are an assistant that writes prompts for an image editing model that restyles "
    "a reference render of a 3D scene. The camera composition and object placement come "
    "from the reference image, so describe only the desired look: art style, mood, "
    "lighting, color treatment, materials and level of detail. "
    "Never mention code, scripts, file formats or how to implement it in Blender. "
    "Rewrite the user's request into such a prompt: clear, complete and unambiguous. "
    "Output ONLY the optimized description text, no explanations, no markdown. "
    "Reply in the same language as the user's message."
)

# 优化目标 -> 系统提示词(标识与 OptimizePrompt 的 target 枚举一致;
# IMAGE 为图像模式的通用图像口吻(材质贴图模式走 TEXTURE 口吻))
OPTIMIZE_SYSTEMS = {
    'SCRIPT': PROMPT_OPTIMIZE_SYSTEM,
    'TEXTURE': TEXTURE_PROMPT_OPTIMIZE_SYSTEM,
    'IMAGE': IMAGE_PROMPT_OPTIMIZE_SYSTEM,
    'RENDER': RENDER_PROMPT_OPTIMIZE_SYSTEM,
}


# ---------------------------------------------------------------------------
# 图像提示词模板(材质贴图 / 效果图)
# ---------------------------------------------------------------------------

# 无缝平铺引导后缀(强调版): 以 IMPORTANT 领起强调必须无缝可平铺——
# 除"无可见接缝 + 光照/阴影/渐晕/渐变禁止"外, 明确要求图案以**均匀尺度与间距重复**,
# **跨图幅边界延续**(重复时自匹配)且**无透视**(实测参考图带透视时模型倾向复刻其透视与
# 不均匀排布, 光"seamless"不足以压住); 不出现边缘羽化/混合一类的处理措辞(羽化属本地
# 像素处理, 不进提示词)
TEXTURE_SEAMLESS_SUFFIX = (
    ". IMPORTANT: this must be a perfectly seamless tileable texture that repeats "
    "infinitely with absolutely no visible seams: the pattern repeats at a uniform "
    "scale and spacing across the entire image and continues across the image "
    "borders, so the tile matches itself when repeated; flat even lighting, "
    "no shadows, no vignetting, no gradients at the image borders, "
    "top-down orthographic view with no perspective"
)

# 基础贴图引导后缀(非平铺): 满幅材质纹理/受光均匀/正交顶视
TEXTURE_BASE_SUFFIX = ", full-frame material texture, flat even lighting, top-down orthographic view"

# 材质通道转换指令(键 = 通道键, 与 script_io.TEXTURE_CHANNEL_SUFFIXES 对齐):
# 每条写"从颜色参考得到什么图 + 灰度/颜色语义方向 + 该通道的关键反直觉约定"
# (粗糙度/金属度要忽略参考图里的烘焙光照, 金属度默认非金属, 法向不烘焙光影, AO 无材质细节)
TEXTURE_CHANNEL_TASKS = {
    'roughness': "a grayscale roughness map for a PBR material: brighter areas are rough and matte, darker areas are smooth and glossy; read the surface finish from the color reference and ignore its baked lighting, shadows and highlights",
    'metallic': "a grayscale metallic map for a PBR material: white for clearly metallic surfaces, black for everything else since most surfaces are non-metal, with clean sharp masks aligned to the color reference",
    'normal': "a tangent-space normal map in the OpenGL convention (green channel points up): flat areas stay the neutral lavender-purple base color (RGB 128, 128, 255), the surface details of the color reference become sloped normals, and no lighting or shading is baked in",
    'bump': "a grayscale bump height map: mid-gray as the base level, brighter areas are higher, darker areas are lower, preserving the surface structures of the color reference",
    'displacement': "a grayscale displacement height map: mid-gray as the base level, brighter areas raised, darker areas lowered, preserving both large shapes and fine details of the color reference",
    'ao': "a grayscale ambient occlusion map: white for fully exposed surfaces, darker gray in crevices, gaps and contact areas, soft large-scale shading only, no direct lighting, no cast shadows, no color and no material detail",
}

# 材质通道的输出规格后缀(全通道): 满幅平面图 + 与颜色参考逐像素对齐 + 反污染(无文字/水印/边框)
# + 原始数据声明(像素值即材质数据, 不做色调映射/伽马/调色——颜色空间是读取端的解释方式,
# 生成 API 无此参数, 这是生成端唯一可声明的等价物)
CHANNEL_OUTPUT_SUFFIX = (
    " Output a full-frame flat 2D map, pixel-wise aligned with the color reference: "
    "every feature keeps the same position and scale, no cropping and no offset; "
    "no text, no watermarks, no borders. The pixel values are raw material data, "
    "without tone mapping, gamma adjustment or color grading."
)
# 灰度类通道追加的纯灰度要求(法向贴图本身是 RGB 编码, 不适用)
CHANNEL_GRAYSCALE_SUFFIX = " Pure neutral grayscale only, no color tint."

# 材质通道的无缝引导(颜色贴图的无缝后缀要求整幅贴图可平铺, 通道图同理, 措辞按"map"改写;
# 本地羽化只对灰度通道生效, 法向贴图的无缝性完全靠该引导压住)
CHANNEL_SEAMLESS_SUFFIX = (
    " The map must be perfectly seamless and tileable: it repeats at a uniform scale " "and spacing across the entire image and continues across the image borders, " "with no visible seams, no vignetting and no gradients at the edges."
)

# 通道键 -> 参考图说明(组装进效果图提示词, 顺序与参考图数组一致):
# 括号内是该通道**读图所需的关键约定**(明暗方向/颜色语义/形态), 缺了模型可能解读反;
# Combined/Diffuse 是画面内容本身, 无需额外约定
PASS_ROLES = {
    'combined': "the color render of the scene",
    'depth': "the depth map of the same view (near objects white, far objects and background black)",
    'normal': "the normal map of the same view",
    'segmentation': "the segmentation map of the same view (a unique flat color per object, black background)",
    'edge': "the line art of the same view (black lines on white)",
    'diffuse': "the diffuse color (flat albedo) map of the same view",
    'ao': "the ambient occlusion map of the same view",
}

# 法向约定补充(完整档, 按面板的法向约定动态拼入 normal 条目):
# 两种约定的绿通道方向相反, 解读错会翻转凹凸感知
NORMAL_CONVENTION_NOTES = {
    'OPENGL': " (OpenGL convention, green channel up)",
    'DIRECTX': " (DirectX convention, green channel down)",
}

# 精简档角色说明(超硬预算自动降档时使用, 与 PASS_ROLES 同键)
PASS_ROLES_COMPACT = {
    'combined': "the color render",
    'depth': "the depth map",
    'normal': "the normal map",
    'segmentation': "the segmentation map",
    'edge': "the line art",
    'diffuse': "the albedo map",
    'ao': "the AO map",
}

# 非照片通道(反泄漏句列举对象): 灰度图/线稿/色块图有强烈"画面感", 不声明用途时模型
# 容易把灰阶/线条/色块直接画进结果(官方线稿示例"不需要体现文字和手绘边缘"即此意图);
# Combined/Diffuse 本身就是画面内容, 不列
LEAK_ROLE_NAMES = {
    'depth': "depth",
    'normal': "normal",
    'segmentation': "segmentation",
    'edge': "line art",
    'ao': "occlusion",
}


# ---------------------------------------------------------------------------
# 解析端正则(与提示词契约绑定, 故与提示词同置一处以保证单一来源)
# ---------------------------------------------------------------------------

# markdown 代码围栏(允许语言标注), 取围栏内部内容
FENCE_RE = re.compile(r"```[a-zA-Z0-9_+-]*[ \t]*\r?\n(.*?)```", re.DOTALL)

# 响应首行命名行 '# script-name: xxx.py'(关键字由 SCRIPT_NAME_ANCHOR 构造)
NAME_LINE_RE = re.compile(rf"^#\s*{re.escape(SCRIPT_NAME_ANCHOR)}:\s*(\S.*?)\s*$", re.IGNORECASE)

# 命名结果里常见的前缀标记(如 "name: xxx"), 清洗前先去掉
NAME_PREFIX_RE = re.compile(r"(?i)^\s*(name|texture|render|image|answer)\s*[:\-]\s*")


def _check_pass_domain() -> None:
    """**本文件**通道说明表域自检(import 期执行一次)

    校验两项: ① 完整档 `PASS_ROLES` 与精简档 `PASS_ROLES_COMPACT` 键集相同(两表按同一批
    通道键查表, 漂移会让某通道在精简档下静默丢失说明); ② 反泄漏表 `LEAK_ROLE_NAMES` 的键
    **是 `PASS_ROLES` 的子集**(反泄漏句只对其中一部分通道生效, 反向包含不成立也不该成立).
    表的用途见 image_client 的组装. 键集漂移的表现是模型解读反而不是报错, 故 import 期钉死.
    """
    if set(PASS_ROLES) != set(PASS_ROLES_COMPACT):
        raise AssertionError(f"PASS_ROLES 与 PASS_ROLES_COMPACT 键集不一致: " f"仅完整档 {set(PASS_ROLES) - set(PASS_ROLES_COMPACT)}, " f"仅精简档 {set(PASS_ROLES_COMPACT) - set(PASS_ROLES)}")
    extra = set(LEAK_ROLE_NAMES) - set(PASS_ROLES)
    if extra:
        raise AssertionError(f"LEAK_ROLE_NAMES 含 PASS_ROLES 之外的通道键: {extra}")


# 契约自检在 import 时执行一次
_check_contract()
_check_pass_domain()
