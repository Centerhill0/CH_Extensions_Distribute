"""
状态属性模块

提供以下功能:
- WM 级状态属性组: 脚本列表快照, AI 输入/最近错误记录, 纯文本对话消息,
  图像生成器状态(三模式共用参数 + 图像侧/效果图专属参数)
- 属性经插件 __init__.py 的 _addon_properties 声明式挂载到 WindowManager, 不随 .blend 保存
- 列表条目属性组 ListItem 与快照重建机制见 common.blender.list_snapshot
"""

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import PropertyGroup

from ...common.blender.list_snapshot import ListItem, is_syncing
from .items import (
    CHAT_ROLE_ITEMS,
    IMAGE_LONG_EDGE,
    IMAGE_RATIOS,
    PROVIDER_MODEL_ITEMS,
    RENDER_SCALE_FACTORS,
    TEXT_PROVIDER_MODEL_ITEMS,
    TEXTURE_PRESET_LONG_EDGES,
    cryptomatte_source_items,
    depth_curve_items,
    edge_preset_items,
    image_size_preset_items,
    mode_items,
    normal_convention_items,
    prefs_model_items,
    render_scale_items,
    service_mode_items,
    tex_size_preset_items,
    text_service_mode_items,
)
from .preference import (
    get_prefs,
)
from .handlers import (
    dump_image_refs,
    gallery_visible_items,
    on_chat_index_update,
    on_image_index_update,
    on_pass_index_update,
    on_ref_index_update,
    on_tex_index_update,
    on_scripts_index_update,
    select_gallery_value,
    select_image_by_name,
)
from .utils.image_client import resolve_output_size, resolve_panel_image_model
from .utils.provider_registry import effective_provider, thinking_items_for


class ChatMessage(PropertyGroup):
    """单条对话消息: 角色与纯文本内容"""

    role: EnumProperty(name="Role", description="Whether the message is from the user or from the AI", items=CHAT_ROLE_ITEMS, default='USER')  # type: ignore
    content: StringProperty(name="Content", description="Text of the chat message")  # type: ignore


class AiAssistantState(PropertyGroup):
    """AI 助手状态: 脚本列表快照与活跃索引, 描述输入, 等待进度与最近一次运行错误记录, 纯文本对话"""

    # ---- 面板级参数(脚本面板与对话面板各一份, 互不影响; 只读不写偏好, 见规范17) ----
    # 文本编辑器联动: 本面板的产物与列表中点击的条目是否自动送进文本编辑器
    use_auto_open_scripts: BoolProperty(
        name="Auto Open Scripts",
        description="Show generated, debugged and revised scripts, and the script clicked in the list, in the text editor automatically",
        default=True,
    )  # type: ignore
    use_auto_open_chat: BoolProperty(
        name="Auto Open Chat",
        description="Show the chat message clicked in the list and new replies in the text editor automatically",
        default=True,
    )  # type: ignore
    scripts: CollectionProperty(type=ListItem)  # type: ignore
    scripts_active_index: IntProperty(default=0, update=on_scripts_index_update)  # type: ignore
    prompt: StringProperty(
        name="Prompt",
        description="Describe the script you need",
    )  # type: ignore
    # ---- 每面板等待状态三件组(scope: script/chat/image/capture/test): 互斥/进度/中断按
    # scope 各自独立——同 scope 串行, 跨 scope 可并行(图像长请求不再堵住对话), 见 ai_generate;
    # 图像生成器三个模式(材质贴图/图像/效果图)共用 image 一个 scope: 任一时刻只有一个模式在跑,
    # 切模式时等待进度与中断按钮不消失
    status_script: StringProperty()  # type: ignore
    wait_script: IntProperty()  # type: ignore
    cancel_script: BoolProperty()  # type: ignore
    status_chat: StringProperty()  # type: ignore
    wait_chat: IntProperty()  # type: ignore
    cancel_chat: BoolProperty()  # type: ignore
    status_image: StringProperty()  # type: ignore
    wait_image: IntProperty()  # type: ignore
    cancel_image: BoolProperty()  # type: ignore
    # 通道捕获: 独立作用域(本地渲染, 不是 AI 请求) —— 可与生成/修改并行, 等待框也各画各的
    status_capture: StringProperty()  # type: ignore
    wait_capture: IntProperty()  # type: ignore
    cancel_capture: BoolProperty()  # type: ignore
    status_test: StringProperty()  # type: ignore
    wait_test: IntProperty()  # type: ignore
    cancel_test: BoolProperty()  # type: ignore
    last_error_script: StringProperty()  # type: ignore
    last_error_traceback: StringProperty()  # type: ignore
    # 报错对应脚本的内容摘要: 脚本改过后不再复用旧 traceback(重捕)
    last_error_hash: StringProperty()  # type: ignore
    # 图像生成器面板的最近一次请求错误摘要(面板内 box 展示, 可经 ClearError 清除;
    # 记录见 ai_generate.record_request_error, <名> = 标题, <名>_detail = 错误详情);
    # 三个模式共用一份(image scope), 标题即失败的算子名
    last_error_image: StringProperty()  # type: ignore
    last_error_image_detail: StringProperty()  # type: ignore
    # 对话面板同款错误摘要(请求失败时用户消息留在历史, 面板内给一条持久的错误提示)
    last_error_chat: StringProperty()  # type: ignore
    last_error_chat_detail: StringProperty()  # type: ignore
    # 最近一次完成请求的用量(token 输入/输出计数, 形如 "1234 / 5678"), 行尾置灰展示;
    # 由 ai_generate._handle_modal 在主线程回写(记录见 format_usage). 只挂文本为主的两个面板
    # (脚本/对话)——图像生成器主发图像请求(无 usage), 不设该字段; 服务商不下发时为 "",
    # 面板自然跳过. 这是面板级展示值, 不随 .blend 保存
    last_usage_script: StringProperty()  # type: ignore
    last_usage_chat: StringProperty()  # type: ignore
    # 纯文本对话: 消息历史, 当前高亮消息(点击行按本面板开关转出文本编辑器)与输入框(存于 WM, 不随 .blend 保存)
    chat_messages: CollectionProperty(type=ChatMessage)  # type: ignore
    chat_active_index: IntProperty(default=0, update=on_chat_index_update)  # type: ignore
    chat_input: StringProperty(
        name="Message",
        description="What to ask the AI in plain text",
    )  # type: ignore
    # 对话下一条消息附带的脚本名(脚本列表高亮脚本, 经"附带脚本"按钮设置, 发送后清空)
    chat_script_name: StringProperty()  # type: ignore


def _on_ref_entry_update(self, _context):
    """参考图条目变更即持久化(引用列表存于 WM): 描述是拼进提示词的有效载荷,
    三个模式的"当前模式使用"标志也随档保存(切模式/重开文件后仍按上次的勾选发送)"""
    if not is_syncing():
        dump_image_refs()


class AiStyleImageRef(PropertyGroup):
    """单张参考图引用(三模式共用一份列表): 图像数据块 + 用户描述 + 三个模式各自的发送标志

    数据块被删后按 None 处理, 描述与发送标志保留(便于找回后继续用)
    """

    image: PointerProperty(type=bpy.types.Image)  # type: ignore
    description: StringProperty(
        name="Description",
        description="What to take from this reference image (colors, material, composition...), " "assembled into its reference role in the prompt",
        update=_on_ref_entry_update,
    )  # type: ignore
    # 三个模式各自的"随请求发送"标志: 行首勾选框按当前模式读写, 切换模式互不影响(缺省全开)。
    # 关掉的条目仍留在列表里, 只是不参与该模式的发送与参考图预算计算。
    use_texture: BoolProperty(
        name="Use in This Mode",
        description="Send this reference image when generating in the current mode",
        default=True,
        update=_on_ref_entry_update,
    )  # type: ignore
    use_image: BoolProperty(
        name="Use in This Mode",
        description="Send this reference image when generating in the current mode",
        default=True,
        update=_on_ref_entry_update,
    )  # type: ignore
    use_render: BoolProperty(
        name="Use in This Mode",
        description="Send this reference image when generating in the current mode",
        default=True,
        update=_on_ref_entry_update,
    )  # type: ignore


def _gallery_items(self, context):
    """预览区缩略图条目: 可见条目(过滤+上限后)逐项取图像预览图标(标识 = 数据块名, 供选中回写)

    标签只放数据块名, 不显示悬停说明: 缩略图标签的可视宽度受缩略图宽度限制, Blender 会把
    过长标签省略号截断(实测"名 + 尺寸"拼接后长名条目只剩名称或只剩尺寸, 看起来时有时无),
    故标签保持短而完整. 标签原样透传数据块名不进翻译链: 运行期拼给动态枚举的文案(含
    iface/report 预翻译出的中文)会经 Blender 的 C 层渲染成乱码(实测 "×"/"·" 乱码),
    静态声明的枚举条目才走 Blender 自己的翻译通路, 不受此限.
    预览数据块异步生成, 首帧 icon_value 为 0 时该项画空位, 下一帧重绘即出.
    """
    items = []
    for idx, item in enumerate(gallery_visible_items(self)):
        image = bpy.data.images.get(item.name)
        if image is None:
            continue
        image.preview_ensure()
        preview = image.preview
        items.append((item.name, item.name, "", preview.icon_id if preview is not None else 0, idx))
    return items


def _on_gallery_select(self, context):
    """缩略图选中某张图像: 高亮列表条目并按本面板开关切换图像编辑器(与点击列表行同款联动)"""
    if is_syncing():
        return
    select_image_by_name(context, self, self.gallery_image)


def _on_gallery_view_change(self, context):
    """过滤条件/显示上限变化: 选中值回落到可见项(护栏内写入, 不影响列表高亮与图像编辑器)

    选中项被过滤/截断掉的枚举值不在候选表内, 读回即空串(Blender 对失效动态枚举的归一化),
    缩略图选中态会悬空, 故可见项非空时回落到首项; 可见项为空(无匹配)时缩略图本就不绘制,
    保持原值, 下次过滤变化或列表同步(handlers._align_gallery_to_index)时重新回落.
    """
    visible = gallery_visible_items(self)
    if visible:
        select_gallery_value(self, visible[0].name)


def _panel_model_items(self, context):
    """面板覆盖模型下拉(按面板服务模式动态)

    Global 无服务商候选表: 给出空标识的"跟随偏好"档(动态 items 枚举不接受空串赋值,
    但空串**标识**合法), 使面板始终可解析; 覆盖模式只列该服务商候选(不接"跟随偏好"档),
    表首项即默认(枚举无 default, 取首项).
    """
    items = PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else prefs_model_items


def _reset_image_panel_model(self, _context):
    """切换图像服务模式时把覆盖模型复位为新模式的表首项

    Global 的表只有"跟随偏好"一档, 其标识是空串而动态 items 枚举不接受空串赋值
    (赋空串必抛 TypeError), 该档下覆盖模型本就不被采用, 因此跳过赋值(见 _reset_text_panel_model).
    """
    items = _panel_model_items(self, _context)
    if items and items[0][0]:
        self.panel_model = items[0][0]


def _reset_text_panel_model(self, _context):
    """切换文本服务模式时把覆盖模型与思考档位复位到新表首项

    GLOBAL 档的表首项是"跟随偏好"哨兵(空标识), 但空标识不能赋值(动态 items 枚举不接受空串,
    赋了必抛 TypeError 且只在控制台留 traceback), 故 GLOBAL 档下跳过模型赋值 —— 该档的模型
    解析本就不看 panel_model; 覆盖模式的表首项是真实模型名, 正常赋值.
    档位标识按服务商定制且各表长度不同, 不复位会被按索引重解释到别的档(或越界读回空串导致
    档位静默不下发), 故档位仍需按新表首项复位; 表首项为空标识哨兵(如偏好 CUSTOM 的
    "不发送"默认)时赋值非法(TypeError), 改用 property_unset 回未设态(见分支注释).
    """
    provider = self.service_mode if self.service_mode != 'GLOBAL' else get_prefs().provider
    items = _panel_text_model_items(self, _context)
    if items and items[0][0]:
        self.panel_model = items[0][0]
    thinking_items = _thinking_items_for(provider)
    if thinking_items and thinking_items[0][0]:
        self.thinking = thinking_items[0][0]
    elif thinking_items:
        # 表首项是空标识哨兵(如偏好 CUSTOM 的"不发送"默认): 空串赋值非法(TypeError,
        # RNA 校验集不含空标识条目), 用 property_unset 回未设态——读回空串, 与哨兵同义
        # (不下发); 跳过赋值则上游游离档的档位会滞留成新表合法值, 违背哨兵默认口径
        self.property_unset("thinking")


def _thinking_items_for(provider: str) -> list:
    """按服务商返回思考档位条目(DeepSeek 4 档 / GLM 3 档 / 通用 3 档), 委托注册表"""
    return list(thinking_items_for(provider))


def _text_thinking_items(self, context):
    """思考档位下拉条目: 按生效服务商(覆盖优先, 否则偏好)动态切换"""
    provider = self.service_mode if self.service_mode != 'GLOBAL' else get_prefs().provider
    return _thinking_items_for(provider)


def _panel_text_model_items(self, context):
    """文本面板覆盖模型下拉(按面板服务模式动态)

    Global 无服务商候选表: 给出空标识的"跟随偏好"档(空串**标识**合法, 空串**赋值**非法);
    覆盖模式只列该服务商候选(不接"跟随偏好"档, 与图像侧面板同规则), 表首项即默认.
    """
    items = TEXT_PROVIDER_MODEL_ITEMS.get(self.service_mode)
    return items if items else prefs_model_items


class ServiceTestState(PropertyGroup):
    """服务连通性测试结果(最近一次, 存于 WM 供偏好面板显示)"""

    text_result: StringProperty()  # type: ignore
    text_ok: BoolProperty()  # type: ignore
    image_result: StringProperty()  # type: ignore
    image_ok: BoolProperty()  # type: ignore


class AiImageServiceState(PropertyGroup):
    """图像生成器服务设置: 服务模式(全局/覆盖服务商)与覆盖模型

    WM 上单实例(ch_ai_image_service): 图像生成器三个模式共用一家服务与一个模型
    (材质贴图/图像/效果图不再各挂一份, 也不再有"文生图模型/编辑模型"之分).
    """

    service_mode: EnumProperty(
        name="Provider",
        description="Image service for the image assistant: Global follows the preferences, others override",
        items=service_mode_items,
        default='GLOBAL',
        update=_reset_image_panel_model,
    )  # type: ignore
    panel_model: EnumProperty(
        name="Image Model",
        description="Image model override for this panel",
        items=_panel_model_items,
    )  # type: ignore


class AiTextServiceState(PropertyGroup):
    """AI 服务设置 · 文本服务: 服务模式(全局/覆盖服务商) + 覆盖模型 + 思考档位

    WM 上单实例(ch_ai_text_service): 脚本生成器与对话共用一家文本服务与一个模型.
    """

    service_mode: EnumProperty(
        name="Provider",
        description="Text service for the text assistant: Global follows the preferences, others override",
        items=text_service_mode_items,
        default='GLOBAL',
        update=_reset_text_panel_model,
    )  # type: ignore
    panel_model: EnumProperty(
        name="Model",
        description="Model override for the text assistant",
        items=_panel_text_model_items,
    )  # type: ignore
    # 思考档位: 档位值即生效服务商的参数值(档位表按服务商定制)
    thinking: EnumProperty(
        name="Thinking Level",
        description="Thinking level for this panel, sent with the provider's own parameter",
        items=_text_thinking_items,
    )  # type: ignore


# 宽高联动/预设回填的递归护栏: 回填一侧宽高会触发对侧的 update, 置位期间跳过联动.
# 图像侧与效果图两族 update 同为主线程回调且互不嵌套, 共用一把护栏即可
_size_syncing = False


def _size_update(fn):
    """给宽高联动 update 回调套上递归护栏(置位期间重入直接跳过, 结束必复位)"""

    def wrapper(self, context):
        global _size_syncing
        if _size_syncing:
            return
        _size_syncing = True
        try:
            fn(self, context)
        finally:
            _size_syncing = False

    return wrapper


# 材质贴图 与 图像 的尺寸参数**各一套字段**(预设表与回填基准不同: 方图像素 vs 画幅比率),
# 因此三模式切换时谁也不会覆盖谁 —— 每套规则都是静态的, 不读当前模式, 也就没有"切模式复位".


def _apply_tex_size_preset(state):
    """按材质贴图预设回填 tex_width/tex_height(方图; 自定义档保持现值不动)"""
    long_edge = TEXTURE_PRESET_LONG_EDGES.get(state.tex_size_preset)
    if long_edge is not None:
        state.tex_width = long_edge
        state.tex_height = long_edge


def _apply_image_size_preset(state):
    """按图像预设回填 image_width/image_height(长边 2048 按比率换算; 自定义档保持现值不动)"""
    ratio = IMAGE_RATIOS.get(state.image_size_preset)
    if ratio is None:
        return
    if ratio >= 1.0:
        state.image_width = IMAGE_LONG_EDGE
        state.image_height = max(256, min(4096, round(IMAGE_LONG_EDGE / ratio)))
    else:
        state.image_height = IMAGE_LONG_EDGE
        state.image_width = max(256, min(4096, round(IMAGE_LONG_EDGE * ratio)))


def _snapshot_tex_lock_ratio(state):
    """把当前宽高比快照为材质贴图的锁定联动比率(锁定瞬间/预设回填后调用)"""
    state.tex_lock_ratio = state.tex_width / max(1, state.tex_height)


def _snapshot_image_lock_ratio(state):
    """把当前宽高比快照为图像的锁定联动比率(锁定瞬间/预设回填后调用)"""
    state.image_lock_ratio = state.image_width / max(1, state.image_height)


@_size_update
def _on_tex_size_preset_update(self, _context):
    """切换材质贴图预设: 按方图档位回填宽高; 非自定义档重新进入锁定态并快照比率"""
    _apply_tex_size_preset(self)
    if self.tex_size_preset != 'CUSTOM':
        self.tex_use_size_lock = True
    if self.tex_use_size_lock:
        _snapshot_tex_lock_ratio(self)


@_size_update
def _on_tex_lock_update(self, _context):
    """切换材质贴图锁定: 锁定时以当前宽高比作为联动比率(解锁后两边各自独立)"""
    if self.tex_use_size_lock:
        _snapshot_tex_lock_ratio(self)


@_size_update
def _on_tex_width_update(self, _context):
    """手动改宽: 档位回落自定义(数值已偏离预设), 锁定态下高度按比率自动跟随"""
    if self.tex_size_preset != 'CUSTOM':
        self.tex_size_preset = 'CUSTOM'
    if self.tex_use_size_lock and self.tex_lock_ratio > 0:
        self.tex_height = max(256, min(4096, round(self.tex_width / self.tex_lock_ratio)))


@_size_update
def _on_tex_height_update(self, _context):
    """手动改高: 档位回落自定义, 锁定态下宽度按比率自动跟随"""
    if self.tex_size_preset != 'CUSTOM':
        self.tex_size_preset = 'CUSTOM'
    if self.tex_use_size_lock and self.tex_lock_ratio > 0:
        self.tex_width = max(256, min(4096, round(self.tex_height * self.tex_lock_ratio)))


@_size_update
def _on_image_size_preset_update(self, _context):
    """切换图像预设: 按比率档回填宽高; 非自定义档重新进入锁定态并快照比率"""
    _apply_image_size_preset(self)
    if self.image_size_preset != 'CUSTOM':
        self.image_use_size_lock = True
    if self.image_use_size_lock:
        _snapshot_image_lock_ratio(self)


@_size_update
def _on_image_lock_update(self, _context):
    """切换图像锁定: 锁定时快照当前比率; 解锁时预设档自动切到自定义(与效果图同款)"""
    if self.image_use_size_lock:
        _snapshot_image_lock_ratio(self)
    elif self.image_size_preset != 'CUSTOM':
        self.image_size_preset = 'CUSTOM'


@_size_update
def _on_image_width_update(self, _context):
    """手动改宽: 档位回落自定义, 锁定态下高度按比率自动跟随"""
    if self.image_size_preset != 'CUSTOM':
        self.image_size_preset = 'CUSTOM'
    if self.image_use_size_lock and self.image_lock_ratio > 0:
        self.image_height = max(256, min(4096, round(self.image_width / self.image_lock_ratio)))


@_size_update
def _on_image_height_update(self, _context):
    """手动改高: 档位回落自定义, 锁定态下宽度按比率自动跟随"""
    if self.image_size_preset != 'CUSTOM':
        self.image_size_preset = 'CUSTOM'
    if self.image_use_size_lock and self.image_lock_ratio > 0:
        self.image_width = max(256, min(4096, round(self.image_height * self.image_lock_ratio)))


# 效果图输出尺寸下限/上限(与服务商约束无关, 下发前另经 resolve_output_size 修正)
_RENDER_DIM_MIN, _RENDER_DIM_MAX = 256, 4096


def camera_ratio(context) -> float:
    """当前场景输出属性分辨率(Resolution X/Y)宽高比(场景无有效分辨率时给 1.0), 效果图比率基准"""
    rd = getattr(context.scene, "render", None) if context is not None else None
    if rd is None:
        return 1.0
    return rd.resolution_x / max(1, rd.resolution_y)


def _render_provider_model(context) -> tuple:
    """解析图像生成器当前生效的 (服务商, 模型), 供缩放档回填时按服务商约束夹取

    模型与生成操作器的 resolve_image_model 同源同口径(面板覆盖 → 偏好), 输出尺寸约束
    由该模型决定, 面板显示值才能与实际下发值一致.
    回调期不保证窗口管理器/服务设置就绪(如后台加载), 任一步取不到即回落 ('', ''),
    此时 resolve_output_size 原样返回, 等价于不夹取(仅走本地 256-4096 兜底).
    """
    wm = getattr(context, "window_manager", None) if context is not None else None
    sstate = getattr(wm, "ch_ai_image_service", None) if wm is not None else None
    if sstate is None:
        return "", ""
    prefs = get_prefs()
    provider = effective_provider(sstate, prefs, 'image')
    model = resolve_panel_image_model(sstate, prefs, "panel_model", "image_model_t2i")
    return provider, model


def _apply_render_size_preset(state, context):
    """按当前分辨率档位回填 render_width/render_height(自定义档保持现值不动)

    缩放档以输出属性的**实际渲染尺寸**长边(resolution_x/y 乘 resolution_percentage)为基准
    乘缩放倍数: 即"以 Blender 当前实际会渲染出的画面尺寸为准, 在其基础上缩放"
    (如 4096x4096 @50% 的实际渲染尺寸是 2048, 50% 档回填 1024).
    回填后**立即按服务商/模型约束夹取**(resolve_output_size), 使面板显示值即最终下发值——
    否则小档位会被服务端下限抬高(如 960x540 -> 1280x720), 大档位被上限压回(150%/200% 撞成同值),
    面板显示的宽高与实际输出对不上.
    """
    factor = RENDER_SCALE_FACTORS.get(state.render_size_preset)
    if factor is None:
        return
    # 缩放档换算: 实际渲染尺寸长边(含 resolution_percentage)乘倍数, 比率取输出属性比率
    ratio = camera_ratio(context)
    rd = getattr(context.scene, "render", None) if context is not None else None
    long_edge = max(rd.resolution_x, rd.resolution_y) * rd.resolution_percentage / 100.0 if rd is not None else 1024
    scaled = max(1, round(long_edge * factor))
    width, height = (scaled, round(scaled / ratio)) if ratio >= 1.0 else (round(scaled * ratio), scaled)
    provider, model = _render_provider_model(context)
    width, height = resolve_output_size(provider, model, width, height)
    state.render_width = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, width))
    state.render_height = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, height))


def _snapshot_render_lock_ratio(state, context):
    """把输出属性分辨率宽高比快照为锁定比率(锁定瞬间/档位回填后调用)

    比率锁定的是**输出属性分辨率(Resolution X/Y)比率**(非当前宽高之比): 缩放档只改像素
    不改比率, 解锁时按当前宽高自由调整, 再锁定时重新对齐回输出属性比率.
    """
    state.render_lock_ratio = camera_ratio(context)


@_size_update
def _on_render_size_preset_update(self, context):
    """切换分辨率档位: 两种档位都按输出属性比率回填/对齐并保持锁定(自定义档默认也锁定)

    自定义档不再自动解锁, 而是保留锁定态并快照输出属性比率——用户切到自定义通常是想在
    该比率下改像素值, 自动解锁会让宽高各自独立, 一不小心就把比率改坏.
    """
    _apply_render_size_preset(self, context)
    self.render_use_size_lock = True
    _snapshot_render_lock_ratio(self, context)


@_size_update
def _on_render_lock_update(self, context):
    """切换锁定: 锁定时把比率快照回输出属性分辨率比率; 解锁时档位自动切到自定义"""
    if self.render_use_size_lock:
        _snapshot_render_lock_ratio(self, context)
    elif self.render_size_preset != 'CUSTOM':
        self.render_size_preset = 'CUSTOM'


@_size_update
def _on_render_width_update(self, context):
    """手动改宽: 档位回落自定义, 锁定态下高度按摄像机比率自动跟随(解锁后自由调整)

    档位回落属自定义档的语义, 故先落到 CUSTOM 再把对侧按比率跟随
    (保持用户在缩放档下的数值不被回填覆盖).
    """
    if self.render_size_preset != 'CUSTOM':
        self.render_size_preset = 'CUSTOM'
    if self.render_use_size_lock and self.render_lock_ratio > 0:
        self.render_height = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, round(self.render_width / self.render_lock_ratio)))


@_size_update
def _on_render_height_update(self, context):
    """手动改高: 档位回落自定义, 锁定态下宽度按摄像机比率自动跟随(解锁后自由调整)"""
    if self.render_size_preset != 'CUSTOM':
        self.render_size_preset = 'CUSTOM'
    if self.render_use_size_lock and self.render_lock_ratio > 0:
        self.render_width = max(_RENDER_DIM_MIN, min(_RENDER_DIM_MAX, round(self.render_height * self.render_lock_ratio)))


def refresh_render_size_from_scene(state, context):
    """原生输出分辨率(输出属性的 Resolution X/Y/%)变化后按当前档位重回填效果图尺寸

    缩放档的宽高是派生显示(输出属性实际渲染尺寸长边乘倍数), 原生属性在输出属性面板改动
    不会触发本插件的 update 回调, 由 handlers 的周期同步检出变化后调本函数对齐;
    自定义档的宽高是用户钉死的数值, 保持不动.
    回填必须在 _size_update 护栏内执行: 否则回填写宽高会经 update 回调把档位误翻成
    自定义(与预设回填走同一护栏, 见 _size_update 说明).
    """
    global _size_syncing
    if state.render_size_preset == 'CUSTOM' or _size_syncing:
        return
    _size_syncing = True
    try:
        _apply_render_size_preset(state, context)
        _snapshot_render_lock_ratio(state, context)
    finally:
        _size_syncing = False


class AiCaptureParams(PropertyGroup):
    """通道生成参数(场景级): 挂 bpy.types.Scene 的 ch_ai_capture_params, 随 .blend 原生保存

    挂场景而非 WM: 捕获参数与场景内容一一对应, 多场景文件各自独立. 同名运行期 RNA
    使底层 idprop 不出现在"自定义属性"面板(rna_prop_ui 对 is_runtime 同名键按
    "API Defined" 过滤; 开发者界面开启时仍可见但只读). 旧版存为场景自定义属性
    裸字典(枚举=字符串, 与 RNA 底层的 int 存储类型不合, 包装器不收养), 载入时经
    handlers.migrate_legacy_capture_params 读裸值经 RNA 重赋值归一.
    """

    # AO 遮蔽距离: 落在临时场景视图层的 eevee.ambient_occlusion_distance(5.1 实证属性在视图层
    # 而非场景, 控制多远内的物体参与遮蔽计算, 对 AO 通道同样生效)
    ao_distance: FloatProperty(
        name="Occlusion Distance",
        description="Distance of objects that contribute to the AO pass, in scene units",
        default=1.0,
        min=0.0,
        soft_max=100.0,
        subtype='DISTANCE',
    )  # type: ignore
    # 渲染采样数: 落到临时场景的 eevee.taa_render_samples(原为硬编码 16). 它直接决定
    # 抗锯齿与噪点水平(合并结果/漫射/AO 最敏感); 两组渲染都用同一个采样数, 故进两组渲染键
    render_samples: IntProperty(
        name="Samples",
        description="Render samples per pixel: higher values smooth edges and reduce noise, " "at the cost of render time",
        default=16,
        min=1,
        max=512,
        soft_max=64,
    )  # type: ignore
    # 语义分割依据: Cryptomatte 的三种 ID 通道(物体/材质/资产), 决定分割图按什么分块.
    # 属**渲染参数**(开哪条 pass 不同), 故进主组渲染键.
    # 出厂默认按物体: 名字表即场景物体名, 被渲到的物体必然命中, 不会出现"有覆盖却无名"的黑块;
    # 选**材质**分块时同材质的多个物体同色(更贴合材质语义), 代价是**没有材质的物体**匹配不到
    # 名字而保持黑色(此时有未解析占比提示). 该默认与通道捕获的 CRYPTO_SOURCE_DEFAULT 同口径
    # (utils/pass_capture/_constants.py)
    cryptomatte_source: EnumProperty(
        name="Segmentation Source",
        description="Which Cryptomatte ID channel drives the semantic segmentation map",
        items=cryptomatte_source_items,
        default='OBJECT',
    )  # type: ignore
    # Cryptomatte 落盘层数: 一层装两个对象槽位, 故 N 层可解析每像素 2N 个重叠物体.
    # 层数越多越不会在重叠处取错对象; 代价是每层一张 32bit EXR(2048² 约 67 MB), 落盘量随层数线性增长
    crypto_slots: IntProperty(
        name="Overlap Layers",
        description="How many Cryptomatte layers to write: each layer resolves two overlapping " "objects per pixel, and costs one 32-bit EXR of temporary disk space",
        default=3,
        min=1,
        max=3,
    )  # type: ignore
    # 分割边缘抗锯齿: 关闭(出厂)时每个像素取覆盖率最大对象的**纯色**, 色块边界是台阶;
    # 打开后按覆盖率把相邻对象色加权平均, 边界随之平滑 —— 代价是出现不属于任何单个对象的
    # 过渡色(与旧"材质覆盖"方案由渲染器抗锯齿得到的效果等价).
    # 属**解码参数**(只影响解码, 不影响渲染), 故**不进渲染键**: 切换它只重解码, 不会重渲.
    smooth_seg_edges: BoolProperty(
        name="Antialias Edges",
        description="Blend neighbouring object colors along segmentation boundaries instead of " "switching abruptly: smoother edges, at the cost of boundary colors that " "belong to no single object",
        default=False,
    )  # type: ignore
    # 深度映射区间(场景单位): 深度通道为米制视空间 Z(背景为摄像机裁剪终点), 按用户区间线性映射 近端->白 远端->黑;
    # 二元向量属性(近, 远)保证面板单行双值与参数框其它行同用 property split 机制对齐
    depth_range: FloatVectorProperty(
        name="Depth Range",
        description="Scene-space distances (near, far) that map the depth pass to white and black",
        size=2,
        subtype='XYZ_LENGTH',
        default=(1.0, 20.0),
        min=0.0,
        soft_max=1000.0,
    )  # type: ignore
    # 深度 8bit 量化曲线: 反深度(视差)把灰阶向近场集中, 主体景深细节保留最多(默认档,
    # 256 级按 1/z 分布, 与 ControlNet/MiDaS 深度惯例一致); 线性均分灰阶为备选
    depth_curve: EnumProperty(
        name="Depth Curve",
        description="Mapping curve of the depth pass: inverse depth concentrates gray levels " "on the near field, linear spreads them evenly",
        items=depth_curve_items,
        default='INVERSE',
    )  # type: ignore
    # 法向约定: Blender 自身遵循 OpenGL(绿通道 Y 向上, 5.0 源码 Normal Map 节点枚举证实),
    # DirectX 约定绿通道向下, 导出时反转绿通道
    normal_convention: EnumProperty(
        name="Convention",
        description="Green channel direction of the normal map: OpenGL points up, DirectX points down",
        items=normal_convention_items,
        default='OPENGL',
    )  # type: ignore
    # 线稿宽度系数: 线宽为通道捕获侧的固定基准 radius(_EDGE_RADIUS_FALLBACK,
    # 见 utils/pass_capture/_constants.py)乘该系数
    # (标签原文带 Scale 以与"线宽"本身区分, 入典出"线宽系数")
    edge_width_scale: FloatProperty(
        name="Line Width Scale",
        description="Scale factor for the line art width",
        default=1.0,
        min=0.01,
        max=10.0,
        subtype='FACTOR',
    )  # type: ignore
    # 线稿预设: 一组线条类型开关打包成一个下拉(逐项铺开会占掉半屏).
    # 属**渲染参数**(改变线稿组渲染结果), 故进线稿组渲染键: 换档只重渲线稿组
    edge_preset: EnumProperty(
        name="Line Art Preset",
        description="Which kinds of lines the line art pass draws",
        items=edge_preset_items,
        default='STANDARD',
    )  # type: ignore
    # 线稿材质边界: 对应 Lineart 修改器的 use_material("Material Borders", 系统词条),
    # 控制材质之间是否生成笔画(默认关, 与修改器出厂默认一致)
    use_material_borders: BoolProperty(
        name="Material Borders",
        description="Generate line art strokes between different materials",
        default=False,
    )  # type: ignore


class AiImageState(PropertyGroup):
    """图像生成器状态: 生成模式, 三模式共用的生成参数, 图像侧(材质贴图·图像)与效果图各自的专属参数

    字段分四类, **前缀即归属**: 无前缀 = 面板级或三模式共用, `tex_` = 材质贴图模式,
    `image_` = 图像模式, `render_` = 效果图模式. 同名同义的参数(主列表/参考图/随机种/张数/多变体/自动打开/画廊显示)已收为一份;
    输出尺寸则三套各自独立(`tex_*` 1K/2K 方图, `image_*` 画幅比率, `render_*` 输出属性渲染尺寸占比)——
    档位语义与回填基准不同, 分开后**切换模式互不覆盖, 每个模式都记住自己的档位与宽高**.
    材质通道组(channel_source/use_channel_*)为材质贴图模式专属, 与效果图捕获开关同为无前缀组;
    存于 WM, 不随 .blend 保存; 参考图引用随 AI_Image_Refs.json 文本块保存/恢复.
    """

    # ---- 生成模式(面板常驻行, 三模式共用一套外壳) ----
    # 生成模式: 只是"看哪一套参数"的开关 —— 三套输出尺寸字段各自独立, 切换模式不写任何参数
    mode: EnumProperty(
        name="Generation Mode",
        description="Material texture, free image or concept render generation",
        items=mode_items,
        default='TEXTURE',
    )  # type: ignore

    # ---- 面板级参数(仅本面板的局部设置, 不写偏好, 见规范17) ----
    # 图像编辑器联动: 产物与列表中点击的条目是否自动送进图像编辑器
    use_auto_open_images: BoolProperty(
        name="Auto Open Images",
        description="Show the generated image and the image clicked in the list in the image editor automatically",
        default=True,
    )  # type: ignore
    # Settings 折叠开关: 三模式共用同一状态(切模式不折叠), 默认展开
    use_show_settings: BoolProperty(
        name="Generation Settings",
        description="Show the resolution, seed, count, reference and pass generation settings",
        default=True,
    )  # type: ignore

    # ---- 三模式共用的生成参数 ----
    # 负向提示词: 描述画面中不想出现的内容(仅百炼 Qwen-Image 支持, 其余服务商不下发)
    negative_prompt: StringProperty(
        name="Negative Prompt",
        description="Content to avoid in the image, sent to providers that support it (Alibaba DashScope only); more than 500 characters is truncated by the server",
    )  # type: ignore
    # 随机种: 0 = 每次随机; 非 0 可复现同一次生成(复现满意的结果后调尺寸重出)
    seed: IntProperty(
        name="Seed",
        description="Random seed: 0 randomizes each run, a fixed value reproduces the same result",
        default=0,
        min=0,
        max=2147483647,
    )  # type: ignore
    # 一次生成的张数(逐张串行请求, 中途失败即停止), 每张单独计费
    count: IntProperty(
        name="Generation Count",
        description="How many images to generate in one run (1-5), each image is a separate billed request",
        default=1,
        min=1,
        max=5,
    )  # type: ignore
    # 批量多变体: 张数>1 时每张换一个宽高比变体与随机种, 一次产出多种构图供挑选(默认开启);
    # 随机种变体仅对支持 seed 的服务商有效, 不支持者只有比率变体(见 provider_registry.supports_seed)
    batch_variants: BoolProperty(
        name="Vary Batch",
        description="With Generation Count > 1: each image uses a different aspect-ratio variant and seed for varied compositions (seed varies only on providers that support it)",
        default=True,
    )  # type: ignore

    # ---- 参考图(三模式共用: 图像侧作视觉参考, 效果图作风格参考) ----
    # 引用集合存于 WM, 随 AI_Image_Refs.json 文本块保存/恢复
    use_ref_images: BoolProperty(
        name="Use References",
        description="Send the loaded reference images with the prompt: the visual direction for textures and images, the style for concept renders",
        default=False,
    )  # type: ignore
    ref_images: CollectionProperty(type=AiStyleImageRef)  # type: ignore
    # 点击行按本面板开关把图像编辑器切换到该参考图
    ref_images_active_index: IntProperty(default=0, update=on_ref_index_update)  # type: ignore

    # ---- 主图像列表(图像/效果图模式产物) ----
    # 快照含图像与效果图产物, 由前缀区分(实时同步见 handlers): "AI Bmp" 图像 /
    # "AI Render" 效果图版本链; 材质贴图产物(AI Tex)走材质通道列表(不混入本列表);
    # 点击行把图像编辑器切换到对应图像
    images: CollectionProperty(type=ListItem)  # type: ignore
    images_active_index: IntProperty(default=0, update=on_image_index_update)  # type: ignore
    # 材质通道列表快照(AI Tex 前缀: 颜色贴图/通道贴图/修改备份同列, 收在材质通道段内回看;
    # 点击行跟随颜色源并按本面板开关聚焦图像编辑器, 见 handlers.on_tex_index_update)
    tex_images: CollectionProperty(type=ListItem)  # type: ignore
    tex_images_active_index: IntProperty(default=0, update=on_tex_index_update)  # type: ignore
    # 通道预览迷你列表快照(固定名捕获预览 "AI Ref: " 前缀): 不进主列表与画廊,
    # 在"生成通道"小节内回看; 点击行按本面板开关聚焦图像编辑器
    pass_images: CollectionProperty(type=ListItem)  # type: ignore
    pass_images_active_index: IntProperty(default=0, update=on_pass_index_update)  # type: ignore

    # ---- 预览区缩略图控件(三模式共用同一套显示参数) ----
    gallery_scale: FloatProperty(
        name="Thumbnail Size",
        description="Size of the thumbnails in the preview area",
        default=6.0,
        min=2.0,
        max=16.0,
        precision=1,
    )  # type: ignore
    gallery_labels: BoolProperty(
        name="Labels",
        description="Show the image name under each thumbnail",
        default=True,
    )  # type: ignore
    gallery_filter: StringProperty(
        name="Name Filter",
        description="Show only thumbnails whose name contains this text",
        update=_on_gallery_view_change,
    )  # type: ignore
    gallery_limit: IntProperty(
        name="Max Shown",
        description="Maximum number of thumbnails shown, 0 shows every matching image",
        default=12,
        min=0,
        max=200,
        update=_on_gallery_view_change,
    )  # type: ignore
    # 控件子面板展开开关: 缩略图控件收在缩略图下方, 默认收起(留白给缩略图)
    use_show_controls: BoolProperty(
        name="Thumbnail Controls",
        description="Show the thumbnail size, label, filter and count controls",
        default=False,
    )  # type: ignore
    gallery_image: EnumProperty(
        name="Gallery",
        description="Click a thumbnail to highlight that image in the list and show it in the image editor",
        items=_gallery_items,
        update=_on_gallery_select,
    )  # type: ignore

    # ---- 图像侧(材质贴图 / 图像)专属参数 ----
    # 提示词: 与效果图侧分开(贴图描述与效果图描述内容不同, 且长文描述块是各自"优化提示词"
    # 的落地处; 共用会让"描述框里的字"与"实际发送的长文块"对不上)
    tex_prompt: StringProperty(
        name="Prompt",
        description="Describe the texture or image to generate",
    )  # type: ignore
    # 无缝贴图: 仅材质贴图模式绘制(图像模式该行不出现)
    use_seamless: BoolProperty(
        name="Seamless",
        description="Make the texture tile seamlessly: stronger prompt guidance plus local edge blending",
        default=True,
    )  # type: ignore
    # ---- 材质贴图模式的输出尺寸(1K/2K 方图 + 自定义) ----
    tex_size_preset: EnumProperty(
        name="Resolution",
        description="Output resolution preset: with the lock on, editing one side adjusts the other",
        items=tex_size_preset_items,
        update=_on_tex_size_preset_update,
    )  # type: ignore
    # 宽高比锁定: 锁定时调整一边另一边按锁定比率自动跟随; 解锁后自由调整
    tex_use_size_lock: BoolProperty(
        name="Lock",
        description="Lock the width to height ratio: editing one side adjusts the other, unlock to adjust freely",
        default=True,
        update=_on_tex_lock_update,
    )  # type: ignore
    # 锁定瞬间的宽高比快照(宽/高), 锁定联动据此换算; 不入面板, 由锁定/预设回填维护
    tex_lock_ratio: FloatProperty(
        default=1.0,
        min=1 / 16,
        max=16,
    )  # type: ignore
    # 自定义输出分辨率(像素): 下发前按服务商/模型支持的区间修正(见 image_client.resolve_output_size),
    # 实际返回分辨率以面板置灰标签为准
    tex_width: IntProperty(
        name="Width",
        description="Output width in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=256,
        max=4096,
        subtype='PIXEL',
        update=_on_tex_width_update,
    )  # type: ignore
    tex_height: IntProperty(
        name="Height",
        description="Output height in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=256,
        max=4096,
        subtype='PIXEL',
        update=_on_tex_height_update,
    )  # type: ignore

    # ---- 材质通道(材质贴图模式专属: 以颜色贴图为源派生其它通道贴图, 两步工作流第二步) ----
    # 贴图无缝: 声明**发送的颜色贴图**是否属于可无缝平铺的贴图——其它材质通道天然与颜色通道
    # 保持一致, "无缝"说明随提示词发送只是为了生成结果的准确(灰度类通道另在本地做边缘羽化);
    # 与上方"Seamless"(管颜色贴图生成本身)相互独立, 显示名"贴图无缝"避免同面板两开关同标签
    use_channel_seamless: BoolProperty(
        name="Texture Is Seamless",
        description="Whether the sent color map is a seamless tileable texture: the generated channel maps naturally match it, the seamless note is added to the prompts for generation accuracy, and grayscale channels are edge-blended locally",
        default=True,
    )  # type: ignore
    # 颜色源: 显式指定图像(空 = 回落材质通道列表高亮的颜色贴图, 校验口径见 ai_texture.resolve_channel_source);
    # 行末按钮可从磁盘载入外部颜色贴图(显式选中不限前缀)
    channel_source: PointerProperty(
        name="Color Source",
        description="The color map the channel maps are derived from: empty falls back to the highlighted generated texture, pick an image or load one from disk with the folder button",
        type=bpy.types.Image,
    )  # type: ignore
    # 通道勾选(默认全关, 经预设菜单整组写回): 键序即请求顺序(见 script_io.TEXTURE_CHANNEL_KEYS)
    use_channel_roughness: BoolProperty(
        name="Roughness",
        description="Generate a grayscale roughness map from the color source: brighter means rougher and more matte",
        default=False,
    )  # type: ignore
    use_channel_metallic: BoolProperty(
        name="Metallic",
        description="Generate a grayscale metallic map from the color source: white for metal, black for non-metal",
        default=False,
    )  # type: ignore
    use_channel_normal: BoolProperty(
        name="Normal",
        description="Generate a tangent-space normal map from the color source in the OpenGL convention (green channel points up)",
        default=False,
    )  # type: ignore
    use_channel_bump: BoolProperty(
        name="Bump",
        description="Generate a grayscale bump height map from the color source: brighter is higher",
        default=False,
    )  # type: ignore
    use_channel_displacement: BoolProperty(
        name="Displacement",
        description="Generate a grayscale displacement height map from the color source: mid-gray base level, brighter raised",
        default=False,
    )  # type: ignore
    use_channel_ao: BoolProperty(
        name="AO",
        description="Generate a grayscale ambient occlusion map from the color source: white for exposed surfaces, darker in crevices",
        default=False,
    )  # type: ignore

    # ---- 图像模式的输出尺寸(常用宽高比 + 自定义) ----
    # 与材质贴图分开成两套: 档位表与回填基准不同, 分开后切换模式互不覆盖(各自记住)
    image_size_preset: EnumProperty(
        name="Resolution",
        description="Output resolution preset: with the lock on, editing one side adjusts the other",
        items=image_size_preset_items,
        update=_on_image_size_preset_update,
    )  # type: ignore
    image_use_size_lock: BoolProperty(
        name="Lock",
        description="Lock the width to height ratio: editing one side adjusts the other, unlock to adjust freely",
        default=True,
        update=_on_image_lock_update,
    )  # type: ignore
    image_lock_ratio: FloatProperty(
        default=1.0,
        min=1 / 16,
        max=16,
    )  # type: ignore
    image_width: IntProperty(
        name="Width",
        description="Output width in pixels, adjusted to the provider's supported range automatically",
        default=2048,
        min=256,
        max=4096,
        subtype='PIXEL',
        update=_on_image_width_update,
    )  # type: ignore
    image_height: IntProperty(
        name="Height",
        description="Output height in pixels, adjusted to the provider's supported range automatically",
        default=2048,
        min=256,
        max=4096,
        subtype='PIXEL',
        update=_on_image_height_update,
    )  # type: ignore

    # ---- 效果图侧专属参数 ----
    # 提示词: 见 tex_prompt 的说明(两套各自独立是刻意的)
    render_prompt: StringProperty(
        name="Prompt",
        description="Describe the look of the concept render",
    )  # type: ignore
    # 通道输出分辨率钳制(仅开关, 无输入框, 通道生成专属): 关闭时直接用 Blender 输出分辨率
    # (乘 Resolution Scale); 打开后仅在最长边超出**当前服务商**的参考图上传上限时按分辨率
    # 百分比等比下调(宽高比不变, 见 utils/pass_capture/_size.py 的 resolve_capture_size),
    # 上限取偏好设置里的参考图最长边
    use_clamp_resolution: BoolProperty(
        name="Clamp Output Resolution",
        description="Limit the captured pass resolution to the reference image limit of the current " "provider: the longest edge is scaled down proportionally only when it exceeds it",
        default=True,
    )  # type: ignore
    # 输出分辨率档位: 缩放档(输出属性实际渲染尺寸长边乘倍数) / 自定义(自由输入宽高);
    # 宽高比率恒锁输出属性分辨率比率
    render_size_preset: EnumProperty(
        name="Resolution",
        description="Output resolution: scale of the current render resolution, or free width and height in pixels",
        items=render_scale_items,
        default='100',
        update=_on_render_size_preset_update,
    )  # type: ignore
    # 宽高比锁定: 锁定(默认)时宽高恒等于输出属性分辨率(Resolution X/Y)比率, 调整一边另一边自动跟随; 解锁后可自由调整
    render_use_size_lock: BoolProperty(
        name="Lock",
        description="Lock the width to height ratio to the render resolution: editing one side adjusts the other",
        default=True,
        update=_on_render_lock_update,
    )  # type: ignore
    # 锁定瞬间的输出属性分辨率宽高比快照(宽/高), 锁定联动据此换算; 不入面板
    render_lock_ratio: FloatProperty(
        default=1.0,
        min=1 / 16,
        max=16,
    )  # type: ignore
    # 自定义输出分辨率(像素): 下发前按服务商/模型支持的区间修正
    render_width: IntProperty(
        name="Width",
        description="Output width in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=_RENDER_DIM_MIN,
        max=_RENDER_DIM_MAX,
        subtype='PIXEL',
        update=_on_render_width_update,
    )  # type: ignore
    render_height: IntProperty(
        name="Height",
        description="Output height in pixels, adjusted to the provider's supported range automatically",
        default=1024,
        min=_RENDER_DIM_MIN,
        max=_RENDER_DIM_MAX,
        subtype='PIXEL',
        update=_on_render_height_update,
    )  # type: ignore
    # 参考通道勾选(面板顺序即需求通道序: 合并结果/深度/法向/语义分割/线稿/漫射颜色/AO);
    # 七通道一律由 EEVEE 出(合并结果/深度/法向/漫射颜色/AO 共享一帧, 语义分割与线稿各一帧),
    # 面板不再有捕获引擎选项;
    # "Line Drawing"为避开系统词条 "Lines"(线) 的改写原文, 入典出"线稿"
    use_combined: BoolProperty(
        name="Combined Result",
        description="Capture the combined render as a reference image",
        default=True,
    )  # type: ignore
    use_depth: BoolProperty(
        name="Depth",
        description="Capture the depth pass as a reference image (foreground white, background black)",
        default=True,
    )  # type: ignore
    use_normal: BoolProperty(
        name="Normal",
        description="Capture the normal pass as a reference image",
        default=False,
    )  # type: ignore
    use_segmentation: BoolProperty(
        name="Semantic Segmentation",
        description="Capture the object segmentation pass as a reference image (a unique color per object)",
        default=False,
    )  # type: ignore
    use_edge: BoolProperty(
        name="Line Drawing",
        description="Capture the scene grease pencil line art as a reference image",
        default=False,
    )  # type: ignore
    use_diffuse: BoolProperty(
        name="Diffuse Color",
        description="Capture the diffuse color pass as a reference image",
        default=False,
    )  # type: ignore
    use_ao: BoolProperty(
        name="AO",
        description="Capture the ambient occlusion pass as a reference image",
        default=False,
    )  # type: ignore
    # ---- 发送通道开关(与捕获勾选独立): 效果图生成发送哪些已捕获的通道图 ----
    # 捕获勾选只控制"生成通道"按钮捕获哪些; 发送勾选在通道列表行首(见 items.pass_send_attr),
    # 支持多捕获/挑着发; 出厂与捕获勾选一致(Combined/Depth 开), 勾选但未捕获的通道在生成时报"请先生成通道"
    use_send_combined: BoolProperty(
        name="Combined Result",
        description="Send the captured combined render to the AI as a reference image",
        default=True,
    )  # type: ignore
    use_send_depth: BoolProperty(
        name="Depth",
        description="Send the captured depth pass to the AI as a reference image",
        default=True,
    )  # type: ignore
    use_send_normal: BoolProperty(
        name="Normal",
        description="Send the captured normal pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_segmentation: BoolProperty(
        name="Semantic Segmentation",
        description="Send the captured segmentation pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_edge: BoolProperty(
        name="Line Drawing",
        description="Send the captured line art pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_diffuse: BoolProperty(
        name="Diffuse Color",
        description="Send the captured diffuse color pass to the AI as a reference image",
        default=False,
    )  # type: ignore
    use_send_ao: BoolProperty(
        name="AO",
        description="Send the captured ambient occlusion pass to the AI as a reference image",
        default=False,
    )  # type: ignore
