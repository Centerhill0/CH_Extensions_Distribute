"""
实时同步处理器模块

提供以下功能:
- sync_scripts_now: 脚本列表快照立即刷新(供脚本写入后调用)
- sync_images_now: 主图像列表与通道预览迷你列表快照立即刷新(供图像生成后调用)
- move_list_item: 列表高亮条目上移/下移(排序写进数据块自定义属性, 持久且跨机)
- activate_script_top: 生成/提取/写回后置顶该脚本并同步快照, 按面板开关聚焦并高亮
- activate_image: 图像生成/修改后同步快照, 把主图像列表高亮指向该图并按面板开关聚焦图像编辑器
  (top=True 时先把新产物置顶到列表第一位; 高亮列表按产物前缀归属, 见 image_list_for_name)
- select_image_by_name: 按数据块名选中图像(预览区缩略图选中联动, 与点击列表行同款)
- gallery_visible_items / select_gallery_value: 缩略图可见项(过滤+上限)与选中值回写(仅写可见项)
- 脚本/对话/图像列表活跃索引 update 回调: 点击行按面板开关聚焦编辑器或切换图像编辑器
- open_chat_message: 按面板开关把当前高亮对话消息转出到 AI_Chat.txt 并聚焦文本编辑器
- dump_chat_history: 对话历史写入 AI_Chat_History.json 文本块(对话存于 WM, 每次变动后落块随 blend 保存)
- dump_image_refs / migrate_legacy_capture_params: 参考图引用(JSON 文本块)持久化与旧版捕获参数存档归一
  (捕获参数现为场景挂载的 RNA 组, 随 blend 原生保存, 不再走 dump/restore)
- load_post 处理器: 快照存于 WM 跨文件保留, 载入后立即对齐; 对话/参考图按当前文件恢复, 旧版捕获参数存档归一为 RNA 组
- 周期计时器: 兜底刷新(文本块/图像数据块增删改不触发 depsgraph)
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接
- 快照重建与重入护栏机制见 common.blender.list_snapshot
"""

import time

import bpy
from bpy.types import Context

from ...common.blender.list_order import materialize_orders, order_key, swap_orders
from ...common.blender.list_snapshot import find_item_index, is_syncing, rebuild_if_changed, set_guarded, set_index, set_index_by_name
from .items import REF_ACTIVE_ATTRS
from .items import pass_send_attr
from .utils import (
    AI_CHAT_HISTORY_NAME,
    AI_CHAT_TEXT_NAME,
    AI_IMAGE_REFS_NAME,
    AI_IMAGE_PREFIX,
    AI_REF_PREFIX,
    AI_RENDER_PREFIX,
    AI_SCRIPT_PREFIX,
    AI_TEXTURE_PREFIX,
    focus_image_editors,
    focus_text_editors,
    parse_chat_history,
    parse_image_refs,
    serialize_chat_history,
    serialize_image_refs,
    texture_channel_key,
    write_text_block,
)

# 脚本列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0

# 列表排序键的数据块自定义属性名(随 blend 保存, 跨机一致)
_ORDER_KEY = "ch_ai_order"

# 等待状态三件组(scope -> status_<scope>/wait_<scope>/cancel_<scope>)的作用域全集,
# 与 ai_generate 的 status_scope 取值一致('test' 供偏好连通性测试用, 无面板进度与中断按钮;
# 'image' 供图像生成器三个模式共用; 'capture' 是通道捕获的本地渲染进度)
_WAIT_SCOPES = ("script", "chat", "image", "capture", "test")


def _datablock(names_kind: str, name: str):
    """按列表种类取条目对应的真实数据块"""
    if names_kind == 'TEXT':
        return bpy.data.texts.get(name)
    return bpy.data.images.get(name)


def _sorted_names(names: list, names_kind: str) -> list:
    """按数据块自定义属性 ch_ai_order 排序(未排序条目按名序排后, 稳定; 算法见 common.list_order)"""

    def key(name: str):
        block = _datablock(names_kind, name)
        return order_key(block, _ORDER_KEY) if block is not None else (1, 0, name)

    return sorted(names, key=key)


def _prefixed_names(collection, prefixes: tuple, names_kind: str) -> list:
    """按前缀过滤数据块名并排序(列表快照的名收集单一入口; prefixes 走 startswith 元组匹配)"""
    names = [b.name for b in collection if b.name.startswith(prefixes)]
    return _sorted_names(names, names_kind)


def _script_names() -> list:
    """脚本列表名称序列(仅 AI 前缀脚本; 长文描述块与对话查看块无此前缀, 天然排除)"""
    return _prefixed_names(bpy.data.texts, (AI_SCRIPT_PREFIX,), 'TEXT')


def _image_names() -> list:
    """主图像列表的名称序列(图像与效果图模式产物: 图像 "AI Bmp" / 效果图版本链 "AI Render";
    材质贴图产物 "AI Tex" 走材质通道列表 _tex_image_names, 通道预览图走 _pass_image_names)"""
    return _prefixed_names(bpy.data.images, (AI_IMAGE_PREFIX, AI_RENDER_PREFIX), 'IMAGE')


def _tex_image_names() -> list:
    """材质通道列表的名称序列(材质贴图产物 "AI Tex" 前缀过滤: 颜色贴图/通道贴图/修改备份同列)"""
    return _prefixed_names(bpy.data.images, (AI_TEXTURE_PREFIX,), 'IMAGE')


def _pass_image_names() -> list:
    """效果图通道预览迷你列表的名称序列(固定名捕获预览 "AI Ref: " 前缀过滤)"""
    return _prefixed_names(bpy.data.images, (AI_REF_PREFIX,), 'IMAGE')


# 可排序列表的目标表: target -> (状态组属性名, 索引属性名, 数据块类型, 名字收集器)
# 单一来源: 新增可排序列表只在此加一行(原为 move_list_item 内的 if/elif 梯子)
_REORDER_TARGETS = {
    'SCRIPT': ("ch_ai_state", "scripts_active_index", 'TEXT', _script_names),
    'IMAGE': ("ch_ai_image_state", "images_active_index", 'IMAGE', _image_names),
}


def move_list_item(target: str, direction: str) -> bool:
    """列表高亮条目与相邻条目交换排序位置, 返回是否移动

    target: 'SCRIPT'/'IMAGE'(与算子枚举标识一致); direction: 'UP'/'DOWN'.
    首次移动时把当前顺序全量写入数据块自定义属性(此后移动为纯交换),
    快照顺序随 _sorted_names 反映, 排序持久且不随快照重建丢失.
    **已知口径**: 名称过滤开启时"相邻"按快照序取,
    视觉相邻行可能被过滤隐藏导致按钮看似无效——UIList 内建过滤的通用行为,
    与"反序漏斗下钉住行翻到末尾"同口径, 不做特殊处理.
    """
    spec = _REORDER_TARGETS.get(target)
    if spec is None:
        return False
    wm_attr, idx_name, kind, collect_names = spec
    state = getattr(bpy.context.window_manager, wm_attr)
    names = collect_names()

    idx = getattr(state, idx_name)
    j = idx - 1 if direction == 'UP' else idx + 1
    if not (0 <= idx < len(names)) or not (0 <= j < len(names)):
        return False
    blocks = [_datablock(kind, name) for name in names]
    if any(b is None for b in blocks):
        return False
    # 先把当前显示序固化为 0..N-1, 再交换相邻两项: 既有顺序值可能稀疏(删过条目/混有
    # 历史值), 只补缺失值会给缺失项写入与既有项冲突的值, 交换时连带重排无关条目.
    materialize_orders(blocks, _ORDER_KEY)
    a, b = blocks[idx], blocks[j]
    swap_orders(a, b, _ORDER_KEY)
    # 立即重建快照反映新顺序(不等计时器节拍), 高亮跟随移动后的条目(护栏内写入, 不触发点击回调)
    if kind == 'TEXT':
        sync_scripts_now()
    else:
        sync_images_now()
    set_index(state, idx_name, j)
    return True


def reset_wait_scope(state, scope: str) -> None:
    """清空单个面板作用域的等待标志(进度文案/已等待秒数/中断标志三件组)

    请求收尾与模态挂载失败只清本面板: 跨面板可并行, 全清会抹掉其它面板仍在运行的标志
    (用户可再次发送 -> 重复请求与重复计费).
    """
    setattr(state, f"status_{scope}", "")
    setattr(state, f"wait_{scope}", 0)
    setattr(state, f"cancel_{scope}", False)


def reset_wait_state(state):
    """清空 AI 请求等待标志(各面板的进度文案/已等待秒数/中断标志三件组)

    等待状态只由等待模态清理, 而模态按窗口持有: 等待期间载入 .blend 或关闭承载窗口会让模态
    被丢弃, 标志却留在 WM 里 → 之后所有请求都被"已有请求在跑"永久拒绝, 只能重启 Blender.
    故 load_post 与模态挂载失败时都调用本函数回收(全 scope 一并清).
    单项收尾请用 reset_wait_scope, 不要动其它面板.
    """
    for scope in _WAIT_SCOPES:
        reset_wait_scope(state, scope)


# ------------------------------------------------------------
# 等待模态看门狗(关窗丢模态的兜底)
# ------------------------------------------------------------

# 等待模态心跳表: scope -> 最近一次心跳(time.monotonic)与超时回收回调。
# 模态与事件计时器都按窗口持有(event_timer_add(window=...)): 等待期间关闭承载窗口
# 会把模态与计时器一并丢弃, status_<scope> 三件组却留在 WM 里——load_post 只覆盖
# 载入 .blend 一条路径, 该面板此后所有请求都被"已有请求在跑"永久拒绝. 看门狗借
# _sync_timer 巡检: 存活模态以 0.1~0.25s 周期续跳, status 非空而心跳超过阈值未刷新
# 即判定模态已死, 回收该 scope; 捕获模态另带回收回调 close 会话(临时场景等
# bpy.data 侧资源的唯一回收点), 否则泄漏随 .blend 保存.
_REQUEST_TICKS: dict = {}
_REQUEST_ON_STALE: dict = {}
_WATCHDOG_STALE_SECONDS = 5.0


def register_wait_modal(scope: str, on_stale=None) -> None:
    """登记等待模态心跳(模态启动成功后调用一次); on_stale 为超时回收回调(可选, 重复登记覆盖)"""
    _REQUEST_TICKS[scope] = time.monotonic()
    _REQUEST_ON_STALE[scope] = on_stale


def keepalive_wait_modal(scope: str) -> None:
    """续跳等待模态心跳(模态 TIMER 分支每轮调用)"""
    _REQUEST_TICKS[scope] = time.monotonic()


def clear_wait_modal(scope: str) -> None:
    """注销等待模态心跳(正常收尾调用, 防看门狗对已收尾的 scope 误判)"""
    _REQUEST_TICKS.pop(scope, None)
    _REQUEST_ON_STALE.pop(scope, None)


def sweep_stale_wait_modals() -> None:
    """看门狗巡检: 回收"模态已死但等待标志残留"的 scope

    判据: 登记表内的 scope 心跳超过阈值未续跳. 只处理登记过的 scope,
    未经登记的残留标志(旧版本遗留/外脚本写入)仍由 load_post 回收.
    """
    if not _REQUEST_TICKS:
        return
    now = time.monotonic()
    stale = [scope for scope, last in _REQUEST_TICKS.items() if now - last > _WATCHDOG_STALE_SECONDS]
    if not stale:
        return
    wm = getattr(bpy.context, "window_manager", None)
    state = getattr(wm, "ch_ai_state", None) if wm is not None else None
    for scope in stale:
        on_stale = _REQUEST_ON_STALE.pop(scope, None)
        _REQUEST_TICKS.pop(scope, None)
        if state is not None:
            reset_wait_scope(state, scope)
        if on_stale is not None:
            try:
                on_stale()
            except Exception:
                pass
    # 模态死了没人清状态栏等待文案: 各窗口工作区一并复位(下次置位会覆盖, 此处求干净)
    if wm is not None:
        for window in wm.windows:
            workspace = getattr(window, "workspace", None)
            if workspace is not None:
                try:
                    workspace.status_text_set(None)
                except (ReferenceError, AttributeError):
                    pass


def sync_scripts_now():
    """立即重建脚本列表快照(生成/调试写入文本块后调用, 不等计时器节拍)"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())


def sync_images_now():
    """立即重建主图像列表/材质通道列表与通道预览迷你列表快照(图像生成/捕获预览后调用, 不等计时器节拍)

    主列表收图像与效果图产物(AI Bmp/AI Render), 材质贴图产物(AI Tex)走材质通道列表,
    通道预览图(AI Ref: 前缀)走独立集合; 重建后把缩略图选中值对齐到当前高亮项:
    条目被删除/改名导致快照变化时, 缩略图的选中态不会停在已不存在的名字上.
    """
    state = bpy.context.window_manager.ch_ai_image_state
    rebuild_if_changed(state, "images", "images_active_index", 'IMAGE', _image_names())
    rebuild_if_changed(state, "tex_images", "tex_images_active_index", 'IMAGE', _tex_image_names())
    rebuild_if_changed(state, "pass_images", "pass_images_active_index", 'IMAGE', _pass_image_names())
    # 发送开关画在通道列表行首, 行随预览图删除而消失后开关会变成不可达的幽灵勾选
    # (阻断发送组装又无从取消), 以重建后的快照为准对账回落;
    # render_send 顶层反向导入本模块, 只能延迟导入(与 _on_load_post 同款)
    from .operators.render_send import sync_send_toggles

    present = set()
    for entry in state.pass_images:
        attr = pass_send_attr(entry.name)
        if attr is not None:
            present.add(attr)
    sync_send_toggles(state, present)
    _align_gallery_to_index(state)


def _align_gallery_to_index(state):
    """把缩略图选中值对齐到列表当前高亮项(护栏内写入, 不触发缩略图回调)"""
    idx = state.images_active_index
    if not 0 <= idx < len(state.images):
        return
    select_gallery_value(state, state.images[idx].name)


def gallery_visible_items(state) -> list:
    """预览区缩略图当前可见的列表条目: 按名称过滤(不区分大小写) + 显示条数上限截断

    顺序即列表快照顺序(生成置顶后新产物在前), 故上限截断保留的是列表前若干项.
    """
    pattern = state.gallery_filter.strip().lower()
    limit = state.gallery_limit
    visible = []
    for item in state.images:
        if pattern and pattern not in item.name.lower():
            continue
        visible.append(item)
        if limit > 0 and len(visible) >= limit:
            break
    return visible


def select_gallery_value(state, name: str) -> bool:
    """把缩略图选中值指向该图像(仅当它在当前过滤/上限下可见; 护栏内写入, 不触发回调)

    不在候选表内的标识写进动态枚举会抛 TypeError(控制台留 traceback), 故先判可见性;
    返回是否写入(未写入表示该图当前在缩略图视野外, 选中态保持原样, 不影响列表高亮).
    """
    if state.gallery_image == name:
        return False
    if not any(item.name == name for item in gallery_visible_items(state)):
        return False
    set_guarded(state, "gallery_image", name)
    return True


def _highlight_image(state, name: str, collection: str = "images", index_name: str = "images_active_index") -> bool:
    """把图像列表高亮与预览区画廊选中值指向该图(护栏内写入, 不触发点击联动), 返回是否命中

    collection/index_name 支持通道迷你列表(pass_images)复用; 画廊选中值仅主列表同步.
    """
    idx = find_item_index(state, collection, name)
    if idx < 0:
        return False
    set_index(state, index_name, idx)
    if collection == "images":
        # 缩略图选中值与列表高亮保持同步(被过滤/上限挡住时不写, 见 select_gallery_value)
        select_gallery_value(state, name)
    return True


def select_image_by_name(context: Context, state, name: str) -> bool:
    """按数据块名选中图像: 高亮列表条目并按本面板开关切换图像编辑器, 返回是否命中

    供预览区画廊的选中回调调用(与点击列表行同款联动, 只是来源是画廊缩略图).
    """
    if not _highlight_image(state, name):
        return False
    if state.use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focus_image_editors(context, image)
    return True


def image_list_for_name(name: str) -> tuple:
    """按产物名前缀解析其所属列表(collection, index_name)

    材质贴图产物(AI Tex: 颜色贴图/通道贴图/修改备份)进材质通道列表, 其余(图像/效果图)进主列表;
    生成/修改落地的高亮归属单一来源(调用方无需自带列表参数).
    """
    if name.startswith(AI_TEXTURE_PREFIX):
        return "tex_images", "tex_images_active_index"
    return "images", "images_active_index"


def activate_image(context: Context, state, name: str, top: bool = False) -> int:
    """图像生成/修改后: 同步快照, 把图像列表高亮指向该图, 按面板开关聚焦图像编辑器

    state 为图像生成器状态组(读其"自动打开图像"开关); 高亮列表按产物前缀自动归属
    (材质贴图产物进材质通道列表, 见 image_list_for_name); top=True 时先置顶(排序号取
    当前最小减一, 与脚本列表同款: 新产物排列表第一位, 不随名称序下沉; 材质通道列表
    快照同用 ch_ai_order 排序键, 置顶同样生效); 返回聚焦到的图像编辑器区域数,
    **-1 表示该面板的开关关闭而未做聚焦**(调用方据此与"没有打开的图像编辑器"区分,
    后者才提示).
    """
    if top:
        image = bpy.data.images.get(name)
        if image is not None:
            orders = [i.get(_ORDER_KEY) for i in bpy.data.images if i.get(_ORDER_KEY) is not None]
            image[_ORDER_KEY] = (min(orders) - 1) if orders else 0
    sync_images_now()
    focused = 0
    if state.use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focused, _ = focus_image_editors(context, image)
    else:
        focused = -1
    _highlight_image(state, name, *image_list_for_name(name))
    return focused


def activate_pass_image(context: Context, name: str):
    """通道预览捕获后: 同步快照, 把通道迷你列表高亮指向该图, 按面板开关聚焦图像编辑器

    通道预览图(AI Ref: 前缀)不进主列表(列表分离), 高亮走迷你列表;
    与 activate_image 的 top 置顶不同, 迷你列表顺序由快照(名称排序)决定, 无置顶.
    """
    sync_images_now()
    state = context.window_manager.ch_ai_image_state
    _highlight_image(state, name, collection="pass_images", index_name="pass_images_active_index")
    if not state.use_auto_open_images:
        return
    image = bpy.data.images.get(name)
    if image is not None:
        focus_image_editors(context, image)


def activate_script_top(context: Context, name: str):
    """提取代码落块后: 置顶(排序号设为当前最小减一), 同步快照, 按面板开关聚焦并高亮该脚本"""
    block = bpy.data.texts.get(name)
    if block is None:
        return
    orders = [b.get(_ORDER_KEY) for b in bpy.data.texts if b.get(_ORDER_KEY) is not None]
    block[_ORDER_KEY] = (min(orders) - 1) if orders else 0
    sync_scripts_now()
    state = context.window_manager.ch_ai_state
    if state.use_auto_open_scripts:
        focus_text_editors(context, block)
    set_index_by_name(state, "scripts", "scripts_active_index", name)


def on_scripts_index_update(self, context: Context):
    """脚本列表活跃索引回调: 面板开关开启时, 用户点击行把文本编辑器聚焦到该脚本"""
    if not self.use_auto_open_scripts:
        return
    if is_syncing() or not 0 <= self.scripts_active_index < len(self.scripts):
        return
    text = bpy.data.texts.get(self.scripts[self.scripts_active_index].name)
    if text is not None:
        focus_text_editors(context, text)


def open_chat_message(context: Context, state):
    """按面板开关把当前高亮对话消息写入 AI_Chat.txt 并聚焦文本编辑器

    供对话活跃索引 update 回调(点击列表行)与回复写入后的联动调用;
    转出后完整内容在文本编辑器阅读, 列表行内仅显示首行.
    """
    if not state.use_auto_open_chat:
        return
    idx = state.chat_active_index
    if not 0 <= idx < len(state.chat_messages):
        return
    text, _ = write_text_block(AI_CHAT_TEXT_NAME, state.chat_messages[idx].content)
    focus_text_editors(context, text)


def on_chat_index_update(self, context: Context):
    """对话消息活跃索引回调: 开关开启时, 用户点击行把该消息转出到文本编辑器

    护栏内的程序化写入(删除消息后的索引压回等)跳过联动——与脚本/图像/通道三个索引回调
    同款口径, 否则删除末条消息会把相邻消息写进 AI_Chat.txt 并抢走文本编辑器焦点.
    """
    if is_syncing():
        return
    open_chat_message(context, self)


def _sync_channel_source(state, name: str) -> None:
    """材质通道颜色源跟随列表高亮(仅有效颜色源覆盖, 判定口径与回落路径一致)

    高亮项是有效颜色源(AI Tex 颜色贴图/无尾缀旧产物)时覆盖颜色源指针, 拾取框同步显示;
    点击图像/效果图/通道产物不动源——通道生成后高亮落在通道产物上, 无条件跟随会让
    下一次派生以通道产物为源; 数据块悬空(高亮项已删)同样不动.
    """
    if not name.startswith(AI_TEXTURE_PREFIX):
        return
    if texture_channel_key(name) not in ('color', None):
        return
    image = bpy.data.images.get(name)
    if image is not None:
        state.channel_source = image


def on_image_index_update(self, context: Context):
    """主图像列表活跃索引回调: 用户点击行时同步缩略图选中态, 并按本面板开关切换图像编辑器

    缩略图选中值与"自动打开图像"开关无关(列表切换后缩略图的选中态必须跟着走),
    编辑器切换才受开关控制; 主列表只收图像/效果图产物, 材质通道颜色源跟随在
    材质通道列表回调(见 on_tex_index_update).
    """
    if is_syncing() or not 0 <= self.images_active_index < len(self.images):
        return
    name = self.images[self.images_active_index].name
    # 缩略图选中态跟到点击的条目(护栏内写入, 不触发缩略图回调造成二次聚焦)
    select_gallery_value(self, name)
    if self.use_auto_open_images:
        image = bpy.data.images.get(name)
        if image is not None:
            focus_image_editors(context, image)


def on_tex_index_update(self, context: Context):
    """材质通道列表活跃索引回调: 有效颜色源高亮跟随 + 按面板开关把图像编辑器切换到该图

    跟随与编辑器切换都只对用户点击生效(护栏内写入跳过, 与主列表同款口径);
    跟随判定见 _sync_channel_source(仅 AI Tex 颜色贴图/无尾缀旧产物覆盖指针).
    """
    if is_syncing() or not 0 <= self.tex_images_active_index < len(self.tex_images):
        return
    name = self.tex_images[self.tex_images_active_index].name
    _sync_channel_source(self, name)
    if not self.use_auto_open_images:
        return
    image = bpy.data.images.get(name)
    if image is not None:
        focus_image_editors(context, image)


def on_pass_index_update(self, context: Context):
    """通道预览迷你列表活跃索引回调: 点击行按面板开关把图像编辑器切换到该通道预览图

    与主列表点击同款开关控制; 迷你列表不联动缩略图画廊(通道图不进主列表与画廊).
    """
    if is_syncing() or not 0 <= self.pass_images_active_index < len(self.pass_images):
        return
    if not self.use_auto_open_images:
        return
    image = bpy.data.images.get(self.pass_images[self.pass_images_active_index].name)
    if image is not None:
        focus_image_editors(context, image)


def _focus_ref_mini_list(state, context: Context, coll_attr: str, index_attr: str) -> None:
    """参考图迷你列表点击联动: 按面板开关把图像编辑器切到高亮的参考图(缺图占位条目跳过)"""
    if is_syncing() or not 0 <= getattr(state, index_attr) < len(getattr(state, coll_attr)):
        return
    if not state.use_auto_open_images:
        return
    ref = getattr(state, coll_attr)[getattr(state, index_attr)]
    if ref.image is not None:
        focus_image_editors(context, ref.image)


def on_ref_index_update(self, context: Context):
    """参考图迷你列表活跃索引回调: 点击行按面板开关把图像编辑器切换到该参考图

    三模式共用一个参考图列表(缺图占位条目跳过; 描述行随高亮切换由面板 draw 跟随).
    """
    _focus_ref_mini_list(self, context, "ref_images", "ref_images_active_index")


# ------------------------------------------------------------
# 对话历史持久化(随 blend 保存, 载入恢复)
# ------------------------------------------------------------


def dump_chat_history(state) -> None:
    """把当前对话历史写入 AI_Chat_History.json 文本块(随 blend 保存)

    对话消息存于 WM 本不随 blend 保存, 重启即失; 每次变动后调用本函数落块,
    载入时经 _on_load_post 恢复. 全程兜住异常: 持久化失败不影响对话本身.
    偏好关闭持久化时直接跳过, 不把对话写进工程文件.
    """
    try:
        from .preference import get_prefs

        if not get_prefs().persist_chat_history:
            return
        pairs = [(m.role, m.content) for m in state.chat_messages]
        write_text_block(AI_CHAT_HISTORY_NAME, serialize_chat_history(pairs, state.chat_active_index))
    except Exception:
        pass


def _restore_chat(state) -> None:
    """用当前 blend 的持久化对话历史替换 WM 对话(对话逐文件独立, 随文件切换/载入恢复)"""
    from .preference import get_prefs

    block = bpy.data.texts.get(AI_CHAT_HISTORY_NAME)
    if not get_prefs().persist_chat_history:
        # 关闭持久化只"不写不读": 工程里既有的历史块属于用户数据, 不在此处删除
        # (载入回调里静默删除会让用户临时关一次开关就永久失去已存对话)
        state.chat_messages.clear()
        state.chat_script_name = ""
        state.chat_active_index = 0
        return
    parsed = parse_chat_history(block.as_string()) if block is not None else None
    state.chat_messages.clear()
    state.chat_script_name = ""
    if parsed is None:
        state.chat_active_index = 0
        return
    messages, active = parsed
    for role, content in messages:
        item = state.chat_messages.add()
        item.role = role
        item.content = content
    state.chat_active_index = active


# ------------------------------------------------------------
# 参考图引用与捕获参数持久化(随 blend 保存, 载入恢复)
# ------------------------------------------------------------

# 恢复期间静默 dump(条目描述的 update 回调在重建时会触发)
_restore_refs_in_progress = False


def dump_image_refs() -> None:
    """把参考图引用写入 AI_Image_Refs.json 文本块(随 blend 保存, 载入时恢复)

    三模式共用一个参考图列表, 只存一节(旧版纹理/效果图两节在恢复时合并);
    描述编辑(条目 update 回调)与结构变动(加载/移除/清描述)都会触发; 恢复期间静默.
    全程兜住异常: 持久化失败不影响引用本身.
    """
    if _restore_refs_in_progress:
        return
    try:
        state = bpy.context.window_manager.ch_ai_image_state
        refs = [(ref.image.name if ref.image is not None else "", ref.description, {key: getattr(ref, key) for key in REF_ACTIVE_ATTRS}) for ref in state.ref_images]
        write_text_block(AI_IMAGE_REFS_NAME, serialize_image_refs(refs))
    except Exception:
        pass


def _restore_image_refs() -> None:
    """从 AI_Image_Refs.json 恢复参考图引用(按数据块名找回图像, 缺失保条目占位)

    旧版两节(texture / render)由 parse_image_refs 合并去重后返回, 下次保存写成单节;
    无存档块的文件一律清空现役引用: 引用指向的图像数据块本就属于旧文件,
    载入新文件后指针必然悬空, 留着只会误导.
    """
    global _restore_refs_in_progress
    block = bpy.data.texts.get(AI_IMAGE_REFS_NAME)
    parsed = parse_image_refs(block.as_string()) if block is not None else None
    refs = parsed if parsed is not None else []
    state = bpy.context.window_manager.ch_ai_image_state
    _restore_refs_in_progress = True
    try:
        coll = state.ref_images
        coll.clear()
        for name, description, active in refs:
            item = coll.add()
            item.image = bpy.data.images.get(name) if name else None
            item.description = description
            # 激活标志缺失(旧档)时保持属性默认值(三模式全开); 非法键(手改存档)忽略
            for key, value in active.items():
                if key in REF_ACTIVE_ATTRS:
                    setattr(item, key, value)
        set_guarded(state, "ref_images_active_index", 0)
    finally:
        _restore_refs_in_progress = False


# 旧版捕获参数存档的场景自定义属性键(新版迁为场景挂载的 RNA 组, 键名不变;
# 存取由 RNA 原生接管, 旧档经 migrate_legacy_capture_params 归一)
_LEGACY_CAPTURE_KEY = "ch_ai_capture_params"


def migrate_legacy_capture_params(scene) -> None:
    """把旧版"场景自定义属性裸字典"的捕获参数归一为 RNA 组存储(载入时调用, 幂等)

    旧版经 update 回调把 11 项参数 dump 成裸 idprop(枚举=字符串/向量为数组/布尔=bool);
    RNA 枚举底层是 int 存储, 包装器不收养类型不合的子项(实测整组回落出厂默认),
    故读回裸值经 RNA 属性重赋值即归一为原生存储(归一后重赋同值无副作用).
    新文件无存档组时直接用 RNA 默认值, 不产生写入.
    """
    raw = scene.get(_LEGACY_CAPTURE_KEY)
    if raw is None:
        return
    try:
        # IDPropertyGroup 在 5.1 已不是 dict 子类(实测 isinstance(x, dict) 为 False),
        # 组形态判定改按 .items() 可用性; 手改成标量的存档无从迁移, 保持 RNA 默认
        entries = list(raw.items())
    except AttributeError:
        return
    cstate = scene.ch_ai_capture_params
    for key, value in entries:
        try:
            setattr(cstate, key, value)
        except (TypeError, ValueError, AttributeError, KeyError):
            # 手改存档注入的非法枚举值(TypeError)/维度不符向量(ValueError)/未知键:
            # 跳过该项并保持 RNA 默认(异常类型经 5.1.2 后台探针实测)
            continue


# ------------------------------------------------------------
# 文件 -> 列表同步
# ------------------------------------------------------------


# 原生输出分辨率快照(上次观察到的输出属性 Resolution X/Y/%)与写入纪律: 只经
# _sync_render_size 赋值(模块级状态, 见 render_send 同款纪律)
_last_render_res: tuple | None = None


def _sync_render_size():
    """原生输出分辨率变化联动: 检出输出属性的分辨率三元组变化时按当前档位重回填效果图尺寸

    原生属性(输出属性面板的 Resolution X/Y/%)改动不触发本插件的 update 回调,
    由周期兜底同步对比快照检出; 首次观察只记快照不回填(启动期的面板数值不凭空跳变).
    """
    global _last_render_res
    scene = getattr(bpy.context, "scene", None)
    rd = getattr(scene, "render", None) if scene is not None else None
    if rd is None:
        return
    current = (rd.resolution_x, rd.resolution_y, rd.resolution_percentage)
    if _last_render_res is None or current == _last_render_res:
        _last_render_res = current
        return
    _last_render_res = current
    # props 顶层反向导入本模块, 只能延迟导入(与 _on_load_post 同款)
    from .props import refresh_render_size_from_scene

    refresh_render_size_from_scene(bpy.context.window_manager.ch_ai_image_state, bpy.context)


def _sync_all():
    """全量同步: 有变化才重建脚本列表与图像列表快照"""
    state = bpy.context.window_manager.ch_ai_state
    rebuild_if_changed(state, "scripts", "scripts_active_index", 'TEXT', _script_names())
    sync_images_now()
    _sync_render_size()


def _on_load_post(*_args):
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐; 对话/参考图按文件恢复,
    捕获参数从场景自定义属性恢复, 等待标志一并回收(模态已失效)

    另清两个跨文件不失效的模块级全局状态(延迟导入以避开 handlers<->operators 循环依赖):
    - 通道捕获发送缓存(_PASS_CAPTURE_CACHE)与参数指纹: 不重启 Blender 载入另一文件时,
      旧文件的通道字节仍在缓存, 会被误判为"已捕获"而把上个场景的通道图当参考图发出,
      必须随文件切换清空.
    - 自动命名待办表(_auto_name_pending): 残留的旧文件命名结果落地时会按名找回图像,
      找不到即静默跳过(无害), 但随文件切换清掉更干净.
    """
    try:
        wm = bpy.context.window_manager
        reset_wait_state(wm.ch_ai_state)
        _restore_chat(wm.ch_ai_state)
        _restore_image_refs()
        migrate_legacy_capture_params(bpy.context.scene)
        # 跨文件失效的模块级缓存: 发送缓存/指纹与自动命名待办一并回收
        from .operators.render_send import clear_pass_cache
        from .operators.ai_generate import clear_auto_name_pending

        clear_pass_cache()
        clear_auto_name_pending()
        _sync_all()
    except Exception:
        # 恢复链中途抛错会跳过 _sync_all(靠 1s 计时器自愈): 放宽到全量兜底,
        # ReferenceError/AttributeError 之外的服务端恢复路径异常同样不炸回调
        pass


def _sync_timer():
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    try:
        _sync_all()
        # 等待模态看门狗: 回收被窗口关闭丢弃的模态留下的等待标志(详见 sweep docstring)
        sweep_stale_wait_modals()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register():
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister():
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
