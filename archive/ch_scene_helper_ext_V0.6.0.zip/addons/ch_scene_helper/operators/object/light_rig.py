"""灯光控制器 rig 操作器模块

"空物体控制器(父级) + 面光源"rig 的全套交互:
- LightAdd: 添加灯光壳算子(默认弹原生灯光选择面板; +Shift/+Ctrl/+Alt 直接建 rig)
- LightCopy / LightInstanceCopy: 复制灯光(数据独立副本) / 实例复制(共享灯光数据)
- LightControllerAdd / LightControllerRemove: 给活动灯光加/摘控制器
- LightRigAdjust: L 键模态, 调灯光方位/距离/功率与控制器吸附对齐

操作流程:
- 面板按钮族(复制/实例/加控制器/摘控制器)作用于灯光面板的活跃灯光行;
- 模态算子按"选到灯光或控制器或二者都选中"解析 rig, 从任一侧进入都能操作整套;
- rig 硬性约束: 一个控制器只挂一个灯光子级(作者 2026-10-28 定).

快捷键:
- L: LightRigAdjust(仅物体模式, 选区里有 rig; 键位见 keymaps.py 的 LIGHT_RIG 组)
- 面板"+"按钮的修饰键: +Shift 活动物体位置 / +Ctrl 游标 / +Alt 世界原点
"""

import bpy
from math import degrees

from mathutils import Matrix, Vector
from bpy.props import BoolProperty
from bpy.types import Context, Event, Object, Operator

from .....common.i18n.i18n import iface, report
from ...handlers import refresh_lists, set_sync_suppressed
from ...modal_base import ModalOperatorMixin, draw_status_item, force_statusbar_redraw, force_ui_update, ignore_events, navigation_passthrough
from ...scene_state import active_block, highlight_item
from ...utils import (
    add_controller,
    align_controller_y,
    collect_light_blocks,
    copy_light_rig,
    create_light_rig,
    get_controller_azimuth,
    get_controller_elevation,
    get_light_distance,
    is_selectable,
    raycast_surface,
    reflection_direction,
    remove_controller,
    reset_controller,
    resolve_rig,
    rig_controller_of,
    set_controller_azimuth,
    set_controller_elevation,
    set_light_distance,
)
from ..utils._base import TranslatedDescriptionMixin
from ...preference import get_prefs

# 模态的调节模式键(A/S/D 互斥切换, 按下即换档; 进入模态默认 A 档)
_AXIS_KEYS = ('A', 'S', 'D')


def _draw_rig_status(op):
    """模态状态栏: 组合键提示(绘制风格对齐 chamfer.py 的 ChamferToFillet;

    作者 2026-10-29 定: 不画算子标题, 导航三键后跟 A/S/D 模式键, 再 Shift/Ctrl/Alt)
    """

    def draw(self, context: Context):
        row = self.layout.row(align=True)
        draw_status_item(row, key='LMB', text=iface("Finish"))
        draw_status_item(row, key='MMB', text=iface("Viewport Navigation"))
        draw_status_item(row, key='RMB', text=iface("Cancel"))
        draw_status_item(row, key='A', text=iface("Azimuth/Elevation"), gap=1)
        draw_status_item(row, key='S', text=iface("Brightness"))
        draw_status_item(row, key='D', text=iface("Distance"))
        draw_status_item(row, key='SHIFT', text=iface("Precise"), gap=1)
        draw_status_item(row, key='CTRL', text=iface("Snap Normal"))
        draw_status_item(row, key='ALT', text=iface("Snap Reflect"))

    return draw


def _panel_light(context: Context):
    """灯光面板活跃条目对应的灯光物体; 无有效条目/类型不符返回 None"""
    obj = active_block(context, "lights")
    return obj if obj is not None and obj.type == 'LIGHT' else None


def _linked_guard(op: Operator, light: Object) -> bool:
    """execute 直调路径的库链接复查(规范 10.2): poll 拦得住 GUI, 直调绕过 poll

    返回 True 表示已报告并应取消.
    """
    if light.library is not None:
        op.report({'WARNING'}, report("Linked lights cannot be edited"))
        return True
    return False


def _resolve_rig_position(context: Context, light: Object, is_shift: bool, is_ctrl: bool, is_alt: bool, op: Operator) -> Vector | None:
    """按修饰键解析控制器摆放位置; 无法确定时报警告并返回 None

    无修饰键 = 活动物体位置(缺活动物体报警告); +Shift = 选中集里除灯光外的
    第一个**非灯光**目标物体(按名字序); +Ctrl = 游标; +Alt = 世界原点.
    """
    if is_alt:
        return Vector((0.0, 0.0, 0.0))
    if is_shift:
        target = next((obj for obj in sorted(context.selected_objects, key=lambda obj: obj.name) if obj is not light and obj.type != 'LIGHT'), None)
        if target is None:
            op.report({'WARNING'}, report("Select a target object to place the controller at"))
            return None
        return target.matrix_world.translation.copy()
    if is_ctrl:
        return context.scene.cursor.location.copy()
    active = context.view_layer.objects.active
    if active is None or active.type == 'LIGHT':
        # 活动物体缺位或就是灯光(落点不会是任何灯, 与 +Shift 的非灯光规则一致,
        # 作者 2026-10-29 定): 无法落点, 报警告
        op.report({'WARNING'}, report("No active object to place the controller at"))
        return None
    return active.matrix_world.translation.copy()


def _resolve_adjust_rig(context: Context) -> tuple[Object, Object] | None:
    """模态算子的 rig 解析: 选区优先(作者激活条件), 面板活跃灯光回退

    灯光方位折叠区按"面板活跃行"显示/编辑属性, 模态若只认选区会出现"属性可编辑
    而唤起按钮置灰"的口径分裂(审查 P2); 回退路径让按钮与属性行同口径.
    """
    rig = resolve_rig(context)
    if rig is not None:
        return rig
    light = _panel_light(context)
    if light is not None:
        controller = rig_controller_of(light)
        if controller is not None:
            return (light, controller)
    return None


class LightAdd(TranslatedDescriptionMixin, Operator):
    """添加灯光: 默认弹原生灯光选择面板, +Shift/+Ctrl/+Alt 直接创建带控制器的面光源"""

    bl_idname = "ch.light_add"
    bl_label = "Add Light"
    bl_description = (
        "Add a light with the native picker (cursor placement and the redo panel are kept)\n"
        "+Shift: Add an area light with a controller empty placed at the active object\n"
        "+Ctrl: Add an area light with a controller empty placed at the 3D cursor\n"
        "+Alt: Add an area light with a controller empty placed at the world origin"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_shift: BoolProperty(name="Shift", default=False, options={'HIDDEN'}, description="Place the controller at the active object (set by +Shift)")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def invoke(self, context: Context, event: Event):
        self.is_shift = bool(event is not None and event.shift)
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        if self.is_shift or self.is_ctrl or self.is_alt:
            return self.execute(context)
        # 无修饰键: 原样转发原生(INVOKE_DEFAULT 保住弹窗与 F9 调整面板, ImageOpen 同款壳)
        return bpy.ops.object.light_add('INVOKE_DEFAULT')

    def execute(self, context: Context):
        if not (self.is_shift or self.is_ctrl or self.is_alt):
            # 直调无修饰键: 与原生直调同口径在游标处建普通灯(不进弹窗);
            # 非物体模式直调时原生 poll 失败会抛 RuntimeError, 先行拦截(审查 P3)
            if context.mode != 'OBJECT':
                return {'CANCELLED'}
            return bpy.ops.object.light_add('EXEC_DEFAULT')
        if self.is_shift:
            active = context.view_layer.objects.active
            if active is None:
                self.report({'WARNING'}, report("No active object to place the controller at"))
                return {'CANCELLED'}
            position = active.matrix_world.translation.copy()
        elif self.is_ctrl:
            position = context.scene.cursor.location.copy()
        else:
            position = Vector((0.0, 0.0, 0.0))
        light, _controller = create_light_rig(context, position)
        # 新建项高亮(与 CreateAlignCamera 同口径): 先同步快照再按名定位
        refresh_lists()
        highlight_item(context, "lights", light.name)
        return {'FINISHED'}


class LightCopy(TranslatedDescriptionMixin, Operator):
    """复制灯光: 把活动灯光连同控制器整套复制, 灯光数据为独立副本"""

    bl_idname = "ch.light_copy"
    bl_label = "Copy Light"
    bl_description = "Duplicate the active light with its controller empty (the light data-block is copied)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        light = _panel_light(context)
        return light is not None and light.library is None and rig_controller_of(light) is not None

    def execute(self, context: Context):
        light = _panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        pair = copy_light_rig(context, light, shared_data=False)
        if pair is None:
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        new_light = pair[0]
        refresh_lists()
        highlight_item(context, "lights", new_light.name)
        self.report({'INFO'}, report("Light rig copied: {}").format(new_light.name))
        return {'FINISHED'}


class LightInstanceCopy(TranslatedDescriptionMixin, Operator):
    """实例复制: 复制活动灯光的 rig 层级但共享灯光数据块(改功率/颜色全联动)"""

    bl_idname = "ch.light_instance_copy"
    bl_label = "Instance Copy"
    bl_description = "Duplicate the active light with its controller empty while sharing the light data-block (power and color edits affect every instance)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        light = _panel_light(context)
        return light is not None and light.library is None and rig_controller_of(light) is not None

    def execute(self, context: Context):
        light = _panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        pair = copy_light_rig(context, light, shared_data=True)
        if pair is None:
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        new_light = pair[0]
        refresh_lists()
        highlight_item(context, "lights", new_light.name)
        self.report({'INFO'}, report("Light instance created: {}").format(new_light.name))
        return {'FINISHED'}


class LightControllerAdd(TranslatedDescriptionMixin, Operator):
    """添加控制器: 给活动灯光绑定控制器空物体, 灯光保位并转身使 -Z 指向控制器"""

    bl_idname = "ch.light_controller_add"
    bl_label = "Add Controller"
    bl_description = (
        "Attach a controller empty to the active light and aim the light at it (the light keeps its position; the controller is placed at the active object by default)\n"
        "+Shift: Place the controller at the first selected non-light object\n"
        "+Ctrl: Place the controller at the 3D cursor\n"
        "+Alt: Place the controller at the world origin"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_shift: BoolProperty(name="Shift", default=False, options={'HIDDEN'}, description="Place the controller at the first selected non-light object (set by +Shift)")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        light = _panel_light(context)
        return light is not None and light.library is None and rig_controller_of(light) is None

    def invoke(self, context: Context, event: Event):
        self.is_shift = bool(event is not None and event.shift)
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        return self.execute(context)

    def execute(self, context: Context):
        light = _panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        if rig_controller_of(light) is not None:
            self.report({'WARNING'}, report("The active light already has a controller"))
            return {'CANCELLED'}
        position = _resolve_rig_position(context, light, self.is_shift, self.is_ctrl, self.is_alt, self)
        if position is None:
            return {'CANCELLED'}
        controller = add_controller(context, light, position)
        # 新控制器入选中集给即时视觉反馈(灯光保持活动与高亮; 排除集合内不可选中则跳过)
        context.view_layer.update()
        if is_selectable(context, controller):
            controller.select_set(True)
        refresh_lists()
        highlight_item(context, "lights", light.name)
        self.report({'INFO'}, report("Controller added: {}").format(controller.name))
        return {'FINISHED'}


class LightControllerRemove(TranslatedDescriptionMixin, Operator):
    """移除控制器: 摘除活动灯光的控制器父级(灯光保世界变换)并删除空物体"""

    bl_idname = "ch.light_controller_remove"
    bl_label = "Remove Controller"
    bl_description = "Remove the controller empty from the active light (the light keeps its world transform)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        light = _panel_light(context)
        return light is not None and light.library is None and rig_controller_of(light) is not None

    def execute(self, context: Context):
        light = _panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        result = remove_controller(light)
        if result == "none":
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        refresh_lists()
        highlight_item(context, "lights", light.name)
        if result == "removed":
            self.report({'INFO'}, report("Controller removed"))
        elif result == "linked":
            self.report({'INFO'}, report("Linked controller kept, only the parent binding was removed"))
        else:
            self.report({'INFO'}, report("Controller has other children, kept as a regular empty"))
        return {'FINISHED'}


class LightControllerReset(TranslatedDescriptionMixin, Operator):
    """重置控制器: 把活动灯光的控制器挪到新位置并重新瞄准(灯光保位, 自旋转归零)"""

    bl_idname = "ch.light_controller_reset"
    bl_label = "Reset Controller"
    bl_description = (
        "Move the controller empty of the active light to a new position and re-aim the light at it (the light keeps its world position; the self rotation resets to 0)\n"
        "+Shift: Place the controller at the first selected non-light object\n"
        "+Ctrl: Place the controller at the 3D cursor\n"
        "+Alt: Place the controller at the world origin"
    )
    bl_options = {'REGISTER', 'UNDO'}

    is_shift: BoolProperty(name="Shift", default=False, options={'HIDDEN'}, description="Place the controller at the first selected non-light object (set by +Shift)")  # type: ignore
    is_ctrl: BoolProperty(name="Ctrl", default=False, options={'HIDDEN'}, description="Place the controller at the 3D cursor (set by +Ctrl)")  # type: ignore
    is_alt: BoolProperty(name="Alt", default=False, options={'HIDDEN'}, description="Place the controller at the world origin (set by +Alt)")  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        light = _panel_light(context)
        if light is None or light.library is not None:
            return False
        controller = rig_controller_of(light)
        # 链接控制器空体不可重置(重定位/改旋转属会话改写库资产, 与四钮口径一致)
        return controller is not None and controller.library is None

    def invoke(self, context: Context, event: Event):
        self.is_shift = bool(event is not None and event.shift)
        self.is_ctrl = bool(event is not None and event.ctrl)
        self.is_alt = bool(event is not None and event.alt)
        return self.execute(context)

    def execute(self, context: Context):
        light = _panel_light(context)
        if light is None:
            return {'CANCELLED'}
        if _linked_guard(self, light):
            return {'CANCELLED'}
        position = _resolve_rig_position(context, light, self.is_shift, self.is_ctrl, self.is_alt, self)
        if position is None:
            return {'CANCELLED'}
        result = reset_controller(context, light, position)
        if result == "none":
            self.report({'WARNING'}, report("The active light has no controller"))
            return {'CANCELLED'}
        if result == "linked":
            self.report({'WARNING'}, report("Linked controller empties cannot be edited"))
            return {'CANCELLED'}
        refresh_lists()
        highlight_item(context, "lights", light.name)
        self.report({'INFO'}, report("Controller reset: {}").format(result))
        return {'FINISHED'}


class LightControllersRemoveAll(TranslatedDescriptionMixin, Operator):
    """移除所有控制器: 把当前灯光列表内全部灯光的控制器批量摘除(灯保位并解锁旋转)"""

    bl_idname = "ch.light_controllers_remove_all"
    bl_label = "Remove All Controllers"
    bl_description = "Remove the controller empty from every light in the current lights list (each light keeps its world position and its rotation is unlocked; linked or shared controller empties are kept, only the parent bindings are removed)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        scene = context.scene
        view_layer = context.view_layer
        # 与四钮同口径: 库链接灯不计入(链接控制器不可解绑)
        return any(light.library is None and rig_controller_of(light) is not None for light in collect_light_blocks(scene, view_layer))

    def execute(self, context: Context):
        lights = collect_light_blocks(context.scene, context.view_layer)
        removed = 0
        unbound = 0
        for light in lights:
            if light.library is not None:
                # 链接灯跳过(会话内解绑库资产重载即复原, 与四钮置灰口径一致)
                continue
            result = remove_controller(light)
            if result == "removed":
                removed += 1
            elif result in {"linked", "shared"}:
                # 链接/共挂的控制器只解绑不删(与单个移除同口径), 计入"仅解绑"
                unbound += 1
        if not removed and not unbound:
            self.report({'INFO'}, report("No lights with controllers"))
            return {'CANCELLED'}
        refresh_lists()
        self.report({'INFO'}, report("Controllers removed: {}, bindings only removed: {}").format(removed, unbound))
        return {'FINISHED'}


class LightRigAdjust(ModalOperatorMixin, TranslatedDescriptionMixin, Operator):
    """灯光控制模态: A/S/D 切档调灯光方位亮度距离, Ctrl/Alt 吸附对齐控制器"""

    bl_idname = "ch.light_rig_adjust"
    bl_label = "Light Control"
    bl_description = (
        "Adjust the light rig interactively\n"
        "+A/S/D: Switch the adjustment mode (A is active on entry) — A: mouse X/Y for azimuth / elevation, S: mouse X for brightness, D: mouse X for distance\n"
        "+Shift: Precise adjustment (half the rate)\n"
        "+Ctrl: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the surface normal (leaves the adjustment mode; press A/S/D to resume)\n"
        "+Alt: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the reflection line of the current view's virtual camera (the scene camera in a camera view; the clicked point becomes the highlight position)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and _resolve_adjust_rig(context) is not None

    def execute(self, context: Context):
        # 模态算子直调守卫(规范 10.2): report WARNING + CANCELLED, 不复入 invoke
        self.report({'WARNING'}, report("This operator runs interactively in the 3D view"))
        return {'CANCELLED'}

    def invoke(self, context: Context, event: Event):
        rig = _resolve_adjust_rig(context)
        if rig is None:
            return {'CANCELLED'}
        self.rig_light: Object = rig[0]
        self.rig_controller: Object = rig[1]
        if context.region_data is None:
            # 后台无视图: 交互不成立, 走直调守卫口径
            return self.execute(context)
        # --- 模态状态 ---
        # 取消还原快照: 控制器/灯光的 basis 与功率(父级逆不受模态影响, basis 还原即世界还原)
        self.init_controller_mx: Matrix = self.rig_controller.matrix_basis.copy()
        self.init_light_mx: Matrix = self.rig_light.matrix_basis.copy()
        self.init_energy: float = self.rig_light.data.energy
        # 调节模式(A/S/D 互斥切换制, 作者 2026-10-29 定): 按下即换档, 进入默认 A 档
        self.axis: str = 'A'
        self.pass_through = False
        self.init_mouse_position(event)
        self.init_status(context, func=_draw_rig_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context)
        force_ui_update(context)
        # 模态调值只写变换, 不改任何列表成员: 挂起 handlers 的全量列表同步(否则每次
        # 调值的 depsgraph 更新都会触发 0.1s 一次的六列表全量重建, 是模态卡顿主因);
        # 置位放在 RUNNING_MODAL 前一行, 消掉 invoke 尾部异常的泄漏窗口(审查 P1)
        set_sync_suppressed(True)
        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        try:
            return self._modal_dispatch(context, event)
        except Exception:
            # 模态期异常(如灯/控制器被外部删除): Blender 直接摘除模态算子且不再走
            # _finish——必须在此复位同步抑制与状态栏, 否则全量同步静默停摆(审查 P1);
            # 收敛动作逐一兜住, 收敛自身失败不掩盖原异常
            set_sync_suppressed(False)
            try:
                self.finish_status()
                self.finish_modal_handlers()
                force_statusbar_redraw(context)
            except Exception:
                pass
            return {'CANCELLED'}

    def _modal_dispatch(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 先数据级还原(不依赖 area, 与 ESC 取消同语义——否则已做
            # 的调整漏进下一次无关操作的 undo 步), 再最小收敛退出
            self._restore()
            set_sync_suppressed(False)
            self._abort_without_area(context)
            force_statusbar_redraw(context)
            return {'CANCELLED'}
        if ignore_events(event):
            return {'RUNNING_MODAL'}
        context.area.tag_redraw()
        return self._handle_modal_events(context, event)

    def _handle_modal_events(self, context: Context, event: Event):
        if event.type == 'MOUSEMOVE':
            return self._handle_mouse_move(context, event)
        if navigation_passthrough(event, alt=True):
            # 视图导航(MMB 旋转等): 事件交给导航系统, 下一帧 MOUSEMOVE 重置基线
            self.pass_through = True
            return {'PASS_THROUGH'}
        if event.value == 'PRESS':
            return self._handle_key_press(context, event)
        return {'RUNNING_MODAL'}

    def _handle_mouse_move(self, context: Context, event: Event):
        if self.pass_through:
            # 视图导航结束: 重置基线, 本帧不做任何调整
            self.pass_through = False
            self.init_mouse_position(event)
            return {'RUNNING_MODAL'}
        if event.ctrl or event.alt:
            # 吸附档: 进入即退出调节模式(置 None)——松开 Ctrl/Alt 后鼠标移动不再调值,
            # 须重新按 A/S/D 才恢复(作者 2026-10-29 定)
            self.axis = None
            self._handle_controller_move(context, event)
        elif self.axis is not None:
            # 调值态光标到区域边缘跳到对侧(作者要求): 包裹帧跳过调值, 基线已在包裹内重置
            if self.wrap_mouse_position(context, event):
                return {'RUNNING_MODAL'}
            self._handle_light_axis(context, event)
        self.init_mouse_position(event)
        self.update_header_text(context)
        return {'RUNNING_MODAL'}

    def _reflection_view_point(self, context: Context) -> Vector:
        """反射模式的观察点: 相机视图用场景相机, 其余用 3D 视图的虚拟相机视点

        (作者 2026-10-29 修正口径——反射线 = 虚拟相机指向表面点的矢量经表面反射;
        逐帧现算, 模态中导航后仍跟随当前视角).
        """
        rv3d = context.region_data
        if rv3d.view_perspective == 'CAMERA' and context.scene.camera is not None:
            return context.scene.camera.matrix_world.translation
        return rv3d.view_matrix.inverted().translation.copy()

    def _handle_controller_move(self, context: Context, event: Event) -> None:
        """控制器调整: 射线吸附表面; +Ctrl 法线对齐 / +Alt 反射对齐(同按 Alt 优先)

        对齐轴为控制器局部 +Y(rig 几何约定灯在局部 +Y 轴上, 作者 2026-10-29 修正).
        """
        result = raycast_surface(context, (event.mouse_region_x, event.mouse_region_y))
        if result is None:
            return
        hit, normal = result
        _loc, rot, scale = self.rig_controller.matrix_basis.decompose()
        self.rig_controller.matrix_basis = Matrix.Translation(hit) @ rot.to_matrix().to_4x4() @ Matrix.Diagonal(scale.to_4d())
        if event.alt:
            align_controller_y(self.rig_controller, reflection_direction(self._reflection_view_point(context), hit, normal))
        elif event.ctrl:
            align_controller_y(self.rig_controller, normal)

    def _reflection_view_point(self, context: Context) -> Vector:
        """反射模式的观察点: 相机视图用场景相机, 其余用 3D 视图的虚拟相机视点

        (作者 2026-10-29 修正口径——反射线 = 虚拟相机指向表面点的矢量经表面反射;
        逐帧现算, 模态中导航后仍跟随当前视角).
        """
        rv3d = context.region_data
        if rv3d.view_perspective == 'CAMERA' and context.scene.camera is not None:
            return context.scene.camera.matrix_world.translation
        return rv3d.view_matrix.inverted().translation.copy()

    def _handle_light_axis(self, context: Context, event: Event) -> None:
        """按当前模式把鼠标增量写进 rig(区域归一幅度与 Shift 精确比率读偏好设置)"""
        prefs = get_prefs()
        delta_x = event.mouse_x - self.last_mouse_x
        delta_y = event.mouse_y - self.last_mouse_y
        factor = prefs.light_rig_shift_factor if event.shift else 1.0
        step_x = delta_x * factor / max(context.region.width, 1)
        step_y = delta_y * factor / max(context.region.height, 1)
        light = self.rig_light
        controller = self.rig_controller
        if self.axis == 'A':
            set_controller_azimuth(controller, get_controller_azimuth(controller) + step_x * prefs.light_rig_angle_sweep)
            set_controller_elevation(controller, get_controller_elevation(controller) + step_y * prefs.light_rig_angle_sweep)
        elif self.axis == 'D':
            set_light_distance(light, get_light_distance(light) + step_x * prefs.light_rig_distance_span)
        else:
            # 功率按绝对幅度增减(归一化), 0 起步自然可用; 链接灯的数据块不改写
            # (与四钮"库链接灯光不可编辑"口径一致, 变换类调节不受影响)
            if light.library is None:
                light.data.energy = max(0.0, light.data.energy + step_x * prefs.light_rig_power_span)

    def _handle_key_press(self, context: Context, event: Event):
        if event.type in _AXIS_KEYS:
            # 切换制(作者 2026-10-29 定): 按下即换档, A/S/D 互斥, 无"按住"语义
            self.axis = event.type
            return {'RUNNING_MODAL'}
        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'}:
            self._finish(context)
            return {'FINISHED'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._restore()
            self._finish(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def update_header_text(self, context: Context) -> None:
        """header 只显数值(规范 5.3): 四属性实时值"""
        text = iface("Azimuth: {}  Elevation: {}  Distance: {}  Brightness: {}").format(
            "{:.1f}".format(degrees(get_controller_azimuth(self.rig_controller))),
            "{:.1f}".format(degrees(get_controller_elevation(self.rig_controller))),
            "{:.2f}".format(get_light_distance(self.rig_light)),
            "{:.1f}".format(self.rig_light.data.energy),
        )
        context.area.header_text_set(text)

    def _restore(self) -> None:
        """取消路径: 控制器变换 / 灯光局部变换 / 功率整体还原到 invoke 快照"""
        self.rig_controller.matrix_basis = self.init_controller_mx
        self.rig_light.matrix_basis = self.init_light_mx
        self.rig_light.data.energy = self.init_energy

    def _finish(self, context: Context) -> None:
        """收尾(生命周期调用序): 状态栏 -> 模态处理器 -> header 清除 -> UI 刷新"""
        set_sync_suppressed(False)
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        # 状态栏区域显式重绘: 恢复 statusbar.draw 后不 tag 会残留旧自绘内容
        force_statusbar_redraw(context)
        force_ui_update(context)
