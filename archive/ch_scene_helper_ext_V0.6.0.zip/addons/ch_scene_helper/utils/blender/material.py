"""
场景资源面板材质动作与着色器算法模块

提供以下功能:
- MATERIAL_SLOT_TYPES: 可拥有材质槽的物体类型集合
- assign_material: 把材质赋给一组物体的材质槽(追加新槽 / 替换活动槽 / 单物体替换指定槽)
- duplicate_material / delete_material / unlink_material: 材质数据块动作
- material_users: 材质的场景使用者查询
- find_material_slot: 在物体材质槽中查找指定材质的位置
- find_instance_group / unsync_instance_group: 实例组查找与独立化
- get_material_output / get_surface_bsdf: 材质输出与表面着色节点
- resolve_bsdf_slots: 按固定语义序解析节点可显示的插槽(可编辑/占位两态)
- trace_upstream: 从插槽沿已接线输入向上追溯, 找指定类型的节点(穿越透传节点)
- detect_pbr_texture_graph / get_pbr_texcoord_pair: PBR 五步检测与坐标节点对定位
- get_texcoord_output / set_texcoord_output: 读取/重建 TexCoord -> Mapping 接线

注: 本模块自持一份材质赋值实现(与 ch_utils_tools 的材质拾取器已分叉);
材质参数子面板算法只服务本插件, 不下沉 common.
"""

import bpy
from contextlib import contextmanager
from bpy.types import Context, ID, Material, Node, NodeSocket, Object, Scene

from .selection import is_selectable
from .._constants import (
    BSDF_NODE_TYPES,
    BSDF_SLOT_ALIASES,
    EMISSION_NODE_SEMANTICS,
    HAIR_NODE_TYPES,
    PBR_CHANNELS,
    PBR_CHANNEL_BSDF_COUNT,
    TEXCOORD_SOCKET_NAMES,
    TREE_TRACE_MAX_DEPTH,
    VOLUME_NODE_TYPES,
)

# 自发光相关语义键(体积节点排除用: 通用 emission_color/emission_strength + EMISSION 专属两行)
EMISSION_SEMANTICS = EMISSION_NODE_SEMANTICS | {"emission_color", "emission_strength"}

# 可拥有材质槽的物体类型(网格/曲线/文本/曲面/融球)
MATERIAL_SLOT_TYPES = {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}

# PBR 通道中挂在 BSDF 上的前几项(其余挂在 Material Output 上)
_BSDF_CHANNELS = frozenset(PBR_CHANNELS[:PBR_CHANNEL_BSDF_COUNT])

# 透传节点类型: 追溯上游时不算命中边界, 继续向其输入端走
_PASS_THROUGH_TYPES = {'REROUTE', 'GROUP', 'GROUP_INPUT'}


# ------------------------------------------------------------
# 材质槽动作
# ------------------------------------------------------------


def _has_material(mat: Material, obj: Object) -> bool:
    """物体材质槽中是否已有该材质(按数据块身份比较)"""
    return any(slot.material == mat for slot in obj.material_slots)


def _ensure_unique_data(obj: Object) -> None:
    """新增材质槽前把共享数据块独立化

    槽数量是数据块级属性: 直接 `obj.data.materials.append` 会给所有共享该 mesh 的实例
    一起加槽. 需要只影响当前物体时先复制数据块(与 Blender 的 Make Single User 同语义).
    """
    data = getattr(obj, "data", None)
    if data is not None and data.users > 1:
        obj.data = data.copy()


def _assign_slot_material(mat: Material, obj: Object, slot_idx: int) -> None:
    """写入已有槽位; 共享数据块时把该槽改为物体级链接, 避免改动其它实例

    槽的 link 为 DATA 时材质存放在 mesh 上, 写入会连带所有使用者; 改为 OBJECT 后
    材质由物体自己持有, mesh 上的原材质与兄弟实例保持不变.
    """
    slot = obj.material_slots[slot_idx]
    if slot.link == 'DATA' and obj.data is not None and obj.data.users > 1:
        slot.link = 'OBJECT'
    slot.material = mat


def _assign_to_slot(mat: Material, obj: Object, slot_idx: int) -> None:
    """把材质写到指定槽位; 编号越界时替换末尾槽"""
    slots = obj.material_slots
    idx = min(slot_idx, len(slots) - 1)
    _assign_slot_material(mat, obj, idx)
    obj.active_material_index = idx


def assign_material(mat: Material, objects: list, append: bool = False, slot_index: int | None = None) -> tuple:
    """把材质赋给一组物体的材质槽, 返回 (赋值物体数, 错误信息)

    三种语义(交互层按修饰键选择):
    - 默认: 写到各物体的活动材质槽, 无槽时追加新槽
    - append=True: 追加到槽列表末尾; 物体已持有该材质时只把活动槽切到它
    - slot_index 非 None: 只对首个物体生效, 替换其第 slot_index 个槽(0 起), 越界改替换末尾槽

    仅处理可拥有材质槽的物体类型(见 MATERIAL_SLOT_TYPES), 其它类型静默跳过.

    隔离语义: 实例（Alt+D / 关联复制）共享同一数据块时不改动兄弟实例 —— 替换已有槽
    改走物体级链接, 新增槽前先复制数据块.
    """
    if mat is None:
        return 0, "material is None"
    targets = objects[:1] if slot_index is not None else objects
    count = 0
    for obj in targets:
        if obj.type not in MATERIAL_SLOT_TYPES:
            continue
        if append:
            if _has_material(mat, obj):
                obj.active_material_index = find_material_slot(obj, mat)
            else:
                _ensure_unique_data(obj)
                obj.data.materials.append(mat)
                obj.active_material_index = len(obj.material_slots) - 1
        elif slot_index is not None:
            if not obj.material_slots:
                _ensure_unique_data(obj)
                obj.data.materials.append(mat)
            else:
                _assign_to_slot(mat, obj, slot_index)
        elif not obj.material_slots:
            _ensure_unique_data(obj)
            obj.data.materials.append(mat)
        else:
            _assign_slot_material(mat, obj, obj.active_material_index)
        count += 1
    return count, None


def find_material_slot(obj: Object | None, mat: Material) -> int:
    """在物体材质槽中查找该材质的位置, 找不到返回 -1"""
    if obj is None or mat is None:
        return -1
    for slot_idx, slot in enumerate(obj.material_slots):
        if slot.material == mat:
            return slot_idx
    return -1


def duplicate_material(mat: Material) -> Material | None:
    """复制材质数据块(含节点树), 继承假用户设置; 入参无效返回 None"""
    if mat is None:
        return None
    new_mat = mat.copy()
    new_mat.use_fake_user = mat.use_fake_user
    return new_mat


def delete_material(mat: Material) -> tuple:
    """删除材质数据块(在用材质由 Blender 自动清空其材质槽), 返回 (是否成功, 错误信息)"""
    if mat is None:
        return False, "material is None"
    bpy.data.materials.remove(mat)
    return True, None


def unlink_material(scene: Scene, mat: Material) -> tuple:
    """解除材质与场景物体材质槽的全部关联(不删除数据块), 返回 (清空的槽数, 错误信息)"""
    if mat is None:
        return 0, "material is None"
    count = 0
    for obj in scene.objects:
        for slot in obj.material_slots:
            if slot.material == mat:
                slot.material = None
                count += 1
    return count, None


def material_users(scene: Scene, mat: Material) -> list:
    """场景中把该材质放进了材质槽的全部物体(按场景物体顺序, 天然去重)"""
    if mat is None:
        return []
    return [obj for obj in scene.objects if any(slot.material == mat for slot in obj.material_slots)]


def _has_user_outside(data: ID, sel_objs: list) -> bool:
    """数据块是否还有选中集合之外的使用者物体

    直接扫 bpy.data.objects, 按数据块身份与物体名称判断(名称在物体命名空间内唯一).
    """
    selected_names = {obj.name for obj in sel_objs if obj is not None}
    for obj in bpy.data.objects:
        if obj.data is data and obj.name not in selected_names:
            return True
    return False


def find_instance_group(sel_objs: list) -> dict:
    """找出选中物体里的实例残留, 按数据块分组: {数据块名: [选中物体...]}

    判据只看数据块共享用户数:
    - 共享用户数为 1 不算实例
    - 全部用户都在选中集合里不算实例(独立化没有意义)
    - 数据块还有未选中的用户时才算实例; 同数据块的多个选中物体归成一组
    """
    selected = list(sel_objs)
    groups = {}
    for obj in selected:
        data = obj.data
        if data is None or data.users < 2:
            continue
        if not _has_user_outside(data, selected):
            continue
        groups.setdefault(data.name, []).append(obj)
    return groups


def unsync_instance_group(group_objs: list) -> dict:
    """把一组实例物体独立化: 共用一份新数据块, 同数据块的其余物体保持原样

    Returns:
        {"ok": 是否成功, "data": 新数据块名或 None, "count": 独立化的物体数, "error": 错误信息}
    """
    result = {"ok": False, "data": None, "count": 0, "error": None}
    if not group_objs:
        result["error"] = "no objects"
        return result
    old_data = group_objs[0].data
    if old_data is None:
        result["error"] = "object has no data"
        return result
    try:
        new_data = old_data.copy()
    except (RuntimeError, AttributeError) as e:
        result["error"] = str(e)
        return result
    for obj in group_objs:
        obj.data = new_data
    result["ok"] = True
    result["data"] = new_data.name
    result["count"] = len(group_objs)
    return result


# ------------------------------------------------------------
# 节点树: 输出/表面/追溯
# ------------------------------------------------------------


def get_material_output(tree):
    """取材质节点树的材质输出节点; 无返回 None

    多个输出节点时取第一个 is_active_output 为真的, 否则取第一个.
    """
    if tree is None:
        return None
    outputs = [node for node in tree.nodes if node.type == 'OUTPUT_MATERIAL']
    if not outputs:
        return None
    return next((node for node in outputs if getattr(node, "is_active_output", False)), outputs[0])


def _surface_socket(mat: Material):
    """材质的 Material Output.Surface 插槽; 无输出/未接线返回 None"""
    output = get_material_output(mat.node_tree if mat is not None else None)
    if output is None:
        return None
    surface = output.inputs.get("Surface")
    return surface if surface is not None and surface.is_linked else None


def get_surface_bsdf(mat: Material):
    """取材质输出 Surface 直连的 BSDF 型节点(基础参数区的作用对象); 不满足返回 None"""
    surface = _surface_socket(mat)
    if surface is None:
        return None
    node = surface.links[0].from_node
    return node if node.type in BSDF_NODE_TYPES else None


def _principled_bsdf(mat: Material):
    """取 PBR 检测所需的 (Material Output, Surface 直连的 Principled BSDF); 不满足返回 (None, None)"""
    output = get_material_output(mat.node_tree if mat is not None else None)
    if output is None:
        return None, None
    surface = output.inputs.get("Surface")
    if surface is None or not surface.is_linked:
        return None, None
    node = surface.links[0].from_node
    return (output, node) if node.type == 'BSDF_PRINCIPLED' else (None, None)


def _channel_socket(bsdf: Node, output: Node, channel: str):
    """按 PBR 通道名取插槽(前四项在 BSDF 上, 末项在 Material Output 上)"""
    return bsdf.inputs.get(channel) if channel in _BSDF_CHANNELS else output.inputs.get(channel)


def _is_pass_through(node: Node) -> bool:
    """是否追溯透传节点(Reroute/节点组)"""
    return node.type in _PASS_THROUGH_TYPES


def _walk_upstream(socket: NodeSocket, wanted_types: frozenset, depth_max: int, found: list, visited: set) -> None:
    """从插槽向上 DFS, 把命中 wanted_types 的节点按就近顺序收进 found(去重)"""
    if depth_max <= 0 or not socket.is_linked:
        return
    for link in socket.links:
        node = link.from_node
        if node in visited:
            continue
        visited.add(node)
        if node.type in wanted_types:
            found.append(node)
        if _is_pass_through(node) or node.type not in wanted_types:
            for upstream in node.inputs:
                _walk_upstream(upstream, wanted_types, depth_max - 1, found, visited)


def trace_upstream(socket: NodeSocket, wanted_types: set, depth_max: int = TREE_TRACE_MAX_DEPTH) -> list:
    """从插槽沿已接线输入向上追溯, 返回命中的节点列表(就近优先, 去重)

    穿越 REROUTE / GROUP / GROUP_INPUT 透传节点与未命中节点继续向上; 命中即停
    (不继续走命中节点自己的上游, 检测语义只需要最近的命中层).
    """
    found: list = []
    if socket is None:
        return found
    _walk_upstream(socket, frozenset(wanted_types), depth_max, found, set())
    return found


# ------------------------------------------------------------
# BSDF 插槽语义表
# ------------------------------------------------------------


def _socket_for_semantic(node: Node, semantic: str):
    """按语义键取节点上第一个命中的候选插槽; 不适用返回 None

    - 候选名逐个试取 node.inputs.get(name)(禁止按下标取值: 大版本会插入新插槽)
    - "ior" 只接受 VALUE 型插槽且毛发节点除外
    - EMISSION 只显示自己的 Color/Strength; 体积节点不显示自发光相关行
    """
    if semantic in EMISSION_NODE_SEMANTICS:
        if node.type != 'EMISSION':
            return None
    elif node.type == 'EMISSION':
        return None
    elif node.type in VOLUME_NODE_TYPES and semantic in EMISSION_SEMANTICS:
        return None
    for name in BSDF_SLOT_ALIASES.get(semantic, ()):
        socket = node.inputs.get(name)
        if socket is None or getattr(socket, "is_unavailable", False):
            continue
        if semantic == "ior":
            if socket.type != 'VALUE':
                continue
            if node.type in HAIR_NODE_TYPES:
                continue
        return socket
    return None


def resolve_bsdf_slots(node: Node) -> list:
    """按固定语义序解析节点可显示的插槽行(基础参数区的数据源)

    Returns:
        [(semantic, socket, is_linked), ...] 按语义序排列; 取不到的语义行跳过
    """
    rows = []
    for semantic in BSDF_SLOT_ALIASES:
        socket = _socket_for_semantic(node, semantic)
        if socket is not None:
            rows.append((semantic, socket, socket.is_linked))
    return rows


# ------------------------------------------------------------
# PBR 检测与坐标下拉
# ------------------------------------------------------------


def detect_pbr_texture_graph(mat: Material) -> dict:
    """PBR 五步检测(全过才显示材质面板贴图区), 返回判定结果与通道映射

    五步:
    ① Surface 直连节点是 Principled BSDF
    ② 五通道中, 上游能追到图像纹理的通道数 >= 2
    ③ 每张命中的图像纹理, 其 Vector 上游能追到 Mapping 节点(取最近的)
    ④ 该 Mapping 的 Vector 上游能追到 Texture Coordinate 节点
    ⑤ 全部满足

    Returns:
        {"ok": 五步是否全过, "tex_by_channel": {通道名: 图像纹理节点}, "first_hit": 第一个命中的通道名或 None}
    """
    result = {"ok": False, "tex_by_channel": {}, "first_hit": None}
    output, bsdf = _principled_bsdf(mat)
    if bsdf is None:
        return result
    tex_by_channel: dict = {}
    for channel in PBR_CHANNELS:
        socket = _channel_socket(bsdf, output, channel)
        if socket is None or not socket.is_linked:
            continue
        tex_nodes = trace_upstream(socket, {'TEX_IMAGE'})
        if not tex_nodes:
            continue
        # 该通道的全部纹理都必须能追到 Mapping -> TexCoord, 否则整个通道不算命中
        if not all(_texture_has_texcoord(tex) for tex in tex_nodes):
            continue
        tex_by_channel[channel] = tex_nodes[0]
    if len(tex_by_channel) < 2:
        return result
    result["tex_by_channel"] = tex_by_channel
    result["first_hit"] = next((channel for channel in PBR_CHANNELS if channel in tex_by_channel), None)
    result["ok"] = True
    return result


def _texture_has_texcoord(tex: Node) -> bool:
    """图像纹理的 Vector 是否经最近的 Mapping 追到 Texture Coordinate"""
    mappings = trace_upstream(tex.inputs.get("Vector"), {'MAPPING'})
    if not mappings:
        return False
    return bool(trace_upstream(mappings[0].inputs.get("Vector"), {'TEX_COORD'}))


def get_pbr_texcoord_pair(mat: Material):
    """取坐标下拉要读写的 (TexCoord, Mapping) 节点对; 不满足返回 None

    "第一个命中": 按 PBR_CHANNELS 固定顺序遍历, 取第一个其图像纹理上游能追到 TexCoord 的通道.
    """
    output, bsdf = _principled_bsdf(mat)
    if bsdf is None:
        return None
    for channel in PBR_CHANNELS:
        socket = _channel_socket(bsdf, output, channel)
        for tex in trace_upstream(socket, {'TEX_IMAGE'}):
            mappings = trace_upstream(tex.inputs.get("Vector"), {'MAPPING'})
            if not mappings:
                continue
            mapping = mappings[0]
            coords = trace_upstream(mapping.inputs.get("Vector"), {'TEX_COORD'})
            if coords:
                return coords[0], mapping
    return None


def get_texcoord_output(tex_coord, mapping) -> str:
    """读当前坐标输出真值: TexCoord 的哪个输出口接到了 Mapping.Vector, 返回枚举标识

    口名 -> 标识经 TEXCOORD_SOCKET_NAMES 反查(口名 "Object" 对应标识 "OBJECT").
    """
    vector = mapping.inputs.get("Vector")
    if vector is None or not vector.is_linked:
        return ""
    name_to_id = {value: key for key, value in TEXCOORD_SOCKET_NAMES.items()}
    for link in vector.links:
        # 按 name(+type) 比较而非 is: 不同获取路径的 bpy_struct 包装器身份不同
        if link.from_node.name == tex_coord.name and link.from_node.type == 'TEX_COORD':
            return name_to_id.get(link.from_socket.name, "")
    return ""


def set_texcoord_output(tex_coord, mapping, output_id: str) -> None:
    """重建 TexCoord -> Mapping.Vector 的接线(坐标下拉改动的落点)

    断掉 Mapping.Vector 上来自该 TexCoord 的旧线(按 name 比较), 接到 output_id 指定的输出口;
    写节点树连接不进 Undo 栈(作者已接受), 由调用方在 tooltip 说明.
    """
    tree = mapping.id_data
    socket_name = TEXCOORD_SOCKET_NAMES.get(output_id)
    target = tex_coord.outputs.get(socket_name) if socket_name else None
    vector = mapping.inputs.get("Vector")
    if tree is None or target is None or vector is None:
        return
    for link in list(vector.links):
        if link.from_node.name == tex_coord.name and link.from_node.type == 'TEX_COORD':
            tree.links.remove(link)
    tree.links.new(target, vector)
    tree.update_tag()


# 坐标下拉镜像写回的抑制计数: 面板 draw 期把"连接真值"写进镜像枚举时,
# props.on_pbr_texcoord_update 查此计数跳过接线重建 —— 否则每帧重画都会触发一次接线重建.
# 用深度计数而非布尔值防嵌套.
_suppress_depth = 0


@contextmanager
def suppress_texcoord_updates():
    """进入镜像写回抑制(面板 draw 期把真值写回枚举时使用), 退出时恢复"""
    global _suppress_depth
    _suppress_depth += 1
    try:
        yield
    finally:
        _suppress_depth -= 1


def is_texcoord_update_suppressed() -> bool:
    """镜像枚举的 update 回调当前是否应跳过(面板 draw 期)"""
    return _suppress_depth > 0


def focus_material(context: Context, mat: Material) -> bool:
    """把该材质的使用者物体设为活动物体并切到对应槽位, 返回是否成功

    着色器编辑器跟随活动物体的活动材质, 故切编辑器只需这两步;
    材质没有场景使用者时不做任何事. 聚焦目标取视图层内的首个使用者:
    使用者全在排除集合里时设活动物体会抛 RuntimeError(见 selection.is_selectable),
    此时同样不做任何事.
    """
    users = material_users(context.scene, mat)
    first_obj = next((obj for obj in users if is_selectable(context, obj)), None)
    if first_obj is None:
        return False
    context.view_layer.objects.active = first_obj
    for idx, slot in enumerate(first_obj.material_slots):
        if slot.material == mat:
            first_obj.active_material_index = idx
            break
    return True
