"""
灯光高级设置算法模块

以模板节点组 + 每灯实例的方式管理灯光节点树上的高级效果链(渐变/图像/IES):
三组渐变模板(径向/线性/柔光箱)按作者 Light_Nodes.blend 的组结构代码重建, 参数为组接口
socket 值(每灯实例可独立覆写); 每灯的组实例/ColorRamp 节点常驻不删, 切换模式
(含切回"无"档)只改 Emission 的接入接线, 保证调好的参数与色标不因切换丢失.

主要功能:
- apply_light_advanced_wiring: 按灯光上的高级设置状态重接 Emission("无"档 = 只断线;
  幂等, 可修复用户误删的链节点; 用户手动接线不删除, 被插件线顶置后由面板提示)
- find_advanced_node: 按标记取灯树里的插件节点(组实例/色标 Ramp/图像与 IES 链节点)
- emission_occupied: Emission 的强度/颜色是否被非插件来源接线(面板提示依据, 不阻断接管)
- collect_orphan_nodes: 从 Light Output 反向不可达的孤立节点(清理算子数据源)
"""

import math

import bpy
from bpy.types import Node, NodeTree

# 插件节点的归属标记(node 级 IDProperty, 用户改名节点后仍可识别)
_MARKER_KEY = "ch_advanced"

# 渐变模式标识 -> 模板组标记后缀(模板组与实例节点共用同一类型串)
GRADIENT_RADIAL = 'RADIAL'
GRADIENT_LINEAR = 'LINEAR'
GRADIENT_SOFTBOX = 'SOFTBOX'

# 节点标记值: 渐变三档用前缀 + 类型串, 图像/IES 链用固定串
_RAMP_KIND = "RAMP:"
_TEMPLATE_KIND = "TEMPLATE:"
_GROUP_KIND = "GROUP:"
_FRAME_KIND = "FRAME:"
MARK_IMAGE_ARRAY = "TEXTURE_ARRAY"
MARK_IMAGE_TEX = "IMAGE_TEX"
MARK_IMAGE_HSV = "IMAGE_HSV"
MARK_IES_TEX = "IES_TEX"
MARK_IES_GAMMA = "IES_GAMMA"

# 走"组实例"前缀的标记键(渐变三档 + 图像档的阵列坐标组)
_GROUP_KEYS = (GRADIENT_RADIAL, GRADIENT_LINEAR, GRADIENT_SOFTBOX, MARK_IMAGE_ARRAY)

# 面光/聚光的参数面中心(Parametric 归一化坐标的几何中心), 照抄作者组的调校值(Z=0)
_PARAM_CENTER = (0.5, 0.5, 0.0)

# 线性渐变与柔光箱条纹的半周期系数(照抄作者组: X*阵列 后乘 π 再进三角函数)
_HALF_PERIOD = math.pi

# 链 Frame 的标签与纵向位置(作者定: X 统一 10, 自上而下 616/316/16/-284/-624, 前四档间距 300)
_FRAME_X = 10.0
_CHAIN_FRAMES = {
    GRADIENT_LINEAR: ("Linear Gradient", 616.0),
    GRADIENT_SOFTBOX: ("Softbox", 316.0),
    GRADIENT_RADIAL: ("Radial Gradient", 16.0),
    "IMAGE": ("Texture Control", -284.0),
    "IES": ("IES Control", -624.0),
}

# Emission 与灯光输出的横坐标(作者定); 纵坐标跟随本档 Chain Frame, 见 _align_output_nodes
_EMISSION_X = 840.0
_OUTPUT_X = 1020.0

# 链首节点相对 Frame 的偏移 = Frame 自动收缩(有标签)时保留的左上内边距(作者实测: 有标签
# (30, -36), 无标签 (30, -30)). 首节点按此值钉位后, 每次收缩重算都是不动点; 小于内边距时
# 每重算一次 Frame 就往差值方向挪一格(实测 29 时每点一次左移 1, 表现为"切换模式节点微移")
_CHAIN_ORIGIN = (30.0, -36.0)
# 链内后续节点的相对横坐标(照旧间距: 首节点 +180 / +460)
_CHAIN_MID = 210.0
_CHAIN_LAST = 490.0


def _marked(nodes, marker: str):
    """按归属标记取节点(取不到返回 None)"""
    for node in nodes:
        if node.get(_MARKER_KEY) == marker:
            return node
    return None


def find_advanced_node(light, node_key: str):
    """取灯树中带指定标记的插件节点(渐变传组类型串, 图像/IES 传 MARK_* 常量; 无则 None)"""
    if light is None or light.node_tree is None:
        return None
    marker = _GROUP_KIND + node_key if node_key in _GROUP_KEYS else node_key
    return _marked(light.node_tree.nodes, marker)


def find_advanced_ramp(light, gradient_type: str):
    """取灯树中指定渐变模式的 ColorRamp 节点(无则 None)"""
    if light is None or light.node_tree is None:
        return None
    return _marked(light.node_tree.nodes, _RAMP_KIND + gradient_type)


def emission_occupied(light) -> bool:
    """Emission 的强度/颜色插座是否被非插件来源的节点占用

    占用说明用户手搭过接线, 高级设置照常接管(面板据此画提示行, 触碰任一控件即恢复插件线).
    Emission 节点缺失同样按占用处理(面板画提示行, 不画可调控件).
    """
    emission = _find_emission(light)
    if emission is None:
        return True
    for socket_name in ("Strength", "Color"):
        for link in emission.inputs[socket_name].links:
            if link.from_node.get(_MARKER_KEY) is None:
                return True
    return False


def light_advanced_has_wiring(light) -> bool:
    """Emission 上是否还挂着插件接线(与链是否完整无关, 灯型闸断线检查用)"""
    emission = _find_emission(light)
    if emission is None:
        return False
    for socket_name in ("Strength", "Color"):
        for link in emission.inputs[socket_name].links:
            if link.from_node.get(_MARKER_KEY) is not None:
                return True
    return False


def light_advanced_chain_broken(light) -> bool:
    """活跃且灯型相符的灯, 插件链是否断线(灯型切换/树重建会把节点树换掉, 见 depsgraph 自愈)

    两类不算断线: "无"档(本来就该断)、占用态(用户接线在位, 不许碰); 灯型不符也不在本函数
    报断——那种状态由 light_advanced_has_wiring 表达(闸要断的是残留线).
    """
    if light is None or light.library is not None or light.node_tree is None:
        return False
    settings = getattr(light, "ch_advanced", None)
    if settings is None or settings.mode == 'NONE':
        return False
    mode = settings.mode
    if mode in {'GRADIENT', 'IMAGE'} and light.type not in {'AREA', 'SPOT'}:
        return False
    if mode == 'IES' and light.type != 'POINT':
        return False
    emission = _find_emission(light)
    if emission is None or emission_occupied(light):
        return False
    strength_srcs = [link.from_node.get(_MARKER_KEY) for link in emission.inputs["Strength"].links]
    color_srcs = [link.from_node.get(_MARKER_KEY) for link in emission.inputs["Color"].links]
    if mode == 'GRADIENT':
        return _GROUP_KIND + settings.gradient_type not in strength_srcs or _RAMP_KIND + settings.gradient_type not in color_srcs
    if mode == 'IMAGE':
        target_socket = "Strength" if settings.image_target == 'STRENGTH' else "Color"
        target_srcs = [link.from_node.get(_MARKER_KEY) for link in emission.inputs[target_socket].links]
        return MARK_IMAGE_HSV not in target_srcs
    return MARK_IES_GAMMA not in strength_srcs


def collect_orphan_nodes(light) -> list:
    """灯光节点树里的孤立节点(从 Light Output 反向不可达), 供清理算子删除

    Frame 恒保留(节点组织容器, 不是效果节点); 无树/库链接灯返回空表.
    """
    if light is None or light.library is not None or light.node_tree is None:
        return []
    tree = light.node_tree
    reachable = set()
    stack = [node for node in tree.nodes if node.type == 'OUTPUT_LIGHT']
    while stack:
        node = stack.pop()
        if node in reachable:
            continue
        reachable.add(node)
        for socket in node.inputs:
            for link in socket.links:
                stack.append(link.from_node)
    return [node for node in tree.nodes if node not in reachable and node.type != 'FRAME']


def _find_emission(light):
    """定位灯光树里接向灯光输出的自发光节点(经 Light Output 上游回溯, 兜底取首个 Emission)"""
    if light is None or light.node_tree is None:
        return None
    tree = light.node_tree
    for node in tree.nodes:
        if node.type != 'OUTPUT_LIGHT':
            continue
        for link in node.inputs["Surface"].links:
            if link.from_node.type == 'EMISSION':
                return link.from_node
    for node in tree.nodes:
        if node.type == 'EMISSION':
            return node
    return None


# ------------------------------------------------------------
# 模板节点组(代码重建, 结构与参数范围照抄作者组)
# ------------------------------------------------------------


def _new_float_socket(tree: NodeTree, name: str, default: float, min_value: float, max_value: float, subtype: str = 'NONE'):
    """给模板组加一个浮点输入接口(带范围; Angle 等角度参数传 subtype='ANGLE' 获得角度控件)"""
    socket = tree.interface.new_socket(name=name, in_out='INPUT', socket_type='NodeSocketFloat')
    socket.default_value = default
    socket.min_value = min_value
    socket.max_value = max_value
    if subtype != 'NONE':
        socket.subtype = subtype
    return socket


def _new_int_socket(tree: NodeTree, name: str, default: int, min_value: int, max_value: int):
    """给模板组加一个整数输入接口(柔光箱阵列)"""
    socket = tree.interface.new_socket(name=name, in_out='INPUT', socket_type='NodeSocketInt')
    socket.default_value = default
    socket.min_value = min_value
    socket.max_value = max_value
    return socket


def _math_node(tree: NodeTree, name: str, operation: str, loc: tuple, x: float = 0.5, use_clamp: bool = False):
    """数学节点: 预置算子/钳位与照抄坐标; x 为第二操作数的写死值(单目算子该槽闲置)"""
    node = tree.nodes.new('ShaderNodeMath')
    node.name = name
    node.operation = operation
    node.use_clamp = use_clamp
    node.inputs[1].default_value = x
    node.location = loc
    return node


def _new_group_io(tree: NodeTree, input_loc: tuple, output_loc: tuple):
    """模板组的输入/输出节点(空树自建, 建在接口声明之后以带上全部插座)"""
    group_input = tree.nodes.new('NodeGroupInput')
    group_input.location = input_loc
    group_output = tree.nodes.new('NodeGroupOutput')
    group_output.location = output_loc
    return group_input, group_output


def _finish_template(tree: NodeTree, gradient_type: str, group_input, group_output, math_node, gamma_loc: tuple):
    """三组共用的收尾段: Gamma 节点整形并接出"强度"输出, 打模板标记"""
    tree.interface.new_socket(name="Strength", in_out='OUTPUT', socket_type='NodeSocketFloat')
    gamma = tree.nodes.new('ShaderNodeGamma')
    gamma.name = "Gamma"
    gamma.location = gamma_loc
    tree.links.new(math_node.outputs[0], gamma.inputs["Color"])
    tree.links.new(group_input.outputs["Gamma"], gamma.inputs["Gamma"])
    tree.links.new(gamma.outputs[0], group_output.inputs["Strength"])
    tree[_MARKER_KEY] = _TEMPLATE_KIND + gradient_type


def _build_radial_template() -> NodeTree:
    """径向渐变模板(坐标/接口照抄作者 5.2 文件): Parametric 减中心取长度 -> Map Range(扩散
    控制 To Max) -> SINE -> Gamma"""
    tree = bpy.data.node_groups.new("ch_adv_radial", 'ShaderNodeTree')
    _new_float_socket(tree, "渐变扩散", 1.0, 0.0, 2.0, subtype='FACTOR')
    _new_float_socket(tree, "Gamma", 1.0, 0.001, 10.0)
    group_input, group_output = _new_group_io(tree, (-280.0, -260.0), (640.0, 0.0))
    geometry = tree.nodes.new('ShaderNodeNewGeometry')
    geometry.location = (-460.0, 0.0)
    subtract = tree.nodes.new('ShaderNodeVectorMath')
    subtract.name = "Subtract Center"
    subtract.operation = 'SUBTRACT'
    subtract.inputs[1].default_value = _PARAM_CENTER
    subtract.location = (-280.0, 0.0)
    length = tree.nodes.new('ShaderNodeVectorMath')
    length.name = "Radius"
    length.operation = 'LENGTH'
    length.location = (-100.0, 0.0)
    tree.links.new(geometry.outputs["Parametric"], subtract.inputs[0])
    tree.links.new(subtract.outputs["Vector"], length.inputs[0])
    map_range = tree.nodes.new('ShaderNodeMapRange')
    map_range.name = "Falloff"
    map_range.clamp = True
    map_range.inputs["From Min"].default_value = 0.499
    map_range.inputs["From Max"].default_value = 0.0
    map_range.inputs["To Min"].default_value = 0.0
    map_range.location = (80.0, 0.0)
    tree.links.new(length.outputs["Value"], map_range.inputs["Value"])
    # 渐变扩散: 减 0.5 后驱动 Map Range 的 To Max(作者新调校, 默认 1.0 -> 0.5)
    spread = _math_node(tree, "Spread", 'SUBTRACT', (-100.0, -140.0), x=0.5)
    tree.links.new(group_input.outputs["渐变扩散"], spread.inputs[0])
    tree.links.new(spread.outputs[0], map_range.inputs["To Max"])
    sine = _math_node(tree, "Shape", 'SINE', (260.0, 0.0))
    tree.links.new(map_range.outputs["Result"], sine.inputs[0])
    _finish_template(tree, GRADIENT_RADIAL, group_input, group_output, sine, (440.0, 0.0))
    return tree


def _build_linear_template() -> NodeTree:
    """线性渐变模板(坐标/接口照抄作者 5.2 文件): Parametric 减中心 -> 绕 Z 旋转 ->
    X 分量*阵列*π -> COSINE 取绝对值 -> Gamma; 阵列改整数(1~100)"""
    tree = bpy.data.node_groups.new("ch_adv_linear", 'ShaderNodeTree')
    _new_float_socket(tree, "Angle", 0.0, -math.pi, math.pi, subtype='ANGLE')
    _new_int_socket(tree, "Array", 1, 1, 100)
    _new_float_socket(tree, "Gamma", 1.0, 0.001, 10.0)
    group_input, group_output = _new_group_io(tree, (-380.0, -260.0), (980.0, -20.0))
    geometry = tree.nodes.new('ShaderNodeNewGeometry')
    geometry.location = (-560.0, 40.0)
    subtract = tree.nodes.new('ShaderNodeVectorMath')
    subtract.name = "Subtract Center"
    subtract.operation = 'SUBTRACT'
    subtract.inputs[1].default_value = _PARAM_CENTER
    subtract.location = (-380.0, 40.0)
    tree.links.new(geometry.outputs["Parametric"], subtract.inputs[0])
    rotate = tree.nodes.new('ShaderNodeVectorRotate')
    rotate.name = "Tilt"
    rotate.location = (-200.0, 40.0)
    tree.links.new(subtract.outputs["Vector"], rotate.inputs["Vector"])
    tree.links.new(group_input.outputs["Angle"], rotate.inputs["Angle"])
    separate = tree.nodes.new('ShaderNodeSeparateXYZ')
    separate.name = "Axis"
    separate.location = (-20.0, 40.0)
    tree.links.new(rotate.outputs["Vector"], separate.inputs["Vector"])
    # 乘法树按作者文件排布: Math=阵列*π, Math.009=X*Math(运算等价, 连线次序照抄)
    tiled = _math_node(tree, "Tile", 'MULTIPLY', (-20.0, -100.0), x=_HALF_PERIOD)
    tree.links.new(group_input.outputs["Array"], tiled.inputs[0])
    waves = _math_node(tree, "Waves", 'MULTIPLY', (160.0, 40.0))
    tree.links.new(separate.outputs["X"], waves.inputs[0])
    tree.links.new(tiled.outputs[0], waves.inputs[1])
    cosine = _math_node(tree, "Shape", 'COSINE', (340.0, 40.0))
    tree.links.new(waves.outputs[0], cosine.inputs[0])
    folded = _math_node(tree, "Fold", 'ABSOLUTE', (520.0, 40.0), x=_HALF_PERIOD, use_clamp=True)
    tree.links.new(cosine.outputs[0], folded.inputs[0])
    _finish_template(tree, GRADIENT_LINEAR, group_input, group_output, folded, (700.0, 40.0))
    return tree


def _build_softbox_template() -> NodeTree:
    """柔光箱模板(坐标照抄作者 5.2 文件): X/Y 两向正弦条纹(各乘阵列与 π) ->
    SMOOTH_MIN 按平滑距离取软最小 -> Gamma"""
    tree = bpy.data.node_groups.new("ch_adv_softbox", 'ShaderNodeTree')
    _new_float_socket(tree, "平滑距离", 0.5, 0.0, 10.0)
    _new_int_socket(tree, "阵列X", 1, 1, 100)
    _new_int_socket(tree, "阵列Y", 1, 1, 100)
    _new_float_socket(tree, "Gamma", 1.0, 0.001, 10.0)
    group_input, group_output = _new_group_io(tree, (-480.0, -300.0), (820.0, -240.0))
    geometry = tree.nodes.new('ShaderNodeNewGeometry')
    geometry.location = (-660.0, 0.0)
    separate = tree.nodes.new('ShaderNodeSeparateXYZ')
    separate.name = "Axis"
    separate.location = (-480.0, 0.0)
    tree.links.new(geometry.outputs["Parametric"], separate.inputs["Vector"])

    def strip(axis: str, array_name: str, tag: str, loc_y: float, tile_loc: tuple = None):
        """单轴条纹段: 坐标分量*阵列 -> *π -> SINE -> ABS, 返回绝对值输出口"""
        tiled = _math_node(tree, "Tile " + tag, 'MULTIPLY', tile_loc if tile_loc is not None else (-280.0, loc_y))
        tree.links.new(separate.outputs[axis], tiled.inputs[0])
        tree.links.new(group_input.outputs[array_name], tiled.inputs[1])
        halved = _math_node(tree, "Half Period " + tag, 'MULTIPLY', (-100.0, loc_y), x=_HALF_PERIOD)
        tree.links.new(tiled.outputs[0], halved.inputs[0])
        sine = _math_node(tree, "Stripe " + tag, 'SINE', (80.0, loc_y))
        tree.links.new(halved.outputs[0], sine.inputs[0])
        folded = _math_node(tree, "Fold " + tag, 'ABSOLUTE', (260.0, loc_y))
        tree.links.new(sine.outputs[0], folded.inputs[0])
        return folded.outputs[0]

    smooth = _math_node(tree, "Soft Min", 'SMOOTH_MIN', (440.0, 80.0), use_clamp=True)
    tree.links.new(strip("X", "阵列X", "X", 80.0), smooth.inputs[0])
    tree.links.new(strip("Y", "阵列Y", "Y", -80.0, tile_loc=(-280.0, -100.0)), smooth.inputs[1])
    tree.links.new(group_input.outputs["平滑距离"], smooth.inputs[2])
    _finish_template(tree, GRADIENT_SOFTBOX, group_input, group_output, smooth, (640.0, -240.0))
    return tree


def _build_texture_array_template() -> NodeTree:
    """纹理阵列坐标模板(坐标/接口照抄作者 5.2 文件; Menu Switch 以 Mix 因子切换模拟——
    5.1.2 无该节点类型): 矩形阵列(坐标*阵列数取模平铺)与环形阵列(极坐标旋转一圈均布)
    双路二选一, 输出图像纹理的采样矢量"""
    tree = bpy.data.node_groups.new("ch_adv_texture_array", 'ShaderNodeTree')
    _new_float_socket(tree, "阵列方式", 0.0, 0.0, 1.0, subtype='FACTOR')
    _new_int_socket(tree, "阵列X", 1, 1, 100)
    _new_int_socket(tree, "阵列Y", 1, 1, 100)
    _new_float_socket(tree, "半径", 0.3, 0.0, 1.0)
    _new_int_socket(tree, "阵列数量", 3, 1, 24)
    _new_float_socket(tree, "缩放", 0.3, 0.001, 1.0)
    _new_float_socket(tree, "自旋转", 0.0, -math.tau, math.tau, subtype='ANGLE')
    tree.interface.new_socket(name="Vector", in_out='OUTPUT', socket_type='NodeSocketVector')
    group_input, group_output = _new_group_io(tree, (1520.0, 40.0), (1880.0, 780.0))
    geometry = tree.nodes.new('ShaderNodeNewGeometry')
    geometry.location = (-640.0, 680.0)
    # 公共段: Parametric 减中心(0.5, 0.5)
    center = tree.nodes.new('ShaderNodeVectorMath')
    center.name = "Subtract Center"
    center.operation = 'SUBTRACT'
    center.inputs[1].default_value = (0.5, 0.5, 0.0)
    center.location = (-400.0, 200.0)
    tree.links.new(geometry.outputs["Parametric"], center.inputs[0])
    # 矩形阵列: X/Y 各乘阵列数后对 1 取模(每格重复)
    separate = tree.nodes.new('ShaderNodeSeparateXYZ')
    separate.name = "Rect Axis"
    separate.location = (500.0, 760.0)
    tree.links.new(geometry.outputs["Parametric"], separate.inputs["Vector"])
    tile_x = _math_node(tree, "Tile X", 'MULTIPLY', (680.0, 760.0))
    tree.links.new(separate.outputs["X"], tile_x.inputs[0])
    tree.links.new(group_input.outputs["阵列X"], tile_x.inputs[1])
    wrap_x = _math_node(tree, "Wrap X", 'MODULO', (860.0, 760.0), x=1.0)
    tree.links.new(tile_x.outputs[0], wrap_x.inputs[0])
    tile_y = _math_node(tree, "Tile Y", 'MULTIPLY', (680.0, 600.0))
    tree.links.new(separate.outputs["Y"], tile_y.inputs[0])
    tree.links.new(group_input.outputs["阵列Y"], tile_y.inputs[1])
    wrap_y = _math_node(tree, "Wrap Y", 'MODULO', (860.0, 600.0), x=1.0)
    tree.links.new(tile_y.outputs[0], wrap_y.inputs[0])
    combine = tree.nodes.new('ShaderNodeCombineXYZ')
    combine.name = "Rect Vector"
    combine.location = (1040.0, 760.0)
    tree.links.new(wrap_x.outputs[0], combine.inputs["X"])
    tree.links.new(wrap_y.outputs[0], combine.inputs["Y"])
    # 环形阵列: 数量钳到下限 -> 2π/数量 = 角度步 -> 现位置角取整对齐步进 -> 绕 -Z 旋转
    count_clamped = _math_node(tree, "Count Safe", 'MAXIMUM', (-220.0, -60.0), x=1.0)
    tree.links.new(group_input.outputs["阵列数量"], count_clamped.inputs[0])
    step = _math_node(tree, "Angle Step", 'DIVIDE', (-40.0, -60.0))
    step.inputs[0].default_value = _HALF_PERIOD * 2.0
    tree.links.new(count_clamped.outputs[0], step.inputs[1])
    polar = _math_node(tree, "Polar Angle", 'ARCTAN2', (-40.0, 120.0))
    ring_separate = tree.nodes.new('ShaderNodeSeparateXYZ')
    ring_separate.name = "Ring Axis"
    ring_separate.location = (-220.0, 120.0)
    tree.links.new(center.outputs["Vector"], ring_separate.inputs["Vector"])
    tree.links.new(ring_separate.outputs["Y"], polar.inputs[0])
    tree.links.new(ring_separate.outputs["X"], polar.inputs[1])
    aligned = _math_node(tree, "Align", 'DIVIDE', (140.0, 120.0))
    tree.links.new(polar.outputs[0], aligned.inputs[0])
    tree.links.new(step.outputs[0], aligned.inputs[1])
    index = _math_node(tree, "Index", 'ROUND', (320.0, 120.0))
    tree.links.new(aligned.outputs[0], index.inputs[0])
    angle = _math_node(tree, "Snapped Angle", 'MULTIPLY', (500.0, 120.0))
    tree.links.new(index.outputs[0], angle.inputs[0])
    tree.links.new(step.outputs[0], angle.inputs[1])
    spin_source = tree.nodes.new('ShaderNodeVectorRotate')
    spin_source.name = "Ring Rotate"
    spin_source.rotation_type = 'AXIS_ANGLE'
    spin_source.inputs["Axis"].default_value = (0.0, 0.0, -1.0)
    spin_source.location = (680.0, 240.0)
    tree.links.new(center.outputs["Vector"], spin_source.inputs["Vector"])
    tree.links.new(angle.outputs[0], spin_source.inputs["Angle"])
    radius = tree.nodes.new('ShaderNodeVectorMath')
    radius.name = "Ring Radius"
    radius.operation = 'SCALE'
    radius.inputs[0].default_value = (1.0, 0.0, 0.0)
    radius.location = (680.0, -80.0)
    tree.links.new(group_input.outputs["半径"], radius.inputs["Scale"])
    offset = tree.nodes.new('ShaderNodeVectorMath')
    offset.name = "Ring Offset"
    offset.operation = 'SUBTRACT'
    offset.location = (860.0, -80.0)
    tree.links.new(spin_source.outputs["Vector"], offset.inputs[0])
    tree.links.new(radius.outputs["Vector"], offset.inputs[1])
    spun = tree.nodes.new('ShaderNodeVectorRotate')
    spun.name = "Spin Rotate"
    spun.rotation_type = 'Z_AXIS'
    spun.location = (1040.0, -80.0)
    tree.links.new(offset.outputs["Vector"], spun.inputs["Vector"])
    tree.links.new(group_input.outputs["自旋转"], spun.inputs["Angle"])
    # 缩放: Shrink DIVIDE = 1.0 / 缩放(照抄作者连线: 缩放接口而非阵列数量)
    shrink = _math_node(tree, "Shrink", 'DIVIDE', (1040.0, -300.0))
    shrink.inputs[0].default_value = 1.0
    tree.links.new(group_input.outputs["缩放"], shrink.inputs[1])
    ring = tree.nodes.new('ShaderNodeVectorMath')
    ring.name = "Ring Vector"
    ring.operation = 'SCALE'
    ring.location = (1220.0, -80.0)
    tree.links.new(spun.outputs["Vector"], ring.inputs[0])
    tree.links.new(shrink.outputs[0], ring.inputs["Scale"])
    centered = tree.nodes.new('ShaderNodeVectorMath')
    centered.name = "Ring Centered"
    centered.operation = 'ADD'
    centered.inputs[1].default_value = (0.5, 0.5, 0.0)
    centered.location = (1400.0, -80.0)
    tree.links.new(ring.outputs["Vector"], centered.inputs[0])
    # 二选一: Mix 因子=阵列方式(0=矩形 1=环形), 5.1 无 Menu Switch 的等价模拟(矢量混合)
    mix = tree.nodes.new('ShaderNodeMix')
    mix.name = "Mode Switch"
    mix.data_type = 'VECTOR'
    mix.location = (1700.0, 780.0)
    tree.links.new(group_input.outputs["阵列方式"], mix.inputs[0])
    tree.links.new(combine.outputs["Vector"], mix.inputs[4])
    tree.links.new(centered.outputs["Vector"], mix.inputs[5])
    tree.links.new(mix.outputs[1], group_output.inputs["Vector"])
    tree[_MARKER_KEY] = _TEMPLATE_KIND + 'TEXTURE_ARRAY'
    return tree


def _ensure_template(gradient_type: str) -> NodeTree:
    """确保模板组存在(按标记查复用, 缺失重建; 组随使用它的 .blend 保存)"""
    marker = _TEMPLATE_KIND + gradient_type
    for tree in bpy.data.node_groups:
        if tree.get(_MARKER_KEY) == marker:
            return tree
    if gradient_type == GRADIENT_RADIAL:
        return _build_radial_template()
    if gradient_type == GRADIENT_LINEAR:
        return _build_linear_template()
    if gradient_type == GRADIENT_SOFTBOX:
        return _build_softbox_template()
    return _build_texture_array_template()


# ------------------------------------------------------------
# 每灯实例链(组实例 + 色标 Ramp 常驻, 切换只改接线)
# ------------------------------------------------------------


def _chain_frame(tree: NodeTree, frame_key: str) -> Node:
    """按档取/建链 Frame(组织容器; 标签与纵向位置见 _CHAIN_FRAMES)

    位置每次调用都重写: Frame 会随内容自动收缩并把 origin 摆到"首节点 − 内边距", 手拖或历史
    漂移都在下一次 apply 归位(代价是不保留用户对 Frame 的手动摆位).
    """
    label, frame_y = _CHAIN_FRAMES[frame_key]
    marker = _FRAME_KIND + frame_key
    frame = _marked(tree.nodes, marker)
    if frame is None:
        frame = tree.nodes.new('NodeFrame')
        frame.name = "ch_adv_frame_" + frame_key.lower()
        frame.label = label
        frame[_MARKER_KEY] = marker
    frame.location = (_FRAME_X, frame_y)
    return frame


def _pin(node: Node, frame_key: str, loc: tuple) -> None:
    """把链节点钉回预设坐标与 Frame(每次 apply 都执行: 旧灯既有节点随重写自动对位)

    先挂父级、再写 location: 给已定位的 Frame 赋 parent 时, Blender 按"保持视觉位置"
    把 location 反算成差值(loc - frame.location), 顺序反了 loc 就成了绝对坐标, 五档内容
    会全叠在同一处(作者 5.1.2 实测). 挂完再写 location 才是相对 Frame 的偏移.
    """
    node.parent = _chain_frame(node.id_data, frame_key)
    node.location = loc


def _ensure_group_node(tree: NodeTree, gradient_type: str) -> Node:
    """确保灯树里该模式的组实例节点(误删重建, 模板绑错重绑; 归入本档 Frame)"""
    marker = _GROUP_KIND + gradient_type
    node = _marked(tree.nodes, marker)
    template = _ensure_template(gradient_type)
    if node is None:
        node = tree.nodes.new('ShaderNodeGroup')
        node.name = "ch_adv_" + gradient_type.lower()
        node[_MARKER_KEY] = marker
    _pin(node, gradient_type, _CHAIN_ORIGIN)
    if node.node_tree != template:
        node.node_tree = template
    return node


def _ensure_ramp_node(tree: NodeTree, gradient_type: str) -> Node:
    """确保灯树里该模式的 ColorRamp(常驻常接; 色标默认全白=无色偏, 调色从白起步)"""
    marker = _RAMP_KIND + gradient_type
    node = _marked(tree.nodes, marker)
    if node is None:
        node = tree.nodes.new('ShaderNodeValToRGB')
        node.name = "ch_adv_ramp_" + gradient_type.lower()
        node[_MARKER_KEY] = marker
        for element in node.color_ramp.elements:
            element.color = (1.0, 1.0, 1.0, 1.0)
    _pin(node, gradient_type, (_CHAIN_MID, _CHAIN_ORIGIN[1]))
    return node


def _ensure_marked_node(tree: NodeTree, marker: str, bl_idname: str, name: str, frame_key: str, loc: tuple):
    """按标记取/建一个链节点(误删重建), 并钉回预设坐标与 Frame"""
    node = _marked(tree.nodes, marker)
    if node is None:
        node = tree.nodes.new(bl_idname)
        node.name = name
        node[_MARKER_KEY] = marker
    _pin(node, frame_key, loc)
    return node


def _ensure_image_chain(tree: NodeTree) -> tuple:
    """图像链三节点: 阵列坐标组实例 -> 图像纹理 -> 色相/饱和度/明度(常驻; 几何源在阵列组内)

    组实例标记与渐变三档同走 GROUP: 前缀(find_advanced_node 的前缀映射依赖它).
    """
    array = _ensure_marked_node(tree, _GROUP_KIND + MARK_IMAGE_ARRAY, 'ShaderNodeGroup', "ch_adv_texture_array", "IMAGE", _CHAIN_ORIGIN)
    template = _ensure_template(MARK_IMAGE_ARRAY)
    if array.node_tree != template:
        array.node_tree = template
    tex = _ensure_marked_node(tree, MARK_IMAGE_TEX, 'ShaderNodeTexImage', "ch_adv_image_tex", "IMAGE", (_CHAIN_MID, _CHAIN_ORIGIN[1]))
    hsv = _ensure_marked_node(tree, MARK_IMAGE_HSV, 'ShaderNodeHueSaturation', "ch_adv_image_hsv", "IMAGE", (_CHAIN_LAST, _CHAIN_ORIGIN[1]))
    tree.links.new(array.outputs["Vector"], tex.inputs["Vector"])
    tree.links.new(tex.outputs["Color"], hsv.inputs["Color"])
    return array, tex, hsv


def _ensure_ies_chain(tree: NodeTree) -> tuple:
    """IES 链两节点: IES 纹理(EXTERNAL 模式, 文件路径由选择器写入) -> 伽玛(常驻)"""
    tex = _ensure_marked_node(tree, MARK_IES_TEX, 'ShaderNodeTexIES', "ch_adv_ies_tex", "IES", _CHAIN_ORIGIN)
    if tex.mode != 'EXTERNAL':
        tex.mode = 'EXTERNAL'
    gamma = _ensure_marked_node(tree, MARK_IES_GAMMA, 'ShaderNodeGamma', "ch_adv_ies_gamma", "IES", (_CHAIN_MID, _CHAIN_ORIGIN[1]))
    tree.links.new(tex.outputs["Factor"], gamma.inputs["Color"])
    return tex, gamma


def _clear_plugin_links(tree: NodeTree, socket):
    """摘除插座上来自插件节点的接入连线(用户自接的线不动, 见 emission_occupied)"""
    for link in list(socket.links):
        if link.from_node.get(_MARKER_KEY) is not None:
            tree.links.remove(link)


def _align_output_nodes(tree: NodeTree, emission: Node, frame_key: str) -> None:
    """Emission 与灯光输出对齐到本档 Chain Frame 的纵坐标(横坐标各自固定, 均不裹入 Frame)

    纵坐标读 Frame 的实际位置而非常量, 与 _chain_frame 的重写口径保持一致(位置由那里统一保证);
    Frame 缺失(接线前必已建, 此处只作兜底)回落 _CHAIN_FRAMES 的常量.
    """
    frame = _marked(tree.nodes, _FRAME_KIND + frame_key)
    y = frame.location.y if frame is not None else _CHAIN_FRAMES[frame_key][1]
    output_node = next((node for node in tree.nodes if node.type == 'OUTPUT_LIGHT'), None)
    for node, x in ((emission, _EMISSION_X), (output_node, _OUTPUT_X)):
        if node is None:
            continue
        node.parent = None
        node.location = (x, y)


def apply_light_advanced_wiring(light) -> None:
    """按灯光上的高级设置状态重接 Emission(幂等)

    模式"无" = 只摘插件旧线不接新线(链节点常驻, 参数与色标保留); 其余按当前模式接线:
    渐变 = 组实例"强度"接 Emission.Strength, 色标(默认全白)恒接 Emission.Color;
    图像 = 几何参数坐标 -> 图像纹理 -> HSV 按接线目标接 Emission.Color/Strength
    (强度档适配灰度图); IES = IES 纹理 -> 伽玛 接 Emission.Strength.
    用户手动接线不阻断重接: 目标插座由插件线顶置生效(该插座原有手线随之断开, 探针实证
    links.new 对单输入插座为替换语义), 其余插座上的手线留置原处.
    灯型不符时不接线(渐变/图像仅面光/聚光, IES 仅点光, 与面板提示行同口径): 插件旧线
    已在上文清空 = 走"无"档断线, 链节点与参数色标保留. 外部切灯型由 depsgraph 自愈
    钩子补接/断线(handlers._reapply_light_advanced).
    Emission 与灯光输出的对位放在接线之后: 纵坐标要跟本档 Frame 走, 而该 Frame 可能正由
    本次接线新建;"无"档与灯型不符时不动这两个节点的位置(无接入节点可对齐).
    """
    if light is None or light.library is not None:
        return
    tree = light.node_tree
    if tree is None:
        return
    emission = _find_emission(light)
    if emission is None:
        return
    _clear_plugin_links(tree, emission.inputs["Strength"])
    _clear_plugin_links(tree, emission.inputs["Color"])
    settings = light.ch_advanced
    if settings.mode == 'NONE':
        return
    mode = settings.mode
    # 灯型闸: 灯型不符直接返回(旧线已清 = "无"档断线, 链节点与色标保留)
    if mode in {'GRADIENT', 'IMAGE'}:
        if light.type not in {'AREA', 'SPOT'}:
            return
    elif mode == 'IES' and light.type != 'POINT':
        return
    if mode == 'GRADIENT':
        frame_key = settings.gradient_type
        group_node = _ensure_group_node(tree, frame_key)
        tree.links.new(group_node.outputs["Strength"], emission.inputs["Strength"])
        # 色标恒接(默认全白=无色偏, 调色在面板色标上做), 着色开关已取消
        ramp = _ensure_ramp_node(tree, frame_key)
        tree.links.new(group_node.outputs["Strength"], ramp.inputs["Fac"])
        tree.links.new(ramp.outputs["Color"], emission.inputs["Color"])
    elif mode == 'IMAGE':
        frame_key = "IMAGE"
        _array, tex, hsv = _ensure_image_chain(tree)
        # 纹理扩展属性: 环形=裁剪 / 其它=重复(照抄作者口径)
        tex.extension = 'CLIP' if settings.image_array_mode == 'RING' else 'REPEAT'
        # 接线目标: 颜色=彩色投影(默认), 强度=灰度图调制亮度(颜色插座转灰度语义)
        target_socket = "Strength" if settings.image_target == 'STRENGTH' else "Color"
        tree.links.new(hsv.outputs["Color"], emission.inputs[target_socket])
    elif mode == 'IES':
        frame_key = "IES"
        _tex, gamma = _ensure_ies_chain(tree)
        tree.links.new(gamma.outputs[0], emission.inputs["Strength"])
    else:
        # 未知模式值(枚举本不应出现): 不接线, 也不动 Emission/输出的位置
        return
    _align_output_nodes(tree, emission, frame_key)
