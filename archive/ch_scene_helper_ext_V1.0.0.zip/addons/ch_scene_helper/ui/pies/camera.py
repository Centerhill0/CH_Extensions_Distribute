"""
相机饼菜单模块

提供以下功能:
- CameraPie: 相机操作饼菜单
"""

from bpy.types import Menu, Context
from ...operators.object.camera import SetAsSceneCamera, CreateAlignCamera


# ============================================================
# 相机饼菜单
# ============================================================
class CameraPie(Menu):
    """
    相机操作饼菜单

    功能:提供相机相关操作
    - 相机选择和切换
    - 跟踪约束设置
    - 相机视图控制
    - 构图辅助线显示

    要求:物体模式
    """

    bl_idname = "VIEW3D_MT_ch_camera_pie"
    bl_label = "CH Camera Pie"
    bl_description = "Camera Pie Menu"

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT'

    def draw(self, context: Context):
        has_camera = context.scene.camera is not None and context.scene.camera.type == 'CAMERA'
        if has_camera:
            camera = context.scene.camera.data

        layout = self.layout
        layout.scale_y = 1.2
        pie = layout.menu_pie()

        # 左:相机选择和切换
        row = pie.row(align=True)
        col = row.box().column()
        col.label(text="Select", icon='RESTRICT_SELECT_OFF')
        col.operator("object.select_camera", text="Active Camera")
        col.operator("object.select_by_type", text="All Cameras").type = 'CAMERA'
        if has_camera:
            row.separator(factor=0.3)
            col = row.box().column()
            col.prop(camera, "show_safe_areas", text="Safe Areas")
            col.prop(camera, "show_background_images", text="Background Images")
            col.prop(camera.dof, "use_dof", text="Depth of Field")

        # 右
        row = pie.row(align=True)
        if has_camera:
            col = row.box().column()
            col.prop(camera, "show_composition_thirds", text="Thirds")
            col.prop(camera, "show_composition_center", text="Center")
            col.prop(camera, "show_composition_golden", text="Golden Ratio")
            row.separator(factor=0.3)
        col = row.box().column()
        col.operator("object.track_set", text="Track To", icon='CON_TRACKTO').type = 'TRACKTO'
        col.operator("object.track_set", text="Damped Track", icon='CON_TRACKTO').type = 'DAMPTRACK'
        col.operator("object.track_clear", text="Clear Track", icon='X').type = 'CLEAR'

        # 下:相机视图和构图
        col = pie.column()
        row = col.row(align=True)
        # 不传 text: 原生 bl_label 同名, 经系统 Operator 语境自动翻译(显式 text 走默认语境)
        row.operator("view3d.view_center_camera", icon='SELECT_SET')
        if has_camera:
            row.separator(factor=0.3)
            row.prop(camera, "show_name")

        # 显示构图选项(仅当场景相机存在且为相机类型时)
        if has_camera:
            row = col.row()
            split = row.split(factor=0.15, align=True)
            split.prop(camera, "show_passepartout", text="")
            split.prop(camera, "passepartout_alpha", text="Passepartout")

        # 窗口合成选项
        col.separator(factor=0.3)
        row = col.row(align=True, heading="Compositor")
        row.prop(context.space_data.shading, "use_compositor", expand=True)

        # 上:相机锁定和对齐
        col = pie.column()
        col.prop(context.space_data, "lock_camera", text="Lock Camera to View")

        # 左上:设为场景相机(任意活动物体; Ctrl 仅设置不切换视图)
        row = pie.row()
        row.operator(SetAsSceneCamera.bl_idname, text="Set Active Object as Scene Camera")

        # 右上:添加对齐视角摄像机
        row = pie.row()
        row.operator(CreateAlignCamera.bl_idname, text="Add Camera Aligned to View", icon='VIEW_CAMERA_UNSELECTED')

        if context.space_data.shading.type == "RENDERED":
            split = row.split()
            split.prop(context.scene.render, "film_transparent")

        # 左下:相机视图和对齐
        row = pie.row(align=True)
        row.operator("view3d.camera_to_view", text="Align Active Camera to View")

        # 右下
        col = pie.column()
        col.operator("view3d.camera_to_view_selected", text="Align Active Camera to Selected", icon='STICKY_UVS_LOC')
