from ....common.i18n.dictionary import preprocess_dictionary

# 翻译条目按对应 Operator / 面板分块注释归类:
# Operator 标签用 ("Operator", "English text"), 通用文本与 report 消息用 ("*", "English text")
dictionary = {
    "zh_HANS": {
        # 侧栏选项卡与面板共用文案(ui/panels/scene_panels.py)
        ("*", "Scene Helper"): "场景助手",
        # 材质参数子面板(ui/panels/_settings.py 的材质设置区)
        # 属性名(Base Color/Color/Metallic/Roughness/IOR/Emission Color/Emission Strength/
        # Strength/Projection/Blend/Texture Coordinate 等)均为系统词条, 已查
        # i18n_check_terms 全部命中, 不入典(i18n 规范: 系统词条不翻译)
        ("*", "Material Settings"): "材质设置",
        # PBR 设置子面板(ui/panels/_settings.py 的 draw_material_pbr)
        # 内容为纹理坐标输出与投影统一控制
        ("*", "PBR Settings"): "PBR设置",
        (
            "*",
            "Texture coordinate output feeding the Mapping node (edits node links, not undoable; affects all users of this material)",
        ): "接入 Mapping 节点的纹理坐标输出(直接改节点接线, 不进撤销栈; 该材质的全部使用者物体都会受影响, 建议先复制材质再改)",
        ("*", "Projection for all PBR image textures (applied to every texture; not undoable)"): "全部 PBR 图像纹理的投影方式(统一应用到每张纹理; 不进撤销栈)",
        ("*", "Blend for box projection, applied to every PBR image texture (not undoable)"): "Box 投影的融合参数(统一应用到每张 PBR 纹理; 不进撤销栈)",
        # 面板动作行/设置子面板文案(未命中系统词条)
        ("*", "DOF"): "景深",
        # 列表按钮列开关(ui/panels/scene_options.py, 属性声明在 props.py)
        # 均为图标按钮(text=""), 只有 name(悬停标签)与 description(tooltip)文案;
        # name 用系统已有词条 Sync Selection(不入典, 系统 mo 优先)
        ("*", "Show 0 Users"): "显示0用户",
        ("*", "Also list materials that have no users (orphans and fake-user only)"): "同时列出没有任何使用者的材质(孤儿与仅假用户)",
        ("*", "Also list worlds that have no users (orphans and fake-user only)"): "同时列出没有任何使用者的世界环境(孤儿与仅假用户)",
        ("*", "Show Linked Data"): "显示库链接",
        (
            "*",
            "Also list data-blocks linked from libraries (materials, worlds and images); turn off to list only data-blocks from this file",
        ): "同时列出经库链接引入的数据块(材质/世界环境/图像)；关闭后只列本文件的数据块",
        # 材质动作算子(operators/utils/material_ops.py)
        # 按钮文案(作者定名): "Apply Material" -> 赋予材质; "Duplicate Material" -> 复制材质.
        # 原文必须避开系统词条: "Assign Material" 已被系统 mo 占用(译为"指定材质", 系统优先,
        # 插件条目不会生效), 故改用 Apply Material(已过 i18n_check_terms --query 未命中).
        ("Operator", "Apply Material"): "赋予材质",
        ("*", "Apply Material"): "赋予材质",
        ("Operator", "Activate Material"): "激活材质",
        ("*", "Activate Material"): "激活材质",
        ("Operator", "Merge Materials"): "合并材质",
        ("*", "Merge Materials"): "合并材质",
        # "Select Users" 仍被图像行首算子(ImageSelectUsers)使用; 材质行首按钮已改激活语义
        ("Operator", "Select Users"): "选中使用者",
        ("Operator", "Duplicate Material"): "复制材质",
        ("Operator", "Unlink Material"): "解除材质关联",
        ("*", "Unlink Material"): "解除材质关联",
        ("*", "No material selected"): "没有选中材质",
        ("*", "No activated materials to merge"): "没有可合并的激活材质",
        ("*", "No objects can hold the material"): "选中物体都不能持有材质槽",
        ("*", "Object has no material slots"): "物体没有材质槽",
        ("*", "Slot assign requires exactly one selected object"): "替换指定材质槽需要恰好选中一个物体",
        ("*", "Material not found"): "未找到材质",
        ("*", "Material not linked to any object"): "没有物体关联该材质",
        ("*", "Material unlinked from {} slots"): "已解除 {} 个材质槽的关联",
        ("*", "Material assigned: {} objects"): "已把材质赋给 {} 个物体",
        ("*", "Material appended: {} objects"): "已把材质追加到 {} 个物体",
        ("*", "Material replaced at slot: {}"): "已替换第 {} 个材质槽的材质",
        ("*", "Slot index out of range, replaced the last slot: {}"): "槽位编号溢出, 已替换末尾材质槽: {}",
        ("*", "Material duplicated and assigned: {}"): "已复制材质并赋给选中物体: {}",
        ("*", "No objects selected, the copy has no users"): "没有选中物体, 副本暂无使用者",
        ("*", "No instanced objects to make independent"): "没有需要独立化的实例物体",
        ("*", "Instances made independent: {} objects"): "已独立化 {} 个实例物体",
        ("*", "Failed to make instance independent: {}"): "实例独立化失败: {}",
        # 修饰键说明一律另起一行(以 \n 开头), 与代码规范「修饰键 tooltip 分行」一致
        (
            "*",
            "Assign the active material of the Materials panel to all selected objects\n+Ctrl: Append the material to the object material slots instead of replacing the active one\n+Alt: Replace the material slot of the given index (single selected object only, out of range replaces the last slot)",
        ): "把材质面板的活动材质赋给全部选中物体\n+Ctrl: 把材质追加到物体材质槽列表, 而不是替换活动槽\n+Alt: 替换指定编号的材质槽(仅单选一个物体时生效, 编号溢出则替换末尾槽)",
        ("*", "Slot Index"): "槽位编号",
        ("*", "Material slot index to replace (0-based, out of range replaces the last slot)"): "要替换的材质槽编号(从 0 开始, 溢出则替换末尾槽)",
        ("*", "Append the material to the object material slots instead of replacing the active one"): "把材质追加到物体材质槽列表, 而不是替换活动槽",
        (
            "*",
            "Duplicate the active material of the Materials panel and assign it to all selected objects\n+Alt: Make the selected instanced objects independent (selected objects sharing a mesh become one unified instance) and then duplicate the material; without instances it only shows a notice",
        ): "复制材质面板的活动材质并赋给全部选中物体\n+Alt: 先把选中的实例物体独立化(共用同一数据块的选中物体独立成一个统一实例), 再复制材质; 没有实例时只给出提示",
        ("*", "Unlink the active material from all objects\n+Shift: Delete the material data-block directly"): "解除活动材质与全部物体的关联\n+Shift: 直接删除该材质数据块",
        # "Delete"(F9 撤销面板的 delete 开关属性名)系统已有(ctx=空), 不入典
        ("*", "Delete the material data-block instead of only unlinking it"): "删除材质数据块, 而非仅解除关联",
        # 列表动作算子(operators/utils/list_ops.py)
        ("*", "Move Down"): "下移",
        ("Operator", "Move List Item"): "移动列表项",
        ("*", "Move List Item"): "移动列表项",
        ("*", "Move the active list item up or down (order saved in the blend file)"): "上移或下移列表活跃项(顺序随 blend 文件持久)",
        # "Sort by Name" 系统已有(ctx=空 与 Operator 均在 blender.mo), 不入典
        ("*", "Sort the list by name (order saved in the blend file)"): "按名称排序列表(顺序随 blend 文件持久)",
        ("Operator", "Delete Object"): "删除物体",
        ("*", "Delete Object"): "删除物体",
        (
            "*",
            "Delete the active object of the list (a light's controller empty with no other children is removed along with it)\nLight pie menu: delete every selected light with a controller (batch)",
        ): "删除列表活跃项对应的物体(灯光的无其它子级控制器随其一并删除)\n灯光饼菜单: 批量删除选中集中所有带控制器的灯光",
        ("*", "List item is no longer in the scene"): "列表项已不在场景中",
        # 摄像机饼菜单与摄像机算子(ui/pies/camera.py, operators/object/camera.py)
        ("Operator", "Toggle Camera"): "切换摄像机",
        ("Operator", "Set As Scene Camera"): "设为场景摄像机",
        ("Operator", "Add Align Camera"): "添加对齐摄像机",
        ("*", "Toggle Next"): "向下切换",
        ("*", "CH Camera Pie"): "CH 摄像机饼菜单",
        ("*", "Toggle the camera object"): "切换摄像机物体",
        ("*", "Set the active object as the scene camera and align the view to it\n+Ctrl: Set only, keep the current view"): "将活动物体设为场景摄像机并对齐视图\n+Ctrl: 仅设置, 不切换视图",
        # 摄像机独立分辨率属性组(props.py 的 CameraResolutionSettings; "Resolution X/Y" 为系统词条不入典)
        ("*", "Independent Resolution"): "独立分辨率",
        ("*", "Override the scene output resolution with this camera's own resolution while it is the scene camera"): "该摄像机为场景摄像机时用它自己的分辨率覆写场景输出分辨率",
        ("*", "Independent output width in pixels"): "独立输出的像素宽度",
        ("*", "Independent output height in pixels"): "独立输出的像素高度",
        ("Operator", "Set Active Object as Scene Camera"): "设置活动物体为场景摄像机",
        ("*", "Set Active Object as Scene Camera"): "设置活动物体为场景摄像机",
        ("*", "Create a camera for aligning the view"): "创建用于对齐视图的摄像机",
        ("*", "Camera Pie Menu"): "摄像机饼菜单",
        # 饼菜单按钮用显式 text= 绘制, 按 Operator 语境查找(GUI 实测定论, 同族弹窗一致);
        # "Frame Camera Bounds" 已去掉显式 text 改用原生 label, 不需要词条
        ("*", "Add Camera Aligned to View"): "添加摄像机对齐视角",
        ("*", "All Cameras"): "所有摄像机",
        ("*", "Align Active Camera to View"): "对齐活动摄像机到当前视角",
        ("*", "Align Active Camera to Selected"): "对齐活动摄像机到选中项",
        ("Operator", "All Cameras"): "所有摄像机",
        ("Operator", "Previous"): "上一个",
        ("Operator", "Next"): "下一个",
        # 约束按钮与系统 mo 约束名统一(标准追踪/阻尼追踪), 撤销面板与约束面板同屏同名
        ("Operator", "Track To"): "标准追踪",
        ("Operator", "Damped Track"): "阻尼追踪",
        ("Operator", "Add Camera Aligned to View"): "添加摄像机对齐视角",
        ("*", "No camera found in view layer"): "视图层中未找到摄像机",
        # 灯光饼菜单(ui/pies/light.py; 同上迁入)
        ("*", "CH Light Pie"): "CH 灯光饼菜单",
        # 类型菜单项走系统 mo 的 "Light" 语境(点光/日光/聚光/面光, iface_ctx 预译),
        # 与系统灯型命名一致, 插件不再自持分道词条(作者定); 弹窗标题走 * 语境
        ("*", "Add Light"): "添加灯光",
        # 饼菜单删除钮显式 text: 批量口径只删灯光物体, 与面板"删除物体"区分(作者定)
        ("Operator", "Delete Light"): "删除灯光",
        ("*", "Delete Light"): "删除灯光",
        ("*", "Light Pie Menu"): "灯光饼菜单",
        ("*", "Light Settings"): "灯光设置",
        # 灯光高级设置子面板(ui/panels/_settings.py 的 draw_light_advanced; 状态组在 props.py)
        # Radial/Linear/Array/Gamma/Mode/Strength/Angle/None(Operator 语境=无)均命中系统词条不入典
        # ("Gradient" 系统译"梯度渐变", 模块枚举/胶囊改用 "Gradient Module" 反译规避, 显示"渐变";
        #  模式胶囊是算子按钮, 显式 text 按 Operator 语境查找——"Image" 系统词条只有 * 语境,
        #  仿 Light Linking 双语境补 Operator 兜底)
        ("*", "Advanced Settings"): "高级设置",
        ("*", "Gradient Module"): "渐变",
        ("Operator", "Gradient Module"): "渐变",
        ("Operator", "Image"): "图像",
        ("*", "Softbox"): "柔光箱",
        # 组接口名已改中文预设名(平滑距离/阵列X/Y/阵列方式等), 不走翻译链不入典
        ("*", "Rect"): "矩形",
        ("*", "Ring"): "环形",
        ("*", "Array Mode"): "阵列方式",
        ("*", "Rectangular tiling or ring array of the projected texture"): "投射纹理的矩形平铺或环形阵列",
        ("*", "Switch the render engine to Cycles"): "请将渲染器切换为 Cycles",
        ("*", "Sun lights are not supported"): "不支持太阳光",
        ("*", "Switch the light to an area or spot light"): "请将灯光切换至面光或聚光",
        ("*", "Switch the light to a point light"): "请将灯光切换至点光",
        ("*", "Hand wiring detected on the Emission node"): "自发光节点存在手动接线(触碰任一控件可恢复插件接管)",
        ("*", "Linked light data is read-only"): "库链接灯光数据为只读",
        # 高级设置资产选择器(图像纹理/IES 光域网; "Image"/"IES" 为系统词条/专有名词不入典)
        ("*", "Add an asset library in the addon preferences"): "请先在插件偏好里添加资产库",
        ("*", "No category folders in this asset library"): "该资产库下没有分类子文件夹",
        ("*", "This asset library is already in the list"): "该资产库已在列表中",
        ("*", "No thumbnails in this category"): "该分类下没有缩略图项",
        ("Operator", "Set Asset Category"): "选定资产分类",
        ("Operator", "Set the category folder of the advanced settings asset picker"): "设定高级设置资产选择器的分类文件夹",
        ("Operator", "Cycle Asset Thumbnail"): "循环切换缩略图",
        ("Operator", "Apply the previous or next thumbnail in the current category (wraps around)"): "应用当前分类的上一张/下一张缩略图(回环)",
        ("Operator", "Cleanup Light Nodes"): "清理灯光节点",
        ("Operator", "Delete nodes of the light node tree that are not connected to the Light Output (plugin leftovers and stray nodes; frames are kept)"): "删除灯光节点树中未连接到灯光输出的节点(插件残留与游离节点; Frame 框保留)",
        ("*", "No orphan nodes in the light node tree"): "灯光节点树中没有孤立节点",
        ("*", "Cleaned {} orphan nodes"): "已清理 {} 个孤立节点",
        ("Operator", "Set Advanced Mode"): "设置高级模式",
        (
            "Operator",
            "Switch the advanced mode of the active light; the light type follows the mode (IES -> point; gradient and image -> area)\n+Shift: gradient and image switch to a spot light",
        ): "切换活动灯光的高级模式; 灯型随模式联动(IES→点光; 渐变/图像→面光)\n+Shift: 渐变/图像改切聚光",
        # 高级设置状态组 tooltip(props.LightAdvancedSettings)
        ("*", "Which advanced module drives the light; None deactivates all modules"): "驱动灯光的高级模块; 无档停用全部模块",
        ("*", "Deactivate the advanced settings (no module drives the light)"): "停用高级设置(没有模块驱动灯光)",
        ("*", "Drive the emission with a procedural gradient (radial, linear or softbox)"): "用程序渐变(径向/线性/柔光箱)驱动发光强度",
        ("*", "Gradient pattern applied to the light emission"): "作用于灯光发光的渐变图案",
        ("*", "Spherical falloff from the center of the light"): "从灯光中心向外球状衰减",
        ("*", "Linear falloff along a rotatable axis, tilable by the array factor"): "沿可旋转轴的线性衰减, 阵列系数可平铺",
        ("*", "Crossed sine stripes like a softbox grid, tilable in X and Y"): "如柔光箱网格的正交正弦条纹, X/Y 可平铺",
        ("*", "Project an image through the light"): "让灯光投射图像纹理",
        ("*", "Shape the light intensity with an IES profile"): "用 IES 光域网塑形灯光强度",
        # 图像档接线目标(颜色/强度两枚胶囊, "Color"/"Strength"/"Target" 均系统词条不入典;
        # 两个分类下拉 Menu 类的 bl_label 走 * 语境入典)
        ("*", "Asset Category"): "资产分类",
        ("*", "Which emission socket the image texture drives"): "图像纹理驱动的自发光插座",
        ("*", "Texture drives the emission color"): "纹理驱动发光颜色(彩色投影)",
        ("*", "Texture drives the emission strength (for grayscale maps)"): "纹理驱动发光强度(灰度图适用)",
        ("*", "HSV Value"): "明度",
        # 外部文件路径(轮9: 图像/IES 选择器的手动来源, 非空时优先于缩略图)
        ("*", "External Image"): "外部图像",
        ("*", "Path to an external image file (overrides the asset picker when set)"): "外部图像文件路径(设置后优先于资产选择器)",
        ("*", "External IES"): "外部IES",
        ("*", "Path to an external IES file (overrides the asset picker when set)"): "外部IES文件路径(设置后优先于资产选择器)",
        ("Operator", "Clear External File"): "清除外部文件",
        ("Operator", "Clear the external file path to restore asset picker control"): "清空外部文件路径以恢复资产选择器的控制",
        ("Operator", "Refresh Source"): "刷新来源",
        ("Operator", "Reload the currently applied image texture or IES file into the node from its source path"): "从来源路径重载当前应用的图像纹理或 IES 文件到节点",
        # 缩略图尺寸("Size"/"Controls"/"None"/"Image" 均为系统词条不入典;
        # "Thumbnail Size" 与 ch_ai_assistant 画廊同源词条, 译法照搬定译)
        ("*", "Thumbnail Size"): "缩略图尺寸",
        ("*", "Size of the thumbnails in the asset picker"): "资产选择器中缩略图的尺寸",
        ("*", "Popup Zoom"): "弹窗放大",
        ("*", "Size of the thumbnail cells in the popup grid relative to the inline grid"): "弹窗网格的格子相对行内网格的放大倍数",
        # 偏好: 资产库列表(每个库一个根目录 + 用途标签; 用途决定其出现在哪个选择器)
        # "Asset Library"/"Name"/"Path"/"Enabled"/"Texture" 均为系统词条不入典
        ("*", "Asset Library Paths"): "资产库路径",
        ("*", "No asset library yet"): "尚未添加资产库",
        ("*", "Purpose"): "用途",
        ("*", "PBR Material"): "PBR材质",
        ("*", "World Environment"): "世界环境",
        ("Operator", "Add Asset Library"): "添加资产库",
        ("Operator", "Pick a directory and add it as an asset library (the folder name becomes the library name)"): "选定一个目录并添加为资产库(目录名即库名)",
        ("*", "No directory selected"): "未选定目录",
        ("Operator", "Move Asset Library Up"): "资产库上移",
        ("Operator", "Move the selected asset library one row up"): "把选中的资产库上移一行",
        ("Operator", "Move Asset Library Down"): "资产库下移",
        ("Operator", "Move the selected asset library one row down"): "把选中的资产库下移一行",
        ("Operator", "Toggle Asset Library Enabled"): "启用/停用资产库",
        ("Operator", "Remove Asset Library"): "移除资产库",
        ("Operator", "Remove the selected asset library from the list"): "从列表移除选中的资产库",
        ("Operator", "Set Asset Library"): "选择资产库",
        ("Operator", "Use this asset library for the active picker"): "让当前选择器使用该资产库",
        # 资产库条目 tooltip(props.CHAssetLibrary)
        ("*", "Name shown in the asset library menu of the pickers"): "资产选择器库菜单里显示的名称",
        (
            "*",
            "Root directory of this asset library: category subfolders, top-level PNG thumbnails, same-name source files in the Textures or IES subfolder",
        ): "该资产库的根目录: 分类子文件夹, 顶层 PNG 为缩略图, Textures 或 IES 子文件夹内存放同名源文件",
        ("*", "Include this asset library in the pickers; turn off to keep it in the list but hide it from the menus"): "让该资产库出现在选择器里; 关闭后仍保留在列表中但不进菜单",
        ("*", "Which picker offers this asset library"): "该库出现在哪个选择器里",
        ("*", "Offer this library in the image texture picker of the light advanced settings"): "让该库出现在灯光高级设置的图像纹理选择器里",
        ("*", "Offer this library in the IES profile picker of the light advanced settings"): "让该库出现在灯光高级设置的 IES 光域网选择器里",
        ("*", "Offer this library in the PBR material picker (not available yet)"): "让该库出现在 PBR 材质选择器里(该功能尚未开发)",
        ("*", "Offer this library in the world environment texture picker (not available yet)"): "让该库出现在世界环境纹理选择器里(该功能尚未开发)",
        ("Operator", "Include"): "包含",
        ("Operator", "Exclude"): "排除",
        # 灯光面板扩展(灯光集合管理列表 + 隔离屏蔽世界; scene_options/props/row_ops/datablock_ops)
        ("*", "Mute World"): "屏蔽世界",
        (
            "*",
            "While isolating a light or a light collection, also mute every link into the World Output node to isolate it from the world lighting (links are restored on un-isolating)",
        ): "隔离灯光或灯光集合时同时屏蔽世界输出节点的全部接入端连线(取消隔离后恢复)",
        ("*", "Light Collections"): "灯光集合",
        # 灯光整理(datablock_ops 的相邻功能, 入口在灯光集合选项菜单)
        ("Operator", "Organize Lights"): "灯光整理",
        ("*", "Move every light outside the light collections into the newest light collection (one is created first when there is no light collection)"): "把灯光集合之外的灯光物体移入最新创建的灯光集合(没有灯光集合时先新建一个)",
        ("*", "No lights outside the light collections"): "灯光集合之外没有灯光物体",
        ("*", "Moved {} lights into {}"): "已将 {} 盏灯光移入 {}",
        # 摄像机整理(入口在摄像机列表选项菜单; 与灯光整理同款"真移动进集合"语义, 中文名同样名词在前)
        ("Operator", "Organize Cameras"): "摄像机整理",
        ("*", "Move every camera into the Cameras collection (created on first use; cameras are unlinked from their other collections)"): "把场景内所有摄像机移入 Cameras 集合(首次使用时自动新建; 摄像机将从原先所属的集合解除挂载)",
        ("*", "No cameras to organize"): "没有可整理的摄像机",
        ("*", "All cameras are already in the Cameras collection"): "全部摄像机已在 Cameras 集合中",
        ("*", "Moved {} cameras into {}"): "已将 {} 台摄像机移入 {}",
        # 灯光集合列表选项菜单(ui/panels/scene_options.py); 菜单标题 ctx=* 与 Operator 双语境
        ("Operator", "Collection Options"): "集合选项",
        ("*", "Collection Options"): "集合选项",
        # 灯光集合激活标记(ch_lights_active): 行首图标切换, 激活的集合过滤灯光列表
        ("Operator", "Activate Collection"): "激活集合",
        ("*", "Toggle this collection as the lights list filter (none checked shows all lights)"): "把该集合作为灯光列表的过滤开关(全不勾选时显示全部灯光)",
        ("*", "Lights Active"): "灯光激活",
        # "Add Collection" 系统已有(ctx=Operator), 不入典; "Delete Hierarchy" 亦为系统词条
        ("*", "Create a new light collection (auto-numbered CLS_NN_) inside the Lights collection"): "新建灯光集合(自动编号 CLS_NN_, 置于 Lights 集合下)",
        # 材质激活/合并(材质行首按钮与 IMPORT 按钮)
        (
            "*",
            "Activate this material and select its users in the scene (deactivates the others)\n+Shift: Toggle this material without touching the others (users are selected/deselected accordingly)",
        ): "激活该材质并在场景中选中其使用者(其它材质取消激活)\n+Shift: 只切换该材质而不影响其它(使用者随激活状态选中/减选)",
        (
            "*",
            "Replace all activated materials with this row's material: every user reference is re-linked and local source materials are removed (linked sources are kept, only their users are re-linked)",
        ): "把全部激活材质替换为本行材质(所有使用者引用改链, 本地源材质删除; 库链接源保留, 只改链其使用者; 用于合并相似材质)",
        ("*", "Linked source kept, its users were re-linked to the target"): "库链接源材质保留, 其使用者已改链到目标材质",
        ("*", "Material Active"): "材质激活",
        ("Operator", "Delete Collection"): "删除集合",
        ("*", "Delete this collection data-block\n+Shift: Also delete the objects and child collections inside"): "删除该集合数据块\n+Shift: 连同其内部物体与子集合一并删除",
        ("*", "Also delete the objects and child collections inside the collection"): "同时删除集合内的物体与子集合",
        # "Delete Hierarchy" 系统词条仅 Operator 语境, 属性名走 * 语境需插件兜底(仿 Light Linking 双语境)
        ("*", "Delete Hierarchy"): "删除层级",
        ("*", "Collection hierarchy delete also removes the objects and child collections inside ({} users)"): "删除层级将同时删除集合内的物体与子集合(将清空 {} 个使用者)",
        # 偏好(左列灯光控制模态参数 + 右列快捷键, 两列布局; "Camera Settings" 为摄像机
        # 详情折叠区标题, 与偏好无关)
        ("*", "Camera Settings"): "摄像机设置",
        ("*", "Hotkeys"): "快捷键",
        # 快捷键分组显示名(keymaps.py)
        ("*", "Camera Pie"): "摄像机饼菜单",
        ("*", "Light Pie"): "灯光饼菜单",
        # 与 ch_utils_tools 共用(对方仍引用): 目标侧各留一份, 两插件词典同名键互不冲突
        # ("Operator: Point" 随饼菜单改版在本插件已无引用, 由 ch_utils_tools 的词典覆盖)
        ("Operator", "Compositor"): "合成器编辑器",
        # ============================================================
        # 场景助手五面板(ui/panels/scene_panels.py + ui/lists/scene_lists.py +
        # operators/utils/{row,image,datablock,material,list}_ops.py + props.SceneHelperState)
        # ============================================================
        # 面板标题与选项菜单("Cameras/Materials/Lights/Images/Worlds"均为系统词条, 不入典)
        ("*", "Camera Options"): "摄像机选项",
        ("*", "Light Options"): "灯光选项",
        ("*", "Material Options"): "材质选项",
        ("*", "Image Options"): "图像选项",
        ("*", "World Options"): "世界环境选项",
        # 算子标签(Operator 上下文)
        ("Operator", "Set View"): "切换视角",
        ("Operator", "Disable in Viewport"): "在视图中禁用",
        ("Operator", "Batch Pass Index"): "批量通道索引",
        ("Operator", "Assign World"): "赋予世界",
        ("*", "Assign World"): "赋予世界",
        ("Operator", "Unlink World"): "解除世界关联",
        ("*", "Unlink World"): "解除世界关联",
        # "Add World" 未命中系统词条, 插件兜底; 名词与面板标题 "Worlds"→"世界环境" 对齐
        # "Pack/Unpack Image"/"Save All Modified"/"Replace Image" 为系统词条, 不入典
        ("Operator", "Add World"): "添加世界环境",
        ("Operator", "Reload All Images"): "重载全部图像",
        ("Operator", "Rename to File Name"): "按文件名重命名",
        ("Operator", "Merge Duplicate Images"): "合并重复图像",
        ("Operator", "Unlink Image"): "解除图像引用",
        # "Add Material"/"Add Collection" 均为系统词条(ctx=Operator), 不入典
        # 算子 tooltip(修饰键说明分行, 与源码逐字符一致)
        ("*", "Select this camera and look through it"): "选中该摄像机并切换到它的视角",
        (
            "*",
            "Toggle viewport visibility for this object\n+Ctrl: Show only this object among the objects of the same type (isolate), click again to restore\nLights with a controller: the controller empty follows this toggle",
        ): "切换该物体在视口中的可见性\n+Ctrl: 只显示该物体（隐藏其余同类，再点恢复）\n带控制器的灯光: 控制器空物体跟随本开关",
        (
            "*",
            "Toggle render exclusion for this object\n+Ctrl: Render only this object among the objects of the same type (isolate), click again to restore",
        ): "切换该物体是否被渲染排除\n+Ctrl: 只渲染该物体（其余同类排除渲染，再点恢复）",
        (
            "*",
            "Toggle viewport visibility for this collection\n+Ctrl: Show only this collection among the light collections (isolate), click again to restore",
        ): "切换该集合在视口中的可见性\n+Ctrl: 只显示该集合（隐藏其余灯光集合，再点恢复）",
        (
            "*",
            "Toggle render exclusion for this collection\n+Ctrl: Render only this collection among the light collections (isolate), click again to restore",
        ): "切换该集合是否被渲染排除\n+Ctrl: 只渲染该集合（其余灯光集合排除渲染，再点恢复）",
        ("*", "Set the pass index of all materials used in the scene in one go"): "一次性设置场景中全部材质的通道索引",
        ("*", "Use this world as the scene world"): "把该世界环境设为场景世界",
        ("*", "Unlink this world from the scene (keep the data-block)\n+Shift: Delete the world data-block directly"): "解除该世界与场景的关联(保留数据块)\n+Shift: 直接删除世界数据块",
        ("*", "World is not linked to the scene"): "该世界未关联到场景",
        ("*", "Delete the world data-block instead of only unlinking it"): "删除世界数据块, 而非仅解除关联",
        ("*", "Create a new world and use it as the scene world"): "新建一个世界环境并设为场景世界",
        ("*", "Pack this image into the blend file"): "把该图像打包进 blend 文件",
        ("*", "Open image file(s); newly imported entries are highlighted in the images list"): "打开图像文件, 载入后图像列表高亮新增项",
        ("*", "Select all objects whose materials use this image"): "选中材质里引用该图像的全部物体",
        ("*", "Unpack this image to disk"): "把该图像解包到磁盘",
        ("*", "Reload every image that references an external file"): "重载全部引用外部文件的图像",
        ("*", "Save every modified image that has a file path"): "保存全部已修改且有文件路径的图像",
        ("*", "Rename the image to the name of the file it references"): "把图像名改成它所引用的文件名",
        ("*", "Point image texture nodes at the original image when they use a duplicate such as name.001"): "把使用 name.001 这类重复图的图像纹理节点指回原图",
        ("*", "Replace every reference to the old image with another image"): "把对旧图像的全部引用换成另一张图像",
        ("*", "Clear every material node reference to this image (the data-block is kept)\n+Shift: Delete the image data-block directly"): "把材质图像节点里对该图像的引用置空（保留数据块）\n+Shift: 直接删除图像数据块",
        ("*", "Image references cleared: {}"): "已清空 {} 处图像引用",
        ("*", "No material nodes use this image"): "没有材质节点使用该图像",
        ("*", "Delete the image data-block instead of only clearing references"): "删除图像数据块而不只是清空引用",
        # 算子属性名与说明
        ("*", "Kind"): "种类",
        ("*", "Isolate among the same-type objects instead of toggling (set by +Ctrl)"): "在同类物体之间隔离而不是切换（由 +Ctrl 设置）",
        ("*", "Isolate among the light collections instead of toggling (set by +Ctrl)"): "在灯光集合之间隔离而不是切换（由 +Ctrl 设置）",
        ("*", "Value assigned to the first material"): "赋给第一个材质的起始值",
        ("*", "Value assigned to every material"): "赋给每个材质的固定值",
        ("*", "Skip Assigned"): "跳过已设置",
        ("*", "Leave materials with a non-zero pass index untouched"): "不改动通道索引非零的材质",
        # 批量通道索引对话框(operators/utils/material_ops.py 的 PassIndexBatch)
        # "Mode"/"Fixed"/"Start"/"Value" 为系统词条(已查 i18n_check_terms 命中), 不入典
        ("*", "Sequential"): "顺序",
        ("Operator", "Sequential"): "顺序",
        ("*", "Assign increasing values"): "分配递增的值",
        ("*", "Assign the same value to every material"): "给每个材质分配相同的值",
        ("*", "Keep Extension"): "保留扩展名",
        ("*", "Keep the file extension in the image name"): "在图像名中保留文件扩展名",
        ("*", "Partition"): "分隔符",
        ("*", "Character that separates the name from the numeric suffix"): "分隔名称与末尾数字后缀的字符",
        ("*", "Old Image"): "旧图像",
        ("*", "All Materials"): "全部材质",
        ("*", "Scan every material instead of the active material only"): "扫描全部材质, 而不是只扫描活动材质",
        ("*", "Create a new material and assign it to the active object"): "新建材质并赋给活动物体",
        # 选区同步 / 0 用户对象开关(选项菜单前三项)
        ("*", "Also list images that have no users (orphans and fake-user only)"): "同时列出没有任何使用者的图像(孤儿与仅假用户)",
        ("*", "Highlight the list item of the active object whenever the active object changes"): "活动物体变化时, 自动把列表高亮切到对应项",
        ("*", "No 3D view to align the camera to"): "没有可用于对齐摄像机的 3D 视图",
        # "Fake User"(Operator 与 * 两语境)均为系统词条, 不入典
        ("*", "Keep this data-block saved even when it has no users"): "即使没有使用者也保留该数据块",
        # 面板状态属性(名称与说明)
        ("*", "Show the lens column"): "显示焦距列",
        ("*", "Show the camera type column"): "显示摄像机类型列",
        ("*", "View Camera Name"): "视图摄像机名称",
        (
            "*",
            "Show or hide the names of all cameras in the 3D view (writes each camera's show_name flag, saved with the .blend; the toggle state itself is re-read on file load)",
        ): "显示或隐藏 3D 视图中所有摄像机的名称(写入各摄像机的 show_name 属性并随 .blend 保存; 开关本身不保存, 载入文件后按摄像机实况回读)",
        ("*", "Show the light color column"): "显示灯光颜色列",
        ("*", "Show the shadow toggle column"): "显示阴影开关列",
        ("*", "Show the pass index column"): "显示通道索引列",
        ("*", "Node Count"): "节点数",
        ("*", "Show the material node count column"): "显示材质节点数列",
        ("*", "Show the world color swatch"): "显示世界颜色色板",
        # 详情子面板标题与空态提示("Camera Settings"/"Light Settings" 已在前文偏好与饼菜单段登记)
        ("*", "No camera is active"): "没有活动摄像机",
        ("*", "No active light"): "没有活动灯光",
        ("*", "No active material"): "没有活动材质",
        ("*", "No surface shader"): "没有可编辑的表面着色器",
        ("*", "No objects use this image"): "没有物体使用该图像",
        # 报告消息
        ("*", "Camera not found"): "未找到摄像机",
        ("*", "No modified images to save"): "没有需要保存的修改图像",
        ("*", "Image not found"): "未找到图像",
        ("*", "No image selected"): "无选中图像",
        ("*", "empty separator"): "分隔符不能为空",
        ("*", "Material created without users"): "已新建材质, 但当前没有可持有材质的活动物体(材质暂无使用者)",
        ("*", "Linked material cannot be deleted"): "库链接材质不可删除",
        ("*", "Material is used by {} users, deleting it clears them"): "材质有 {} 个使用者, 删除会一并清空材质槽",
        ("*", "Linked data-block cannot be deleted"): "库链接数据块不可删除",
        ("*", "Data-block is used by {} users, deleting it clears them"): "数据块有 {} 个使用者, 删除会一并清空引用",
        ("*", "Turn off alphabetical sorting to move items manually"): "请先关闭字母排序, 再手动上移/下移",
        ("*", "Pass index set: {} materials"): "已设置 {} 个材质的通道索引",
        ("*", "Images reloaded: {}"): "已重载 {} 张图像",
        ("*", "Image references merged: {}"): "已合并 {} 处图像引用",
        ("*", "Image references replaced: {}"): "已替换 {} 处图像引用",
        ("*", "Rename failed: {}"): "重命名失败: {}",
        ("*", "Pack failed: {}"): "打包失败: {}",
        ("*", "Unpack failed: {}"): "解包失败: {}",
        ("*", "Reload failed: {}"): "重载失败: {}",
        ("Operator", "Relocate Image"): "重定位图像",
        ("*", "Open a file browser to relocate this image and load it from the new location"): "打开文件浏览器重定位该图像，并从新位置载入",
        ("*", "New path of the image file"): "图像文件的新路径",
        ("Operator", "Select Lights"): "选择灯光",
        ("*", "Select the lights whose IES nodes reference this file"): "选中 IES 节点引用了此文件的灯光",
        ("*", "No lights use this IES"): "没有灯光使用此 IES",
        ("*", "Unpacking writes to the original path and may overwrite it"): "解包会写回原始路径, 可能覆盖磁盘上的同名文件",
        ("*", "Reloading discards unsaved image edits"): "重载会丢弃图像中未保存的修改",
        # ============================================================
        # 灯光控制器 rig(operators/object/light_rig.py + keymaps LIGHT_RIG 组 +
        # props 的 rig 镜像属性 + scene_panels 的 rig 动作行与灯光方位折叠区)
        # ============================================================
        # 算子标签("Add Light"为系统词条 Operator 语境, 不入典)
        ("Operator", "Copy Light"): "复制灯光",
        ("*", "Copy Light"): "复制灯光",
        ("Operator", "Instance Copy"): "实例复制",
        ("*", "Instance Copy"): "实例复制",
        ("Operator", "Set Controller"): "设置控制器",
        ("*", "Set Controller"): "设置控制器",
        ("Operator", "Remove Controller"): "移除控制器",
        ("*", "Remove Controller"): "移除控制器",
        ("Operator", "Reset Parameters"): "重置参数",
        ("*", "Reset Parameters"): "重置参数",
        ("Operator", "Remove All Controllers"): "移除所有控制器",
        ("*", "Remove All Controllers"): "移除所有控制器",
        ("Operator", "Light Control"): "灯光控制",
        ("*", "Light Control"): "灯光控制",
        # 折叠区标题与属性名("Distance"为系统词条空语境, 不入典)
        ("*", "Light Rig"): "灯光方位",
        ("*", "Azimuth"): "方位角",
        ("*", "Elevation"): "高度角",
        ("*", "Self Rotation"): "自旋转",
        ("*", "No controller"): "无控制器",
        # 算子 tooltip(修饰键说明一律另起一行, 与源码逐字符一致)
        (
            "*",
            "Add a light rig with its controller at the active object (a non-light object is required)\n+Shift: Pick the light type from a popup menu and add a rig of that type (hold Ctrl or Alt along with Shift to land the controller at the 3D cursor or the world origin)\n+Ctrl: Land the controller at the 3D cursor\n+Alt: Land the controller at the world origin",
        ): "添加灯光rig, 控制器落在活动物体上(需要非灯光的活动物体)\n+Shift: 弹出菜单选择灯光类型并按该类型添加rig(同时按住Ctrl或Alt可把控制器落到3D游标或世界原点)\n+Ctrl: 控制器落在3D游标位置\n+Alt: 控制器落在世界原点",
        (
            "*",
            "Duplicate the active light with its controller empty (the light data-block is copied)\nLight pie menu: duplicate every selected light with a controller (batch)",
        ): "把活动灯光连同控制器整套复制(灯光数据块为独立副本)\n灯光饼菜单: 批量复制选中集中所有带控制器的灯光",
        (
            "*",
            "Duplicate the active light with its controller empty while sharing the light data-block (power and color edits affect every instance)\nLight pie menu: instance-copy every selected light with a controller (batch, sharing data)",
        ): "把活动灯光连同控制器整套复制, 但共享灯光数据块(改功率/颜色全部实例联动)\n灯光饼菜单: 批量实例复制选中集中所有带控制器的灯光(共享数据块)",
        (
            "*",
            "Attach a controller empty to the panel's active light without one, or move the existing controller to a new position and re-aim the light at it (the light keeps its world position; the self rotation resets to 0; the controller lands on the last selected object that is neither a light nor a light controller)\n+Ctrl: Place the controller at the 3D cursor\n+Alt: Place the controller at the world origin\nLight pie menu: batch — every selected light has its controller reset to the active object, or a new controller attached when it has none (the active object must not be a light or a light controller)",
        ): "给面板活跃灯光绑定控制器空物体(无控制器时), 或把已有控制器挪到新位置并重新瞄准(灯光保持世界位置不变, 自旋转归零; 控制器落在选中集最后一个非灯光且非灯光控制器的物体上)\n+Ctrl: 控制器落在3D游标位置\n+Alt: 控制器落在世界原点\n灯光饼菜单: 批量——选中集中所有灯光, 有控制器的重设到活动物体, 没有的新增控制器(活动物体不能是灯光或灯光控制器)",
        (
            "*",
            "Reset the rig parameters of the active light to their defaults (azimuth 0, elevation 45 degrees, distance back to the rig's initial distance recorded at creation, self rotation 0; rigs without the recorded initial distance fall back to the 5 m default)\nLight pie menu: reset every selected light with a controller (batch)",
        ): "把活动灯光方位区的四个参数恢复默认值(方位角0、高度角45°、距离回到创建时记录的初始距离、自旋转0; 未记录初始距离的旧灯光回退到默认5m)\n灯光饼菜单: 批量重置选中集中所有带控制器的灯光",
        (
            "*",
            "Remove the controller empty from the active light (the light keeps its world transform)\nLight pie menu: remove the controllers of every selected light with one (batch)",
        ): "移除活动灯光的控制器空物体(灯光保持世界变换不变)\n灯光饼菜单: 批量移除选中集中所有带控制器的灯光的控制器",
        (
            "*",
            "Remove the controller empty from every light in the current lights list (each light keeps its world position and its rotation is unlocked; linked or shared controller empties are kept, only the parent bindings are removed)",
        ): "移除当前灯光列表内全部灯光的控制器空物体(每盏灯保持世界位置并解锁旋转; 链接或共挂的控制器空体保留, 仅解除父级绑定)",
        (
            "*",
            "Adjust the light rig interactively\n+A/S/D/W: A is the base mode — mouse X/Y for azimuth / elevation; hold S (mouse X for brightness), D (mouse X for distance) or W (mouse X for self rotation), releasing the key returns to A\n+Shift: Precise adjustment (half the rate)\n+Ctrl: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the surface normal (leaves the adjustment mode; press A/S/D/W to resume)\n+Alt: Hold and move the mouse to snap the controller to surfaces and align its Y axis to the reflection line of the current view's virtual camera (the scene camera in a camera view; the clicked point becomes the highlight position)",
        ): "交互式调整灯光控制器rig\n+A/S/D/W: A 为常驻档——鼠标横向调方位角/纵向调高度角; 按住 S 横向移动调亮度, 按住 D 横向移动调距离, 按住 W 横向移动调自旋转(松开按键即回到 A 档)\n+Shift: 精确调整(半速)\n+Ctrl: 按住并移动鼠标, 控制器吸附到网格表面且Y轴对齐表面法向(同时退出调节档, 重按A/S/D/W恢复)\n+Alt: 按住并移动鼠标, 控制器吸附到网格表面且Y轴对齐当前视图虚拟摄像机指向表面点的矢量经表面反射的反射线(摄像机视图用场景摄像机; 点击处即高光位置)",
        (
            "*",
            "Select this object and highlight its list item\n+Shift: Toggle selection\n+Ctrl: Select the controller empty of the light (lights with a controller only)",
        ): "选中该物体并高亮该列表项\n+Shift: 切换选中/减选\n+Ctrl: 选中灯光的控制器空物体(仅带控制器的灯光)",
        # 报告消息与模态 header/状态栏模板
        ("*", "Select a non-light object to place the controller at"): "请先选中一个非灯光物体, 控制器将落在其位置",
        ("*", "The active light has no controller"): "活动灯光没有控制器",
        ("*", "Linked lights cannot be edited"): "库链接灯光不可编辑",
        ("*", "Controller added: {}"): "已添加控制器: {}",
        ("*", "Controller reset: {}"): "已重置控制器: {}",
        ("*", "Light rig parameters reset"): "灯光方位参数已重置",
        ("*", "Light rigs copied: {}"): "已复制 {} 套灯光 rig",
        ("*", "Light instances created: {}"): "已创建 {} 个灯光实例",
        ("*", "Light rig parameters reset: {}"): "已重置 {} 盏灯光的方位参数",
        ("*", "Lights deleted: {}"): "已删除 {} 盏灯光",
        ("*", "Controllers reset: {}, controllers added: {}"): "已重设 {} 个控制器, 已添加 {} 个控制器",
        ("*", "; linked lights skipped: {}"): "；跳过 {} 盏库链接",
        ("*", "; linked controllers skipped: {}"): "；跳过 {} 个链接控制器",
        ("*", "No lights with controllers in the selection"): "选中集里没有带控制器的灯光",
        ("*", "No lights in the selection"): "选中集里没有灯光",
        ("*", "No lights with controllers"): "没有带控制器的灯光",
        ("*", "Controllers removed: {}, bindings only removed: {}"): "已移除 {} 个控制器, {} 个仅解除绑定(链接或共挂)",
        ("*", "Controller removed"): "已移除控制器",
        ("*", "Linked controller kept, only the parent binding was removed"): "控制器是库链接数据块, 已保留, 仅解除父级绑定",
        ("*", "Controller has other children, kept as a regular empty"): "控制器还有其它子级, 已保留为普通空物体",
        ("*", "Light rig copied: {}"): "已复制灯光: {}",
        ("*", "Light instance created: {}"): "已创建灯光实例: {}",
        ("*", "This operator runs interactively in the 3D view"): "该算子需在3D视图中交互执行",
        ("*", "Azimuth: {}  Elevation: {}  Distance: {}  Brightness: {}  Self Rotation: {}"): "方位角: {}  高度角: {}  距离: {}  亮度: {}  自旋转: {}",
        ("*", "Linked controller empties cannot be edited"): "链接控制器空体不可编辑",
        # 灯光控制模态的偏好设置(preference.py 左列; 标题 Light Control 沿用前文词条)
        ("*", "Angle Sweep"): "旋转幅度",
        ("*", "Power Span"): "亮度幅度",
        ("*", "Distance Span"): "距离幅度",
        ("*", "Precise Factor"): "精确比率",
        ("*", "Rotation for azimuth / elevation / self rotation while the mouse crosses the full region width (modal L)"): "方位角/高度角/自旋转的区域归一幅度: 鼠标扫过整个区域宽度对应的旋转量",
        ("*", "Brightness change while the mouse crosses the full region width (modal L)"): "亮度的区域归一幅度: 鼠标扫过整个区域宽度对应的增减量",
        ("*", "Distance change while the mouse crosses the full region width (modal L)"): "距离的区域归一幅度: 鼠标扫过整个区域宽度对应的增减量",
        ("*", "Adjustment rate multiplier while Shift is held (modal L)"): "按住 Shift 时的调值速率倍率",
        # 轨迹预览参数(preference.py 左列 Light Control box 内; 总开关标签沿用 "Trajectory Preview")
        ("*", "Trajectory Preview"): "轨迹预览",
        ("*", "Azimuth Track Color"): "方位角轨迹颜色",
        ("*", "Elevation Track Color"): "高度角轨迹颜色",
        ("*", "Track Line Width"): "轨迹线宽度",
        ("*", "Reference Ticks"): "参考刻度",
        ("*", "Tick Interval"): "刻度间隔",
        ("*", "Tick Scale"): "刻度系数",
        ("*", "Track Dim"): "轨迹线暗淡",
        ("*", "Spoke Color"): "半径连线颜色",
        ("*", "Always in Front"): "始终显示在前",
        ("*", "Draw the trajectory preview (azimuth ring and elevation great circle) in the 3D view while adjusting (modal L, A and D modes)"): "调值(A/D 档)时在 3D 视图绘制轨迹预览(方位圆环与高度大圆)",
        ("*", "Color of the horizontal azimuth ring and the plain tick marks"): "水平方位圆环与普通刻度点的颜色",
        ("*", "Color of the elevation great circle"): "高度大圆的颜色",
        ("*", "Preview line width in pixels"): "预览线宽(像素)",
        ("*", "Draw tick dots on both tracks; the four axis ticks (0/90/180/270 degrees) use the X/Y/Z axis colors"): "在两条轨迹上绘制刻度圆点; 0/90/180/270 四个正轴刻度使用 X/Y/Z 轴线色",
        ("*", "Degrees between tick marks on the trajectory"): "轨迹上相邻刻度的间隔角度(度)",
        ("*", "Tick dot diameter relative to the trajectory line width; the four axis ticks are always 1.5 times the regular ticks"): "刻度圆点直径相对轨迹线宽的缩放系数; 四个正轴刻度恒为普通刻度的 1.5 倍",
        ("*", "Alpha of the trajectory lines at the point farthest from the light (the nearest end is always opaque)"): "轨迹线在距灯光最远端的不透明度(近端恒不透明)",
        ("*", "Color of the radius line from the controller to the light"): "控制器到灯光的半径连线颜色",
        ("*", "Draw the preview over the scene objects; turn off to let the geometry hide it"): "轨迹绘制在场景物体之上; 关闭后由场景几何遮挡",
        ("*", "Finish"): "完成",
        ("*", "Viewport Navigation"): "视口导航",
        ("*", "Azimuth/Elevation"): "方位/高度",
        ("*", "Precise"): "精确",
        ("*", "Snap Normal"): "吸附法向",
        ("*", "Snap Reflect"): "吸附反射",
        # 算子属性说明(名称 Shift/Ctrl/Alt 为隐藏项不显示, 不入典)
        ("*", "Operate on the lights filtered from the selection (set by the light pie menu)"): "对选中集筛选出的灯光批量起作用(由灯光饼菜单设置)",
        ("*", "Open the light type menu (set by +Shift)"): "弹出灯光类型选择菜单(由+Shift设置)",
        ("*", "Place the controller at the 3D cursor (set by +Ctrl)"): "控制器落在3D游标位置(由+Ctrl设置)",
        ("*", "Place the controller at the world origin (set by +Alt)"): "控制器落在世界原点(由+Alt设置)",
        ("*", "Select the light's controller empty instead of the light (set by +Ctrl)"): "改为选中灯光的控制器空物体(由+Ctrl设置)",
        ("*", "Rotation of the controller empty around its Z axis (edits the controller transform, not undoable)"): "控制器空物体绕其Z轴的旋转(直接改写控制器变换, 不进撤销栈)",
        ("*", "Rotation of the controller empty around its X axis (edits the controller transform, not undoable)"): "控制器空物体绕其X轴的旋转(直接改写控制器变换, 不进撤销栈)",
        ("*", "Distance from the light to its controller (edits the light's local location, not undoable)"): "灯光到控制器的距离(直接改写灯光局部位置, 不进撤销栈)",
        (
            "*",
            "Self rotation of the light around its local Y axis (edits only the Y component, not undoable; resetting to 0 also restores the local rotation X -90 and Z 0)",
        ): "灯光绕自身局部Y轴的自旋转(只改写Y分量, 不进撤销栈; 恢复默认值0时同时把局部旋转的X恢复为-90°、Z恢复为0°)",
        ("*", "(removed)"): "(已移除)",
        # 属性描述(属性参数规范化轮: subtype/单位/HIDDEN 修正)
        ("*", "Current name of the image"): "图像数据块的当前名称",
        ("*", "How the pass indices are assigned"): "通道索引的分配方式",
        ("*", "Move the item down instead of up"): "向下移动该项而非向上",
        ("*", "Name of the collection"): "集合名称",
        ("*", "Name of the datablock"): "数据块名称",
        ("*", "Name of the image datablock"): "图像数据块名称",
        ("*", "Name of the object"): "物体名称",
        ("*", "Name of the world"): "世界名称",
        ("*", "New name for the image"): "图像的新名称",
        ("*", "Toggle to the next camera in the list instead of the previous one"): "切换到列表中的下一台摄像机而非上一台",
        ("*", "Type of the datablock"): "数据块类型",
        ("*", "Which asset list the operation applies to"): "该操作作用于哪个资源列表",
        # ============================================================
        # 灯光&阴影链接子面板(operators/object/light_linking.py +
        # scene_panels 的链接折叠区 + props 的模式枚举)
        # ============================================================
        # 折叠区标题与模式枚举("Light Linking"/"Shadow Linking" 条目名与 "No active
        # object" 占位均为系统词条, 不入典)
        ("*", "Light & Shadow Linking"): "灯光&阴影链接",
        ("*", "Collection View"): "集合视角",
        ("*", "Show the active collection's link states instead of the active object's"): "显示活动集合(而非活动物体)在各灯链接集合中的链接状态",
        ("*", "Please switch the render engine to Cycles or EEVEE"): "请切换至Cycles或EEVEE渲染器",
        ("*", "Object Linking"): "物体链接",
        ("*", "Edit which objects receive light from the active light of the Lights panel"): "编辑面板活跃灯光的受光对象",
        ("*", "Edit which objects cast shadows for the active light of the Lights panel"): "编辑面板活跃灯光的阴影遮挡对象",
        ("*", "Look up which lights light-link or shadow-link the active object"): "反查活动物体被哪些灯灯光/阴影链接",
        # 算子标签与按钮文案(静态审计要求 ctx=Operator 覆盖)
        ("Operator", "Select Receivers"): "选中接收者",
        ("*", "Select Receivers"): "选中接收者",
        ("Operator", "Add Selected Objects"): "添加选中物体",
        ("*", "Add Selected Objects"): "添加选中物体",
        ("Operator", "Set Link State"): "设置链接状态",
        ("*", "Set Link State"): "设置链接状态",
        ("Operator", "Remove from Linking"): "从链接移除",
        ("*", "Remove from Linking"): "从链接移除",
        ("Operator", "Focus Light"): "定位灯光",
        ("*", "Focus Light"): "定位灯光",
        # 算子 tooltip
        ("*", "Create a new collection and assign it as the light/shadow linking collection of the active light of the Lights panel"): "新建集合并指派为灯光面板活跃灯光的灯光/阴影链接集合",
        (
            "*",
            "Link the selected objects as included members of the active light's light/shadow linking collection\n+Shift: Add the current view layer's active collection instead",
        ): "把选中物体以包含状态加入活跃灯光的灯光/阴影链接集合\n+Shift: 改为加入当前视图层的活动集合",
        ("*", "Toggle between included and excluded, adding the target to the light's linking collection when it is not a member yet"): "在包含与排除间切换, 目标尚未加入时先将其加入该灯的链接集合",
        (
            "*",
            "Remove this member from the light's linking collection\nObject list rows: removes both the light link and the shadow link entries when direct",
        ): "把该成员从灯光的链接集合移除\n物体链接行: 同时移除灯光与阴影两处的直接项",
        ("*", "Select all objects that receive light from (or cast shadows for) the active light of the Lights panel in the 3D viewport"): "在3D视口中选中灯光面板活跃灯光的全部接收者(或阴影遮挡者)",
        ("*", "Highlight this light in the Lights panel list"): "在灯光面板列表中高亮该灯光",
        (
            "*",
            "Copy the shared light/shadow linking collection so this light gets its own (members and their include/exclude states are preserved); the row number is how many lights share the collection",
        ): "复制被共享的灯光/阴影链接集合使该灯独享(成员与包含/排除状态随副本保留); 行内数字即共享灯数",
        # 偏好面板的链接预览三色(标签经 prop text= 查默认语境)
        ("*", "Light Link Color"): "灯光链接颜色",
        ("*", "Color of the light linking preview lines and bounding box wireframes for included members"): "灯光链接预览中已激活成员的线与线框颜色",
        ("*", "Shadow Link Color"): "阴影链接颜色",
        ("*", "Color of the shadow linking preview lines and bounding box wireframes for included members"): "阴影链接预览中已激活成员的线与线框颜色",
        ("*", "Inactive Link Color"): "未激活链接颜色",
        ("*", "Color for preview lines and wireframes of members that are in the linking collection but currently excluded"): "链接集合中未激活(被排除)成员的线与线框颜色",
        ("*", "Preview Line Width"): "预览线宽度",
        ("*", "Line width of the light linking preview lines and bounding box wireframes"): "灯光链接预览的线与边界盒线框宽度",
        # 灯光饼菜单同步与预览(operators/object/light_linking.py 的同步/预览算子族)
        ("Operator", "Sync Light Linking"): "同步灯光链接",
        ("*", "Sync Light Linking"): "同步灯光链接",
        (
            "*",
            "Share the active light's light linking collection with every selected light (the collection data-block is shared, so edits affect all of them)",
        ): "把活动灯的灯光链接集合数据块共享给选中集里的每一盏灯(共享数据块, 之后任一灯侧的编辑全体生效)",
        ("Operator", "Sync Shadow Linking"): "同步阴影链接",
        ("*", "Sync Shadow Linking"): "同步阴影链接",
        (
            "*",
            "Share the active light's shadow linking collection with every selected light (the collection data-block is shared, so edits affect all of them)",
        ): "把活动灯的阴影链接集合数据块共享给选中集里的每一盏灯(共享数据块, 之后任一灯侧的编辑全体生效)",
        ("Operator", "Light Link Objects Preview"): "灯光链接物体预览",
        ("*", "Light Link Objects Preview"): "灯光链接物体预览",
        (
            "*",
            "Preview the light linking relations of the active light: lines run from the light to the top center of every linked object's bounding box, and the boxes draw as wireframes. LMB or Enter closes the preview",
        ): "预览活动灯的灯光链接关系: 从灯引线到每个被链接物体边界盒顶面中心, 物体画边界盒线框. 左键或 Enter 关闭预览",
        ("Operator", "Shadow Link Objects Preview"): "阴影链接物体预览",
        ("*", "Shadow Link Objects Preview"): "阴影链接物体预览",
        (
            "*",
            "Preview the shadow linking relations of the active light: lines run from the light to the top center of every shadow-linked object's bounding box, and the boxes draw as wireframes. LMB or Enter closes the preview",
        ): "预览活动灯的阴影链接关系: 从灯引线到每个被阴影链接物体边界盒顶面中心, 物体画边界盒线框. 左键或 Enter 关闭预览",
        ("Operator", "Object Light Link Preview"): "物体灯光链接预览",
        ("*", "Object Light Link Preview"): "物体灯光链接预览",
        (
            "*",
            "Preview which lights light-link the active object: lines run from the object's bounding box center to each of those lights. LMB or Enter closes the preview",
        ): "预览灯光链接活动物体的灯: 从物体边界盒中心引线到每盏这样的灯. 左键或 Enter 关闭预览",
        ("Operator", "Object Shadow Link Preview"): "物体阴影链接预览",
        ("*", "Object Shadow Link Preview"): "物体阴影链接预览",
        (
            "*",
            "Preview which lights shadow-link the active object: lines run from the object's bounding box center to each of those lights. LMB or Enter closes the preview",
        ): "预览阴影链接活动物体的灯: 从物体边界盒中心引线到每盏这样的灯. 左键或 Enter 关闭预览",
        # 报告消息
        ("*", "The light has no linking collection"): "该灯光没有链接集合",
        ("*", "No selected objects to link"): "没有可链接的选中物体",
        ("*", "Selected {} objects"): "已选中 {} 个物体",
        ("*", "Light linking collection '{}' is used by a scene"): "灯光链接集合'{}'被场景占用",
        ("*", "Not a direct member of the linking collection"): "不是链接集合的直接成员",
        ("*", "Cannot link a collection into itself"): "集合不能链接到其自身",
        ("*", "No linking relation to preview"): "没有可预览的链接关系",
        ("*", "Synced {} lights"): "已同步 {} 盏灯",
        ("*", "Linked {} objects"): "已链接 {} 个物体",
        ("*", "Linked: {}"): "已链接: {}",
        ("*", "Linking collection is not shared"): "链接集合没有被共享",
        ("*", "Made single user: {}"): "已独立化: {}",
        ("*", "The light already has a linking collection"): "该灯已有链接集合",
        ("*", "No such light"): "找不到该灯光",
    }
}

dictionary = preprocess_dictionary(dictionary)
