"""
列表顺序状态模块

列表排序值以自定义属性挂在数据块上(随 blend 持久, 跨机同步), 键名由调用方指定;
collect 按 order_key 排序: 有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序).

提供以下功能:
- get_order / set_order / order_key: 读写单个数据块的顺序值与排序键
- materialize_orders: 把当前显示序固化为 0..N-1
- swap_orders: 交换相邻两项的顺序值
- assign_order_at_end: 新建项默认追加到列表末尾(取物化后的最大值 +1)

供 ch_scene_helper(六个资源列表, 键 "ch_scene_order")与 ch_ai_assistant
(脚本/图像列表, 键 "ch_ai_order")共用. 两插件的键名各自沿用既有 .blend 文件里
已写入的值, 故 order_prop 必须由调用方传入, 不能统一改名.
"""

# 默认顺序值键名(ch_scene_helper 沿用自 ch_utils_tools 的历史键)
ORDER_PROP = "ch_scene_order"


def get_order(datablock, order_prop: str = ORDER_PROP) -> int | None:
    """取数据块的列表顺序值, 未设置或非整数返回 None

    Args:
        datablock: 物体或材质等 ID 数据块
        order_prop: 顺序值自定义属性名

    Returns:
        顺序值, 未设置返回 None
    """
    value = datablock.get(order_prop)
    return value if isinstance(value, int) else None


def set_order(datablock, value: int, order_prop: str = ORDER_PROP) -> None:
    """写入数据块的列表顺序值"""
    datablock[order_prop] = value


def order_key(datablock, order_prop: str = ORDER_PROP) -> tuple:
    """排序键: 有顺序值在前按值排, 无顺序值在后按名称排(默认即名称序)

    Args:
        datablock: 物体或材质等 ID 数据块
        order_prop: 顺序值自定义属性名

    Returns:
        可直接用于 sorted(key=...) 的元组
    """
    value = get_order(datablock, order_prop)
    if value is None:
        return (1, 0, datablock.name)
    return (0, value, datablock.name)


def materialize_orders(blocks: list, order_prop: str = ORDER_PROP) -> None:
    """按给定顺序给全部数据块写入 0..N-1 的顺序值(忽略已有值)

    把"当前显示序"固化为持久顺序: 移动条目后调用, 保证顺序值与快照序一致.
    只补缺失值不安全: 既有值稀疏时(删过条目/混有历史值)会给缺失项写入与既有项
    冲突的值, 交换相邻两项会连带重排无关条目.

    Args:
        blocks: 按目标顺序排列的数据块列表
        order_prop: 顺序值自定义属性名
    """
    for idx, block in enumerate(blocks):
        set_order(block, idx, order_prop)


def swap_orders(first, second, order_prop: str = ORDER_PROP) -> None:
    """交换两个数据块的顺序值(调用方须先 materialize_orders 保证双方都有值)"""
    first_value, second_value = get_order(first, order_prop), get_order(second, order_prop)
    set_order(first, second_value, order_prop)
    set_order(second, first_value, order_prop)


def assign_order_at_end(datablock, blocks: list, order_prop: str = ORDER_PROP) -> None:
    """把数据块追加到 blocks 当前显示序的末尾(新建项默认落位)

    无顺序值的新项在 order_key 里会落进"无顺序值组"按名称插入——不赋值时新建项
    不在列表末尾; 先按当前显示序全量物化(历史无值项一并固化), 再取最大值 +1 写入,
    此后新建项恒追加在创建序末尾. blocks 须为该列表的全量成员(含 datablock 自身,
    库链接项已由调用方排除——链接 ID 不可写自定义属性).
    """
    materialize_orders(sorted(blocks, key=lambda block: order_key(block, order_prop)), order_prop)
    end = max((get_order(block, order_prop) for block in blocks if get_order(block, order_prop) is not None), default=-1)
    set_order(datablock, end + 1, order_prop)
