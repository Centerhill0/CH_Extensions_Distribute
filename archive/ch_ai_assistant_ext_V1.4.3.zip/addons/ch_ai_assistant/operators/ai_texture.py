"""
AI 图像生成(纹理贴图 / 图像)操作模块

提示词送 AI 图像服务文生图, 纹理贴图模式下产物无缝化处理(可选)后加载为贴图打包, 不进材质.
生成模式为"图像"时按提示词原样生成任意图像(不加贴图引导, 不做无缝化).
"修改图像"以列表高亮图像为参考图做参考图生图, 原图保留(改名加 _bak 后缀).
加载了参考图且"使用参考图"开启时, 生成走参考图生图(职责声明拼进提示词),
未加载或关闭时走文生图——两种路径共用同一请求管线与同一个模型(面板唯一模型).

图像生成器三个模式共用一套列表、一个请求作用域(scope 'image')与一份参考图列表;
本模块只放图像侧(纹理贴图 / 图像)的业务算子, 效果图模式见 ai_render.

操作流程:
1. 描述来源: 纹理长文描述块(AI_Texture_Prompt.txt)优先, 为空时取单行输入框
2. invoke: 校验提示词与图像服务配置, 按生成模式组装提示词(无缝平铺引导可选,
   参考图职责声明可选), 自定义分辨率按服务商/模型约束修正后,
   按张数逐张串行请求进入模态等待; 随机种 0 时本地抽取实际种子并回填面板(可复现, 仅支持 seed 的服务商)
3. modal: 计时器轮询线程结果并刷新面板等待进度, Esc 放弃等待(底层请求不中断, 结果丢弃)
4. 响应处理: 纹理贴图且 Seamless 开启时字节先做本地边缘羽化混合无缝化 -> 逐张加载为
   图像数据块(打包) -> 按偏好目录另存 -> 产物置顶到图像列表并按面板开关聚焦图像编辑器

支持的选项:
- Texture Map / Image: 生成模式, 命名前缀随模式区分(AI Tex / AI Bmp)
- Seamless: 提示词追加强调版无缝平铺引导 + 产物本地边缘羽化混合保证可平铺(默认开, 仅纹理贴图模式)
- Reference Images: 加载的外部参考图(逐张描述, 三模式共用一份列表), 开启"使用参考图"后随生成发送
- Negative Prompt: 负向提示词(仅百炼 Qwen-Image 支持, 其余服务商不下发)
- Size/Width/Height: 尺寸预设与自定义宽高(像素), 按服务商支持区间自动修正
- Count: 一次生成的张数(1-5), 逐张串行请求, 每张单独计费, 中途失败即停止
- Vary Batch: 张数>1 时每张换一个宽高比变体与递增随机种, 一次产出多种构图(不支持 seed 的服务商只有比率变体)

另含两个列表共用与本面板私有的操作器:
- SaveImage / SaveAllImages: 目标列表图像另存为 PNG(主列表与通道预览共用, 按 target 区分)
- OpenImageEditor: 在图像编辑器中查看目标列表高亮图像(已有编辑器复用,
  没有则 wm.window_new 弹单区域窗改型挂图)
- PreviewTexturePrompt: 把生成将实际发送的完整提示词写入文本块(供核对, 面板按钮)
- LoadStyleImage / RemoveStyleImage / ClearStyleDescription: 参考图引用维护
  (定义在 style_refs, 三模式共用一份列表)
"""

import os

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Context, Event, Operator

from ....common.i18n.i18n import iface, report
from ..handlers import activate_image
from ..items import image_list_target_items
from ..preference import get_prefs
from ..utils import (
    AI_IMAGE_PREFIX,
    AI_TEXTURE_FINAL_PROMPT_TEXT_NAME,
    AI_TEXTURE_PREFIX,
    AI_TEXTURE_PROMPT_TEXT_NAME,
    ai_image_name,
    ai_texture_name,
    api_error,
    build_texture_prompt,
    describe_error,
    format_size,
    focus_image_editors,
    focus_text_editors,
    image_to_scaled_png_bytes,
    load_image_from_bytes,
    make_seamless,
    prompt_stem,
    resolve_ref_limits,
    sanitize_image_file_name,
    unique_ai_name,
    write_text_block,
)
from .ai_generate import (
    AiRequestMixin,
    report_text_focus,
    resolve_prompt,
)
from .image_common import (
    ImageRequestArgs,
    batch_image_worker,
    batch_request_specs,
    check_image_service,
    collect_ref_entries,
    effective_negative_prompt,
    effective_seed,
    fail_request,
    highlighted_image,
    image_timeout_value,
    is_modifiable_image,
    land_generated_images,
    modify_image_worker,
    prune_image_backups,
    report_image_focus,
    resolve_and_notify_size,
    resolve_image_list_state,
    resolve_image_model,
    resolve_image_service,
)


def image_side_size(state) -> tuple:
    """图像侧输出宽高: 纹理贴图读 tex_*, 图像模式读 image_*(两套字段各自记忆互不覆盖)"""
    return (state.tex_width, state.tex_height) if state.mode == 'TEXTURE' else (state.image_width, state.image_height)


def collect_image_refs(state) -> list:
    """收集生效的参考图条目("使用参考图"关闭时不发送; 三模式共用同一份列表)"""
    return collect_ref_entries(state, "use_ref_images", "ref_images")


def resolve_image_prompt(state, prompt: str) -> tuple:
    """按生成模式/无缝/参考图组装图像侧实际发送的完整提示词, 返回 (完整提示词, 参考图条目列表)

    GenerateTexture 与 PreviewTexturePrompt 共用(保证预览即发送).
    """
    texture_mode = state.mode == 'TEXTURE'
    seamless = texture_mode and state.use_seamless
    refs = collect_image_refs(state)
    ref_descriptions = [ref.description for ref in refs]
    full_prompt = build_texture_prompt(prompt, seamless, ref_descriptions, kind='texture' if texture_mode else 'image')
    return full_prompt, refs


class GenerateTexture(Operator, AiRequestMixin):
    """
    生成纹理操作器

    功能: 把描述发给 AI 图像服务, 纹理贴图开关开启时产物做无缝化处理(可选),
    关闭时按提示词原样生成任意图像; 结果加载为贴图打包, 不创建材质不赋物体;
    需要使用时在着色器中新建图像纹理节点选择该贴图.

    要求: 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.generate_texture"
    bl_label = "Generate Texture"
    bl_description = "Ask the AI image service to generate an image from the prompt and pack it into the blend file, " "the Generation Count option generates several images with one click (each image is billed separately)"
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Generating texture... (Esc to cancel)"
    # 三模式共用 image 作用域: 任一时刻只有一个模式在跑, 切模式时等待进度与中断不消失
    status_scope = 'image'

    def invoke(self, context: Context, event: Event):
        state = context.window_manager.ch_ai_image_state
        if state.mode == 'RENDER':
            # 防御: 效果图模式由 GenerateRender 处理, 本算子的按钮不绘制
            self.report({'WARNING'}, "Switch to the texture or image mode first")
            return {'CANCELLED'}
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, state.tex_prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the texture in the prompt field first")
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_image_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}

        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        # 生成模式与无缝开关随请求一并快照: 等待期间被改动时本单请求行为仍一致;
        # 命名前缀随模式区分(纹理贴图 "AI Tex" / 图像 "AI Bmp"), 等待文案同理
        self._texture_mode = state.mode == 'TEXTURE'
        self._seamless = self._texture_mode and state.use_seamless
        self._namer = ai_texture_name if self._texture_mode else ai_image_name
        self._prefix = AI_TEXTURE_PREFIX if self._texture_mode else AI_IMAGE_PREFIX
        self.status_text = "Generating texture... (Esc to cancel)" if self._texture_mode else "Generating image... (Esc to cancel)"
        # 提示词组装与预览算子共用同一函数(保证预览即发送): 无缝引导 + 参考图职责声明
        full_prompt, refs = resolve_image_prompt(state, prompt)
        # 模型: 面板唯一可见下拉(panel_model) → 偏好 image_model_t2i, 解析口径单一
        # 参考图字节主线程编码(超长边按服务商上限缩放副本, 原图零改动), 单张失败跳过并提醒
        model = resolve_image_model(sstate, prefs)
        ref_images = []
        _count, limit_edge = resolve_ref_limits(provider, prefs)
        for ref in refs:
            data, enc_err = image_to_scaled_png_bytes(ref.image, limit_edge)
            if enc_err is not None:
                self.report({'WARNING'}, describe_error(enc_err))
                continue
            ref_images.append(data)
        if refs and not ref_images:
            self.report({'WARNING'}, "The reference images are unavailable, generating without them")
        # 随机种 0 时本地抽取实际种子并回填面板(可复现, 仅支持 seed 的服务商); 批量规格表从基准递增
        seed = effective_seed(state, provider)
        # 自定义分辨率按服务商/模型支持的区间修正(CUSTOM 原样下发, 服务端裁决)
        out_w, out_h = resolve_and_notify_size(self, provider, model, *image_side_size(state))
        # 负向提示词仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        neg_prompt = effective_negative_prompt(state, provider)
        # 逐张请求规格表: 批量多变体开启且张数>1 时每张换宽高比变体, 种子从基准递增
        specs = batch_request_specs(provider, model, out_w, out_h, state.count, seed, state.batch_variants)
        # 命名短名随请求一并快照: 等待期间描述被改动时产物名仍与请求内容一致
        self._stem = prompt_stem(prompt)
        self._prompt = prompt
        args = (ImageRequestArgs(base_url, api_key, image_timeout_value(prefs), provider), model, full_prompt, specs, neg_prompt, ref_images or None)
        if not self._start_request(context, batch_image_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, results, err):
        """逐张落地产物: results 为成功图片字节列表, err 为首个请求错误(部分成功时仅告警)"""
        return land_generated_images(
            self,
            context,
            results,
            err,
            # 命名短名随请求快照, 等待期间描述被改动不影响本单产物名
            name_for=lambda: unique_ai_name(self._namer(self._stem)),
            prefix=self._prefix,
            prompt=self._prompt,
            seamless=self._seamless,
            report_each=self._report_created,
        )

    def _report_created(self, op, name: str) -> None:
        """逐张成功提示: 名称随生成模式切换(纹理贴图 / 图像)"""
        created_msg = "Texture '{}' created" if self._texture_mode else "Image '{}' created"
        op.report({'INFO'}, report(created_msg).format(name))


class ModifyImage(Operator, AiRequestMixin):
    """
    修改图像操作器

    功能: 以纹理列表当前高亮的图像为参考图, 连同描述发给 AI 图像服务参考图生图;
    原图不删除, 改名追加 "_bak" 后缀(前缀不变, 仍留在列表中作为备份),
    新图继承原图原名, 置顶并按面板开关聚焦图像编辑器.

    要求: 列表中有高亮图像; 图像服务偏好已配置.
    """

    bl_idname = "ch_ai.modify_image"
    bl_label = "Modify Image"
    bl_description = (
        "Edit the highlighted image with the AI image model based on the prompt, "
        "the original is kept and renamed with a '_bak' suffix; "
        "affected settings: prompt, generation mode, seamless, negative prompt, "
        "resolution, seed and the panel's Model override; always a single image"
    )
    bl_options = {'REGISTER', 'UNDO'}

    status_text = "Modifying image... (Esc to cancel)"
    status_scope = 'image'

    @classmethod
    def poll(cls, context: Context):
        # 三模式共用一个列表: 高亮项必须是图像侧产物(AI Tex / AI Bmp), 否则按钮置灰
        state = context.window_manager.ch_ai_image_state
        if not 0 <= state.images_active_index < len(state.images):
            return
        return is_modifiable_image(state.images[state.images_active_index].name)

    def invoke(self, context: Context, event: Event):
        state = context.window_manager.ch_ai_image_state
        if state.mode == 'RENDER':
            self.report({'WARNING'}, "Switch to the texture or image mode first")
            return {'CANCELLED'}
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, state.tex_prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the change in the prompt field first")
            return {'CANCELLED'}
        source = highlighted_image(self, state)
        if source is None:
            return {'CANCELLED'}
        if not is_modifiable_image(source.name):
            self.report({'WARNING'}, "Only generated textures or images can be modified")
            return {'CANCELLED'}
        sstate = context.window_manager.ch_ai_image_service
        if not check_image_service(self, sstate):
            return {'CANCELLED'}
        prefs = get_prefs()
        provider, base_url, api_key = resolve_image_service(sstate, prefs)
        # 编辑源图按参考图上限缩放上传(全尺寸 4K/8K 会超服务端限制并放大内存/流量);
        # 编码在主线程完成(RNA 属性不支持跨线程读取)
        _count, limit_edge = resolve_ref_limits(provider, prefs)
        source_bytes, err = image_to_scaled_png_bytes(source, limit_edge)
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}

        # 模型与生成请求同源(面板唯一可见下拉)
        model = resolve_image_model(sstate, prefs)
        # 生成模式/无缝/等待文案随请求一并快照
        self._texture_mode = state.mode == 'TEXTURE'
        self._seamless = self._texture_mode and state.use_seamless
        self._namer = ai_texture_name if self._texture_mode else ai_image_name
        full_prompt = build_texture_prompt(prompt, self._seamless) if self._texture_mode else prompt.strip()
        out_w, out_h = resolve_and_notify_size(self, provider, model, *image_side_size(state))
        size = format_size(provider, out_w, out_h)
        # 负向提示词仅支持的服务商(如百炼 Qwen-Image)下发, 其余服务商不下发
        neg_prompt = effective_negative_prompt(state, provider)
        self._source_name = source.name
        self._stem = prompt_stem(prompt)
        args = (ImageRequestArgs(base_url, api_key, image_timeout_value(prefs), provider), model, full_prompt, [source_bytes], size, effective_seed(state, provider), neg_prompt)
        if not self._start_request(context, modify_image_worker, *args):
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def _on_response(self, context: Context, image_bytes, err):
        if err is not None:
            return fail_request(self, context, self.bl_label, err)
        if self._seamless:
            # 已计费的生成结果不能因本地后处理失败而丢弃: 失败时沿用原图并提示
            seamless_bytes, seamless_err = make_seamless(image_bytes)
            if seamless_err is not None:
                self.report({'WARNING'}, describe_error(seamless_err))
            else:
                image_bytes = seamless_bytes
        # 原图保留: 改名追加 _bak 后缀(前缀不变仍在列表; 重名由 Blender 自动加序号),
        # 随后按偏好上限清理更早的备份(仅保留最新若干份)
        source = bpy.data.images.get(self._source_name)
        if source is not None:
            source.name = f"{self._source_name}_bak"
            prune_image_backups(self, self._source_name, source.name)
        else:
            self.report({'INFO'}, report("The source image was deleted while waiting"))
        # 新图继承原图原名(源图缺失时回落提示词短名), 前缀必然保留在对应列表内
        base_name = self._source_name if source is not None else self._namer(self._stem)
        image, img_err = load_image_from_bytes(image_bytes, unique_ai_name(base_name))
        if img_err is not None:
            # 加载失败(服务端坏字节): 把源图名改回去, 保持"修改失败 = 现状不变"——
            # 否则源图留在 "_bak" 名下, 重试时工作名永久漂移一格且每次失败消耗一个备份名额
            if source is not None:
                source.name = self._source_name
            self.report({'ERROR'}, describe_error(img_err))
            return {'CANCELLED'}
        focused = activate_image(context, context.window_manager.ch_ai_image_state, image.name, top=True)
        report_image_focus(self, focused)
        created_msg = "Texture '{}' created" if self._texture_mode else "Image '{}' created"
        self.report({'INFO'}, report(created_msg).format(image.name))
        return {'FINISHED'}


class PreviewTexturePrompt(Operator):
    """
    完整提示词操作器

    功能: 按生成纹理/图像的组装口径(生成模式口吻 + 无缝引导 + 参考图职责声明),
    把实际会发送的完整提示词写入 AI_Texture_Final_Prompt.txt 并聚焦文本编辑器;
    与 GenerateTexture 逐字一致(同一组装函数), 供核对发送内容.
    """

    bl_idname = "ch_ai.preview_texture_prompt"
    bl_label = "Full Prompt"
    bl_description = "Show the exact prompt that Generate Texture will send, assembled with the " "seamless guidance and reference roles, in the text editor"
    bl_options = {'REGISTER'}

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_image_state
        prompt = resolve_prompt(AI_TEXTURE_PROMPT_TEXT_NAME, state.tex_prompt)
        if not prompt:
            self.report({'WARNING'}, "Describe the texture in the prompt field first")
            return {'CANCELLED'}
        full_prompt, refs = resolve_image_prompt(state, prompt)
        mode = "Texture Map" if state.mode == 'TEXTURE' else "Image"
        # 头部与实际发送同源: 无缝只在纹理贴图模式生效(resolve_image_prompt 的 texture_mode and 开关),
        # 直接读开关会让 IMAGE 模式残留的 True 谎报 "seamless on"
        seamless_effective = state.mode == 'TEXTURE' and state.use_seamless
        header = iface("Texture & Image final prompt (verbatim): mode {}, seamless {}, {} reference image(s)").format(mode, "on" if seamless_effective else "off", len(refs))
        ref_names = ", ".join(ref.image.name for ref in refs) or "-"
        text, _err = write_text_block(AI_TEXTURE_FINAL_PROMPT_TEXT_NAME, header + "\nReferences: " + ref_names + "\n\n" + full_prompt + "\n")
        focused, _ = focus_text_editors(context, text)
        report_text_focus(self, focused)
        return {'FINISHED'}


def _save_image_to_path(image, path: str) -> tuple:
    """把图像数据块按用户选择的路径存为 PNG, 返回 (文件路径, 错误信息, 是否避让改名)

    与 save_image_file 的区别: 文件名取用户在文件浏览器里填的名字(选目录时用数据块名).
    目标位置已有同名文件时不覆盖, 自动追加递增序号(-1, -2, ...)另存.
    """
    directory, filename = os.path.split(path)
    if not filename:
        filename = sanitize_image_file_name(image.name)
    if not filename.lower().endswith(".png"):
        filename += ".png"
    path = os.path.join(directory, filename)
    renamed = os.path.exists(path)
    if renamed:
        base, ext = os.path.splitext(path)
        num = 1
        while os.path.exists(path):
            path = f"{base}-{num}{ext}"
            num += 1
    try:
        os.makedirs(directory, exist_ok=True)
        image.filepath_raw = path
        image.file_format = 'PNG'
        image.save()
    except (OSError, RuntimeError) as e:
        return None, api_error("Failed to save image", e), False
    return path, None, renamed


# 保存操作器的目标条目见 items.image_list_target_items(与 DeleteImage 共用一份声明)


def _image_list_state(context: Context, target: str):
    """按目标取 (状态属性组, 集合属性名, 高亮索引属性名)

    主图像列表(三模式共用)用 images/images_active_index; 通道预览迷你列表
    用 pass_images/pass_images_active_index(同一状态属性组上的另一个快照集合).
    映射表单一来源见 image_common._IMAGE_LIST_STATES.
    """
    return resolve_image_list_state(context, target)


class SaveImage(Operator):
    """
    保存图像操作器

    功能: 把图像列表当前高亮的图像另存为 PNG 文件(弹出文件浏览器选择保存位置,
    默认目录取偏好设置的图像保存目录); 列表为空时不可用; 同名不覆盖, 自动追加序号另存.

    支持的目标:
    - IMAGE: 主图像列表(三模式产物同列: AI Tex / AI Bmp / AI Render)
    - PASS: 通道预览迷你列表(固定名捕获预览数据块)
    """

    bl_idname = "ch_ai.save_image"
    bl_label = "Save Image"
    bl_description = "Save the highlighted image to a PNG file"
    bl_options = {'REGISTER'}

    # 目标列表由面板写死(两个列表同款按钮共用一个操作器);
    # 可用性由面板按列表是否为空置灰, 故不设 poll(与 DeleteImage 同)
    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=image_list_target_items,
        default='IMAGE',
    )  # type: ignore
    filepath: StringProperty(
        name="File Path",
        description="Target file path of the saved image",
        subtype='FILE_PATH',
    )  # type: ignore

    def _active_image(self, context: Context):
        """目标列表高亮条目对应的图像数据块(条目标识即数据块名)"""
        state, collection, index_name = _image_list_state(context, self.target)
        items = getattr(state, collection)
        idx = getattr(state, index_name)
        if not (0 <= idx < len(items)):
            return None
        return bpy.data.images.get(items[idx].name)

    def invoke(self, context: Context, event: Event):
        image = self._active_image(context)
        if image is None:
            self.report({'WARNING'}, "No image selected")
            return {'CANCELLED'}
        prefs = get_prefs()
        # 默认路径: 偏好目录 + 图像名(**经 sanitize 清洗**——通道预览图的固定名含冒号,
        # "AI Ref: Depth.png" 在 Windows 会落进 NTFS 备用数据流, 产出无扩展名的坏文件);
        # 偏好未配置时落到系统 home(文件浏览器内可改)
        default_dir = prefs.image_save_dir or bpy.path.abspath("//")
        self.filepath = os.path.join(default_dir, f"{sanitize_image_file_name(image.name)}.png")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        image = self._active_image(context)
        if image is None:
            self.report({'WARNING'}, "Image no longer exists")
            return {'CANCELLED'}
        path, err, renamed = _save_image_to_path(image, bpy.path.abspath(self.filepath))
        if err is not None:
            self.report({'ERROR'}, describe_error(err))
            return {'CANCELLED'}
        if renamed:
            self.report({'INFO'}, report("Same name exists, saved as '{}'").format(os.path.basename(path)))
        self.report({'INFO'}, report("Image saved to {}").format(path))
        return {'FINISHED'}


class SaveAllImages(Operator):
    """
    批量保存图像操作器

    功能: 把列表中的全部图像逐张另存为 PNG 文件(弹出文件浏览器选择目标目录,
    默认目录取偏好设置的图像保存目录); 列表为空时不可用; 已失效条目跳过;
    同名不覆盖, 自动追加序号另存.

    支持的目标: IMAGE / PASS(同 SaveImage).
    """

    bl_idname = "ch_ai.save_all_images"
    bl_label = "Save All Images"
    bl_description = "Save every image in the list to a PNG file each (pick the target directory)"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=image_list_target_items,
        default='IMAGE',
    )  # type: ignore
    directory: StringProperty(
        name="Directory",
        description="Target directory of the saved images",
        subtype='DIR_PATH',
    )  # type: ignore

    def invoke(self, context: Context, event: Event):
        prefs = get_prefs()
        self.directory = prefs.image_save_dir or bpy.path.abspath("//")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context: Context):
        state, collection, _index_name = _image_list_state(context, self.target)
        directory = bpy.path.abspath(self.directory)
        saved = 0
        renamed = 0
        for item in getattr(state, collection):
            image = bpy.data.images.get(item.name)
            if image is None:
                continue
            # 文件名清洗同上(数据块名可能含冒号, 见 SaveImage.invoke 注释)
            path, err, was_renamed = _save_image_to_path(image, os.path.join(directory, f"{sanitize_image_file_name(image.name)}.png"))
            if err is not None:
                self.report({'WARNING'}, describe_error(err))
                continue
            saved += 1
            renamed += 1 if was_renamed else 0
        if saved == 0:
            self.report({'WARNING'}, "No image saved")
            return {'CANCELLED'}
        if renamed:
            self.report({'INFO'}, report("Renamed {} files to avoid overwriting").format(renamed))
        self.report({'INFO'}, report("Saved {} images to {}").format(saved, directory))
        return {'FINISHED'}


class OpenImageEditor(Operator):
    """
    打开图像编辑器操作器

    功能: 在 Blender 自带的图像编辑器中查看列表当前高亮的图像; 已有图像编辑器区域时
    全部切到该图(与"自动打开图像"开关共用 focus_image_editors), 一个都没有时用
    bpy.ops.wm.window_new 弹出单区域窗口并把其区域改为图像编辑器挂图(有 exec, Python
    可调; 窗口尺寸为源窗口 95% x 90%, 源码硬编码无参数). 只查看不修改数据.

    支持的目标: IMAGE / PASS(同 SaveImage).
    """

    bl_idname = "ch_ai.open_image_editor"
    bl_label = "Open Image Editor"
    bl_description = "View the highlighted image in Blender's built-in image editor " "(opens a new window when no image editor exists)"
    bl_options = {'REGISTER'}

    # 目标列表由面板写死(与 SaveImage 同款); 可用性由面板按列表置灰, 故不设 poll
    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=image_list_target_items,
        default='IMAGE',
    )  # type: ignore

    def execute(self, context: Context):
        state, collection, index_name = resolve_image_list_state(context, self.target)
        # 两条守卫文案(未选中 / 数据块已删)与判定次序走共用入口, 见 image_common.highlighted_image
        image = highlighted_image(self, state, collection=collection, index_name=index_name)
        if image is None:
            return {'CANCELLED'}
        # 已有图像编辑器区域: 全部切到该图, 不重复弹窗(与"自动打开图像"开关同口径)
        focused, _err = focus_image_editors(context, image)
        if focused:
            self.report({'INFO'}, report("Opened the image in {} image editor area(s)").format(focused))
            return {'FINISHED'}
        # 一个都没有: 弹单区域窗并改型挂图(wm.window_new 有 exec 可从 Python 调用;
        # 渲染视图通道 render.view_show 与 area_dupli 只有 invoke, Python 调用报
        # "Invalid operator call"——wm_event_system.cc 的 invoke 分支要求 event 非空)
        old_pointers = {w.as_pointer() for w in context.window_manager.windows}
        try:
            bpy.ops.wm.window_new()
        except RuntimeError as e:
            self.report({'ERROR'}, describe_error(api_error("Failed to open a new window", e)))
            return {'CANCELLED'}
        # 新窗口按指针集合差识别(bpy 包装对象每次访问都是新 Python 对象, is 身份比较恒
        # 不等, 曾把枚举居首的主窗口误判成新窗口并改写其布局区域); 识别不到宁可放弃,
        # 绝不改写用户工作布局的区域
        new_windows = [w for w in context.window_manager.windows if w.as_pointer() not in old_pointers]
        if not new_windows:
            self.report({'WARNING'}, report("The new window was not found, nothing was changed"))
            return {'CANCELLED'}
        # 新窗口只有一个区域(wm_window_new_exec 经 WM_window_open 建单区 screen), 改型挂图
        area = new_windows[0].screen.areas[0]
        area.type = 'IMAGE_EDITOR'
        area.spaces.active.image = image
        self.report({'INFO'}, report("Opened the image in the image editor window"))
        return {'FINISHED'}
