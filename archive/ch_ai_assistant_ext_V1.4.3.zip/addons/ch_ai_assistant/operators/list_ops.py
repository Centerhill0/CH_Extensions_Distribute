"""
列表项排序操作模块

脚本列表与主图像列表的高亮项上移与下移, 以及图像列表的项删除;
排序写进数据块自定义属性(handlers.move_list_item), 对话列表无排序.
"""

import bpy
from bpy.props import EnumProperty
from bpy.types import Context, Operator

from ....common.blender.list_snapshot import set_index_after_removal
from ..handlers import move_list_item, sync_images_now
from ..items import image_list_target_items
from .render_send import clear_pass_cache_ref
from .image_common import highlighted_image, resolve_image_list_state

# 排序目标与方向项(模块级 *_items 供 i18n 提取, "Script/Image/Up/Down"为系统词条不入典)
_target_items = [
    ('SCRIPT', "Script", "The script list"),
    ('IMAGE', "Image", "The generated image list"),
]
_direction_items = [
    ('UP', "Up", "Move the item up"),
    ('DOWN', "Down", "Move the item down"),
]


class MoveListItem(Operator):
    """
    移动列表项操作器

    功能: 把列表当前高亮项与相邻项交换排序位置(到顶/底时不动),
    排序持久存于数据块, 列表快照随之反映.

    支持的目标:
    - SCRIPT: 脚本列表(文本块)
    - IMAGE: 主图像列表(三模式产物同列的数据块)
    """

    bl_idname = "ch_ai.move_list_item"
    bl_label = "Move List Item"
    bl_description = "Move the selected list item up or down"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which list to reorder",
        items=_target_items,
        default='SCRIPT',
    )  # type: ignore
    direction: EnumProperty(
        name="Direction",
        description="Move direction",
        items=_direction_items,
        default='UP',
    )  # type: ignore

    def execute(self, context: Context):
        moved = move_list_item(self.target, self.direction)
        if not moved:
            # 到顶/底或项缺失: 静默不动(按钮本就无可用动作)
            return {'CANCELLED'}
        return {'FINISHED'}


class DeleteImage(Operator):
    """
    删除图像操作器

    功能: 删除主图像列表或通道预览迷你列表当前高亮的图像数据块(不可撤销),
    高亮压回有效范围; 删到通道预览图时联动清理发送缓存对应通道.

    支持的目标:
    - IMAGE: 主图像列表(AI Tex / AI Bmp / AI Render 三种产物)
    - PASS: 通道预览迷你列表(固定名捕获预览数据块)
    """

    bl_idname = "ch_ai.delete_image"
    bl_label = "Delete Image"
    bl_description = "Delete the selected image from the blend file"
    bl_options = {'REGISTER', 'UNDO'}

    target: EnumProperty(
        name="Target",
        description="Which list the image belongs to",
        items=image_list_target_items,
        default='IMAGE',
    )  # type: ignore

    def execute(self, context: Context):
        state, collection, index_name = resolve_image_list_state(context, self.target)
        # 负索引会取到末项(RNA 集合语义), 与"未选中"的意图相反; 两条守卫与文案
        # (未选中 / 数据块已删)见 image_common.highlighted_image
        idx = getattr(state, index_name)
        image = highlighted_image(self, state, collection=collection, index_name=index_name)
        if image is None:
            return {'CANCELLED'}
        # 删到通道预览图时联动清理发送缓存对应通道(保持"列表里没有 = 不会发送")
        clear_pass_cache_ref(image.name)
        bpy.data.images.remove(image)
        # 立即重建图像列表快照, 高亮压回有效范围(护栏内写入, 不触发切换回调)
        sync_images_now()
        set_index_after_removal(state, index_name, len(getattr(state, collection)), idx)
        return {'FINISHED'}
