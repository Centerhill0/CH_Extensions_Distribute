"""
AI 助手服务设置面板模块

AI 助手 Tab 顶部的服务设置(默认折叠): 一组文本服务 + 一组图像服务 ——
- 文本服务(Text Generation): 服务商 + 覆盖模型 + 思考档位, 脚本生成器与对话共用;
- 图像服务(Image Generation): 服务商 + 覆盖模型, 图像生成器三个模式共用.

两组的绘制件分别在 ai_text_service / ai_image_service(非面板), 本模块只做面板外壳与顺序.
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from .ai_image_service import draw_image_service
from .ai_text_service import draw_text_service


@reg_order(1)
class AiServicePanel(Panel):
    """AI 助手服务设置面板(文本服务 + 图像服务)"""

    bl_label = "AI Service"
    bl_idname = "VIEW3D_PT_ch_ai_service"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # AI 助手选项卡(四个面板共用)
    bl_category = "AI Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        wm = context.window_manager
        draw_text_service(self.layout, wm.ch_ai_text_service)
        draw_image_service(self.layout, wm.ch_ai_image_service)
