"""按渲染组的增量缓存: 组是「一次渲染调用」与「缓存失效」的共同单位"""

import hashlib

import bpy
import numpy as np

from ._constants import CRYPTO_SLOT_COUNT, CRYPTO_SLOT_KEYS, CRYPTO_SOURCE_DEFAULT, EDGE_PRESET_DEFAULT, GROUP_LINEART, GROUP_MAIN, GROUP_OUTPUTS, _EEVEE_SAMPLES, _crypto_slots_used, _group_entries
from ._size import _sane_clamp, resolve_capture_size

_PASS_RAW_CACHE: dict | None = None


# 原始字节增量缓存的内存上限. 定标依据: 2048² 下三层 cryptomatte 约 201 MB,
# 再加深度/法向 EXR 约 280 MB —— 给 512 MB 在常规分辨率不会触发, 又能挡住 4K/8K 把内存吃满.
# 超限即整体丢弃(不做半缓存), 该口径见 store_group_cache 的 docstring.
_RAW_CACHE_MAX_BYTES = 512 * 1024 * 1024


_CHANNEL_GROUP = {key: group for group, entries in GROUP_OUTPUTS.items() for key, _ in entries}
# cryptomatte 各层由主组渲染, 故归入主组(键名由层数派生, 不随渲染组声明表变化)
_CHANNEL_GROUP.update({key: GROUP_MAIN for key in CRYPTO_SLOT_KEYS})


def needed_groups(wanted: dict) -> list:
    """本次需要的渲染组(按批次顺序: 主组在前, 线稿组在后)"""
    return [group for group in (GROUP_MAIN, GROUP_LINEART) if _group_entries(group, wanted)]


def _color_management_key(scene) -> tuple:
    """用户色彩管理的关键项

    只有**合并结果**通道遵循用户色彩管理(其余通道 save_as_render=False 已隔离), 故它只进
    主组键. 漏掉它会导致「改了 view transform 却命中缓存,合并结果不跟着变」——
    实测该回归由 test_capture_passes 的「合并结果随 view transform 变化」断言抓出.
    """
    settings = getattr(scene, "view_settings", None)
    if settings is None:
        return ()
    return (settings.view_transform, settings.look, settings.exposure, settings.gamma)


def _digest(value) -> str:
    """把可打印结构压成短摘要(只用于比较, 不要求抗碰撞)"""
    return hashlib.blake2b(repr(value).encode("utf-8"), digest_size=8).hexdigest()


def _mesh_geometry_token(obj, depsgraph) -> tuple:
    """网格几何指纹: 顶点坐标(经修改器/形态键求值) + 拓扑规模

    只取顶点/面数量无法发现"顶点被移动/修改器参数改变".
    评估网格用 `to_mesh()` 取, 读取后必须 `to_mesh_clear()` 释放.
    """
    data = getattr(obj, "data", None)
    # 无修改器/形态键时基础网格就是最终几何, 免去 to_mesh() 的全量复制(常见场景的大头)
    needs_eval = depsgraph is not None and (len(getattr(obj, "modifiers", ())) > 0 or getattr(data, "shape_keys", None) is not None)
    ev = obj.evaluated_get(depsgraph) if needs_eval else obj
    mesh = None
    try:
        mesh = ev.to_mesh() if needs_eval else data
        if mesh is None:
            return ()
        count = len(mesh.vertices)
        coords = np.empty(count * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", coords)
        return (count, len(mesh.polygons), _digest(coords.tobytes()))
    except (RuntimeError, ValueError, TypeError):
        return (len(getattr(data, "vertices", ())), len(getattr(data, "polygons", ())))
    finally:
        if needs_eval and mesh is not None:
            ev.to_mesh_clear()


# 节点属性里与出图无关的项(UI 位置/尺寸/选择/显示态等). 数组属性(位置/尺寸/颜色)由 is_array
# 排除, 指针属性(image 等)单独取, 避免把整个 RNA 表面扫进指纹.
_NODE_SKIP_PROPS = frozenset(
    {
        "name",
        "label",
        "parent",
        "inputs",
        "outputs",
        "internal_links",
        "warning_propagation",
        "select",
        "hide",
        "show_options",
        "show_preview",
        "show_texture",
        "use_custom_color",
        "width",
        "height",
    }
)

# 参与指纹的节点标量属性类型
_NODE_VALUE_TYPES = frozenset({'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'})


def _socket_values(sockets) -> tuple:
    """socket 默认值序列

    输入与输出都要取: Value/RGB 节点的值存在**输出** socket 的 default_value 上,
    只读输入会让这两类最常见的节点改动完全不出现在指纹里.
    """
    values = []
    for sock in sockets:
        value = getattr(sock, "default_value", None)
        if isinstance(value, (bool, int, str)):
            values.append(value)
        elif isinstance(value, float):
            values.append(round(value, 6))
        elif hasattr(value, "__len__"):
            try:
                values.append(tuple(round(float(item), 6) for item in value))
            except (TypeError, ValueError):
                continue
    return tuple(values)


def _is_node_value_prop(prop) -> bool:
    """节点属性是否参与指纹: 可写、非数组的标量, 且排除 `bl_*` 常量与 UI 显示态"""
    if prop.identifier.startswith("bl_") or prop.identifier in _NODE_SKIP_PROPS:
        return False
    if prop.is_readonly or getattr(prop, "is_array", False):
        return False
    return prop.type in _NODE_VALUE_TYPES


def _node_prop_values(node) -> tuple:
    """节点自身的标量属性(混合模式/运算类型/插值/投影等非 socket 参数)"""
    values = []
    for prop in node.bl_rna.properties:
        if not _is_node_value_prop(prop):
            continue
        try:
            values.append((prop.identifier, getattr(node, prop.identifier)))
        except (AttributeError, ReferenceError, TypeError):
            continue
    return tuple(values)


def _ramp_token(node) -> tuple:
    """色带节点的色标(位置/颜色)与插值模式: 存在 node.color_ramp, 不是 socket 默认值"""
    ramp = getattr(node, "color_ramp", None)
    if ramp is None:
        return ()
    elements = tuple((round(element.position, 6), tuple(round(float(channel), 6) for channel in element.color)) for element in ramp.elements)
    return (ramp.interpolation, getattr(ramp, "color_mode", ""), elements)


def _image_token(node) -> tuple:
    """贴图节点的图像引用与内容版本(换图/改图/重新打包都改变指纹)"""
    image = getattr(node, "image", None)
    if image is None:
        return ()
    packed = getattr(image, "packed_file", None)
    return (image.name, tuple(image.size), image.filepath, image.source, bool(image.is_dirty), packed.size if packed is not None else -1)


def _node_tree_token(tree) -> str:
    """材质/世界节点树指纹: 节点类型/名称/输入输出默认值/标量属性/色标/贴图 + 连线拓扑"""
    if tree is None:
        return ""
    nodes = []
    for node in tree.nodes:
        nodes.append(
            (
                node.bl_idname,
                node.name,
                _socket_values(node.inputs),
                _socket_values(node.outputs),
                _node_prop_values(node),
                _ramp_token(node),
                _image_token(node),
            )
        )
    nodes.sort(key=lambda entry: (entry[0], entry[1]))
    links = sorted((link.from_node.name, link.from_socket.name, link.to_node.name, link.to_socket.name) for link in tree.links)
    return _digest((nodes, links))


def _camera_data_token(cam) -> tuple:
    """摄像机数据指纹(镜头/裁切/传感/移轴/投影/景深)"""
    if cam is None:
        return ()
    data = cam.data
    dof = getattr(data, "dof", None)
    return (
        data.type,
        round(data.lens, 4),
        round(data.sensor_width, 4),
        data.sensor_fit,
        round(data.shift_x, 6),
        round(data.shift_y, 6),
        round(data.clip_start, 6),
        round(data.clip_end, 6),
        round(getattr(data, "ortho_scale", 1.0), 6),
        bool(dof.use_dof) if dof is not None else False,
        round(dof.aperture_fstop, 4) if dof is not None else 0.0,
        round(dof.focus_distance, 4) if dof is not None else 0.0,
        dof.focus_object.name if dof is not None and dof.focus_object is not None else "",
    )


def _light_data_token(light) -> tuple:
    """灯光数据指纹(类型/能量/颜色/尺寸)"""
    if light is None:
        return ()
    return (
        light.type,
        round(light.energy, 4),
        tuple(round(float(channel), 4) for channel in light.color),
        round(getattr(light, "size", 0.0), 4),
        round(getattr(light, "spot_size", 0.0), 4),
        round(getattr(light, "spot_blend", 0.0), 4),
        getattr(light, "shape", ""),
        round(getattr(light, "angle", 0.0), 4),
    )


_VISIBILITY_ATTRS = ("visible_camera", "visible_diffuse", "visible_glossy", "visible_transmission", "visible_volume_scatter", "visible_shadow")


def deep_scene_content_key(scene) -> tuple:
    """捕获期使用的**深度**场景指纹(进渲染键, 不进面板绘制的过期提示)

    与 `scene_content_key` 的分工: 后者在面板 draw 里每次重绘都会算, 只能取廉价项;
    本函数只在真正捕获/比较缓存时调用一次, 覆盖会改变出图但不改名称/矩阵的改动:
    摄像机镜头与裁切、灯光能量/颜色、材质与世界的节点值/连线、顶点坐标(含修改器与形态键).

    宁可多失效(多渲一次)也不能少失效(给出陈旧出图) —— 这是增量缓存的核心约束.
    """
    depsgraph = bpy.context.evaluated_depsgraph_get() if scene == getattr(bpy.context, "scene", None) else None
    material_tokens = {}
    items = []
    for obj in scene.objects:
        data = getattr(obj, "data", None)
        if obj.type == 'MESH' and data is not None:
            shape = _mesh_geometry_token(obj, depsgraph)
        elif obj.type == 'GREASE_PENCIL' and data is not None:
            shape = (data.name, len(data.layers))
        elif data is not None:
            shape = (data.name,)
        else:
            shape = ()
        materials = []
        for slot in getattr(obj, "material_slots", ()):
            material = slot.material
            if material is None:
                materials.append(("", ""))
                continue
            if material.name not in material_tokens:
                material_tokens[material.name] = _node_tree_token(getattr(material, "node_tree", None))
            materials.append((material.name, material_tokens[material.name]))
        visibility = tuple(bool(getattr(obj, attr, True)) for attr in _VISIBILITY_ATTRS)
        light = _light_data_token(getattr(obj, "data", None) if obj.type == 'LIGHT' else None)
        items.append((obj.name, obj.type, bool(obj.hide_render), tuple(round(v, 4) for row in obj.matrix_world for v in row), shape, tuple(materials), visibility, light))
    items.sort(key=lambda entry: entry[0])
    world = getattr(scene, "world", None)
    world_token = (world.name, _node_tree_token(getattr(world, "node_tree", None))) if world is not None else ()
    return (
        tuple(items),
        world_token,
        _camera_data_token(getattr(scene, "camera", None)),
        getattr(scene, "frame_current", 0),
        bool(getattr(scene.render, "film_transparent", False)),
    )


def scene_content_key(scene) -> tuple:
    """场景**可见内容**的指纹(进渲染键)

    **必须有它**: 渲染键若只含尺寸/摄像机/参数, 那么增删物体后键**一字不变** → 命中增量
    缓存 → 直接返回**上一个场景**的通道字节(加/删物体后点生成通道, 出图仍是旧场景).

    取粗粒度指纹(名字/类型/隐藏态/世界矩阵/网格规模/材质名/帧号)而非逐顶点哈希:
    覆盖增删/改名/移动/隐藏/换材质/改拓扑/换帧这些常见改动, 又不至于每次捕获都做重活.
    宁可多失效(多渲一次)也不能少失效(给出陈旧出图).
    """
    items = []
    for obj in scene.objects:
        data = getattr(obj, "data", None)
        if obj.type == 'MESH' and data is not None:
            shape = (len(data.vertices), len(data.polygons))
        elif obj.type == 'GREASE_PENCIL' and data is not None:
            shape = (len(data.layers),)
        elif data is not None:
            shape = (len(data.name),)  # 其它类型只认数据块名(改数据即改名或换块)
        else:
            shape = ()
        mats = tuple(slot.material.name if slot.material else "" for slot in getattr(obj, "material_slots", ()))
        items.append((obj.name, obj.type, bool(obj.hide_render), tuple(round(v, 4) for row in obj.matrix_world for v in row), shape, mats))
    items.sort()
    return (tuple(items), scene.world.name if getattr(scene, "world", None) else "", getattr(scene, "frame_current", 0))


def group_render_key(
    group: str,
    scene,
    *,
    ao_distance: float = 1.0,
    edge_width_scale: float = 1.0,
    material_borders: bool = False,
    edge_preset: str = EDGE_PRESET_DEFAULT,
    clamp_long_edge: int = 0,
    render_samples: int = _EEVEE_SAMPLES,
    crypto_source: str = CRYPTO_SOURCE_DEFAULT,
    crypto_slots: int = CRYPTO_SLOT_COUNT,
    content_key: tuple | None = None,
) -> tuple:
    """某组的**渲染键**: 只含改变该组渲染结果的参数

    刻意不含「本次要哪些通道」(由子集判定负责), 也**不含其它组的参数** ——
    线宽不进主组键,AO 距离不进线稿组键, 这样改一个参数只影响它真正影响的那个组.
    公共项(钳制后尺寸/摄像机名/摄像机世界矩阵/**场景深度指纹**)两组都含:
    它们会改变任何一组的渲染结果. 采样数两组都含: 两组共享同一个场景采样数.

    content_key 由调用方一次算好传入(两组共用), 缺省时现算深度指纹.
    """
    cap_w, cap_h = resolve_capture_size(scene, _sane_clamp(clamp_long_edge))
    cam = scene.camera
    if content_key is None:
        content_key = deep_scene_content_key(scene)
    common = ((cap_w, cap_h), cam.name if cam is not None else "", tuple(cam.matrix_world) if cam is not None else (), render_samples, content_key)
    if group == GROUP_MAIN:
        # 主组是唯一有通道遵循用户色彩管理的组(合并结果), 故色彩管理必须进它的键;
        # 分割依据与落盘层数只影响主组(它们决定主组开哪条 pass,出几层)
        return (ao_distance, crypto_source, _crypto_slots_used(crypto_slots)) + _color_management_key(scene) + common
    if group == GROUP_LINEART:
        # 线稿走 alpha 映射(save_as_render=False), 与色彩管理无关
        return (edge_width_scale, material_borders, edge_preset) + common
    return common


def lookup_group_cache(keys: dict, wanted: dict, crypto_source: str = CRYPTO_SOURCE_DEFAULT, crypto_slots: int = CRYPTO_SLOT_COUNT) -> dict:
    """按组查缓存, 返回可复用的 {组: {通道键: 原始落盘字节}}

    命中条件: 该组渲染键与缓存一致, **且**本次所需通道 ⊆ 该组已产出通道(子集判定).
    子集判定是「取消一个通道不重渲」得以成立的关键.
    """
    cached = (_PASS_RAW_CACHE or {}).get("groups", {})
    reused = {}
    for group, key in keys.items():
        entry = cached.get(group)
        if not entry or entry.get("key") != key:
            continue
        needed = {channel for channel, _socket in _group_entries(group, wanted, crypto_source, crypto_slots)}
        raw = entry.get("raw") or {}
        if needed and needed <= set(raw):
            reused[group] = dict(raw)
    return reused


def store_group_cache(keys: dict, raw_by_group: dict, size, notices) -> None:
    """把本次渲染产出的各组原始字节并入缓存(未重渲的组保留原有条目)"""
    global _PASS_RAW_CACHE
    groups = dict((_PASS_RAW_CACHE or {}).get("groups", {}))
    for group, raw in raw_by_group.items():
        if raw:
            groups[group] = {"key": keys.get(group), "raw": dict(raw)}
    if not groups:
        _PASS_RAW_CACHE = None
        return
    total = sum(len(blob) for entry in groups.values() for blob in entry["raw"].values())
    if total > _RAW_CACHE_MAX_BYTES:
        # 超上限即**整体丢弃**(不留半份): 下次捕获走全量渲染, 绝不静默留一个"看似命中,
        # 实则缺通道"的缓存. 缓存规模本身有界(最多两个组, 各组通道固定), 这里是病态防护.
        _PASS_RAW_CACHE = None
        return
    _PASS_RAW_CACHE = {"groups": groups, "size": size, "notices": list(notices)}


def clear_raw_cache() -> None:
    """清空增量缓存(载入新 .blend 时调用, 防跨文件误用上一份场景的原始字节)"""
    global _PASS_RAW_CACHE
    _PASS_RAW_CACHE = None
