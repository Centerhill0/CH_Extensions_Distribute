"""
摄像机视图参考通道提取子包(EEVEE 单引擎 · 临时文件中转管线)

以 EEVEE 在一个临时场景中渲染场景摄像机视图, 提取七种参考通道. 渲染按**渲染组**组织,
组是「一次渲染调用」与「缓存失效」的共同单位(见 _constants.GROUP_VIEW_LAYER / GROUP_OUTPUTS):
- 主组(用户世界): 合并结果(Combined)/深度(Depth)/法向(Normal)/漫射颜色(Diffuse Color)/
  AO(Ambient Occlusion), 共享用户世界与摄像机, 合并结果套用用户色彩管理;
- 主组(附加出线): 语义分割由 Cryptomatte 出图 —— 勾选分割时主组额外落盘若干层
  crypto_NN.exr(每层两个对象槽位), 解码期在 Python 内按所选依据(物体/材质/资产)合成
  「每对象一色 + 纯黑背景」的分割图, 全程不建覆盖材质, 也不改用户世界;
- 线稿组(场景线条画): 场景级蜡笔(LINEART_SCENE)开启视图层蜡笔通道, **原样**输出 Grease
  Pencil 通道, 白底黑线在 Python 内按 1-alpha 映射(合成器内做算术不可信, 见 _scene).

两组默认在**同一次渲染调用**里一起落盘(各占一个视图层); 线稿组靠集合排除把自己从主组隔开,
故合并结果不被线稿污染. 未失效的组可由增量缓存直接复用, 只重渲真正需要的那一组.

落盘机制:
File Output 节点的 format.media_type 默认是 MULTI_LAYER_IMAGE, 该档下 file_format 被锁死为
OPEN_EXR_MULTILAYER, 所有输入并被合并进同一个 .exr; 必须先设 media_type='IMAGE' 才能
逐通道独立指定格式. 故本管线"一个通道一个 File Output 节点", 逐通道落盘到
%TEMP%/ch_ai_assistant_pass_capture/<本次唯一目录>/, 读入内存后立即删除:
- 合并结果/漫射颜色 -> JPEG(体积小, 走 Blender 编码), AO -> PNG 8bit;
- 语义分割 -> 若干层 crypto_NN.exr 32bit(哈希是按位重解释的浮点, 任何有损环节都会摧毁 ID),
  解码期自编码 PNG, 因此该通道**完全不进 Blender 色彩管线**;
- 深度/法向 -> 单层 EXR 16bit(需回读原始浮点: 深度背景为 camera.clip_end 远超 1,
  法向是**带符号原始向量**而非 (n+1)/2, 写 LDR 会被钳成 0), 回读后在 numpy 内完成
  映射与编码(深度按用户近/远区间映射为灰阶, 法向按 (n+1)/2 编码, DIRECTX 约定反绿通道);
- 线稿 -> PNG 8bit, 但渲染写出的像素 RGB 恒为 0, 笔画信息**全在 alpha**, 故回读 alpha 后
  按 1-alpha 映射为黑线白底再自编码 PNG.
渲染自身不写静帧(write_still=False): 通道文件由 File Output 节点落盘, 与静帧写盘无关,
故一次捕获只产出 7 份通道文件(实测).

用户场景零修改: 临时场景只关联(引用)用户集合/摄像机/世界, 全部改动都落在临时场景与临时
视图层上; 分割走 Cryptomatte 后**既不写用户物体的 obj.color, 也不建覆盖材质/覆盖世界**
(更早的实现两者都做); 蜡笔对象经上下文覆写在临时场景内创建并在 finally 中回收,
用户侧的集合成员, 选中集与活动物体均不被改动.

临时文件生命周期: 每次捕获前先清扫本插件自有临时根目录下的旧目录,
捕获中"渲染写出 -> 读入内存/打包 -> 立即删除", 删除一律尽力而为(Windows 上刚写出的图片
常被杀软实时扫描/索引器/缩略图预览瞬时占用而抛 WinError 32, 短延时重试一次, 仍失败即放弃,
绝不允许打断捕获流程); 只动自家目录, 不碰 %TEMP% 中他人的文件.

模块分工(依赖自上而下, 无环):
- _constants: 常量与声明式表(采样/钳制/线稿预设/深度拾取/落盘规格/渲染组), 依赖栈底
- _tmpdir: 本插件自有临时目录的清扫与新建
- _size: 捕获分辨率与落盘体积估算
- _scene: 临时场景,视图层分组,合成节点树,单次渲染调用
- _pixels: 通道像素读回与自编码(深度/法向/线稿映射)
- _lineart: 场景级蜡笔线稿的创建与回收
- _depth_pick: 视锥几何投射采样可见深度(不渲染)
- _cache: 按渲染组的增量缓存与渲染键
- _session: PassCaptureSession(按批驱动)
- _entry: capture_camera_passes(会话的薄封装, 供脚本与测试直调)

公共 API 在本文件唯一声明; 各子模块不写模块级 __all__(见代码风格规范 §5/§10).
内部协作模块按需深路径导入, 不进顶层命名空间.

主要功能:
- capture_camera_passes: 渲染摄像机视图并提取所选通道, 返回 (通道字典, 参考图尺寸, 提示消息列表, 错误信息)
- sample_visible_depth: 按摄像机视锥几何投射采样可见深度, 返回 (近端, 远端, 命中数, 错误信息),
  供面板「深度拾取」一键回填深度范围(不渲染)
- scene_content_key: 场景可见内容的粗粒度指纹(名字/类型/隐藏态/世界矩阵/网格规模/材质名/帧号),
  进渲染键与捕获参数指纹, 供"增删物体后不得命中陈旧缓存/漏掉过期提示"共用同一来源
"""

__all__ = [
    "PASS_ORDER",
    "WARN_EDGE_PX",
    "PassCaptureSession",
    "capture_camera_passes",
    "clear_raw_cache",
    "estimate_capture_bytes",
    "resolve_capture_size",
    "sample_visible_depth",
    "scene_content_key",
]

from ._cache import clear_raw_cache, scene_content_key
from ._constants import PASS_ORDER, WARN_EDGE_PX
from ._depth_pick import sample_visible_depth
from ._entry import capture_camera_passes
from ._session import PassCaptureSession
from ._size import estimate_capture_bytes, resolve_capture_size
