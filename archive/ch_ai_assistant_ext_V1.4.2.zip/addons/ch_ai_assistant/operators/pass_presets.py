"""
通道组合预设操作模块

把图像生成器效果图模式的捕获通道开关存为**面板状态**里的命名快照(仅本会话), 提供应用/保存/删除三个算子.
预设只快照捕获组: 发送选择收在通道列表行首勾选框(见 items.pass_send_attr), 不进预设.
预设存于面板而非偏好: 面板参数一律不得反向写偏好(规范17), 偏好只承载全局设置.
预设名清洗为 ASCII: 下拉是动态枚举, 非 ASCII 条目在 Blender C 层会渲染成乱码.
"""

import re


from bpy.types import Context
from bpy.types import Operator
from bpy.props import StringProperty


from .render_send import _PASS_TOGGLES

_PRESET_TOGGLES = tuple(attr for attr, _key in _PASS_TOGGLES)


def _sanitize_preset_name(name: str) -> str:
    """预设名清洗为 ASCII: 动态枚举下拉条目经 Blender C 层绘制, 非 ASCII 实测渲染成乱码

    非 ASCII 可打印字符的连续段折叠为单下划线并去掉首尾的 "_"/空格;
    清洗后为空(如纯中文名)返回空串, 由调用方回落序号自动命名.
    """
    return re.sub(r"[^\x20-\x7e]+", "_", name).strip("_ ")


class ApplyPassPreset(Operator):
    """
    应用通道组合预设操作器

    功能: 把面板下拉中选中的通道组合预设写回面板的捕获通道开关;
    预设存于面板状态, 由 SavePassPreset 保存, DeletePassPreset 删除.
    """

    bl_idname = "ch_ai.apply_pass_preset"
    bl_label = "Apply Pass Preset"
    bl_description = "Apply the selected pass preset to the capture toggles"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return len(context.window_manager.ch_ai_image_state.pass_presets) > 0

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_image_state
        preset = next((p for p in state.pass_presets if p.name == state.pass_preset_choice), None)
        if preset is None:
            self.report({'WARNING'}, "No pass preset selected")
            return {'CANCELLED'}
        for attr in _PRESET_TOGGLES:
            setattr(state, attr, getattr(preset, attr))
        return {'FINISHED'}


class SavePassPreset(Operator):
    """
    保存通道组合预设操作器

    功能: 把面板当前的捕获通道开关快照存为面板预设;
    名称留空时按序号自动命名("Preset N"), 重名即覆盖(更新已有预设);
    名称清洗为 ASCII(下拉是动态枚举, 非 ASCII 条目 C 层乱码), 清洗后为空按序号命名;
    保存后下拉自动选中该预设.
    """

    bl_idname = "ch_ai.save_pass_preset"
    bl_label = "Save Pass Preset"
    bl_description = "Save the current capture toggles as a named pass preset in this panel"
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(
        name="Name",
        description="Preset name, empty names it automatically, non-ASCII characters fold to underscores",
    )  # type: ignore

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_image_state
        name = _sanitize_preset_name(self.name)
        if not name:
            # 自动命名扫下一个空闲序号: len+1 在删除过预设后会撞上幸存预设名,
            # 命中"重名即覆盖"分支等于用没输入过的名字覆盖用户预设(裁决⑭)
            existing = {p.name for p in state.pass_presets}
            num = len(state.pass_presets) + 1
            while f"Preset {num}" in existing:
                num += 1
            name = f"Preset {num}"
        # 用户显式输入撞名维持"重名即覆盖"(README 载明)
        preset = next((p for p in state.pass_presets if p.name == name), None)
        if preset is None:
            preset = state.pass_presets.add()
        preset.name = name
        for attr in _PRESET_TOGGLES:
            setattr(preset, attr, getattr(state, attr))
        state.pass_preset_choice = name
        return {'FINISHED'}


class DeletePassPreset(Operator):
    """
    删除通道组合预设操作器

    功能: 从面板预设列表中删除下拉当前选中的通道组合预设(不可恢复); 删除后下拉回落.
    """

    bl_idname = "ch_ai.delete_pass_preset"
    bl_label = "Delete Pass Preset"
    bl_description = "Delete the selected pass preset from this panel"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        return len(context.window_manager.ch_ai_image_state.pass_presets) > 0

    def execute(self, context: Context):
        state = context.window_manager.ch_ai_image_state
        idx = next((i for i, p in enumerate(state.pass_presets) if p.name == state.pass_preset_choice), None)
        if idx is None:
            self.report({'WARNING'}, "No pass preset selected")
            return {'CANCELLED'}
        state.pass_presets.remove(idx)
        # 下拉选中值回落: 原条目已随删除消失(动态枚举失效值读回空串), 显式写回首项或占位档
        state.pass_preset_choice = state.pass_presets[0].name if len(state.pass_presets) else 'NONE'
        return {'FINISHED'}
