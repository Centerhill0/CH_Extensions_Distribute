"""
图像生成器 · 图像侧(纹理贴图 / 图像)绘制段模块

不是面板: 由 ui/panels/ai_image.py 的合并面板按当前模式调用, 只画图像侧的专属内容——
- draw_image_settings: 输出尺寸(1K/2K 方图或画幅比率) + 无缝(仅纹理贴图模式显示)
- draw_image_prompt: 描述 / 负向 / 长文提示 / 三个提示词工具 / 修改图像·生成

设置小节的外壳(折叠头与公共段)在合并面板里, 本模块只提供模式专属段.
"""

from bpy.types import UILayout

from ...operators.ai_generate import ClearPrompt, EditPrompt, OptimizePrompt
from ...operators.ai_texture import (
    GenerateTexture,
    ModifyImage,
    PreviewTexturePrompt,
)
from ...utils import AI_TEXTURE_PROMPT_TEXT_NAME
from .blocks import (
    IMAGE_SIZE_FIELDS,
    TEX_SIZE_FIELDS,
    draw_long_desc_hint,
    draw_negative_row,
    draw_operator,
    draw_size_settings,
)


def draw_image_settings(layout: UILayout, state, provider: str, model: str) -> None:
    """图像侧输出尺寸段: 分辨率 + 实际输出(纹理贴图与图像各一套字段, 切模式互不覆盖)

    - 纹理贴图: 1K/2K 方图 + 自定义, 仅自定义档可改宽高(与既有锁定语义一致);
    - 图像: 常用宽高比 + 自定义, 宽高恒可编辑(改动即回落自定义档).
    provider/model 由合并面板解析后传入(尺寸约束与实际下发值同口径);
    无缝贴图与张数等项由合并面板按固定次序插在本段之后.
    """
    if state.mode == 'IMAGE':
        draw_size_settings(layout, state, IMAGE_SIZE_FIELDS, provider, model, editable=True, lock_enabled=True)
        return
    custom = state.tex_size_preset == 'CUSTOM'
    draw_size_settings(layout, state, TEX_SIZE_FIELDS, provider, model, editable=custom, lock_enabled=custom)


def draw_image_prompt(layout: UILayout, state, provider: str) -> None:
    """图像侧描述与操作行: 描述框 + 负向提示 + 长文提示 + 提示词工具 + 修改/生成

    长文描述块与完整提示词块按图像侧分开(AI_Texture_Prompt.txt / AI_Texture_Final_Prompt.txt),
    与效果图模式互不覆盖.
    """
    layout.separator(type='LINE')
    col = layout.column(align=False)
    prompt_row = col.row(align=True)
    prompt_row.prop(state, "tex_prompt", text="Prompt")
    draw_operator(prompt_row, ClearPrompt.bl_idname, 'TEXTURE', 'CANCEL_LARGE', text="")
    # 负向提示: 仅支持该参数的服务商显示(简短输入, 行尾清除按钮)
    draw_negative_row(col, state, provider, 'TEXTURE')
    draw_long_desc_hint(col, AI_TEXTURE_PROMPT_TEXT_NAME)
    # 编辑描述 / 优化提示词(读 AI 服务面板的文本服务设置) / 完整提示词(与发送逐字一致)
    row = col.row(align=True)
    draw_operator(row, EditPrompt.bl_idname, 'TEXTURE', 'TEXT')
    row.separator(factor=0.5)
    draw_operator(row, OptimizePrompt.bl_idname, 'TEXTURE', 'SHADERFX')
    row.separator(factor=0.5)
    draw_operator(row, PreviewTexturePrompt.bl_idname, None, 'WORDWRAP_ON')
    # 修改图像在左(以高亮图像为参考图), 生成在右(名称随模式动态显示)
    # (文案直接写在调用处而非先取变量: 按钮文字是用户可见元素, 静态上应可查)
    row = col.row(align=True)
    draw_operator(row, ModifyImage.bl_idname, None, 'GREASEPENCIL')
    row.separator(factor=0.5)
    draw_operator(row, GenerateTexture.bl_idname, None, 'KEY_RETURN', text="Generate Texture" if state.mode == 'TEXTURE' else "Generate Image")
