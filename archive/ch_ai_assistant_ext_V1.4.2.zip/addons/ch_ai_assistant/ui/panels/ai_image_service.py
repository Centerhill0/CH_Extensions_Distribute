"""
AI 服务设置 · 图像服务组绘制模块(非面板)

由 ui/panels/ai_service.py 的合并服务面板调用, 只画图像服务一家:
服务模式(全局/覆盖服务商) + 覆盖模型; Global 档置灰显示生效模型, 缺密钥在面板内警示.
绘制件见 blocks.draw_service_group(与文本侧同款).

图像生成器三个模式(纹理贴图 / 图像 / 效果图)共用这份设置 —— 一家服务商, 一个模型.
"""

from bpy.types import UILayout

from ...preference import get_prefs
from ...utils.provider_registry import effective_provider, get_image_provider
from .blocks import draw_service_group


def draw_image_service(layout: UILayout, state) -> None:
    """图像服务组: 服务商 + 覆盖模型(或生效模型)

    state 为共享的图像服务设置(ch_ai_image_service): 三个模式共用一份.
    """
    prefs = get_prefs()
    provider = effective_provider(state, prefs, 'image')
    key_attr = get_image_provider(provider).api_key_attr
    draw_service_group(layout, state, "Image Generation", 'IMAGE_DATA', key_attr, "panel_model", prefs.image_model_t2i)
