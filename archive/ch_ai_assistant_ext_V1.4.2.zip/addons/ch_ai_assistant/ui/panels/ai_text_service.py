"""
AI 服务设置 · 文本服务组绘制模块(非面板)

由 ui/panels/ai_service.py 的合并服务面板调用, 只画文本服务一家:
服务模式(全局/覆盖服务商) + 覆盖模型 + 思考档位; Global 档置灰显示生效模型,
缺密钥在面板内警示(绘制件见 blocks.draw_service_group).

脚本生成器与对话共用这份设置(合并前两个面板各挂一个实例, 可分别覆盖服务商/模型).
"""

from bpy.types import UILayout

from ...preference import get_prefs
from ...utils.provider_registry import effective_provider, get_text_provider
from .blocks import draw_service_group


def _key_attr(provider: str) -> str:
    """按文本服务商取偏好密钥字段名: 预设商查注册表, CUSTOM/未知回落通用 api_key 字段"""
    p = get_text_provider(provider)
    return p.api_key_attr if p is not None else "api_key"


def draw_text_service(layout: UILayout, state) -> None:
    """文本服务组: 服务商 + 覆盖模型(或生效模型) + 思考档位

    state 为共享的文本服务设置(ch_ai_text_service): 脚本生成器与对话共用一份.
    """
    prefs = get_prefs()
    provider = effective_provider(state, prefs, 'text')
    col = draw_service_group(layout, state, "Text Generation", 'CONSOLE', _key_attr(provider), "panel_model", prefs.model)
    # 思考档位: 档位表按生效服务商定制(DeepSeek 4 档 / GLM 3 档 / 通用 3 档)
    col.prop(state, "thinking", text="Thinking Level")
