"""
AI 对话面板模块

AI 助手选项卡下的纯文本对话面板(顺序上位于服务设置之后, 默认展开):
- 消息历史列表(空也常驻, 行数随内容自适应; 点击行按本面板开关转出文本编辑器阅读长回复;
  附带过脚本的消息跳过附件标记显示实际问题首行) 右侧竖列: "自动打开对话"开关 + 删除
- 所选消息操作: 查看 / 提取代码 / 复制到剪贴板; 会话操作: 归档(转出文本块并开新对话) / 清空
- 输入框(行尾清除按钮)与操作行: 重用 / 附带脚本 / 完整提示词 / 重新生成 / 发送,
  附件状态行置灰显示; 附带脚本按钮标签随状态切换(已附带当前高亮脚本时显示"取消附带")
- 最近请求错误摘要,最近请求用量,请求等待进度(末尾三段, 与其余面板同款)
"""

from bpy.types import Context, Panel

from .....common.i18n.i18n import iface
from .....common.types.framework import reg_order
from ...operators.ai_chat import (
    ChatArchive,
    ChatAttachScript,
    ChatClear,
    ChatClearInput,
    ChatCopyMessage,
    ChatDeleteMessage,
    ChatExtractCode,
    ChatRegenerate,
    ChatReuseMessage,
    ChatSend,
    ChatViewMessage,
    ChatViewPrompt,
)
from ..lists.chat import CH_AI_UL_chat
from .blocks import draw_operator, draw_error_box, draw_greyed_row, draw_usage_hint, draw_wait_box

# 消息列表显示行数: 空列表的矮框高度(下限)与随内容增长的上限
_CHAT_ROWS_MIN = 4
_CHAT_ROWS = 6


@reg_order(2)
class AiChatPanel(Panel):
    """AI 纯文本对话面板"""

    bl_label = "Chat"
    bl_idname = "VIEW3D_PT_ch_ai_chat"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # AI 助手选项卡(四个面板共用; 服务面板在上, 本面板默认展开, 其余收缩)
    bl_category = "AI Assistant"

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_state
        layout = self.layout
        messages = state.chat_messages
        has_messages = len(messages) > 0
        # 重新生成要求末条为 AI 回复(才能摘掉最后一轮问答)
        last_is_reply = has_messages and messages[len(messages) - 1].role == 'ASSISTANT'

        # ---- 消息历史列表 + 右侧竖列(自动打开开关 / 删除选定消息) ----
        row = layout.row(align=True)
        row.template_list(CH_AI_UL_chat.__name__, "ch_ai_chat", state, "chat_messages", state, "chat_active_index", rows=max(_CHAT_ROWS_MIN, min(len(messages), _CHAT_ROWS)))
        # 右侧竖列整列一次置灰(enabled 沿布局继承: 开关/删除在无消息时同灰)
        col = row.column(align=False)
        col.enabled = has_messages
        col.prop(state, "use_auto_open_chat", text="", icon='TEXT', toggle=True)
        draw_operator(col, ChatDeleteMessage.bl_idname, None, 'X', text="")

        # ---- 所选消息操作 / 会话操作(无消息时整行置灰) ----
        col = layout.column(align=False)
        row = col.row(align=True)
        row.enabled = has_messages
        draw_operator(row, ChatViewMessage.bl_idname, None, 'TEXT')
        row.separator(factor=0.5)
        draw_operator(row, ChatExtractCode.bl_idname, None, 'CONSOLE')
        row.separator(factor=0.5)
        draw_operator(row, ChatCopyMessage.bl_idname, None, 'COPYDOWN')
        row = col.row(align=True)
        row.enabled = has_messages
        draw_operator(row, ChatArchive.bl_idname, None, 'PACKAGE')
        row.separator(factor=0.5)
        draw_operator(row, ChatClear.bl_idname, None, 'TRASH')

        # ---- 输入框(行尾清除按钮, 只清输入不动历史)与操作行 ----
        layout.separator(type='LINE')
        col = layout.column(align=False)
        input_row = col.row(align=True)
        input_row.prop(state, "chat_input", text="Message")
        draw_operator(input_row, ChatClearInput.bl_idname, None, 'CANCEL_LARGE', text="")
        # 各按钮独立置灰: 重用依赖消息, 附带依赖脚本列表, 完整提示词恒可用;
        # (operator() 返回值无 enabled, 单按钮独立控制须各自包嵌套行)
        row = col.row(align=True)
        reuse = row.row(align=False)
        reuse.enabled = has_messages
        draw_operator(reuse, ChatReuseMessage.bl_idname, None, 'LOOP_BACK')
        row.separator(factor=0.5)
        attach = row.row(align=False)
        attach.enabled = len(state.scripts) > 0
        # Label follows the attachment state: the click detaches only when the
        # highlighted script IS the attached one, so show the detach label then
        # (pinned icon reinforces it); otherwise it attaches/switches, show attach.
        highlighted_name = state.scripts[state.scripts_active_index].name if 0 <= state.scripts_active_index < len(state.scripts) else ""
        if state.chat_script_name and state.chat_script_name == highlighted_name:
            draw_operator(attach, ChatAttachScript.bl_idname, None, 'PINNED', text=iface("Detach Script"))
        else:
            draw_operator(attach, ChatAttachScript.bl_idname, None, 'TEXT')
        # 完整提示词: 文本编辑器查看下一次实际发送的完整消息列表(系统 + 历史 + 输入框,
        # 已附带脚本时含附件; 与发送逐字一致)
        row.separator(factor=0.5)
        draw_operator(row, ChatViewPrompt.bl_idname, None, 'WORDWRAP_ON')
        # 重新生成(需末条为 AI 回复) 与 发送恒可用
        row = col.row(align=True)
        regen = row.row(align=False)
        regen.enabled = last_is_reply
        draw_operator(regen, ChatRegenerate.bl_idname, None, 'FILE_REFRESH')
        row.separator(factor=0.5)
        draw_operator(row, ChatSend.bl_idname, None, 'KEY_RETURN')
        # 附件状态行置灰显示
        if state.chat_script_name:
            draw_greyed_row(col, iface("Attached: {}").format(state.chat_script_name), icon='PINNED')

        # ---- 末尾三段(与其余面板同款): 错误摘要 / 用量 / 等待进度 ----
        draw_error_box(layout, wm, 'CHAT')
        draw_usage_hint(layout, state, 'chat')
        draw_wait_box(layout, state, 'chat')
