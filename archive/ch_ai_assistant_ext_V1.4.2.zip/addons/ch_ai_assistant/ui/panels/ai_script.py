"""
AI 脚本生成器面板模块

AI 助手选项卡下的脚本生成器面板(默认收缩):
- 脚本列表(空也常驻, 行数随内容自适应; 点击行按本面板开关聚焦编辑器, 上移/下移排序, 删除)
  右侧竖列: "自动打开脚本"开关 + 排序两键(紧凑) + 删除
- 所选脚本操作: 一键调试 / 运行; 描述输入(长文描述块优先)与清除按钮
- 编辑描述 / 优化提示词 / 完整提示词(发送快照) / 对话修改 / 生成脚本
- 最近运行错误摘要,最近请求用量,请求等待进度(末尾三段, 与其余面板同款)
"""

from bpy.types import Context, Panel

from .....common.types.framework import reg_order
from ...operators.ai_generate import (
    ClearPrompt,
    EditPrompt,
    GenerateScript,
    OptimizePrompt,
    ViewFullPrompt,
)
from ...operators.list_ops import MoveListItem
from ...operators.script_actions import (
    DebugScript,
    DeleteScript,
    ReviseScript,
    RunScript,
)
from ...utils import AI_PROMPT_TEXT_NAME
from ..lists.scripts import CH_AI_UL_scripts
from .blocks import draw_operator, draw_error_box, draw_long_desc_hint, draw_usage_hint, draw_wait_box

# 脚本列表显示行数: 空列表的矮框高度(下限)与随内容增长的上限
_SCRIPT_ROWS_MIN = 4
_SCRIPT_ROWS = 5


@reg_order(3)
class AiScriptPanel(Panel):
    """AI 脚本生成器面板"""

    bl_label = "Script Generator"
    bl_idname = "VIEW3D_PT_ch_ai_script"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # AI 助手选项卡(四个面板共用; 顺序为 服务 -> 对话 -> 脚本生成器 -> 图像生成器)
    bl_category = "AI Assistant"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: Context):
        wm = context.window_manager
        state = wm.ch_ai_state
        layout = self.layout
        has_items = len(state.scripts) > 0
        # 列表高亮条目的数据块名(列表为空或索引越界时条目不存在, 故先给出空串供按钮携带;
        # 只用 has_items 守卫不够: 索引可能因过滤/清空落在界外, 面板 draw 里越界即报绘制错误)
        idx = state.scripts_active_index
        active_name = state.scripts[idx].name if 0 <= idx < len(state.scripts) else ""

        # ---- 脚本列表 + 右侧竖列(自动打开开关 / 上移 / 下移 / 删除) ----
        row = layout.row(align=True)
        row.template_list(CH_AI_UL_scripts.__name__, "ch_ai_scripts", state, "scripts", state, "scripts_active_index", rows=max(_SCRIPT_ROWS_MIN, min(len(state.scripts), _SCRIPT_ROWS)))
        # 右侧竖列整列一次置灰(enabled 沿布局继承: 开关/排序/删除在列表为空时同灰)
        col = row.column(align=False)
        col.enabled = has_items
        col.prop(state, "use_auto_open_scripts", text="", icon='TEXT', toggle=True)
        # 排序两键紧凑成一组, 删除独立一行
        reorder = col.column(align=True)
        draw_operator(reorder, MoveListItem.bl_idname, 'SCRIPT', 'TRIA_UP', text="", direction='UP')
        draw_operator(reorder, MoveListItem.bl_idname, 'SCRIPT', 'TRIA_DOWN', text="", direction='DOWN')
        draw_operator(col, DeleteScript.bl_idname, None, 'X', text="", script_name=active_name)

        # ---- 所选脚本操作(点击列表行即聚焦编辑器, 无需打开按钮) ----
        row = layout.row(align=False)
        row.enabled = has_items
        draw_operator(row, DebugScript.bl_idname, None, 'ERROR', text="Debug", script_name=active_name)
        draw_operator(row, RunScript.bl_idname, None, 'PLAY', text="Run", script_name=active_name)

        # ---- 描述输入(长文描述块优先, 为空时采用单行输入; 行尾清除按钮) ----
        layout.separator(type='LINE')
        col = layout.column(align=False)
        prompt_row = col.row(align=True)
        prompt_row.prop(state, "prompt", text="Prompt")
        draw_operator(prompt_row, ClearPrompt.bl_idname, None, 'CANCEL_LARGE', text="")
        draw_long_desc_hint(col, AI_PROMPT_TEXT_NAME)
        # 编辑描述 / 优化提示词 / 完整提示词(与生成请求逐字一致的发送快照)
        row = col.row(align=True)
        draw_operator(row, EditPrompt.bl_idname, None, 'TEXT')
        row.separator(factor=0.5)
        draw_operator(row, OptimizePrompt.bl_idname, None, 'SHADERFX')
        row.separator(factor=0.5)
        draw_operator(row, ViewFullPrompt.bl_idname, None, 'WORDWRAP_ON')
        # 对话修改(依赖列表高亮) 与 生成脚本(恒可用) 同行
        row = col.row(align=True)
        revise_row = row.row(align=False)
        revise_row.enabled = has_items
        draw_operator(revise_row, ReviseScript.bl_idname, None, 'GREASEPENCIL', script_name=active_name)
        row.separator(factor=0.5)
        draw_operator(row, GenerateScript.bl_idname, None, 'KEY_RETURN')

        # ---- 末尾三段(与其余面板同款): 错误摘要 / 用量 / 等待进度 ----
        # 脚本面板的运行错误字段与其余面板不同(last_error_script / last_error_traceback)
        draw_error_box(layout, wm, 'SCRIPT', title_attr="last_error_script", detail_attr="last_error_traceback")
        draw_usage_hint(layout, state, 'script')
        draw_wait_box(layout, state, 'script')
