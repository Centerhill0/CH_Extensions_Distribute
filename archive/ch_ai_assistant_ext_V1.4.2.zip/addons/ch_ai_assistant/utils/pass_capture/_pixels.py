"""通道像素的读回与自编码(深度/法向/线稿的映射在此完成)"""

import bpy
import numpy as np
import os
import struct
import tempfile
import zlib


from ..errors import api_error


from ._constants import _EXTENSIONS, _PASS_FORMATS, _PNG_COMPRESS


from ._scene import _pass_file


from ._tmpdir import _drop_path


def _read_bytes(path: str) -> tuple:
    """读文件字节(通道图的最终产出即该文件的字节)"""
    try:
        with open(path, "rb") as f:
            return f.read(), None
    except OSError as e:
        return None, api_error("Failed to read the captured pass", e)


def _read_pass_pixels(path: str) -> tuple:
    """把通道文件(单层 EXR 或 PNG)读回 HxWxC float32 数组, 返回 (数组, 错误信息)

    深度/法向/线稿三个通道需要像素级后处理, 故回读原始值:
    深度背景为 camera.clip_end(远超 1, 写 LDR 会被钳), 法向是带符号原始向量(写 LDR
    负数被钳成 0 会整张全黑), 线稿的信息全在 alpha(见 _edge_bytes).
    色彩空间设 Non-Color 以取回文件里的原值(不做线性->sRGB 往返; alpha 不受色彩空间影响).
    """
    try:
        img = bpy.data.images.load(path, check_existing=False)
    except RuntimeError as e:
        return None, api_error("Failed to load the captured pass", e)
    try:
        try:
            img.colorspace_settings.name = 'Non-Color'
        except Exception:  # noqa: BLE001 - 老构建无该色彩空间时按默认读回
            pass
        width, height = img.size
        if width == 0 or height == 0:
            return None, api_error("Captured pass is empty")
        buf = np.empty(width * height * img.channels, dtype=np.float32)
        img.pixels.foreach_get(buf)
        return buf.reshape(height, width, img.channels), None
    finally:
        try:
            bpy.data.images.remove(img)
        except Exception:  # noqa: BLE001 - 数据块已被外部清理时忽略
            pass


def _read_crypto_slot(raw: bytes) -> tuple:
    """把一层 Cryptomatte 的原始 EXR 字节读回为 HxWxC float32 数组, 返回 (数组, 错误信息)

    与 _decode_raw 的差别: 那条路要的是**最终字节**(只有深度/法向/线稿需要映射),
    这里要的是**像素本身** —— 哈希与覆盖率都在浮点里, 必须原值读回(故全程 32bit float).
    """
    fd, tmp_path = tempfile.mkstemp(suffix=".exr", prefix="ch_ai_crypto_")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as f:
            f.write(raw)
        return _read_pass_pixels(tmp_path)
    finally:
        _drop_path(tmp_path)


def _quantize(arr: np.ndarray) -> np.ndarray:
    """0-1 浮点数组四舍五入量化为 uint8"""
    return (np.clip(arr, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def _encode_png(rows: np.ndarray) -> bytes:
    """HxWx3/4 uint8 数组编码为内存 PNG 字节(纯 zlib, 不落盘)

    深度/法向是回读 EXR 后在 numpy 内映射出来的, 没有现成文件可读, 故按 PNG 规范手工组块:
    IHDR(8bit RGB/RGBA) + IDAT(逐行前置过滤字节 0 的 zlib 流) + IEND.
    Blender 像素缓冲行序自下而上(原点左下), PNG 行序自上而下, 编码前须上下翻转,
    否则成图整体倒置(实测); 两通道共用本编码器, 翻转一次即全体修正.
    """
    height, width = rows.shape[:2]
    channels = rows.shape[2]
    color_type = 2 if channels == 3 else 6
    rows = rows[::-1]
    raw = b"".join(b"\x00" + rows[y].tobytes() for y in range(height))

    def chunk(tag: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", width, height, 8, color_type, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw, _PNG_COMPRESS)) + chunk(b"IEND", b"")


def _gray_to_rgb(gray01: np.ndarray) -> np.ndarray:
    """0-1 灰度(HxW)展开为 HxWx3"""
    return np.repeat(gray01[..., None], 3, axis=2)


def _depth_gray(pixels: np.ndarray, near: float, far: float, curve: str = 'LINEAR', background: float | None = None) -> np.ndarray:
    """EEVEE 深度(视空间 Z 米制, 背景 = camera.clip_end)按用户区间映射: 近端->1 远端->0

    线性曲线: 区间均分 256 级灰阶; 反深度曲线(INVERSE): 按 1/z(视差)在近端/远端锚定后
    线性化, 灰阶级数向近场集中(近处每米分到的级数远多于远景), 主体景深细节保留最多,
    与 ControlNet/MiDaS 等深度惯例一致; 深度值是米制距离, 背景像素(>= clip_end)置 0;
    近于近端的物体全部钳为 1, 远于远端的全部钳为 0(远端填 0 即"前景为 1 背景为 0"的目标语义);
    区间倒置时自动对调, 过窄/过近按 1e-6 兜底避免除零.
    """
    z = pixels[..., 0]
    if far < near:
        near, far = far, near
    if curve == 'INVERSE':
        near_safe = max(near, 1e-6)
        far_safe = max(far, near_safe + 1e-6)
        denom = 1.0 / near_safe - 1.0 / far_safe
        disp = 1.0 / np.maximum(z, 1e-6)
        depth = (disp - 1.0 / far_safe) / denom
    else:
        span = max(far - near, 1e-6)
        depth = 1.0 - (z - near) / span
    if background and background > 0:
        # EEVEE 的深度背景恒为 camera.clip_end(实测 clip_end=1000 -> 1000.55),
        # 几何体不会超出 clip_end, 故 >= 该值即为背景(留 0.1% 容差吸收浮点误差)
        depth = np.where(z >= background * 0.999, 0.0, depth)
    return np.clip(depth, 0.0, 1.0)


def _normal_bytes(pixels: np.ndarray, convention: str) -> bytes:
    """法向通道: 原始带符号向量 -> (n+1)/2 标准法线编码(背景法向 0 编码后为中灰)"""
    n = np.clip(pixels[..., :3], -1.0, 1.0).astype(np.float32, copy=True)
    if convention == 'DIRECTX':
        # DirectX 约定绿通道向下: 反转 G 后再做 (n+1)/2
        # (与 Blender 法向贴图节点对 DirectX 的处理一致, 即反转绿通道)
        n[..., 1] = -n[..., 1]
    return _encode_png(_quantize(n * 0.5 + 0.5))


def _edge_bytes(pixels: np.ndarray) -> bytes:
    """线稿通道: 笔画信息全在 alpha -> 按 1-alpha 映射为黑线白底

    实测本管线渲染写出的 Grease Pencil 通道像素 RGB 恒为 0,笔画信息全在 alpha
    (alpha 峰值 0.667, 抗锯齿边缘介于 0 与峰值之间); 故"白底黑线" = 灰阶 1-alpha:
    无笔画处 alpha=0 -> 纯白, 笔画核心处 alpha 最大 -> 最暗, 线性映射天然带抗锯齿.
    极少数构建若只回读 RGB(无 alpha 通道), 退化为按亮度取反(此时信息已在亮度里).
    """
    if pixels.shape[2] >= 4:
        line = 1.0 - pixels[..., 3]
    else:
        line = 1.0 - pixels[..., :3].mean(axis=2)
    return _encode_png(_gray_to_rgb(_quantize(line)))


def _decode_raw(key: str, raw: bytes, *, depth_near: float, depth_far: float, depth_curve: str, normal_convention: str, depth_background: float | None) -> tuple:
    """把通道的**原始落盘字节**转成最终参考图字节, 返回 (字节, 错误信息)

    深度/法向/线稿需要像素级后处理(原始字节写临时文件回读像素后在 numpy 内映射):
    深度按用户近/远区间映射灰阶, 法向按 (n+1)/2 编码, 线稿按 1-alpha 映射白底黑线;
    其余通道的原始字节即最终字节(直接返回).
    """
    if key not in ('depth', 'normal', 'edge'):
        return raw, None
    fd, tmp_path = tempfile.mkstemp(suffix=_EXTENSIONS[_PASS_FORMATS[key][0]], prefix="ch_ai_redecode_")
    os.close(fd)
    try:
        with open(tmp_path, "wb") as f:
            f.write(raw)
        pixels, err = _read_pass_pixels(tmp_path)
        if err is not None:
            return None, err
        if key == 'depth':
            gray = _quantize(_depth_gray(pixels, depth_near, depth_far, depth_curve, depth_background))
            return _encode_png(_gray_to_rgb(gray)), None
        if key == 'normal':
            return _normal_bytes(pixels, normal_convention), None
        return _edge_bytes(pixels), None
    finally:
        _drop_path(tmp_path)


def _decode_pass(key: str, path: str, *, depth_near: float, depth_far: float, depth_curve: str, normal_convention: str, depth_background: float | None) -> tuple:
    """把某通道的落盘文件转成最终参考图字节, 返回 (原始落盘字节, 最终字节, 错误信息)

    原始字节供增量捕获缓存(解码参数变化时免渲染重解码, 见 lookup_group_cache);
    色彩空间设 Non-Color 取回文件原值(见 _read_pass_pixels).
    """
    raw, err = _read_bytes(path)
    if err is not None:
        return None, None, err
    final, err = _decode_raw(key, raw, depth_near=depth_near, depth_far=depth_far, depth_curve=depth_curve, normal_convention=normal_convention, depth_background=depth_background)
    return raw, final, err


def _collect_frame(tmp_dir: str, entries: tuple, missing: list, passes: dict, decode_kwargs: dict, passes_raw: dict | None = None) -> list:
    """把一帧落盘的通道文件读成最终参考图字节写入 passes, 返回本帧提示消息列表

    entries 为 (通道键, 出线名) 表; missing 为本帧节点组已报出的缺失通道(不重复报告);
    逐通道的任何一步失败都只跳过该通道并追加提示, 不打断整次捕获;
    passes_raw 不为 None 时同步记录各通道的**原始落盘字节**(增量捕获缓存用,
    解码参数变化时免渲染重解码, 见 lookup_group_cache).
    """
    notices = []
    for key, _socket in entries:
        if any(key == skipped for skipped, _ in missing):
            continue
        path = _pass_file(tmp_dir, key, _PASS_FORMATS[key][0])
        if path is None:
            notices.append(api_error("The pass was not written by the render, it was skipped", key))
            continue
        raw, data, err = _decode_pass(key, path, **decode_kwargs)
        if err is not None:
            notices.append(api_error("The captured pass could not be read, it was skipped", key))
            continue
        passes[key] = data
        if passes_raw is not None and raw is not None:
            passes_raw[key] = raw
    return notices
