"""场景级蜡笔线稿的创建与回收(按 _constants 的线稿预设与线宽基准落到修改器开关)"""

import bpy
import numpy as np


from ..errors import api_error


from ._constants import EDGE_PRESETS, EDGE_PRESET_DEFAULT, _EDGE_RADIUS_FALLBACK, _EDGE_RADIUS_MAX, _EDGE_RADIUS_MIN, drop_silently, set_attr_safe


def _add_edge_gp(tmp, width_scale: float, material_borders: bool, edge_preset: str = EDGE_PRESET_DEFAULT) -> tuple:
    """添加场景级蜡笔(LINEART_SCENE)并设置线宽与线条类型, 返回 (GP 对象, 提示消息或 None)

    线宽基准取 _EDGE_RADIUS_FALLBACK(固定 0.01 世界单位 radius), 再乘用户的宽度缩放系数;
    线条类型按 edge_preset 落到修改器的 use_contour/use_loose/use_crease/use_edge_mark/
    use_intersection/use_shadow/use_light_contour(见 EDGE_PRESETS);
    材质边界开关落在 Lineart 修改器 use_material(控制材质之间是否生成笔画,
    默认关与修改器出厂默认一致).

    用户场景零修改(含选择态): 添加操作器默认把蜡笔链到**当前活动集合**并夺走选中集与
    活动物体(属用户场景侧, 实测确认), 故用 temp_override 把 scene/view_layer/collection
    三件套都指向临时场景——落点直接进临时场景主集合, 用户侧的选择态与活动物体原样保留.
    下方解绑/链接仍保留为兜底: 覆写未被操作器采纳的构建上依旧落回用户集合, 需要搬移.
    落点固定为原点: 场景级线稿的笔画经物体变换补偿(实测两种落点的**世界坐标完全一致**),
    落点与出图无关, 不再沿用探测期遗留的视口坐标.
    """
    known = set(bpy.data.objects)
    try:
        with bpy.context.temp_override(scene=tmp, view_layer=tmp.view_layers[0], collection=tmp.collection):
            bpy.ops.object.grease_pencil_add(type='LINEART_SCENE', align='WORLD', location=(0.0, 0.0, 0.0), scale=(1, 1, 1))
    except Exception:  # noqa: BLE001 - 物体上下文不可用(编辑模式等)时跳过边缘通道
        return None, api_error("Failed to add the line art grease pencil, the edge pass was skipped")
    # 按对象增量取新建的蜡笔: 覆写下活动物体落在临时场景视图层, 走全局 active 取不到
    gp = next((obj for obj in bpy.data.objects if obj not in known), None)
    if gp is None:
        return None, api_error("The line art grease pencil was not created, the edge pass was skipped")
    for col in list(gp.users_collection):
        col.objects.unlink(gp)
    tmp.collection.objects.link(gp)
    mod = gp.modifiers.get("Lineart")
    if mod is not None:
        # 固定基准线宽(0.01 世界单位)乘用户缩放系数, 钳到安全区间
        if hasattr(mod, "radius"):
            mod.radius = float(np.clip(_EDGE_RADIUS_FALLBACK * width_scale, _EDGE_RADIUS_MIN, _EDGE_RADIUS_MAX))
        # 材质边界: 材质之间是否生成笔画(开关缺失的旧构建按修改器默认)
        set_attr_safe(mod, "use_material", bool(material_borders))
        # 线条类型预设: 逐个落到修改器开关, 缺失的开关按修改器默认(不报错)
        for flag, value in EDGE_PRESETS.get(edge_preset, EDGE_PRESETS[EDGE_PRESET_DEFAULT]).items():
            set_attr_safe(mod, flag, value)
    return gp, None


def _remove_gp(gp) -> None:
    """回收蜡笔对象,数据块, 以及线条画自动挂上的材质

    实测 bpy.data.grease_pencils.remove() **不清材质**: 场景线条画会给蜡笔数据挂一个名为
    Black 的材质, 只删对象与数据块会在 bpy.data.materials 里留下 Black / Black.001 ...
    残骸(每次捕获 +1), 故先按材质槽快照, 删完数据块后再回收用户数归零的那些.
    只回收本次新建且已无人引用的材质, 绝不触碰用户材质(users > 0 一律跳过).
    """
    if gp is None:
        return
    data = gp.data
    mats = list(getattr(data, "materials", ()) or ()) if data is not None else []
    drop_silently(bpy.data.objects.remove, gp, do_unlink=True)
    if data is not None:
        drop_silently(bpy.data.grease_pencils.remove, data)
    for mat in mats:
        if mat is None:
            continue
        # 读取 users 失败与回收失败在旧实现里同属"跳过本次回收", 故两处都按尽力而为处理
        if _no_users(mat):
            drop_silently(bpy.data.materials.remove, mat)


def _no_users(block) -> bool:
    """数据块是否已无人引用; 引用失效时返回 False(按旧实现: 跳过回收, 不报错)

    比较必须保持 `block.users == 0` 原式, **不加 int() 转换**: 强转会让
    0.5 / '0' 这类非整数值从"跳过回收"变成"执行回收", 与原实现分叉
    (真实 bpy 的 .users 是整型, 该分支不可达, 但等价性不该依赖这个假设).
    """
    try:
        return block.users == 0
    except Exception:  # noqa: BLE001 - 引用失效视为不可回收
        return False
