"""本插件自有临时目录的建/清扫(捕获目录的落点与回收)"""

import os
import shutil
import tempfile
import time

_TMP_ROOT_NAME = "ch_ai_assistant_pass_capture"


def _tmp_root() -> str:
    """本插件自有临时根目录(所有捕获目录都建在其下, 便于只清扫自家的残留)"""
    return os.path.join(tempfile.gettempdir(), _TMP_ROOT_NAME)


def _drop_path(path) -> None:
    """尽力而为地删除文件/目录: 失败即放弃, 绝不影响捕获流程

    Windows 上刚写出的图片常被杀软实时扫描/索引器/缩略图预览瞬时占用,
    os.remove/rmtree 会抛 PermissionError(WinError 32); 短延时重试一次, 仍失败静默放弃.
    宿主系统是否会自动清理 %TEMP% 不可依赖(存储感知默认多在磁盘不足时触发且可关闭,
    %TEMP% 也没有"保留 N 天自动删除"的默认策略), 故主动收口.
    """
    if not path:
        return
    for attempt in (0, 1):
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            return
        except FileNotFoundError:
            return
        except OSError:
            if attempt == 0:
                time.sleep(0.05)
    return


def _sweep_tmp_root() -> None:
    """清扫本插件临时根目录下上一次捕获遗留的子目录(只动自家目录)

    删除失败/进程崩溃留下的残骸不允许跨次累积: 每次捕获开头先清一遍,
    即便上一次因占用没删干净, 也不会被本次捕获读到(每次捕获用全新唯一子目录).
    """
    root = _tmp_root()
    try:
        names = os.listdir(root)
    except OSError:
        return
    for name in names:
        _drop_path(os.path.join(root, name))


def _new_tmp_dir() -> str:
    """建本次捕获的唯一临时子目录(唯一目录可杜绝读到上一次残留的陈旧文件)"""
    root = _tmp_root()
    os.makedirs(root, exist_ok=True)
    return tempfile.mkdtemp(prefix="cap_", dir=root)
