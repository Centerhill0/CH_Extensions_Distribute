"""捕获分辨率与落盘体积估算(面板标签与真实输出同口径)"""

from ._constants import CRYPTO_SLOT_COUNT, CRYPTO_SLOT_KEYS, _CLAMP_EDGE_MAX, _PASS_FORMATS, _crypto_slots_used


def _render_size(rd) -> tuple:
    """实际渲染像素尺寸(分辨率乘百分比)"""
    scale = rd.resolution_percentage / 100.0
    return max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale))


def _clamped_percentage(rd, clamp_long_edge: int) -> int:
    """分辨率百分比: 钳制开启且长边超上限时等比下调, 否则沿用原值

    未开启钳制时直接用 Blender 输出属性(resolution_x/y 乘 resolution_percentage);
    开启后只在**超过上限**时钳制, 且经百分比等比缩放保证宽高比不变
    (渲染只支持整数百分比, 故结果可能略小于上限, 不会超过).
    """
    percentage = rd.resolution_percentage
    if clamp_long_edge <= 0:
        return percentage
    long_edge = max(rd.resolution_x, rd.resolution_y)
    if long_edge <= 0 or long_edge * percentage / 100.0 <= clamp_long_edge:
        return percentage
    return max(1, min(percentage, int(clamp_long_edge * 100 / long_edge)))


def _sane_clamp(clamp_long_edge) -> int:
    """规范化钳制上限: 非法值按不钳制, 并夹到防御性硬上限"""
    try:
        value = int(clamp_long_edge)
    except (TypeError, ValueError):
        return 0
    return min(max(value, 0), _CLAMP_EDGE_MAX)


def resolve_capture_size(scene, clamp_long_edge) -> tuple:
    """本次捕获会实际渲染的像素尺寸(宽, 高)

    面板标签与真实输出同口径: 未开启钳制时即 Blender 输出分辨率乘 resolution_percentage,
    开启后仅在超出上限时经百分比等比下调. 场景不可用时回落 (0, 0).
    """
    rd = getattr(scene, "render", None)
    if rd is None:
        return (0, 0)
    percentage = _clamped_percentage(rd, _sane_clamp(clamp_long_edge))
    scale = percentage / 100.0
    return (max(1, round(rd.resolution_x * scale)), max(1, round(rd.resolution_y * scale)))


def estimate_capture_bytes(size, keys, crypto_slots: int = CRYPTO_SLOT_COUNT) -> int:
    """估算所选通道落盘总体积(字节), 仅用于面板提示, 非精确值

    依据各通道的落盘规格估算每像素字节数: EXR 未压缩(实测 format.compression 对输出体积
    无影响)按 RGBA 四位深算, PNG/JPEG 为实测经验系数(通道图多为平涂/线稿, 压缩率较高);
    真实体积随画面复杂度浮动, 故面板文案标为估算.
    语义分割按当前 crypto_slots 展开成对应层数的 32bit EXR(层数变了估算要跟着变).
    """
    width, height = size if size else (0, 0)
    pixels = max(0, int(width) * int(height))
    if not pixels:
        return 0
    total = 0.0
    for key in keys:
        # 语义分割的实际落盘是若干层 32bit EXR(最终那张 PNG 由解码期在内存里生成, 不落盘)
        actual_keys = CRYPTO_SLOT_KEYS[: _crypto_slots_used(crypto_slots)] if key == 'segmentation' else (key,)
        for actual in actual_keys:
            spec = _PASS_FORMATS.get(actual)
            if spec is None:
                continue
            image_format, color_depth, _save_as_render = spec
            if image_format == 'OPEN_EXR':
                total += pixels * (8.0 if color_depth == '16' else 16.0)
            elif image_format == 'JPEG':
                total += pixels * 0.3
            else:
                total += pixels * 1.0
    return int(total)
