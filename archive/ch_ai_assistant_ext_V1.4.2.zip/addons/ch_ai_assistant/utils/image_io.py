"""
图像 IO 工具模块

生成图片字节的加载, 无缝化处理, 命名, 存盘与图像编辑器聚焦.

主要功能:
- load_image_from_bytes: 图片字节经临时文件加载为图像数据块(随即打包并删临时文件)
- save_image_file: 图像数据块另存为 PNG 到指定目录
- image_to_png_bytes: 图像数据块编码为 PNG 字节(临时文件往返, 结束后还原路径属性)
- image_to_scaled_png_bytes: 图像数据块编码为 PNG 字节, 最长边超限时缩放**副本**上传
- make_seamless: 边缘羽化镜像混合, 把图片字节处理为像素级可平铺的无缝图(尺寸不变)
- prompt_stem: 提示词转短名(英文词组), 无英文词回落空串
- unique_ai_name: 生成图像数据块的不冲突名(冲突加 .00N 序号)
- focus_image_editors: 把所有图像编辑器区域聚焦到指定图像
"""

import os
import re
import tempfile

import numpy as np

import bpy
from bpy.types import Context, Image

from .errors import api_error

# 无缝化羽化带占单边宽/高的比例(两端各一条, 带宽保底 1 像素, 上限为单边的 1/4)
_SEAMLESS_FEATHER = 0.15
# 无缝处理的峰值内存上限(字节): 约 4 份 RGBA float32, 超过即拒绝(4K 约 1.1 GB)
_SEAMLESS_MAX_BYTES = 1536 * 1024 * 1024


def _image_suffix(image_bytes: bytes) -> str:
    """按魔数嗅探图片格式后缀(PNG/JPEG), 未知回落 .png"""
    if image_bytes.startswith(b"\x89PNG"):
        return ".png"
    if image_bytes.startswith(b"\xff\xd8"):
        return ".jpg"
    return ".png"


def load_image_from_bytes(image_bytes: bytes, name: str) -> tuple:
    """把图片字节写入临时文件并加载为图像数据块, 返回 (Image 数据块, 错误信息)

    载入后打包进 blend 并删除临时文件(数据块自包含, 跨机不丢图);
    重名时 Blender 自动追加 .001 序号, 调用方以返回的 image.name 为准.
    """
    if not image_bytes:
        return None, api_error("Image data is empty")
    fd, path = tempfile.mkstemp(suffix=_image_suffix(image_bytes), prefix="ch_ai_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(image_bytes)
        image = bpy.data.images.load(path)
    except (OSError, RuntimeError) as e:
        try:
            os.remove(path)
        except OSError:
            pass
        return None, api_error("Generated image data is invalid", e)
    # 非图片字节(错误页/截断下载体)会被 Blender 静默载成 0x0 空块而不抛异常,
    # 不校验就会当成功返回, 调用方随后报"已创建"却得到空图
    width, height = image.size
    if not image.has_data or width == 0 or height == 0:
        bpy.data.images.remove(image)
        try:
            os.remove(path)
        except OSError:
            pass
        return None, api_error("Generated image data could not be decoded")
    try:
        image.name = name
        image.pack()
    except (OSError, RuntimeError) as e:
        # 打包失败也要收口(裁决⑪): 回收已创建的图像块与临时文件, 元组契约不被打破
        bpy.data.images.remove(image)
        try:
            os.remove(path)
        except OSError:
            pass
        return None, api_error("Failed to save image", e)
    try:
        os.remove(path)
    except OSError:
        pass  # 临时文件删除失败无害(位于系统临时目录)
    return image, None


def sanitize_image_file_name(name: str) -> str:
    """图像数据块名转文件名词干: 非法字符折叠为下划线(存盘与改名共用同一规则, 单一来源)"""
    return re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_") or "ai_image"


def save_image_file(image: Image, directory: str) -> tuple:
    """把图像数据块存为 PNG 到指定目录, 返回 (文件路径, 错误信息)

    文件名取图像数据块名(非法字符转下划线, 见 sanitize_image_file_name); 同名文件已存在
    时追加 `-N` 序号, 不覆盖用户已有文件.
    """
    try:
        os.makedirs(directory, exist_ok=True)
        stem = sanitize_image_file_name(image.name)
        path = os.path.join(directory, f"{stem}.png")
        num = 1
        while os.path.exists(path):
            path = os.path.join(directory, f"{stem}-{num}.png")
            num += 1
        image.filepath_raw = path
        image.file_format = 'PNG'
        image.save()
    except (OSError, RuntimeError) as e:
        return None, api_error("Failed to save image", e)
    return path, None


def _cached_png_bytes(image: Image) -> bytes | None:
    """直接取已有 PNG 字节(打包数据或磁盘原文件), 避免 save() 的临时文件往返

    生成图通常已打包为 PNG; 磁盘 PNG 且未修改时原文件就是最终字节. 两条快路径都
    不触碰 `filepath_raw/file_format`, 也就不会触发额外的 depsgraph 更新.
    """
    packed = getattr(image, "packed_file", None)
    # 打包字节只在未修改时可信: 图像编辑器里画过/改过像素(is_dirty)后必须重新编码,
    # 否则上传的是打包那一刻的旧图
    if packed is not None and image.file_format == 'PNG' and not image.is_dirty:
        try:
            return bytes(packed.data)
        except (AttributeError, RuntimeError, TypeError):
            return None
    if image.source == 'FILE' and not image.is_dirty and image.filepath.lower().endswith(".png"):
        path = bpy.path.abspath(image.filepath)
        try:
            if os.path.isfile(path):
                with open(path, "rb") as handle:
                    return handle.read()
        except OSError:
            return None
    return None


def image_to_png_bytes(image: Image, use_cached: bool = True) -> tuple:
    """把图像数据块编码为 PNG 字节(优先复用已有 PNG 字节, 否则临时文件往返), 返回 (字节, 错误)

    use_cached=False 用于"像素已被改动但 packed_file 仍是旧数据"的副本(缩放图),
    此时必须真正重新编码.
    """
    if use_cached:
        cached = _cached_png_bytes(image)
        if cached is not None:
            return cached, None
    fd, path = tempfile.mkstemp(suffix=".png", prefix="ch_ai_src_")
    os.close(fd)
    raw_path, raw_format = image.filepath_raw, image.file_format
    try:
        image.filepath_raw = path
        image.file_format = 'PNG'
        image.save()
        with open(path, "rb") as f:
            return f.read(), None
    except (OSError, RuntimeError) as e:
        return None, api_error("Failed to read the source image", e)
    finally:
        image.filepath_raw, image.file_format = raw_path, raw_format
        try:
            os.remove(path)
        except OSError:
            pass


def image_to_scaled_png_bytes(image: Image, limit_edge: int) -> tuple:
    """图像数据块编码为 PNG 字节, 最长边超 limit_edge 时复制缩放后编码再删副本

    缩放只作用于副本, 用户原图数据块零改动(参考图上传预处理, 编码沿用 image_to_png_bytes);
    limit_edge <= 0 表示不限, 原图直接编码.
    """
    width, height = image.size
    source = image
    copy = None
    try:
        if limit_edge > 0 and max(width, height) > limit_edge:
            scale = limit_edge / max(width, height)
            copy = image.copy()
            try:
                copy.scale(max(2, round(width * scale)), max(2, round(height * scale)))
            except (RuntimeError, OSError) as e:
                # 无像素缓冲的副本 scale 会抛(裁决⑪): 回收副本并走错误信息元组
                return None, api_error("Failed to read the source image", e)
            source = copy
        # 缩放副本的 packed_file 可能仍是原图字节, 不能走缓存快路径
        return image_to_png_bytes(source, use_cached=copy is None)
    finally:
        if copy is not None:
            bpy.data.images.remove(copy)


def _edge_feather_alpha(length: int) -> np.ndarray:
    """平铺羽化权重(0-1, 长度 length): 两端各 FEATHER_RATIO 带内线性过渡, 中段恒 1

    中段保持 1 意味着只把两端各一条窄带替换为滚转内容(接缝处必然连续),
    原图主体不被重影; 带宽按尺寸比例取整并保底 1 像素.
    """
    alpha = np.ones(length, dtype=np.float32)
    band = max(1, min(length // 4, int(round(length * _SEAMLESS_FEATHER))))
    ramp = np.linspace(0.0, 1.0, band + 1, dtype=np.float32)[:-1]
    alpha[:band] = ramp
    alpha[length - band :] = ramp[::-1]
    return alpha


def make_seamless(image_bytes: bytes) -> tuple:
    """把图片字节做边缘羽化无缝化, 输出像素级可平铺的图(尺寸不变), 返回 (图片字节, 错误信息)

    原理: 两端各一条窄带(总宽约 2*FEATHER_RATIO)与半宽滚转内容按线性权重混合, 中段原样保留;
    平铺边界两侧恰为原图中部相邻内容, 必然连续; 代价是窄带内出现中部内容的滚转呼应.
    提示词引导无法保证服务端真出无缝图, 本地处理兜底保证可平铺.
    """
    fd, path = tempfile.mkstemp(suffix=_image_suffix(image_bytes), prefix="ch_ai_src_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(image_bytes)
        image = bpy.data.images.load(path)
    except (OSError, RuntimeError) as e:
        # 与 load_image_from_bytes 同款收口: 载入失败也要删掉临时文件,
        # 否则每次服务端返回坏图都在 %TEMP% 留一份残留(该分支正是坏图时才会走到).
        # fd 已交给 fdopen 时随 with 关闭; fdopen 自身抛错(此时 fd 未托管)则在此补关.
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.remove(path)
        except OSError:
            pass
        return None, api_error("Generated image data is invalid", e)

    out_img = None
    fd2, path2 = tempfile.mkstemp(suffix=".png", prefix="ch_ai_seam_")
    os.close(fd2)
    try:
        width, height = image.size
        # 峰值估算按 80 B/px(16*5): 缓冲 16 + 水平/垂直 blend 链约 60 —— 原系数 4 份(64 B/px)
        # 低估约 1.2 倍(裁决⑫), 贴上限的大图在紧内存机器有 OOM 余量不足风险;
        # 超大图直接拒绝, 避免进程被 OOM 杀掉(提示用户先降分辨率)
        if width * height * 16 * 5 > _SEAMLESS_MAX_BYTES:
            return None, api_error("Image is too large to make seamless")
        buf = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(buf)
        rgb = buf.reshape(height, width, 4)[..., :3]
        # 水平方向: 两端羽化带取半宽滚转内容, 中段保留原图
        wx = _edge_feather_alpha(width)
        blended_x = rgb * wx[None, :, None] + np.roll(rgb, width // 2, axis=1) * (1.0 - wx)[None, :, None]
        del rgb
        # 垂直方向同法
        wy = _edge_feather_alpha(height)
        blended = blended_x * wy[:, None, None] + np.roll(blended_x, height // 2, axis=0) * (1.0 - wy)[:, None, None]
        del blended_x
        out = np.ones((height, width, 4), dtype=np.float32)
        out[..., :3] = blended
        del blended

        out_img = bpy.data.images.new("CH_AI_Seamless", width, height, alpha=False)
        # colorspace sRGB: 像素(线性)编码落盘, 与 load 的默认识别一致, 往返还原线性值
        out_img.colorspace_settings.name = 'sRGB'
        out_img.filepath_raw = path2
        out_img.file_format = 'PNG'
        out_img.pixels.foreach_set(out.ravel())
        out_img.save()
        with open(path2, "rb") as f:
            return f.read(), None
    except (OSError, RuntimeError, ValueError) as e:
        return None, api_error("Failed to make the image seamless", e)
    finally:
        bpy.data.images.remove(image)
        if out_img is not None:
            bpy.data.images.remove(out_img)
        for p in (path, path2):
            try:
                os.remove(p)
            except OSError:
                pass


def prompt_stem(prompt: str, words: int = 8) -> str:
    """提示词转短名(取前 words 个英文词, 非法字符转下划线), 无英文词回落空串由调用方取默认名"""
    filtered = re.sub(r"[^A-Za-z0-9_ -]+", " ", prompt).split()
    if not filtered:
        return ""
    return "_".join(filtered[:words])[:48]


def unique_ai_name(base: str) -> str:
    """图像数据块不冲突名: 同名时追加 .00N 序号(与 Blender 自动去重同格式)"""
    if base not in bpy.data.images:
        return base
    idx = 1
    while f"{base}.{idx:03d}" in bpy.data.images:
        idx += 1
    return f"{base}.{idx:03d}"


def focus_image_editors(context: Context, image: Image) -> tuple:
    """把所有图像编辑器区域的活动图像设为指定图像, 返回 (聚焦区域数, 错误信息)"""
    focused = 0
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = image
                focused += 1
    return focused, None
