"""
AI 图像服务客户端工具模块

文生图与参考图生图的单次请求(火山方舟 Seedream 与阿里百炼千问双适配), 提示词模板组装.

主要功能:
- build_texture_prompt: 纹理提示词模板(无缝平铺引导可选)
- build_render_prompt: 相机效果图提示词模板(说明各参考图含义, 要求保持构图)
- request_image: urllib 单次图像请求(含可选随机种), 统一返回图片字节(文生图/参考图生图共用)
- resolve_output_size: 自定义宽高按服务商/模型约束修正(Seedream 与 Qwen-Image 各自规则)
- ref_image_limits: 服务商参考图输入限制(张数, 最长边像素), 偏好里的自定义值逐字段覆盖, 0 = 跟随官方
- resolve_ref_limits: 按面板生效服务商解析参考图限制(偏好自定义值仅对同服务商生效)
- output_limits: 服务商输出图像限制(仅供偏好面板文本提醒)
- resolve_image_endpoint: 按服务商解析 (base_url, api_key)(预设服务商取固定端点, CUSTOM 取偏好配置)
"""

import json

from .http_client import post_json
from .errors import api_error
from .prompts import (
    LEAK_ROLE_NAMES,
    NORMAL_CONVENTION_NOTES,
    PASS_ROLES,
    PASS_ROLES_COMPACT,
    TEXTURE_BASE_SUFFIX,
    TEXTURE_SEAMLESS_SUFFIX,
)
from .provider_registry import IMAGE_PROVIDERS, get_image_provider

# 预设服务商的默认模型(自服务商注册表派生, 单一来源, 加商无需手改此处):
# 取轻量档, 供偏好与面板的生效模型兜底链使用(见 image_common.resolve_image_model).
PROVIDER_DEFAULT_MODELS = {key: p.default_model_t2i for key, p in IMAGE_PROVIDERS.items()}


def resolve_panel_image_model(state, prefs, panel_attr: str, fallback_attr: str) -> str:
    """面板图像模型统一兜底链: GLOBAL(跟随偏好)取偏好模型; 覆盖服务商取面板下拉,
    空则回落该服务商的预设默认模型(图像生成器三模式共用单一来源).

    调用方传面板覆盖字段与偏好字段: 图像生成器为 panel_model / image_model_t2i.
    属 utils 内部协作 API(不进公共 __all__).
    """
    if state.service_mode == 'GLOBAL':
        return getattr(prefs, fallback_attr)
    return getattr(state, panel_attr) or PROVIDER_DEFAULT_MODELS.get(state.service_mode) or getattr(prefs, fallback_attr)


def _join_names(names: list) -> str:
    """自然语言并列: 两个用 and, 三个以上逗号加 and"""
    if len(names) <= 1:
        return names[0] if names else ""
    if len(names) == 2:
        return f"{names[0]} and {names[1]}"
    return ", ".join(names[:-1]) + f" and {names[-1]}"


def _style_clause(start: int, descriptions: list, compact: bool) -> str:
    """风格参考图职责声明(排在通道图之后, 逐张一条): 用户描述拼入各自条目

    有描述时描述进括号补充("Image 8 is a style reference (warm dusk lighting): ..."),
    无描述回落通用措辞; 逐张条目保证每张图与自己的描述一一对应.
    """
    parts = []
    for idx, desc in enumerate(descriptions, start):
        desc = (desc or "").strip()
        if compact:
            inner = f"{desc}, palette and mood only" if desc else "palette and mood only"
            parts.append(f"Image {idx}: style reference ({inner})")
        elif desc:
            parts.append(f"Image {idx} is a style reference ({desc}): " "take its palette and mood, not its content")
        else:
            parts.append(f"Image {idx} is a style reference: " "take its palette and mood, not its content")
    return "".join(", " + part for part in parts)


def _leak_clause(pass_names: list, compact: bool) -> str:
    """非照片通道反泄漏句: 仅列实际勾选的通道, 通道图"只作结构/明暗参考, 勿画入画面" """
    leak = [LEAK_ROLE_NAMES[name] for name in pass_names if name in LEAK_ROLE_NAMES]
    if not leak:
        return ""
    names = _join_names(leak)
    if compact:
        return f" Treat the {names} maps as structure guides only, do not render their appearance."
    if len(leak) == 1:
        return f" Use the {names} map as a structure and shading guide only, " "do not render its grayscale, lines or flat colors as content."
    return f" Use the {names} maps as structure and shading guides only, " "do not render their grayscale, lines or flat colors as content."


def build_texture_prompt(prompt: str, seamless: bool, ref_descriptions: list | None = None, kind: str = 'texture') -> str:
    """纹理/图像生成提示词: 纹理模式追加平铺/视角/光照引导模板(seamless 开启时要求可无缝平铺)

    ref_descriptions 非空时(参考图生图)追加参考图职责声明段: 单张直接以
    "Reference image: 描述" 点名(不作 "Image 1" 编号, 无编排意义), 多张逐条
    "Image N: 描述"(空描述回落通用措辞); 结尾句把视觉方向导向参考图,
    且 seamless 开启时补一句**重绘指令**——压平参考图的透视与机位,去掉光照变化,
    只保留表面材质与图案并铺满整幅(参考图本身是平铺纹理时该句等同于无操作;
    是透视照片时这是产出可重复图案的关键要求).
    kind 决定口吻与结尾名词('texture' 出贴图引导与 texture, 'image' 不加贴图引导).
    """
    if kind == 'texture':
        suffix = TEXTURE_SEAMLESS_SUFFIX if seamless else TEXTURE_BASE_SUFFIX
        text = f"{prompt.strip().rstrip(',.，。')}{suffix}"
    else:
        text = prompt.strip()
    if not ref_descriptions:
        return text
    noun = "texture" if kind == 'texture' else "image"

    def _role(description: str) -> str:
        return description.strip() or f"visual reference for the {noun}"

    if len(ref_descriptions) == 1:
        lines = [text, "", f"Reference image: {_role(ref_descriptions[0])}."]
        follow = f"Follow it for the visual direction of the {noun}, " "and the description above for the content."
    else:
        lines = [text, "", "Reference images:"]
        for idx, description in enumerate(ref_descriptions, 1):
            lines.append(f"Image {idx}: {_role(description)}")
        follow = f"Follow the reference images for the visual direction of the {noun}, " "and the description above for the content."
    if seamless:
        follow += " Redraw the reference into a seamless tileable pattern: flatten its " "perspective and camera angle, remove lighting variation, and keep only " "the surface material, color and pattern, filling the entire frame."
    lines.append(follow)
    return "\n".join(lines)


def _closing_clause(pass_names: list, compact: bool) -> str:
    """构图基准与重绘指令: 引用**实际序号**的合并结果作为构图基准

    合并结果在场(通常为首项)时引用其 Image N; 用户放宽后可不勾选 Combined——
    此时所有通道同相机视图, 改说"参考图组"(不说 Image 1, 那可能是深度图).
    """
    if not pass_names:
        return "Generate the scene as described above."
    base = f"Image {pass_names.index('combined') + 1}" if 'combined' in pass_names else "the reference views (same camera)"
    if compact:
        return f"Keep the composition of {base} and restyle the scene as described above."
    return f"Keep the camera composition and object placement of {base}, " "restyle the scene as described above."


def build_render_prompt(prompt: str, pass_names: list, style_descriptions: list | None = None, compact: bool = False, normal_convention: str = 'OPENGL') -> str:
    """效果图提示词: 说明各参考图含义并要求保持相机构图(预算紧张时可用精简档)

    pass_names 为有序通道键列表('combined'/'depth'/'normal'/'segmentation'/'edge'/'diffuse'/'ao'),
    顺序必须与请求携带的参考图数组一致(同一列表驱动提示词枚举与参考图数组, 结构性保证一致);
    style_descriptions 为附加的风格参考图描述列表(排在通道图之后, 参与序号编排,
    每张的描述拼进各自的职责声明; None/[] 表示无风格图);
    compact 为精简档(角色短语与反泄漏句缩短且**不带**通道约定描述, 供超硬预算自动降档用);
    normal_convention 为面板的法向约定(完整档拼进 normal 条目, 精简档省略).
    """
    roles = PASS_ROLES_COMPACT if compact else PASS_ROLES
    described = ", ".join((f"Image {idx}: {roles.get(name, name)}" if compact else f"Image {idx} is {roles.get(name, name)}{(NORMAL_CONVENTION_NOTES.get(normal_convention, '') if name == 'normal' else '')}") for idx, name in enumerate(pass_names, 1))
    described += _style_clause(len(pass_names) + 1, style_descriptions or [], compact)
    closing = _closing_clause(pass_names, compact) + _leak_clause(pass_names, compact)
    reference = f"Reference images: {described}. " if described else ""
    return f"{prompt.strip()}\n\n{reference}{closing}"


# 提示词 token 预算 (上限, 是否硬截断) 现已由服务商注册表提供(见 utils/provider_registry):
# 百炼正向提示词超限**静默截断**——硬预算, 超限时自动降精简档尽量保住引导句;
# 方舟 Seedream 无硬上限——软预算, 只警示不降档; CUSTOM 未知, 0 = 不估算


def prompt_token_budget(provider: str) -> tuple:
    """服务商提示词 token 预算 (上限, 是否硬截断), 未知服务商返回 (0, False) 即不估算

    上限为近似值: 官方按 Token 计, 插件按字符近似估算(见 estimate_prompt_tokens),
    仅用于面板警示与自动降档, 与服务端计数有出入属预期.
    """
    p = get_image_provider(provider)
    return (p.token_budget, p.token_hard)


def estimate_prompt_tokens(text: str) -> int:
    """提示词 token 近似估算: CJK 字符(含中文标点)约 1 token, 其余约 0.25 token

    CJK 判定含全角标点区(\\u3000-\\u303f 中文标点/\\uff00-\\uffef 全角形式)——中文标点
    在分词器里同样约 1 token, 不计入会低估超限风险(估算偏保守, 不会漏报超限);
    仅用于面板警示与降档判定, 非服务端精确计数.
    """
    cjk = sum(1 for ch in text if '\u3000' <= ch <= '\u9fff' or '\uff00' <= ch <= '\uffef')
    return cjk + (len(text) - cjk) // 4


# token 估算的记忆化: 面板 draw 每帧重绘都会对组装出的全文跑一遍逐字符纯 Python 扫描,
# 是 token 摘要链的主导成本(MB 级文本达百毫秒级); 组装出的全文每次都是新 str, 按
# (长度, 哈希) 记忆化——哈希为 C 速且内容一变键即失效, 无需人工失效
_TOKEN_ESTIMATE_CACHE: dict = {"key": None, "tokens": 0}


def estimate_prompt_tokens_cached(text: str) -> int:
    """estimate_prompt_tokens 的 (长度, 哈希) 记忆化版(面板 draw 热路径专用)"""
    key = (len(text), hash(text))
    if _TOKEN_ESTIMATE_CACHE["key"] == key:
        return _TOKEN_ESTIMATE_CACHE["tokens"]
    tokens = estimate_prompt_tokens(text)
    _TOKEN_ESTIMATE_CACHE["key"] = key
    _TOKEN_ESTIMATE_CACHE["tokens"] = tokens
    return tokens


def resolve_render_prompt(prompt: str, pass_names: list, style_descriptions: list | None = None, provider: str = 'CUSTOM', normal_convention: str = 'OPENGL') -> tuple:
    """组装最终发送提示词, 返回 (最终文本, 是否超预算)

    硬预算服务商(百炼)超限时自动降精简档重组, 仍超则返回精简档文本并标记超预算;
    软预算服务商(方舟)恒用完整档只标记; 无预算(CUSTOM)恒用完整档不标记.
    发送与预览共用本函数, 保证"预览即发送".
    """
    limit, is_hard = prompt_token_budget(provider)
    text = build_render_prompt(prompt, pass_names, style_descriptions, compact=False, normal_convention=normal_convention)
    if limit <= 0:
        return text, False
    if estimate_prompt_tokens_cached(text) <= limit:
        return text, False
    if not is_hard:
        return text, True
    compact = build_render_prompt(prompt, pass_names, style_descriptions, compact=True)
    return compact, estimate_prompt_tokens_cached(compact) > limit


def ref_image_limits(provider: str, override=None) -> tuple:
    """服务商的参考图输入限制 (张数, 最长边像素)

    override 为偏好面板里的自定义二元组, **逐字段**生效: 该字段 <= 0 或非法即取该服务商的
    官方上限.故 0 的语义是"跟随官方上限"——自定义服务商的官方值本就是 0/0, 于是它的 0 就是
    不限(原样交服务端裁决).
    这样设计是为了**升级安全**: 不在偏好里存一份"官方数字的快照", 换服务商/升级时不会把甲的
    限制错当乙的默认(旧写法把方舟 10/6000 写死为属性默认值, 百炼档会一直停在方舟数字上).
    """
    p = get_image_provider(provider)
    official_count, official_edge = p.ref_count, p.ref_edge
    if override is None:
        return (official_count, official_edge)
    try:
        count, edge = (int(value) for value in override)
    except (TypeError, ValueError):
        return (official_count, official_edge)
    return (count if count > 0 else official_count, edge if edge > 0 else official_edge)


def resolve_ref_limits(provider: str, prefs) -> tuple:
    """按生效服务商解析参考图限制 (张数, 最长边像素), 已并入偏好里的自定义值

    provider 为**面板生效服务商**(可被面板的覆盖档改成非偏好中的那个): 偏好里那组自定义
    数字只在 provider 与偏好服务商一致时才属于该服务商, 否则一律回落该服务商的内置默认,
    避免把甲服务商的限制错安到乙服务商头上.
    """
    override = None
    if provider == prefs.image_provider:
        override = (prefs.image_ref_count, prefs.image_ref_edge)
    return ref_image_limits(provider, override)


def output_limits(provider: str):
    """服务商输出图像限制元组(未知服务商返回 None)

    返回 (单边下限, 单边上限, 总像素下限, 总像素上限, 最宽宽高比), 供偏好面板拼提醒文案.
    """
    return get_image_provider(provider).output_limits


def format_size(provider: str, width: int, height: int) -> str:
    """输出宽高转服务商尺寸字符串(方舟 x 分隔, 百炼 * 分隔)"""
    sep = get_image_provider(provider).size_sep
    return f"{width}{sep}{height}"


def resolve_output_size(provider: str, model: str, width: int, height: int) -> tuple:
    """把面板的自定义宽高修正为当前服务商/模型支持的输出尺寸, 返回 (宽, 高)

    约束见服务商注册表(utils/provider_registry); CUSTOM 服务商不做修正, 原样下发给服务端裁决.
    """
    return get_image_provider(provider).resolve_size(model, width, height)


def resolve_image_endpoint(provider: str, prefs) -> tuple:
    """按生效服务商解析 (base_url, api_key): 预设服务商端点固定, 密钥各存一把, CUSTOM 取偏好通用配置"""
    p = get_image_provider(provider)
    base_url = p.base_url if p.base_url else prefs.image_base_url
    api_key = getattr(prefs, p.api_key_attr, "")
    return base_url, api_key


def _inline_error(data: dict):
    """从 200 响应体内提取服务端错误描述(部分服务把错误放响应体而非 HTTP 状态码)

    返回错误对象或 None; 服务端返回的 code/message 属动态内容, 放 detail 原样透出.
    """
    err = data.get("error")
    if isinstance(err, dict) and (err.get("code") or err.get("message")):
        return api_error("API error", f"{err.get('code', '')} {err.get('message', '')}".strip())
    if isinstance(err, str) and err.strip():
        return api_error("API error", err.strip())
    if data.get("code") and data.get("message"):
        return api_error("API error", f"{data['code']} {data['message']}")
    return None


def request_image(base_url: str, api_key: str, model: str, prompt: str, timeout: float, provider: str = 'CUSTOM', size: str | None = None, ref_images: list | None = None, seed: int = 0, negative_prompt: str = "") -> tuple:
    """单次图像生成请求(文生图或参考图生图), 不自动重试; 返回 (图片字节, 错误信息)

    provider 决定请求体格式与取图路径(见服务商注册表): 方舟/自定义走 OpenAI images 风格,
    百炼走 multimodal-generation; CUSTOM 不下发 watermark/response_format/seed 等额外参数;
    size 格式由调用方按服务商拼接; ref_images 为 JPEG/PNG 字节列表, 顺序即参考优先序;
    seed 为随机种(0 = 每次随机); negative_prompt 为负向提示词(仅支持者下发).
    """
    p = get_image_provider(provider)
    url = base_url.rstrip('/') + p.endpoint_path
    payload = p.build_payload(model, prompt, size, ref_images, seed, negative_prompt)
    body = json.dumps(payload).encode("utf-8")
    data, err = post_json(url, body, api_key, timeout)
    if err is not None:
        return None, err

    if not isinstance(data, dict):
        return None, api_error("Unexpected API response format")
    inline = _inline_error(data)
    if inline is not None:
        return None, inline
    return p.parse_response(data, timeout)
