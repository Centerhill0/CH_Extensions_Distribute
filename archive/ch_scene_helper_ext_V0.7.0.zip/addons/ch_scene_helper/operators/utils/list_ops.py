"""
列表动作算子模块

提供以下功能:
- ListMove: 上移/下移列表活跃项(顺序值写数据块自定义属性, 随 blend 持久; 高亮跟随被移动项)
- ListSort: 一键按名称排序(顺序值写数据块自定义属性)
- ObjectDelete: 删除列表活跃项对应的物体(相机/灯光列表)

列表顺序值算法见 common.blender.list_order: 挂数据块自定义属性 ch_scene_order,
collect 按 order_key 排序; 移动/排序只改写顺序值, 由 refresh_lists 立即重建快照.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import Context, Operator

from .....common.blender.list_order import materialize_orders, order_key, swap_orders
from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import LIST_SPECS, all_blocks_for, blocks_for, filter_sort_flags, get_state
from ...utils import is_runtime_image

# 列表种类枚举(显示名由种类标识标题化, 与面板标题一致)
_LIST_KIND_ITEMS = tuple((kind, kind.title(), "") for kind in LIST_SPECS)
_OBJECT_LIST_ITEMS = (("lights", "Lights", ""), ("cameras", "Cameras", ""))


def _cancel_stale(op: Operator) -> set:
    """列表条目已失效: 报告后返回取消结果"""
    op.report({'WARNING'}, report("List item is no longer in the scene"))
    return {'CANCELLED'}


def _has_stale_block(context: Context, kind: str, blocks: list) -> bool:
    """快照里是否存在失效条目(IES 显示行本就不是图像数据块, 不算失效)"""
    spec = LIST_SPECS[kind]
    items = getattr(get_state(context), spec.collection)
    return any(item.kind != 'IES' and block is None for item, block in zip(items, blocks))


class ListMove(Operator):
    """上移/下移列表活跃项(交换相邻项的顺序值, 顺序随 blend 文件持久)"""

    bl_idname = "ch.list_move"
    bl_label = "Move List Item"
    bl_description = "Move the active list item up or down (order saved in the blend file)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_LIST_KIND_ITEMS, default="lights")  # type: ignore
    move_down: BoolProperty(name="Move Down", default=False)  # type: ignore

    def execute(self, context: Context):
        spec = LIST_SPECS[self.list_kind]
        state = get_state(context)
        coll = getattr(state, spec.collection)
        idx = getattr(state, spec.index)
        if not coll or not 0 <= idx < len(coll):
            return {'CANCELLED'}
        alpha, reverse = filter_sort_flags(state, self.list_kind)
        if alpha:
            # 字母排序时显示序由名称决定, 交换顺序值不会改变可见顺序; 先关掉再手动移动
            self.report({'WARNING'}, report("Turn off alphabetical sorting to move items manually"))
            return {'CANCELLED'}
        # 按**显示顺序**换算相邻项: 反序开启时"下移"对应快照里的前一项
        display = list(range(len(coll)))
        if reverse:
            display.reverse()
        pos = display.index(idx)
        new_pos = pos + 1 if self.move_down else pos - 1
        if not 0 <= new_pos < len(display):
            return {'CANCELLED'}
        target = display[new_pos]
        blocks = blocks_for(context, self.list_kind)
        # IES 显示行(图像列表尾部)不是图像数据块, 运行期图像(Render Result/合成 Viewer)
        # 钉在列表前两位: 两者都不参与移动, 静默取消(与边界同口径)——运行期图像没有顺序值,
        # 交换会把 None 塞进自定义属性. IES 判定须先于失效检查: 它本就解析不出数据块,
        # 先查失效会把纯显示行误报成"条目已失效"
        for item, block in ((coll[idx], blocks[idx]), (coll[target], blocks[target])):
            if item.kind == 'IES' or (item.kind == 'IMAGE' and block is not None and is_runtime_image(block)):
                return {'CANCELLED'}
        if blocks[idx] is None or blocks[target] is None:
            return _cancel_stale(self)
        # 全量物化(含被过滤的 0 用户项), 保证顺序值唯一; 只交换可见的两个相邻项
        materialize_orders(sorted(all_blocks_for(context, self.list_kind), key=order_key))
        swap_orders(blocks[idx], blocks[target])
        # 重建快照时活跃项按真实名跟随(common/blender/list_snapshot.py), 被移动项自然落到 target 行;
        # 不要在重建前写 target: 旧快照的行号语义与重建后的新序不同, 会把高亮落到相邻项
        refresh_lists()
        return {'FINISHED'}


class ListSort(Operator):
    """一键按名称排序列表(顺序值写数据块自定义属性, 随 blend 文件持久)"""

    bl_idname = "ch.list_sort"
    bl_label = "Sort by Name"
    bl_description = "Sort the list by name (order saved in the blend file)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_LIST_KIND_ITEMS, default="lights")  # type: ignore

    def execute(self, context: Context):
        spec = LIST_SPECS[self.list_kind]
        coll = getattr(get_state(context), spec.collection)
        if not coll:
            return {'CANCELLED'}
        blocks = blocks_for(context, self.list_kind)
        if _has_stale_block(context, self.list_kind, blocks):
            return _cancel_stale(self)
        # 全量按名称物化: 只排可见子集时, 被过滤的 0 用户项会保留旧顺序值并与新值冲突;
        # key 用 lower() 与 UI 的 A-Z 按钮同口径(避免大小写两套顺序)
        materialize_orders(sorted(all_blocks_for(context, self.list_kind), key=lambda block: (block.name.lower(), block.name)))
        refresh_lists()
        return {'FINISHED'}


class ObjectDelete(Operator):
    """删除列表活跃项对应的物体(灯光/相机列表; 灯光的空控制器随删, 子物体保留, Ctrl+Z 可撤销)"""

    bl_idname = "ch.object_delete"
    bl_label = "Delete Object"
    bl_description = "Delete the active object of the list (a light's controller empty with no other children is removed along with it)"
    bl_options = {'REGISTER', 'UNDO'}

    list_kind: EnumProperty(name="List", items=_OBJECT_LIST_ITEMS, default="lights")  # type: ignore

    def execute(self, context: Context):
        spec = LIST_SPECS[self.list_kind]
        state = get_state(context)
        coll = getattr(state, spec.collection)
        idx = getattr(state, spec.index)
        if not coll or not 0 <= idx < len(coll):
            return {'CANCELLED'}
        obj = blocks_for(context, self.list_kind)[idx]
        if obj is None:
            return _cancel_stale(self)
        if obj.library is not None:
            # 库链接物体两口径都不许删(作者 2026-10-27 定): 实测 5.1.2 的 remove 对链接 ID
            # 不抛错、直接从会话摘除(重载即回来, 属无效操作且有断链风险); 面板侧按钮同步置灰
            self.report({'ERROR'}, report("Linked data-block cannot be deleted"))
            return {'CANCELLED'}
        parent = obj.parent
        is_light = obj.type == 'LIGHT'
        bpy.data.objects.remove(obj)
        if is_light and parent is not None and parent.type == 'EMPTY' and parent.library is None and not parent.children:
            # 灯光的控制器空物体随删(作者口径"删除时需同时移除灯光的父物体"): 仅当
            # 父级再无其它子级——rig 硬性约束("一个控制器只挂一灯")下等价于"是控制器",
            # 用户手动父级化的多子级空物体留壳不误删; 链接父级不删(5.1.2 的 remove
            # 对链接 ID 不设防, 会把库资产从会话静默摘除). 类型须在删除前读: remove
            # 后再访问 obj 会抛 ReferenceError(StructRNA 已移除, e2e 实证)
            bpy.data.objects.remove(parent)
        # 物体移除虽触发 depsgraph, 仍主动重建保证快照立即可见(后台通道尤甚)
        refresh_lists()
        return {'FINISHED'}
