"""
楔形挤出算法模块

提供楔形的选择快照与几何创建: 由基准边解析两端边/端面拓扑, 并按交互层逐帧算出的
交点坐标生成楔形面与边(含锐度与倒角权重继承).
不读偏好, 不调用 report: 选择不合格统一返回 None, 由调用方决定提示文案.

主要功能:
- build_wedge_data: 由基准边构建楔形操作数据
- create_wedge_geometry: 由数据与交点坐标生成楔形几何
"""

from dataclasses import dataclass, field

import bmesh
from bmesh.types import BMEdge, BMesh
from bpy.types import Object
from mathutils import Matrix, Vector

from ..infrastructure.data import rotate_list
from ..math.geometry import get_edge_angle
from .bmesh_utils import ensure_default_data_layers


@dataclass
class WedgeEndData:
    """楔形端面数据(端点边/端面/顶点及其坐标缓存)"""

    edge: dict = field(default_factory=dict)  # 端点边 {面索引: 边索引}
    other_edge: dict = field(default_factory=dict)  # 端点另一条边 {面索引: 边索引}
    edge_coords: dict = field(default_factory=dict)  # 端点边坐标 {面索引: [端点坐标]}
    other_edge_coords: dict = field(default_factory=dict)  # 端点另一条边坐标 {面索引: [端点坐标]}
    face: int | None = None  # 端面索引
    face_no: Vector | None = None  # 端面法线
    vert: int | None = None  # 端点顶点索引
    vert_co: Vector | None = None  # 端点顶点坐标


@dataclass
class WedgeData:
    """楔形操作数据(由 build_wedge_data 构建的选择快照)"""

    mx: Matrix  # 物体世界矩阵
    edge: int | None = None  # 楔形基准边索引
    edge_sharp: bool = False  # 基准边是否锐边
    edge_bw: float = 0  # 基准边倒角权重
    edge_coords: list = field(default_factory=list)  # 基准边端点坐标
    side_faces: list = field(default_factory=list)  # 两侧面索引
    end1: WedgeEndData = field(default_factory=WedgeEndData)  # 端点1
    end2: WedgeEndData = field(default_factory=WedgeEndData)  # 端点2


@dataclass
class WedgeGeometry:
    """楔形逐帧计算出的交点坐标(交互层写入, 几何创建时读取)"""

    edge_intersection: Vector | None = None  # 基准边上的最近点
    wedge_corner: Vector | None = None  # 楔形角点(滑动后位置)
    end_edge_intersection: Vector | None = None  # 端边上的交点
    end_face_intersection: Vector | None = None  # 端面上的深度交点
    end_other_edge_intersection: Vector | None = None  # 端面另一条边上的交点
    slide_dir: Vector = field(default_factory=Vector)  # 角点滑动方向


def _resolve_end(edge: BMEdge, side_faces: list, end_face) -> tuple | None:
    """
    解析单个端点: 找端点顶点在该侧面上的一条边与另一条边, 并校验夹角不退化

    Args:
        edge: 基准边
        side_faces: 基准边两侧面
        end_face: 端面(可为 None)

    Returns:
        (端点顶点, 端点边, 端点另一条边); 端面缺失或夹角退化时返回 None
    """
    if not end_face:
        return None

    end_vert = [v for v in edge.verts if v in end_face.verts][0]
    end_edges = [e for e in end_vert.link_edges if e != edge and e in side_faces[0].edges]
    other_edges = [e for e in end_vert.link_edges if e != edge and e not in end_edges]

    if not end_edges or not other_edges:
        return None

    end_edge = end_edges[0]
    other_edge = other_edges[0]

    # 夹角达到 180 度(共线)时端点无法构成楔形端面
    if round(get_edge_angle(edge, end_edge, radians=False), 4) >= 180 or round(get_edge_angle(edge, other_edge, radians=False), 4) >= 180:
        return None

    return end_vert, end_edge, other_edge


def _fill_end(end_data: WedgeEndData, end_face, resolved: tuple | None, side_faces: list):
    """
    把单个端点的解析结果写入端面数据

    Args:
        end_data: 端面数据容器
        end_face: 端面
        resolved: _resolve_end 的结果
        side_faces: 基准边两侧面
    """
    if resolved is None:
        return

    end_vert, end_edge, other_edge = resolved

    end_data.face = end_face.index
    end_data.face_no = end_face.normal.copy()
    end_data.vert = end_vert.index
    end_data.vert_co = end_vert.co.copy()

    # 两侧面上"端点边/另一条边"互为镜像: 第二侧交换, 使键始终指向所贴的那一面
    for idx, face in enumerate(side_faces):
        if idx == 0:
            end_data.edge[face.index] = end_edge.index
            end_data.other_edge[face.index] = other_edge.index
            end_data.edge_coords[face.index] = [v.co.copy() for v in end_edge.verts]
            end_data.other_edge_coords[face.index] = [v.co.copy() for v in other_edge.verts]
        else:
            end_data.edge[face.index] = other_edge.index
            end_data.other_edge[face.index] = end_edge.index
            end_data.edge_coords[face.index] = [v.co.copy() for v in other_edge.verts]
            end_data.other_edge_coords[face.index] = [v.co.copy() for v in end_edge.verts]


def build_wedge_data(bm: BMesh, mx: Matrix, edge: BMEdge, bw) -> WedgeData | None:
    """
    由基准边构建楔形操作数据

    Args:
        bm: BMesh对象
        mx: 物体世界矩阵
        edge: 楔形基准边
        bw: 倒角权重层

    Returns:
        WedgeData 或 None(选择不构成楔形)
    """
    bm.faces.ensure_lookup_table()
    bm.normal_update()

    data = WedgeData(mx=mx)

    side_faces = [f for f in edge.link_faces]

    if len(side_faces) != 2:
        return None

    end1_faces = [f for f in edge.verts[0].link_faces if f not in side_faces]
    end2_faces = [f for f in edge.verts[1].link_faces if f not in side_faces]

    end1_face = end1_faces[0] if len(end1_faces) == 1 else None
    end2_face = end2_faces[0] if len(end2_faces) == 1 else None

    # 两端都没有端面时无法确定楔形区域(先判存在性, 夹角校验在其后)
    if not (end1_face or end2_face):
        return None

    resolved1 = _resolve_end(edge, side_faces, end1_face)
    resolved2 = _resolve_end(edge, side_faces, end2_face)

    data.edge = edge.index
    data.edge_sharp = not edge.smooth
    data.edge_bw = edge[bw]
    data.edge_coords = [v.co.copy() for v in edge.verts]
    data.side_faces = [f.index for f in side_faces]

    _fill_end(data.end1, end1_face, resolved1, side_faces)
    _fill_end(data.end2, end2_face, resolved2, side_faces)

    return data


def create_wedge_geometry(active: Object, bm: BMesh, data: WedgeData, geom: WedgeGeometry, end: str, faceidx: int, slide_amount: float, in_object_mode: bool):
    """
    由楔形数据与逐帧交点坐标生成楔形几何

    Args:
        active: 活动对象
        bm: BMesh对象
        data: 楔形操作数据
        geom: 逐帧交点坐标
        end: 使用的端点名("end1"/"end2")
        faceidx: 当前所贴的侧面索引
        slide_amount: 角点滑动量(F9 面板可改, 故由调用方持有)
        in_object_mode: 是否处于物体模式(独立 bm, 需回写并释放)
    """
    if geom.end_other_edge_intersection is None:
        return

    bm.normal_update()
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    bw = ensure_default_data_layers(bm)[1]

    edge = bm.edges[data.edge]
    end_data = getattr(data, end)

    side_face = bm.faces[faceidx]
    other_side_face = [bm.faces[idx] for idx in data.side_faces if idx != faceidx][0]
    end_face = bm.faces[(end_data.face)]

    side_face_verts = [v for v in side_face.verts]
    other_side_face_verts = [v for v in other_side_face.verts]
    end_face_verts = [v for v in end_face.verts]

    end_vert = bm.verts[end_data.vert]

    idx = side_face_verts.index(end_vert)
    if idx != 0:
        rotate_list(side_face_verts, idx)

    idx = other_side_face_verts.index(end_vert)
    if idx != 0:
        rotate_list(other_side_face_verts, idx)

    idx = end_face_verts.index(end_vert)
    if idx != 0:
        rotate_list(end_face_verts, idx)

    loop = [l for l in edge.link_loops if l.face == side_face][0]
    loop_vert_is_end = loop.vert == end_vert

    edge_vert = bm.verts.new(geom.edge_intersection)
    wedge_corner_vert = bm.verts.new(geom.wedge_corner + geom.slide_dir * slide_amount)
    end_edge_vert = bm.verts.new(geom.end_edge_intersection)
    end_face_vert = bm.verts.new(geom.end_face_intersection)

    for v in side_face.verts:
        v.select_set(True)

    side_face_verts.remove(end_vert)

    if loop_vert_is_end:
        side_face_verts.insert(0, edge_vert)
        side_face_verts.insert(0, wedge_corner_vert)
        side_face_verts.insert(0, end_edge_vert)
    else:
        side_face_verts.insert(0, end_edge_vert)
        side_face_verts.insert(0, wedge_corner_vert)
        side_face_verts.insert(0, edge_vert)

    side_face.hide_set(True)
    new_side_face = bm.faces.new(side_face_verts)
    new_side_face.smooth = side_face.smooth

    for v in other_side_face.verts:
        v.select_set(True)

    if loop_vert_is_end:
        other_side_face_verts.insert(0, edge_vert)
    else:
        other_side_face_verts.insert(1, edge_vert)

    other_side_face.hide_set(True)
    new_other_side_face = bm.faces.new(other_side_face_verts)
    new_other_side_face.smooth = other_side_face.smooth

    end_vert.co = geom.end_other_edge_intersection

    for v in end_face.verts:
        v.select_set(True)

    if loop_vert_is_end:
        end_face_verts.insert(1, end_face_vert)
        end_face_verts.insert(2, end_edge_vert)
    else:
        end_face_verts.insert(0, end_face_vert)
        end_face_verts.insert(0, end_edge_vert)

    end_face.hide_set(True)
    new_end_face = bm.faces.new(end_face_verts)
    new_end_face.smooth = end_face.smooth

    if loop_vert_is_end:
        wedge_tri = bm.faces.new([wedge_corner_vert, end_edge_vert, end_face_vert])
        wedge_quad = bm.faces.new([end_vert, edge_vert, wedge_corner_vert, end_face_vert])
    else:
        wedge_tri = bm.faces.new([wedge_corner_vert, end_face_vert, end_edge_vert])
        wedge_quad = bm.faces.new([end_vert, end_face_vert, wedge_corner_vert, edge_vert])

    wedge_tri.smooth = new_side_face.smooth
    wedge_quad.smooth = new_side_face.smooth

    axis_edge = bm.edges.get([edge_vert, wedge_corner_vert])
    length_edge = bm.edges.get([wedge_corner_vert, end_edge_vert])
    wedge_edge1 = bm.edges.get([edge_vert, end_vert])
    wedge_edge2 = bm.edges.get([wedge_corner_vert, end_face_vert])
    end_face_edge1 = bm.edges.get([end_edge_vert, end_face_vert])
    end_face_edge2 = bm.edges.get([end_vert, end_face_vert])

    edges = [axis_edge, length_edge, wedge_edge1, wedge_edge2, end_face_edge1, end_face_edge2]
    connected_edges = [e for v in [edge_vert, end_edge_vert] for e in v.link_edges if e not in edges]

    for e in edges + connected_edges:
        e.smooth = not data.edge_sharp
        e[bw] = data.edge_bw

    bmesh.ops.delete(bm, geom=[side_face, other_side_face, end_face], context="FACES")

    bm.normal_update()

    if in_object_mode:
        bm.to_mesh(active.data)
        bm.free()
        active.select_set(True)
    else:
        bmesh.update_edit_mesh(active.data)
