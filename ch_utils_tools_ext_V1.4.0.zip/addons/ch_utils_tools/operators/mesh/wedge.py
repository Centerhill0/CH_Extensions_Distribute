"""
楔形几何体创建操作模块

从选中的边创建楔形(Wedge)几何体.
通过在边的端点处创建新的面来形成楔形结构.

操作流程:
1. 选择一条流形边(manifold edge)
2. 区域定义模式: 移动鼠标定义楔形区域,按LMB进入深度定义模式
3. 深度定义模式: 移动鼠标定义楔形深度,按LMB确认完成
4. 按RMB可从深度模式返回区域模式,或取消操作

支持的选项:
- Planar Quad: 创建平面四边形楔形(P键切换)
- Flip: 翻转楔形方向(F键,当两端都有面时可用)
- Slide: 滑动楔形角点位置(S键)

快捷键:
区域定义模式:
- 鼠标移动: 定义楔形区域
- LMB: 进入深度定义模式
- F: 翻转楔形方向
- S: 滑动楔形角点
- RMB/ESC: 取消操作

深度定义模式:
- 鼠标移动: 定义楔形深度
- LMB/Space: 确认完成
- P: 切换平面四边形模式
- RMB: 返回区域定义模式
- ESC: 取消操作
"""

__all__ = ["WedgeExtrude"]

import bmesh
from bpy.types import Operator, Context, Event
from bpy.props import BoolProperty, FloatProperty, IntProperty
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d
from mathutils import Vector
from mathutils.geometry import intersect_point_line, intersect_line_line, intersect_line_plane

from ...constants import white, red, blue, green, yellow, black
from ...utils import (
    Snap,
    ensure_default_data_layers,
    ignore_events,
    draw_line,
    draw_lines,
    draw_points,
    draw_status_item,
    force_ui_update,
    get_length_unit_data,
    navigation_passthrough,
    format_adaptive_precision,
    WedgeData,
    WedgeGeometry,
    build_wedge_data,
    create_wedge_geometry,
)
from ...modal_base import ModalOperatorMixin


class WedgeExtrude(Operator, ModalOperatorMixin):
    """
    楔形几何体创建操作器

    功能: 从选中的边创建楔形几何体
    - 支持平面四边形模式
    - 支持翻转楔形方向
    - 支持滑动楔形角点

    要求: 选择一条流形边,至少有一端连接到恰好两条其他边
    """

    bl_idname = "ch.wedge_extrude"
    bl_label = "Wedge Extrude"
    bl_description = "Create Wedge Extrude from Edge Selection"
    bl_options = {'REGISTER', 'UNDO'}

    planar_wedge_quad: BoolProperty(name="Planar", default=True, description="Keep the quad faces of the wedge planar")  # type: ignore
    flip: BoolProperty(name="Flip Direction", default=False, description="Flip the extrusion direction")  # type: ignore
    depth_amount: FloatProperty(name="Depth Amount", step=0.1, subtype='DISTANCE', description="Depth of the wedge along the extrusion direction")  # type: ignore
    slide_amount: FloatProperty(name="Slide Amount", step=0.1, subtype='DISTANCE', description="Offset of the wedge along the edge direction")  # type: ignore

    index: IntProperty(name="Edge Index", options={'HIDDEN'})  # type: ignore

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        act_obj = context.active_object
        # 非网格物体没有可楔形挤出的边(放过 Camera/Light/Empty 会在 bmesh.from_mesh 抛错);
        # 物体模式放行是上游既有行为且有 e2e 契约(U-08), 不收紧
        if act_obj is None or act_obj.type != 'MESH':
            return False
        return context.mode in ["EDIT_MESH", "OBJECT"]

    def invoke(self, context: Context, event: Event):
        self.act_obj = context.active_object
        # execute 按名重解析用: F9 重做在同一实例上重跑 execute, 撤销回退可能使缓存引用失效
        self._object_name = self.act_obj.name
        self.mx = self.act_obj.matrix_world

        self.data: WedgeData = self._get_wedge_data(context, self.index)

        if self.data:
            self.init_mouse_position(event)

            # 记录"本次 invoke 是否隐藏了修改器"(仅物体模式进入时):
            # finish 按 ownership 恢复, 而非按当下 context.mode——模态期间切换模式时后者不可靠
            self._owns_mods = context.mode == "OBJECT"
            if self._owns_mods:
                self.mods = [(mod, mod.show_viewport) for mod in self.act_obj.modifiers]

                for mod, _ in self.mods:
                    mod.show_viewport = False

            self.S = Snap(context, include=[self.act_obj])

            self.count = 0

            self.flip = False
            self.can_flip = self.data.end1.face is not None and self.data.end2.face is not None

            self.is_sliding_corner = False
            self.is_setting_depth = False

            self.hitindex = None
            self.hitlocation = None
            self.hitnormal = None

            # 逐帧交点坐标(F9 可改的 slide_amount 仍留在 RNA 属性上)
            self.geom = WedgeGeometry()
            self.slide_amount = 0

            self.depth_dir = None
            self.depth_amount = 0

            self.wedge_axis_coords = []
            self.wedge_axis_dots_coords = []
            self.wedge_width_coords = []
            self.wedge_length_coords = []
            self.wedge_depth_on_end_face_coords = []
            self.wedge_side_coords = []

            self.init_status(context, func=_draw_wedge_status(self))
            self.init_modal_handlers(context, view3d=True)
            force_ui_update(context)
            return {"RUNNING_MODAL"}

        self.report(
            {"WARNING"},
            "Make sure to select a single, manifold edge, with at least one end leading to exactly 2 other edges, where neither should be parallel to the active edge!",
        )
        return {"CANCELLED"}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 先归还修改器可视性再最小收敛, 否则隐藏的修改器滞留在物体上
            self._restore_mods()
            self._abort_without_area(context)
            return {'CANCELLED'}

        if ignore_events(event):
            return {"RUNNING_MODAL"}

        context.area.tag_redraw()

        self.init_mouse_position(event)

        events = ["MOUSEMOVE", "P"]

        if self.can_flip:
            events.append("F")

        if not self.is_setting_depth:
            events.append("S")

        if event.type in events:
            if event.type == "MOUSEMOVE":
                self._handle_mouse_move(context)
            elif event.type == "S" and event.value == "PRESS":
                self._toggle_slide_mode(context)
            elif event.type in ["P", "F"] and event.value == "PRESS":
                self._handle_key_press(context, event)

        elif navigation_passthrough(event, alt=False, wheel=False):
            return {"PASS_THROUGH"}

        elif self.S.hit and self.S.hit_index in self.data.side_faces and event.type == "LEFTMOUSE" and event.value == "PRESS":
            self.is_setting_depth = True
            context.active_object.select_set(True)

        if self.is_setting_depth:
            # 仅以按下事件确认完成: 进入深度阶段的按下在释放前若已有鼠标移动,
            # 其释放同样落在该分支内, 会误判为确认而跳过深度定义
            if self.depth_dir and event.value == "PRESS" and event.type in {"SPACE", "LEFTMOUSE"}:
                self.finish(context)
                return self.execute(context)

            elif event.type == "RIGHTMOUSE" and event.value == "PRESS":
                self._reset_to_area_mode(context)
                return {"RUNNING_MODAL"}

            elif event.type == "ESC" and event.value == "PRESS":
                self.finish(context)
                return {"CANCELLED"}

        else:
            if event.type in {"RIGHTMOUSE", "ESC"} and event.value == "PRESS":
                self.finish(context)
                return {"CANCELLED"}

        return {"RUNNING_MODAL"}

    def execute(self, context: Context):
        # execute 可能被脚本直调而未经 invoke; 楔形几何完全由模态交互(拾取区域/深度/滑动)派生,
        # 无交互状态时无法重建, 干净取消而非崩溃.
        # 注意: 不可复入 invoke 重建——invoke 会注册模态处理器与状态栏, execute 路径复入会泄漏句柄;
        # F9 重做走持久实例, count 已存在, 不受此守卫影响
        if not hasattr(self, "count"):
            self.report({"WARNING"}, "Wedge Extrude requires interactive viewport input and cannot be executed directly")
            return {"CANCELLED"}

        # F9 重做在同一实例上重跑 execute: invoke 缓存的物体引用经撤销回退后可能失效,
        # 按名重解析并刷新矩阵(§10.2, 与 symmetrize 同款); 解析失败干净取消而非解引用死指针
        name = getattr(self, "_object_name", "")
        self.act_obj = context.scene.objects.get(name) if name else None
        if self.act_obj is None:
            self.act_obj = context.active_object
        if self.act_obj is None:
            self.report({"WARNING"}, "No active mesh object")
            return {"CANCELLED"}
        self.mx = self.act_obj.matrix_world

        context.evaluated_depsgraph_get()

        if self.count:
            self._get_wedge_area(self.hitindex, self.hitlocation, self.hitnormal)
            self._get_end_area()

        self._create_wedge_geometry(context, self.S.hit_index)

        self.count += 1
        return {"FINISHED"}

    def _restore_mods(self) -> None:
        """按 invoke 时的所有权归还修改器可视性"""
        if self._owns_mods:
            for mod, state in self.mods:
                try:
                    mod.show_viewport = state
                except ReferenceError:
                    continue  # 模态期间 undo 释放了修改器

    def finish(self, context: Context):
        """完成操作,清理资源"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        self.S.finish()
        self._restore_mods()
        force_ui_update(context)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "depth_amount")
        layout.prop(self, "slide_amount")
        layout.prop(self, "planar_wedge_quad")
        layout.active = self.can_flip
        layout.prop(self, "flip")

    def update_header_text(self, context: Context):
        """更新区域header文本显示数值信息"""
        # 内部米值乘系数换算成场景单位显示(见 get_length_unit_data)
        unit_symbol, factor = get_length_unit_data(context)

        if self.is_setting_depth and self.depth_dir:
            depth_text = format_adaptive_precision(self.depth_amount * factor, 1)
            slide_text = format_adaptive_precision(self.slide_amount * factor, 1)
            text = f"Depth: {depth_text} {unit_symbol} | Slide: {slide_text} {unit_symbol}"
        elif self.slide_amount > 0:
            slide_text = format_adaptive_precision(self.slide_amount * factor, 1)
            text = f"Slide: {slide_text} {unit_symbol}"
        else:
            text = ""

        context.area.header_text_set(text)

    def draw_VIEW3D(self, context: Context):
        """绘制3D视图中的预览"""
        if context.area == self.area:
            if self.geom.wedge_corner:
                draw_line(self.wedge_axis_coords, mx=self.mx, color=yellow, width=2, alpha=0.99)

                draw_points(self.wedge_axis_dots_coords, mx=self.mx, color=yellow, size=3)

                draw_line(self.wedge_width_coords, mx=self.mx, color=black, width=1.5, alpha=0.99)

                draw_line(self.wedge_length_coords, mx=self.mx, color=green, alpha=0.99)

                if self.depth_dir:
                    draw_lines(self.wedge_depth_on_end_face_coords, mx=self.mx, color=blue, alpha=0.99)
                    draw_lines(self.wedge_side_coords, mx=self.mx, color=white if self.planar_wedge_quad else red, alpha=0.5)

    def _handle_mouse_move(self, context: Context):
        """处理鼠标移动事件"""
        if self.is_setting_depth:
            self._get_wedge_depth(context)

            if self.depth_dir:
                self._get_end_area()

        elif self.is_sliding_corner:
            self.S.update_hit(self.mouse_region_pos)

            if self.S.hit and self.S.hit_index in self.data.side_faces:
                self._slide_wedge_corner(self.S.hit_location)

        else:
            self.S.update_hit(self.mouse_region_pos)

            if self.S.hit and self.S.hit_index in self.data.side_faces:
                self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)

        self._get_view3d_coords()
        self.update_header_text(context)

    def _toggle_slide_mode(self, context: Context):
        """切换滑动模式"""
        self.is_sliding_corner = not self.is_sliding_corner
        context.active_object.select_set(True)

        if not self.is_sliding_corner:
            self.geom.slide_dir = Vector()
            self.slide_amount = 0

            self.S.update_hit(self.mouse_region_pos)

            if self.S.hit and self.S.hit_index in self.data.side_faces:
                self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)
                self._get_view3d_coords()

        self.update_header_text(context)

    def _handle_key_press(self, context: Context, event: Event):
        """处理按键按下事件"""
        if event.value != "PRESS":
            return

        key_actions = {
            "P": lambda: setattr(self, "planar_wedge_quad", not self.planar_wedge_quad),
            "F": lambda: self._flip_wedge_direction(context),
        }

        if event.type in key_actions:
            key_actions[event.type]()

        if self.is_setting_depth:
            self._get_wedge_depth(context)

            if self.depth_dir:
                self._get_end_area()

        self._get_view3d_coords()
        force_ui_update(context)

    def _flip_wedge_direction(self, context: Context):
        """翻转楔形方向"""
        self.flip = not self.flip
        self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)
        force_ui_update(context, self.act_obj)

    def _reset_to_area_mode(self, context: Context):
        """重置到区域调整模式"""
        self.is_setting_depth = False
        self.depth_dir = None
        self.is_sliding_corner = False
        self.geom.slide_dir = Vector()
        self.slide_amount = 0

        self.S.update_hit(self.mouse_region_pos)

        if self.S.hit and self.S.hit_index in self.data.side_faces:
            self._get_wedge_area(self.S.hit_index, self.S.hit_location, self.S.hit_normal)
            self._get_view3d_coords()

        self.update_header_text(context)
        context.active_object.select_set(True)

    def _get_wedge_data(self, context: Context, idx: int | None = None) -> WedgeData | None:
        """
        获取楔形几何体的数据

        Args:
            context: Blender上下文
            idx: 边索引(对象模式下使用)

        Returns:
            WedgeData | None: 楔形数据,无效选择返回None
        """
        active = context.active_object

        if context.mode == "OBJECT":
            bm = bmesh.new()
            bm.from_mesh(active.data)
            bm.edges.ensure_lookup_table()
            # 空网格或索引越界(如 F9 重做时网格已变): 提前释放并返回, 不进入后续 bm.edges[idx]
            if not bm.edges or not 0 <= idx < len(bm.edges):
                bm.free()
                return None

            try:
                bw = ensure_default_data_layers(bm, crease=False)[1]
                return build_wedge_data(bm, active.matrix_world, bm.edges[idx], bw)
            finally:
                bm.free()

        bm = bmesh.from_edit_mesh(active.data)
        bw = ensure_default_data_layers(bm, crease=False)[1]
        selected = [e for e in bm.edges if e.select]

        if len(selected) != 1:
            return None

        return build_wedge_data(bm, active.matrix_world, selected[0], bw)

    def _get_end(self) -> str:
        """获取当前使用的端点名称"""
        if self.can_flip:
            if self.flip:
                return "end2"
            else:
                return "end1"
        elif self.data.end1.face is not None:
            return "end1"
        elif self.data.end2.face is not None:
            return "end2"
        return "end1"

    def _get_wedge_area(self, faceidx: int, location: Vector, normal: Vector):
        """计算楔形区域"""
        mx = self.data.mx
        edge_coords = [mx @ co for co in self.data.edge_coords]

        closest_on_edge, _ = intersect_point_line(location, *edge_coords)

        self.hitindex = faceidx
        self.hitlocation = location
        self.hitnormal = normal

        self.geom.wedge_corner = mx.inverted_safe() @ location
        self.geom.edge_intersection = mx.inverted_safe() @ closest_on_edge

        end_data = getattr(self.data, self._get_end())
        end_edge_coords = [mx @ co for co in end_data.edge_coords[faceidx]]
        edge_dir = edge_coords[1] - edge_coords[0]

        intersection = intersect_line_line(location, location + edge_dir, *end_edge_coords)

        if intersection:
            self.geom.end_edge_intersection = self.mx.inverted_safe() @ intersection[1]
        else:
            # 端边与基准边同向平行(0 度, _get_wedge_data 只拦了 180 度反向)时无交点:
            # end_edge_intersection 保持 None, 后续深度/绘制阶段会 None + Vector 崩溃——
            # 置空 wedge_corner 熔断(各阶段均以它为门), 楔形保持未定义态等待用户重新拾取
            self.geom.wedge_corner = None
            return

        if self.geom.slide_dir == Vector() and self.geom.end_edge_intersection is not None:
            self.geom.slide_dir = (self.geom.end_edge_intersection - self.geom.wedge_corner).normalized()

    def _slide_wedge_corner(self, location: Vector):
        """滑动楔形角点"""
        wedge_dir_coords = [self.geom.wedge_corner, self.geom.end_edge_intersection]

        closest_on_wedge_dir, _ = intersect_point_line(self.mx.inverted_safe() @ location, *wedge_dir_coords)

        slide_dir = closest_on_wedge_dir - self.geom.wedge_corner

        self.geom.slide_dir = slide_dir.normalized()
        self.slide_amount = slide_dir.length

    def _get_wedge_depth(self, context: Context):
        """计算楔形深度"""
        hitlocation = self.hitlocation + (self.geom.slide_dir * self.slide_amount)

        normal_coords = [hitlocation, hitlocation + self.hitnormal]

        view_origin = region_2d_to_origin_3d(context.region, context.region_data, self.mouse_region_pos)
        view_dir = region_2d_to_vector_3d(context.region, context.region_data, self.mouse_region_pos)

        intersection = intersect_line_line(*normal_coords, view_origin, view_origin + view_dir)

        if not intersection:
            return

        closest_on_normal = intersection[0]

        depth_dir = self.mx.inverted_safe().to_quaternion() @ (closest_on_normal - hitlocation)

        self.depth_dir = depth_dir.normalized()
        self.depth_amount = depth_dir.length

    def _get_end_area(self):
        """计算端面区域"""
        end_data = getattr(self.data, self._get_end())
        end_face_normal = end_data.face_no

        edge_dir = self.data.edge_coords[1] - self.data.edge_coords[0]
        intersector = [
            self.geom.end_edge_intersection + self.depth_dir * self.depth_amount,
            self.geom.end_edge_intersection + self.depth_dir * self.depth_amount + edge_dir,
        ]

        i = intersect_line_plane(*intersector, self.geom.end_edge_intersection, end_face_normal)

        if i:
            self.geom.end_face_intersection = i
            end_other_edge_coords = end_data.other_edge_coords[self.hitindex]

            if self.planar_wedge_quad:
                wedge_corner = self.geom.wedge_corner + self.geom.slide_dir * self.slide_amount

                tri_v1 = (self.geom.edge_intersection - wedge_corner).normalized()
                tri_v2 = (self.geom.end_face_intersection - wedge_corner).normalized()
                tri_no = tri_v1.cross(tri_v2)

                i = intersect_line_plane(*end_other_edge_coords, wedge_corner, tri_no)

                if i:
                    self.geom.end_other_edge_intersection = i
            else:
                end_edge_coords = end_data.edge_coords[self.hitindex]
                end_edge_dir = (end_edge_coords[1] - end_edge_coords[0]).normalized()

                intersection = intersect_line_line(self.geom.end_face_intersection, self.geom.end_face_intersection + end_edge_dir, *end_other_edge_coords)
                i = intersection[1] if intersection else None

                if i:
                    self.geom.end_other_edge_intersection = i

    def _get_view3d_coords(self):
        """获取3D视图坐标"""
        if self.geom.wedge_corner:
            end_data = getattr(self.data, self._get_end())

            wedge_corner = self.geom.wedge_corner + self.geom.slide_dir * self.slide_amount

            self.wedge_axis_coords = [wedge_corner, self.geom.edge_intersection]
            self.wedge_axis_dots_coords = [
                self.wedge_axis_coords[0] + (self.wedge_axis_coords[0] - self.wedge_axis_coords[1]) * 0.2,
                self.wedge_axis_coords[1] - (self.wedge_axis_coords[0] - self.wedge_axis_coords[1]) * 0.2,
            ]

            self.wedge_width_coords = [end_data.vert_co, self.geom.end_edge_intersection]
            self.wedge_length_coords = [wedge_corner, self.geom.end_edge_intersection]

            if self.depth_dir:
                end_vert_co = end_data.vert_co

                self.wedge_depth_on_end_face_coords = [self.geom.end_edge_intersection, self.geom.end_face_intersection]
                self.wedge_depth_on_end_face_coords.extend([end_vert_co, self.geom.end_other_edge_intersection])
                self.wedge_depth_on_end_face_coords.extend([self.geom.end_face_intersection, self.geom.end_other_edge_intersection])

                self.wedge_side_coords = [wedge_corner, self.geom.end_face_intersection]
                self.wedge_side_coords.extend([self.geom.edge_intersection, self.geom.end_other_edge_intersection])

    def _create_wedge_geometry(self, context: Context, faceidx: int):
        """创建楔形几何体"""
        # geom 未定义(直调 execute / 端边平行的熔断路径)时早退: 守卫须在 bm 创建之前,
        # 否则物体模式路径每次早退都泄漏一只独立 BMesh(算法层内还有一道同判据守卫)
        if self.geom.end_other_edge_intersection is None:
            return

        in_object_mode = context.mode == "OBJECT"

        if in_object_mode:
            bm = bmesh.new()
            bm.from_mesh(self.act_obj.data)
        else:
            bm = bmesh.from_edit_mesh(self.act_obj.data)

        create_wedge_geometry(self.act_obj, bm, self.data, self.geom, self._get_end(), faceidx, self.slide_amount, in_object_mode)


def _draw_wedge_status(op: WedgeExtrude):
    """
    返回 WedgeExtrude 操作的状态栏绘制回调函数

    Args:
        op: WedgeExtrude 操作实例

    Returns:
        function: 状态栏绘制回调函数
    """

    def draw(self, context: Context):
        """状态栏实际绘制回调"""
        layout = self.layout
        row = layout.row(align=True)

        if not op.is_setting_depth:
            draw_status_item(row, key="LMB", text="Confirm")
            draw_status_item(row, key='MMB', text="Viewport Navigation")
            draw_status_item(row, key="RMB", text="Cancel")

            draw_status_item(row, key="MOVE", text="Define Area", gap=3)
            if op.can_flip:
                draw_status_item(row, key="F", text="Flip")

            draw_status_item(row, active=op.is_sliding_corner, key="S", text="Slide Corner")
        else:
            draw_status_item(row, key="LMB", text="Finish")
            draw_status_item(row, key='MMB', text="Viewport Navigation")
            draw_status_item(row, key="RMB", text="Go Back")

            draw_status_item(row, key="MOVE", text="Define Depth", gap=3)
            draw_status_item(row, active=op.can_flip, key="F", text="Flip")
            draw_status_item(row, active=op.planar_wedge_quad, key="P", text="Planar")

    return draw
