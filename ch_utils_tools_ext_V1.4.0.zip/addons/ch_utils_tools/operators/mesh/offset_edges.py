"""
偏移边环操作器模块

提供以下功能:
- OffsetEdges: 对选中的边环做偏移/挤出/移动

操作流程:
1. 网格编辑模式下选中要偏移的边(或面选区的边界)
2. 水平拖动调当前拖动轴(默认宽度; DEPTH 模式可切深度, ANGLE 模式可切角度;
   MOVE 模式实时位移, 其余模式 GPU 折线预览虚拟偏移环, 挤出另绘原顶点连接线)
3. W 切换几何模式, D/A 切拖动轴, S 切深度模式, F/R/M 切换沿面/轨道/镜像(F/R/M 只读重算方向)
4. 左键确认时一次性执行真实拓扑变更, 右键取消还原

快捷键:
- 拖动: 水平调当前拖动轴(宽度/深度/角度, 见 D/A)
- 数字键: 精确输入当前拖动轴的数值(宽度/深度按场景单位换算, 角度按度输入)
- D: 切换宽度/深度拖动轴(仅 DEPTH 深度模式; 再按一次切回宽度)
- Alt+D: 深度归零并退回宽度拖动轴(仅 DEPTH 深度模式)
- A: 切换宽度/角度拖动轴(仅 ANGLE 深度模式; 再按一次切回宽度)
- Alt+A: 角度归零并退回宽度拖动轴(仅 ANGLE 深度模式)
- W: 循环几何模式(偏移/挤出/移动)
- F: 切换沿邻接面
- R: 切换内部边轨道
- M: 切换镜像修改器
- S: 切换深度模式(直接深度/由角度推出; 切换时非宽度拖动轴退回宽度)
- X: 重置当前拖动轴的数值(宽度回默认, 深度/角度归零)
- 左键/空格/回车: 确认
- 右键/ESC: 取消(数字输入中先退出输入)
- MMB: 旋转视图

注意: 模态不做拓扑手术(遵循 chamfer/hole_extrude 的既有模式:
模态期只做参数调整、坐标重放与 GPU 预览, 真实拓扑变更在确认时一次性执行).
"""

__all__ = ["OffsetEdges"]

from dataclasses import dataclass, field

import bmesh
from bmesh.types import BMEdge, BMesh, BMVert
from math import cos, degrees, pi, radians, sin
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Context, Event, Object, Operator
from mathutils import Matrix, Vector

from ...constants import cyan, yellow
from ...items import depth_mode_items, offset_geometry_mode_items
from ...utils import (
    collect_loops,
    draw_line,
    draw_lines,
    draw_status_item,
    feed_numeric,
    force_ui_update,
    format_adaptive_precision,
    get_directions,
    get_length_unit_data,
    get_mirror_planes,
    get_selection_border_edges,
    get_vert_mirror_pairs,
    ignore_events,
    navigation_passthrough,
    numeric_start_value,
    restore_vert_positions,
    snapshot_vert_positions,
    step_enum,
)
from ...utils._constants import MODAL_DRAG_SENSITIVITY
from ...modal_base import ModalOperatorMixin

UPWARD = Vector((1.0, 1.0, 1.0)).normalized()  # 统一环朝向的参考上方向
NORMAL_FALLBACK = Vector((0.0, 0.0, 1.0))  # 环法线无法计算时的回退法线
FLAT_FACE_THRESHOLD = radians(0.05)  # 两邻接面视为共面的法线夹角阈值
DEFAULT_WIDTH = 0.2  # 宽度属性默认值与 X 重置值共用
MODE_LABELS = {identifier: label for identifier, label, *_ in offset_geometry_mode_items}
ANGLE_DRAG_SENSITIVITY = 0.005  # 角度拖动灵敏度(弧度/像素, 约 0.29°/px; 宽度/深度沿用 MODAL_DRAG_SENSITIVITY 的距离口径)


@dataclass
class OffsetLoopData:
    """偏移边环载荷(方向求解结果与基线快照)"""

    lp: list  # [v, e, v, ..., v] 交错环序列(重算方向时复用)
    edges_orig: list[BMEdge]  # 环原始边
    orig_verts: list[BMVert]  # 环原始顶点(闭合环不含重复尾顶点)
    orig_base_coords: list[Vector]  # 原顶点基线坐标(取消还原与预览共用)
    directions: list[tuple[Vector, Vector]]  # 与原顶点对齐的 (宽度方向, 深度方向)
    is_closed: bool  # 是否闭合环
    preview_coords: list[Vector] = field(default_factory=list)  # 虚拟偏移环坐标(GPU 预览)
    preview_indices: list[tuple[int, int]] = field(default_factory=list)  # 折线索引对(拓扑逐帧不变, 随坐标一次算好)


def _extrude_edges(bm: bmesh.types.BMesh, edges_orig: list[BMEdge]) -> dict:
    """
    挤出原始边并归类返回几何
    Args:
        bm: 工作BMesh
        edges_orig: 要挤出的边列表
    Returns:
        含 verts(副本顶点)/edges(副本边)/faces(新面)/side(侧边) 的字典
    """
    extruded = bmesh.ops.extrude_edge_only(bm, edges=edges_orig)['geom']
    co_edges = co_faces = len(edges_orig)
    co_verts = len(extruded) - co_edges - co_faces

    verts = set(extruded[:co_verts])
    edges = set(extruded[co_verts : co_verts + co_edges])
    faces = set(extruded[co_verts + co_edges :])

    return {'verts': verts, 'edges': edges, 'faces': faces, 'side': {e for v in verts for e in v.link_edges if e not in edges}}


def _collect_moved_verts(orig_verts: list[BMVert], geom: dict) -> list[BMVert]:
    """
    按原顶点顺序定位各自的挤出副本顶点(经侧边连接)
    Args:
        orig_verts: 环原顶点列表
        geom: _extrude_edges 返回的几何字典
    Returns:
        与原顶点顺序对齐的副本顶点列表
    """
    moved = []
    for vert in orig_verts:
        for edge in vert.link_edges:
            if edge in geom['side']:
                moved.append(edge.other_vert(vert))
                break
    return moved


def _clean_selection(bm: bmesh.types.BMesh, geometry_mode: str, edges_orig: list[BMEdge], geom: dict | None):
    """
    重置选择状态; offset 模式额外删除侧边与新生成的面
    Args:
        bm: 工作BMesh
        geometry_mode: 几何模式
        edges_orig: 环原始边
        geom: 挤出几何字典, MOVE 模式为 None
    """
    for face in bm.faces:
        face.select = False

    if geom:
        for edge in geom['edges']:
            edge.select = True
        if geometry_mode == 'OFFSET':
            bmesh.ops.delete(bm, geom=list(geom['side']) + list(geom['faces']), context='EDGES')
    else:
        for edge in edges_orig:
            edge.select = True


# ============================================================
# 偏移边环操作器
# ============================================================
class OffsetEdges(Operator, ModalOperatorMixin):
    """
    偏移边环

    功能:对选中的边环做偏移/挤出/移动
    - 宽度与深度双参数控制位移
    - 支持沿邻接面/内部边轨道/镜像修改器
    - 模态期可拖动/数字输入宽度、深度(DEPTH 模式)与角度(ANGLE 模式), 真实拓扑变更在确认时一次性执行

    要求:网格编辑模式下有选中的边, 且边环互不重叠
    """

    bl_idname = "ch.offset_edges"
    bl_label = "Offset Edges"
    bl_description = "Offset / extrude / move selected edge loops"
    bl_options = {'REGISTER', 'UNDO'}

    geometry_mode: EnumProperty(name="Mode", description="How to apply the offset", items=offset_geometry_mode_items, default='OFFSET')  # type: ignore
    width: FloatProperty(name="Width", description="Offset width", default=DEFAULT_WIDTH, precision=4, step=1, subtype='DISTANCE')  # type: ignore
    flip_width: BoolProperty(name="Flip Width", description="Flip width direction", default=False)  # type: ignore
    depth: FloatProperty(name="Depth", description="Offset depth", default=0.0, precision=4, step=1, subtype='DISTANCE')  # type: ignore
    flip_depth: BoolProperty(name="Flip Depth", description="Flip depth direction", default=False)  # type: ignore
    depth_mode: EnumProperty(name="Depth Mode", description="How to derive the depth", items=depth_mode_items, default='DEPTH')  # type: ignore
    angle: FloatProperty(name="Angle", description="Angle between width and depth", default=0.0, precision=3, step=0.1, min=-2 * pi, max=2 * pi, subtype='ANGLE')  # type: ignore
    flip_angle: BoolProperty(name="Flip Angle", description="Flip angle direction", default=False)  # type: ignore
    follow_face: BoolProperty(name="Follow Face", description="Offset along faces around", default=False)  # type: ignore
    edge_rail: BoolProperty(name="Inner Edge Rail", description="Align vertices along inner edges", default=False)  # type: ignore
    edge_rail_only_end: BoolProperty(name="Edge Rail Only End", description="Apply edge rail to end verts only", default=False)  # type: ignore
    use_mirror: BoolProperty(name="Mirror Modifier", description="Take into account of Mirror modifier", default=False)  # type: ignore
    threshold: FloatProperty(name="Flat Face Threshold", description="If difference of angle between two adjacent faces is below this value, those faces are regarded as flat", default=FLAT_FACE_THRESHOLD, precision=5, step=1e-4, subtype='ANGLE', options={'HIDDEN'})  # type: ignore

    is_numeric_input: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore
    numeric_input_amount: StringProperty(default='0', options={'HIDDEN'})  # type: ignore

    # 当前拖动轴(模态会话状态, 不进 RNA 存储也不参与重做): 'WIDTH'/'DEPTH'/'ANGLE',
    # D/A 键按深度模式切换(见 _handle_key_press); 类级缺省覆盖无 invoke 的直调路径
    drag_axis: str = 'WIDTH'

    # --- 模态状态 ---
    pass_through: BoolProperty(default=False, options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == "EDIT_MESH"

    def _resolve_mirror_edges(self, border_edges: set[BMEdge], obj: Object) -> tuple[dict | None, set[BMEdge]]:
        """
        按镜像开关过滤整体落在镜像平面上的边

        Args:
            border_edges: 选区边界边集合
            obj: 目标网格物体
        Returns:
            (顶点到镜像平面的映射, 过滤后的边集合); 过滤后为空集时报错提示
        """
        if not self.use_mirror:
            return None, border_edges

        mirror_pairs, set_edges = get_vert_mirror_pairs(border_edges, get_mirror_planes(obj))
        if not set_edges:
            self.report({'WARNING'}, "All selected edges lie on mirror planes. Disable Mirror Modifier or select other edges")
        return mirror_pairs, set_edges

    def _build_loops(self, set_edges: set[BMEdge], mirror_pairs: dict | None) -> list[OffsetLoopData] | None:
        """
        求解边环方向并构建载荷列表

        Args:
            set_edges: 参与偏移的边集合
            mirror_pairs: 顶点到镜像平面的映射(无则 None)
        Returns:
            载荷列表; 边环重叠无法串接时返回 None
        """
        loops = collect_loops(set_edges)
        if loops is None:
            return None

        loops_data = []
        for lp in loops:
            verts, directions = get_directions(
                lp,
                UPWARD,
                NORMAL_FALLBACK,
                mirror_pairs,
                follow_face=self.follow_face,
                edge_rail=self.edge_rail,
                edge_rail_only_end=self.edge_rail_only_end,
                threshold=self.threshold,
            )
            if not verts:
                continue
            loops_data.append(
                OffsetLoopData(
                    lp=lp,
                    edges_orig=lp[1::2],
                    orig_verts=verts,
                    orig_base_coords=snapshot_vert_positions(verts),
                    directions=directions,
                    is_closed=lp[0] is lp[-1],
                )
            )
        return loops_data

    def invoke(self, context: Context, event: Event):
        self.act_obj: Object = context.active_object
        self.act_mx: Matrix = self.act_obj.matrix_world
        self.bm: BMesh = bmesh.from_edit_mesh(self.act_obj.data)
        self._verts_moved = False  # MOVE 模式是否动过顶点(离场还原与显示网格同步的门控)

        self.border_edges: set[BMEdge] = get_selection_border_edges(self.bm)
        if not self.border_edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}

        # 面选中时自动沿邻接面(沿用源算子行为); 深度模式不再强制——模态已支持深度/角度
        # 拖动(见 _handle_key_press), 尊重 F9 面板/上次会话留下的 ANGLE 选择
        if any(face.select for face in self.bm.faces):
            self.follow_face = True

        self.mirror_pairs: dict | None
        self.set_edges: set[BMEdge]
        self.mirror_pairs, self.set_edges = self._resolve_mirror_edges(self.border_edges, self.act_obj)
        if not self.set_edges:
            return {'CANCELLED'}

        self.loops_data: list[OffsetLoopData] = self._build_loops(self.set_edges, self.mirror_pairs)
        if self.loops_data is None:
            self.report({'WARNING'}, "Overlap detected. Select non-overlapping edge loops")
            return {'CANCELLED'}

        if not context.region_data:
            return self.execute(context)

        self.init_mouse_position(event)
        self.drag_base_x: int = event.mouse_x
        self.drag_axis = 'WIDTH'
        self.is_numeric_input = False
        self.numeric_input_amount = '0'

        self.init_status(context, func=_draw_offset_edges_status(self))
        self.update_header_text(context)
        self.init_modal_handlers(context, view3d=True)
        force_ui_update(context)

        return {'RUNNING_MODAL'}

    def modal(self, context: Context, event: Event):
        if context.area is None:
            # 视图/工作区已关闭: 最小收敛并退出, 否则每个后续事件都抛 AttributeError 且模态永不收敛
            self._abort_without_area(context)
            return {'CANCELLED'}

        if ignore_events(event):
            return {'RUNNING_MODAL'}

        context.area.tag_redraw()
        self.init_mouse_position(event)

        return self._handle_modal_events(context, event)

    def _handle_modal_events(self, context: Context, event: Event):
        if self._handle_numeric_input(context, event):
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            self._handle_mouse_move(context, event)
        elif navigation_passthrough(event, alt=True):
            # 视图导航(MMB 旋转等): 事件交给导航系统, 下一个 MOUSEMOVE 重置拖动基线
            self.pass_through = True
            return {'PASS_THROUGH'}
        elif event.value == 'PRESS':
            return self._handle_key_press(context, event)

        return {'RUNNING_MODAL'}

    def _handle_mouse_move(self, context: Context, event: Event):
        """水平拖动调当前拖动轴(宽度/深度按距离口径, 角度按弧度口径, 灵敏度固定)"""
        if self.pass_through:
            # 视图导航结束: 重置拖动基线, 不更新参数
            self.pass_through = False
            self.drag_base_x = event.mouse_x
            return

        if self.is_numeric_input:
            # 非拖动状态也跟进基线: 退出数字输入后首帧增量才从当前位置起算
            self.drag_base_x = event.mouse_x
            return

        dx = event.mouse_x - self.drag_base_x
        if self.drag_axis == 'DEPTH':
            self.depth += dx * MODAL_DRAG_SENSITIVITY
        elif self.drag_axis == 'ANGLE':
            self.angle += dx * ANGLE_DRAG_SENSITIVITY
        else:
            self.width += dx * MODAL_DRAG_SENSITIVITY
        self.drag_base_x = event.mouse_x

        self._apply_preview()
        self.update_header_text(context)
        force_ui_update(context)

    def _handle_key_press(self, context: Context, event: Event):
        """按键分发: W 切几何模式, D/A 切拖动轴, F/R/M 切选项, X 重置当前轴, 确认与取消"""
        if event.type == 'W':
            self.geometry_mode = step_enum(self.geometry_mode, offset_geometry_mode_items, 1)
        elif event.type == 'D':
            # 深度拖动轴仅在 DEPTH 深度模式下可用(ANGLE 模式深度由宽度与角度推出);
            # 切轴即结束数字输入会话——缓冲是旧轴的输入原文, 带过去会把数字写给新轴
            if self.depth_mode == 'DEPTH':
                if event.alt:
                    # Alt+D 重置: 深度归零并退回宽度拖动轴(口径对齐 ChamferToFillet 的 Alt+W)
                    self.depth = 0.0
                    self.drag_axis = 'WIDTH'
                else:
                    self.drag_axis = 'WIDTH' if self.drag_axis == 'DEPTH' else 'DEPTH'
                self.is_numeric_input = False
        elif event.type == 'A':
            # 角度拖动轴仅在 ANGLE 深度模式下可用(DEPTH 模式角度不参与求值); 会话收尾同 D
            if self.depth_mode == 'ANGLE':
                if event.alt:
                    # Alt+A 重置: 角度归零并退回宽度拖动轴(口径对齐 Alt+D)
                    self.angle = 0.0
                    self.drag_axis = 'WIDTH'
                else:
                    self.drag_axis = 'WIDTH' if self.drag_axis == 'ANGLE' else 'ANGLE'
                self.is_numeric_input = False
        elif event.type == 'S':
            # 深度模式切换(直接深度/由角度推出): 非宽度拖动轴的语义随模式失效, 一律退回宽度并结束数字会话
            self.depth_mode = step_enum(self.depth_mode, depth_mode_items, 1)
            if self.drag_axis != 'WIDTH':
                self.drag_axis = 'WIDTH'
                self.is_numeric_input = False
        elif event.type in {'F', 'R', 'M'}:
            if event.type == 'F':
                self.follow_face = not self.follow_face
            elif event.type == 'R':
                self.edge_rail = not self.edge_rail
            else:
                self.use_mirror = not self.use_mirror
            self._recompute_directions()
        elif event.type == 'X':
            self._reset_params()
        elif event.type in {'LEFTMOUSE', 'SPACE', 'RET', 'NUMPAD_ENTER'}:
            self._apply_final()
            self.finish(context)
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.is_numeric_input:
                self.is_numeric_input = False
            else:
                self._cancel(context)
                return {'CANCELLED'}

        self._apply_preview()
        self.update_header_text(context)
        force_ui_update(context)
        return {'RUNNING_MODAL'}

    def _handle_numeric_input(self, context: Context, event: Event) -> bool:
        """数字键精确输入当前拖动轴的数值, 返回事件是否已被消费

        宽度/深度按屏幕单位解读(除以系数还原内部米值), 角度按度输入(转弧度, 与
        F9 面板的角度显示口径一致).
        """
        start = numeric_start_value(event)

        if not self.is_numeric_input:
            if start is None:
                return False
            # 起始键不在此返回: 置空缓冲落入下方 feed 分支, 与后续键走同一应用路径——
            # 否则单键输入(如深度归零的 "0")只改 header 显示不应用值, 直接确认还会丢输入
            self.is_numeric_input = True
            self.numeric_input_amount = ""

        buffer, action = feed_numeric(self.numeric_input_amount, event)
        if action == 'ignore':
            return False
        self.numeric_input_amount = buffer
        if action == 'cancel':
            # 退格删空退出输入态: header 从输入原文回数值口径(与 hole_extrude 同族口径)
            self.is_numeric_input = False
            self.update_header_text(context)
            return True

        try:
            if self.drag_axis == 'ANGLE':
                self.angle = radians(float(buffer))
            elif self.drag_axis == 'DEPTH':
                # 数字输入按屏幕单位解读, 除以系数还原内部米值(见 get_length_unit_data)
                self.depth = float(buffer) / get_length_unit_data(context)[1]
            else:
                self.width = float(buffer) / get_length_unit_data(context)[1]
        except ValueError:
            # 缓冲暂不可解析(如只敲了小数点): header 刷出缓冲原文供用户核对
            self.update_header_text(context)
            return True

        self._apply_preview()
        self.update_header_text(context)
        force_ui_update(context)
        return True

    def _reset_params(self):
        """重置当前拖动轴的数值(宽度回默认, 深度/角度归零; 翻转开关不动)"""
        if self.drag_axis == 'DEPTH':
            self.depth = 0.0
        elif self.drag_axis == 'ANGLE':
            self.angle = 0.0
        else:
            self.width = DEFAULT_WIDTH
            self.flip_width = False

    def _get_width_depth(self) -> tuple[float, float]:
        """按深度模式与翻转开关换算实际的宽度/深度标量"""
        if self.depth_mode == 'ANGLE':
            angle = -self.angle if self.flip_angle else self.angle
            width = self.width * cos(angle)
            depth = self.width * sin(angle)
        else:
            width, depth = self.width, self.depth

        return (-width if self.flip_width else width, -depth if self.flip_depth else depth)

    def _recompute_directions(self):
        """F/R/M 选项变化重算方向(只读, 不动拓扑)

        先还原原顶点到基线, 再按当前选项重新过滤镜像边集并重建环(与 invoke 同一条管线):
        否则"整体落在镜像平面上的边不参与偏移"这条源规则只在 invoke 时 M 已开启的情况下生效,
        模态中按 M 打开镜像会把这些边仍留在环里参与偏移.
        """
        for loop in self.loops_data:
            restore_vert_positions(loop.orig_verts, loop.orig_base_coords)

        self.mirror_pairs, self.set_edges = self._resolve_mirror_edges(self.border_edges, self.act_obj)
        if not self.set_edges:
            self.loops_data = []
            return

        loops_data = self._build_loops(self.set_edges, self.mirror_pairs)
        if loops_data is None:
            # 镜像过滤只可能减少边, 不会新增重叠; 保留原载荷以防万一
            return
        self.loops_data = loops_data

    def _apply_preview(self):
        """按当前参数应用预览: MOVE 模式实时位移原顶点, 其余模式记录虚拟偏移环坐标供 GPU 绘制"""
        width, depth = self._get_width_depth()

        moved = False
        for loop in self.loops_data:
            loop.preview_coords = [base_co + width * vec_width + depth * vec_depth for base_co, (vec_width, vec_depth) in zip(loop.orig_base_coords, loop.directions)]
            # 折线索引对只依赖点数与闭合性(模态期恒定): 随坐标一次算好, draw 每帧只读
            n = len(loop.preview_coords)
            if loop.is_closed:
                loop.preview_indices = [(idx, (idx + 1) % n) for idx in range(n)]
            else:
                loop.preview_indices = [(idx, idx + 1) for idx in range(n - 1)]
            if self.geometry_mode == 'MOVE':
                for vert, co in zip(loop.orig_verts, loop.preview_coords):
                    vert.co = co
                moved = True
            elif self._verts_moved:
                # 离开 MOVE 模式后的一次性还原(保证偏移始终基于初始网格): 顶点已在基线
                # 位置时不再重复还原, 也不必每事件同步显示网格
                restore_vert_positions(loop.orig_verts, loop.orig_base_coords)

        if moved or self._verts_moved:
            # 顶点坐标被写(位移或还原), 重算法线保证预览着色正确; 其余模式网格未被修改
            # (预览走 GPU 折线), 每事件全网格法线重算 + 显示网格同步是纯浪费
            self.bm.normal_update()
            bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=False, destructive=False)

        self._verts_moved = moved

    def _apply_final(self):
        """确认: 一次性执行真实拓扑变更(挤出/清理)并把副本顶点写到预览位置; MOVE 模式顶点已在位"""
        if self.geometry_mode == 'MOVE':
            return

        width, depth = self._get_width_depth()
        for loop in self.loops_data:
            geom = _extrude_edges(self.bm, loop.edges_orig)
            moved_verts = _collect_moved_verts(loop.orig_verts, geom)
            _clean_selection(self.bm, self.geometry_mode, loop.edges_orig, geom)

            for vert, base_co, (vec_width, vec_depth) in zip(moved_verts, loop.orig_base_coords, loop.directions):
                vert.co = base_co + width * vec_width + depth * vec_depth

        # 顶点位移/挤出后重算法线(着色正确), 再以拓扑变更参数同步
        self.bm.normal_update()
        # 拓扑已变更(挤出/删除): destructive=True 通知依赖系统失效, loop_triangles=True 重算三角化
        # ——否则绘制系统 extract_tris 用陈旧三角化索引新几何, ACCESS_VIOLATION 崩溃
        bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=True, destructive=True)

    def _cancel(self, context: Context):
        """取消: MOVE 模式还原原顶点坐标并恢复选择后收敛; 其余模式模态期未动网格"""
        if self.geometry_mode == 'MOVE':
            for loop in self.loops_data:
                restore_vert_positions(loop.orig_verts, loop.orig_base_coords)
                for edge in loop.edges_orig:
                    edge.select = True
            # 还原后重算法线
            self.bm.normal_update()
            bmesh.update_edit_mesh(self.act_obj.data, loop_triangles=False, destructive=False)

        self.finish(context)

    def execute(self, context: Context):
        # 自包含执行: 从当前选区全新解析并构建, 不依赖 invoke 写入的实例状态 ——
        # F9 重做经撤销系统重建编辑态 BMesh, 模态期持有的顶点引用已失效, 不能复用;
        # 重建式执行同时让脚本直调可用(对齐源算子语义)
        act_obj = context.active_object
        bm = bmesh.from_edit_mesh(act_obj.data)

        border_edges = get_selection_border_edges(bm)
        if not border_edges:
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}

        mirror_pairs, set_edges = self._resolve_mirror_edges(border_edges, act_obj)
        if not set_edges:
            return {'CANCELLED'}

        loops_data = self._build_loops(set_edges, mirror_pairs)
        if loops_data is None:
            self.report({'WARNING'}, "Overlap detected. Select non-overlapping edge loops")
            return {'CANCELLED'}

        width, depth = self._get_width_depth()
        for loop in loops_data:
            if self.geometry_mode == 'MOVE':
                moved_verts, base_coords = loop.orig_verts, loop.orig_base_coords
                geom = None
            else:
                geom = _extrude_edges(bm, loop.edges_orig)
                moved_verts = _collect_moved_verts(loop.orig_verts, geom)
                base_coords = snapshot_vert_positions(moved_verts)
                _clean_selection(bm, self.geometry_mode, loop.edges_orig, geom)

            for vert, base_co, (vec_width, vec_depth) in zip(moved_verts, base_coords, loop.directions):
                vert.co = base_co + width * vec_width + depth * vec_depth

        # 顶点位移/挤出后重算法线(着色正确), 再以拓扑变更参数同步(见 _apply_final 注释)
        bm.normal_update()
        bmesh.update_edit_mesh(act_obj.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

    def finish(self, context: Context):
        """finish 阶段: 按约定 10 的顺序收敛(状态栏 -> 模态处理器 -> 头部文本 -> 释放资源)"""
        self.finish_status()
        self.finish_modal_handlers()
        context.area.header_text_set(None)
        self.act_obj.update_from_editmode()
        force_ui_update(context)

    def update_header_text(self, context: Context):
        """更新区域header文本, 只显示数值信息(宽度恒显; 深度/角度按深度模式追加)"""
        # 内部米值乘系数换算成场景单位显示; 数字输入分支当前轴显示用户输入原文(本就是屏幕单位值)
        unit, factor = get_length_unit_data(context)
        if self.is_numeric_input:
            width_text = self.numeric_input_amount if self.drag_axis == 'WIDTH' else format_adaptive_precision(self.width * factor, 2)
        else:
            width_text = format_adaptive_precision(self.width * factor, 2)
        text = f"Width: {width_text} {unit}"

        if self.depth_mode == 'ANGLE':
            if self.is_numeric_input and self.drag_axis == 'ANGLE':
                angle_text = self.numeric_input_amount
            else:
                angle_text = f"{format_adaptive_precision(degrees(self.angle), 1)}°"
            text += f" | Angle: {angle_text}"
        else:
            if self.is_numeric_input and self.drag_axis == 'DEPTH':
                depth_text = self.numeric_input_amount
            else:
                depth_text = format_adaptive_precision(self.depth * factor, 2)
            text += f" | Depth: {depth_text} {unit}"

        context.area.header_text_set(text)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "geometry_mode")

        row = layout.row(align=True)
        row.prop(self, "width")
        row.prop(self, "flip_width", icon='ARROW_LEFTRIGHT', icon_only=True)

        row = layout.row(align=True)
        row.prop(self, "depth_mode", expand=True)
        row = layout.row(align=True)
        if self.depth_mode == 'ANGLE':
            row.prop(self, "angle")
            row.prop(self, "flip_angle", icon='ARROW_LEFTRIGHT', icon_only=True)
        else:
            row.prop(self, "depth")
            row.prop(self, "flip_depth", icon='ARROW_LEFTRIGHT', icon_only=True)

        layout.prop(self, "follow_face")
        row = layout.row()
        row.prop(self, "edge_rail")
        if self.edge_rail:
            row.prop(self, "edge_rail_only_end", text="Only End", toggle=True)
        layout.prop(self, "use_mirror")
        if self.follow_face:
            layout.prop(self, "threshold")

    def draw_VIEW3D(self, context: Context):
        """GPU 预览: OFFSET 青色折线, EXTRUDE 黄色折线 + 原顶点连接线(表现挤出壁), 模式一目了然"""
        if self.pass_through or context.area != self.area:
            return
        if self.geometry_mode == 'MOVE':
            return

        for loop in self.loops_data:
            coords = loop.preview_coords
            if len(coords) < 2:
                continue

            color = yellow if self.geometry_mode == 'EXTRUDE' else cyan
            draw_line(coords, indices=loop.preview_indices, mx=self.act_mx, color=color, alpha=0.8, xray=True)

            if self.geometry_mode == 'EXTRUDE':
                connectors = [co for base_co, preview_co in zip(loop.orig_base_coords, coords) for co in (base_co, preview_co)]
                draw_lines(connectors, mx=self.act_mx, color=cyan, alpha=0.5, width=2, xray=True)


def _draw_offset_edges_status(op: OffsetEdges):
    def draw(self, context: Context):
        layout = self.layout
        row = layout.row(align=True)

        draw_status_item(row, key='LMB', text="Finish")
        draw_status_item(row, key='MMB', text="Viewport Navigation")
        draw_status_item(row, key='RMB', text="Cancel")

        draw_status_item(row, active=True, key='W', text=MODE_LABELS[op.geometry_mode], gap=3)
        # S 深度模式项: 显示当前模式(与 D/A 拖动轴项的可用条件同口径; 词条走系统 mo)
        draw_status_item(row, active=True, key='S', text="Angle" if op.depth_mode == 'ANGLE' else "Depth")

        # D/A 拖动轴切换按深度模式出现(拖动轴非宽度时高亮; 与按键分发的可用条件同口径)
        if op.depth_mode == 'DEPTH':
            draw_status_item(row, active=op.drag_axis == 'DEPTH', key='D', text="Depth")
            if op.drag_axis == 'DEPTH':
                draw_status_item(row, key=['ALT', 'D'], text="Reset")
        elif op.depth_mode == 'ANGLE':
            draw_status_item(row, active=op.drag_axis == 'ANGLE', key='A', text="Angle")
            if op.drag_axis == 'ANGLE':
                draw_status_item(row, key=['ALT', 'A'], text="Reset")

        draw_status_item(row, active=op.follow_face, key='F', text="Follow Face")
        draw_status_item(row, active=op.edge_rail, key='R', text="Inner Edge Rail")
        draw_status_item(row, active=op.use_mirror, key='M', text="Mirror")

        draw_status_item(row, key='X', text="Reset")

    return draw
