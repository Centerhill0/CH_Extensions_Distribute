"""
曲线对齐操作器模块

提供以下功能:
- AlignEditCurve: 曲线编辑模式下控制点对齐
"""

__all__ = ["AlignEditCurve"]

from bpy.props import EnumProperty
from bpy.types import Context, Event, Operator
from mathutils import Vector

from ...items import align_direction_items, align_type_items, sorted_axis_items, space_items
from ...utils import (
    get_view_aligned_axes,
    get_space_transform_matrix,
    transform_local_to_space,
    transform_space_to_local,
)


def _iter_selected_points(curve):
    """跨样条迭代选中的控制点, 产出 (是否贝塞尔, 点)——BEZIER 样条的 spline.points 恒为空
    (RNA 层如此, 见 utils.blender.curve 注), 须走 bezier_points 分支"""
    for spline in curve.splines:
        if spline.type == 'BEZIER':
            yield from ((True, point) for point in spline.bezier_points if point.select_control_point)
        else:
            yield from ((False, point) for point in spline.points if point.select)


# ============================================================
# 曲线编辑模式对齐操作器
# ============================================================
class AlignEditCurve(Operator):
    """
    曲线编辑模式控制点对齐操作器
    功能:将选中的控制点沿视图轴对齐到选区边界或居中
    - 默认:局部空间对齐
    - Alt:世界空间对齐
    - Ctrl:游标空间对齐
    - 居中:水平/垂直居中到选区包围盒中心(F9 可切零点/游标)

    要求:曲线编辑模式下有选中控制点
    """

    bl_idname = "ch.align_edit_curve"
    bl_label = "Align Edit Curve"
    bl_description = "Align Selected Points to Axis\n+Alt: World Space\n+Ctrl: Cursor Space"
    bl_options = {'REGISTER', 'UNDO'}

    align_axis: EnumProperty(name="Align Axis", items=sorted_axis_items, description="Align on the X, Y or Z Axis", default='0')  # type: ignore
    align_space: EnumProperty(name="Align Space", items=space_items, description="Align in Local, World or Cursor Space", default='LOCAL')  # type: ignore
    align_direction: EnumProperty(name="Align Direction", items=align_direction_items[:6], description="Align Direction", default='Align_Right')  # type: ignore
    align_type: EnumProperty(name="Align Type", items=align_type_items, description="Align to Average, Zero or Cursor", default='AVERAGE')  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        if context.mode != "EDIT_CURVE":
            return
        act_obj = context.active_object
        if act_obj is None or act_obj.type != 'CURVE':
            return
        return any(True for _ in _iter_selected_points(act_obj.data))

    def invoke(self, context: Context, event: Event):
        # Alt和Ctrl不能同时按下
        if event.alt and event.ctrl:
            self.report({'ERROR'}, "Hold down Alt, Ctrl or neither, not both!")
            return {'CANCELLED'}

        # 根据修饰键设置对齐空间
        if event.ctrl:
            self.align_space = 'CURSOR'
        elif event.alt:
            self.align_space = 'WORLD'
        else:
            self.align_space = 'LOCAL'

        self.act_obj = context.active_object

        # 获取视图对齐的坐标轴信息(invoke 用于定轴, execute 对齐时共用翻转标记)
        self._update_view_axes(context)
        self._derive_axis_from_direction()
        return self.execute(context)

    def _derive_axis_from_direction(self) -> None:
        """由对齐方向推导视图轴(F9 面板改 direction 后 execute 须重推, 否则沿旧轴对齐)"""
        self.align_axis = str(self.axis_right_idx if self.align_direction in {'Align_Right', 'Align_Left', 'Align_Center_H'} else self.axis_up_idx)

    def _update_view_axes(self, context: Context) -> None:
        """计算视图对齐轴与翻转标记(上下文派生, invoke 与 execute 各自现算)"""
        self.axis_right_idx, self.axis_up_idx, self.is_flip_right, self.is_flip_up = get_view_aligned_axes(
            context,
            mx=get_space_transform_matrix(context, self.act_obj, self.align_space),
        )

    def execute(self, context: Context):
        # 上下文派生状态现算, 保证 execute 可未经 invoke 直接执行(脚本调用 / F9 重做)
        self.act_obj = context.active_object
        self._update_view_axes(context)
        self._derive_axis_from_direction()

        curve = self.act_obj.data
        mx = transform_local_to_space(context, self.act_obj, self.align_space)
        inv_mx = transform_space_to_local(context, self.act_obj, self.align_space)

        # 收集选中控制点(局部坐标): 整体选区一组界, 不分孤岛(网格版的孤岛/各自原点暂不进曲线版)
        selected = [(is_bezier, point, point.co.copy() if is_bezier else point.co.to_3d()) for is_bezier, point in _iter_selected_points(curve)]
        if not selected:
            return {'CANCELLED'}

        # 选区在目标空间沿视图轴的边界(左/下取 min = 右/上翻转标记取反); 居中方向取包围盒中心或零点/游标
        cos_space = [mx @ co_local for _, _, co_local in selected]
        axis = int(self.align_axis)
        if self.align_direction in {'Align_Center_H', 'Align_Center_V'}:
            axis_val = self._get_center_axis_value(context, axis, cos_space)
        else:
            if self.align_direction in {'Align_Right', 'Align_Left'}:
                is_flip = self.is_flip_right if self.align_direction == 'Align_Right' else not self.is_flip_right
            else:
                is_flip = self.is_flip_up if self.align_direction == 'Align_Up' else not self.is_flip_up
            axis_val = min(co[axis] for co in cos_space) if is_flip else max(co[axis] for co in cos_space)

        for is_bezier, point, co_local in selected:
            co_target = mx @ co_local
            co_target[axis] = axis_val
            new_local = inv_mx @ co_target
            if is_bezier:
                delta = new_local - co_local
                point.co = new_local
                # 手柄是绝对局部坐标: 与控制点平移同一 delta 保持手柄相对形状(AUTO 手柄由 Blender 重算, 不受影响)
                point.handle_left = point.handle_left + delta
                point.handle_right = point.handle_right + delta
            else:
                point.co = Vector((*new_local, point.co.w))

        return {'FINISHED'}

    def _get_center_axis_value(self, context: Context, axis: int, cos_space: list[Vector]) -> float:
        """居中方向的对齐值: 平均=选区包围盒中心, 零点=0, 游标=游标在目标空间沿轴的分量(网格版同款口径)"""
        if self.align_type == 'AVERAGE':
            return (min(co[axis] for co in cos_space) + max(co[axis] for co in cos_space)) / 2
        if self.align_type == 'ZERO':
            return 0
        match self.align_space:
            case 'LOCAL':
                cur_loc_local = self.act_obj.matrix_world.inverted_safe() @ context.scene.cursor.location
                return cur_loc_local[axis]
            case 'WORLD':
                return context.scene.cursor.location[axis]
            case _:
                # 游标空间下游标即原点
                return 0

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        row = layout.row()
        row.prop(self, "align_axis", expand=True)
        layout.prop(self, "align_space", expand=True)
        layout.prop(self, "align_direction")

        if self.align_direction in {'Align_Center_H', 'Align_Center_V'}:
            layout.prop(self, "align_type", expand=True)
