"""
晶格修改器模块

提供以下功能:
- LatticeOverlay: 自动为选中物体添加晶格修改器
- ApplyLattice: 应用晶格修改器到目标物体

模块常量:
- SUPPORT_TYPES: 支持晶格操作的物体类型集合
"""

__all__ = ["LatticeOverlay", "ApplyLattice"]

import bpy
from bpy.types import Operator, Context, Object, Modifier
from mathutils import Matrix, Vector, Euler
from bpy.props import EnumProperty, BoolProperty, IntVectorProperty, FloatVectorProperty

from .....common.i18n.i18n import report

from ...items import space_items, processing_mode_items, interpolation_type_items, lattice_apply_mode_items
from ...utils import (
    MeasureIsland,
    MeasureIslands,
    MeasureObject,
    MeasureObjects,
    get_evaluated_objects,
    set_object_parent,
    add_lattice_modifier,
)

# 蜡笔不在列: 其 modifiers.new('LATTICE') 返回 None(晶格变形走 grease_pencil_modifiers), 混入会在赋值时崩溃
SUPPORT_TYPES = {'MESH', 'LATTICE', 'CURVE', 'SURFACE', 'FONT'}


# ============================================================
# 晶格覆盖操作器
# ============================================================
class LatticeOverlay(Operator):
    """
    晶格覆盖

    功能:自动为选中物体添加晶格修改器
    - 支持三种空间模式:局部/世界/游标
    - 支持两种处理模式:独立/整体
    - 支持自定义晶格分辨率和缩放
    - 支持自动设置父子关系

    要求:有选中物体
    """

    bl_idname = "ch.lattice_helper"
    bl_label = "Lattice Overlay"
    bl_description = "Automatically add a lattice to selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    space: EnumProperty(name="Space", description="The space of the object to use for the lattice", items=space_items, default='LOCAL')  # type: ignore
    mode: EnumProperty(name="Mode", description="The mode to add the lattice", items=processing_mode_items, default='INDIVIDUAL')  # type: ignore
    lerp: EnumProperty(name="Interpolation", description="The interpolation type for the lattice", items=interpolation_type_items, default='KEY_BSPLINE')  # type: ignore
    set_parent: BoolProperty(name="Set Parent", description="set the lattice as the parent of the object", default=True)  # type: ignore
    res: IntVectorProperty(name="Resolution", default=[2, 2, 2], size=3, min=2, max=64, description="Number of lattice control points on each axis")  # type: ignore
    multi_scale: FloatVectorProperty(name="Scale", description="scale the lattice", default=[1, 1, 1], min=0.1, max=5)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        # execute 只处理 OBJECT/EDIT_MESH 两分支: 其余模式(雕刻/姿态等)不提供入口
        return context.mode in {'OBJECT', 'EDIT_MESH'} and len(context.selected_objects) > 0

    def execute(self, context: Context):
        # 过滤出支持类型的物体
        self.selected_objs = [obj for obj in context.selected_objects if obj.type in SUPPORT_TYPES]

        if not self.selected_objs:
            self.report({'ERROR'}, report("Not supported objects selected"))
            return {'CANCELLED'}

        # 确定活动物体
        self.obj_0 = context.active_object if context.active_object in self.selected_objs else self.selected_objs[0]

        if context.mode == 'EDIT_MESH':
            self._execute_edit_mesh(context)
        elif context.mode == 'OBJECT':
            self._execute_object(context)

        return {'FINISHED'}

    def _execute_edit_mesh(self, context: Context):
        """
        编辑模式下的执行逻辑

        为选中的网格顶点创建晶格覆盖
        """
        context.view_layer.update()
        obj = context.active_object
        all_islands = MeasureIslands(obj, mx=self._get_transform_matrix(context, obj))

        match self.mode:
            case 'INDIVIDUAL':
                # 独立模式:为每个孤岛创建独立晶格
                for island in all_islands.islands:
                    lattice_obj = self._create_lattice_overlay(context, obj, f"_{island.island_idx:02}", island)
                    if self.set_parent:
                        self._parent_set(lattice_obj, obj, reverse=False)

            case 'GROUP':
                # 整体模式:为所有孤岛创建一个晶格
                lattice_obj = self._create_lattice_overlay(context, obj, "_Group", all_islands)
                if self.set_parent:
                    self._parent_set(lattice_obj, obj, reverse=False)

    def _execute_object(self, context: Context):
        """
        物体模式下的执行逻辑

        为选中的物体创建晶格覆盖
        """
        context.view_layer.update()
        dep_objs = get_evaluated_objects(context, self.selected_objs)
        matrices = [self._get_transform_matrix(context, dep_obj) for dep_obj in dep_objs]
        measure_objs = MeasureObjects(dep_objs, matrices)

        match self.mode:
            case 'INDIVIDUAL':
                # 独立模式:为每个物体创建独立晶格
                for obj, m_obj in zip(self.selected_objs, measure_objs):
                    lattice_obj = self._create_lattice_overlay(context, obj, "", m_obj)
                    if self.set_parent:
                        # 曲线物体需要反向父子关系
                        reverse = True if obj.type == 'CURVE' else False
                        self._parent_set(lattice_obj, obj, reverse=reverse)

            case 'GROUP':
                # 整体模式:为所有物体创建一个晶格; 每个物体都须各挂一枚指向同一晶格的
                # 修改器——此前只给活动物体挂, 其余物体仅被父子绑定, 晶格变形对它们
                # 不生效(晶格虽包住全部物体, 变形却只作用于活动物体)
                lattice_obj = self._create_lattice_overlay(context, self.obj_0, "_Group", measure_objs)
                for obj in self.selected_objs:
                    if obj is not self.obj_0:
                        add_lattice_modifier(obj, lattice_obj, lattice_obj.name + '_VG')
                if self.set_parent:
                    for obj in self.selected_objs:
                        self._parent_set(lattice_obj, obj, reverse=True)

    def _create_lattice_overlay(self, context: Context, target_obj: Object, lattice_name: str, measure: MeasureIsland | MeasureIslands | MeasureObject | MeasureObjects) -> Object:
        """
        创建晶格覆盖物体

        Args:
            context: Blender上下文
            target_obj: 目标物体
            lattice_name: 晶格名称后缀
            measure: 测量数据对象

        Returns:
            创建的晶格物体
        """
        # 添加晶格物体
        lattice_obj = self._add_lattice_object(context, target_obj.name + lattice_name)
        # 设置晶格物体的变换
        self._set_lattice_object_transform(context, lattice_obj, target_obj, measure.dims, measure.center_pos)
        # 添加晶格修改器
        verts_idx = measure.selected_vertices_idx if hasattr(measure, 'selected_vertices_idx') else None
        add_lattice_modifier(target_obj, lattice_obj, lattice_obj.name + '_VG', verts_idx)
        return lattice_obj

    def _get_transform_matrix(self, context: Context, obj: Object) -> Matrix:
        """
        获取变换矩阵

        根据空间模式返回不同的变换矩阵

        Args:
            context: Blender上下文
            obj: 目标物体

        Returns:
            变换矩阵
        """
        mx = obj.matrix_world.copy()

        match self.space:
            case 'LOCAL':
                # 局部空间:消除物体自身旋转的影响(制式无关)
                if context.mode == 'OBJECT' and self.mode == 'GROUP':
                    obj = self.obj_0
                return obj.matrix_world.to_quaternion().to_matrix().to_4x4().inverted_safe() @ mx

            case 'WORLD':
                # 世界空间:使用完整的世界变换矩阵
                return mx

            case 'CURSOR':
                # 游标空间:使用游标的旋转逆矩阵
                return context.scene.cursor.rotation_euler.to_matrix().to_4x4().inverted_safe() @ mx

    def _parent_set(self, lattice_obj: Object, target_obj: Object, reverse: bool = True) -> None:
        """
        设置目标物体与晶格物体的父子关系

        Args:
            lattice_obj: 晶格物体
            target_obj: 目标物体
            reverse: True 表示晶格为父级,False 表示目标物体为父级
        """
        if reverse:
            # 晶格为父级
            set_object_parent(target_obj, lattice_obj)
        else:
            # 目标物体为父级
            set_object_parent(lattice_obj, target_obj)

    def _add_lattice_object(self, context: Context, lattice_name: str) -> Object:
        """
        添加晶格物体并设置参数

        Args:
            context: Blender上下文
            lattice_name: 晶格名称

        Returns:
            创建的晶格物体
        """
        lattice_data = bpy.data.lattices.new(name="LT_" + lattice_name)
        lattice_obj = bpy.data.objects.new(name=lattice_data.name, object_data=lattice_data)
        context.collection.objects.link(lattice_obj)

        # 设置晶格参数
        lattice_data.interpolation_type_u = self.lerp
        lattice_data.interpolation_type_v = self.lerp
        lattice_data.interpolation_type_w = self.lerp
        lattice_data.points_u, lattice_data.points_v, lattice_data.points_w = self.res

        return lattice_obj

    def _set_lattice_object_transform(self, context: Context, lattice_obj: Object, target_obj: Object, scale: Vector, location: Vector) -> None:
        """
        设置晶格物体的变换

        Args:
            context: Blender上下文
            lattice_obj: 晶格物体
            target_obj: 目标物体
            scale: 缩放向量
            location: 位置向量
        """
        # 防止扁平面情况,并增加轴向缩放系数
        final_scale = Vector([i if abs(i) > 0.000001 else 0.1 for i in scale]) * Vector(self.multi_scale)

        match self.space:
            case 'LOCAL':
                # 局部空间:将位置转换到目标物体的旋转坐标系(制式无关)
                target_rot = target_obj.matrix_world.to_quaternion()
                new_loc = target_rot.to_matrix() @ location
                lattice_obj.matrix_world = Matrix.LocRotScale(new_loc, target_rot, final_scale)

            case 'WORLD':
                # 世界空间:直接使用世界坐标
                lattice_obj.matrix_world = Matrix.LocRotScale(location, Euler(), final_scale)

            case 'CURSOR':
                # 游标空间:对齐游标的旋转
                new_loc = context.scene.cursor.rotation_euler.to_matrix() @ location
                lattice_obj.matrix_world = Matrix.LocRotScale(new_loc, context.scene.cursor.rotation_euler, final_scale)

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "space", expand=True)
        layout.prop(self, "mode", expand=True)
        layout.prop(self, "res")
        layout.prop(self, "lerp")
        layout.prop(self, "multi_scale")
        layout.prop(self, "set_parent")


# ============================================================
# 应用晶格修改器操作器
# ============================================================
class ApplyLattice(Operator):
    """
    应用晶格修改器

    功能:自动应用晶格修改器到目标物体
    - 支持三种应用模式:应用/移除/转为形态键
    - 支持应用后删除晶格物体
    - 支持应用后删除顶点组

    要求:物体模式下有选中物体
    """

    bl_idname = "ch.apply_lattice"
    bl_label = "Apply Lattice"
    bl_description = "Automatically apply the lattice modifier"
    bl_options = {'REGISTER', 'UNDO'}

    apply_mode: EnumProperty(name="Apply Mode", description="The mode to apply the lattice modifier", items=lattice_apply_mode_items, default='APPLY')  # type: ignore
    is_delete_lattice: BoolProperty(name="Delete The Lattice", description="Whether to delete the lattice after applying the deformation", default=True)  # type: ignore
    is_delete_vg: BoolProperty(name="Delete The VG", description="Whether to delete the vertex group after applying the deformation", default=True)  # type: ignore

    @classmethod
    def poll(cls, context: Context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context: Context):
        # 分类选中的物体:晶格物体和其他支持类型物体
        self.selected_objects_a = [obj for obj in context.selected_objects if obj.type == 'LATTICE']
        self.selected_objects_b = [obj for obj in context.selected_objects if obj.type in SUPPORT_TYPES - {'LATTICE'}]

        if len(self.selected_objects_a) == 0 and len(self.selected_objects_b) == 0:
            self.report({'ERROR'}, "No objects selected")
            return {'CANCELLED'}

        # 全程隔离操作会吞掉用户选中集与活动物体, 结束前恢复
        pre_selected = context.selected_objects.copy()
        pre_active = context.view_layer.objects.active

        # 应用失败的晶格记录: 删除阶段跳过(失败修改器仅存的锚), 详见 _match_apply_mode
        self._failed_lattices = set()

        self._apply_lattice_object_modifiers(context)
        self._apply_deformed_object_modifiers(context)
        self._delete_applied_lattices(context)
        self._restore_selection(context, pre_selected, pre_active)

        return {'FINISHED'}

    def _apply_lattice_object_modifiers(self, context: Context) -> None:
        """处理选中的晶格物体: 经父级或子级路径应用其承载的晶格修改器"""
        for obj in self.selected_objects_a.copy():
            if obj.parent is not None:
                # 晶格有父级:处理父级物体上的晶格修改器
                context.view_layer.objects.active = obj.parent
                obj.parent.select_set(True)
                for mod in obj.parent.modifiers:
                    if mod.type == 'LATTICE' and mod.object == obj:
                        self._match_apply_mode(obj.parent, mod)

            elif len(obj.children) != 0:
                # 晶格有子级:遍历处理每个子级物体上的晶格修改器
                for child_obj in obj.children:
                    context.view_layer.objects.active = child_obj
                    child_obj.select_set(True)
                    for mod in child_obj.modifiers:
                        if mod.type == 'LATTICE' and mod.object == obj:
                            self._match_apply_mode(child_obj, mod)

    def _apply_deformed_object_modifiers(self, context: Context) -> None:
        """处理选中的非晶格物体: 应用其晶格修改器, 按开关删除涉及顶点组"""
        for obj in self.selected_objects_b.copy():
            context.view_layer.objects.active = obj
            obj.select_set(True)

            del_vg = set()
            for mod in obj.modifiers:
                if mod.type == 'LATTICE' and mod.object is not None:
                    # 预读引用: APPLY/REMOVE/TO_SHAPE_KEY 成功都会把修改器移出栈, 调用
                    # _match_apply_mode 之后再读 mod 是死 Modifier 引用(第三轮复核 P1)
                    lat_obj = mod.object
                    vg_name = mod.vertex_group
                    # 应用失败的修改器仍在位: 其晶格与顶点组都不删——变形没烘进去, 删了
                    # 修改器悬空指向已删物体, 用户重试也失锚
                    if not self._match_apply_mode(obj, mod):
                        self._failed_lattices.add(lat_obj)
                        continue
                    # 收集晶格物体以便后续删除
                    self.selected_objects_a.append(lat_obj)
                    # 收集顶点组名称以便后续删除(按物体分组, 避免跨物体误删; 去重防两个修改器共用同名组二次删除)
                    if vg_name != '':
                        del_vg.add(vg_name)

            # 删除顶点组
            if self.is_delete_vg and del_vg:
                for vg in del_vg:
                    vg_obj = obj.vertex_groups.get(vg)
                    if vg_obj is not None:
                        obj.vertex_groups.remove(vg_obj)

    def _delete_applied_lattices(self, context: Context) -> None:
        """删除已应用的晶格物体(应用失败的跳过: 晶格是失败修改器仅存的锚)"""
        if self.is_delete_lattice:
            for obj in set(self.selected_objects_a):
                if obj.name not in bpy.data.objects or obj in self._failed_lattices:
                    continue

                # 仅对目标晶格执行父级清除, 避免影响当前选中集
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
                bpy.data.objects.remove(obj, do_unlink=True)

    def _restore_selection(self, context: Context, pre_selected, pre_active) -> None:
        """恢复被隔离操作吞掉的选中集与活动物体(已被中途删除的物体跳过)"""
        for obj in pre_selected:
            try:
                if obj.name in bpy.data.objects:
                    obj.select_set(True)
            except ReferenceError:
                continue
        try:
            if pre_active is not None and pre_active.name in bpy.data.objects:
                context.view_layer.objects.active = pre_active
        except ReferenceError:
            pass

    def _match_apply_mode(self, obj: Object, mod: Modifier) -> bool:
        """
        根据应用模式执行相应操作

        Args:
            obj: 目标物体
            mod: 晶格修改器
        Returns:
            是否成功; 失败(APPLY/TO_SHAPE_KEY 报错或物体类型不符)时把晶格记入
            _failed_lattices 供删除阶段跳过——REMOVE 恒成功
        """
        match self.apply_mode:
            case 'APPLY':
                # 应用修改器
                if obj.type in {'CURVE', 'SURFACE', 'MESH'}:
                    # 多用户数据先独立化: modifier_apply 对共享网格 report 错误并抛
                    # RuntimeError(与 ApplyBooleanMod 同款守卫); 包 try 防单个物体失败
                    # 把后续物体的应用,晶格删除与选区恢复全部跳过
                    if obj.data.users > 1:
                        obj.data = obj.data.copy()
                    try:
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    except RuntimeError as e:
                        self.report({'ERROR'}, report("Failed to apply modifier: {}").format(e))
                        self._failed_lattices.add(mod.object)
                        return False
                else:
                    # FONT 物体无法应用修改器
                    self.report({'ERROR'}, report("Cannot apply modifier for this object type"))
                    self._failed_lattices.add(mod.object)
                    return False

            case 'REMOVE':
                # 移除修改器
                bpy.ops.object.modifier_remove(modifier=mod.name)

            case 'TO_SHAPE_KEY':
                # 转为形态键
                if obj.type == 'MESH':
                    if obj.data.users > 1:
                        obj.data = obj.data.copy()
                    try:
                        bpy.ops.object.modifier_apply_as_shapekey(keep_modifier=False, modifier=mod.name)
                    except RuntimeError as e:
                        self.report({'ERROR'}, report("Failed to apply modifier: {}").format(e))
                        self._failed_lattices.add(mod.object)
                        return False
                else:
                    # FONT, CURVE, SURFACE, GP 物体无法应用为形态键
                    self.report({'ERROR'}, report("Cannot apply modifier for this object type"))
                    self._failed_lattices.add(mod.object)
                    return False

        return True

    def draw(self, context: Context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, "apply_mode", expand=True)
        layout.prop(self, "is_delete_lattice")

        # 仅网格物体显示顶点组删除选项
        if context.active_object and context.active_object.type == 'MESH':
            layout.prop(self, "is_delete_vg")
