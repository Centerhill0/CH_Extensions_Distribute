import bpy

from .config import __addon_name__
from .i18n.dictionary import dictionary
from ...common.class_loader import auto_load
from ...common.class_loader.auto_load import add_properties, remove_properties
from ...common.i18n.dictionary import common_dictionary
from ...common.i18n.i18n import load_dictionary
from .icon_manager.icon_load import load_icon, clear_icon
from .keymaps import register_keymaps, unregister_keymaps

# You may declare properties like following, framework will automatically add and remove them.
# Do not define your own property group class in the __init__.py file. Define it in a separate file and import it here.
# 注意不要在__init__.py文件中自定义PropertyGroup类.请在单独的文件中定义它们并在此处导入.
# dup_hash 供 Surface Slide 反查同批关联物体; 其余四项是布尔/Surface Slide 记账键的**纯遮蔽注册**
# (键名权威在 operators/modifier/boolean.py 的 _BOOLEAN_*_PROP 与 surface_slide.py 的
# _SURFACE_TEMP_PROP, 改名须同步这里, 否则记账键会重新出现在"自定义属性"面板).
# 记账读写仍走 obj["..."] 裸 idprop 通道: 同名简单类型 RNA 与裸 idprop 是两套存储
# (RNA 读恒默认值, RNA 写不落裸键), 遮蔽的唯一作用是按 rna_prop_ui 的 is_runtime "API Defined"
# 过滤, 让内部记账键不进物体的"自定义属性"面板(可防止用户误删 F9 重做所需的标记).
_addon_properties = {
    bpy.types.Object: {
        "dup_hash": bpy.props.StringProperty(description="Hash to find associated objects for Surface Slide"),
        "ch_boolean_run": bpy.props.StringProperty(),
        "ch_boolean_mods": bpy.props.StringProperty(),
        "ch_boolean_temp": bpy.props.StringProperty(),
        "ch_surface_slide_temp": bpy.props.BoolProperty(),
    },
}


def register():
    """
    注册插件
    """
    # Register classes
    auto_load.init()
    auto_load.register()

    load_icon()
    register_keymaps()

    add_properties(_addon_properties)

    # Internationalization
    load_dictionary(dictionary)
    bpy.app.translations.register(__addon_name__, common_dictionary)

    print("{} addon is installed.".format(__addon_name__))


def unregister():
    """
    注销插件
    """
    # Internationalization
    bpy.app.translations.unregister(__addon_name__)
    # unRegister classes
    auto_load.unregister()

    clear_icon()
    unregister_keymaps()

    remove_properties(_addon_properties)
    print("{} addon is uninstalled.".format(__addon_name__))
