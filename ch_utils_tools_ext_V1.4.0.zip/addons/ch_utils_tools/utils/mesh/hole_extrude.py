"""
孔洞挤出算法模块

提供孔洞挤出的选区解析, 几何数据提取与网格生成: 面集与有序边界解析, 边界/内部顶点分类,
射线出口坐标, 挤出与推拉坐标更新, 挤出几何创建及收尾清理.
不读偏好, 不调用 report: 失败统一返回 (结果, 错误信息) 元组, 文案由调用方翻译.

主要功能:
- get_hole_selection: 由当前选择解析挤出目标
- build_hole_data: 构建挤出所需的几何与拓扑数据
- get_hole_direction: 按模式取挤出方向向量
- update_hole_exit_coords: 计算边界顶点的射线出口坐标
- build_hole_extruded_data: 生成挤出顶点/面/三角面索引及映射
- build_hole_side_data: 生成侧面四边形与侧面三角面索引
- set_hole_extruded_coords: 按挤出量更新挤出顶点坐标
- apply_hole_push_pull: 按推拉参数更新原始与挤出顶点坐标
- create_hole_geo: 由数据生成挤出几何并标记切割面
- cleanup_hole_mesh: 常规清理与冗余边溶解
- reset_hole_mesh: 用初始快照重置编辑网格
"""

import math
from copy import copy
from dataclasses import dataclass

import bpy
import bmesh
from bmesh.types import BMesh
from bpy.types import Object
from mathutils import Vector

from ..blender.raycast import RaycastCache, raycast_from_point
from ..infrastructure.data import rotate_list
from ..math.geometry import get_average_normals, get_average_position, get_face_angle
from .bmesh_utils import ensure_face_cut_layer, get_loop_triangles
from .topology import get_boundary_edges, get_mesh_element_islands, get_vert_sequences

# 切割面标记层: 生成阶段给新增面打标记, 清理阶段据此溶解共面冗余边, 收尾即移除层
# 创建与查取共用同一常量名: 名字不一致时查取恒为空, 冗余边溶解与层移除会静默失效
CUT_LAYER_NAME = "hole_extrude"

# 默认无射线出口时的偏移系数: 基于选区面积平方根的小量, 避免射线的自相交
_RAY_ORIGIN_OFFSET_SCALE = 0.00001


@dataclass
class HoleVertData:
    """挤洞顶点载荷(原始/挤出顶点共用, 存于 original_verts/extruded_verts 容器)"""

    co: Vector  # 当前坐标
    init_co: Vector  # 初始坐标
    exit_co: Vector | None  # 射线出口坐标
    vert_dir: Vector  # 顶点法线方向(取反)
    push_dir: Vector | None  # 边界推挤方向
    bound_idx: int  # 边界序列索引, 内部顶点为-1


def ensure_hole_cut_layer(bm: BMesh):
    """
    确保孔洞挤出的切割面标记层存在

    Args:
        bm: BMesh对象

    Returns:
        整数层对象
    """
    return ensure_face_cut_layer(bm, CUT_LAYER_NAME)


def get_hole_selection(bm: BMesh) -> tuple[tuple | None, str | None]:
    """
    由当前选择解析挤出目标: 面选择优先, 无面选择时由闭合顶点/边环填充区域

    Args:
        bm: BMesh对象

    Returns:
        ((faces, loop_triangles, sorted_boundary_verts, inner_verts) 或 None, 错误信息或 None)
    """
    faces = {f for f in bm.faces if f.select}

    if not faces:
        verts = {v for v in bm.verts if v.select}

        if not verts:
            return None, "You need to select at least one face or a closed verts/edge loop"

        sequences = get_vert_sequences(verts, ensure_seq_len=True)

        if not sequences:
            return None, "You need to select at least one face or a closed verts/edge loop"

        vert_seq_list = [s for s, c in sequences if c]

        if not vert_seq_list:
            return None, "You need to select at least one face or a closed verts/edge loop"

        if len(vert_seq_list) == 1:
            vert_seq = vert_seq_list[0]
        else:
            vert_seq = max(vert_seq_list, key=lambda x: len(x))

        for s, _ in sequences:
            if s != vert_seq:
                for v in s:
                    v.select_set(False)
        bm.select_flush_mode()

        bpy.ops.mesh.loop_to_region()
        faces = {f for f in bm.faces if f.select}

        if not faces:
            # 闭合环内部无可填充面(围住既有空洞/自接触环), loop_to_region 无产出
            return None, "You need to select at least one face or a closed verts/edge loop"

    islands = get_mesh_element_islands(faces)
    faces = max(islands, key=lambda x: len(x[2]))[2]

    if set(faces) == {f for f in bm.faces}:
        return None, "The whole mesh is selected"

    loop_triangles = get_loop_triangles(bm, faces)
    verts = {v for f in faces for v in f.verts}
    boundary_edges = get_boundary_edges(faces)
    boundary_verts = list(set(v for e in boundary_edges for v in e.verts))
    inner_verts = [v for v in verts if v not in boundary_verts]

    if any(any(not e.is_manifold for e in v.link_edges) for v in boundary_verts):
        return None, "Selection is next to non-manifold edges!"

    sequences = get_vert_sequences(boundary_verts, boundary_edges)

    if len(sequences) > 1:
        return None, "Selection contains multiple edge loops, try selecting a single loop"

    sorted_boundary_verts = sequences[0][0]
    first_edge = bm.edges.get(sorted_boundary_verts[:2])

    for loop in first_edge.link_loops:
        if loop.face in faces:
            if loop.vert != sorted_boundary_verts[0]:
                sorted_boundary_verts.reverse()

    smallest = min(sorted_boundary_verts, key=lambda x: x.index)

    if smallest != sorted_boundary_verts[0]:
        rotate_list(sorted_boundary_verts, sorted_boundary_verts.index(smallest))

    return (faces, loop_triangles, sorted_boundary_verts, inner_verts), None


def build_hole_data(faces: set, loop_triangles: list, sorted_boundary_verts: list, inner_verts: list, mx, cmx, axis_vectors: dict) -> dict:
    """
    收集并组织挤洞操作所需的所有几何与拓扑数据

    Args:
        faces: 选中的面集合
        loop_triangles: 选中面的三角形循环列表
        sorted_boundary_verts: 有序边界顶点列表
        inner_verts: 内部顶点列表
        mx: 物体世界矩阵
        cmx: 游标世界矩阵
        axis_vectors: 三轴单位向量({'X'/'Y'/'Z': Vector}), 用于派生游标空间方向

    Returns:
        挤出数据字典
    """
    inv_mx = mx.inverted_safe()

    data = {
        'original_verts': {},
        'extruded_verts': {},
        'original_faces': {},
        'extruded_faces': {},
        'side_faces': {},
        'original_tri_indices': [],
        'extruded_tri_indices': [],
        'side_tri_indices': [],
        'sorted_boundary': [],
        'sorted_boundary_indices': [],
        'vert_map': {},
        'avg_co': get_average_position([f.calc_center_median() for f in faces]),
        'avg_dir': -get_average_normals([f.normal for f in faces]),
        'edge_co': None,
        'edge_dir': None,
        'cursor_dir_x': inv_mx.to_3x3() @ (cmx.to_quaternion() @ axis_vectors['X']),
        'cursor_dir_y': inv_mx.to_3x3() @ (cmx.to_quaternion() @ axis_vectors['Y']),
        'cursor_dir_z': inv_mx.to_3x3() @ (cmx.to_quaternion() @ axis_vectors['Z']),
        'area': 0,
    }

    # 保证坐标轴方向与平均法线方向一致, 若相反则取反
    for axis in axis_vectors:
        cursor_dir = data[f"cursor_dir_{axis.lower()}"]
        if cursor_dir.dot(data['avg_dir']) < 0:
            cursor_dir.negate()

    seen = {}  # 记录顶点对象到索引的映射, 避免重复
    orig_verts = data['original_verts']
    orig_faces = data['original_faces']
    # 边界顶点索引预建映射: 循环内 list.index 是 O(n²), 大环时明显拖慢构建
    boundary_index_map = {v: idx for idx, v in enumerate(sorted_boundary_verts)}
    vidx = 0  # 顶点索引计数器

    # 遍历所有面, 收集顶点和面信息
    for fidx, f in enumerate(faces):
        face_vidx_list = []  # 当前面的顶点索引列表
        for v in f.verts:
            if v not in seen:
                seen[v] = vidx
                # 计算该顶点的法线方向(取反)
                vert_dir = -get_average_normals([f.normal for f in v.link_faces if f in faces])
                # 判断是否为内顶点, 边界顶点需记录其在边界序列中的索引
                bound_idx = -1 if v in inner_verts else boundary_index_map[v]
                orig_verts[vidx] = HoleVertData(
                    co=v.co.copy(),
                    init_co=v.co.copy(),
                    exit_co=None,
                    vert_dir=vert_dir,
                    push_dir=None,
                    bound_idx=bound_idx,
                )
                face_vidx_list.append(vidx)
                vidx += 1
            else:
                face_vidx_list.append(seen[v])
        orig_faces[fidx] = face_vidx_list
        data['area'] += f.calc_area()

    # 记录所有三角面顶点索引
    data['original_tri_indices'] = [seen[l.vert] for lt in loop_triangles for l in lt]

    # 生成有序边界顶点索引及其成对索引
    sorted_boundary = [seen[v] for v in sorted_boundary_verts]
    data['sorted_boundary'] = sorted_boundary
    data['sorted_boundary_indices'] = [(idx, (idx + 1) % len(sorted_boundary)) for idx in range(len(sorted_boundary))]

    # 计算每个边界顶点的推挤方向(push_dir)
    for idx, vidx in enumerate(sorted_boundary):
        v_co = orig_verts[vidx].co
        vert_dir = orig_verts[vidx].vert_dir
        next_vidx = sorted_boundary[(idx + 1) % len(sorted_boundary)]
        prev_vidx = sorted_boundary[(idx - 1) % len(sorted_boundary)]
        # 前后相邻顶点方向
        fwd_vec = (orig_verts[next_vidx].co - v_co).normalized()
        bwd_vec = (orig_verts[prev_vidx].co - v_co).normalized()
        # 前后方向的合成
        fwd_dir = (v_co + fwd_vec - (v_co + bwd_vec)).normalized()
        # 推挤方向为法线与前后方向的叉积
        push_dir = vert_dir.cross(fwd_dir)
        orig_verts[vidx].push_dir = push_dir

    return data


def get_hole_direction(data: dict, mode: str, cursor_axis: str) -> Vector | None:
    """
    按挤出模式取方向向量

    Args:
        data: 挤出数据字典
        mode: 挤出模式(AVERAGE/NORMAL/EDGE/CURSOR)
        cursor_axis: 游标轴(X/Y/Z, 仅 CURSOR 模式)

    Returns:
        方向向量; None 表示需按顶点法线(vert_dir)逐点取方向
    """
    if mode == 'EDGE':
        return data['edge_dir']

    if mode == 'CURSOR':
        return data[f"cursor_dir_{cursor_axis.lower()}"]

    if mode == 'NORMAL':
        return None

    return data['avg_dir']


def update_hole_exit_coords(data: dict, obj: Object, cache: RaycastCache, direction: str = 'AVERAGE', cursor_axis: str = 'X'):
    """
    计算边界顶点在指定方向上的射线投射出口坐标

    Args:
        data: 挤出数据字典
        obj: 待投射的物体
        cache: 射线检测缓存
        direction: 投射方向模式
        cursor_axis: 游标轴(仅 CURSOR 模式)
    """
    # 网格数据已变化, 旧缓存失效
    cache.clear()

    offset = math.sqrt(data['area']) * _RAY_ORIGIN_OFFSET_SCALE
    ray_direction = get_hole_direction(data, direction, cursor_axis)

    for idx in data['sorted_boundary']:
        vdata = data['original_verts'][idx]
        # 指定了全局方向则用它, 否则退回逐顶点法线方向
        current_ray_dir = ray_direction if ray_direction else vdata.vert_dir
        # 双重偏移确保射线从网格外部开始, 避免自相交
        ray_origin = vdata.init_co - vdata.push_dir * offset + current_ray_dir * offset
        _, hitloc, *_ = raycast_from_point(ray_origin, direction=current_ray_dir, cache=cache, candidates=[obj])

        if hitloc:
            vdata.exit_co = hitloc


def build_hole_extruded_data(data: dict):
    """
    基于原始顶点和面数据, 生成挤出后的顶点, 面, 三角面索引及映射关系

    Args:
        data: 挤出数据字典(原地写入 extruded_verts/extruded_faces/extruded_tri_indices/vert_map)
    """
    vert_count = len(data['original_verts'])
    face_count = len(data['original_faces'])

    for orig_vidx, orig_vdata in data['original_verts'].items():
        extr_vidx = orig_vidx + vert_count
        data['extruded_verts'][extr_vidx] = copy(orig_vdata)
        data['vert_map'][orig_vidx] = extr_vidx
        data['vert_map'][extr_vidx] = orig_vidx

    for orig_fidx, orig_fdata in data['original_faces'].items():
        extr_fidx = orig_fidx + face_count
        data['extruded_faces'][extr_fidx] = [data['vert_map'][vidx] for vidx in orig_fdata]

    data['extruded_tri_indices'] = [data['vert_map'][idx] for idx in data['original_tri_indices']]


def build_hole_side_data(data: dict):
    """
    为每一对相邻边界顶点构建四边形侧面, 并生成侧面三角面索引

    Args:
        data: 挤出数据字典(原地写入 side_faces/side_tri_indices)
    """
    sorted_boundary = data['sorted_boundary']
    # 侧面索引起始值: 原始面数 + 挤出面数
    side_face_idx = len(data['original_faces']) + len(data['extruded_faces'])

    for idx, orig_vidx in enumerate(sorted_boundary):
        extr_vidx = data['vert_map'][orig_vidx]
        next_orig_vidx = sorted_boundary[(idx + 1) % len(sorted_boundary)]
        next_extr_vidx = data['vert_map'][next_orig_vidx]
        # 构建四边形侧面(顺序: 原, 挤出, 下一个挤出, 下一个原)
        data['side_faces'][side_face_idx] = [orig_vidx, extr_vidx, next_extr_vidx, next_orig_vidx]
        side_face_idx += 1
        # 拆分为两个三角面索引(顺序保证法线朝外)
        data['side_tri_indices'].extend([orig_vidx, extr_vidx, next_extr_vidx, orig_vidx, next_extr_vidx, next_orig_vidx])


def set_hole_extruded_coords(data: dict, depth: float, mode: str, cursor_axis: str):
    """
    按挤出量更新挤出顶点坐标

    Args:
        data: 挤出数据字典
        depth: 挤出量(须为正)
        mode: 挤出模式
        cursor_axis: 游标轴(仅 CURSOR 模式)
    """
    for vdata in data['extruded_verts'].values():
        direction = vdata.vert_dir if mode == 'NORMAL' else get_hole_direction(data, mode, cursor_axis)
        vdata.co = vdata.init_co + direction * depth


def apply_hole_push_pull(data: dict, depth: float, pushed: int, pulled: int, mode: str, cursor_axis: str):
    """
    按推拉参数调整顶点坐标, 实现侧面推挤和拉回效果

    Args:
        data: 挤出数据字典
        depth: 挤出量
        pushed: 推值
        pulled: 拉值
        mode: 挤出模式
        cursor_axis: 游标轴(仅 CURSOR 模式)
    """
    orig_verts = data['original_verts']
    extr_verts = data['extruded_verts']

    # 推拉缩放因子, 基于选区面积
    push_pull_scale = math.sqrt(data['area']) * _RAY_ORIGIN_OFFSET_SCALE

    for vidx, vdata in (orig_verts | extr_verts).items():
        co = vdata.init_co.copy()

        direction = get_hole_direction(data, mode, cursor_axis)
        extr_dir = depth * (direction if direction else vdata.vert_dir)

        # 挤出顶点: 加上挤出方向
        if vidx in extr_verts:
            co += extr_dir

        # 推: 沿 push_dir 方向移动
        if vdata.push_dir and pushed:
            co += vdata.push_dir * push_pull_scale * pushed

        # 拉: 原始顶点沿挤出方向反向移动
        if vidx in orig_verts and pulled:
            # 防止 extr_dir 为零导致归一化异常
            norm_dir = extr_dir.normalized() if extr_dir.length > 0 else extr_dir
            co -= norm_dir * push_pull_scale * pulled

        vdata.co = co


def create_hole_geo(obj: Object, bm: BMesh, data: dict):
    """
    根据挤出数据生成新几何体(顶点, 面), 并标记切割面

    Args:
        obj: 活动对象
        bm: BMesh对象
        data: 挤出数据字典
    """
    vert_map = {}
    faces = []

    face_layer = ensure_face_cut_layer(bm, CUT_LAYER_NAME)

    for vidx, vdata in (data['original_verts'] | data['extruded_verts']).items():
        vert_map[vidx] = bm.verts.new(vdata.co)

    for fidx, indices in (data['original_faces'] | data['extruded_faces'] | data['side_faces']).items():
        faces.append(bm.faces.new([vert_map[vidx] for vidx in indices]))

    bmesh.ops.recalc_face_normals(bm, faces=faces)

    bpy.ops.mesh.select_all(action='DESELECT')

    for f in faces:
        f.select_set(True)
        if face_layer:
            f[face_layer] = 1

    bmesh.update_edit_mesh(obj.data)


def cleanup_hole_mesh(obj: Object, generic: bool = True, redundant: bool = True) -> tuple[int, int]:
    """
    网格清理: 常规清理(去重/溶解退化/删除孤立元素)与冗余边溶解

    Args:
        obj: 活动对象
        generic: 是否执行常规清理
        redundant: 是否溶解切割面中角度为0的边

    Returns:
        (移除的顶点数, 溶解的冗余边数)
    """
    bm = bmesh.from_edit_mesh(obj.data)
    bm.normal_update()
    face_layer = bm.faces.layers.int.get(CUT_LAYER_NAME, None)

    init_vert_count = len(bm.verts)

    if generic:
        # remove_doubles 限定切割区域顶点: 整网格焊接(默认开启)会合并用户刻意保留的
        # 近距几何; CUT_LAYER 标记层圈定本次布尔产生的面, 只焊接其顶点(层缺失回退原行为)
        if face_layer is not None:
            cut_verts = {v for f in bm.faces if f[face_layer] for v in f.verts}
        else:
            cut_verts = set(bm.verts)
        if cut_verts:
            bmesh.ops.remove_doubles(bm, verts=list(cut_verts), dist=0.0001)
        bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=0.0001)
        # 布尔差集结果的绕向由求解器决定不保证朝外(孔底面可能朝下), 按实体体积统一重算
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

        # 删除孤立顶点/边与完全非流形的面
        loose_verts = [v for v in bm.verts if not v.link_edges]
        if loose_verts:
            bmesh.ops.delete(bm, geom=loose_verts, context="VERTS")

        loose_edges = [e for e in bm.edges if not e.link_faces]
        if loose_edges:
            bmesh.ops.delete(bm, geom=loose_edges, context="EDGES")

        loose_faces = [f for f in bm.faces if all([not e.is_manifold for e in f.edges])]
        if loose_faces:
            bmesh.ops.delete(bm, geom=loose_faces, context="FACES")

    # 冗余边处理: 溶解切割面中角度为0的边
    redundant_edges = []
    cut_faces = set()

    if redundant and face_layer:
        cut_faces = set([f for f in bm.faces if f[face_layer] == 1])
        if cut_faces:
            edges = set([e for f in cut_faces for e in f.edges])
            for e in edges:
                if round(get_face_angle(e, signed=False), 2) == 0:
                    redundant_edges.append(e)
            if redundant_edges:
                bmesh.ops.dissolve_edges(bm, edges=redundant_edges, use_verts=False)

    # 移除切割面标记层
    if face_layer:
        bm.faces.layers.int.remove(face_layer)

    # 同步到编辑网格
    bmesh.update_edit_mesh(obj.data)

    removed_verts = init_vert_count - len(bm.verts)
    removed_edges = len(redundant_edges) if redundant and face_layer and cut_faces else 0

    return removed_verts, removed_edges


def reset_hole_mesh(obj: Object, init_bm: BMesh, return_bmesh: bool = False) -> BMesh | None:
    """
    用初始快照重置网格到操作开始时的状态

    Args:
        obj: 活动对象
        init_bm: 初始的 BMesh 快照
        return_bmesh: 是否返回重置后的编辑态 BMesh

    Returns:
        BMesh | None: return_bmesh 为 True 时返回新的 BMesh
    """
    # 切换到对象模式以更新网格数据
    bpy.ops.object.mode_set(mode='OBJECT')
    init_bm.to_mesh(obj.data)
    bpy.ops.object.mode_set(mode='EDIT')

    if return_bmesh:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.normal_update()
        # 不在此重建标记层: 层由 create_hole_geo 在生成阶段 ensure, 并在 cleanup_hole_mesh 收尾移除;
        # 重置路径预建会让"确认后退回挤出阶段再取消"在网格上留下一个全 0 的自定义层(取消路径无清理点)
        return bm
