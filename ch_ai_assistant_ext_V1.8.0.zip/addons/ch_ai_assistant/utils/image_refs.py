"""
参考图引用序列化模块(纯函数, 不依赖 bpy)

AI_Image_Refs.json 文本块的读写: 三模式共用一份参考图列表, 每个条目带"名字 + 描述 +
三个模式的发送标志". 单独成模块有两个原因:
- 纯 stdlib(json), 可在无 Blender 环境下单测(tests/test_ch_ai_image_refs.py);
- 与 script_io(文本数据块/脚本落盘)分层: 参考图存档不是脚本 IO, 早先挂在 script_io 里只是历史.
"""

import json

# 参考图引用的存档文本块名(随 .blend 保存; 与其它 AI_* 文本块同域, 但读写都在本模块)
AI_IMAGE_REFS_NAME = "AI_Image_Refs.json"


def serialize_image_refs(refs: list) -> str:
    """参考图引用序列化为 JSON 文本(写入 AI_Image_Refs.json 文本块随 blend 保存)

    refs 为 (图像数据块名, 描述, 激活标志字典) 三元组列表: 名字在数据块缺失时为空串
    (条目保留以保住描述与标志, 恢复后由列表的缺失占位显示); 激活标志字典的键即
    items.REF_ACTIVE_KEYS 的三个属性名(按生成模式分开记忆).
    图像生成器三个模式共用一份参考图列表, 故只存一节.
    """
    payload = []
    for name, description, active in refs:
        item = {"name": name, "description": description}
        item.update(active)
        payload.append(item)
    return json.dumps({"refs": payload}, ensure_ascii=False)


def parse_image_refs(raw: str) -> list | None:
    """解析持久化的参考图引用, 返回 (名字或 None, 描述, 激活标志字典) 元组列表; 无效内容返回 None

    只认现行单节 refs 格式: 缺 refs 键或类型不对均视为无效存档(返回 None, 与无存档
    同待——恢复方载入即清空重建); 缺失的激活标志不补键, 由恢复方按属性默认值
    处理(三模式全开). 逐条校验类型, 非法条目丢弃, 同名只保留首个.
    """

    def _load(items) -> list:
        if not isinstance(items, list):
            return []
        refs = []
        for item in items:
            if not isinstance(item, dict):
                continue
            name = item.get("name")
            description = item.get("description")
            if not isinstance(description, str):
                continue
            # 布尔字段原样收下(键的合法集由写入方 handlers 按 REF_ACTIVE_ATTRS 过滤):
            # 本模块不导入 items —— items 会经 utils 包初始化反向回来, 形成循环导入
            active = {key: value for key, value in item.items() if isinstance(value, bool)}
            refs.append((name if isinstance(name, str) and name else None, description, active))
        return refs

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError, AttributeError):
        return None
    if not isinstance(data, dict):
        return None
    refs = data.get("refs")
    if not isinstance(refs, list):
        return None
    merged = []
    seen = set()
    for name, description, active in _load(refs):
        if name is not None:
            if name in seen:
                continue
            seen.add(name)
        merged.append((name, description, active))
    return merged
