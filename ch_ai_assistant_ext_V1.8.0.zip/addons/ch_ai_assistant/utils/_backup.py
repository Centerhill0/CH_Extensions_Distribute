"""
"_bak" 备份环清理工具模块

图像数据块与文本块共用同一套备份环策略: 按偏好上限保留最新若干份, 其余按名称序号
从旧到新移除. 两种数据块的差异只在遍历集合,删除 API 与提示文案, 故把"选哪些该删"
这一算法收口为单一实现; 删除与上报由调用方按自身文案逐个执行
(utils 内不做 report, 且报告与删除的先后顺序属调用方的可观测行为).

主要功能:
- expired_backups: 选出超出上限的旧备份数据块, 返回 (数据块列表, 错误信息)
"""


def expired_backups(collection, base: str, keep_name: str, limit: int) -> tuple:
    """选出超出保留上限的旧备份数据块, 返回 (数据块列表, 错误信息)

    collection 为待遍历的数据块集合(bpy.data.images / bpy.data.texts);
    base 为原名干(不含 "_bak" 后缀), keep_name 为刚生成的最新备份名(必保留);
    limit 为保留份数(调用方自偏好解析, 不足 1 份时按 0 处理).

    名字为 <base>_bak 或 <base>_bak.<纯数字序号> 的条目视作备份, 按序号从旧到新排序后
    取超限的前若干项; 其余形态(如 <base>_bak.py 这类旧版命名或用户手写同名脚本)一律
    不视作备份, 无误删风险(旧版命名兼容已随 "5.3 全新安装"口径移除).
    本函数只做筛选不执行删除, 故错误信息恒为 None; 保留该返回位是为守住 utils
    "失败经 (结果, 错误信息) 元组表达" 的口径(见 utils 包组织规范).
    """
    prefix = f"{base}_bak"

    def _backup_seq(name: str) -> int | None:
        """<base>_bak 本体记 0(最旧候选), <base>_bak.<纯数字> 记其序号; 其余不是备份"""
        if name == prefix:
            return 0
        tail = name[len(prefix) :]
        return int(tail[1:]) if tail.startswith(".") and tail[1:].isdigit() else None

    backups = []
    for block in collection:
        if block.name == keep_name:
            continue
        seq = _backup_seq(block.name)
        if seq is not None:
            backups.append((seq, block))

    excess = len(backups) - max(0, limit)
    if excess <= 0:
        return [], None

    return [block for _seq, block in sorted(backups, key=lambda pair: pair[0])[:excess]], None
