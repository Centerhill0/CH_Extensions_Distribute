from ....common.i18n.dictionary import preprocess_dictionary

# 翻译条目按对应 Operator / 面板分块注释归类:
# Operator 标签用 ("Operator", "English text"), 通用文本与 report 消息用 ("*", "English text")
dictionary = {
    "zh_HANS": {
        # 侧栏选项卡与面板共用文案(ui/panels/scene_panels.py)
        ("*", "Scene Helper"): "场景助手",
        # 材质参数子面板(ui/panels/_settings.py 的材质设置区)
        # 属性名(Base Color/Color/Metallic/Roughness/IOR/Emission Color/Emission Strength/
        # Strength/Projection/Blend/Texture Coordinate 等)均为系统词条, 已查
        # i18n_check_terms 全部命中, 不入典(i18n 规范: 系统词条不翻译)
        ("*", "Material Settings"): "材质设置",
        # PBR 设置子面板(ui/panels/_settings.py 的 draw_material_pbr)
        # 内容为纹理坐标输出与投影统一控制; 2026-10-19 从材质设置子面板拆出独立成面板(作者定名)
        ("*", "PBR Settings"): "PBR设置",
        (
            "*",
            "Texture coordinate output feeding the Mapping node (edits node links, not undoable; affects all users of this material)",
        ): "接入 Mapping 节点的纹理坐标输出(直接改节点接线, 不进撤销栈; 该材质的全部使用者物体都会受影响, 建议先复制材质再改)",
        ("*", "Projection for all PBR image textures (applied to every texture; not undoable)"): "全部 PBR 图像纹理的投影方式(统一应用到每张纹理; 不进撤销栈)",
        ("*", "Blend for box projection, applied to every PBR image texture (not undoable)"): "Box 投影的融合参数(统一应用到每张 PBR 纹理; 不进撤销栈)",
        # 面板动作行/设置子面板文案(未命中系统词条)
        ("*", "DOF"): "景深",
        ("*", "Spot Size"): "聚光尺寸",
        # 原生算子按钮文案(静态审计要求 ctx=Operator 覆盖; 运行时系统 mo 优先, 插件词典兜底)
        ("Operator", "Light Linking"): "灯光链接",
        ("Operator", "Shadow Linking"): "阴影链接",
        # 面板按钮用显式 text= 绘制, 走默认语境而非 Operator 语境
        ("*", "Light Linking"): "灯光链接",
        ("*", "Shadow Linking"): "阴影链接",
        # 列表按钮列开关(ui/panels/scene_options.py, 属性声明在 props.py)
        # 均为图标按钮(text=""), 只有 name(悬停标签)与 description(tooltip)文案;
        # name 用系统已有词条 Sync Selection(不入典, 系统 mo 优先)
        ("*", "Show 0 Users"): "显示0用户",
        ("*", "Also list materials that have no users (orphans and fake-user only)"): "同时列出没有任何使用者的材质(孤儿与仅假用户)",
        ("*", "Also list worlds that have no users (orphans and fake-user only)"): "同时列出没有任何使用者的世界环境(孤儿与仅假用户)",
        ("*", "Show Linked Data"): "显示库链接",
        (
            "*",
            "Also list data-blocks linked from libraries (materials, worlds and images); turn off to list only data-blocks from this file",
        ): "同时列出经库链接引入的数据块(材质/世界环境/图像)；关闭后只列本文件的数据块",
        # 材质动作算子(operators/utils/material_ops.py)
        # 按钮文案(作者定名): "Apply Material" -> 赋予材质; "Duplicate Material" -> 复制材质.
        # 原文必须避开系统词条: "Assign Material" 已被系统 mo 占用(译为"指定材质", 系统优先,
        # 插件条目不会生效), 故改用 Apply Material(已过 i18n_check_terms --query 未命中).
        ("Operator", "Apply Material"): "赋予材质",
        ("*", "Apply Material"): "赋予材质",
        ("Operator", "Activate Material"): "激活材质",
        ("*", "Activate Material"): "激活材质",
        ("Operator", "Merge Materials"): "合并材质",
        ("*", "Merge Materials"): "合并材质",
        # "Select Users" 仍被图像行首算子(ImageSelectUsers)使用; 材质行首按钮已改激活语义
        ("Operator", "Select Users"): "选中使用者",
        ("Operator", "Duplicate Material"): "复制材质",
        ("*", "Duplicate Material"): "复制材质",
        ("Operator", "Unlink Material"): "解除材质关联",
        ("*", "Unlink Material"): "解除材质关联",
        ("*", "No material selected"): "没有选中材质",
        ("*", "No activated materials to merge"): "没有可合并的激活材质",
        ("*", "No objects can hold the material"): "选中物体都不能持有材质槽",
        ("*", "Object has no material slots"): "物体没有材质槽",
        ("*", "Slot assign requires exactly one selected object"): "替换指定材质槽需要恰好选中一个物体",
        ("*", "Material not found"): "未找到材质",
        ("*", "Material not linked to any object"): "没有物体关联该材质",
        ("*", "Material unlinked from {} slots"): "已解除 {} 个材质槽的关联",
        ("*", "Material assigned: {} objects"): "已把材质赋给 {} 个物体",
        ("*", "Material appended: {} objects"): "已把材质追加到 {} 个物体",
        ("*", "Material replaced at slot: {}"): "已替换第 {} 个材质槽的材质",
        ("*", "Slot index out of range, replaced the last slot: {}"): "槽位编号溢出, 已替换末尾材质槽: {}",
        ("*", "Material duplicated and assigned: {}"): "已复制材质并赋给选中物体: {}",
        ("*", "No objects selected, the copy has no users"): "没有选中物体, 副本暂无使用者",
        ("*", "No instanced objects to make independent"): "没有需要独立化的实例物体",
        ("*", "Instances made independent: {} objects"): "已独立化 {} 个实例物体",
        ("*", "Failed to make instance independent: {}"): "实例独立化失败: {}",
        # 修饰键说明一律另起一行(以 \n 开头), 与代码规范「修饰键 tooltip 分行」一致
        (
            "*",
            "Assign the active material of the Materials panel to all selected objects\n+Ctrl: Append the material to the object material slots instead of replacing the active one\n+Alt: Replace the material slot of the given index (single selected object only, out of range replaces the last slot)",
        ): "把材质面板的活动材质赋给全部选中物体\n+Ctrl: 把材质追加到物体材质槽列表, 而不是替换活动槽\n+Alt: 替换指定编号的材质槽(仅单选一个物体时生效, 编号溢出则替换末尾槽)",
        ("*", "Slot Index"): "槽位编号",
        ("*", "Material slot index to replace (0-based, out of range replaces the last slot)"): "要替换的材质槽编号(从 0 开始, 溢出则替换末尾槽)",
        ("*", "Append"): "追加",
        ("*", "Append the material to the object material slots instead of replacing the active one"): "把材质追加到物体材质槽列表, 而不是替换活动槽",
        (
            "*",
            "Duplicate the active material of the Materials panel and assign it to all selected objects\n+Alt: Make the selected instanced objects independent (selected objects sharing a mesh become one unified instance) and then duplicate the material; without instances it only shows a notice",
        ): "复制材质面板的活动材质并赋给全部选中物体\n+Alt: 先把选中的实例物体独立化(共用同一数据块的选中物体独立成一个统一实例), 再复制材质; 没有实例时只给出提示",
        ("*", "Unlink the active material from all objects\n+Shift: Delete the material data-block directly"): "解除活动材质与全部物体的关联\n+Shift: 直接删除该材质数据块",
        ("*", "Delete"): "删除",
        ("*", "Delete the material data-block instead of only unlinking it"): "删除材质数据块, 而非仅解除关联",
        # 列表动作算子(operators/utils/list_ops.py)
        ("*", "Move Down"): "下移",
        ("Operator", "Move List Item"): "移动列表项",
        ("*", "Move List Item"): "移动列表项",
        ("*", "Move the active list item up or down (order saved in the blend file)"): "上移或下移列表活跃项(顺序随 blend 文件持久)",
        # "Sort by Name" 系统已有(ctx=空 与 Operator 均在 blender.mo), 不入典
        ("*", "Sort the list by name (order saved in the blend file)"): "按名称排序列表(顺序随 blend 文件持久)",
        ("Operator", "Delete Object"): "删除物体",
        ("*", "Delete Object"): "删除物体",
        ("*", "Delete the active object of the list"): "删除列表活跃项对应的物体",
        ("*", "List item is no longer in the scene"): "列表项已不在场景中",
        # 相机饼菜单与相机算子(ui/pies/camera.py, operators/object/camera.py; 2026-10-16 自 ch_utils_tools 迁入)
        ("Operator", "Toggle Camera"): "切换相机",
        ("Operator", "Set As Scene Camera"): "设为场景相机",
        ("Operator", "Create Align Camera"): "创建对齐相机",
        ("*", "Toggle Next"): "向下切换",
        ("*", "CH Camera Pie"): "CH 相机饼菜单",
        ("*", "Toggle the camera object"): "切换相机物体",
        ("*", "Set the active object as the scene camera and align the view to it\n+Ctrl: Set only, keep the current view"): "将活动物体设为场景相机并对齐视图\n+Ctrl: 仅设置, 不切换视图",
        # 相机独立分辨率属性组(props.py 的 CameraResolutionSettings; "Resolution X/Y" 为系统词条不入典)
        ("*", "Independent Resolution"): "独立分辨率",
        ("*", "Override the scene output resolution with this camera's own resolution while it is the scene camera"): "该相机为场景相机时用它自己的分辨率覆写场景输出分辨率",
        ("*", "Independent output width in pixels"): "独立输出的像素宽度",
        ("*", "Independent output height in pixels"): "独立输出的像素高度",
        ("Operator", "Set Active Object as Scene Camera"): "设置活动物体为场景相机",
        ("*", "Set Active Object as Scene Camera"): "设置活动物体为场景相机",
        ("*", "Create a camera for aligning the view"): "创建用于对齐视图的相机",
        ("*", "Camera Pie Menu"): "相机饼菜单",
        # 饼菜单按钮用显式 text= 绘制, 走默认语境(见上"Light Linking"双语境先例);
        # "Frame Camera Bounds" 已去掉显式 text 改用原生 label, 不需要词条
        ("*", "Create Camera Aligned to View"): "创建相机对齐视角",
        ("*", "All Cameras"): "所有相机",
        ("*", "Align Active Camera to View"): "对齐活动相机到当前视角",
        ("*", "Align Active Camera to Selected"): "对齐活动相机到选中项",
        ("Operator", "All Cameras"): "所有相机",
        ("Operator", "Previous"): "上一个",
        ("Operator", "Next"): "下一个",
        ("Operator", "Track To"): "标准跟随",
        ("Operator", "Damped Track"): "阻尼跟踪",
        ("Operator", "Create Camera Aligned to View"): "创建相机对齐视角",
        ("*", "No camera found in view layer"): "视图层中未找到相机",
        # 灯光饼菜单(ui/pies/light.py; 同上迁入)
        ("*", "CH Light Pie"): "CH 灯光饼菜单",
        ("*", "{} Settings"): "{}设置",
        ("*", "Spot"): "聚光",
        ("*", "Area"): "区域",
        ("*", "Light Pie Menu"): "灯光饼菜单",
        ("*", "Light Settings"): "灯光设置",
        ("Operator", "Include"): "包含",
        ("Operator", "Exclude"): "排除",
        # 灯光面板扩展(灯光集合管理列表 + 隔离屏蔽世界; scene_options/props/row_ops/datablock_ops)
        ("*", "Mute World"): "屏蔽世界",
        (
            "*",
            "While isolating a light or a light collection, also mute every link into the World Output node to isolate it from the world lighting (links are restored on un-isolating)",
        ): "隔离灯光或灯光集合时同时屏蔽世界输出节点的全部接入端连线(取消隔离后恢复)",
        ("*", "Light Collections"): "灯光集合",
        # 灯光整理(datablock_ops 的相邻功能, 入口在灯光集合选项菜单)
        ("Operator", "Organize Lights"): "灯光整理",
        ("*", "Move every light outside the light collections into the newest light collection (one is created first when there is no light collection)"): "把灯光集合之外的灯光物体移入最新创建的灯光集合(没有灯光集合时先新建一个)",
        ("*", "No lights outside the light collections"): "灯光集合之外没有灯光物体",
        ("*", "Moved {} lights into {}"): "已将 {} 盏灯光移入 {}",
        # 相机整理(入口在相机列表选项菜单; 与灯光整理同款"真移动进集合"语义, 中文名同样名词在前)
        ("Operator", "Organize Cameras"): "相机整理",
        ("*", "Move every camera into the Cameras collection (created on first use; cameras are unlinked from their other collections)"): "把场景内所有相机移入 Cameras 集合(首次使用时自动新建; 相机将从原先所属的集合解除挂载)",
        ("*", "No cameras to organize"): "没有可整理的相机",
        ("*", "All cameras are already in the Cameras collection"): "全部相机已在 Cameras 集合中",
        ("*", "Moved {} cameras into {}"): "已将 {} 台相机移入 {}",
        # 灯光集合列表选项菜单(ui/panels/scene_options.py); 菜单标题 ctx=* 与 Operator 双语境
        ("Operator", "Collection Options"): "集合选项",
        ("*", "Collection Options"): "集合选项",
        # 灯光集合激活标记(ch_lights_active): 行首图标切换, 激活的集合过滤灯光列表
        ("Operator", "Activate Collection"): "激活集合",
        ("*", "Toggle this collection as the lights list filter (none checked shows all lights)"): "把该集合作为灯光列表的过滤开关(全不勾选时显示全部灯光)",
        ("*", "Lights Active"): "灯光激活",
        # "New Collection" 系统已有(ctx=Operator), 不入典; "Delete Hierarchy" 亦为系统词条
        ("*", "Create a new light collection (auto-numbered CLS_NN_) inside the Lights collection"): "新建灯光集合(自动编号 CLS_NN_, 置于 Lights 集合下)",
        # 材质激活/合并(材质行首按钮与 IMPORT 按钮, 作者 2026-10-24 定名)
        (
            "*",
            "Activate this material and select its users in the scene (deactivates the others)\n+Shift: Toggle this material without touching the others (users are selected/deselected accordingly)",
        ): "激活该材质并在场景中选中其使用者(其它材质取消激活)\n+Shift: 只切换该材质而不影响其它(使用者随激活状态选中/减选)",
        (
            "*",
            "Replace all activated materials with this row's material: every user reference is re-linked and local source materials are removed (linked sources are kept, only their users are re-linked)",
        ): "把全部激活材质替换为本行材质(所有使用者引用改链, 本地源材质删除; 库链接源保留, 只改链其使用者; 用于合并相似材质)",
        ("*", "Linked source kept, its users were re-linked to the target"): "库链接源材质保留, 其使用者已改链到目标材质",
        ("*", "Material Active"): "材质激活",
        ("*", "Delete this collection data-block\n+Shift: Also delete the objects and child collections inside"): "删除该集合数据块\n+Shift: 连同其内部物体与子集合一并删除",
        ("*", "Also delete the objects and child collections inside the collection"): "同时删除集合内的物体与子集合",
        # "Delete Hierarchy" 系统词条仅 Operator 语境, 属性名走 * 语境需插件兜底(仿 Light Linking 双语境)
        ("*", "Delete Hierarchy"): "删除层级",
        ("*", "Collection hierarchy delete also removes the objects and child collections inside ({} users)"): "删除层级将同时删除集合内的物体与子集合(将清空 {} 个使用者)",
        # 偏好(左列相机设置 + 右列快捷键, 两列布局)
        ("*", "Camera Settings"): "相机设置",
        ("*", "No camera settings yet"): "暂无相机设置项",
        ("*", "Hotkeys"): "快捷键",
        # 快捷键分组显示名(keymaps.py)
        ("*", "Camera Pie"): "相机饼菜单",
        ("*", "Light Pie"): "灯光饼菜单",
        # 与 ch_utils_tools 共用(对方仍引用): 目标侧各留一份, 两插件词典同名键互不冲突
        ("Operator", "Compositor"): "合成器编辑器",
        ("Operator", "Point"): "点",
        # ============================================================
        # 场景助手五面板(ui/panels/scene_panels.py + ui/lists/scene_lists.py +
        # operators/utils/{row,image,datablock,material,list}_ops.py + props.SceneHelperState)
        # ============================================================
        # 面板标题与选项菜单
        ("*", "Cameras"): "相机",
        ("*", "Materials"): "材质",
        ("*", "Lights"): "灯光",
        ("*", "Images"): "图像",
        ("*", "Worlds"): "世界环境",
        ("*", "Camera Options"): "相机选项",
        ("*", "Light Options"): "灯光选项",
        ("*", "Material Options"): "材质选项",
        ("*", "Image Options"): "图像选项",
        ("*", "World Options"): "世界环境选项",
        # 算子标签(Operator 上下文)
        ("Operator", "Select Object"): "选择物体",
        ("Operator", "Set View"): "切换视角",
        ("Operator", "Disable in Viewport"): "在视图中禁用",
        ("Operator", "Disable in Render"): "在渲染中禁用",
        ("Operator", "Delete"): "删除",
        ("Operator", "Batch Pass Index"): "批量通道索引",
        ("Operator", "Assign World"): "指派世界",
        ("*", "Assign World"): "指派世界",
        ("Operator", "Unlink World"): "解除世界关联",
        ("*", "Unlink World"): "解除世界关联",
        ("Operator", "New World"): "新建世界",
        ("Operator", "Pack Image"): "打包图像",
        ("Operator", "Unpack Image"): "解包图像",
        ("Operator", "Reload All Images"): "重载全部图像",
        ("Operator", "Save All Modified"): "保存全部修改",
        ("Operator", "Rename to File Name"): "按文件名重命名",
        ("Operator", "Merge Duplicate Images"): "合并重复图像",
        ("Operator", "Replace Image"): "替换图像",
        ("Operator", "Unlink Image"): "解除图像引用",
        ("Operator", "New Material"): "新建材质",
        ("*", "New Material"): "新建材质",
        # 算子 tooltip(修饰键说明分行, 与源码逐字符一致)
        ("*", "Select this object and highlight its list item\n+Shift: Toggle selection"): "选中该物体并高亮该列表项\n+Shift: 切换选中/减选",
        ("*", "Select this camera and look through it"): "选中该相机并切换到它的视角",
        (
            "*",
            "Toggle viewport visibility for this object\n+Ctrl: Show only this object among the objects of the same type (isolate), click again to restore",
        ): "切换该物体在视口中的可见性\n+Ctrl: 只显示该物体（隐藏其余同类，再点恢复）",
        (
            "*",
            "Toggle render exclusion for this object\n+Ctrl: Render only this object among the objects of the same type (isolate), click again to restore",
        ): "切换该物体是否被渲染排除\n+Ctrl: 只渲染该物体（其余同类排除渲染，再点恢复）",
        (
            "*",
            "Toggle viewport visibility for this collection\n+Ctrl: Show only this collection among the light collections (isolate), click again to restore",
        ): "切换该集合在视口中的可见性\n+Ctrl: 只显示该集合（隐藏其余灯光集合，再点恢复）",
        (
            "*",
            "Toggle render exclusion for this collection\n+Ctrl: Render only this collection among the light collections (isolate), click again to restore",
        ): "切换该集合是否被渲染排除\n+Ctrl: 只渲染该集合（其余灯光集合排除渲染，再点恢复）",
        ("*", "Set the pass index of all materials used in the scene in one go"): "一次性设置场景中全部材质的通道索引",
        ("*", "Use this world as the scene world"): "把该世界环境设为场景世界",
        ("*", "Unlink this world from the scene (keep the data-block)\n+Shift: Delete the world data-block directly"): "解除该世界与场景的关联(保留数据块)\n+Shift: 直接删除世界数据块",
        ("*", "World is not linked to the scene"): "该世界未关联到场景",
        ("*", "Delete the world data-block instead of only unlinking it"): "删除世界数据块, 而非仅解除关联",
        ("*", "Create a new world and use it as the scene world"): "新建一个世界环境并设为场景世界",
        ("*", "Pack this image into the blend file"): "把该图像打包进 blend 文件",
        ("*", "Open image file(s); newly imported entries are highlighted in the images list"): "打开图像文件, 载入后图像列表高亮新增条目",
        ("*", "Select all objects whose materials use this image"): "选中材质里引用该图像的全部物体",
        ("*", "Unpack this image to disk"): "把该图像解包到磁盘",
        ("*", "Reload every image that references an external file"): "重载全部引用外部文件的图像",
        ("*", "Save every modified image that has a file path"): "保存全部已修改且有文件路径的图像",
        ("*", "Rename the image to the name of the file it references"): "把图像名改成它所引用的文件名",
        ("*", "Point image texture nodes at the original image when they use a duplicate such as name.001"): "把使用 name.001 这类重复图的图像纹理节点指回原图",
        ("*", "Replace every reference to the old image with another image"): "把对旧图像的全部引用换成另一张图像",
        ("*", "Clear every material node reference to this image (the data-block is kept)\n+Shift: Delete the image data-block directly"): "把材质图像节点里对该图像的引用置空（保留数据块）\n+Shift: 直接删除图像数据块",
        ("*", "Image references cleared: {}"): "已清空 {} 处图像引用",
        ("*", "No material nodes use this image"): "没有材质节点使用该图像",
        ("*", "Delete the image data-block instead of only clearing references"): "删除图像数据块而不只是清空引用",
        # 算子属性名与说明
        ("*", "Kind"): "种类",
        ("*", "Isolate among the same-type objects instead of toggling (set by +Ctrl)"): "在同类物体之间隔离而不是切换（由 +Ctrl 设置）",
        ("*", "Isolate among the light collections instead of toggling (set by +Ctrl)"): "在灯光集合之间隔离而不是切换（由 +Ctrl 设置）",
        ("*", "Value assigned to the first material"): "赋给第一个材质的起始值",
        ("*", "Value assigned to every material"): "赋给每个材质的固定值",
        ("*", "Skip Assigned"): "跳过已设置",
        ("*", "Leave materials with a non-zero pass index untouched"): "不改动通道索引非零的材质",
        # 批量通道索引对话框(operators/utils/material_ops.py 的 PassIndexBatch)
        # "Mode"/"Fixed"/"Start"/"Value" 为系统词条(已查 i18n_check_terms 命中), 不入典
        ("*", "Sequential"): "顺序",
        ("Operator", "Sequential"): "顺序",
        ("*", "Assign increasing values"): "分配递增的值",
        ("*", "Assign the same value to every material"): "给每个材质分配相同的值",
        ("*", "Keep Extension"): "保留扩展名",
        ("*", "Keep the file extension in the image name"): "在图像名中保留文件扩展名",
        ("*", "Partition"): "分隔符",
        ("*", "Character that separates the name from the numeric suffix"): "分隔名称与末尾数字后缀的字符",
        ("*", "Old Image"): "旧图像",
        ("*", "All Materials"): "全部材质",
        ("*", "Scan every material instead of the active material only"): "扫描全部材质, 而不是只扫描活动材质",
        ("*", "Create a new material and assign it to the active object"): "新建材质并赋给活动物体",
        # 选区同步 / 0 用户对象开关(选项菜单前三项)
        ("*", "Also list images that have no users (orphans and fake-user only)"): "同时列出没有任何使用者的图像(孤儿与仅假用户)",
        ("*", "Previous"): "上一个",
        ("*", "Next"): "下一个",
        ("*", "Highlight the list item of the active object whenever the active object changes"): "活动物体变化时, 自动把列表高亮切到对应条目",
        ("*", "No 3D view to align the camera to"): "没有可用于对齐相机的 3D 视图",
        ("Operator", "Fake User"): "伪用户",
        ("*", "Fake User"): "伪用户",
        ("*", "Keep this data-block saved even when it has no users"): "即使没有使用者也保留该数据块",
        # 面板状态属性(名称与说明)
        ("*", "Show the lens column"): "显示焦距列",
        ("*", "Show the camera type column"): "显示相机类型列",
        ("*", "View Camera Name"): "视图相机名称",
        (
            "*",
            "Show or hide the names of all cameras in the 3D view (writes each camera's show_name flag, saved with the .blend; the toggle state itself is re-read on file load)",
        ): "显示或隐藏 3D 视图中所有相机的名称(写入各相机的 show_name 属性并随 .blend 保存; 开关本身不保存, 载入文件后按相机实况回读)",
        ("*", "Show the light color column"): "显示灯光颜色列",
        ("*", "Show the shadow toggle column"): "显示阴影开关列",
        ("*", "Show the pass index column"): "显示通道索引列",
        ("*", "Node Count"): "节点数",
        ("*", "Show the material node count column"): "显示材质节点数列",
        ("*", "Show the world color swatch"): "显示世界颜色色板",
        # 详情子面板标题与空态提示("Camera Settings"/"Light Settings" 已在前文偏好与饼菜单段登记)
        ("*", "No active camera"): "没有活动相机",
        ("*", "No active light"): "没有活动灯光",
        ("*", "No active material"): "没有活动材质",
        ("*", "No surface shader"): "没有可编辑的表面着色器",
        ("*", "No objects use this image"): "没有物体使用该图像",
        # 报告消息
        ("*", "Camera not found"): "未找到相机",
        ("*", "No modified images to save"): "没有需要保存的修改图像",
        ("*", "Image not found"): "未找到图像",
        ("*", "No image selected"): "没有选中图像",
        ("*", "empty separator"): "分隔符不能为空",
        ("*", "Material created without users"): "已新建材质, 但当前没有可持有材质的活动物体(材质暂无使用者)",
        ("*", "Linked material cannot be deleted"): "库链接材质不可删除",
        ("*", "Material is used by {} users, deleting it clears them"): "材质有 {} 个使用者, 删除会一并清空材质槽",
        ("*", "Linked data-block cannot be deleted"): "库链接数据块不可删除",
        ("*", "Data-block is used by {} users, deleting it clears them"): "数据块有 {} 个使用者, 删除会一并清空引用",
        ("*", "Turn off alphabetical sorting to move items manually"): "请先关闭字母排序, 再手动上移/下移",
        ("*", "Pass index set: {} materials"): "已设置 {} 个材质的通道索引",
        ("*", "Images reloaded: {}"): "已重载 {} 张图像",
        ("*", "Image references merged: {}"): "已合并 {} 处图像引用",
        ("*", "Image references replaced: {}"): "已替换 {} 处图像引用",
        ("*", "Rename failed: {}"): "重命名失败: {}",
        ("*", "Pack failed: {}"): "打包失败: {}",
        ("*", "Unpack failed: {}"): "解包失败: {}",
        ("*", "Reload failed: {}"): "重载失败: {}",
        ("Operator", "Relocate Image"): "重定位图像",
        ("*", "Open a file browser to relocate this image and load it from the new location"): "打开文件浏览器重定位该图像，并从新位置载入",
        ("*", "New path of the image file"): "图像文件的新路径",
        ("Operator", "Select Lights"): "选择灯光",
        ("*", "Select the lights whose IES nodes reference this file"): "选中 IES 节点引用了此文件的灯光",
        ("*", "No lights use this IES"): "没有灯光使用此 IES",
        ("*", "Unpacking writes to the original path and may overwrite it"): "解包会写回原始路径, 可能覆盖磁盘上的同名文件",
        ("*", "Reloading discards unsaved image edits"): "重载会丢弃图像中未保存的修改",
        ("*", "(removed)"): "(已移除)",
    }
}

dictionary = preprocess_dictionary(dictionary)
