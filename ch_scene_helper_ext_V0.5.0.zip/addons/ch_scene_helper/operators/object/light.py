"""
灯光辅助操作器模块

提供以下功能:
- LightOrganize: 灯光整理, 把灯光集合之外的灯光物体移入最新创建的灯光集合
"""

from bpy.types import Context, Operator

from .....common.i18n.i18n import report
from ...handlers import refresh_lists
from ...scene_state import highlight_item
from ...utils import collect_stray_lights, create_light_collection, move_objects_to_collection, newest_light_collection


class LightOrganize(Operator):
    """灯光整理: 把灯光集合之外的灯光物体(不含被排除集合内的)移入最新创建的灯光集合"""

    bl_idname = "ch.light_organize"
    bl_label = "Organize Lights"
    bl_description = "Move every light outside the light collections into the newest light collection (one is created first when there is no light collection)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: Context):
        scene = context.scene
        # 先判"有活可干"能避免为了空整理凭空建集合(无集合时新建的 CLS_01_ 本身不含灯光, 顺序无影响)
        lights = collect_stray_lights(scene, context.view_layer)
        if not lights:
            self.report({'INFO'}, report("No lights outside the light collections"))
            return {'CANCELLED'}
        target = newest_light_collection(scene)
        if target is None:
            target = create_light_collection(scene)
        count = move_objects_to_collection(lights, target)
        refresh_lists()
        highlight_item(context, "light_collections", target.name)
        self.report({'INFO'}, report("Moved {} lights into {}").format(count, target.name))
        return {'FINISHED'}
