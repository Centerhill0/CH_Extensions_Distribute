"""
实时同步处理器模块

提供以下功能:
- depsgraph_update_post / load_post 处理器: 场景资源列表实时刷新与"选区同步"高亮;
  载入文件后回读相机 show_name 实况对齐"视图相机名称"开关
- refresh_lists: 公开的"立即重建快照"入口(供不触发 depsgraph 的算子主动调用)
- on_sync_toggle / on_list_scope_update: 面板状态开关的 update 回调
- on_images_index_update: 图像列表行点击时把图像编辑器切换到该图
- 周期计时器: 兜底刷新
- register/unregister: 由 class_loader 在类注册后自动调用, 无需手动挂接

注:
- 列表活跃索引没有 update 回调 —— 点击名称只切换高亮, 选中物体由列表首按钮算子负责;
- "选区同步"只在**活动物体(或其活动材质)变化时**回写高亮, 用户手动点其它行不会被
  定时器顶回;
- 世界列表高亮无条件跟随场景世界(_sync_scene_refs: 面板无"选区同步"开关, 与灯光集合
  跟随大纲活动集合同款);
- 新建灯光不分路径(面板"+"/Shift+A/复制等)高亮该行, 选区同步开与关都跟
  (_pending_new_light: "新建即活动物体", 选中既有物体仍尊重开关);
- 面板导入图像(ImageOpen 壳)经 expect_image_import 登记, 快照重建按差集高亮新增
  非运行期图像(文件对话框异步载入, 算子拿不到完成时机).
- 六种列表的集合/索引/开关统一取自 scene_state.LIST_SPECS;
- depsgraph 更新按 0.1s 合并窗口延迟刷新(见 _on_depsgraph_update), 避免拖动参数时逐帧全量采集;
  高亮同步不等这个窗口: 回调内先做一次只读活动项比较的即时同步(_sync_highlight_now);
- 相机/灯光/灯光集合三个列表按视图层收集: 被排除(exclude)的集合内的物体与集合本身不列;
- **已知限制**: WM 级状态组是单份, 多窗口查看不同场景时会互相覆盖(修复需按窗口分桶,
  属独立工程); 当前只保证"不处理其它场景的 depsgraph 更新".
"""

import bpy

from ...common.blender.list_order import assign_order_at_end, get_order
from ...common.blender.list_snapshot import find_item_index, is_syncing, rebuild_if_changed, set_guarded, set_index
from .scene_state import LIST_SPECS, all_blocks_for, get_state, highlight_item
from .utils import (
    LIGHT_COLLECTION_PREFIX,
    apply_light_advanced_wiring,
    collect_camera_blocks,
    collect_image_blocks,
    collect_ies_filepaths,
    collect_light_collection_blocks,
    collect_light_blocks,
    collect_scene_material_blocks,
    collect_material_blocks,
    collect_world_blocks,
    first_image_of_material,
    focus_image_editors,
    is_runtime_image,
    light_advanced_chain_broken,
    light_advanced_has_wiring,
    rig_light_of,
    sync_active_camera_resolution,
)

# 列表兜底刷新间隔(秒)
_TIMER_INTERVAL = 1.0
# depsgraph 更新的合并窗口(秒): 拖动参数/播放动画时 depsgraph 每帧触发, 逐次全量采集会卡顿
_DEBOUNCE_SECONDS = 0.1

# 上一次已跟进的活动状态 (物体名, 活动材质名); 变化时才回写各列表高亮
_LAST_ACTIVE: tuple = ("", "")
# 上一次已跟进的活动集合名(灯光集合列表 ↔ 大纲活动层集合联动); 变化时才回写
_LAST_ACTIVE_LIGHT_COLL: str = ""
# 上一次已跟进的场景级引用 (世界名, 场景相机名); 变化时才显式 tag 重绘
_LAST_SCENE_REFS: tuple = ("", "")
# "面板导入图像"的待高亮登记(ImageOpen 打开文件对话框前记录现有图像名集合):
# 载入完成后的首次快照重建按差集高亮新增非运行期图像并清除; 对话框被取消时登记
# 保留(下次有真实导入才消耗), 载入 .blend 时作废. 不进 reset_sync_cache: 它是
# 用户操作意图标记而非已同步状态, 合并窗口内的快照重建不能把它丢掉
_PENDING_IMAGE_HIGHLIGHT: set | None = None
# 已挂起一次延迟刷新(合并窗口内的重复更新只排一次)
_debounce_pending = False
# 模态调值期间的全量同步挂起(模态只写变换, 快照比较键是名称/类型/库链接, 变换写
# 不可能改变列表成员——期间的全量重建与兜底刷新纯属浪费, 是模态卡顿主因)
_sync_suppressed = False


def set_sync_suppressed(suppressed: bool) -> None:
    """挂起/恢复列表全量同步(模态算子调值期间调用, 退出必须复位)"""
    global _sync_suppressed, _debounce_pending
    _sync_suppressed = suppressed
    if suppressed and _debounce_pending:
        # 进模态前已排队的 0.1s 重建在模态内照跑属浪费: 取消(模态只写变换, 取消安全)
        _debounce_pending = False
        if bpy.app.timers.is_registered(_debounced_sync):
            bpy.app.timers.unregister(_debounced_sync)


def reset_sync_cache() -> None:
    """清空"已同步的活动状态"缓存(选区同步开关切换/载入文件后重新开始同步)

    _LAST_SCENE_REFS 不在此列: 它缓存的是场景实际引用(自校验), 清零反而让每轮快照
    重建后的 _sync_scene_refs 把世界高亮重新顶回场景世界行, 顶掉用户手动高亮.
    """
    global _LAST_ACTIVE, _LAST_ACTIVE_LIGHT_COLL
    _LAST_ACTIVE = ("", "")
    _LAST_ACTIVE_LIGHT_COLL = ""


def on_sync_toggle(self, context) -> None:
    """选区同步开关的 update 回调: 重置缓存, 让下一轮同步重新对齐"""
    reset_sync_cache()


def on_list_scope_update(self, context) -> None:
    """收集范围开关(显示0用户/显示库链接)的 update 回调: 立即重建快照(开关只改收集范围)"""
    refresh_lists()


def on_images_index_update(self, context) -> None:
    """图像列表活跃索引回调: 点击行时把图像编辑器切换到该图

    程序化写入(快照重建/高亮回写/移动条目)均在 common.list_snapshot 的护栏内,
    见 is_syncing 即跳过, 避免同步过程抢走用户的图像编辑器.
    """
    if is_syncing():
        return
    idx = self.images_active_index
    if not 0 <= idx < len(self.images):
        return
    # 同名本地/链接对按行标记消歧(经 resolver), 不能按名称裸查
    image = LIST_SPECS["images"].resolve(context, self.images[idx])
    if image is not None:
        focus_image_editors(context, image)


def _collect_lists(state) -> dict:
    """收集各资源列表的目标名称序列

    相机/灯光/灯光集合按**视图层**收集(被排除的集合不列); 场景材质槽每轮只扫描一次:
    材质列表直接复用该结果; 图像列表尾部追加 IES 光域网条目(kind='IES', 灯光节点树
    引用的外部路径与内嵌 Text 块), 图像本体仍按顺序值排序.
    """
    scene = bpy.context.scene
    view_layer = bpy.context.view_layer
    used_materials = collect_scene_material_blocks(scene)
    image_blocks = collect_image_blocks(state.show_zero_user_images, state.show_linked_data)
    ies_paths = collect_ies_filepaths(scene)
    material_blocks = collect_material_blocks(scene, state.show_zero_user_materials, used_materials, state.show_linked_data)
    world_blocks = collect_world_blocks(state.show_zero_user_worlds, state.show_linked_data)
    camera_blocks = collect_camera_blocks(scene, view_layer)
    light_blocks = collect_light_blocks(scene, view_layer)
    collection_blocks = collect_light_collection_blocks(view_layer)
    return {
        "cameras": ([block.name for block in camera_blocks], ['OBJECT'] * len(camera_blocks), [bool(block.library) for block in camera_blocks]),
        "lights": ([block.name for block in light_blocks], ['OBJECT'] * len(light_blocks), [bool(block.library) for block in light_blocks]),
        "light_collections": ([block.name for block in collection_blocks], ['COLLECTION'] * len(collection_blocks), [bool(block.library) for block in collection_blocks]),
        "materials": ([block.name for block in material_blocks], ['MATERIAL'] * len(material_blocks), [bool(block.library) for block in material_blocks]),
        "worlds": ([block.name for block in world_blocks], ['WORLD'] * len(world_blocks), [bool(block.library) for block in world_blocks]),
        "images": ([block.name for block in image_blocks] + ies_paths, ['IMAGE'] * len(image_blocks) + ['IES'] * len(ies_paths), [bool(block.library) for block in image_blocks] + [False] * len(ies_paths)),
    }


def tag_3d_views() -> None:
    """标记所有 3D 视图与大纲管理器区域重绘(程序化写入不触发刷新, 需显式 tag)

    供算子/回调在写入视口相关状态后调用(隔离屏蔽世界、列表高亮回写等).
    """
    for window in bpy.context.window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type in {'VIEW_3D', 'OUTLINER'}:
                area.tag_redraw()


def _sync_selection(context, state) -> None:
    """活动物体(或其活动材质)变化时, 按选区同步开关回写高亮

    只在"活动状态"变化时执行: 用户点其它行只改高亮, 不会被下一轮重建顶回.
    写入索引后显式 tag 重绘: 程序化属性写入不触发面板刷新, 否则高亮变化要等
    鼠标划过面板才可见.
    """
    global _LAST_ACTIVE
    act_obj = context.view_layer.objects.active
    if act_obj is None:
        _LAST_ACTIVE = ("", "")
        return
    act_mat = act_obj.active_material
    active = (act_obj.name, act_mat.name if act_mat is not None else "")
    if active == _LAST_ACTIVE:
        return
    _LAST_ACTIVE = active
    if not state.sync_selection:
        return
    highlight_item(context, "cameras", act_obj.name)
    _follow_light(context, act_obj)
    if act_mat is not None:
        highlight_item(context, "materials", act_mat.name)
        image = first_image_of_material(act_mat)
        if image is not None:
            highlight_item(context, "images", image.name)
    tag_3d_views()


def _follow_light(context, act_obj) -> None:
    """灯光列表跟进: 活动物体是灯光时高亮该灯光; 是恰挂一灯的控制器空体时高亮其灯"""
    if act_obj.type == 'LIGHT':
        highlight_item(context, "lights", act_obj.name, 'OBJECT')
    elif act_obj.type == 'EMPTY':
        light = rig_light_of(act_obj)
        if light is not None:
            highlight_item(context, "lights", light.name, 'OBJECT')


def _sync_light_collection_highlight(context) -> None:
    """大纲管理器的活动集合变化时, 灯光集合列表高亮跟随(仅限 CLS_ 前缀集合)

    面板点击行经 props 回调设活动层集合, 走到这里时名字一致即 no-op, 不会互相顶回;
    大纲里选中的集合若不带前缀则不碰列表高亮.
    """
    global _LAST_ACTIVE_LIGHT_COLL
    view_layer = getattr(context, "view_layer", None)
    active_coll = getattr(getattr(view_layer, "active_layer_collection", None), "collection", None)
    name = active_coll.name if active_coll is not None and active_coll.name.startswith(LIGHT_COLLECTION_PREFIX) else ""
    if name == _LAST_ACTIVE_LIGHT_COLL:
        return
    _LAST_ACTIVE_LIGHT_COLL = name
    if not name:
        return
    highlight_item(context, "light_collections", name)
    tag_3d_views()


def _sync_scene_refs(context) -> None:
    """场景世界/场景相机被面板外路径改写时: 世界列表高亮跟随 + 显式 tag 重绘

    世界行指派图标与相机行视角图标按 scene.world / scene.camera draw 期直读, 外部
    切换(着色器编辑器世界选择器、大纲、属性编辑器等)只重绘来源编辑器, 资源面板要等
    鼠标划过才刷新. 世界列表高亮也跟随场景世界——与材质高亮
    跟随活动物体材质同款语义(着色器编辑器切的就是它), 世界面板无"选区同步"开关故
    无条件跟进(与灯光集合跟随大纲同款); 只在世界名变化时写一次, 用户点其它行不会被顶回.
    比较只读两个名称, 供即时与全量两条同步路径共用.
    """
    global _LAST_SCENE_REFS
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    world = scene.world
    cam = scene.camera
    refs = (world.name if world is not None else "", cam.name if cam is not None else "")
    if refs == _LAST_SCENE_REFS:
        return
    world_changed = refs[0] != _LAST_SCENE_REFS[0]
    _LAST_SCENE_REFS = refs
    if world_changed and refs[0]:
        highlight_item(context, "worlds", refs[0])
    tag_3d_views()


def expect_image_import() -> None:
    """登记一次"面板导入图像"待高亮(供 ImageOpen 算子打开文件对话框前调用)

    文件对话框是异步载入, 算子拿不到载入完成时机; 记下现有图像名集合, 之后首次
    快照重建时按差集消耗(见 _consume_image_import_highlight).
    """
    global _PENDING_IMAGE_HIGHLIGHT
    _PENDING_IMAGE_HIGHLIGHT = {img.name for img in bpy.data.images}


def _consume_image_import_highlight(context) -> None:
    """消耗图像导入登记: 快照出现登记时不存在的新图像(非运行期)即高亮该行并清除

    新增的只有运行期图像(渲染 Result 等)时不消耗不高亮; 没有新增(对话框被取消)
    保留登记, 下次有真实导入才消耗.
    """
    global _PENDING_IMAGE_HIGHLIGHT
    if _PENDING_IMAGE_HIGHLIGHT is None:
        return
    for item in get_state(context).images:
        if item.kind != 'IMAGE' or item.src_name in _PENDING_IMAGE_HIGHLIGHT:
            continue
        image = LIST_SPECS["images"].resolve(context, item)
        if image is not None and not is_runtime_image(image):
            highlight_item(context, "images", item.src_name)
            _PENDING_IMAGE_HIGHLIGHT = None
            return


def _pending_new_light(context) -> str:
    """新建灯光待高亮判定(快照重建前调用): 活动灯光不在快照里才可能是新建项

    "新建灯光"不分路径(面板"+"按钮/Shift+A/添加菜单/复制)都让新灯成为活动物体;
    与"选区同步"的口径差异: 选中既有物体不改高亮(尊重开关), 新建才跟随, 同步开与
    关都跟. 返回待高亮灯光名, 非新建返回空串.
    """
    act = getattr(context.view_layer, "objects", None)
    act = getattr(act, "active", None) if act is not None else None
    name = act.name if act is not None and act.type == 'LIGHT' else ""
    if name and find_item_index(get_state(context), "lights", name, 'OBJECT') < 0:
        return name
    return ""


def _order_new_light_at_end(context, name: str) -> None:
    """新建灯光默认追加到灯光列表末尾

    无顺序值的新灯按 order_key 会落进"无顺序值组"按名称插入; 快照重建前授予
    最大值+1 使其落在创建序末尾. 复制灯继承源的顺序值(紧邻源)不在此列;
    库链接灯不可写自定义属性, 跳过(相机/灯光无链接导入价值, 防御性守卫).
    """
    light = context.scene.objects.get(name)
    if light is None or light.library is not None or get_order(light) is not None:
        return
    assign_order_at_end(light, all_blocks_for(context, "lights"))


def _order_imported_images_at_end(context) -> None:
    """面板导入的图像默认追加到图像列表末尾

    文件对话框异步载入, 只能在快照重建前按差集(登记集合之外的本地面板图像)补
    顺序值; 复制图像继承源的顺序值不在此列.
    """
    if _PENDING_IMAGE_HIGHLIGHT is None:
        return
    for image in bpy.data.images:
        if image.name in _PENDING_IMAGE_HIGHLIGHT or is_runtime_image(image) or image.library is not None:
            continue
        if get_order(image) is None:
            assign_order_at_end(image, all_blocks_for(context, "images"))


def _sync_all() -> None:
    """全量同步: 有变化才重建各列表快照, 按选区同步开关回写高亮, 并按场景相机同步独立分辨率"""
    context = bpy.context
    state = get_state(context)
    # 新建项追加到末尾的顺序值授予须在快照重建**前**完成, 本次重建即按末尾序排列
    pending_light = _pending_new_light(context)
    if pending_light:
        _order_new_light_at_end(context, pending_light)
    _order_imported_images_at_end(context)
    collected = _collect_lists(state)
    rebuilt = False
    for kind, spec in LIST_SPECS.items():
        names, kinds, linked = collected[kind]
        if rebuild_if_changed(state, spec.collection, spec.index, spec.item_kind, names, kinds, linked):
            rebuilt = True
    if rebuilt:
        # 条目被整体替换后旧缓存不代表已同步: 不清掉的话, 即时高亮路径在"新建物体尚未
        # 进快照"时的失败会被 _LAST_ACTIVE 吃掉, 高亮要等用户再换一次选中才跟上
        reset_sync_cache()
        # 外部路径增删资源(属性编辑器/大纲等)同样不重绘本插件面板: 快照变了就显式 tag
        tag_3d_views()
        if pending_light and find_item_index(state, "lights", pending_light, 'OBJECT') >= 0:
            highlight_item(context, "lights", pending_light, 'OBJECT')
    _consume_image_import_highlight(context)
    _sync_image_tips(context, state)
    _sync_selection(context, state)
    _sync_light_collection_highlight(context)
    _sync_scene_refs(context)
    # 场景相机变化(含 Ctrl+Numpad0/大纲等原生路径)与覆写值变化都经此兜底, 幂等无反馈环
    sync_active_camera_resolution(bpy.context.scene)


def _sync_image_tips(context, state) -> None:
    """图像条目的整行悬停信息(分辨率 + 引用路径), 有变化才写

    template_list 的 item_dyntip_propname 指向 ListItem.tip; 尺寸/路径变化不改变列表
    成员(不走快照重建), 在此按需回填; 渲染结果/查看器等无尺寸无路径的条目留空.
    同名本地/链接对按行标记消歧(经 resolver), 不能按名称裸查.
    """
    for item in state.images:
        img = LIST_SPECS["images"].resolve(context, item)
        parts = []
        if img is not None:
            # 读 img.size 会把未载入图像强制载入像素(5.1.2 探针实测: load 载入的图像
            # has_data False->True), 每轮全量逐图读会让大贴图在同步节拍下被周期性强制载入;
            # 未载入条目 tip 只给路径, 待图像被自然载入(has_data 翻真)后下一轮回填尺寸
            if img.has_data:
                width, height = img.size
                if width > 0:
                    parts.append("{} x {}".format(width, height))
            if img.filepath:
                parts.append(img.filepath)
        tip = "\n".join(parts)
        if item.tip != tip:
            item.tip = tip


def _sync_highlight_now(context) -> None:
    """立即回写列表高亮(选区同步 + 灯光集合跟随), 不做快照重建

    只读活动物体名与本地上次值比较, 命中变化才写一次索引, 成本可忽略; depsgraph 更新
    到快照重建之间原本隔着合并窗口(0.1s)与全量采集, 选中后高亮要等一截才动(同步延迟明显). 全量重建仍走合并窗口, 不受影响.
    """
    try:
        _sync_selection(context, get_state(context))
        _sync_light_collection_highlight(context)
        _sync_scene_refs(context)
    except (ReferenceError, AttributeError, RuntimeError):
        # 注销窗口期 WM 属性已摘除; RuntimeError 兜住"该上下文不许写属性"的极端情形
        pass


def _sync_all_safe() -> None:
    """全量同步, 吞掉"插件注销窗口期 WM 属性已摘除"类异常(各入口共用)"""
    try:
        _sync_all()
    except (ReferenceError, AttributeError):
        pass


def _debounced_sync() -> None:
    """合并窗口到期: 清挂起位并做一次全量同步"""
    global _debounce_pending
    _debounce_pending = False
    _sync_all_safe()
    return None


def _advanced_touched(depsgraph) -> bool:
    """本次 depsgraph 更新是否涉及灯光(灯型切换/树重建才需要自愈检查; 常规更新零成本跳过)

    updates 里可能出现灯光物体或灯光数据块(灯型切换重建节点树走后者); 迭代异常按
    "需要检查"兜底(误报只多跑一次便宜循环, 漏报则自愈失效).
    """
    try:
        for update in depsgraph.updates:
            item = getattr(update, "id", None)
            if isinstance(item, bpy.types.Light) or (isinstance(item, bpy.types.Object) and item.type == 'LIGHT'):
                return True
    except Exception:
        return True
    return False


def _reapply_light_advanced(scene) -> None:
    """高级设置链自愈: 活跃模式灯两类修正——灯型相符但接线断(树重建/误删节点)幂等重接;
    灯型不符但插件线残留(外部切灯型不经控件)按接线闸断线. 只在真有变化时才写,
    重接/断线本身会再触发一次 depsgraph, 届时状态已就位, 自然收敛不循环.

    本函数只从 timer 调用(depsgraph 回调内写节点树属重入修改, 有崩溃风险).
    """
    for obj in scene.objects:
        if obj.type != 'LIGHT' or obj.library is not None:
            continue
        settings = getattr(obj.data, "ch_advanced", None)
        if settings is None or settings.mode == 'NONE':
            continue
        mismatched = (settings.mode in {'GRADIENT', 'IMAGE'} and obj.data.type not in {'AREA', 'SPOT'}) or (settings.mode == 'IES' and obj.data.type != 'POINT')
        if mismatched:
            if light_advanced_has_wiring(obj.data):
                apply_light_advanced_wiring(obj.data)
        elif light_advanced_chain_broken(obj.data):
            apply_light_advanced_wiring(obj.data)


_advanced_reapply_pending = False


def _schedule_reapply():
    """把链自愈排到 timer 执行: depsgraph 回调内直接写节点树(重链/建模板组)会在
    depsgraph 求值期间改数据, 用户手动连线时实测崩溃——推迟到主循环干净节拍"""
    global _advanced_reapply_pending
    if _advanced_reapply_pending:
        return
    _advanced_reapply_pending = True
    try:
        bpy.app.timers.register(_advanced_reapply_timer)
    except (ValueError, RuntimeError):
        _advanced_reapply_pending = False


def _advanced_reapply_timer():
    global _advanced_reapply_pending
    _advanced_reapply_pending = False
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        _reapply_light_advanced(scene)
    return None


def _on_depsgraph_update(scene=None, depsgraph=None) -> None:
    """depsgraph 更新回调: 只跟进当前窗口场景, 高亮即时同步, 快照重建按合并窗口延迟

    多窗口下 WM 状态仍是单份(见模块 docstring 的已知限制), 但至少不把其它场景的
    更新算进来; 连续更新(拖动参数/动画)在窗口内只排一次重建.
    选中物体(视口/大纲)会带 ID_RECALC_SELECT 触发本回调, 高亮因此不必等合并窗口.
    """
    global _debounce_pending
    if _sync_suppressed:
        # 模态调值期: 变换写不改变列表成员, 全量重建与高亮跟进一并跳过
        return
    current = getattr(bpy.context, "scene", None)
    if scene is not None and current is not None and scene != current:
        return
    _sync_highlight_now(bpy.context)
    if depsgraph is not None and _advanced_touched(depsgraph):
        _schedule_reapply()
    if _debounce_pending:
        return
    _debounce_pending = True
    try:
        bpy.app.timers.register(_debounced_sync, first_interval=_DEBOUNCE_SECONDS)
    except (ValueError, RuntimeError):
        # 注册失败(注销窗口期/计时器不可用)时不能把挂起位留在 True, 否则同步永久停摆
        _debounce_pending = False


def _sync_camera_names_state(state) -> None:
    """文件加载后回读相机 show_name 实况, 对齐"视图相机名称"开关

    开关是 WM 级不随文件保存, 而 show_name 写在相机对象上随 .blend 保存;
    不回读会错位成"相机名仍显示、开关却是关". 全部相机都显示才记为开;
    混合状态记为关但不清除 —— 回读经 set_guarded 护栏写入, 不触发批量覆写.
    """
    cameras = [obj for obj in bpy.context.scene.objects if obj.type == 'CAMERA']
    set_guarded(state, "cameras_show_names", bool(cameras) and all(obj.show_name for obj in cameras))


def _on_load_post(*_args) -> None:
    """文件加载回调: 快照存于 WM 跨文件保留, 载入后立即对齐新场景并重置跟进缓存

    活跃索引是 WM 级、跨文件保留的旧值, 新文件条目完全不同; 归零后再按名跟随/夹取,
    避免"打开新文件后高亮停在一个任意行". 另回读相机 show_name 实况对齐
    "视图相机名称"开关(开关 WM 级不随文件保存, 见 _sync_camera_names_state);
    场景侧分辨率覆写状态随 .blend 保存, 载入后先按场景相机对齐一次输出分辨率.
    """
    global _PENDING_IMAGE_HIGHLIGHT
    # 未完成的导入登记跨文件没有意义: 新文件的图像对登记集合全是"新增", 会高亮到任意行
    _PENDING_IMAGE_HIGHLIGHT = None
    reset_sync_cache()
    try:
        sync_active_camera_resolution(bpy.context.scene)
    except (ReferenceError, AttributeError):
        pass
    try:
        state = get_state(bpy.context)
        for spec in LIST_SPECS.values():
            set_index(state, spec.index, 0)
        _sync_camera_names_state(state)
    except (ReferenceError, AttributeError):
        pass
    _sync_all_safe()


def _on_undo_post(*_args) -> None:
    """撤销/重做回调: 顺序值写在数据块自定义属性上, 不触发 depsgraph, 需主动重建"""
    reset_sync_cache()
    _sync_all_safe()


def refresh_lists() -> None:
    """立即重建列表快照并回写高亮

    供"写自定义属性(不触发 depsgraph, 5.1.2 实测)"的算子主动调用, 如列表排序值写入.
    """
    _sync_all_safe()


def _sync_timer() -> float:
    """周期兜底刷新; 计时器回调抛错会被 Blender 摘除, 因此全量兜住"""
    if _sync_suppressed:
        return _TIMER_INTERVAL
    try:
        _sync_all()
    except Exception:
        pass
    return _TIMER_INTERVAL


def register() -> None:
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    for handlers_list in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_post not in handlers_list:
            handlers_list.append(_on_undo_post)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=_TIMER_INTERVAL, persistent=True)


def unregister() -> None:
    global _debounce_pending, _advanced_reapply_pending
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for handlers_list in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_post in handlers_list:
            handlers_list.remove(_on_undo_post)
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
    if bpy.app.timers.is_registered(_debounced_sync):
        bpy.app.timers.unregister(_debounced_sync)
    if bpy.app.timers.is_registered(_advanced_reapply_timer):
        bpy.app.timers.unregister(_advanced_reapply_timer)
    _debounce_pending = False
    _advanced_reapply_pending = False
