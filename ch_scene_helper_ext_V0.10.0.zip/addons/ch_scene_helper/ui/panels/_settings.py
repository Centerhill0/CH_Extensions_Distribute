"""
资源设置绘制模块

灯光/相机/材质设置区与 PBR 设置子面板的共享绘制实现.
抽出的目的是让折叠头/参数区/PBR 三项只有一份实现.

主要功能:
- setup_param_box: 参数子面板 box 的统一排版(property split + 去装饰)
- draw_details_section: 可折叠详情子面板的统一骨架(折叠头 + box + 内容回调)
- draw_bsdf_slots / draw_slot_placeholder_row: 材质基础参数区
- draw_light_settings / draw_camera_settings: 活动灯光/相机设置
- draw_light_advanced: 灯光高级设置子面板(四模式枚举含"无"档; 渐变三模式 + 常显色标,
  图像纹理/IES 光域网选择器 = 分类行 + 缩略图网格 + 链参数)
- draw_material_pbr: 材质面板的 PBR 设置子面板(坐标输出 + 投影统一控制)
"""

from bpy.types import Context, UILayout

from ...operators.object.light import LightAssetCategoryCycle, LightAssetCategoryMenuIES, LightAssetCategoryMenuImage, LightAdvancedCleanup, LightAdvancedClearExternal, LightAdvancedModeSet, LightAdvancedRefreshSource, LightAssetThumbCycle
from ...preference import get_prefs
from ...scene_state import panel_material
from ...utils import (
    MARK_IMAGE_ARRAY,
    MARK_IMAGE_HSV,
    MARK_IES_GAMMA,
    collect_orphan_nodes,
    detect_pbr_texture_graph,
    emission_occupied,
    find_advanced_node,
    find_advanced_ramp,
    get_surface_bsdf,
    get_texcoord_output,
    list_assets,
    list_categories,
    resolve_bsdf_slots,
    suppress_texcoord_updates,
)
from ...utils._constants import NO_SLIDER_SOCKETS, TEXCOORD_OPTIONS

# 已接线占位行的上游节点名截断上限(每帧布局, 长名会拖慢侧栏)
_UPSTREAM_NAME_MAX = 24

# 资产选择器的弹出预览相对网格缩略图的放大倍数(template_icon_view 的 scale_popup)
_GRID_POPUP_FACTOR = 1.6

# 高级设置模式胶囊(算子按钮, depress 高亮当前档): 标签走 Operator 语境查翻译
_ADVANCED_MODE_PILLS = (
    ('NONE', "None"),
    ('GRADIENT', "Gradient Module"),
    ('IMAGE', "Image"),
    ('IES', "IES"),
)

# 坐标输出下拉的合法标识集合(绘制期判真值是否落在候选项内)
_TEXCOORD_IDS = frozenset(option[0] for option in TEXCOORD_OPTIONS)


def truncate_node_name(name: str) -> str:
    """截断过长的上游节点名(首 _UPSTREAM_NAME_MAX 字符 + ...)"""
    return name if len(name) <= _UPSTREAM_NAME_MAX else name[:_UPSTREAM_NAME_MAX] + "..."


def setup_param_box(box: UILayout) -> None:
    """参数子面板 box 的统一排版口径

    - use_property_split: 属性名进左列、控件进右列, 与原生属性面板同观感
    - use_property_decorate = False: 去掉行尾的动画/覆盖等装饰点
    """
    box.use_property_split = True
    box.use_property_decorate = False


def draw_subpanel_header(layout: UILayout, state, prop_name: str, title: str, tail=None) -> bool:
    """无框折叠头(三角箭头 + 标题文本), 返回是否展开

    口径: prop(text="", emboss=False) 只画三角, 标题用 label 紧跟其后;
    展开态存面板状态组(SceneHelperState). tail 可选: 标题行尾的附加控件
    (如灯光方位折叠头的模态唤起按钮), 画在标题行内、标题文本之后.
    """
    opened = getattr(state, prop_name)
    header = layout.row()
    header.prop(state, prop_name, text="", emboss=False, icon='TRIA_DOWN' if opened else 'TRIA_RIGHT')
    header.label(text=title)
    if tail is not None:
        tail(header)
    return opened


def draw_details_section(layout: UILayout, state, prop_name: str, title: str, draw_body, header_tail=None) -> None:
    """可折叠详情子面板: 未展开直接返回; 展开时画 box 并交给 draw_body"""
    if not draw_subpanel_header(layout, state, prop_name, title, header_tail):
        return
    draw_body(layout.box())


def draw_texcoord_row(col: UILayout, ui_state, tex_coord, mapping) -> None:
    """PBR 设置第一行: 坐标输出下拉(Generated/UV/Object)

    真值在连接关系里(TexCoord 的哪个输出口接到 Mapping.Vector): 绘制前把真值写进镜像枚举,
    再画下拉; 用户改动经 props.on_pbr_texcoord_update 重建接线. draw 期写镜像必须抑制
    update 回调(否则每帧重画都会触发一次接线重建).
    真值不在三项候选内(如 Camera/Window/Reflection)时画置灰只读行.
    """
    current = get_texcoord_output(tex_coord, mapping)
    if current not in _TEXCOORD_IDS:
        row = col.row()
        row.enabled = False
        row.alignment = 'RIGHT'
        row.label(text="Texture Coordinate", icon='NODE_SOCKET_COLLECTION')
        row.label(text=current)
        return
    with suppress_texcoord_updates():
        ui_state.pbr_texcoord = current
    col.prop(ui_state, "pbr_texcoord")


def draw_texture_projection(col: UILayout, ui_state, textures: list) -> None:
    """PBR 设置第二行: 所有 PBR 图像纹理的投影统一控制

    - 绘制前读真值: 全部图一致 -> 写回镜像; 不一致 -> 保持镜像原值不动
    - 用户改动 -> 统一写全部命中纹理(非 Box 时 Blend 归零)
    - Box 时追加 Blend 行(镜像 FloatProperty, 同样统一写全部图)
    """
    values = {tex.projection for tex in textures}
    if len(values) == 1:
        with suppress_texcoord_updates():
            ui_state.pbr_projection = values.pop()
    col.prop(ui_state, "pbr_projection")
    if ui_state.pbr_projection == 'BOX':
        with suppress_texcoord_updates():
            ui_state.pbr_projection_blend = textures[0].projection_blend
        col.prop(ui_state, "pbr_projection_blend")


def draw_material_pbr(layout: UILayout, context: Context, ui_state) -> None:
    """材质面板的 PBR 设置子面板(材质设置之下, 同构折叠头)

    可见性: 取不到 Surface 直连的白名单节点、或 PBR 五步检测不过时整块不出现.
    """
    mat = panel_material(context)
    if mat is None or get_surface_bsdf(mat) is None:
        return
    pbr = detect_pbr_texture_graph(mat)
    if not pbr["ok"]:
        return

    def draw_body(box: UILayout) -> None:
        setup_param_box(box)
        # 坐标对复用 detect_pbr_texture_graph 同一遍追溯的结果(结果键 texcoord_pair,
        # 与 get_pbr_texcoord_pair 同口径): draw 期每帧重绘, 二次全树追溯纯属重复
        pair = pbr["texcoord_pair"]
        col = box.column()
        if mat.library is not None:
            # 库链接材质的节点树只读: 镜像枚举挂在 WM 状态上不会经 RNA editable 自动置灰,
            # 不禁用的话改动会写进链接节点树抛 RuntimeError
            col.enabled = False
        if pair is not None:
            draw_texcoord_row(col, ui_state, *pair)
        draw_texture_projection(col, ui_state, list(pbr["tex_by_channel"].values()))

    draw_details_section(layout, ui_state, "show_pbr_details", "PBR Settings", draw_body)


def draw_slot_placeholder_row(col: UILayout, socket) -> None:
    """已接线插槽的占位行: 图标 + 属性名靠右 + 置灰

    已接线的插槽写 default_value 会被渲染忽略, 画可编辑控件会让用户"拖了没反应".
    """
    row = col.row()
    row.enabled = False
    row.alignment = 'RIGHT'
    row.label(text=socket.name, icon='NODE_SOCKET_COLLECTION')
    upstream = socket.links[0].from_node.name if socket.links else ""
    row.label(text=truncate_node_name(upstream))


def draw_bsdf_slots(box: UILayout, node) -> None:
    """材质基础参数区: 按固定语义序一行一个属性

    - 未接线: prop 正常控件; 颜色带 slider; 金属度/粗糙度带 slider;
      Emission Strength 与 IOR 不用滑条(RNA hard 范围过大, 一拖数值就飞)
    - 已接线: 占位行
    """
    setup_param_box(box)
    col = box.column()
    for _semantic, socket, is_linked in resolve_bsdf_slots(node):
        if is_linked:
            draw_slot_placeholder_row(col, socket)
            continue
        use_slider = socket.type == 'RGBA' or (socket.type == 'VALUE' and socket.name not in NO_SLIDER_SOCKETS)
        col.prop(socket, "default_value", text=socket.name, slider=use_slider)


def draw_light_settings(box: UILayout, obj, context: Context) -> None:
    """灯光设置(传灯光物体, 因为 Cycles 的 lightgroup/spread 挂在物体与数据块两处)

    结构顺序固定: 可见性五钮网格 -> Temperature -> Color -> Power -> 类型属性 ->
    阴影/引擎项.
    """

    col = box.column(align=True)
    grid = col.row().grid_flow(align=True)
    grid.scale_y = 1.2
    grid.prop(obj, "visible_camera", text="", icon='CAMERA_DATA')
    grid.prop(obj, "visible_diffuse", text="", icon='MATSPHERE')
    grid.prop(obj, "visible_glossy", text="", icon='SHADING_RENDERED')
    grid.prop(obj, "visible_transmission", text="", icon='DISC')
    grid.prop(obj, "visible_volume_scatter", text="", icon='VOLUME_DATA')

    light = obj.data
    setup_param_box(box)
    col = box.column()
    row = col.row(align=True, heading="Temperature")
    row.prop(light, "use_temperature", text="")
    sub = row.row()
    sub.active = light.use_temperature
    sub.prop(light, "temperature", text="")

    col.prop(light, "color", text="Color" if not light.use_temperature else "Tint")
    row = col.row(align=True)
    row.prop(light, "energy")
    row.prop(light, "normalize", text="")
    col.prop(light, "exposure")

    if light.type in {'POINT', 'SPOT'}:
        row = col.row(align=True)
        row.prop(light, "shadow_soft_size", text="Radius")
        row.prop(light, "use_soft_falloff", text="")
        if light.type == 'SPOT':
            sub_row = col.row(align=True)
            sub_row.prop(light, "spot_size", text="Beam Shape")
            sub_row.prop(light, "spot_blend", text="", slider=True)
            sub_row.prop(light, "show_cone", text="", icon='LIGHT_SPOT')
    elif light.type == 'SUN':
        col.prop(light, "angle")
    elif light.type == 'AREA':
        col.prop(light, "shape")
        row = col.row(align=True)
        if light.shape in {'SQUARE', 'DISK'}:
            row.prop(light, "size")
        elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
            row.prop(light, "size", text="Size")
            row.prop(light, "size_y", text="Size")
        if context.scene.render.engine == 'CYCLES':
            col.prop(light, "spread")

    if light.type in {'POINT', 'SPOT', 'AREA'}:
        row = col.row(align=True, heading="Custom Distance")
        row.prop(light, "use_custom_distance", text="")
        sub_row = row.row()
        sub_row.active = light.use_custom_distance
        sub_row.prop(light, "cutoff_distance", text="")

    col.prop(light, "use_shadow", text="Cast Shadow")
    if context.scene.render.engine == 'CYCLES':
        col.prop_search(obj, "lightgroup", context.view_layer, "lightgroups", text="Light Group")


def draw_light_advanced(layout: UILayout, context: Context, state, obj) -> None:
    """灯光高级设置子面板(灯光设置与灯光方位之间)

    折叠头为标准折叠样式(三角 + 标题, 无激活按钮——激活由模式枚举的"无"档承担).
    提示替代 UI: 库链接灯 / 引擎非 Cycles / 太阳光时整块只画一行提示(与灯光方位
    无控制器提示同款), 不画任何控件; 渐变/图像档仅面光/聚光出控件, IES 档仅点光
    出控件, 灯型不符同样只画提示. 各模式参数的真值在灯光节点树的插件实例节点上,
    面板直绘节点插座(同材质基础参数区先例); Emission 被用户手改接线时只画提示行
    不置灰(触碰任一控件即恢复插件线), 模式胶囊保持可用以便切回"无"档退出.
    """
    if obj is None:
        return
    light = obj.data
    settings = light.ch_advanced

    def header_tail(header: UILayout) -> None:
        """标题行尾的清理钮(灯光方位折叠头先例): 无孤立节点时置灰"""
        tail_row = header.row(align=True)
        tail_row.enabled = obj.library is None and bool(collect_orphan_nodes(light))
        tail_row.operator(LightAdvancedCleanup.bl_idname, text="", icon='TRACKING_CLEAR_BACKWARDS')

    if not draw_subpanel_header(layout, state, "show_light_advanced", "Advanced Settings", header_tail):
        return

    body = layout.box()

    if obj.library is not None:
        # 库链接灯只读: 任何引擎下都只画这一行提示(检查先于 mode 行与引擎判断)
        setup_param_box(body)
        col = body.column()
        col.label(text="Linked light data is read-only", icon='LIBRARY_DATA_DIRECT')
        return

    if context.scene.render.engine == 'CYCLES':
        header_row = body.row(align=True)
        header_row.scale_y = 1.2
        for mode_value, label in _ADVANCED_MODE_PILLS:
            pill = header_row.operator(LightAdvancedModeSet.bl_idname, text=label, depress=settings.mode == mode_value)
            pill.mode = mode_value

    setup_param_box(body)
    col = body.column()
    if context.scene.render.engine != 'CYCLES':
        col.label(text="Switch the render engine to Cycles", icon='INFO')
        return
    if light.type == 'SUN':
        col.label(text="Sun lights are not supported", icon='INFO')
        return

    if settings.mode == 'NONE':
        return

    module = col
    if emission_occupied(light):
        # 用户手动接线不阻断接管(触碰任一控件即恢复插件线), 面板只提示
        warning = col.row()
        warning.enabled = False
        warning.label(text="Hand wiring detected on the Emission node", icon='INFO')
    if settings.mode == 'GRADIENT':
        if light.type not in {'AREA', 'SPOT'}:
            module.label(text="Switch the light to an area or spot light", icon='INFO')
            return
        _draw_gradient_controls(module, settings, light)
    elif settings.mode == 'IMAGE':
        if light.type not in {'AREA', 'SPOT'}:
            module.label(text="Switch the light to an area or spot light", icon='INFO')
            return
        _draw_image_controls(module, state, light)
    elif settings.mode == 'IES':
        if light.type != 'POINT':
            module.label(text="Switch the light to a point light", icon='INFO')
            return
        _draw_ies_controls(module, state, light)


def _draw_gradient_controls(controls: UILayout, settings, light) -> None:
    """渐变档: 渐变调节区(模式行下方常显, 默认全白) + 分隔线 + 渐变类型(单行) + 组实例参数

    着色开关已取消: 色标恒接 Emission.Color, 每档色标独立常驻(切换不丢).
    """
    ramp = find_advanced_ramp(light, settings.gradient_type)
    if ramp is not None:
        controls.template_color_ramp(ramp, "color_ramp")
    controls.separator(type='LINE')
    type_row = controls.row(align=True)
    type_row.prop(settings, "gradient_type", expand=True)
    group_node = find_advanced_node(light, settings.gradient_type)
    if group_node is not None:
        params = controls.column()
        for socket in group_node.inputs:
            params.prop(socket, "default_value", text=socket.name)


def _draw_external_path_row(controls: UILayout, settings, pick_kind: str) -> None:
    """外部文件路径行: 全宽绘制(不设 use_property_split)+ 清除按钮(常驻, 无路径时置灰)"""
    field = "image_external" if pick_kind == 'IMAGE' else "ies_external"
    row = controls.row(align=True)
    row.use_property_split = False
    row.prop(settings, field, text="")
    clear_col = row.column(align=True)
    clear_col.enabled = bool(getattr(settings, field))
    clear = clear_col.operator(LightAdvancedClearExternal.bl_idname, text="", icon='X')
    clear.pick_kind = pick_kind


def _draw_image_controls(controls: UILayout, state, light) -> None:
    """图像档: 外部文件路径(全宽+清除) + 纹理选择器 + 接线目标胶囊 + 阵列参数 + HSV"""
    settings = light.ch_advanced
    _draw_external_path_row(controls, settings, 'IMAGE')
    _draw_asset_picker(controls, state, 'IMAGE')
    target_row = controls.row(align=True)
    target_row.prop(settings, "image_target", expand=True)
    array_group = find_advanced_node(light, MARK_IMAGE_ARRAY)
    if array_group is not None:
        target_row = controls.row(align=True)
        target_row.prop(settings, "image_array_mode", expand=True)
        params = controls.column(align=True)
        ring = array_group.inputs["阵列方式"].default_value > 0.5
        shown = ("阵列数量", "缩放", "半径", "自旋转") if ring else ("阵列X", "阵列Y")
        for socket_name in shown:
            params.prop(array_group.inputs[socket_name], "default_value", text=socket_name)
    hsv = find_advanced_node(light, MARK_IMAGE_HSV)
    if hsv is not None:
        params = controls.column()
        for socket_name in ("Hue", "Saturation", "Value"):
            params.prop(hsv.inputs[socket_name], "default_value", text=socket_name)


def _draw_ies_controls(controls: UILayout, state, light) -> None:
    """IES 档: 外部文件路径(全宽+清除) + 光域网选择器 + 伽玛参数"""
    settings = light.ch_advanced
    _draw_external_path_row(controls, settings, 'IES')
    _draw_asset_picker(controls, state, 'IES')
    gamma = find_advanced_node(light, MARK_IES_GAMMA)
    if gamma is not None:
        controls.prop(gamma.inputs["Gamma"], "default_value", text="Gamma")


def _draw_asset_picker(col: UILayout, state, pick_kind: str) -> None:
    """资产选择器(图像纹理/IES 共用): 分类行(箭头循环 + 名称点击弹窗选定) +
    缩略图行(左右钮循环应用 + 图标网格) + 选中名标签 + 分隔横线

    分类与文件名都是运行期才知道的中文: 分类名/选中名走算子按钮与 label(翻译链安全),
    网格条目名称不进动态枚举(非 ASCII 会乱码, 图标即条目身份; 悬停说明带名称与分辨率).
    缩略图尺寸取偏好 asset_thumb_size(两选择器共用). 偏好目录未配/无分类/无缩略图各画
    提示行; 分类失效只影响扫描与显示, 由箭头算子落位.
    """
    prefs = get_prefs()
    root = prefs.light_tex_dir if pick_kind == 'IMAGE' else prefs.ies_dir
    kind_lower = 'image' if pick_kind == 'IMAGE' else 'ies'
    if not root:
        hint = col.row()
        hint.enabled = False
        hint.label(text="Set the asset directory in the addon preferences", icon='PREFERENCES')
        return
    categories = list_categories(root)
    if not categories:
        hint = col.row()
        hint.enabled = False
        hint.label(text="No category folders in the asset directory", icon='INFO')
        return
    current = getattr(state, f"adv_{kind_lower}_category", "")
    if current not in categories:
        current = categories[0]
    row = col.row(align=True)
    op = row.operator(LightAssetCategoryCycle.bl_idname, text="", icon='TRIA_LEFT')
    op.pick_kind = pick_kind
    op.is_next = False
    # 分类名挂下拉菜单: 菜单项落 Set 算子写回分类
    category_menu = LightAssetCategoryMenuImage if pick_kind == 'IMAGE' else LightAssetCategoryMenuIES
    row.menu(category_menu.bl_idname, text=current)
    op = row.operator(LightAssetCategoryCycle.bl_idname, text="", icon='TRIA_RIGHT')
    op.pick_kind = pick_kind
    op.is_next = True

    assets = list_assets(root, current, pick_kind)
    if not assets:
        hint = col.row()
        hint.enabled = False
        hint.label(text="No thumbnails in this category", icon='IMAGE_DATA')
        return
    scale = get_prefs().asset_thumb_size
    thumb_row = col.row(align=True)
    # 循环钮包进同系数拉伸的列, 与缩略图网格绘制高度一致(系数同源偏好尺寸)
    left_col = thumb_row.column(align=True)
    left_col.scale_y = scale
    op = left_col.operator(LightAssetThumbCycle.bl_idname, text="", icon='TRIA_LEFT')
    op.pick_kind = pick_kind
    op.is_next = False
    thumb_row.template_icon_view(state, f"adv_{kind_lower}_pick", show_labels=False, scale=scale, scale_popup=scale * _GRID_POPUP_FACTOR)
    right_col = thumb_row.column(align=True)
    right_col.scale_y = scale
    op = right_col.operator(LightAssetThumbCycle.bl_idname, text="", icon='TRIA_RIGHT')
    op.pick_kind = pick_kind
    op.is_next = True
    picked_key = getattr(state, f"adv_{kind_lower}_pick", "")
    picked_asset = next((asset for asset in assets if asset["key"] == picked_key), None)
    if picked_asset is not None:
        label_row = col.row(align=True)
        label_row.label(text=picked_asset["source_name"])
        refresh = label_row.operator(LightAdvancedRefreshSource.bl_idname, text="", icon='FILE_REFRESH')
        refresh.pick_kind = pick_kind
    # 预览区与属性设置之间的分隔横线(属性由调用方接着绘制)
    col.separator(type='LINE')


def draw_camera_settings(box: UILayout, obj, context: Context) -> None:
    """相机设置: Independent Resolution -> Lens -> Clip -> Sensor -> Safe Areas -> Background Images -> DOF

    传物体而非相机数据: 独立分辨率属性组挂在物体上(随 .blend 保存).
    """
    cam = obj.data
    setup_param_box(box)
    # 独立分辨率: 每相机独立的输出分辨率, 该相机为场景相机时覆写场景输出(镜头行上方);
    # 开关用 prop 绘制以参与 use_property_split 两列布局(operator 按钮会占满整行),
    # 开启时的初始化与即时同步走属性 update 回调(props.on_camera_resolution_update)
    col = box.column()
    settings = obj.ch_resolution
    col.prop(settings, "use_independent")
    if settings.use_independent:
        col.prop(settings, "res_x", text="X")
        col.prop(settings, "res_y", text="Y")

    row = col.row(align=True)
    row.prop(cam, "lens_unit")
    if cam.lens_unit == 'MILLIMETERS':
        row.prop(cam, "lens")
    else:
        row.prop(cam, "angle")

    row = col.row(align=True)
    row.prop(cam, "clip_start", text="Clip")
    row.prop(cam, "clip_end", text="")

    col = col.column()
    col.prop(cam, "sensor_width", text="Sensor")
    col.prop(cam, "show_safe_areas", text="Safe Areas")
    col.prop(cam, "show_background_images", text="Background Images")

    col.prop(cam.dof, "use_dof", text="DOF")
    if cam.dof.use_dof:
        col.row().prop(cam.dof, "focus_object")
        row = col.row()
        row.active = cam.dof.focus_object is None
        row.prop(cam.dof, "focus_distance")
        # 取景器算子的路径以 context.scene.camera 为落点: 面板活动相机不是场景相机时
        # 画出来会改到另一台相机的焦点距离, 故只在两者一致时提供.
        scene_camera = context.scene.camera
        if scene_camera is not None and scene_camera.data == cam:
            op = row.operator("ui.eyedropper_depth", icon='EYEDROPPER', text="")
            op.prop_data_path = 'scene.camera.data.dof.focus_distance'
        col.row().prop(cam.dof, "aperture_fstop")
