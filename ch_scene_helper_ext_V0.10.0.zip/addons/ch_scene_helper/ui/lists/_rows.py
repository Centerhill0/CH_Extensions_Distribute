"""
列表行绘制共享 helper

供五个资源列表(ui/lists/scene_lists.py)使用的行绘制单元:
名称列、缺失条目占位、类型图标、选择/伪用户按钮、行内视口/渲染禁用开关与材质预览图.
行内列宽分配: 全部行走行布局原生机制——空文本图标按钮 fixed_size 恒宽, 名称与列区
数字/路径等自由条目吃掉剩余宽度(见 interface_layout.cc 的 LayoutRow::resolve_impl),
行尾按钮任何宽度都不压缩, 零估算; 名称格仅在有列行按恒定 factor split 预留稳定列位.

列表行状态均为 draw 期直读真实数据块, 不存在快照里; 其中图像行的使用者图标查共享
映射(USERS_MAP_CACHE, 由图像列表 filter_items 每轮重建一次), 避免逐行全文件扫描——
逐行现算曾是大场景下本模块的主要绘制开销.
"""

from bpy.types import Context, Object, UILayout

from ...constants import LIGHT_ICONS
from ...operators.object.light_linking import LightLinkingEntryStateSet, LightLinkingEntryStateSetShadow
from ...operators.utils.image_ops import ImageSelectUsers, IesSelectLights
from ...operators.utils.row_ops import FakeUserToggle, ObjectRenderToggle, ObjectSelect, ObjectViewportToggle
from ...utils import USERS_MAP_CACHE, find_ies_lights, rig_controller_of

# 三列排布所需的最小面板宽度(像素): 更窄时回退纯靠右, 避免列区挤压右侧按钮
SPLIT_MIN_REGION_WIDTH = 300


def draw_link_state_toggle(row: UILayout, current: str, payload: dict, icon_include: str, icon_exclude: str, icon_off: str | None = None) -> None:
    """条目行尾的包含/排除单钮(原生同款: 图标示当前态, 点击翻转写另一态)

    current 为条目现态: INCLUDE/EXCLUDE 之间翻转; 空串 = 目标尚未加入集合, 点击即
    以包含态加入(反查行恒绘钮的"未加入"态), 图标取 icon_off(缺省用排除侧图标).
    payload 为算子载荷(emitter/target 等), state 由本助手按翻转结果写入; 载荷里的
    link_type 只用来选算子类, 不写入算子属性.
    两态图标由调用方按钮组语义给定(成员列表 = CHECKBOX 对, 反查行 = 灯/探针图标对
    区分灯光与阴影两组).
    """
    if current == 'INCLUDE':
        icon, next_state = icon_include, 'EXCLUDE'
    elif current == 'EXCLUDE':
        icon, next_state = icon_exclude, 'INCLUDE'
    else:
        icon, next_state = (icon_off or icon_exclude), 'INCLUDE'
    # 反查行同一行画两枚切换钮: 灯光/阴影各占一个 bl_idname 才不串属性(见 _EntryStateSetMixin)
    op_cls = LightLinkingEntryStateSetShadow if payload.get("link_type") == 'BLOCKER' else LightLinkingEntryStateSet
    op = row.operator(op_cls.bl_idname, text="", icon=icon, emboss=False)
    for attr, value in payload.items():
        if attr != "link_type":
            setattr(op, attr, value)
    op.state = next_state


def light_icon(obj: Object | None) -> str:
    """灯光行图标: 按灯光类型取; 失效条目回落通用灯图标"""
    if obj is None or obj.type != 'LIGHT':
        return 'LIGHT'
    return LIGHT_ICONS.get(obj.data.type, 'LIGHT')


def camera_icon(context: Context, obj: Object | None) -> str:
    """相机行图标: 场景相机用实心 VIEW_CAMERA 徽标, 其余用大纲相机图标"""
    is_scene_cam = obj is not None and context.scene.camera == obj
    return 'VIEW_CAMERA' if is_scene_cam else 'VIEW_CAMERA_UNSELECTED'


def draw_object_toggles(row: UILayout, obj: Object) -> None:
    """行内双开关: 在视图中禁用 / 在渲染中禁用(+Ctrl 隔离同类, 见 ObjectViewportToggle)

    两个开关各是独立算子类(同 idname 双按钮会串属性, 见 _ObjectDisableMixin);
    算子按钮没有 IconToggle 的开关态自动换算, 图标按当前状态显式取 _ON/_OFF 字形
    (与大纲管理器同款), 图标即状态.
    """
    op = row.operator(ObjectViewportToggle.bl_idname, text="", icon='RESTRICT_VIEW_ON' if obj.hide_viewport else 'RESTRICT_VIEW_OFF', emboss=False)
    op.obj_name = obj.name
    op.obj_linked = obj.library is not None
    op = row.operator(ObjectRenderToggle.bl_idname, text="", icon='RESTRICT_RENDER_ON' if obj.hide_render else 'RESTRICT_RENDER_OFF', emboss=False)
    op.obj_name = obj.name
    op.obj_linked = obj.library is not None


def material_preview_icon(mat) -> int:
    """取材质的预览图图标 id(原生材质列表同款彩色小球), 不可用时返回 0

    本插件的 ListItem 是 PropertyGroup 而非 MaterialSlot, 无法走原生自动路径,
    故显式取 mat.preview.icon_id 并以 icon_value 传入. 预览图由图标系统懒渲染,
    未渲染过时 icon_id 为 0(后台通道实测恒 0), 由调用方回落通用 MATERIAL 图标.
    """
    if mat is None:
        return 0
    preview = mat.preview
    if preview is None:
        try:
            preview = mat.preview_ensure()
        except (RuntimeError, AttributeError):
            return 0
    return getattr(preview, "icon_id", 0) if preview is not None else 0


def can_split_columns(context: Context) -> bool:
    """当前面板宽度是否足够容纳"列区 + 靠右按钮区"

    region 不可用时(后台/无界面)按可分割处理, 保持绘制逻辑一致.
    """
    region = getattr(context, "region", None)
    return region is None or getattr(region, "width", 0) >= SPLIT_MIN_REGION_WIDTH


def draw_name_cell(layout: UILayout, item, icon: str = 'NONE', icon_value: int = 0, name_factor: float | None = None, name_enabled: bool = True) -> UILayout:
    """行内名称格(无浮雕名称编辑框, 双击写穿真实数据块), 返回行尾按钮区

    无列行(name_factor=None): 名称直接画进行首按钮所在的 align 行——行布局里 prop 是
    自由条目, 空文本图标按钮是 fixed_size 恒宽, 子行全为 fixed 按钮时子行整体亦恒宽
    (interface_layout.cc 的 LayoutRow::resolve_impl / layout_add_but / estimate_impl),
    名称天然吃掉行尾按钮之外的全部宽度, 按钮任何宽度都不压缩——大纲管理器手绘分配的
    原生等价物, 零估算.
    有列行(name_factor 传入): 名称格按 factor split 预留稳定列位, 返回的右侧行已设
    右对齐, 列区 prop 与行尾按钮先后画入同一行即可——簇整体贴右缘, fixed 按钮任何
    宽度不压缩, 自由条目列区(数字/路径)在窄端按比例收缩.
    icon_value 与 icon 不能同时传(Blender 只认其中之一): icon_value 非 0 时画预览图,
    否则画 icon.
    name_enabled 为假(库链接数据块, 名称只读)时名称置灰并禁改: Layout::resolve 在块解析期
    才按 enabled_ 最终值给整棵子树的按钮打 BUT_DISABLED(interface_layout.cc), 同一容器
    "置假再恢复"不会生效——名称必须包进专属子行并让该子行的最终值为假, 行尾按钮区另建不受牵连.
    """
    if name_factor is None:
        if not name_enabled:
            name_row = layout.row(align=True)
            name_row.enabled = False
        else:
            name_row = layout
        if icon_value:
            name_row.prop(item, "name", text="", emboss=False, icon_value=icon_value)
        else:
            name_row.prop(item, "name", text="", emboss=False, icon=icon)
        right = layout.row(align=True)
    else:
        split = layout.split(factor=name_factor)
        if not name_enabled:
            name_row = split.row(align=True)
            name_row.enabled = False
        else:
            name_row = split
        if icon_value:
            name_row.prop(item, "name", text="", emboss=False, icon_value=icon_value)
        else:
            name_row.prop(item, "name", text="", emboss=False, icon=icon)
        right = split.row(align=True)
    right.alignment = 'RIGHT'
    return right


def draw_missing_item(layout: UILayout, item) -> None:
    """快照条目已失效时的整行占位(置灰 + 错误图标 + 旧名称)"""
    layout.enabled = False
    layout.label(text=item.name, icon='ERROR')


def _select_state_icon(context: Context, related_objects: list) -> str:
    """首位"选中关联物体"按钮的图标

    关联物体里含活动物体或有选中项 -> RESTRICT_SELECT_OFF(实心), 否则 RESTRICT_SELECT_ON.
    """
    if not related_objects:
        return 'RESTRICT_SELECT_ON'
    active = context.view_layer.objects.active
    if active is not None and any(obj is active for obj in related_objects):
        return 'RESTRICT_SELECT_OFF'
    return 'RESTRICT_SELECT_OFF' if any(obj.select_get() for obj in related_objects) else 'RESTRICT_SELECT_ON'


def draw_select_button(layout: UILayout, context: Context, obj: Object, list_kind: str) -> None:
    """行内选择按钮(相机/灯光): 选中该物体并高亮列表项(+Shift 切换选中, +Ctrl 选控制器)

    有控制器的灯: 按钮子行 alert 标红作为"已绑定控制器"的视觉标记;
    控制器的选中/活动态也点亮图标(+Ctrl 加减选控制器时的可见反馈).
    """
    related = [obj]
    controller = rig_controller_of(obj)
    has_controller = controller is not None
    if has_controller:
        related.append(controller)
    icon = _select_state_icon(context, related)
    button_row = layout.row(align=True)
    if has_controller:
        button_row.alert = True
    op = button_row.operator(ObjectSelect.bl_idname, text="", icon=icon, emboss=False)
    op.obj_name = obj.name
    op.obj_linked = obj.library is not None
    op.list_kind = list_kind


def draw_image_select(layout: UILayout, context: Context, img) -> None:
    """图像的"选中使用者"按钮(三态图标, 点击同时高亮图像列表项)

    使用者查共享映射(图像列表 filter_items 每轮重绘先建, 本函数只被该列表的
    draw_item 调用, 映射必已新鲜); 逐行现算是全文件扫描, 大文件上行数一多即卡.
    """
    users = USERS_MAP_CACHE.get(img.name, [])
    icon = _select_state_icon(context, users)
    op = layout.operator(ImageSelectUsers.bl_idname, text="", icon=icon, emboss=False)
    op.image_name = img.name
    op.image_linked = img.library is not None


def draw_ies_select(layout: UILayout, context: Context, src_name: str) -> None:
    """IES 行首"选中使用者"按钮(与图像行同款三态图标, 点击选中引用此 IES 的灯光)"""
    users = find_ies_lights(context.scene, src_name)
    icon = _select_state_icon(context, users)
    op = layout.operator(IesSelectLights.bl_idname, text="", icon=icon, emboss=False)
    op.ies_source = src_name


def draw_fake_user_count(row: UILayout, datablock, id_kind: str) -> None:
    """行内伪用户开关 + 使用者数(数字并入按钮内, 与图标紧凑成一体)

    库链接数据块不置灰: 按钮与本地行同款(带用户数)保持对齐,
    但点击无动作——算子侧按 library 拒绝(伪用户标志挂在库数据上, 会话内"生效"但不持久).
    """
    icon = 'FAKE_USER_ON' if datablock.use_fake_user else 'FAKE_USER_OFF'
    op = row.operator(FakeUserToggle.bl_idname, text="{:02d}".format(datablock.users), icon=icon, emboss=False)
    op.id_name = datablock.name
    op.id_kind = id_kind
    op.id_linked = datablock.library is not None
