"""
算子公共 mixin 与共享守卫

- TranslatedDescriptionMixin: 动态 tooltip 回调统一经 tip() 翻译
- PanelMaterialMixin: "物体模式 + 材质面板有活动材质"的 poll 与取材质/警告
- SelectionBatchMixin: 灯光饼菜单入口标记(对选中集筛选出的灯光批量起作用)
- batch_report: 批量结果计数报告, 库链接跳过仅在有跳过时追加尾缀
- deletion_guard: 数据块删除前的只读/引用检查与确认框(DatablockDelete/
  WorldUnlink/MaterialDelete 共用, 确认文案可按数据块类型覆盖)
"""

from bpy.props import BoolProperty
from bpy.types import Context, Event, Operator

from .....common.i18n.i18n import report, tip
from ...scene_state import panel_material
from ...utils import real_user_count


class TranslatedDescriptionMixin:
    """动态 tooltip 回调 mixin

    Blender 要求 description 是 classmethod/staticmethod, 且回调返回值不走静态
    bl_description 的翻译链, 必须经 tip() 自查.
    """

    @classmethod
    def description(cls, context: Context, properties):
        return tip(cls.bl_description)


class PanelMaterialMixin:
    """材质面板算子 mixin: poll 与取面板活动材质

    子类可按需关闭物体模式要求(如删除算子只要求有活动材质).
    """

    require_object_mode = True

    @classmethod
    def poll(cls, context: Context):
        if cls.require_object_mode and context.mode != 'OBJECT':
            return False
        return panel_material(context) is not None

    def require_panel_material(self, context: Context):
        """取面板活动材质; 无有效条目时报告警告并返回 None"""
        mat = panel_material(context)
        if mat is None:
            self.report({'WARNING'}, report("No material selected"))
        return mat


class SelectionBatchMixin:
    """饼菜单入口标记: True 时对选中集筛选出的灯光批量起作用, False 走各算子的缺省锚点

    灯光饼菜单的六钮(五钮 + 删除物体)置 True; 缺省锚点按算子而定——rig 族跟灯光面板
    活跃行, ObjectDelete 跟列表活跃行. 隐藏项不进 F9 面板(入口靠隐藏布尔属性传给算子,
    供 execute 分流).
    """

    use_selection_batch: BoolProperty(
        name="Selection Batch",
        default=False,
        # SKIP_SAVE: 入口标记不得进"上次算子属性"复用——否则饼菜单运行后, 面板入口会
        # 继承批量口径(与 LightAdd 的类型标记同族, 见 wm_operator last properties)
        options={'HIDDEN', 'SKIP_SAVE'},
        description="Operate on the lights filtered from the selection (set by the light pie menu)",
    )  # type: ignore


def batch_report(op: Operator, message: str, linked_skipped: list) -> None:
    """批量结果计数报告: 库链接跳过仅在有跳过时追加尾缀(零跳过不产噪声)"""
    if linked_skipped:
        message += report("; linked lights skipped: {}").format(len(linked_skipped))
    op.report({'INFO'}, message)


def deletion_guard(
    op: Operator,
    context: Context,
    event: Event | None,
    datablock,
    linked_msg: str = "Linked data-block cannot be deleted",
    users_msg: str = "Data-block is used by {} users, deleting it clears them",
) -> set | None:
    """数据块删除前的只读/引用检查, 返回 None 表示可以继续删除

    - 库链接数据: 不可删, 直接取消
    - 仍有真实使用者: 弹确认; 无事件(脚本直调)时 fail-closed 直接取消
    - linked_msg/users_msg: 传英文模板按数据块类型覆盖确认文案(如材质侧沿用材质专属文案)
    """
    if datablock.library is not None:
        op.report({'ERROR'}, report(linked_msg))
        return {'CANCELLED'}
    users = real_user_count(datablock)
    if users <= 0:
        return None
    op.report({'WARNING'}, report(users_msg).format(users))
    if event is None:
        return {'CANCELLED'}
    if not isinstance(op, Operator):
        # 无法弹模态的调用载体(如面板冒烟/用例桩): 不给隐式放行, 由调用方显式置 confirmed 续跑
        return {'CANCELLED'}
    op.confirmed = True
    return context.window_manager.invoke_confirm(op, event)
