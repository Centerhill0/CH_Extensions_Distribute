"""
灯光资产目录扫描模块

高级设置子面板(图像/IES 档)的资源选择器后端: 扫描偏好目录下的分类子文件夹与
缩略图条目(顶层 PNG=缩略图, Textures/ 或 IES/ 子目录内同名文件=源文件),
用图像数据块自带的预览机制生成缩略图图标(与 ch_ai 画廊同款, preview_ensure),
并负责源文件的查找与图像数据块的查重加载.

主要功能:
- list_categories / list_assets: 目录结构与条目扫描(条目须有源文件才收录)
- preview_icon_id: 缩略图预览图标(数据块查重加载 + preview_ensure; 打 ch_asset_thumb
  标记供图像列表过滤, 不进"自定义属性"面板)
- find_or_load_image: 按绝对路径查重加载图像数据块
- resolve_asset: 按条目键反查资产(缩略图枚举 update 回调用)
"""

import os
import zlib
from pathlib import Path

import bpy

# 目录约定: <根>/<分类>/ 顶层 PNG 为缩略图, 子目录内同名文件为源文件
IMAGE_SOURCE_SUBDIR = "Textures"
IES_SOURCE_SUBDIR = "IES"

# 图像源文件的候选扩展名(按序取首个命中)
_IMAGE_SOURCE_EXTS = (".jpg", ".jpeg", ".png", ".exr")

# 本会话被选择器当作缩略图载入的图像路径记忆(draw 期不能写 ID 类的 idprop,
# 故用纯 Python 集合记录, 供图像列表过滤; 0 使用者不随 .blend 保存, 跨会话自然重建)
_thumb_paths: set = set()

# 目录扫描缓存(绘制期每帧两次扫描的降噪): 键 = 扫描标识, 值 = (目录签名, 结果列表);
# 签名 = 目录内 (名字, mtime_ns) 元组(含源文件子目录)——增删/改写任一变化即失效重扫
_scan_cache: dict = {}
_SCAN_CACHE_MAX = 256


def _dir_signature(directory: Path) -> tuple:
    """目录签名((名字, mtime_ns) 按名排序); 目录不存在返回 ()"""
    if not directory.is_dir():
        return ()
    try:
        return tuple(sorted((item.name, item.stat().st_mtime_ns) for item in directory.iterdir()))
    except OSError:
        # 目录在签名期被移走(极端竞态): 视为空, 下次绘制按空目录口径走
        return ()


def _cached_scan(cache_key: str, scan_dir: Path, sub_dirs: tuple, scan_fn) -> list:
    """带签名的扫描记忆化: 签名不变直接回缓存, 变化则重扫并更新"""
    sig = (_dir_signature(scan_dir), tuple((name, _dir_signature(scan_dir / name)) for name in sub_dirs))
    hit = _scan_cache.get(cache_key)
    if hit is not None and hit[0] == sig:
        return hit[1]
    result = scan_fn()
    if len(_scan_cache) >= _SCAN_CACHE_MAX:
        _scan_cache.clear()
    _scan_cache[cache_key] = (sig, result)
    return result


def asset_key(name: str) -> str:
    """条目稳定键(文件名 crc32 十六进制): 跨扫描稳定, 重命名文件即换键"""
    return format(zlib.crc32(name.encode("utf-8")) & 0xFFFFFFFF, "08x")


def list_categories(root: str) -> list:
    """根目录下的分类子文件夹名(排序; 根目录缺失/非目录/为空返回 [])"""
    if not root:
        return []
    root_path = Path(root)
    if not root_path.is_dir():
        # 非目录(含不存在/是文件)直接空表: iterdir 会抛 NotADirectoryError
        return []

    def _scan():
        return sorted(item.name for item in root_path.iterdir() if item.is_dir() and not item.name.startswith("."))

    return _cached_scan(("cats", _norm_path(root)), root_path, (), _scan)


def _find_source(source_dir: Path, stem: str, exts) -> str | None:
    """在源文件子目录里按主干名匹配首个存在的文件"""
    for ext in exts:
        candidate = source_dir / (stem + ext)
        if candidate.is_file():
            return str(candidate)
    return None


def list_assets(root: str, category: str, kind: str) -> list:
    """某分类下的资产条目(排序, 仅收录源文件存在的条目; 带签名记忆化, 重绘期免重复扫描)

    kind: 'IMAGE' -> Textures/ 内同名图像; 'IES' -> IES/ 内同名 .ies.
    条目为 dict: name(主干名)/key(稳定键)/thumb(缩略图绝对路径)/source(源文件绝对路径)/
    size(缩略图像素宽高, 供悬停说明; 载入失败为 (0, 0)).
    """
    if not root or not category:
        return []
    cat_dir = Path(root) / category
    if not cat_dir.is_dir():
        return []
    subdir_name = IMAGE_SOURCE_SUBDIR if kind == 'IMAGE' else IES_SOURCE_SUBDIR
    exts = _IMAGE_SOURCE_EXTS if kind == 'IMAGE' else (".ies",)

    def _scan():
        assets = []
        for thumb in sorted(cat_dir.glob("*.png")):
            if not thumb.is_file():
                continue
            source = _find_source(cat_dir / subdir_name, thumb.stem, exts)
            if source is None:
                continue
            image = find_or_load_image(str(thumb))
            size = (image.size[0], image.size[1]) if image is not None else (0, 0)
            assets.append({"name": thumb.stem, "key": asset_key(thumb.stem), "thumb": str(thumb), "source": source, "source_name": Path(source).name, "size": size})
        return assets

    return _cached_scan(("assets", _norm_path(root), category, kind), cat_dir, (subdir_name,), _scan)


def resolve_asset(root: str, category: str, kind: str, key: str):
    """按稳定键反查资产条目(查无返回 None)"""
    for asset in list_assets(root, category, kind):
        if asset["key"] == key:
            return asset
    return None


def _norm_path(path: str) -> str:
    """路径归一(解 // 相对前缀 + 绝对化 + 大小写归一, 供集合比对)"""
    return os.path.normcase(os.path.abspath(bpy.path.abspath(path)))


def is_asset_thumb(image) -> bool:
    """该图像数据块是否为资产选择器载入的缩略图(图像列表过滤用)"""
    return _norm_path(image.filepath) in _thumb_paths


def preview_icon_id(thumb_path: str) -> int:
    """缩略图的预览图标 id(数据块查重加载 + preview_ensure, ch_ai 画廊同款机制)

    载入的缩略图按路径记入会话集合(图像列表据此过滤), 0 使用者不随 .blend 保存;
    文件缺失/不可读(含 OneDrive 仅云占位)按约定静默返回 0 画空位.
    """
    image = find_or_load_image(thumb_path)
    if image is None:
        return 0
    _thumb_paths.add(_norm_path(image.filepath))
    image.preview_ensure()
    preview = image.preview
    return preview.icon_id if preview is not None else 0


def find_or_load_image(source_path: str):
    """按绝对路径取图像数据块(同路径查重复用, 查重按已载入数据块)"""
    if not source_path:
        return None
    try:
        return bpy.data.images.load(source_path, check_existing=True)
    except (RuntimeError, ValueError):
        # 文件缺失/不可读(含 OneDrive 仅云占位): 按约定不提示, 保持现状
        return None
