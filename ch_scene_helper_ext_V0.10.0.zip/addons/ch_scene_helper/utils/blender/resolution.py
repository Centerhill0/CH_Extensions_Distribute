"""
相机独立分辨率模块

每个相机可设独立输出分辨率(RNA 属性组 CameraResolutionSettings 挂物体, 随 .blend 保存):
相机成为场景相机后覆写场景输出分辨率, 离开时回落到覆写前记录的基准值
(SceneResolutionState 挂场景, 同样随 .blend 保存). 开关与数值的即时同步由属性组
update 回调(props.on_camera_resolution_update)触发, 改场景相机的其它路径由 handlers 兜底.

主要功能:
- camera_resolution: 取相机的独立分辨率, 未启用返回 None
- init_camera_resolution_from_scene: 首次开启时以场景输出分辨率初始化 X/Y
- sync_active_camera_resolution: 按当前场景相机同步场景输出分辨率(幂等, 可重复调用)

注:
- 只覆写 render.resolution_x/y, 分辨率百分比不动
- 同步无反馈环: 应用后标记与输出一致, 重复调用即 no-op
- 本层经 getattr 访问 RNA 属性组(不 import props.py, 分层规则); 属性组缺失
  (插件注销窗口期)一律视作未启用/无状态, 不抛异常
"""

from bpy.types import Object, Scene

from .....common.blender.list_snapshot import set_guarded
from .._constants import CAMERA_RES_MAX

# 独立分辨率的有效下限(对齐原生 render.resolution_x 的语义); 上限与属性组 RNA 同源,
# 见 utils/_constants.py 的 CAMERA_RES_MAX
_RES_MIN = 4


def _resolution_settings(obj: Object):
    """取物体的独立分辨率属性组; 属性未挂载(注销窗口期)返回 None"""
    return getattr(obj, "ch_resolution", None)


def camera_resolution(obj: Object) -> tuple[int, int] | None:
    """取相机的独立分辨率, 未启用或数值未初始化(低于下限)返回 None"""
    settings = _resolution_settings(obj)
    if settings is None or not settings.use_independent:
        return None
    if settings.res_x >= _RES_MIN and settings.res_y >= _RES_MIN:
        return (settings.res_x, settings.res_y)
    return None


def init_camera_resolution_from_scene(settings, scene: Scene) -> None:
    """首次开启(res 出厂为 0)以场景输出分辨率初始化 X/Y, 关闭再开启保留上次数值

    写入经护栏: 本函数由 update 回调进入, 普通赋值会再次回触 update——场景输出退化
    (<4px)时写入值仍低于下限, 同值写无限递归; 护栏内写不再回触.
    """
    if settings.res_x < _RES_MIN or settings.res_y < _RES_MIN:
        # 场景输出可能超出属性组 RNA 上限, 收进合法区间
        set_guarded(settings, "res_x", min(scene.render.resolution_x, CAMERA_RES_MAX))
        set_guarded(settings, "res_y", min(scene.render.resolution_y, CAMERA_RES_MAX))


def _restore_base(scene: Scene, state) -> None:
    """把场景输出分辨率回落到覆写前记录的基准值"""
    if state.has_base:
        scene.render.resolution_x = state.base_x
        scene.render.resolution_y = state.base_y


def sync_active_camera_resolution(scene: Scene) -> None:
    """按当前场景相机同步场景输出分辨率(幂等状态机)

    - 覆写源相机变更/失去独立分辨率/场景相机清空 -> 恢复基准并清标记
    - 从非覆写态进入覆写态 -> 重记基准(以用户最新手动值为准)
    - 已覆写相机的独立值变化 -> 输出跟随(属性 update 回调即时, 此处兜底)
    """
    render = scene.render
    state = getattr(scene, "ch_res_state", None)
    if state is None:
        return
    cam = scene.camera
    cam_name = cam.name if cam is not None else ""
    applied = state.applied_src
    override = camera_resolution(cam) if cam is not None else None

    if applied and applied != cam_name:
        # 离开覆写态(切到其它相机或清空场景相机): 回落基准
        _restore_base(scene, state)
        state.applied_src = ""
        applied = ""
    if override is None:
        if applied:
            # 覆写源相机被关闭独立分辨率: 同样回落
            _restore_base(scene, state)
            state.applied_src = ""
        return
    if applied != cam_name:
        # 进入覆写态: 把当前输出记为基准(覆写态之间切换不重记, 基准保持用户原值)
        state.has_base = True
        state.base_x = render.resolution_x
        state.base_y = render.resolution_y
    if (render.resolution_x, render.resolution_y) != override:
        render.resolution_x, render.resolution_y = override
    state.applied_src = cam_name
